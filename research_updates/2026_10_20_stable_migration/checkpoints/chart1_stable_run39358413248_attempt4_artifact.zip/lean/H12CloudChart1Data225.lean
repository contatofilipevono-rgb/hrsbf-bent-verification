import H12CloudChart1Data224

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound56983 : H12AffineFastState.Bounded env56983 := by
  intro p hp
  have h : env56983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56982_56983 : H12AffineEnvironment.transform 8 42 env56982 = env56983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env56982 == env56983) = true)

theorem identity56983 : scanCanonicalize (H12AffineFastState.compose env56983 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound56983 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56984 : List Nat := [2,4,8,11,32,42,35,4,42,47,0,10,40,42,43,3,33,32,47,43,11,32,42,34,2,10,11,42,0,33,36,10,5,0,32,42]

theorem envBound56984 : H12AffineFastState.Bounded env56984 := by
  intro p hp
  have h : env56984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56983_56984 : H12AffineEnvironment.transform 6 35 env56983 = env56984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env56983 == env56984) = true)

theorem identity56984 : scanCanonicalize (H12AffineFastState.compose env56984 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56984 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56985 : List Nat := [2,4,8,11,0,10,3,4,10,15,0,10,8,10,11,3,1,0,15,11,11,0,10,2,2,10,11,10,0,1,4,10,5,0,0,10]

theorem envBound56985 : H12AffineFastState.Bounded env56985 := by
  intro p hp
  have h : env56985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56984_56985 : H12AffineEnvironment.transform 4 0 env56984 = env56985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56984 == env56985) = true)

theorem identity56985 : scanCanonicalize (H12AffineFastState.compose env56985 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56985 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56986 : List Nat := [2,4,3,0,0,1,3,4,1,4,0,1,3,1,0,3,1,0,4,0,0,0,1,2,2,1,0,1,0,1,4,1,5,0,0,1]

theorem envBound56986 : H12AffineFastState.Bounded env56986 := by
  intro p hp
  have h : env56986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56985_56986 : H12AffineEnvironment.transform 2 3 env56985 = env56986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56985 == env56986) = true)

def env56987 : List Nat := [2,4,8,16,32,64,128,256,512,393,815,4096,89,4177,249,374,4605,4583,393,249,4469,32,308,82,208,357,4123,4177,4525,522,85,169,257,112,4604,512]

theorem envBound56987 : H12AffineFastState.Bounded env56987 := by
  intro p hp
  have h : env56987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56971_56987 : H12AffineEnvironment.transform 9 393 env56971 = env56987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env56971 == env56987) = true)

def env56988 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,4096,41,4129,137,262,4493,4503,393,137,4357,32,308,34,160,277,4123,4129,4525,522,37,169,257,0,4492,512]

theorem envBound56988 : H12AffineFastState.Bounded env56988 := by
  intro p hp
  have h : env56988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56987_56988 : H12AffineEnvironment.transform 5 48 env56987 = env56988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56987 == env56988) = true)

theorem identity56988 : scanCanonicalize (H12AffineFastState.compose env56988 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 814) := by decide +kernel

theorem selectedBound56988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56989 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,814,41,783,137,262,675,697,393,137,555,32,308,34,160,277,821,783,643,522,37,169,257,0,674,512]

theorem envBound56989 : H12AffineFastState.Bounded env56989 := by
  intro p hp
  have h : env56989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56988_56989 : H12AffineEnvironment.transform 11 814 env56988 = env56989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 814 env56988 == env56989) = true)

theorem identity56989 : scanCanonicalize (H12AffineFastState.compose env56989 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound56989 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56990 : List Nat := [2,4,8,16,32,48,128,256,163,393,396,397,41,428,137,262,0,26,393,137,136,32,308,34,160,277,406,428,32,169,37,169,257,0,1,163]

theorem envBound56990 : H12AffineFastState.Bounded env56990 := by
  intro p hp
  have h : env56990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56989_56990 : H12AffineEnvironment.transform 8 163 env56989 = env56990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env56989 == env56990) = true)

def env56991 : List Nat := [2,4,8,16,32,48,128,4,163,141,136,137,41,168,137,2,0,26,141,137,136,32,48,34,160,17,146,168,32,169,37,169,5,0,1,163]

theorem envBound56991 : H12AffineFastState.Bounded env56991 := by
  intro p hp
  have h : env56991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56990_56991 : H12AffineEnvironment.transform 7 4 env56990 = env56991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56990 == env56991) = true)

theorem identity56991 : scanCanonicalize (H12AffineFastState.compose env56991 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56991 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env56992 : List Nat := [2,4,8,16,0,16,128,4,131,141,136,137,9,136,137,2,0,26,141,137,136,0,16,2,128,17,146,136,0,137,5,137,5,0,1,131]

theorem envBound56992 : H12AffineFastState.Bounded env56992 := by
  intro p hp
  have h : env56992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56991_56992 : H12AffineEnvironment.transform 4 0 env56991 = env56992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56991 == env56992) = true)

theorem identity56992 : scanCanonicalize (H12AffineFastState.compose env56992 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound56992 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56993 : List Nat := [2,4,8,16,0,16,18,4,17,31,26,27,9,26,27,2,0,26,31,27,26,0,16,2,18,17,0,26,0,27,5,27,5,0,1,17]

theorem envBound56993 : H12AffineFastState.Bounded env56993 := by
  intro p hp
  have h : env56993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56992_56993 : H12AffineEnvironment.transform 6 18 env56992 = env56993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env56992 == env56993) = true)

theorem identity56993 : scanCanonicalize (H12AffineFastState.compose env56993 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56993 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56994 : List Nat := [2,4,3,16,0,16,18,4,17,20,17,16,2,17,16,2,0,17,20,16,17,0,16,2,18,17,0,17,0,16,5,16,5,0,1,17]

theorem envBound56994 : H12AffineFastState.Bounded env56994 := by
  intro p hp
  have h : env56994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56993_56994 : H12AffineEnvironment.transform 2 3 env56993 = env56994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56993 == env56994) = true)

def env56995 : List Nat := [2,4,8,16,32,48,128,5,163,140,137,136,41,169,137,3,0,26,140,137,136,32,49,34,160,16,147,169,32,169,37,169,4,0,1,163]

theorem envBound56995 : H12AffineFastState.Bounded env56995 := by
  intro p hp
  have h : env56995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56990_56995 : H12AffineEnvironment.transform 7 5 env56990 = env56995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56990 == env56995) = true)

theorem identity56995 : scanCanonicalize (H12AffineFastState.compose env56995 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56995 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env56996 : List Nat := [2,4,8,0,32,32,128,5,163,140,137,136,41,169,137,3,0,10,140,137,136,32,33,34,160,0,131,169,32,169,37,169,4,0,1,163]

theorem envBound56996 : H12AffineFastState.Bounded env56996 := by
  intro p hp
  have h : env56996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56995_56996 : H12AffineEnvironment.transform 3 0 env56995 = env56996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56995 == env56996) = true)

def env56997 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,4096,40,4128,136,263,4492,4502,393,136,4356,32,308,35,161,276,4123,4128,4525,522,36,169,257,1,4493,512]

theorem envBound56997 : H12AffineFastState.Bounded env56997 := by
  intro p hp
  have h : env56997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56987_56997 : H12AffineEnvironment.transform 5 49 env56987 = env56997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56987 == env56997) = true)

theorem identity56997 : scanCanonicalize (H12AffineFastState.compose env56997 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 903) := by decide +kernel

theorem selectedBound56997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56998 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,903,40,935,136,263,523,529,393,136,643,32,308,35,161,276,924,935,554,522,36,169,257,1,522,512]

theorem envBound56998 : H12AffineFastState.Bounded env56998 := by
  intro p hp
  have h : env56998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56997_56998 : H12AffineEnvironment.transform 11 903 env56997 = env56998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 903 env56997 == env56998) = true)

theorem identity56998 : scanCanonicalize (H12AffineFastState.compose env56998 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 444) := by decide +kernel

theorem selectedBound56998 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56999 : List Nat := [2,4,8,16,32,49,128,256,444,393,147,59,40,27,136,263,439,429,393,136,319,32,308,35,161,276,32,27,406,438,36,169,257,1,438,444]

theorem envBound56999 : H12AffineFastState.Bounded env56999 := by
  intro p hp
  have h : env56999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56998_56999 : H12AffineEnvironment.transform 8 444 env56998 = env56999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 444 env56998 == env56999) = true)

theorem identity56999 : scanCanonicalize (H12AffineFastState.compose env56999 (packedSelected [1,13] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound56999 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env57000 : List Nat := [2,4,8,16,32,49,128,30,162,151,147,59,40,27,136,25,169,179,151,136,33,32,42,35,161,10,32,27,136,168,36,169,31,1,168,162]

theorem envBound57000 : H12AffineFastState.Bounded env57000 := by
  intro p hp
  have h : env57000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56999_57000 : H12AffineEnvironment.transform 7 30 env56999 = env57000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env56999 == env57000) = true)

theorem identity57000 : scanCanonicalize (H12AffineFastState.compose env57000 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57000 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57001 : List Nat := [2,4,8,16,32,49,41,30,11,62,58,59,40,27,33,25,0,26,62,33,33,32,42,35,8,10,32,27,33,1,36,0,31,1,1,11]

theorem envBound57001 : H12AffineFastState.Bounded env57001 := by
  intro p hp
  have h : env57001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57000_57001 : H12AffineEnvironment.transform 6 41 env57000 = env57001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57000 == env57001) = true)

def env57002 : List Nat := [2,4,8,0,32,33,41,14,11,46,42,43,40,11,33,9,0,10,46,33,33,32,42,35,8,10,32,11,33,1,36,0,15,1,1,11]

theorem envBound57002 : H12AffineFastState.Bounded env57002 := by
  intro p hp
  have h : env57002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57001_57002 : H12AffineEnvironment.transform 3 0 env57001 = env57002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57001 == env57002) = true)

theorem identity57002 : scanCanonicalize (H12AffineFastState.compose env57002 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57003 : List Nat := [2,4,8,0,11,10,2,14,11,5,1,0,3,11,10,9,0,10,5,10,10,11,1,8,8,10,11,11,10,1,15,0,15,1,1,11]

theorem envBound57003 : H12AffineFastState.Bounded env57003 := by
  intro p hp
  have h : env57003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57002_57003 : H12AffineEnvironment.transform 4 11 env57002 = env57003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57002 == env57003) = true)

def env57004 : List Nat := [2,4,8,1,32,32,41,15,11,47,43,42,40,10,33,8,0,11,47,33,33,32,42,35,8,10,32,10,33,1,36,0,14,1,1,11]

theorem envBound57004 : H12AffineFastState.Bounded env57004 := by
  intro p hp
  have h : env57004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57001_57004 : H12AffineEnvironment.transform 3 1 env57001 = env57004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57001 == env57004) = true)

def env57005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142598,28889,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57005 : H12AffineFastState.Bounded env57005 := by
  intro p hp
  have h : env57005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56964_57005 : H12AffineEnvironment.transform 21 41089 env56964 = env57005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56964 == env57005) = true)

theorem identity57005 : scanCanonicalize (H12AffineFastState.compose env57005 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 98402) := by decide +kernel

theorem selectedBound57005 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,98402,41089,102434,78308,28889,114722,103452,16384,77954,96346,46565,74119,257,57368,78035,21072]

theorem envBound57006 : H12AffineFastState.Bounded env57006 := by
  intro p hp
  have h : env57006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57005_57006 : H12AffineEnvironment.transform 20 98402 env57005 = env57006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 98402 env57005 == env57006) = true)

theorem identity57006 : scanCanonicalize (H12AffineFastState.compose env57006 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57006 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,32768,65536,78034,79256,1024,32768,98402,41089,102434,78308,1409,111994,103452,13656,77954,68866,46565,74119,257,38208,78035,9992]

theorem envBound57007 : H12AffineFastState.Bounded env57007 := by
  intro p hp
  have h : env57007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57006_57007 : H12AffineEnvironment.transform 13 13656 env57006 = env57007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57006 == env57007) = true)

theorem identity57007 : scanCanonicalize (H12AffineFastState.compose env57007 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5609) := by decide +kernel

theorem selectedBound57007 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5609,65536,78034,79256,1024,5609,71051,13672,67019,78308,1409,73875,66037,13656,77954,68866,8204,74119,257,169,78035,9992]

theorem envBound57008 : H12AffineFastState.Bounded env57008 := by
  intro p hp
  have h : env57008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57007_57008 : H12AffineEnvironment.transform 14 5609 env57007 = env57008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5609 env57007 == env57008) = true)

theorem identity57008 : scanCanonicalize (H12AffineFastState.compose env57008 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57008 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5609,65536,71131,69777,1024,5609,71051,4193,67019,70893,1409,66970,66037,4177,71051,68866,1285,66702,257,169,71130,513]

theorem envBound57009 : H12AffineFastState.Bounded env57009 := by
  intro p hp
  have h : env57009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57008_57009 : H12AffineEnvironment.transform 12 1289 env57008 = env57009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57008 == env57009) = true)

theorem identity57009 : scanCanonicalize (H12AffineFastState.compose env57009 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound57009 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5609,515,6104,4754,1024,5609,6024,4193,1992,5870,1409,1945,1014,4177,6024,3841,1285,1677,257,169,6105,513]

theorem envBound57010 : H12AffineFastState.Bounded env57010 := by
  intro p hp
  have h : env57010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57009_57010 : H12AffineEnvironment.transform 15 515 env57009 = env57010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env57009 == env57010) = true)

theorem identity57010 : scanCanonicalize (H12AffineFastState.compose env57010 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57010 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,444,1028,515,1589,895,1024,1028,1637,396,1992,1795,1409,1945,1014,444,1637,3841,1285,1677,257,169,1588,513]

theorem envBound57011 : H12AffineFastState.Bounded env57011 := by
  intro p hp
  have h : env57011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57010_57011 : H12AffineEnvironment.transform 11 493 env57010 = env57011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57010 == env57011) = true)

theorem identity57011 : scanCanonicalize (H12AffineFastState.compose env57011 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57011 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,493,1289,444,1028,515,1589,895,1024,1028,1637,396,1992,1795,1409,1945,1014,444,1637,10,1285,1677,257,169,1588,513]

theorem envBound57012 : H12AffineFastState.Bounded env57012 := by
  intro p hp
  have h : env57012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57011_57012 : H12AffineEnvironment.transform 10 1803 env57011 = env57012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57011 == env57012) = true)

theorem identity57012 : scanCanonicalize (H12AffineFastState.compose env57012 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound57012 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57013 : List Nat := [2,4,8,16,32,64,128,256,512,905,130,493,640,444,909,515,444,895,905,909,492,396,65,138,520,16,1014,444,492,10,652,260,257,169,445,513]

theorem envBound57013 : H12AffineFastState.Bounded env57013 := by
  intro p hp
  have h : env57013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57012_57013 : H12AffineEnvironment.transform 9 905 env57012 = env57013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env57012 == env57013) = true)

theorem identity57013 : scanCanonicalize (H12AffineFastState.compose env57013 (packedSelected [0,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound57013 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env57014 : List Nat := [2,4,8,16,32,64,120,256,512,881,122,277,632,324,885,515,324,895,881,885,276,372,65,114,520,16,782,324,276,10,628,260,257,81,325,513]

theorem envBound57014 : H12AffineFastState.Bounded env57014 := by
  intro p hp
  have h : env57014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57013_57014 : H12AffineEnvironment.transform 6 120 env57013 = env57014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env57013 == env57014) = true)

def env57015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295815,4247640,6348993,4273308,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256465]

theorem envBound57015 : H12AffineFastState.Bounded env57015 := by
  intro p hp
  have h : env57015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56963_57015 : H12AffineEnvironment.transform 17 82113 env56963 = env57015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env56963 == env57015) = true)

def env57016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142599,28888,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57016 : H12AffineFastState.Bounded env57016 := by
  intro p hp
  have h : env57016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57015_57016 : H12AffineEnvironment.transform 21 41088 env57015 = env57016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57015 == env57016) = true)

theorem identity57016 : scanCanonicalize (H12AffineFastState.compose env57016 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 103794) := by decide +kernel

theorem selectedBound57016 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,103794,41088,99635,74997,28888,120115,103452,16384,77954,96347,41204,74118,257,62729,78035,21073]

theorem envBound57017 : H12AffineFastState.Bounded env57017 := by
  intro p hp
  have h : env57017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57016_57017 : H12AffineEnvironment.transform 20 103794 env57016 = env57017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 103794 env57016 == env57017) = true)

theorem identity57017 : scanCanonicalize (H12AffineFastState.compose env57017 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 20649) := by decide +kernel

theorem selectedBound57017 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20649,65536,78034,82113,1024,20649,83419,28713,87450,74997,28888,66970,83125,16384,77954,96347,28765,74118,257,9632,78035,21073]

theorem envBound57018 : H12AffineFastState.Bounded env57018 := by
  intro p hp
  have h : env57018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57017_57018 : H12AffineEnvironment.transform 14 20649 env57017 = env57018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20649 env57017 == env57018) = true)

theorem identity57018 : scanCanonicalize (H12AffineFastState.compose env57018 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57018 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,65536,78034,69776,1024,248,71050,8312,67019,74997,8329,66970,70884,4177,77954,75786,8204,74118,257,9632,78035,512]

theorem envBound57019 : H12AffineFastState.Bounded env57019 := by
  intro p hp
  have h : env57019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57018_57019 : H12AffineEnvironment.transform 13 4177 env57018 = env57019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57018 == env57019) = true)

theorem identity57019 : scanCanonicalize (H12AffineFastState.compose env57019 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound57019 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,375,12709,4583,1024,248,5373,8312,1212,9602,8329,1261,5523,4177,12789,10621,8204,8433,257,9632,12708,512]

theorem envBound57020 : H12AffineFastState.Bounded env57020 := by
  intro p hp
  have h : env57020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57019_57020 : H12AffineEnvironment.transform 15 375 env57019 = env57020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env57019 == env57020) = true)

theorem identity57020 : scanCanonicalize (H12AffineFastState.compose env57020 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound57020 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,248,375,8027,4583,1024,248,5373,3718,1212,2940,3703,1261,5523,4177,7947,1923,3826,3599,257,2910,8026,512]

theorem envBound57021 : H12AffineFastState.Bounded env57021 := by
  intro p hp
  have h : env57021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57020_57021 : H12AffineEnvironment.transform 12 3838 env57020 = env57021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env57020 == env57021) = true)

theorem identity57021 : scanCanonicalize (H12AffineFastState.compose env57021 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound57021 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,4096,88,4177,248,375,4605,4583,1024,248,5373,32,1212,1498,209,1261,5523,4177,4525,1923,84,169,257,1528,4604,512]

theorem envBound57022 : H12AffineFastState.Bounded env57022 := by
  intro p hp
  have h : env57022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57021_57022 : H12AffineEnvironment.transform 10 1702 env57021 = env57022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env57021 == env57022) = true)

def env57023 : List Nat := [2,4,8,16,32,64,128,256,512,392,814,4096,88,4177,248,375,4605,4583,392,248,4469,32,308,82,209,357,4123,4177,4525,523,84,169,257,112,4604,512]

theorem envBound57023 : H12AffineFastState.Bounded env57023 := by
  intro p hp
  have h : env57023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57022_57023 : H12AffineEnvironment.transform 9 392 env57022 = env57023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env57022 == env57023) = true)

def env57024 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,4096,40,4129,136,263,4493,4503,392,136,4357,32,308,34,161,277,4123,4129,4525,523,36,169,257,0,4492,512]

theorem envBound57024 : H12AffineFastState.Bounded env57024 := by
  intro p hp
  have h : env57024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57023_57024 : H12AffineEnvironment.transform 5 48 env57023 = env57024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57023 == env57024) = true)

theorem identity57024 : scanCanonicalize (H12AffineFastState.compose env57024 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 903) := by decide +kernel

theorem selectedBound57024 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57025 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,903,40,934,136,263,522,528,392,136,642,32,308,34,161,277,924,934,554,523,36,169,257,0,523,512]

theorem envBound57025 : H12AffineFastState.Bounded env57025 := by
  intro p hp
  have h : env57025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57024_57025 : H12AffineEnvironment.transform 11 903 env57024 = env57025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 903 env57024 == env57025) = true)

theorem identity57025 : scanCanonicalize (H12AffineFastState.compose env57025 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 445) := by decide +kernel

theorem selectedBound57025 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57026 : List Nat := [2,4,8,16,32,48,128,256,445,392,147,58,40,27,136,263,439,429,392,136,319,32,308,34,161,277,33,27,407,438,36,169,257,0,438,445]

theorem envBound57026 : H12AffineFastState.Bounded env57026 := by
  intro p hp
  have h : env57026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57025_57026 : H12AffineEnvironment.transform 8 445 env57025 = env57026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 445 env57025 == env57026) = true)

theorem identity57026 : scanCanonicalize (H12AffineFastState.compose env57026 (packedSelected [1,13] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57026 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env57027 : List Nat := [2,4,8,16,32,48,128,31,162,151,147,58,40,27,136,24,168,178,151,136,32,32,43,34,161,10,33,27,136,169,36,169,30,0,169,162]

theorem envBound57027 : H12AffineFastState.Bounded env57027 := by
  intro p hp
  have h : env57027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57026_57027 : H12AffineEnvironment.transform 7 31 env57026 = env57027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57026 == env57027) = true)

theorem identity57027 : scanCanonicalize (H12AffineFastState.compose env57027 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57027 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57028 : List Nat := [2,4,8,16,32,48,40,31,10,63,59,58,40,27,32,24,0,26,63,32,32,32,43,34,9,10,33,27,32,1,36,1,30,0,1,10]

theorem envBound57028 : H12AffineFastState.Bounded env57028 := by
  intro p hp
  have h : env57028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57027_57028 : H12AffineEnvironment.transform 6 40 env57027 = env57028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57027 == env57028) = true)

def env57029 : List Nat := [2,4,8,0,32,32,40,15,10,47,43,42,40,11,32,8,0,10,47,32,32,32,43,34,9,10,33,11,32,1,36,1,14,0,1,10]

theorem envBound57029 : H12AffineFastState.Bounded env57029 := by
  intro p hp
  have h : env57029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57028_57029 : H12AffineEnvironment.transform 3 0 env57028 = env57029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57028 == env57029) = true)

def env57030 : List Nat := [2,4,8,1,32,33,40,14,10,46,42,43,40,10,32,9,0,11,46,32,32,32,43,34,9,10,33,10,32,1,36,1,15,0,1,10]

theorem envBound57030 : H12AffineFastState.Bounded env57030 := by
  intro p hp
  have h : env57030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57028_57030 : H12AffineEnvironment.transform 3 1 env57028 = env57030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57028 == env57030) = true)

theorem identity57030 : scanCanonicalize (H12AffineFastState.compose env57030 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57031 : List Nat := [2,4,8,1,11,10,3,14,10,5,1,0,3,10,11,9,0,11,5,11,11,11,0,9,9,10,10,10,11,1,15,1,15,0,1,10]

theorem envBound57031 : H12AffineFastState.Bounded env57031 := by
  intro p hp
  have h : env57031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57030_57031 : H12AffineEnvironment.transform 4 11 env57030 = env57031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57030 == env57031) = true)

def env57032 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,4096,41,4128,137,262,4492,4502,392,137,4356,32,308,35,160,276,4123,4128,4525,523,37,169,257,1,4493,512]

theorem envBound57032 : H12AffineFastState.Bounded env57032 := by
  intro p hp
  have h : env57032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57023_57032 : H12AffineEnvironment.transform 5 49 env57023 = env57032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57023 == env57032) = true)

theorem identity57032 : scanCanonicalize (H12AffineFastState.compose env57032 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 815) := by decide +kernel

theorem selectedBound57032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57033 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,815,41,783,137,262,675,697,392,137,555,32,308,35,160,276,820,783,642,523,37,169,257,1,674,512]

theorem envBound57033 : H12AffineFastState.Bounded env57033 := by
  intro p hp
  have h : env57033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57032_57033 : H12AffineEnvironment.transform 11 815 env57032 = env57033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 815 env57032 == env57033) = true)

theorem identity57033 : scanCanonicalize (H12AffineFastState.compose env57033 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound57033 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57034 : List Nat := [2,4,8,16,32,49,128,256,163,392,397,396,41,428,137,262,0,26,392,137,136,32,308,35,160,276,407,428,33,168,37,169,257,1,1,163]

theorem envBound57034 : H12AffineFastState.Bounded env57034 := by
  intro p hp
  have h : env57034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57033_57034 : H12AffineEnvironment.transform 8 163 env57033 = env57034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env57033 == env57034) = true)

def env57035 : List Nat := [2,4,8,16,32,49,128,4,163,140,137,136,41,168,137,2,0,26,140,137,136,32,48,35,160,16,147,168,33,168,37,169,5,1,1,163]

theorem envBound57035 : H12AffineFastState.Bounded env57035 := by
  intro p hp
  have h : env57035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57034_57035 : H12AffineEnvironment.transform 7 4 env57034 = env57035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57034 == env57035) = true)

theorem identity57035 : scanCanonicalize (H12AffineFastState.compose env57035 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57035 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57036 : List Nat := [2,4,8,1,32,32,128,4,163,140,137,136,41,168,137,2,0,11,140,137,136,32,33,35,160,1,130,168,33,168,37,169,5,1,1,163]

theorem envBound57036 : H12AffineFastState.Bounded env57036 := by
  intro p hp
  have h : env57036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57035_57036 : H12AffineEnvironment.transform 3 1 env57035 = env57036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57035 == env57036) = true)

def env57037 : List Nat := [2,4,8,16,32,49,128,5,163,141,136,137,41,169,137,3,0,26,141,137,136,32,49,35,160,17,146,169,33,168,37,169,4,1,1,163]

theorem envBound57037 : H12AffineFastState.Bounded env57037 := by
  intro p hp
  have h : env57037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57034_57037 : H12AffineEnvironment.transform 7 5 env57034 = env57037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57034 == env57037) = true)

theorem identity57037 : scanCanonicalize (H12AffineFastState.compose env57037 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57037 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57038 : List Nat := [2,4,8,16,1,16,128,5,130,141,136,137,8,136,137,3,0,26,141,137,136,1,16,2,129,17,146,136,0,137,4,136,4,1,1,130]

theorem envBound57038 : H12AffineFastState.Bounded env57038 := by
  intro p hp
  have h : env57038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57037_57038 : H12AffineEnvironment.transform 4 1 env57037 = env57038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57037 == env57038) = true)

theorem identity57038 : scanCanonicalize (H12AffineFastState.compose env57038 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57039 : List Nat := [2,4,8,16,1,16,18,5,16,31,26,27,8,26,27,3,0,26,31,27,26,1,16,2,19,17,0,26,0,27,4,26,4,1,1,16]

theorem envBound57039 : H12AffineFastState.Bounded env57039 := by
  intro p hp
  have h : env57039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57038_57039 : H12AffineEnvironment.transform 6 18 env57038 = env57039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57038 == env57039) = true)

theorem identity57039 : scanCanonicalize (H12AffineFastState.compose env57039 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57039 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57040 : List Nat := [2,4,2,16,1,16,18,5,16,21,16,17,2,16,17,3,0,16,21,17,16,1,16,2,19,17,0,16,0,17,4,16,4,1,1,16]

theorem envBound57040 : H12AffineFastState.Bounded env57040 := by
  intro p hp
  have h : env57040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57039_57040 : H12AffineEnvironment.transform 2 2 env57039 = env57040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57039 == env57040) = true)

def env57041 : List Nat := [2,4,8,16,32,64,128,256,512,393,815,4096,88,4177,248,375,4605,4583,393,248,4468,32,309,83,209,356,4122,4177,4525,522,84,169,257,113,4604,512]

theorem envBound57041 : H12AffineFastState.Bounded env57041 := by
  intro p hp
  have h : env57041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57022_57041 : H12AffineEnvironment.transform 9 393 env57022 = env57041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env57022 == env57041) = true)

def env57042 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,4096,40,4129,136,263,4493,4503,393,136,4356,32,309,35,161,276,4122,4129,4525,522,36,169,257,1,4492,512]

theorem envBound57042 : H12AffineFastState.Bounded env57042 := by
  intro p hp
  have h : env57042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57041_57042 : H12AffineEnvironment.transform 5 48 env57041 = env57042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57041 == env57042) = true)

theorem identity57042 : scanCanonicalize (H12AffineFastState.compose env57042 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound57042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57043 : List Nat := [2,4,8,16,32,48,128,256,512,393,815,642,40,675,136,263,783,789,393,136,902,32,309,35,161,276,664,675,815,522,36,169,257,1,782,512]

theorem envBound57043 : H12AffineFastState.Bounded env57043 := by
  intro p hp
  have h : env57043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57042_57043 : H12AffineEnvironment.transform 11 642 env57042 = env57043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env57042 == env57043) = true)

theorem identity57043 : scanCanonicalize (H12AffineFastState.compose env57043 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound57043 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57044 : List Nat := [2,4,8,16,32,48,128,189,512,52,658,642,40,675,136,186,690,680,52,136,571,32,136,35,161,169,664,675,658,522,36,169,188,1,691,512]

theorem envBound57044 : H12AffineFastState.Bounded env57044 := by
  intro p hp
  have h : env57044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57043_57044 : H12AffineEnvironment.transform 7 189 env57043 = env57044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env57043 == env57044) = true)

theorem identity57044 : scanCanonicalize (H12AffineFastState.compose env57044 (packedSelected [0,3,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57044 : packedSelected [0,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env57045 : List Nat := [2,4,8,11,32,43,128,166,512,47,649,642,40,675,136,161,681,680,47,136,544,32,136,35,161,169,643,675,649,522,36,169,167,1,680,512]

theorem envBound57045 : H12AffineFastState.Bounded env57045 := by
  intro p hp
  have h : env57045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57044_57045 : H12AffineEnvironment.transform 3 11 env57044 = env57045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57044 == env57045) = true)

theorem identity57045 : scanCanonicalize (H12AffineFastState.compose env57045 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound57045 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57046 : List Nat := [2,4,8,11,32,43,128,166,42,47,163,168,40,137,136,161,131,130,47,136,10,32,136,35,161,169,169,137,163,32,36,169,167,1,130,42]

theorem envBound57046 : H12AffineFastState.Bounded env57046 := by
  intro p hp
  have h : env57046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57045_57046 : H12AffineEnvironment.transform 8 42 env57045 = env57046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env57045 == env57046) = true)

theorem identity57046 : scanCanonicalize (H12AffineFastState.compose env57046 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound57046 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57047 : List Nat := [2,4,8,11,32,43,35,5,42,47,0,11,40,42,43,2,32,33,47,43,10,32,43,35,2,10,10,42,0,32,36,10,4,1,33,42]

theorem envBound57047 : H12AffineFastState.Bounded env57047 := by
  intro p hp
  have h : env57047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57046_57047 : H12AffineEnvironment.transform 6 35 env57046 = env57047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env57046 == env57047) = true)

theorem identity57047 : scanCanonicalize (H12AffineFastState.compose env57047 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57047 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57048 : List Nat := [2,4,8,11,1,10,2,5,11,14,0,11,9,11,10,2,1,0,14,10,10,1,10,2,2,10,10,11,0,1,5,10,4,1,0,11]

theorem envBound57048 : H12AffineFastState.Bounded env57048 := by
  intro p hp
  have h : env57048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57047_57048 : H12AffineEnvironment.transform 4 1 env57047 = env57048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57047 == env57048) = true)

theorem identity57048 : scanCanonicalize (H12AffineFastState.compose env57048 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57049 : List Nat := [2,4,2,1,1,0,2,5,1,4,0,1,3,1,0,2,1,0,4,0,0,1,0,2,2,0,0,1,0,1,5,0,4,1,0,1]

theorem envBound57049 : H12AffineFastState.Bounded env57049 := by
  intro p hp
  have h : env57049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57048_57049 : H12AffineEnvironment.transform 2 2 env57048 = env57049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57048 == env57049) = true)

def env57050 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,4096,41,4128,137,262,4492,4502,393,137,4357,32,309,34,160,277,4122,4128,4525,522,37,169,257,0,4493,512]

theorem envBound57050 : H12AffineFastState.Bounded env57050 := by
  intro p hp
  have h : env57050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57041_57050 : H12AffineEnvironment.transform 5 49 env57041 = env57050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57041 == env57050) = true)

theorem identity57050 : scanCanonicalize (H12AffineFastState.compose env57050 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound57050 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57051 : List Nat := [2,4,8,16,32,49,128,256,512,393,815,554,41,522,137,262,934,956,393,137,815,32,309,34,160,277,560,522,903,522,37,169,257,0,935,512]

theorem envBound57051 : H12AffineFastState.Bounded env57051 := by
  intro p hp
  have h : env57051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57050_57051 : H12AffineEnvironment.transform 11 554 env57050 = env57051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env57050 == env57051) = true)

theorem identity57051 : scanCanonicalize (H12AffineFastState.compose env57051 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound57051 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57052 : List Nat := [2,4,8,16,32,49,128,167,512,46,648,554,41,522,137,161,513,539,46,137,648,32,146,34,160,178,560,522,544,522,37,169,166,0,512,512]

theorem envBound57052 : H12AffineFastState.Bounded env57052 := by
  intro p hp
  have h : env57052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57051_57052 : H12AffineEnvironment.transform 7 167 env57051 = env57052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env57051 == env57052) = true)

theorem identity57052 : scanCanonicalize (H12AffineFastState.compose env57052 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57052 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57053 : List Nat := [2,4,8,16,32,49,40,15,512,46,544,554,41,522,33,9,513,539,46,33,544,32,58,34,8,26,560,522,544,522,37,1,14,0,512,512]

theorem envBound57053 : H12AffineFastState.Bounded env57053 := by
  intro p hp
  have h : env57053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57052_57053 : H12AffineEnvironment.transform 6 40 env57052 = env57053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57052 == env57053) = true)

theorem identity57053 : scanCanonicalize (H12AffineFastState.compose env57053 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57053 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57054 : List Nat := [2,4,8,10,32,43,40,15,512,46,544,554,41,522,33,9,513,513,46,33,544,32,32,34,8,0,554,522,544,522,37,1,14,0,512,512]

theorem envBound57054 : H12AffineFastState.Bounded env57054 := by
  intro p hp
  have h : env57054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57053_57054 : H12AffineEnvironment.transform 3 10 env57053 = env57054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57053 == env57054) = true)

theorem identity57054 : scanCanonicalize (H12AffineFastState.compose env57054 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57055 : List Nat := [2,4,8,10,10,1,2,15,512,4,522,512,3,522,11,9,513,513,4,11,522,10,10,8,8,0,512,522,522,522,15,1,14,0,512,512]

theorem envBound57055 : H12AffineFastState.Bounded env57055 := by
  intro p hp
  have h : env57055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57054_57055 : H12AffineEnvironment.transform 4 10 env57054 = env57055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57054 == env57055) = true)

def env57056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142598,28889,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57056 : H12AffineFastState.Bounded env57056 := by
  intro p hp
  have h : env57056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57015_57056 : H12AffineEnvironment.transform 21 41089 env57015 = env57056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57015 == env57056) = true)

theorem identity57056 : scanCanonicalize (H12AffineFastState.compose env57056 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 118835) := by decide +kernel

theorem selectedBound57056 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,118835,41089,114803,90549,28889,102515,103453,16384,77954,96346,58804,74119,257,45129,78035,21072]

theorem envBound57057 : H12AffineFastState.Bounded env57057 := by
  intro p hp
  have h : env57057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57056_57057 : H12AffineEnvironment.transform 20 118835 env57056 = env57057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 118835 env57056 == env57057) = true)

theorem identity57057 : scanCanonicalize (H12AffineFastState.compose env57057 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57057 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,32768,65536,78034,79257,1024,32768,107883,41089,111915,70893,1409,102515,103453,13656,77954,68866,37100,74119,257,45129,78035,9992]

theorem envBound57058 : H12AffineFastState.Bounded env57058 := by
  intro p hp
  have h : env57058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57057_57058 : H12AffineEnvironment.transform 13 13656 env57057 = env57058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57057 == env57058) = true)

theorem identity57058 : scanCanonicalize (H12AffineFastState.compose env57058 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound57058 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12512,65536,78034,79257,1024,12512,71051,4193,67019,70893,1409,73875,75005,13656,77954,68866,8204,74119,257,169,78035,9992]

theorem envBound57059 : H12AffineFastState.Bounded env57059 := by
  intro p hp
  have h : env57059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57058_57059 : H12AffineEnvironment.transform 14 12512 env57058 = env57059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env57058 == env57059) = true)

theorem identity57059 : scanCanonicalize (H12AffineFastState.compose env57059 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57059 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5609,65536,71131,69776,1024,5609,71051,4193,67019,70893,1409,66970,66036,4177,71051,68866,1285,66702,257,169,71130,513]

theorem envBound57060 : H12AffineFastState.Bounded env57060 := by
  intro p hp
  have h : env57060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57059_57060 : H12AffineEnvironment.transform 12 1289 env57059 = env57060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57059 == env57060) = true)

theorem identity57060 : scanCanonicalize (H12AffineFastState.compose env57060 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound57060 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5609,515,6104,4755,1024,5609,6024,4193,1992,5870,1409,1945,1015,4177,6024,3841,1285,1677,257,169,6105,513]

theorem envBound57061 : H12AffineFastState.Bounded env57061 := by
  intro p hp
  have h : env57061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57060_57061 : H12AffineEnvironment.transform 15 515 env57060 = env57061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env57060 == env57061) = true)

theorem identity57061 : scanCanonicalize (H12AffineFastState.compose env57061 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57061 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,444,1028,515,1589,894,1024,1028,1637,396,1992,1795,1409,1945,1015,444,1637,3841,1285,1677,257,169,1588,513]

theorem envBound57062 : H12AffineFastState.Bounded env57062 := by
  intro p hp
  have h : env57062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57061_57062 : H12AffineEnvironment.transform 11 493 env57061 = env57062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57061 == env57062) = true)

theorem identity57062 : scanCanonicalize (H12AffineFastState.compose env57062 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound57062 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,493,1289,444,1028,515,1589,894,1024,1028,1637,396,1992,1795,1409,1945,1015,444,1637,11,1285,1677,257,169,1588,513]

theorem envBound57063 : H12AffineFastState.Bounded env57063 := by
  intro p hp
  have h : env57063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57062_57063 : H12AffineEnvironment.transform 10 1802 env57062 = env57063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env57062 == env57063) = true)

theorem identity57063 : scanCanonicalize (H12AffineFastState.compose env57063 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57063 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57064 : List Nat := [2,4,8,16,32,64,128,256,512,904,130,493,641,444,908,515,445,894,904,908,493,396,64,139,521,17,1015,444,493,11,653,261,257,169,444,513]

theorem envBound57064 : H12AffineFastState.Bounded env57064 := by
  intro p hp
  have h : env57064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57063_57064 : H12AffineEnvironment.transform 9 904 env57063 = env57064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57063 == env57064) = true)

theorem identity57064 : scanCanonicalize (H12AffineFastState.compose env57064 (packedSelected [0,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound57064 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env57065 : List Nat := [2,4,8,16,32,64,25,256,512,785,27,372,536,293,789,515,292,894,785,789,372,277,64,18,521,17,878,293,372,11,532,261,257,48,293,513]

theorem envBound57065 : H12AffineFastState.Bounded env57065 := by
  intro p hp
  have h : env57065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57064_57065 : H12AffineEnvironment.transform 6 25 env57064 = env57065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env57064 == env57065) = true)

theorem identity57065 : scanCanonicalize (H12AffineFastState.compose env57065 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 383) := by decide +kernel

theorem selectedBound57065 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57066 : List Nat := [2,4,8,16,32,64,25,256,383,110,27,372,359,293,106,380,292,1,110,106,372,277,64,18,374,17,17,293,372,11,363,261,257,48,293,382]

theorem envBound57066 : H12AffineFastState.Bounded env57066 := by
  intro p hp
  have h : env57066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57065_57066 : H12AffineEnvironment.transform 8 383 env57065 = env57066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 383 env57065 == env57066) = true)

theorem identity57066 : scanCanonicalize (H12AffineFastState.compose env57066 (packedSelected [4,5,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57066 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env57067 : List Nat := [2,4,3,16,32,64,18,256,372,101,16,372,359,293,97,375,292,1,101,97,372,277,64,18,374,17,17,293,372,0,352,261,257,48,293,373]

theorem envBound57067 : H12AffineFastState.Bounded env57067 := by
  intro p hp
  have h : env57067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57066_57067 : H12AffineEnvironment.transform 2 3 env57066 = env57067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57066 == env57067) = true)

theorem identity57067 : scanCanonicalize (H12AffineFastState.compose env57067 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57067 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57068 : List Nat := [2,4,3,0,32,64,2,256,356,101,0,356,359,293,97,359,292,1,101,97,356,261,64,2,358,1,1,293,356,0,352,261,257,32,293,357]

theorem envBound57068 : H12AffineFastState.Bounded env57068 := by
  intro p hp
  have h : env57068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57067_57068 : H12AffineEnvironment.transform 3 0 env57067 = env57068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57067 == env57068) = true)

theorem identity57068 : scanCanonicalize (H12AffineFastState.compose env57068 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 39) := by decide +kernel

theorem selectedBound57068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57069 : List Nat := [2,4,3,0,32,64,2,39,67,101,0,67,64,2,97,64,3,1,101,97,67,34,64,2,65,1,1,2,67,0,71,34,38,32,2,66]

theorem envBound57069 : H12AffineFastState.Bounded env57069 := by
  intro p hp
  have h : env57069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57068_57069 : H12AffineEnvironment.transform 7 39 env57068 = env57069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 39 env57068 == env57069) = true)

theorem identity57069 : scanCanonicalize (H12AffineFastState.compose env57069 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound57069 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57070 : List Nat := [2,4,3,0,2,64,2,5,67,71,0,67,64,2,67,64,3,1,71,67,67,0,64,2,65,1,1,2,67,0,71,0,4,2,2,66]

theorem envBound57070 : H12AffineFastState.Bounded env57070 := by
  intro p hp
  have h : env57070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57069_57070 : H12AffineEnvironment.transform 4 2 env57069 = env57070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env57069 == env57070) = true)

theorem identity57070 : scanCanonicalize (H12AffineFastState.compose env57070 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound57070 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env57071 : List Nat := [2,4,3,0,2,2,2,5,1,5,0,1,2,2,1,2,3,1,5,1,1,0,2,2,3,1,1,2,1,0,5,0,4,2,2,0]

theorem envBound57071 : H12AffineFastState.Bounded env57071 := by
  intro p hp
  have h : env57071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57070_57071 : H12AffineEnvironment.transform 5 2 env57070 = env57071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env57070 == env57071) = true)

theorem identity57071 : scanCanonicalize (H12AffineFastState.compose env57071 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57071 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57072 : List Nat := [1,4,0,0,1,1,1,5,1,5,0,1,1,1,1,1,0,1,5,1,1,0,1,1,0,1,1,1,1,0,5,0,4,1,1,0]

theorem envBound57072 : H12AffineFastState.Bounded env57072 := by
  intro p hp
  have h : env57072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57071_57072 : H12AffineEnvironment.transform 0 1 env57071 = env57072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57071 == env57072) = true)

def env57073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,4247641,8409088,10798236,16384,77954,4315355,8463815,10564039,257,6406395,78035,4256464]

theorem envBound57073 : H12AffineFastState.Bounded env57073 := by
  intro p hp
  have h : env57073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56826_57073 : H12AffineEnvironment.transform 24 4247641 env56826 = env57073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env56826 == env57073) = true)

def env57074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295814,4247641,6348992,4486236,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256464]

theorem envBound57074 : H12AffineFastState.Bounded env57074 := by
  intro p hp
  have h : env57074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57073_57074 : H12AffineEnvironment.transform 22 6336704 env57073 = env57074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env57073 == env57074) = true)

def env57075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295814,4247641,6348992,4273308,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256464]

theorem envBound57075 : H12AffineFastState.Bounded env57075 := by
  intro p hp
  have h : env57075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57074_57075 : H12AffineEnvironment.transform 17 82112 env57074 = env57075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57074 == env57075) = true)

def env57076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142598,28889,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound57076 : H12AffineFastState.Bounded env57076 := by
  intro p hp
  have h : env57076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57075_57076 : H12AffineEnvironment.transform 21 41088 env57075 = env57076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57075 == env57076) = true)

theorem identity57076 : scanCanonicalize (H12AffineFastState.compose env57076 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 87094) := by decide +kernel

theorem selectedBound57076 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,87094,41088,83062,124336,28889,70774,103452,16384,77954,96347,25009,74119,257,13389,78035,21072]

theorem envBound57077 : H12AffineFastState.Bounded env57077 := by
  intro p hp
  have h : env57077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57076_57077 : H12AffineEnvironment.transform 20 87094 env57076 = env57077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 87094 env57076 == env57077) = true)

theorem identity57077 : scanCanonicalize (H12AffineFastState.compose env57077 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57077 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,16384,32768,65536,71131,82112,1024,32768,87094,34185,83062,114873,21968,70774,103452,16384,71051,89426,17592,66702,257,4420,71130,21072]

theorem envBound57078 : H12AffineFastState.Bounded env57078 := by
  intro p hp
  have h : env57078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57077_57078 : H12AffineEnvironment.transform 12 1289 env57077 = env57078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57077 == env57078) = true)

theorem identity57078 : scanCanonicalize (H12AffineFastState.compose env57078 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57078 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,16384,32768,65536,66615,82112,1024,32768,83418,34185,83062,114873,17468,66970,99824,16384,66663,85182,17592,66702,257,168,66614,17340]

theorem envBound57079 : H12AffineFastState.Bounded env57079 := by
  intro p hp
  have h : env57079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57078_57079 : H12AffineEnvironment.transform 11 492 env57078 = env57079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57078 == env57079) = true)

theorem identity57079 : scanCanonicalize (H12AffineFastState.compose env57079 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound57079 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,65536,66615,65916,1024,32768,66662,34185,67018,98565,1408,66970,99824,444,66663,68866,1284,66702,257,168,66614,512]

theorem envBound57080 : H12AffineFastState.Bounded env57080 := by
  intro p hp
  have h : env57080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57079_57080 : H12AffineEnvironment.transform 13 444 env57079 = env57080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57079 == env57080) = true)

theorem identity57080 : scanCanonicalize (H12AffineFastState.compose env57080 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound57080 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,1875,868,1583,1024,32768,821,34185,665,34390,1408,713,33443,444,820,2641,1284,989,257,168,869,512]

theorem envBound57081 : H12AffineFastState.Bounded env57081 := by
  intro p hp
  have h : env57081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57080_57081 : H12AffineEnvironment.transform 15 1875 env57080 = env57081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env57080 == env57081) = true)

def env57082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142599,28888,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound57082 : H12AffineFastState.Bounded env57082 := by
  intro p hp
  have h : env57082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57075_57082 : H12AffineEnvironment.transform 21 41089 env57075 = env57082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57075 == env57082) = true)

theorem identity57082 : scanCanonicalize (H12AffineFastState.compose env57082 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 70007) := by decide +kernel

theorem selectedBound57082 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,70007,41089,65846,106736,28888,86326,103453,16384,77954,96346,9457,74118,257,28941,78035,21073]

theorem envBound57083 : H12AffineFastState.Bounded env57083 := by
  intro p hp
  have h : env57083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57082_57083 : H12AffineEnvironment.transform 20 70007 env57082 = env57083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70007 env57082 == env57083) = true)

theorem identity57083 : scanCanonicalize (H12AffineFastState.compose env57083 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound57083 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57084 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,16384,32768,65536,78034,82112,252,32768,70007,41089,65846,106736,28888,86326,102625,16384,77954,96346,8205,74118,257,28941,78035,21073]

theorem envBound57084 : H12AffineFastState.Bounded env57084 := by
  intro p hp
  have h : env57084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57083_57084 : H12AffineEnvironment.transform 9 252 env57083 = env57084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env57083 == env57084) = true)

theorem identity57084 : scanCanonicalize (H12AffineFastState.compose env57084 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound57084 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57085 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,16384,32768,33167,45405,49487,252,32768,37112,41089,32953,8575,28888,53433,4462,16384,45325,63957,8205,40969,257,28941,45404,21073]

theorem envBound57085 : H12AffineFastState.Bounded env57085 := by
  intro p hp
  have h : env57085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57084_57085 : H12AffineEnvironment.transform 15 33167 env57084 = env57085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env57084 == env57085) = true)

def env57086 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,4096,32768,33167,45405,37199,252,32768,37112,41089,32953,8575,8408,32953,4462,4096,45325,43477,8205,40969,257,8461,45404,593]

theorem envBound57086 : H12AffineFastState.Bounded env57086 := by
  intro p hp
  have h : env57086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57085_57086 : H12AffineEnvironment.transform 13 4096 env57085 = env57086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env57085 == env57086) = true)

def env57087 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4096,32768,33167,45325,37151,172,32768,37032,41089,32953,8495,8328,32953,4414,4096,45325,43397,8205,40969,257,8461,45324,513]

theorem envBound57087 : H12AffineFastState.Bounded env57087 := by
  intro p hp
  have h : env57087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57086_57087 : H12AffineEnvironment.transform 5 16 env57086 = env57087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57086 == env57087) = true)

theorem identity57087 : scanCanonicalize (H12AffineFastState.compose env57087 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound57087 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57088 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4096,32,431,12589,4415,172,32,4232,8353,153,8495,8328,153,4414,4096,12589,10661,8205,8233,257,8461,12588,513]

theorem envBound57088 : H12AffineFastState.Bounded env57088 := by
  intro p hp
  have h : env57088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57087_57088 : H12AffineEnvironment.transform 14 32 env57087 = env57088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env57087 == env57088) = true)

theorem identity57088 : scanCanonicalize (H12AffineFastState.compose env57088 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound57088 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57089 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,300,4096,32,431,4097,4415,172,32,4232,397,153,3,420,153,4414,4096,4097,2185,289,261,257,33,4096,513]

theorem envBound57089 : H12AffineFastState.Bounded env57089 := by
  intro p hp
  have h : env57089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57088_57089 : H12AffineEnvironment.transform 12 300 env57088 = env57089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env57088 == env57089) = true)

theorem identity57089 : scanCanonicalize (H12AffineFastState.compose env57089 (packedSelected [0,1,2,4,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 781) := by decide +kernel

theorem selectedBound57089 : packedSelected [0,1,2,4,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57090 : List Nat := [2,4,8,16,32,16,128,256,512,172,781,4096,300,4096,32,431,4097,4415,172,32,4232,397,153,3,420,153,4414,4096,4097,900,289,261,257,33,4096,513]

theorem envBound57090 : H12AffineFastState.Bounded env57090 := by
  intro p hp
  have h : env57090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57089_57090 : H12AffineEnvironment.transform 10 781 env57089 = env57090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 781 env57089 == env57090) = true)

theorem identity57090 : scanCanonicalize (H12AffineFastState.compose env57090 (packedSelected [0,1,2,4,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 926) := by decide +kernel

theorem selectedBound57090 : packedSelected [0,1,2,4,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57091 : List Nat := [2,4,8,16,32,16,128,256,512,172,781,926,300,926,32,431,927,673,172,32,790,397,153,3,420,153,672,926,927,900,289,261,257,33,926,513]

theorem envBound57091 : H12AffineFastState.Bounded env57091 := by
  intro p hp
  have h : env57091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57090_57091 : H12AffineEnvironment.transform 11 926 env57090 = env57091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 926 env57090 == env57091) = true)

theorem identity57091 : scanCanonicalize (H12AffineFastState.compose env57091 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 142) := by decide +kernel

theorem selectedBound57091 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57092 : List Nat := [2,4,8,16,32,16,128,142,512,172,643,528,162,528,32,33,529,673,172,32,664,3,153,3,42,153,672,528,529,522,175,139,143,33,528,513]

theorem envBound57092 : H12AffineFastState.Bounded env57092 := by
  intro p hp
  have h : env57092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57091_57092 : H12AffineEnvironment.transform 7 142 env57091 = env57092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 142 env57091 == env57092) = true)

theorem identity57092 : scanCanonicalize (H12AffineFastState.compose env57092 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 155) := by decide +kernel

theorem selectedBound57092 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env57093 : List Nat := [2,4,8,16,32,16,128,142,155,172,24,139,162,139,32,33,138,58,172,32,3,3,153,3,42,153,59,139,138,145,175,139,143,33,139,154]

theorem envBound57093 : H12AffineFastState.Bounded env57093 := by
  intro p hp
  have h : env57093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57092_57093 : H12AffineEnvironment.transform 8 155 env57092 = env57093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 155 env57092 == env57093) = true)

theorem identity57093 : scanCanonicalize (H12AffineFastState.compose env57093 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound57093 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57094 : List Nat := [2,4,8,16,32,16,42,36,49,6,24,33,8,33,32,33,32,58,6,32,3,3,51,3,42,51,59,33,32,59,5,33,37,33,33,48]

theorem envBound57094 : H12AffineFastState.Bounded env57094 := by
  intro p hp
  have h : env57094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57093_57094 : H12AffineEnvironment.transform 6 42 env57093 = env57094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env57093 == env57094) = true)

theorem identity57094 : scanCanonicalize (H12AffineFastState.compose env57094 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound57094 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57095 : List Nat := [2,4,8,16,9,16,3,13,24,6,24,8,8,8,9,8,9,19,6,9,3,3,26,3,3,26,18,8,9,18,5,8,12,8,8,25]

theorem envBound57095 : H12AffineFastState.Bounded env57095 := by
  intro p hp
  have h : env57095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57094_57095 : H12AffineEnvironment.transform 4 9 env57094 = env57095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env57094 == env57095) = true)

def env57096 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,4096,8192,4096,32768,33167,45324,37150,173,32768,37033,41089,32953,8494,8329,32953,4415,4096,45325,43396,8205,40969,257,8461,45325,512]

theorem envBound57096 : H12AffineFastState.Bounded env57096 := by
  intro p hp
  have h : env57096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57086_57096 : H12AffineEnvironment.transform 5 17 env57086 = env57096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57086 == env57096) = true)

theorem identity57096 : scanCanonicalize (H12AffineFastState.compose env57096 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound57096 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57097 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,4096,2562,4096,32768,33167,39694,37150,173,32768,37033,35459,32953,2860,2699,32953,4415,4096,39695,33670,2575,35339,257,2831,39695,512]

theorem envBound57097 : H12AffineFastState.Bounded env57097 := by
  intro p hp
  have h : env57097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57096_57097 : H12AffineEnvironment.transform 12 2562 env57096 = env57097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env57096 == env57097) = true)

theorem identity57097 : scanCanonicalize (H12AffineFastState.compose env57097 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57097 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57098 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,4096,2562,4096,2723,2860,4525,7101,173,2723,6666,32,2586,2860,2699,2586,4415,4096,4524,2341,2575,168,257,2831,4524,512]

theorem envBound57098 : H12AffineFastState.Bounded env57098 := by
  intro p hp
  have h : env57098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57097_57098 : H12AffineEnvironment.transform 14 2723 env57097 = env57098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57097 == env57098) = true)

theorem identity57098 : scanCanonicalize (H12AffineFastState.compose env57098 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound57098 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57099 : List Nat := [2,4,8,16,32,17,128,256,512,173,2048,545,2562,545,2723,2860,908,2460,173,2723,2091,32,2586,2860,2699,2586,798,545,909,2341,2575,168,257,2831,909,512]

theorem envBound57099 : H12AffineFastState.Bounded env57099 := by
  intro p hp
  have h : env57099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57098_57099 : H12AffineEnvironment.transform 11 545 env57098 = env57099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env57098 == env57099) = true)

theorem identity57099 : scanCanonicalize (H12AffineFastState.compose env57099 (packedSelected [1,3,4,9,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57099 : packedSelected [1,3,4,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57100 : List Nat := [2,4,8,16,32,17,128,20,512,173,2048,545,2562,545,2723,2616,664,2184,173,2723,2091,32,2586,2616,2699,2586,522,545,665,2097,2575,168,21,2587,665,512]

theorem envBound57100 : H12AffineFastState.Bounded env57100 := by
  intro p hp
  have h : env57100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57099_57100 : H12AffineEnvironment.transform 7 20 env57099 = env57100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57099 == env57100) = true)

theorem identity57100 : scanCanonicalize (H12AffineFastState.compose env57100 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 690) := by decide +kernel

theorem selectedBound57100 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57101 : List Nat := [2,4,8,16,32,17,128,20,512,173,690,545,176,545,17,138,664,570,173,17,665,32,168,138,57,168,522,545,665,643,189,168,21,169,665,512]

theorem envBound57101 : H12AffineFastState.Bounded env57101 := by
  intro p hp
  have h : env57101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57100_57101 : H12AffineEnvironment.transform 10 690 env57100 = env57101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 690 env57100 == env57101) = true)

def env57102 : List Nat := [2,4,8,16,32,17,128,20,48,173,130,17,176,17,17,138,168,10,173,17,169,32,168,138,57,168,58,17,169,179,189,168,21,169,169,48]

theorem envBound57102 : H12AffineFastState.Bounded env57102 := by
  intro p hp
  have h : env57102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57101_57102 : H12AffineEnvironment.transform 8 48 env57101 = env57102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env57101 == env57102) = true)

theorem identity57102 : scanCanonicalize (H12AffineFastState.compose env57102 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57102 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57103 : List Nat := [2,4,8,16,32,17,51,20,48,30,49,17,3,17,17,57,27,10,30,17,26,32,27,57,57,27,58,17,26,0,14,27,21,26,26,48]

theorem envBound57103 : H12AffineFastState.Bounded env57103 := by
  intro p hp
  have h : env57103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57102_57103 : H12AffineEnvironment.transform 6 51 env57102 = env57103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57102 == env57103) = true)

def env57104 : List Nat := [2,4,8,16,16,17,3,20,0,30,1,17,3,17,17,9,27,10,30,17,26,16,27,9,9,27,10,17,26,0,14,27,21,26,26,0]

theorem envBound57104 : H12AffineFastState.Bounded env57104 := by
  intro p hp
  have h : env57104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57103_57104 : H12AffineEnvironment.transform 4 16 env57103 = env57104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57103 == env57104) = true)

def env57105 : List Nat := [2,4,8,16,17,17,2,20,1,30,0,17,3,17,17,8,27,10,30,17,26,17,27,8,8,27,11,17,26,0,14,27,21,26,26,1]

theorem envBound57105 : H12AffineFastState.Bounded env57105 := by
  intro p hp
  have h : env57105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57103_57105 : H12AffineEnvironment.transform 4 17 env57103 = env57105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57103 == env57105) = true)

theorem identity57105 : scanCanonicalize (H12AffineFastState.compose env57105 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57106 : List Nat := [2,4,8,10,11,11,2,14,1,4,0,11,3,11,11,8,1,10,4,11,0,11,1,8,8,1,11,11,0,0,14,1,15,0,0,1]

theorem envBound57106 : H12AffineFastState.Bounded env57106 := by
  intro p hp
  have h : env57106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57105_57106 : H12AffineEnvironment.transform 3 10 env57105 = env57106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57105 == env57106) = true)

def env57107 : List Nat := [2,4,8,16,32,17,128,20,49,173,131,16,176,16,17,138,169,11,173,17,168,32,168,138,57,168,59,16,168,178,189,168,21,169,168,49]

theorem envBound57107 : H12AffineFastState.Bounded env57107 := by
  intro p hp
  have h : env57107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57101_57107 : H12AffineEnvironment.transform 8 49 env57101 = env57107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env57101 == env57107) = true)

theorem identity57107 : scanCanonicalize (H12AffineFastState.compose env57107 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57108 : List Nat := [2,4,8,16,27,17,128,20,10,150,131,16,139,16,17,138,146,11,150,17,147,27,147,138,2,147,0,16,147,137,134,147,21,146,147,10]

theorem envBound57108 : H12AffineFastState.Bounded env57108 := by
  intro p hp
  have h : env57108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57107_57108 : H12AffineEnvironment.transform 4 27 env57107 = env57108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57107 == env57108) = true)

def env57109 : List Nat := [2,4,8,0,11,1,128,4,10,134,131,0,139,0,1,138,130,11,134,1,131,11,131,138,2,131,0,0,131,137,134,131,5,130,131,10]

theorem envBound57109 : H12AffineFastState.Bounded env57109 := by
  intro p hp
  have h : env57109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57108_57109 : H12AffineEnvironment.transform 3 0 env57108 = env57109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57108 == env57109) = true)

theorem identity57109 : scanCanonicalize (H12AffineFastState.compose env57109 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57110 : List Nat := [2,4,2,0,1,1,128,4,0,134,131,0,129,0,1,128,130,1,134,1,131,1,131,128,2,131,0,0,131,131,134,131,5,130,131,0]

theorem envBound57110 : H12AffineFastState.Bounded env57110 := by
  intro p hp
  have h : env57110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57109_57110 : H12AffineEnvironment.transform 2 2 env57109 = env57110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57109 == env57110) = true)

def env57111 : List Nat := [2,4,8,1,10,0,128,5,10,135,131,1,139,1,0,138,131,11,135,0,130,10,130,138,2,130,0,1,130,137,134,130,4,131,130,10]

theorem envBound57111 : H12AffineFastState.Bounded env57111 := by
  intro p hp
  have h : env57111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57108_57111 : H12AffineEnvironment.transform 3 1 env57108 = env57111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57108 == env57111) = true)

def env57112 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,4097,32768,33167,45405,37198,252,32768,37112,41089,32953,8575,8409,32952,4462,4097,45325,43476,8205,40969,257,8460,45404,592]

theorem envBound57112 : H12AffineFastState.Bounded env57112 := by
  intro p hp
  have h : env57112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57085_57112 : H12AffineEnvironment.transform 13 4097 env57085 = env57112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env57085 == env57112) = true)

theorem identity57112 : scanCanonicalize (H12AffineFastState.compose env57112 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57112 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env57113 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4097,32768,33167,45325,37150,172,32768,37032,41089,32953,8495,8329,32952,4414,4097,45325,43396,8205,40969,257,8460,45324,512]

theorem envBound57113 : H12AffineFastState.Bounded env57113 := by
  intro p hp
  have h : env57113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57112_57113 : H12AffineEnvironment.transform 5 16 env57112 = env57113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57112 == env57113) = true)

theorem identity57113 : scanCanonicalize (H12AffineFastState.compose env57113 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound57113 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57114 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2562,4097,32768,33167,39695,37150,172,32768,37032,35459,32953,2861,2699,32952,4414,4097,39695,33670,2575,35339,257,2830,39694,512]

theorem envBound57114 : H12AffineFastState.Bounded env57114 := by
  intro p hp
  have h : env57114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57113_57114 : H12AffineEnvironment.transform 12 2562 env57113 = env57114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env57113 == env57114) = true)

theorem identity57114 : scanCanonicalize (H12AffineFastState.compose env57114 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57114 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57115 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2562,4097,2723,2860,4524,7101,172,2723,6667,32,2586,2861,2699,2587,4414,4097,4524,2341,2575,168,257,2830,4525,512]

theorem envBound57115 : H12AffineFastState.Bounded env57115 := by
  intro p hp
  have h : env57115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57114_57115 : H12AffineEnvironment.transform 14 2723 env57114 = env57115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57114 == env57115) = true)

theorem identity57115 : scanCanonicalize (H12AffineFastState.compose env57115 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound57115 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57116 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,2091,2562,2090,2723,2860,2439,918,172,2723,544,32,2586,2861,2699,2587,2325,2090,2439,2341,2575,168,257,2830,2438,512]

theorem envBound57116 : H12AffineFastState.Bounded env57116 := by
  intro p hp
  have h : env57116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57115_57116 : H12AffineEnvironment.transform 11 2091 env57115 = env57116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env57115 == env57116) = true)

theorem identity57116 : scanCanonicalize (H12AffineFastState.compose env57116 (packedSelected [0,1,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound57116 : packedSelected [0,1,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57117 : List Nat := [2,4,8,16,32,16,128,256,512,172,798,821,284,820,445,50,665,918,172,445,544,32,260,51,405,261,523,820,665,571,273,168,257,16,664,512]

theorem envBound57117 : H12AffineFastState.Bounded env57117 := by
  intro p hp
  have h : env57117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57116_57117 : H12AffineEnvironment.transform 10 798 env57116 = env57117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env57116 == env57117) = true)

theorem identity57117 : scanCanonicalize (H12AffineFastState.compose env57117 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57117 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57118 : List Nat := [2,4,8,16,32,16,57,256,512,21,798,821,284,820,260,50,544,815,21,260,544,32,260,51,300,261,523,820,544,571,273,17,257,16,545,512]

theorem envBound57118 : H12AffineFastState.Bounded env57118 := by
  intro p hp
  have h : env57118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57117_57118 : H12AffineEnvironment.transform 6 57 env57117 = env57118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57117 == env57118) = true)

def env57119 : List Nat := [2,4,8,16,16,16,9,256,512,21,798,773,284,772,260,2,528,799,21,260,528,16,260,3,284,261,523,772,528,523,273,17,257,16,529,512]

theorem envBound57119 : H12AffineFastState.Bounded env57119 := by
  intro p hp
  have h : env57119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57118_57119 : H12AffineEnvironment.transform 4 16 env57118 = env57119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57118 == env57119) = true)

theorem identity57119 : scanCanonicalize (H12AffineFastState.compose env57119 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57120 : List Nat := [2,4,8,16,16,16,9,31,512,21,513,538,3,539,27,2,528,512,21,27,528,16,27,3,3,26,523,539,528,523,14,17,30,16,529,512]

theorem envBound57120 : H12AffineFastState.Bounded env57120 := by
  intro p hp
  have h : env57120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57119_57120 : H12AffineEnvironment.transform 7 31 env57119 = env57120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57119 == env57120) = true)

theorem identity57120 : scanCanonicalize (H12AffineFastState.compose env57120 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57121 : List Nat := [2,4,8,11,11,11,9,4,512,14,513,513,3,512,0,2,523,512,14,0,523,11,0,3,3,1,523,512,523,523,14,10,5,11,522,512]

theorem envBound57121 : H12AffineFastState.Bounded env57121 := by
  intro p hp
  have h : env57121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57120_57121 : H12AffineEnvironment.transform 3 11 env57120 = env57121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57120 == env57121) = true)

def env57122 : List Nat := [2,4,8,16,17,16,8,256,512,21,798,772,284,773,260,3,529,798,21,260,529,17,260,2,285,261,523,773,529,522,273,17,257,16,528,512]

theorem envBound57122 : H12AffineFastState.Bounded env57122 := by
  intro p hp
  have h : env57122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57118_57122 : H12AffineEnvironment.transform 4 17 env57118 = env57122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57118 == env57122) = true)

theorem identity57122 : scanCanonicalize (H12AffineFastState.compose env57122 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57122 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57123 : List Nat := [2,4,8,16,17,16,8,256,11,21,277,271,284,270,260,3,26,277,21,260,26,17,260,2,285,261,0,270,26,1,273,17,257,16,27,11]

theorem envBound57123 : H12AffineFastState.Bounded env57123 := by
  intro p hp
  have h : env57123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57122_57123 : H12AffineEnvironment.transform 8 11 env57122 = env57123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57122 == env57123) = true)

theorem identity57123 : scanCanonicalize (H12AffineFastState.compose env57123 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57123 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57124 : List Nat := [2,4,8,16,17,16,8,14,11,21,27,1,18,0,10,3,26,27,21,10,26,17,10,2,19,11,0,0,26,1,31,17,15,16,27,11]

theorem envBound57124 : H12AffineFastState.Bounded env57124 := by
  intro p hp
  have h : env57124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57123_57124 : H12AffineEnvironment.transform 7 14 env57123 = env57124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57123 == env57124) = true)

def env57125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295814,4247641,6348992,4273309,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256464]

theorem envBound57125 : H12AffineFastState.Bounded env57125 := by
  intro p hp
  have h : env57125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57074_57125 : H12AffineEnvironment.transform 17 82113 env57074 = env57125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57074 == env57125) = true)

def env57126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142598,28889,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound57126 : H12AffineFastState.Bounded env57126 := by
  intro p hp
  have h : env57126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57125_57126 : H12AffineEnvironment.transform 21 41088 env57125 = env57126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57125 == env57126) = true)

theorem identity57126 : scanCanonicalize (H12AffineFastState.compose env57126 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 66663) := by decide +kernel

theorem selectedBound57126 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,66663,41088,70695,112097,28889,82983,103453,16384,77954,96347,12768,74119,257,25628,78035,21072]

theorem envBound57127 : H12AffineFastState.Bounded env57127 := by
  intro p hp
  have h : env57127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57126_57127 : H12AffineEnvironment.transform 20 66663 env57126 = env57127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66663 env57126 == env57127) = true)

theorem identity57127 : scanCanonicalize (H12AffineFastState.compose env57127 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57127 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,16384,32768,65536,71131,82113,1024,32768,66663,34185,70695,102632,21968,82983,103453,16384,71051,89426,5353,66702,257,16661,71130,21072]

theorem envBound57128 : H12AffineFastState.Bounded env57128 := by
  intro p hp
  have h : env57128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57127_57128 : H12AffineEnvironment.transform 12 1289 env57127 = env57128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57127 == env57128) = true)

theorem identity57128 : scanCanonicalize (H12AffineFastState.compose env57128 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound57128 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,445,32768,65536,71131,65916,1024,32768,66663,34185,70695,102632,5229,66970,103453,445,71051,72943,5353,66702,257,168,71130,5101]

theorem envBound57129 : H12AffineFastState.Bounded env57129 := by
  intro p hp
  have h : env57129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57128_57129 : H12AffineEnvironment.transform 13 445 env57128 = env57129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57128 == env57129) = true)

theorem identity57129 : scanCanonicalize (H12AffineFastState.compose env57129 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57129 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,65536,66614,65916,1024,32768,66663,34185,67018,98565,1408,66970,99824,445,66662,68866,1284,66702,257,168,66615,512]

theorem envBound57130 : H12AffineFastState.Bounded env57130 := by
  intro p hp
  have h : env57130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57129_57130 : H12AffineEnvironment.transform 11 493 env57129 = env57130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57129 == env57130) = true)

theorem identity57130 : scanCanonicalize (H12AffineFastState.compose env57130 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound57130 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,1875,869,1583,1024,32768,820,34185,665,34390,1408,713,33443,445,821,2641,1284,989,257,168,868,512]

theorem envBound57131 : H12AffineFastState.Bounded env57131 := by
  intro p hp
  have h : env57131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57130_57131 : H12AffineEnvironment.transform 15 1875 env57130 = env57131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env57130 == env57131) = true)

def env57132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142599,28888,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound57132 : H12AffineFastState.Bounded env57132 := by
  intro p hp
  have h : env57132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57125_57132 : H12AffineEnvironment.transform 21 41089 env57125 = env57132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57125 == env57132) = true)

theorem identity57132 : scanCanonicalize (H12AffineFastState.compose env57132 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 82215) := by decide +kernel

theorem selectedBound57132 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,82215,41089,86374,127136,28888,65894,103452,16384,77954,96346,29857,74118,257,8541,78035,21073]

theorem envBound57133 : H12AffineFastState.Bounded env57133 := by
  intro p hp
  have h : env57133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57132_57133 : H12AffineEnvironment.transform 20 82215 env57132 = env57133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82215 env57132 == env57133) = true)

theorem identity57133 : scanCanonicalize (H12AffineFastState.compose env57133 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound57133 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,65536,78034,70765,1024,32768,71051,41089,67018,107532,9332,65894,103452,5292,77954,77046,8205,74118,257,8541,78035,1789]

theorem envBound57134 : H12AffineFastState.Bounded env57134 := by
  intro p hp
  have h : env57134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57133_57134 : H12AffineEnvironment.transform 13 5292 env57133 = env57134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env57133 == env57134) = true)

theorem identity57134 : scanCanonicalize (H12AffineFastState.compose env57134 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound57134 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,33167,45405,38370,1024,32768,37892,41089,33861,9603,9332,33001,5523,5292,45325,44409,8205,40969,257,8541,45404,1789]

theorem envBound57135 : H12AffineFastState.Bounded env57135 := by
  intro p hp
  have h : env57135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57134_57135 : H12AffineEnvironment.transform 15 33167 env57134 = env57135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env57134 == env57135) = true)

def env57136 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5292,32768,33167,45325,38322,1024,32768,37892,41089,33813,9603,9252,32953,5523,5292,45325,44329,8205,40969,257,8461,45324,1709]

theorem envBound57136 : H12AffineFastState.Bounded env57136 := by
  intro p hp
  have h : env57136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57135_57136 : H12AffineEnvironment.transform 5 16 env57135 = env57136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57135 == env57136) = true)

theorem identity57136 : scanCanonicalize (H12AffineFastState.compose env57136 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound57136 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env57137 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4097,32768,33167,45325,37151,173,32768,37033,41089,32952,8494,8329,32953,4414,4097,45325,43396,8205,40969,257,8461,45324,512]

theorem envBound57137 : H12AffineFastState.Bounded env57137 := by
  intro p hp
  have h : env57137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57136_57137 : H12AffineEnvironment.transform 9 173 env57136 = env57137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env57136 == env57137) = true)

theorem identity57137 : scanCanonicalize (H12AffineFastState.compose env57137 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound57137 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57138 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2562,4097,32768,33167,39695,37151,173,32768,37033,35459,32952,2860,2699,32953,4414,4097,39695,33670,2575,35339,257,2831,39694,512]

theorem envBound57138 : H12AffineFastState.Bounded env57138 := by
  intro p hp
  have h : env57138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57137_57138 : H12AffineEnvironment.transform 12 2562 env57137 = env57138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env57137 == env57138) = true)

theorem identity57138 : scanCanonicalize (H12AffineFastState.compose env57138 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57138 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57139 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2562,4097,2723,2860,4524,7100,173,2723,6666,32,2587,2860,2699,2586,4414,4097,4524,2341,2575,168,257,2831,4525,512]

theorem envBound57139 : H12AffineFastState.Bounded env57139 := by
  intro p hp
  have h : env57139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57138_57139 : H12AffineEnvironment.transform 14 2723 env57138 = env57139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57138 == env57139) = true)

theorem identity57139 : scanCanonicalize (H12AffineFastState.compose env57139 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound57139 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57140 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,2091,2562,2090,2723,2860,2439,919,173,2723,545,32,2587,2860,2699,2586,2325,2090,2439,2341,2575,168,257,2831,2438,512]

theorem envBound57140 : H12AffineFastState.Bounded env57140 := by
  intro p hp
  have h : env57140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57139_57140 : H12AffineEnvironment.transform 11 2091 env57139 = env57140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env57139 == env57140) = true)

theorem identity57140 : scanCanonicalize (H12AffineFastState.compose env57140 (packedSelected [0,1,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound57140 : packedSelected [0,1,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57141 : List Nat := [2,4,8,16,32,16,128,256,512,173,799,820,285,821,444,51,664,919,173,444,545,32,260,51,404,261,522,821,664,570,272,168,257,16,665,512]

theorem envBound57141 : H12AffineFastState.Bounded env57141 := by
  intro p hp
  have h : env57141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57140_57141 : H12AffineEnvironment.transform 10 799 env57140 = env57141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env57140 == env57141) = true)

theorem identity57141 : scanCanonicalize (H12AffineFastState.compose env57141 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57141 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57142 : List Nat := [2,4,8,16,32,16,57,256,512,20,799,820,285,821,261,51,545,814,20,261,545,32,260,51,301,261,522,821,545,570,272,17,257,16,544,512]

theorem envBound57142 : H12AffineFastState.Bounded env57142 := by
  intro p hp
  have h : env57142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57141_57142 : H12AffineEnvironment.transform 6 57 env57141 = env57142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57141 == env57142) = true)

def env57143 : List Nat := [2,4,8,16,16,16,9,256,512,20,799,772,285,773,261,3,529,798,20,261,529,16,260,3,285,261,522,773,529,522,272,17,257,16,528,512]

theorem envBound57143 : H12AffineFastState.Bounded env57143 := by
  intro p hp
  have h : env57143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57142_57143 : H12AffineEnvironment.transform 4 16 env57142 = env57143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57142 == env57143) = true)

theorem identity57143 : scanCanonicalize (H12AffineFastState.compose env57143 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57144 : List Nat := [2,4,8,16,16,16,9,30,512,20,513,538,3,539,27,3,529,512,20,27,529,16,26,3,3,27,522,539,529,522,14,17,31,16,528,512]

theorem envBound57144 : H12AffineFastState.Bounded env57144 := by
  intro p hp
  have h : env57144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57143_57144 : H12AffineEnvironment.transform 7 30 env57143 = env57144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57143 == env57144) = true)

theorem identity57144 : scanCanonicalize (H12AffineFastState.compose env57144 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57145 : List Nat := [2,4,8,11,11,11,9,5,512,15,513,513,3,512,0,3,522,512,15,0,522,11,1,3,3,0,522,512,522,522,14,10,4,11,523,512]

theorem envBound57145 : H12AffineFastState.Bounded env57145 := by
  intro p hp
  have h : env57145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57144_57145 : H12AffineEnvironment.transform 3 11 env57144 = env57145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57144 == env57145) = true)

def env57146 : List Nat := [2,4,8,16,17,16,8,256,512,20,799,773,285,772,261,2,528,799,20,261,528,17,260,2,284,261,522,772,528,523,272,17,257,16,529,512]

theorem envBound57146 : H12AffineFastState.Bounded env57146 := by
  intro p hp
  have h : env57146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57142_57146 : H12AffineEnvironment.transform 4 17 env57142 = env57146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57142 == env57146) = true)

theorem identity57146 : scanCanonicalize (H12AffineFastState.compose env57146 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57146 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57147 : List Nat := [2,4,8,16,17,16,8,256,10,20,277,271,285,270,261,2,26,277,20,261,26,17,260,2,284,261,0,270,26,1,272,17,257,16,27,10]

theorem envBound57147 : H12AffineFastState.Bounded env57147 := by
  intro p hp
  have h : env57147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57146_57147 : H12AffineEnvironment.transform 8 10 env57146 = env57147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57146 == env57147) = true)

theorem identity57147 : scanCanonicalize (H12AffineFastState.compose env57147 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57147 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57148 : List Nat := [2,4,8,16,17,16,8,14,10,20,27,1,19,0,11,2,26,27,20,11,26,17,10,2,18,11,0,0,26,1,30,17,15,16,27,10]

theorem envBound57148 : H12AffineFastState.Bounded env57148 := by
  intro p hp
  have h : env57148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57147_57148 : H12AffineEnvironment.transform 7 14 env57147 = env57148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57147 == env57148) = true)

def env57149 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5292,32768,33167,45324,38323,1024,32768,37892,41089,33812,9603,9253,32952,5523,5292,45325,44328,8205,40969,257,8460,45325,1708]

theorem envBound57149 : H12AffineFastState.Bounded env57149 := by
  intro p hp
  have h : env57149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57135_57149 : H12AffineEnvironment.transform 5 17 env57135 = env57149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57135 == env57149) = true)

def env57150 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5276,32768,33167,45324,38275,1024,32768,37892,41089,33812,9603,9237,32904,5523,5276,45325,44312,8205,40969,257,8460,45325,1692]

theorem envBound57150 : H12AffineFastState.Bounded env57150 := by
  intro p hp
  have h : env57150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57149_57150 : H12AffineEnvironment.transform 4 16 env57149 = env57150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57149 == env57150) = true)

def env57151 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5276,1296,1183,13340,4243,1024,1296,4372,9617,260,9603,9237,1432,5523,5276,13341,10248,8205,9497,257,8460,13341,1692]

theorem envBound57151 : H12AffineFastState.Bounded env57151 := by
  intro p hp
  have h : env57151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57150_57151 : H12AffineEnvironment.transform 14 1296 env57150 = env57151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env57150 == env57151) = true)

theorem identity57151 : scanCanonicalize (H12AffineFastState.compose env57151 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6406) := by decide +kernel

theorem selectedBound57151 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57152 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,6406,5276,1296,1183,3354,4243,1024,1296,4372,7319,260,7301,7443,1432,5523,5276,3355,4366,6411,7199,257,6154,3355,1692]

theorem envBound57152 : H12AffineFastState.Bounded env57152 := by
  intro p hp
  have h : env57152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57151_57152 : H12AffineEnvironment.transform 12 6406 env57151 = env57152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6406 env57151 == env57152) = true)

theorem identity57152 : scanCanonicalize (H12AffineFastState.compose env57152 (packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound57152 : packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env57153 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,1944,3742,772,1296,1183,3354,1803,1024,1296,1676,2831,260,2845,2699,1432,523,772,3355,1686,3731,2951,257,3986,3355,1692]

theorem envBound57153 : H12AffineFastState.Bounded env57153 := by
  intro p hp
  have h : env57153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57152_57153 : H12AffineEnvironment.transform 11 1944 env57152 = env57153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env57152 == env57153) = true)

theorem identity57153 : scanCanonicalize (H12AffineFastState.compose env57153 (packedSelected [8,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57153 : packedSelected [8,10,13] rootPS < 2^1333 := by decide +kernel

def env57154 : List Nat := [2,4,8,16,16,17,2,256,512,1024,2048,1818,3612,772,1296,1053,3354,1803,1024,1296,1550,2831,260,2845,2569,1306,523,772,3355,1556,3601,2821,257,3856,3355,1566]

theorem envBound57154 : H12AffineFastState.Bounded env57154 := by
  intro p hp
  have h : env57154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57153_57154 : H12AffineEnvironment.transform 6 2 env57153 = env57154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57153 == env57154) = true)

theorem identity57154 : scanCanonicalize (H12AffineFastState.compose env57154 (packedSelected [4,5,7,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound57154 : packedSelected [4,5,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57155 : List Nat := [2,4,8,16,16,17,2,256,512,1024,789,1818,1289,772,1296,1053,1551,1803,1024,1296,1550,26,260,8,284,1306,523,772,1550,1556,1284,16,257,1029,1550,1566]

theorem envBound57155 : H12AffineFastState.Bounded env57155 := by
  intro p hp
  have h : env57155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57154_57155 : H12AffineEnvironment.transform 10 789 env57154 = env57155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env57154 == env57155) = true)

theorem identity57155 : scanCanonicalize (H12AffineFastState.compose env57155 (packedSelected [0,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound57155 : packedSelected [0,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57156 : List Nat := [2,4,8,16,16,17,2,256,512,20,789,782,285,772,260,9,539,799,20,260,538,26,260,8,284,270,523,772,538,512,272,16,257,17,538,522]

theorem envBound57156 : H12AffineFastState.Bounded env57156 := by
  intro p hp
  have h : env57156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57155_57156 : H12AffineEnvironment.transform 9 20 env57155 = env57156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env57155 == env57156) = true)

theorem identity57156 : scanCanonicalize (H12AffineFastState.compose env57156 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57156 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57157 : List Nat := [2,4,8,11,11,10,2,256,512,15,782,782,262,772,260,9,512,772,15,260,513,1,260,8,263,270,523,772,513,512,267,11,257,10,513,522]

theorem envBound57157 : H12AffineFastState.Bounded env57157 := by
  intro p hp
  have h : env57157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57156_57157 : H12AffineEnvironment.transform 3 11 env57156 = env57157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57156 == env57157) = true)

theorem identity57157 : scanCanonicalize (H12AffineFastState.compose env57157 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57157 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57158 : List Nat := [2,4,2,1,1,0,2,256,512,5,772,772,262,772,260,3,512,772,5,260,513,1,260,2,263,260,513,772,513,512,257,1,257,0,513,512]

theorem envBound57158 : H12AffineFastState.Bounded env57158 := by
  intro p hp
  have h : env57158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57157_57158 : H12AffineEnvironment.transform 2 2 env57157 = env57158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57157 == env57158) = true)

def env57159 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5276,1297,1182,13341,4242,1024,1297,4373,9616,261,9603,9237,1433,5523,5276,13340,10249,8205,9496,257,8460,13340,1692]

theorem envBound57159 : H12AffineFastState.Bounded env57159 := by
  intro p hp
  have h : env57159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57150_57159 : H12AffineEnvironment.transform 14 1297 env57150 = env57159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env57150 == env57159) = true)

theorem identity57159 : scanCanonicalize (H12AffineFastState.compose env57159 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6543) := by decide +kernel

theorem selectedBound57159 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57160 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,6543,5276,1297,1182,3474,4242,1024,1297,4373,7199,261,7180,7578,1433,5523,5276,3475,4486,6530,7319,257,6275,3475,1692]

theorem envBound57160 : H12AffineFastState.Bounded env57160 := by
  intro p hp
  have h : env57160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57159_57160 : H12AffineEnvironment.transform 12 6543 env57159 = env57160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6543 env57159 == env57160) = true)

theorem identity57160 : scanCanonicalize (H12AffineFastState.compose env57160 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound57160 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57161 : List Nat := [2,4,8,16,16,17,128,256,512,21,2048,4096,6543,4233,260,139,2439,4242,21,260,4373,6154,261,6169,6543,396,4486,4233,2438,4486,6530,6274,257,6275,2438,649]

theorem envBound57161 : H12AffineFastState.Bounded env57161 := by
  intro p hp
  have h : env57161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57160_57161 : H12AffineEnvironment.transform 9 21 env57160 = env57161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env57160 == env57161) = true)

theorem identity57161 : scanCanonicalize (H12AffineFastState.compose env57161 (packedSelected [2,3,5,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound57161 : packedSelected [2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env57162 : List Nat := [2,4,8,16,16,17,128,256,512,21,798,4096,4753,4233,260,139,665,4242,21,260,4373,4884,261,4871,4753,396,4486,4233,664,4486,4764,5020,257,5021,664,649]

theorem envBound57162 : H12AffineFastState.Bounded env57162 := by
  intro p hp
  have h : env57162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57161_57162 : H12AffineEnvironment.transform 10 798 env57161 = env57162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env57161 == env57162) = true)

theorem identity57162 : scanCanonicalize (H12AffineFastState.compose env57162 (packedSelected [2,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound57162 : packedSelected [2,11,12] rootPS < 2^1333 := by decide +kernel

def env57163 : List Nat := [2,4,8,16,16,17,128,256,512,21,798,528,129,665,260,139,665,642,21,260,773,260,261,279,129,396,918,665,664,918,140,396,257,397,664,649]

theorem envBound57163 : H12AffineFastState.Bounded env57163 := by
  intro p hp
  have h : env57163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57162_57163 : H12AffineEnvironment.transform 11 528 env57162 = env57163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env57162 == env57163) = true)

theorem identity57163 : scanCanonicalize (H12AffineFastState.compose env57163 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound57163 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env57164 : List Nat := [2,4,8,16,16,17,128,157,512,21,643,528,129,665,153,139,665,642,21,153,664,153,152,138,129,17,523,665,664,523,140,17,156,16,664,649]

theorem envBound57164 : H12AffineFastState.Bounded env57164 := by
  intro p hp
  have h : env57164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57163_57164 : H12AffineEnvironment.transform 7 157 env57163 = env57164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env57163 == env57164) = true)

theorem identity57164 : scanCanonicalize (H12AffineFastState.compose env57164 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound57164 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57165 : List Nat := [2,4,8,16,16,17,128,157,152,21,27,136,129,1,153,139,1,26,21,153,0,153,152,138,129,17,147,1,0,147,140,17,156,16,0,17]

theorem envBound57165 : H12AffineFastState.Bounded env57165 := by
  intro p hp
  have h : env57165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57164_57165 : H12AffineEnvironment.transform 8 152 env57164 = env57165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env57164 == env57165) = true)

theorem identity57165 : scanCanonicalize (H12AffineFastState.compose env57165 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57165 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57166 : List Nat := [2,4,8,16,16,17,19,14,11,21,27,27,18,1,10,24,1,26,21,10,0,10,11,25,18,17,0,1,0,0,31,17,15,16,0,17]

theorem envBound57166 : H12AffineFastState.Bounded env57166 := by
  intro p hp
  have h : env57166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57165_57166 : H12AffineEnvironment.transform 6 19 env57165 = env57166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57165 == env57166) = true)

theorem identity57166 : scanCanonicalize (H12AffineFastState.compose env57166 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57166 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57167 : List Nat := [2,4,8,10,10,11,9,14,11,15,1,1,8,1,10,2,1,0,15,10,0,10,11,3,8,11,0,1,0,0,5,11,15,10,0,11]

theorem envBound57167 : H12AffineFastState.Bounded env57167 := by
  intro p hp
  have h : env57167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57166_57167 : H12AffineEnvironment.transform 3 10 env57166 = env57167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57166 == env57167) = true)

def env57168 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5277,32768,33167,45324,38274,1024,32768,37892,41089,33812,9603,9236,32905,5523,5277,45325,44313,8205,40969,257,8460,45325,1693]

theorem envBound57168 : H12AffineFastState.Bounded env57168 := by
  intro p hp
  have h : env57168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57149_57168 : H12AffineEnvironment.transform 4 17 env57149 = env57168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57149 == env57168) = true)

def env57169 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5277,1296,1183,13340,4242,1024,1296,4372,9617,260,9603,9236,1433,5523,5277,13341,10249,8205,9497,257,8460,13341,1693]

theorem envBound57169 : H12AffineFastState.Bounded env57169 := by
  intro p hp
  have h : env57169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57168_57169 : H12AffineEnvironment.transform 14 1296 env57168 = env57169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env57168 == env57169) = true)

theorem identity57169 : scanCanonicalize (H12AffineFastState.compose env57169 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound57169 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57170 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,2074,8192,3207,1296,1183,11270,2184,1024,1296,2318,9617,260,9603,9236,1433,3465,3207,11271,10249,8205,9497,257,8460,11271,1693]

theorem envBound57170 : H12AffineFastState.Bounded env57170 := by
  intro p hp
  have h : env57170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57169_57170 : H12AffineEnvironment.transform 11 2074 env57169 = env57170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env57169 == env57170) = true)

theorem identity57170 : scanCanonicalize (H12AffineFastState.compose env57170 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound57170 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57171 : List Nat := [2,4,8,16,17,17,128,256,512,20,2048,2074,8192,2195,260,139,10258,2184,20,260,2318,8581,260,8599,8192,397,2461,2195,10259,10249,8205,8461,257,8460,10259,649]

theorem envBound57171 : H12AffineFastState.Bounded env57171 := by
  intro p hp
  have h : env57171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57170_57171 : H12AffineEnvironment.transform 9 20 env57170 = env57171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env57170 == env57171) = true)

theorem identity57171 : scanCanonicalize (H12AffineFastState.compose env57171 (packedSelected [0,1,4,5,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2838) := by decide +kernel

theorem selectedBound57171 : packedSelected [0,1,4,5,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57172 : List Nat := [2,4,8,16,17,17,128,256,512,20,2048,2074,2838,2195,260,139,772,2184,20,260,2318,2707,260,2689,2838,397,2461,2195,773,799,2843,2587,257,2586,773,649]

theorem envBound57172 : H12AffineFastState.Bounded env57172 := by
  intro p hp
  have h : env57172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57171_57172 : H12AffineEnvironment.transform 12 2838 env57171 = env57172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2838 env57171 == env57172) = true)

theorem identity57172 : scanCanonicalize (H12AffineFastState.compose env57172 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound57172 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57173 : List Nat := [2,4,8,16,17,17,128,157,512,20,2048,2074,2699,2195,153,139,665,2184,20,153,2195,2707,153,2689,2699,16,2048,2195,664,642,2694,2587,156,2586,664,649]

theorem envBound57173 : H12AffineFastState.Bounded env57173 := by
  intro p hp
  have h : env57173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57172_57173 : H12AffineEnvironment.transform 7 157 env57172 = env57173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env57172 == env57173) = true)

theorem identity57173 : scanCanonicalize (H12AffineFastState.compose env57173 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57173 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57174 : List Nat := [2,4,8,16,17,17,9,20,512,20,2048,2074,2562,2074,16,2,528,2049,20,16,2074,2586,16,2568,2562,16,2048,2074,529,523,2575,2587,21,2586,529,512]

theorem envBound57174 : H12AffineFastState.Bounded env57174 := by
  intro p hp
  have h : env57174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57173_57174 : H12AffineEnvironment.transform 6 9 env57173 = env57174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57173 == env57174) = true)

theorem identity57174 : scanCanonicalize (H12AffineFastState.compose env57174 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound57174 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57175 : List Nat := [2,4,8,16,17,17,9,20,512,20,27,1,537,1,16,2,528,26,20,16,1,513,16,531,537,16,27,1,529,523,532,512,21,513,529,512]

theorem envBound57175 : H12AffineFastState.Bounded env57175 := by
  intro p hp
  have h : env57175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57174_57175 : H12AffineEnvironment.transform 10 27 env57174 = env57175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env57174 == env57175) = true)

theorem identity57175 : scanCanonicalize (H12AffineFastState.compose env57175 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57175 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57176 : List Nat := [2,4,8,16,17,17,9,20,11,20,27,1,18,1,16,2,27,26,20,16,1,10,16,24,18,16,27,1,26,0,31,11,21,10,26,11]

theorem envBound57176 : H12AffineFastState.Bounded env57176 := by
  intro p hp
  have h : env57176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57175_57176 : H12AffineEnvironment.transform 8 11 env57175 = env57176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57175 == env57176) = true)

theorem identity57176 : scanCanonicalize (H12AffineFastState.compose env57176 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57176 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57177 : List Nat := [2,4,8,10,11,11,9,14,11,14,1,1,8,1,10,2,1,0,14,10,1,10,10,2,8,10,1,1,0,0,5,11,15,10,0,11]

theorem envBound57177 : H12AffineFastState.Bounded env57177 := by
  intro p hp
  have h : env57177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57176_57177 : H12AffineEnvironment.transform 3 10 env57176 = env57177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57176 == env57177) = true)

theorem identity57177 : scanCanonicalize (H12AffineFastState.compose env57177 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57177 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57178 : List Nat := [2,4,2,0,1,1,3,4,1,4,1,1,2,1,0,2,1,0,4,0,1,0,0,2,2,0,1,1,0,0,5,1,5,0,0,1]

theorem envBound57178 : H12AffineFastState.Bounded env57178 := by
  intro p hp
  have h : env57178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57177_57178 : H12AffineEnvironment.transform 2 2 env57177 = env57178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57177 == env57178) = true)

def env57179 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5277,1297,1182,13341,4243,1024,1297,4373,9616,261,9603,9236,1432,5523,5277,13340,10248,8205,9496,257,8460,13340,1693]

theorem envBound57179 : H12AffineFastState.Bounded env57179 := by
  intro p hp
  have h : env57179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57168_57179 : H12AffineEnvironment.transform 14 1297 env57168 = env57179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env57168 == env57179) = true)

theorem identity57179 : scanCanonicalize (H12AffineFastState.compose env57179 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound57179 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57180 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,2195,8192,3086,1297,1182,11406,2048,1024,1297,2438,9616,261,9603,9236,1432,3328,3086,11407,10248,8205,9496,257,8460,11407,1693]

theorem envBound57180 : H12AffineFastState.Bounded env57180 := by
  intro p hp
  have h : env57180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57179_57180 : H12AffineEnvironment.transform 11 2195 env57179 = env57180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env57179 == env57180) = true)

theorem identity57180 : scanCanonicalize (H12AffineFastState.compose env57180 (packedSelected [3,4,5,7,10,11,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57180 : packedSelected [3,4,5,7,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env57181 : List Nat := [2,4,8,16,17,17,8,256,512,1024,2048,2075,8192,3086,1297,1046,11270,2048,1024,1297,2318,9496,261,9483,9236,1296,3328,3086,11271,10248,8205,9496,257,8460,11271,1557]

theorem envBound57181 : H12AffineFastState.Bounded env57181 := by
  intro p hp
  have h : env57181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57180_57181 : H12AffineEnvironment.transform 6 8 env57180 = env57181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57180 == env57181) = true)

theorem identity57181 : scanCanonicalize (H12AffineFastState.compose env57181 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57181 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57182 : List Nat := [2,4,8,16,17,17,8,256,512,1024,2048,2075,1289,3086,1297,1046,2319,2048,1024,1297,2318,17,261,2,285,1296,3328,3086,2318,3329,1284,17,257,1029,2318,1557]

theorem envBound57182 : H12AffineFastState.Bounded env57182 := by
  intro p hp
  have h : env57182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57181_57182 : H12AffineEnvironment.transform 12 1289 env57181 = env57182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57181 == env57182) = true)

theorem identity57182 : scanCanonicalize (H12AffineFastState.compose env57182 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound57182 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57183 : List Nat := [2,4,8,16,17,17,8,256,512,273,2048,2075,24,2335,0,263,2319,2048,273,0,2318,17,261,2,285,1,2065,2335,2318,2064,21,17,257,276,2318,772]

theorem envBound57183 : H12AffineFastState.Bounded env57183 := by
  intro p hp
  have h : env57183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57182_57183 : H12AffineEnvironment.transform 9 273 env57182 = env57183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env57182 == env57183) = true)

theorem identity57183 : scanCanonicalize (H12AffineFastState.compose env57183 (packedSelected [1,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57183 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env57184 : List Nat := [2,4,8,16,17,17,8,31,512,14,2048,2075,24,2048,0,24,2064,2048,14,0,2065,17,26,2,2,1,2065,2048,2065,2064,21,17,30,11,2065,539]

theorem envBound57184 : H12AffineFastState.Bounded env57184 := by
  intro p hp
  have h : env57184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57183_57184 : H12AffineEnvironment.transform 7 31 env57183 = env57184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57183 == env57184) = true)

theorem identity57184 : scanCanonicalize (H12AffineFastState.compose env57184 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound57184 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57185 : List Nat := [2,4,8,16,17,17,8,31,512,14,523,528,24,523,0,24,539,523,14,0,538,17,26,2,2,1,538,523,538,539,21,17,30,11,538,539]

theorem envBound57185 : H12AffineFastState.Bounded env57185 := by
  intro p hp
  have h : env57185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57184_57185 : H12AffineEnvironment.transform 10 523 env57184 = env57185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env57184 == env57185) = true)

theorem identity57185 : scanCanonicalize (H12AffineFastState.compose env57185 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57186 : List Nat := [2,4,8,1,0,0,8,14,512,14,523,513,9,523,0,9,522,523,14,0,523,0,11,2,2,1,523,523,523,522,4,0,15,11,523,522]

theorem envBound57186 : H12AffineFastState.Bounded env57186 := by
  intro p hp
  have h : env57186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57185_57186 : H12AffineEnvironment.transform 3 1 env57185 = env57186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57185 == env57186) = true)

def env57187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295815,4247641,6348993,4486237,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256464]

theorem envBound57187 : H12AffineFastState.Bounded env57187 := by
  intro p hp
  have h : env57187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57073_57187 : H12AffineEnvironment.transform 22 6336705 env57073 = env57187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env57073 == env57187) = true)

def env57188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295815,4247641,6348993,4273309,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256464]

theorem envBound57188 : H12AffineFastState.Bounded env57188 := by
  intro p hp
  have h : env57188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57187_57188 : H12AffineEnvironment.transform 17 82112 env57187 = env57188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57187 == env57188) = true)

def env57189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142599,28889,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound57189 : H12AffineFastState.Bounded env57189 := by
  intro p hp
  have h : env57189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57188_57189 : H12AffineEnvironment.transform 21 41088 env57188 = env57189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57188 == env57189) = true)

theorem identity57189 : scanCanonicalize (H12AffineFastState.compose env57189 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 74094) := by decide +kernel

theorem selectedBound57189 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,74094,41088,78127,102633,28889,90415,103453,16384,77954,96347,5352,74118,257,16661,78035,21072]

theorem envBound57190 : H12AffineFastState.Bounded env57190 := by
  intro p hp
  have h : env57190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57189_57190 : H12AffineEnvironment.transform 20 74094 env57189 = env57190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 74094 env57189 == env57190) = true)

theorem identity57190 : scanCanonicalize (H12AffineFastState.compose env57190 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57190 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,16384,32768,65536,71130,82112,1024,32768,66662,34184,70695,102633,21969,82983,103453,16384,71050,89427,5352,66702,257,16661,71131,21072]

theorem envBound57191 : H12AffineFastState.Bounded env57191 := by
  intro p hp
  have h : env57191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57190_57191 : H12AffineEnvironment.transform 12 1288 env57190 = env57191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57190 == env57191) = true)

theorem identity57191 : scanCanonicalize (H12AffineFastState.compose env57191 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound57191 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,444,32768,65536,71130,65916,1024,32768,66662,34184,70695,102633,5229,66971,103453,444,71050,72943,5352,66702,257,169,71131,5100]

theorem envBound57192 : H12AffineFastState.Bounded env57192 := by
  intro p hp
  have h : env57192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57191_57192 : H12AffineEnvironment.transform 13 444 env57191 = env57192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57191 == env57192) = true)

theorem identity57192 : scanCanonicalize (H12AffineFastState.compose env57192 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57192 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,65536,66614,65916,1024,32768,66662,34184,67019,98565,1409,66971,99825,444,66662,68867,1284,66702,257,169,66615,512]

theorem envBound57193 : H12AffineFastState.Bounded env57193 := by
  intro p hp
  have h : env57193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57192_57193 : H12AffineEnvironment.transform 11 492 env57192 = env57193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57192 == env57193) = true)

theorem identity57193 : scanCanonicalize (H12AffineFastState.compose env57193 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound57193 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,1875,869,1583,1024,32768,821,34184,664,34390,1409,712,33442,444,821,2640,1284,989,257,169,868,512]

theorem envBound57194 : H12AffineFastState.Bounded env57194 := by
  intro p hp
  have h : env57194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57193_57194 : H12AffineEnvironment.transform 15 1875 env57193 = env57194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env57193 == env57194) = true)

def env57195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142598,28888,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound57195 : H12AffineFastState.Bounded env57195 := by
  intro p hp
  have h : env57195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57188_57195 : H12AffineEnvironment.transform 21 41089 env57188 = env57195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57188 == env57195) = true)

theorem identity57195 : scanCanonicalize (H12AffineFastState.compose env57195 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 91182) := by decide +kernel

theorem selectedBound57195 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,91182,41089,95342,120232,28888,74862,103452,16384,77954,96346,20905,74119,257,1108,78035,21073]

theorem envBound57196 : H12AffineFastState.Bounded env57196 := by
  intro p hp
  have h : env57196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57195_57196 : H12AffineEnvironment.transform 20 91182 env57195 = env57196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91182 env57195 == env57196) = true)

theorem identity57196 : scanCanonicalize (H12AffineFastState.compose env57196 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 12709) := by decide +kernel

theorem selectedBound57196 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,65536,78034,78181,1024,32768,71051,41089,67019,107533,381,74862,103452,12709,77954,68095,8204,74119,257,1108,78035,9204]

theorem envBound57197 : H12AffineFastState.Bounded env57197 := by
  intro p hp
  have h : env57197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57196_57197 : H12AffineEnvironment.transform 13 12709 env57196 = env57197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12709 env57196 == env57197) = true)

theorem identity57197 : scanCanonicalize (H12AffineFastState.compose env57197 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 41083) := by decide +kernel

theorem selectedBound57197 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,41083,37033,37150,1024,32768,46576,41089,42416,1142,381,33813,13415,12709,37113,43396,8204,33276,257,1108,37032,9204]

theorem envBound57198 : H12AffineFastState.Bounded env57198 := by
  intro p hp
  have h : env57198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57197_57198 : H12AffineEnvironment.transform 15 41083 env57197 = env57198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41083 env57197 == env57198) = true)

theorem identity57198 : scanCanonicalize (H12AffineFastState.compose env57198 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 500) := by decide +kernel

theorem selectedBound57198 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env57199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,500,4177,32768,33167,37033,37150,1024,32768,37892,33141,33860,1142,381,33813,5523,4177,37113,34928,504,33276,257,1108,37032,512]

theorem envBound57199 : H12AffineFastState.Bounded env57199 := by
  intro p hp
  have h : env57199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57198_57199 : H12AffineEnvironment.transform 12 500 env57198 = env57199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 500 env57198 == env57199) = true)

theorem identity57199 : scanCanonicalize (H12AffineFastState.compose env57199 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound57199 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,500,4177,32768,33167,37033,37150,1024,32768,37892,33141,33860,1142,381,33813,5523,4177,37113,34682,504,33276,257,1108,37032,512]

theorem envBound57200 : H12AffineFastState.Bounded env57200 := by
  intro p hp
  have h : env57200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57199_57200 : H12AffineEnvironment.transform 10 1802 env57199 = env57200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env57199 == env57200) = true)

theorem identity57200 : scanCanonicalize (H12AffineFastState.compose env57200 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound57200 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,500,4177,341,218,4604,4171,1024,341,5457,32,1297,1142,381,1344,5523,4177,4524,1583,504,169,257,1108,4605,512]

theorem envBound57201 : H12AffineFastState.Bounded env57201 := by
  intro p hp
  have h : env57201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57200_57201 : H12AffineEnvironment.transform 14 341 env57200 = env57201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env57200 == env57201) = true)

def env57202 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,4096,300,4177,341,2,4388,4171,1024,341,5457,32,1297,1142,381,1344,5451,4177,4468,1583,288,113,257,1108,4389,512]

theorem envBound57202 : H12AffineFastState.Bounded env57202 := by
  intro p hp
  have h : env57202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57201_57202 : H12AffineEnvironment.transform 6 88 env57201 = env57202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env57201 == env57202) = true)

def env57203 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,0,300,81,341,2,292,75,1024,341,1361,32,1297,1142,381,1344,1355,81,372,1583,288,113,257,1108,293,512]

theorem envBound57203 : H12AffineFastState.Bounded env57203 := by
  intro p hp
  have h : env57203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57202_57203 : H12AffineEnvironment.transform 11 0 env57202 = env57203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57202 == env57203) = true)

theorem identity57203 : scanCanonicalize (H12AffineFastState.compose env57203 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57204 : List Nat := [2,4,8,16,32,64,88,21,512,1024,1567,0,57,81,64,2,49,75,1024,64,1092,32,1028,1142,104,1109,1118,81,97,1583,53,113,20,1108,48,512]

theorem envBound57204 : H12AffineFastState.Bounded env57204 := by
  intro p hp
  have h : env57204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57203_57204 : H12AffineEnvironment.transform 7 21 env57203 = env57204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57203 == env57204) = true)

theorem identity57204 : scanCanonicalize (H12AffineFastState.compose env57204 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 638) := by decide +kernel

theorem selectedBound57204 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57205 : List Nat := [2,4,8,16,32,64,88,21,512,638,97,0,57,81,64,2,49,75,638,64,570,32,634,520,104,555,544,81,97,81,53,113,20,554,48,512]

theorem envBound57205 : H12AffineFastState.Bounded env57205 := by
  intro p hp
  have h : env57205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57204_57205 : H12AffineEnvironment.transform 9 638 env57204 = env57205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 638 env57204 == env57205) = true)

theorem identity57205 : scanCanonicalize (H12AffineFastState.compose env57205 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound57205 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57206 : List Nat := [2,4,8,16,32,64,88,21,90,36,97,0,57,81,64,2,49,75,36,64,96,32,32,82,104,113,122,81,97,81,53,113,20,112,48,90]

theorem envBound57206 : H12AffineFastState.Bounded env57206 := by
  intro p hp
  have h : env57206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57205_57206 : H12AffineEnvironment.transform 8 90 env57205 = env57206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env57205 == env57206) = true)

theorem identity57206 : scanCanonicalize (H12AffineFastState.compose env57206 (packedSelected [0,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound57206 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env57207 : List Nat := [2,4,8,16,32,58,34,21,32,36,27,0,57,43,58,2,49,49,36,58,26,32,32,40,18,11,0,43,27,43,53,11,20,10,48,32]

theorem envBound57207 : H12AffineFastState.Bounded env57207 := by
  intro p hp
  have h : env57207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57206_57207 : H12AffineEnvironment.transform 5 58 env57206 = env57207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env57206 == env57207) = true)

def env57208 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,1,300,80,341,2,293,74,1024,341,1360,32,1297,1142,381,1344,1354,80,373,1583,288,113,257,1108,292,512]

theorem envBound57208 : H12AffineFastState.Bounded env57208 := by
  intro p hp
  have h : env57208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57202_57208 : H12AffineEnvironment.transform 11 1 env57202 = env57208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57202 == env57208) = true)

theorem identity57208 : scanCanonicalize (H12AffineFastState.compose env57208 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound57208 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57209 : List Nat := [2,4,8,16,32,64,88,256,512,516,270,1,300,80,341,2,293,74,516,341,852,32,789,626,381,836,846,80,373,43,288,113,257,592,292,512]

theorem envBound57209 : H12AffineFastState.Bounded env57209 := by
  intro p hp
  have h : env57209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57208_57209 : H12AffineEnvironment.transform 9 516 env57208 = env57209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env57208 == env57209) = true)

theorem identity57209 : scanCanonicalize (H12AffineFastState.compose env57209 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound57209 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57210 : List Nat := [2,4,8,16,32,64,88,256,91,95,270,1,300,80,341,2,293,74,95,341,271,32,334,41,381,287,277,80,373,43,288,113,257,11,292,91]

theorem envBound57210 : H12AffineFastState.Bounded env57210 := by
  intro p hp
  have h : env57210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57209_57210 : H12AffineEnvironment.transform 8 91 env57209 = env57210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env57209 == env57210) = true)

theorem identity57210 : scanCanonicalize (H12AffineFastState.compose env57210 (packedSelected [4,7,13] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57210 : packedSelected [4,7,13] rootPS < 2^1333 := by decide +kernel

def env57211 : List Nat := [2,4,8,16,32,11,19,256,16,20,270,1,300,27,286,2,293,1,20,286,271,32,261,41,310,287,277,27,318,43,288,58,257,11,292,16]

theorem envBound57211 : H12AffineFastState.Bounded env57211 := by
  intro p hp
  have h : env57211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57210_57211 : H12AffineEnvironment.transform 5 11 env57210 = env57211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57210 == env57211) = true)

def env57212 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,4096,301,4177,341,3,4389,4171,1024,341,5457,32,1297,1142,381,1344,5450,4177,4469,1583,289,112,257,1108,4388,512]

theorem envBound57212 : H12AffineFastState.Bounded env57212 := by
  intro p hp
  have h : env57212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57201_57212 : H12AffineEnvironment.transform 6 89 env57201 = env57212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57201 == env57212) = true)

def env57213 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,0,301,81,341,3,293,75,1024,341,1361,32,1297,1142,381,1344,1354,81,373,1583,289,112,257,1108,292,512]

theorem envBound57213 : H12AffineFastState.Bounded env57213 := by
  intro p hp
  have h : env57213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57212_57213 : H12AffineEnvironment.transform 11 0 env57212 = env57213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57212 == env57213) = true)

theorem identity57213 : scanCanonicalize (H12AffineFastState.compose env57213 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound57213 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57214 : List Nat := [2,4,8,16,32,64,89,256,512,368,634,0,301,81,341,3,293,75,368,341,33,32,97,262,381,48,58,81,373,863,289,112,257,292,292,512]

theorem envBound57214 : H12AffineFastState.Bounded env57214 := by
  intro p hp
  have h : env57214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57213_57214 : H12AffineEnvironment.transform 9 368 env57213 = env57214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env57213 == env57214) = true)

theorem identity57214 : scanCanonicalize (H12AffineFastState.compose env57214 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57214 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57215 : List Nat := [2,4,8,16,32,64,89,78,512,62,634,0,99,81,27,3,107,75,62,27,33,32,97,72,51,48,58,81,59,529,111,112,79,106,106,512]

theorem envBound57215 : H12AffineFastState.Bounded env57215 := by
  intro p hp
  have h : env57215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57214_57215 : H12AffineEnvironment.transform 7 78 env57214 = env57215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57214 == env57215) = true)

def env57216 : List Nat := [2,4,8,16,32,48,41,62,512,62,522,0,19,33,27,3,27,59,62,27,33,32,17,56,51,48,58,33,59,529,31,0,63,26,26,512]

theorem envBound57216 : H12AffineFastState.Bounded env57216 := by
  intro p hp
  have h : env57216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57215_57216 : H12AffineEnvironment.transform 5 48 env57215 = env57216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57215 == env57216) = true)

theorem identity57216 : scanCanonicalize (H12AffineFastState.compose env57216 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound57216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57217 : List Nat := [2,4,8,16,32,48,41,62,16,62,26,0,19,33,27,3,27,59,62,27,33,32,17,56,51,48,58,33,59,1,31,0,63,26,26,16]

theorem envBound57217 : H12AffineFastState.Bounded env57217 := by
  intro p hp
  have h : env57217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57216_57217 : H12AffineEnvironment.transform 8 16 env57216 = env57217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env57216 == env57217) = true)

def env57218 : List Nat := [2,4,8,16,32,49,40,63,512,62,523,0,18,32,27,3,26,58,62,27,33,32,16,57,51,48,58,32,59,529,30,1,62,27,27,512]

theorem envBound57218 : H12AffineFastState.Bounded env57218 := by
  intro p hp
  have h : env57218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57215_57218 : H12AffineEnvironment.transform 5 49 env57215 = env57218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57215 == env57218) = true)

theorem identity57218 : scanCanonicalize (H12AffineFastState.compose env57218 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57218 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57219 : List Nat := [2,4,8,16,32,49,40,63,10,62,1,0,18,32,27,3,26,58,62,27,33,32,16,57,51,48,58,32,59,27,30,1,62,27,27,10]

theorem envBound57219 : H12AffineFastState.Bounded env57219 := by
  intro p hp
  have h : env57219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57218_57219 : H12AffineEnvironment.transform 8 10 env57218 = env57219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57218 == env57219) = true)

theorem identity57219 : scanCanonicalize (H12AffineFastState.compose env57219 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57219 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57220 : List Nat := [2,4,8,10,32,43,40,37,10,36,1,0,8,32,1,3,0,32,36,1,33,32,10,35,41,42,32,32,33,1,4,1,36,1,1,10]

theorem envBound57220 : H12AffineFastState.Bounded env57220 := by
  intro p hp
  have h : env57220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57219_57220 : H12AffineEnvironment.transform 3 10 env57219 = env57220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57219 == env57220) = true)

theorem identity57220 : scanCanonicalize (H12AffineFastState.compose env57220 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57221 : List Nat := [2,4,8,10,11,0,3,14,10,15,1,0,8,11,1,3,0,11,15,1,10,11,10,8,2,1,11,11,10,1,4,1,15,1,1,10]

theorem envBound57221 : H12AffineFastState.Bounded env57221 := by
  intro p hp
  have h : env57221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57220_57221 : H12AffineEnvironment.transform 4 11 env57220 = env57221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57220 == env57221) = true)

def env57222 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,1,301,80,341,3,292,74,1024,341,1360,32,1297,1142,381,1344,1355,80,372,1583,289,112,257,1108,293,512]

theorem envBound57222 : H12AffineFastState.Bounded env57222 := by
  intro p hp
  have h : env57222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57212_57222 : H12AffineEnvironment.transform 11 1 env57212 = env57222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57212 == env57222) = true)

theorem identity57222 : scanCanonicalize (H12AffineFastState.compose env57222 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound57222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57223 : List Nat := [2,4,8,16,32,64,89,256,97,1024,1387,1,301,80,341,3,292,74,1024,341,1360,32,1297,1142,381,1344,1355,80,372,1102,289,112,257,1108,293,97]

theorem envBound57223 : H12AffineFastState.Bounded env57223 := by
  intro p hp
  have h : env57223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57222_57223 : H12AffineEnvironment.transform 8 97 env57222 = env57223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env57222 == env57223) = true)

theorem identity57223 : scanCanonicalize (H12AffineFastState.compose env57223 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57223 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57224 : List Nat := [2,4,8,11,32,64,66,256,97,1024,1387,1,301,75,334,3,292,74,1024,334,1355,32,1290,1133,358,1344,1355,75,367,1102,289,107,257,1103,293,97]

theorem envBound57224 : H12AffineFastState.Bounded env57224 := by
  intro p hp
  have h : env57224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57223_57224 : H12AffineEnvironment.transform 3 11 env57223 = env57224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57223 == env57224) = true)

theorem identity57224 : scanCanonicalize (H12AffineFastState.compose env57224 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57224 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env57225 : List Nat := [2,4,8,11,32,64,66,78,97,1024,1061,1,99,75,0,3,106,74,1024,0,1029,32,1092,1133,40,1038,1029,75,33,1102,111,107,79,1103,107,97]

theorem envBound57225 : H12AffineFastState.Bounded env57225 := by
  intro p hp
  have h : env57225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57224_57225 : H12AffineEnvironment.transform 7 78 env57224 = env57225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57224 == env57225) = true)

theorem identity57225 : scanCanonicalize (H12AffineFastState.compose env57225 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound57225 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57226 : List Nat := [2,4,8,11,32,64,66,78,97,37,0,1,99,75,0,3,106,74,37,0,32,32,97,72,40,43,32,75,33,107,111,107,79,106,107,97]

theorem envBound57226 : H12AffineFastState.Bounded env57226 := by
  intro p hp
  have h : env57226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57225_57226 : H12AffineEnvironment.transform 9 37 env57225 = env57226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env57225 == env57226) = true)

def env57227 : List Nat := [2,4,8,11,32,32,34,46,1,37,0,1,3,43,0,3,10,42,37,0,32,32,1,40,40,43,32,43,33,11,15,11,47,10,11,1]

theorem envBound57227 : H12AffineFastState.Bounded env57227 := by
  intro p hp
  have h : env57227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57226_57227 : H12AffineEnvironment.transform 5 32 env57226 = env57227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57226 == env57227) = true)

theorem identity57227 : scanCanonicalize (H12AffineFastState.compose env57227 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57227 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57228 : List Nat := [2,4,2,1,32,32,34,36,1,37,0,1,3,33,0,3,0,32,37,0,32,32,1,34,34,33,32,33,33,1,5,1,37,0,1,1]

theorem envBound57228 : H12AffineFastState.Bounded env57228 := by
  intro p hp
  have h : env57228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57227_57228 : H12AffineEnvironment.transform 2 2 env57227 = env57228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57227 == env57228) = true)

def env57229 : List Nat := [2,4,8,11,32,33,35,47,0,37,0,1,2,42,0,3,11,43,37,0,32,32,0,41,40,43,32,42,33,10,14,10,46,11,10,0]

theorem envBound57229 : H12AffineFastState.Bounded env57229 := by
  intro p hp
  have h : env57229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57226_57229 : H12AffineEnvironment.transform 5 33 env57226 = env57229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57226 == env57229) = true)

def env57230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295815,4247641,6348993,4273308,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256464]

theorem envBound57230 : H12AffineFastState.Bounded env57230 := by
  intro p hp
  have h : env57230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57187_57230 : H12AffineEnvironment.transform 17 82113 env57187 = env57230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57187 == env57230) = true)

def env57231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142599,28889,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound57231 : H12AffineFastState.Bounded env57231 := by
  intro p hp
  have h : env57231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57230_57231 : H12AffineEnvironment.transform 21 41088 env57230 = env57231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57230 == env57231) = true)

theorem identity57231 : scanCanonicalize (H12AffineFastState.compose env57231 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 94527) := by decide +kernel

theorem selectedBound57231 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,94527,41088,90494,114872,28889,78206,103452,16384,77954,96347,17593,74118,257,4420,78035,21072]

theorem envBound57232 : H12AffineFastState.Bounded env57232 := by
  intro p hp
  have h : env57232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57231_57232 : H12AffineEnvironment.transform 20 94527 env57231 = env57232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 94527 env57231 == env57232) = true)

theorem identity57232 : scanCanonicalize (H12AffineFastState.compose env57232 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57232 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,16384,32768,65536,71130,82113,1024,32768,87095,34184,83062,114872,21969,70774,103452,16384,71050,89427,17593,66702,257,4420,71131,21072]

theorem envBound57233 : H12AffineFastState.Bounded env57233 := by
  intro p hp
  have h : env57233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57232_57233 : H12AffineEnvironment.transform 12 1288 env57232 = env57233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57232 == env57233) = true)

theorem identity57233 : scanCanonicalize (H12AffineFastState.compose env57233 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57233 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,16384,32768,65536,66615,82113,1024,32768,83418,34184,83062,114872,17468,66971,99825,16384,66663,85182,17593,66702,257,169,66614,17341]

theorem envBound57234 : H12AffineFastState.Bounded env57234 := by
  intro p hp
  have h : env57234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57233_57234 : H12AffineEnvironment.transform 11 493 env57233 = env57234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57233 == env57234) = true)

theorem identity57234 : scanCanonicalize (H12AffineFastState.compose env57234 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound57234 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,65536,66615,65916,1024,32768,66663,34184,67019,98565,1409,66971,99825,445,66663,68867,1284,66702,257,169,66614,512]

theorem envBound57235 : H12AffineFastState.Bounded env57235 := by
  intro p hp
  have h : env57235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57234_57235 : H12AffineEnvironment.transform 13 445 env57234 = env57235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57234 == env57235) = true)

theorem identity57235 : scanCanonicalize (H12AffineFastState.compose env57235 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound57235 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,1875,868,1583,1024,32768,820,34184,664,34390,1409,712,33442,445,820,2640,1284,989,257,169,869,512]

theorem envBound57236 : H12AffineFastState.Bounded env57236 := by
  intro p hp
  have h : env57236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57235_57236 : H12AffineEnvironment.transform 15 1875 env57235 = env57236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env57235 == env57236) = true)

def env57237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142598,28888,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound57237 : H12AffineFastState.Bounded env57237 := by
  intro p hp
  have h : env57237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57230_57237 : H12AffineEnvironment.transform 21 41089 env57230 = env57237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57230 == env57237) = true)

theorem identity57237 : scanCanonicalize (H12AffineFastState.compose env57237 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 78974) := by decide +kernel

theorem selectedBound57237 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,78974,41089,74814,99832,28888,95294,103453,16384,77954,96346,505,74119,257,21508,78035,21073]

theorem envBound57238 : H12AffineFastState.Bounded env57238 := by
  intro p hp
  have h : env57238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57237_57238 : H12AffineEnvironment.transform 20 78974 env57237 = env57238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78974 env57237 == env57238) = true)

theorem identity57238 : scanCanonicalize (H12AffineFastState.compose env57238 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 501) := by decide +kernel

theorem selectedBound57238 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,65536,69927,82113,1024,32768,71051,33140,67019,99832,20781,87499,103453,16384,70007,88495,505,65650,257,21508,69926,21073]

theorem envBound57239 : H12AffineFastState.Bounded env57239 := by
  intro p hp
  have h : env57239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57238_57239 : H12AffineEnvironment.transform 12 501 env57238 = env57239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 501 env57238 == env57239) = true)

theorem identity57239 : scanCanonicalize (H12AffineFastState.compose env57239 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 53726) := by decide +kernel

theorem selectedBound57239 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,53726,49401,37151,1024,32768,50261,33140,54293,21542,20781,33813,17859,16384,49321,34929,505,53676,257,21508,49400,21073]

theorem envBound57240 : H12AffineFastState.Bounded env57240 := by
  intro p hp
  have h : env57240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57239_57240 : H12AffineEnvironment.transform 15 53726 env57239 = env57240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53726 env57239 == env57240) = true)

theorem identity57240 : scanCanonicalize (H12AffineFastState.compose env57240 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57240 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env57241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,4177,32768,33167,37032,37151,1024,32768,37892,33140,33860,1143,380,33813,5522,4177,37112,34929,505,33277,257,1109,37033,512]

theorem envBound57241 : H12AffineFastState.Bounded env57241 := by
  intro p hp
  have h : env57241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57240_57241 : H12AffineEnvironment.transform 13 4177 env57240 = env57241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57240 == env57241) = true)

theorem identity57241 : scanCanonicalize (H12AffineFastState.compose env57241 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound57241 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,501,4177,32768,33167,37032,37151,1024,32768,37892,33140,33860,1143,380,33813,5522,4177,37112,34683,505,33277,257,1109,37033,512]

theorem envBound57242 : H12AffineFastState.Bounded env57242 := by
  intro p hp
  have h : env57242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57241_57242 : H12AffineEnvironment.transform 10 1802 env57241 = env57242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env57241 == env57242) = true)

theorem identity57242 : scanCanonicalize (H12AffineFastState.compose env57242 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound57242 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,501,4177,340,219,4604,4171,1024,340,5456,32,1296,1143,380,1345,5522,4177,4524,1583,505,169,257,1109,4605,512]

theorem envBound57243 : H12AffineFastState.Bounded env57243 := by
  intro p hp
  have h : env57243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57242_57243 : H12AffineEnvironment.transform 14 340 env57242 = env57243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env57242 == env57243) = true)

def env57244 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,4096,301,4177,340,3,4388,4171,1024,340,5456,32,1296,1143,380,1345,5450,4177,4468,1583,289,113,257,1109,4389,512]

theorem envBound57244 : H12AffineFastState.Bounded env57244 := by
  intro p hp
  have h : env57244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57243_57244 : H12AffineEnvironment.transform 6 88 env57243 = env57244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env57243 == env57244) = true)

def env57245 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,0,301,81,340,3,292,75,1024,340,1360,32,1296,1143,380,1345,1354,81,372,1583,289,113,257,1109,293,512]

theorem envBound57245 : H12AffineFastState.Bounded env57245 := by
  intro p hp
  have h : env57245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57244_57245 : H12AffineEnvironment.transform 11 0 env57244 = env57245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57244 == env57245) = true)

theorem identity57245 : scanCanonicalize (H12AffineFastState.compose env57245 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57246 : List Nat := [2,4,8,16,32,64,88,21,512,1024,1567,0,56,81,65,3,49,75,1024,65,1093,32,1029,1143,105,1108,1119,81,97,1583,52,113,20,1109,48,512]

theorem envBound57246 : H12AffineFastState.Bounded env57246 := by
  intro p hp
  have h : env57246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57245_57246 : H12AffineEnvironment.transform 7 21 env57245 = env57246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57245 == env57246) = true)

theorem identity57246 : scanCanonicalize (H12AffineFastState.compose env57246 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 638) := by decide +kernel

theorem selectedBound57246 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57247 : List Nat := [2,4,8,16,32,64,88,21,512,638,97,0,56,81,65,3,49,75,638,65,571,32,635,521,105,554,545,81,97,81,52,113,20,555,48,512]

theorem envBound57247 : H12AffineFastState.Bounded env57247 := by
  intro p hp
  have h : env57247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57246_57247 : H12AffineEnvironment.transform 9 638 env57246 = env57247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 638 env57246 == env57247) = true)

theorem identity57247 : scanCanonicalize (H12AffineFastState.compose env57247 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound57247 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57248 : List Nat := [2,4,8,16,32,64,88,21,91,37,97,0,56,81,65,3,49,75,37,65,96,32,32,82,105,113,122,81,97,81,52,113,20,112,48,91]

theorem envBound57248 : H12AffineFastState.Bounded env57248 := by
  intro p hp
  have h : env57248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57247_57248 : H12AffineEnvironment.transform 8 91 env57247 = env57248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env57247 == env57248) = true)

theorem identity57248 : scanCanonicalize (H12AffineFastState.compose env57248 (packedSelected [0,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound57248 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env57249 : List Nat := [2,4,8,16,32,58,34,21,33,37,27,0,56,43,59,3,49,49,37,59,26,32,32,40,19,11,0,43,27,43,52,11,20,10,48,33]

theorem envBound57249 : H12AffineFastState.Bounded env57249 := by
  intro p hp
  have h : env57249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57248_57249 : H12AffineEnvironment.transform 5 58 env57248 = env57249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env57248 == env57249) = true)

def env57250 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1802,1,301,80,340,3,293,74,1024,340,1361,32,1296,1143,380,1345,1355,80,373,1583,289,113,257,1109,292,512]

theorem envBound57250 : H12AffineFastState.Bounded env57250 := by
  intro p hp
  have h : env57250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57244_57250 : H12AffineEnvironment.transform 11 1 env57244 = env57250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57244 == env57250) = true)

theorem identity57250 : scanCanonicalize (H12AffineFastState.compose env57250 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound57250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57251 : List Nat := [2,4,8,16,32,64,88,256,512,516,270,1,301,80,340,3,293,74,516,340,853,32,788,627,380,837,847,80,373,43,289,113,257,593,292,512]

theorem envBound57251 : H12AffineFastState.Bounded env57251 := by
  intro p hp
  have h : env57251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57250_57251 : H12AffineEnvironment.transform 9 516 env57250 = env57251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env57250 == env57251) = true)

end H12CloudChart1