import H12CloudChart1Data045

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity11507 : scanCanonicalize (H12AffineFastState.compose env11507 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11507 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11508 : List Nat := [2,4,8,16,0,17,128,141,151,156,2048,2062,128,2079,137,138,2063,2184,157,136,2078,137,17,3,8,17,2049,2063,2062,2048,157,1,140,0,2079,151]

theorem envBound11508 : H12AffineFastState.Bounded env11508 := by
  intro p hp
  have h : env11508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11507_11508 : H12AffineEnvironment.transform 5 17 env11507 = env11508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11507 == env11508) = true)

theorem identity11508 : scanCanonicalize (H12AffineFastState.compose env11508 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11508 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11509 : List Nat := [2,4,8,16,0,17,8,5,31,20,2048,2062,8,2079,1,2,2063,2048,21,0,2078,1,17,3,8,17,2049,2063,2062,2048,21,1,4,0,2079,31]

theorem envBound11509 : H12AffineFastState.Bounded env11509 := by
  intro p hp
  have h : env11509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11508_11509 : H12AffineEnvironment.transform 6 8 env11508 = env11509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11508 == env11509) = true)

theorem identity11509 : scanCanonicalize (H12AffineFastState.compose env11509 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound11509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11510 : List Nat := [2,4,8,16,0,17,8,5,31,20,30,16,8,1,1,2,17,30,21,0,0,1,17,3,8,17,31,17,16,30,21,1,4,0,1,31]

theorem envBound11510 : H12AffineFastState.Bounded env11510 := by
  intro p hp
  have h : env11510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11509_11510 : H12AffineEnvironment.transform 10 30 env11509 = env11510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env11509 == env11510) = true)

theorem identity11510 : scanCanonicalize (H12AffineFastState.compose env11510 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound11510 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11511 : List Nat := [2,4,8,15,0,14,8,5,0,11,1,15,8,1,1,2,14,1,10,0,0,1,14,3,8,14,0,14,15,1,10,1,4,0,1,0]

theorem envBound11511 : H12AffineFastState.Bounded env11511 := by
  intro p hp
  have h : env11511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11510_11511 : H12AffineEnvironment.transform 3 15 env11510 = env11511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env11510 == env11511) = true)

def env11512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1025,32769,58516,168,62660,98780,8328,64,64724,57797,17664,32161,61704,32,257,21792,46212,120543]

theorem envBound11512 : H12AffineFastState.Bounded env11512 := by
  intro p hp
  have h : env11512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11497_11512 : H12AffineEnvironment.transform 17 10281 env11497 = env11512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11497 == env11512) = true)

theorem identity11512 : scanCanonicalize (H12AffineFastState.compose env11512 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound11512 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10281,1025,8540,17865,168,21913,73857,8328,64,23945,16536,17664,32161,20565,32,257,21792,5593,96130]

theorem envBound11513 : H12AffineFastState.Bounded env11513 := by
  intro p hp
  have h : env11513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11512_11513 : H12AffineEnvironment.transform 14 8541 env11512 = env11513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env11512 == env11513) = true)

theorem identity11513 : scanCanonicalize (H12AffineFastState.compose env11513 (packedSelected [0,1,2,6,7,8,11,18,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound11513 : packedSelected [0,1,2,6,7,8,11,18,20,26] rootPS < 2^1333 := by decide +kernel

def env11514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,21510,24908,10281,1025,8540,17865,168,21913,29831,8328,64,23945,16536,17664,32161,20565,32,257,21792,5593,9092]

theorem envBound11514 : H12AffineFastState.Bounded env11514 := by
  intro p hp
  have h : env11514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11513_11514 : H12AffineEnvironment.transform 15 21510 env11513 = env11514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env11513 == env11514) = true)

theorem identity11514 : scanCanonicalize (H12AffineFastState.compose env11514 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound11514 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env11515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,398,13508,10281,1025,8540,4161,168,17,8463,8328,64,2049,5392,4232,10281,1501,32,257,168,5593,9092]

theorem envBound11515 : H12AffineFastState.Bounded env11515 := by
  intro p hp
  have h : env11515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11514_11515 : H12AffineEnvironment.transform 13 5512 env11514 = env11515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env11514 == env11515) = true)

theorem identity11515 : scanCanonicalize (H12AffineFastState.compose env11515 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound11515 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5512,216,398,5441,2476,1025,217,4161,168,17,138,269,64,2049,5392,4232,2476,1501,32,257,168,5593,513]

theorem envBound11516 : H12AffineFastState.Bounded env11516 := by
  intro p hp
  have h : env11516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11515_11516 : H12AffineEnvironment.transform 12 389 env11515 = env11516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env11515 == env11516) = true)

theorem identity11516 : scanCanonicalize (H12AffineFastState.compose env11516 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11516 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11517 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,137,398,5392,2476,1025,136,4112,168,17,138,269,17,2049,5392,4232,2476,1420,32,257,168,5512,513]

theorem envBound11517 : H12AffineFastState.Bounded env11517 := by
  intro p hp
  have h : env11517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11516_11517 : H12AffineEnvironment.transform 5 17 env11516 = env11517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11516 == env11517) = true)

theorem identity11517 : scanCanonicalize (H12AffineFastState.compose env11517 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11517 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11518 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4112,32,17,2,269,17,2049,5392,4096,2340,1284,32,257,32,5376,513]

theorem envBound11518 : H12AffineFastState.Bounded env11518 := by
  intro p hp
  have h : env11518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11517_11518 : H12AffineEnvironment.transform 6 8 env11517 = env11518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11517 == env11518) = true)

theorem identity11518 : scanCanonicalize (H12AffineFastState.compose env11518 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound11518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11519 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,33,269,1313,1,262,1329,2340,1025,0,49,32,17,2,269,17,2049,1329,33,2340,1284,32,257,32,1313,513]

theorem envBound11519 : H12AffineFastState.Bounded env11519 := by
  intro p hp
  have h : env11519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11518_11519 : H12AffineEnvironment.transform 11 33 env11518 = env11519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env11518 == env11519) = true)

theorem identity11519 : scanCanonicalize (H12AffineFastState.compose env11519 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound11519 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11520 : List Nat := [2,4,8,16,32,17,8,256,276,1024,2048,33,269,1313,1,262,1329,2340,1025,0,49,32,17,2,269,17,2049,1329,33,2340,1284,32,257,32,1313,277]

theorem envBound11520 : H12AffineFastState.Bounded env11520 := by
  intro p hp
  have h : env11520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11519_11520 : H12AffineEnvironment.transform 8 276 env11519 = env11520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env11519 == env11520) = true)

theorem identity11520 : scanCanonicalize (H12AffineFastState.compose env11520 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound11520 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11521 : List Nat := [2,4,8,16,32,17,8,256,276,5,2048,33,269,292,1,262,308,2340,4,0,49,32,17,2,269,17,2049,308,33,2340,257,32,257,32,292,277]

theorem envBound11521 : H12AffineFastState.Bounded env11521 := by
  intro p hp
  have h : env11521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11520_11521 : H12AffineEnvironment.transform 9 5 env11520 = env11521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env11520 == env11521) = true)

theorem identity11521 : scanCanonicalize (H12AffineFastState.compose env11521 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound11521 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11522 : List Nat := [2,4,8,16,32,17,8,52,32,5,2048,33,57,16,1,50,0,2064,4,0,49,32,17,2,57,17,2049,0,33,2064,53,32,53,32,16,33]

theorem envBound11522 : H12AffineFastState.Bounded env11522 := by
  intro p hp
  have h : env11522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11521_11522 : H12AffineEnvironment.transform 7 52 env11521 = env11522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env11521 == env11522) = true)

theorem identity11522 : scanCanonicalize (H12AffineFastState.compose env11522 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11522 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11523 : List Nat := [2,4,8,16,32,17,8,52,32,5,0,33,57,16,1,50,0,16,4,0,49,32,17,2,57,17,1,0,33,16,53,32,53,32,16,33]

theorem envBound11523 : H12AffineFastState.Bounded env11523 := by
  intro p hp
  have h : env11523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11522_11523 : H12AffineEnvironment.transform 10 0 env11522 = env11523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11522 == env11523) = true)

theorem identity11523 : scanCanonicalize (H12AffineFastState.compose env11523 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11523 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11524 : List Nat := [2,4,8,16,17,17,8,5,17,5,0,16,8,16,1,3,0,16,4,0,0,17,17,2,8,17,1,0,16,16,4,17,4,17,16,16]

theorem envBound11524 : H12AffineFastState.Bounded env11524 := by
  intro p hp
  have h : env11524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11523_11524 : H12AffineEnvironment.transform 4 17 env11523 = env11524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11523 == env11524) = true)

def env11525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169353,98781,8328,64,4510805,163976,17665,284041,168004,4350405,257,21792,46212,243603]

theorem envBound11525 : H12AffineFastState.Bounded env11525 := by
  intro p hp
  have h : env11525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11492_11525 : H12AffineEnvironment.transform 22 169353 env11492 = env11525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env11492 == env11525) = true)

def env11526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169353,98781,8328,64,64725,163976,17665,284041,168004,411973,257,21792,46212,243603]

theorem envBound11526 : H12AffineFastState.Bounded env11526 := by
  intro p hp
  have h : env11526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11525_11526 : H12AffineEnvironment.transform 21 272512 env11525 = env11526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11525 == env11526) = true)

def env11527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272392,169217,98645,8192,64,64605,163840,17665,283905,168004,411973,257,21792,46092,243483]

theorem envBound11527 : H12AffineFastState.Bounded env11527 := by
  intro p hp
  have h : env11527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11526_11527 : H12AffineEnvironment.transform 6 8 env11526 = env11527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11526 == env11527) = true)

theorem identity11527 : scanCanonicalize (H12AffineFastState.compose env11527 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound11527 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env11528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,77898,272392,73755,98645,8192,64,64605,79130,17665,283905,75102,392287,257,21792,46092,513]

theorem envBound11528 : H12AffineFastState.Bounded env11528 := by
  intro p hp
  have h : env11528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11527_11528 : H12AffineEnvironment.transform 16 111898 env11527 = env11528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env11527 == env11528) = true)

theorem identity11528 : scanCanonicalize (H12AffineFastState.compose env11528 (packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound11528 : packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env11529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,67618,1025,32769,77898,73770,73755,98645,8192,64,64605,79130,17665,89379,75102,62589,257,21792,46092,513]

theorem envBound11529 : H12AffineFastState.Bounded env11529 := by
  intro p hp
  have h : env11529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11528_11529 : H12AffineEnvironment.transform 17 67618 env11528 = env11529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env11528 == env11529) = true)

theorem identity11529 : scanCanonicalize (H12AffineFastState.compose env11529 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11529 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1025,32769,4161,33,16,41310,8192,64,64605,5393,17665,32040,1365,62589,257,21792,46092,513]

theorem envBound11530 : H12AffineFastState.Bounded env11530 := by
  intro p hp
  have h : env11530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11529_11530 : H12AffineEnvironment.transform 15 8203 env11529 = env11530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11529 == env11530) = true)

theorem identity11530 : scanCanonicalize (H12AffineFastState.compose env11530 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound11530 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8203,5440,10281,1025,80,4161,33,16,8463,8192,64,31756,5393,17665,32040,1365,29740,257,21792,13405,513]

theorem envBound11531 : H12AffineFastState.Bounded env11531 := by
  intro p hp
  have h : env11531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11530_11531 : H12AffineEnvironment.transform 14 81 env11530 = env11531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env11530 == env11531) = true)

def env11532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272393,169216,98644,8193,64,64604,163841,17665,283904,168004,411973,257,21792,46093,243482]

theorem envBound11532 : H12AffineFastState.Bounded env11532 := by
  intro p hp
  have h : env11532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11526_11532 : H12AffineEnvironment.transform 6 9 env11526 = env11532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11526 == env11532) = true)

theorem identity11532 : scanCanonicalize (H12AffineFastState.compose env11532 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound11532 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env11533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,50497,272393,54544,98644,8193,64,64604,49169,17665,283904,53332,264533,257,21792,46093,128778]

theorem envBound11533 : H12AffineFastState.Bounded env11533 := by
  intro p hp
  have h : env11533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11532_11533 : H12AffineEnvironment.transform 16 16400 env11532 = env11533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11532 == env11533) = true)

def env11534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,4161,272393,16,87124,8193,64,10588,5393,17665,283904,1364,264533,257,21792,24845,74250]

theorem envBound11534 : H12AffineFastState.Bounded env11534 := by
  intro p hp
  have h : env11534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11533_11534 : H12AffineEnvironment.transform 14 21760 env11533 = env11534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11533 == env11534) = true)

theorem identity11534 : scanCanonicalize (H12AffineFastState.compose env11534 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound11534 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21591,16400,262144,1025,21761,4161,272393,16,3,8193,64,10588,5393,17665,283904,1364,264533,257,21792,24845,30301]

theorem envBound11535 : H12AffineFastState.Bounded env11535 := by
  intro p hp
  have h : env11535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11534_11535 : H12AffineEnvironment.transform 15 21591 env11534 = env11535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env11534 == env11535) = true)

theorem identity11535 : scanCanonicalize (H12AffineFastState.compose env11535 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound11535 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env11536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21591,16400,32041,1025,21761,4161,21792,16,3,8193,64,10588,5393,17665,10281,1364,29820,257,21792,24845,30301]

theorem envBound11536 : H12AffineFastState.Bounded env11536 := by
  intro p hp
  have h : env11536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11535_11536 : H12AffineEnvironment.transform 17 32041 env11535 = env11536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env11535 == env11536) = true)

theorem identity11536 : scanCanonicalize (H12AffineFastState.compose env11536 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11536 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env11537 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,21541,21591,16400,31756,1025,21540,4161,21509,16,3,8193,64,10361,5172,17444,10281,1137,29820,36,21509,24616,30301]

theorem envBound11537 : H12AffineFastState.Bounded env11537 := by
  intro p hp
  have h : env11537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11536_11537 : H12AffineEnvironment.transform 7 37 env11536 = env11537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11536 == env11537) = true)

theorem identity11537 : scanCanonicalize (H12AffineFastState.compose env11537 (packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound11537 : packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env11538 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,1,115,5172,10280,1025,0,4161,33,16,3,8193,64,10361,5172,4096,10281,1137,8280,36,33,13324,8825]

theorem envBound11538 : H12AffineFastState.Bounded env11538 := by
  intro p hp
  have h : env11538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11537_11538 : H12AffineEnvironment.transform 13 5156 env11537 = env11538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env11537 == env11538) = true)

theorem identity11538 : scanCanonicalize (H12AffineFastState.compose env11538 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11538 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11539 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,8192,4112,1,115,4096,10280,53,0,4161,33,16,3,8193,64,10361,4096,4096,10281,69,8280,36,33,12344,8825]

theorem envBound11539 : H12AffineFastState.Bounded env11539 := by
  intro p hp
  have h : env11539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11538_11539 : H12AffineEnvironment.transform 9 52 env11538 = env11539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11538 == env11539) = true)

theorem identity11539 : scanCanonicalize (H12AffineFastState.compose env11539 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound11539 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11540 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,120,4112,1,115,4096,2128,53,0,4161,33,16,3,121,64,2049,4096,4096,2129,69,32,36,33,4160,513]

theorem envBound11540 : H12AffineFastState.Bounded env11540 := by
  intro p hp
  have h : env11540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11539_11540 : H12AffineEnvironment.transform 12 120 env11539 = env11540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env11539 == env11540) = true)

theorem identity11540 : scanCanonicalize (H12AffineFastState.compose env11540 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11541 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4112,1,34,4096,2049,53,0,4112,33,16,3,40,17,2049,4096,4096,2048,20,32,36,33,4113,513]

theorem envBound11541 : H12AffineFastState.Bounded env11541 := by
  intro p hp
  have h : env11541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11540_11541 : H12AffineEnvironment.transform 5 17 env11540 = env11541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11540 == env11541) = true)

theorem identity11541 : scanCanonicalize (H12AffineFastState.compose env11541 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11542 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,4096,41,4112,1,34,4096,529,53,0,4112,33,16,3,40,17,529,4096,4096,528,20,32,36,33,4113,513]

theorem envBound11542 : H12AffineFastState.Bounded env11542 := by
  intro p hp
  have h : env11542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11541_11542 : H12AffineEnvironment.transform 10 528 env11541 = env11542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11541 == env11542) = true)

theorem identity11542 : scanCanonicalize (H12AffineFastState.compose env11542 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound11542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11543 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,27,41,11,1,34,27,529,53,0,11,33,16,3,40,17,529,27,27,528,20,32,36,33,10,513]

theorem envBound11543 : H12AffineFastState.Bounded env11543 := by
  intro p hp
  have h : env11543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11542_11543 : H12AffineEnvironment.transform 11 27 env11542 = env11543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env11542 == env11543) = true)

theorem identity11543 : scanCanonicalize (H12AffineFastState.compose env11543 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound11543 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11544 : List Nat := [2,4,8,16,32,17,9,37,26,52,10,27,41,11,1,34,27,11,53,0,11,33,16,3,40,17,11,27,27,10,20,32,36,33,10,27]

theorem envBound11544 : H12AffineFastState.Bounded env11544 := by
  intro p hp
  have h : env11544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11543_11544 : H12AffineEnvironment.transform 8 26 env11543 = env11544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env11543 == env11544) = true)

def env11545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,4160,272393,17,87125,8193,64,10589,5392,17665,283904,1365,264533,257,21792,24844,74251]

theorem envBound11545 : H12AffineFastState.Bounded env11545 := by
  intro p hp
  have h : env11545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11533_11545 : H12AffineEnvironment.transform 14 21761 env11533 = env11545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env11533 == env11545) = true)

theorem identity11545 : scanCanonicalize (H12AffineFastState.compose env11545 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound11545 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,97407,1025,21760,4160,87158,17,87125,8193,64,10589,5392,17665,76159,1365,95530,257,21792,24844,74251]

theorem envBound11546 : H12AffineFastState.Bounded env11546 := by
  intro p hp
  have h : env11546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11545_11546 : H12AffineEnvironment.transform 17 97407 env11545 = env11546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env11545 == env11546) = true)

theorem identity11546 : scanCanonicalize (H12AffineFastState.compose env11546 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11546 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,16400,23668,1025,21760,4160,29821,17,29790,8193,64,10589,5392,17665,2420,1365,21793,257,21792,24844,512]

theorem envBound11547 : H12AffineFastState.Bounded env11547 := by
  intro p hp
  have h : env11547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11546_11547 : H12AffineEnvironment.transform 15 8203 env11546 = env11547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11546 == env11547) = true)

theorem identity11547 : scanCanonicalize (H12AffineFastState.compose env11547 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound11547 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,292,8203,5173,2129,1025,293,4160,8280,17,8315,8193,64,10589,5392,4388,2420,1365,260,257,261,13609,512]

theorem envBound11548 : H12AffineFastState.Bounded env11548 := by
  intro p hp
  have h : env11548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11547_11548 : H12AffineEnvironment.transform 13 5157 env11547 = env11548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env11547 == env11548) = true)

theorem identity11548 : scanCanonicalize (H12AffineFastState.compose env11548 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound11548 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env11549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,783,4096,8192,5157,292,8203,5173,862,1025,293,4160,8280,17,8315,8193,64,8786,5392,4388,635,1365,260,257,261,13609,512]

theorem envBound11549 : H12AffineFastState.Bounded env11549 := by
  intro p hp
  have h : env11549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11548_11549 : H12AffineEnvironment.transform 10 783 env11548 = env11549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env11548 == env11549) = true)

theorem identity11549 : scanCanonicalize (H12AffineFastState.compose env11549 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11549 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env11550 : List Nat := [2,4,8,16,32,17,9,256,512,1024,783,4096,8192,5157,292,8203,5173,783,1025,293,4113,8201,17,8234,8193,17,8707,5392,4388,554,1284,260,257,261,13609,512]

theorem envBound11550 : H12AffineFastState.Bounded env11550 := by
  intro p hp
  have h : env11550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11549_11550 : H12AffineEnvironment.transform 5 17 env11549 = env11550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11549 == env11550) = true)

theorem identity11550 : scanCanonicalize (H12AffineFastState.compose env11550 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11550 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env11551 : List Nat := [2,4,8,16,32,17,9,256,512,1024,783,4096,269,5157,292,262,5173,783,1025,293,4113,260,17,295,268,17,782,5392,4388,554,1284,260,257,261,5156,512]

theorem envBound11551 : H12AffineFastState.Bounded env11551 := by
  intro p hp
  have h : env11551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11550_11551 : H12AffineEnvironment.transform 12 269 env11550 = env11551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11550 == env11551) = true)

theorem identity11551 : scanCanonicalize (H12AffineFastState.compose env11551 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11551 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11552 : List Nat := [2,4,8,16,32,17,9,5,512,1024,522,4096,8,5157,33,3,5173,522,1025,32,4113,1,17,34,9,17,523,5141,4129,554,1025,1,4,0,5156,512]

theorem envBound11552 : H12AffineFastState.Bounded env11552 := by
  intro p hp
  have h : env11552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11551_11552 : H12AffineEnvironment.transform 7 5 env11551 = env11552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11551 == env11552) = true)

theorem identity11552 : scanCanonicalize (H12AffineFastState.compose env11552 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11552 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11553 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,8,5124,0,3,5140,522,1025,1,4113,1,17,3,9,17,523,5141,4096,523,1025,1,4,0,5125,512]

theorem envBound11553 : H12AffineFastState.Bounded env11553 := by
  intro p hp
  have h : env11553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11552_11553 : H12AffineEnvironment.transform 4 1 env11552 = env11553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11552 == env11553) = true)

def env11554 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,16,8,1044,0,3,1028,522,1025,1,1,1,17,3,9,17,523,1029,16,523,1025,1,4,0,1045,512]

theorem envBound11554 : H12AffineFastState.Bounded env11554 := by
  intro p hp
  have h : env11554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11553_11554 : H12AffineEnvironment.transform 11 16 env11553 = env11554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11553 == env11554) = true)

theorem identity11554 : scanCanonicalize (H12AffineFastState.compose env11554 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound11554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11555 : List Nat := [2,4,8,16,1,17,9,5,512,1,522,16,8,21,0,3,5,522,0,1,1,1,17,3,9,17,523,4,16,523,0,1,4,0,20,512]

theorem envBound11555 : H12AffineFastState.Bounded env11555 := by
  intro p hp
  have h : env11555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11554_11555 : H12AffineEnvironment.transform 9 1 env11554 = env11555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env11554 == env11555) = true)

def env11556 : List Nat := [2,4,8,4,1,5,9,5,512,1,522,4,8,1,0,3,5,522,0,1,1,1,5,3,9,5,523,4,4,523,0,1,4,0,0,512]

theorem envBound11556 : H12AffineFastState.Bounded env11556 := by
  intro p hp
  have h : env11556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11555_11556 : H12AffineEnvironment.transform 3 4 env11555 = env11556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11555 == env11556) = true)

theorem identity11556 : scanCanonicalize (H12AffineFastState.compose env11556 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound11556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11557 : List Nat := [2,4,8,4,1,5,9,5,8,1,2,4,8,1,0,3,5,2,0,1,1,1,5,3,9,5,3,4,4,3,0,1,4,0,0,8]

theorem envBound11557 : H12AffineFastState.Bounded env11557 := by
  intro p hp
  have h : env11557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11556_11557 : H12AffineEnvironment.transform 8 8 env11556 = env11557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env11556 == env11557) = true)

def leafEnv11557 : List Nat := [2,4,8,4,1,5,9,5,8,1,2,4,8,1,0,3,5,2,0,1,1,1,5,3,0,9,1,5,3,4,4,3,0,1,4,0,4,2,0,8,1,0,0]

def active11557 : List Nat := [0,1,2]

def tree11557 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11557 : H12WitnessSearch.Good tree11557 := H12GlobalWitnessIndex.good

theorem leafIdentity11557 : H12AffineFastState.composeSystem env11557 rootObs = leafEnv11557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11557 rootObs == leafEnv11557) = true)

theorem terminalChecked11557 : H12PackedTerminal.terminalCheckFast leafEnv11557 active11557 tree11557 = true := by decide +kernel

def env11558 : List Nat := [2,4,8,5,1,4,9,5,512,1,522,5,8,0,0,3,5,522,0,1,1,1,4,3,9,4,523,4,5,523,0,1,4,0,1,512]

theorem envBound11558 : H12AffineFastState.Bounded env11558 := by
  intro p hp
  have h : env11558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11555_11558 : H12AffineEnvironment.transform 3 5 env11555 = env11558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11555 == env11558) = true)

theorem identity11558 : scanCanonicalize (H12AffineFastState.compose env11558 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11559 : List Nat := [1,4,8,5,1,4,9,5,512,1,521,5,8,0,0,0,5,521,0,1,1,1,4,0,9,4,520,4,5,520,0,1,4,0,1,512]

theorem envBound11559 : H12AffineFastState.Bounded env11559 := by
  intro p hp
  have h : env11559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11558_11559 : H12AffineEnvironment.transform 0 1 env11558 = env11559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11558 == env11559) = true)

def leafEnv11559 : List Nat := [1,4,8,5,1,4,9,5,512,1,521,5,8,0,0,0,5,521,0,1,1,1,4,0,0,9,1,4,520,4,5,520,0,1,4,0,4,1,1,512,1,0,0]

def active11559 : List Nat := [1,2,8]

def tree11559 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11559 : H12WitnessSearch.Good tree11559 := H12GlobalWitnessIndex.good

theorem leafIdentity11559 : H12AffineFastState.composeSystem env11559 rootObs = leafEnv11559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11559 rootObs == leafEnv11559) = true)

theorem terminalChecked11559 : H12PackedTerminal.terminalCheckFast leafEnv11559 active11559 tree11559 = true := by decide +kernel

def env11560 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,17,8,1045,0,3,1029,522,1025,1,0,1,17,3,9,17,523,1028,17,523,1025,1,4,0,1044,512]

theorem envBound11560 : H12AffineFastState.Bounded env11560 := by
  intro p hp
  have h : env11560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11553_11560 : H12AffineEnvironment.transform 11 17 env11553 = env11560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11553 == env11560) = true)

theorem identity11560 : scanCanonicalize (H12AffineFastState.compose env11560 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound11560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11561 : List Nat := [2,4,8,4,1,5,9,5,512,1024,522,5,8,1025,0,3,1029,522,1025,1,0,1,5,3,9,5,523,1028,5,523,1025,1,4,0,1024,512]

theorem envBound11561 : H12AffineFastState.Bounded env11561 := by
  intro p hp
  have h : env11561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11560_11561 : H12AffineEnvironment.transform 3 4 env11560 = env11561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11560 == env11561) = true)

def env11562 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,5,8,1,0,3,5,522,1,1,0,1,5,3,9,5,523,4,5,523,1,1,4,0,0,512]

theorem envBound11562 : H12AffineFastState.Bounded env11562 := by
  intro p hp
  have h : env11562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11561_11562 : H12AffineEnvironment.transform 9 0 env11561 = env11562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env11561 == env11562) = true)

theorem identity11562 : scanCanonicalize (H12AffineFastState.compose env11562 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11563 : List Nat := [1,4,8,4,1,5,9,5,512,0,521,5,8,1,0,0,5,521,1,1,0,1,5,0,9,5,520,4,5,520,1,1,4,0,0,512]

theorem envBound11563 : H12AffineFastState.Bounded env11563 := by
  intro p hp
  have h : env11563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11562_11563 : H12AffineEnvironment.transform 0 1 env11562 = env11563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11562 == env11563) = true)

def leafEnv11563 : List Nat := [1,4,8,4,1,5,9,5,512,0,521,5,8,1,0,0,5,521,1,1,0,1,5,0,1,9,1,5,520,4,5,520,1,1,4,0,4,1,0,512,1,1,0]

def active11563 : List Nat := [1,2,8]

def tree11563 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11563 : H12WitnessSearch.Good tree11563 := H12GlobalWitnessIndex.good

theorem leafIdentity11563 : H12AffineFastState.composeSystem env11563 rootObs = leafEnv11563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11563 rootObs == leafEnv11563) = true)

theorem terminalChecked11563 : H12PackedTerminal.terminalCheckFast leafEnv11563 active11563 tree11563 = true := by decide +kernel

def env11564 : List Nat := [2,4,8,4,1,5,9,5,512,1,522,5,8,0,0,3,4,522,0,1,0,1,5,3,9,5,523,5,5,523,0,1,4,0,1,512]

theorem envBound11564 : H12AffineFastState.Bounded env11564 := by
  intro p hp
  have h : env11564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11561_11564 : H12AffineEnvironment.transform 9 1 env11561 = env11564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env11561 == env11564) = true)

theorem identity11564 : scanCanonicalize (H12AffineFastState.compose env11564 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound11564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11565 : List Nat := [2,4,8,4,1,5,9,5,9,1,3,5,8,0,0,3,4,3,0,1,0,1,5,3,9,5,2,5,5,2,0,1,4,0,1,9]

theorem envBound11565 : H12AffineFastState.Bounded env11565 := by
  intro p hp
  have h : env11565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11564_11565 : H12AffineEnvironment.transform 8 9 env11564 = env11565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env11564 == env11565) = true)

def leafEnv11565 : List Nat := [2,4,8,4,1,5,9,5,9,1,3,5,8,0,0,3,4,3,0,1,0,1,5,3,0,9,1,5,2,5,5,2,0,1,4,0,4,2,1,9,1,1,0]

def active11565 : List Nat := [0,1,2]

def tree11565 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11565 : H12WitnessSearch.Good tree11565 := H12GlobalWitnessIndex.good

theorem leafIdentity11565 : H12AffineFastState.composeSystem env11565 rootObs = leafEnv11565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11565 rootObs == leafEnv11565) = true)

theorem terminalChecked11565 : H12PackedTerminal.terminalCheckFast leafEnv11565 active11565 tree11565 = true := by decide +kernel

def env11566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169353,98781,8328,64,64724,163976,17665,284041,168004,411972,257,21792,46212,243603]

theorem envBound11566 : H12AffineFastState.Bounded env11566 := by
  intro p hp
  have h : env11566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11525_11566 : H12AffineEnvironment.transform 21 272513 env11525 = env11566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11525 == env11566) = true)

theorem identity11566 : scanCanonicalize (H12AffineFastState.compose env11566 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound11566 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4160,272513,17,98781,8328,64,64724,5392,17665,284041,1500,318684,257,21792,46212,74251]

theorem envBound11567 : H12AffineFastState.Bounded env11567 := by
  intro p hp
  have h : env11567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11566_11567 : H12AffineEnvironment.transform 16 38296 env11566 = env11567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env11566 == env11567) = true)

theorem identity11567 : scanCanonicalize (H12AffineFastState.compose env11567 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11567 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env11568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,4160,272513,17,41431,8328,64,64724,5392,17665,284041,1500,318684,257,21792,46212,513]

theorem envBound11568 : H12AffineFastState.Bounded env11568 := by
  intro p hp
  have h : env11568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11567_11568 : H12AffineEnvironment.transform 15 8202 env11567 = env11568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11567 == env11568) = true)

def env11569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,8388608,8590421,8328,64,4510804,8393984,8573064,8830976,168005,12645453,257,21793,46213,243602]

theorem envBound11569 : H12AffineFastState.Bounded env11569 := by
  intro p hp
  have h : env11569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11491_11569 : H12AffineEnvironment.transform 23 8590421 env11491 = env11569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590421 env11491 == env11569) = true)

def env11570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169352,98781,8328,64,4510804,163976,17664,284040,168005,4350405,257,21793,46213,243602]

theorem envBound11570 : H12AffineFastState.Bounded env11570 := by
  intro p hp
  have h : env11570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11569_11570 : H12AffineEnvironment.transform 22 169352 env11569 = env11570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env11569 == env11570) = true)

def env11571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169352,98781,8328,64,64724,163976,17664,284040,168005,411973,257,21793,46213,243602]

theorem envBound11571 : H12AffineFastState.Bounded env11571 := by
  intro p hp
  have h : env11571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11570_11571 : H12AffineEnvironment.transform 21 272512 env11570 = env11571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11570 == env11571) = true)

theorem identity11571 : scanCanonicalize (H12AffineFastState.compose env11571 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound11571 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,77899,272512,73755,98781,8328,64,64724,79131,17664,284040,75222,392406,257,21793,46213,513]

theorem envBound11572 : H12AffineFastState.Bounded env11572 := by
  intro p hp
  have h : env11572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11571_11572 : H12AffineEnvironment.transform 16 112019 env11571 = env11572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env11571 == env11572) = true)

def env11573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90259,262144,1025,21761,77899,272512,73755,87261,8328,64,10708,79131,17664,284040,75222,338390,257,21793,24965,513]

theorem envBound11573 : H12AffineFastState.Bounded env11573 := by
  intro p hp
  have h : env11573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11572_11573 : H12AffineEnvironment.transform 14 21760 env11572 = env11573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11572 == env11573) = true)

theorem identity11573 : scanCanonicalize (H12AffineFastState.compose env11573 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11573 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90139,262144,1025,21761,77899,272392,73755,87125,8192,64,10588,79131,17664,283904,75102,338270,257,21793,24845,513]

theorem envBound11574 : H12AffineFastState.Bounded env11574 := by
  intro p hp
  have h : env11574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11573_11574 : H12AffineEnvironment.transform 6 8 env11573 = env11574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11573 == env11574) = true)

theorem identity11574 : scanCanonicalize (H12AffineFastState.compose env11574 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound11574 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env11575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90139,67618,1025,21761,77899,73770,73755,87125,8192,64,10588,79131,17664,89378,75102,8572,257,21793,24845,513]

theorem envBound11575 : H12AffineFastState.Bounded env11575 := by
  intro p hp
  have h : env11575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11574_11575 : H12AffineEnvironment.transform 17 67618 env11574 = env11575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env11574 == env11575) = true)

theorem identity11575 : scanCanonicalize (H12AffineFastState.compose env11575 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11575 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,16400,10281,1025,21761,4160,33,16,29790,8192,64,10588,5392,17664,32041,1365,8572,257,21793,24845,513]

theorem envBound11576 : H12AffineFastState.Bounded env11576 := by
  intro p hp
  have h : env11576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11575_11576 : H12AffineEnvironment.transform 15 8203 env11575 = env11576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11575 == env11576) = true)

theorem identity11576 : scanCanonicalize (H12AffineFastState.compose env11576 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound11576 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8203,13389,10281,1025,8540,4160,33,16,3,8192,64,10588,5392,12637,2420,1365,8572,257,8572,5456,513]

theorem envBound11577 : H12AffineFastState.Bounded env11577 := by
  intro p hp
  have h : env11577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11576_11577 : H12AffineEnvironment.transform 13 13405 env11576 = env11577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env11576 == env11577) = true)

theorem identity11577 : scanCanonicalize (H12AffineFastState.compose env11577 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11577 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11578 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13405,8313,8203,13389,10281,1025,8312,4160,33,16,3,8192,64,10360,5172,12409,2128,1137,8280,37,8280,5236,513]

theorem envBound11578 : H12AffineFastState.Bounded env11578 := by
  intro p hp
  have h : env11578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11577_11578 : H12AffineEnvironment.transform 7 36 env11577 = env11578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11577 == env11578) = true)

theorem identity11578 : scanCanonicalize (H12AffineFastState.compose env11578 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound11578 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11579 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,4096,8192,12344,8313,8203,12328,10281,100,8312,4160,33,16,3,8192,64,10360,4177,12409,2128,20,8280,37,8280,4113,513]

theorem envBound11579 : H12AffineFastState.Bounded env11579 := by
  intro p hp
  have h : env11579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11578_11579 : H12AffineEnvironment.transform 9 101 env11578 = env11579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env11578 == env11579) = true)

theorem identity11579 : scanCanonicalize (H12AffineFastState.compose env11579 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 4201) := by decide +kernel

theorem selectedBound11579 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11580 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,4096,4201,81,4112,4194,65,6208,100,4113,4160,33,16,3,4201,64,6161,4177,16,2128,20,4145,37,4145,4113,513]

theorem envBound11580 : H12AffineFastState.Bounded env11580 := by
  intro p hp
  have h : env11580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11579_11580 : H12AffineEnvironment.transform 12 4201 env11579 = env11580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4201 env11579 == env11580) = true)

theorem identity11580 : scanCanonicalize (H12AffineFastState.compose env11580 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11580 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env11581 : List Nat := [2,4,8,16,32,64,8,36,512,101,1,4096,4201,81,4112,4194,65,4161,100,4113,4160,33,16,3,4201,64,4112,4177,16,81,20,4145,37,4145,4113,513]

theorem envBound11581 : H12AffineFastState.Bounded env11581 := by
  intro p hp
  have h : env11581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11580_11581 : H12AffineEnvironment.transform 10 1 env11580 = env11581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11580 == env11581) = true)

theorem identity11581 : scanCanonicalize (H12AffineFastState.compose env11581 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11581 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11582 : List Nat := [2,4,8,16,32,64,8,36,512,101,1,16,121,81,0,114,65,81,100,1,80,33,16,3,121,64,0,65,16,81,20,33,37,33,1,513]

theorem envBound11582 : H12AffineFastState.Bounded env11582 := by
  intro p hp
  have h : env11582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11581_11582 : H12AffineEnvironment.transform 11 16 env11581 = env11582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11581 == env11582) = true)

theorem identity11582 : scanCanonicalize (H12AffineFastState.compose env11582 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11583 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,16,41,1,0,34,17,1,52,1,0,33,16,3,41,16,0,17,16,1,20,33,37,33,1,513]

theorem envBound11583 : H12AffineFastState.Bounded env11583 := by
  intro p hp
  have h : env11583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11582_11583 : H12AffineEnvironment.transform 5 16 env11582 = env11583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11582 == env11583) = true)

theorem identity11583 : scanCanonicalize (H12AffineFastState.compose env11583 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound11583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11584 : List Nat := [2,4,8,16,32,16,8,36,33,53,1,16,41,1,0,34,17,1,52,1,0,33,16,3,41,16,0,17,16,1,20,33,37,33,1,32]

theorem envBound11584 : H12AffineFastState.Bounded env11584 := by
  intro p hp
  have h : env11584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11583_11584 : H12AffineEnvironment.transform 8 33 env11583 = env11584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env11583 == env11584) = true)

def env11585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90258,262144,1025,21760,77899,272512,73755,87260,8328,64,10709,79131,17664,284040,75222,338391,257,21793,24964,513]

theorem envBound11585 : H12AffineFastState.Bounded env11585 := by
  intro p hp
  have h : env11585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11572_11585 : H12AffineEnvironment.transform 14 21761 env11572 = env11585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env11572 == env11585) = true)

theorem identity11585 : scanCanonicalize (H12AffineFastState.compose env11585 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound11585 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env11586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8322,16400,262144,1025,21760,4297,272512,153,29790,8328,64,10709,5529,17664,284040,1364,264533,257,21793,24964,513]

theorem envBound11586 : H12AffineFastState.Bounded env11586 := by
  intro p hp
  have h : env11586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11585_11586 : H12AffineEnvironment.transform 15 8322 env11585 = env11586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env11585 == env11586) = true)

theorem identity11586 : scanCanonicalize (H12AffineFastState.compose env11586 (packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound11586 : packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS < 2^1333 := by decide +kernel

def env11587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,136,8322,5529,262144,1025,137,4297,272512,153,8663,8328,64,10709,5529,4233,262145,1364,264533,257,168,13325,513]

theorem envBound11587 : H12AffineFastState.Bounded env11587 := by
  intro p hp
  have h : env11587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11586_11587 : H12AffineEnvironment.transform 13 5513 env11586 = env11587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env11586 == env11587) = true)

theorem identity11587 : scanCanonicalize (H12AffineFastState.compose env11587 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11587 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env11588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,136,479,5529,262144,1025,137,4297,264669,153,138,469,64,2184,5529,4233,262145,1364,264533,257,168,5456,513]

theorem envBound11588 : H12AffineFastState.Bounded env11588 := by
  intro p hp
  have h : env11588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11587_11588 : H12AffineEnvironment.transform 12 349 env11587 = env11588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11587 == env11588) = true)

theorem identity11588 : scanCanonicalize (H12AffineFastState.compose env11588 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound11588 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env11589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,136,479,5529,2421,1025,137,4297,168,153,138,469,64,2184,5529,4233,2420,1364,32,257,168,5456,513]

theorem envBound11589 : H12AffineFastState.Bounded env11589 := by
  intro p hp
  have h : env11589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11588_11589 : H12AffineEnvironment.transform 17 2421 env11588 = env11589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env11588 == env11589) = true)

theorem identity11589 : scanCanonicalize (H12AffineFastState.compose env11589 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11589 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2421,1025,0,4160,33,16,3,348,64,2049,5392,4096,2420,1364,32,257,33,5456,513]

theorem envBound11590 : H12AffineFastState.Bounded env11590 := by
  intro p hp
  have h : env11590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11589_11590 : H12AffineEnvironment.transform 6 9 env11589 = env11590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11589 == env11590) = true)

theorem identity11590 : scanCanonicalize (H12AffineFastState.compose env11590 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11590 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11591 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2340,1025,0,4113,33,16,3,269,17,2049,5392,4096,2341,1285,32,257,33,5377,513]

theorem envBound11591 : H12AffineFastState.Bounded env11591 := by
  intro p hp
  have h : env11591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11590_11591 : H12AffineEnvironment.transform 5 17 env11590 = env11591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11590 == env11591) = true)

theorem identity11591 : scanCanonicalize (H12AffineFastState.compose env11591 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound11591 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11592 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3329,268,2049,1,263,2065,2340,1025,0,3344,33,16,3,269,17,2049,2065,3329,2341,1285,32,257,33,2048,513]

theorem envBound11592 : H12AffineFastState.Bounded env11592 := by
  intro p hp
  have h : env11592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11591_11592 : H12AffineEnvironment.transform 11 3329 env11591 = env11592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env11591 == env11592) = true)

theorem identity11592 : scanCanonicalize (H12AffineFastState.compose env11592 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11592 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11593 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,40,2049,1,35,2065,2048,1025,0,3124,33,16,3,41,17,2049,2065,3109,2049,1057,32,37,33,2048,513]

theorem envBound11593 : H12AffineFastState.Bounded env11593 := by
  intro p hp
  have h : env11593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11592_11593 : H12AffineEnvironment.transform 7 36 env11592 = env11593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11592 == env11593) = true)

theorem identity11593 : scanCanonicalize (H12AffineFastState.compose env11593 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11593 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11594 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2065,40,2049,1,35,2065,2048,53,0,2048,33,16,3,41,17,2049,2065,2065,2049,21,32,37,33,2048,513]

theorem envBound11594 : H12AffineFastState.Bounded env11594 := by
  intro p hp
  have h : env11594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11593_11594 : H12AffineEnvironment.transform 9 52 env11593 = env11594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11593 == env11594) = true)

def env11595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169352,98781,8328,64,64725,163976,17664,284040,168005,411972,257,21793,46213,243602]

theorem envBound11595 : H12AffineFastState.Bounded env11595 := by
  intro p hp
  have h : env11595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11570_11595 : H12AffineEnvironment.transform 21 272513 env11570 = env11595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11570 == env11595) = true)

theorem identity11595 : scanCanonicalize (H12AffineFastState.compose env11595 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11595 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165336,272513,169352,41431,8328,64,64725,163976,17664,284040,168005,411972,257,21793,46213,169880]

theorem envBound11596 : H12AffineFastState.Bounded env11596 := by
  intro p hp
  have h : env11596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11595_11596 : H12AffineEnvironment.transform 15 8202 env11595 = env11596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11595 == env11596) = true)

def env11597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165200,272393,169216,41311,8192,64,64605,163840,17664,283904,168005,411972,257,21793,46093,169744]

theorem envBound11597 : H12AffineFastState.Bounded env11597 := by
  intro p hp
  have h : env11597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11596_11597 : H12AffineEnvironment.transform 6 8 env11596 = env11597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11596 == env11597) = true)

theorem identity11597 : scanCanonicalize (H12AffineFastState.compose env11597 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound11597 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1025,32769,165200,169264,169216,41311,8192,64,64605,163840,17664,190521,168005,62589,257,21793,46093,169744]

theorem envBound11598 : H12AffineFastState.Bounded env11598 := by
  intro p hp
  have h : env11598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11597_11598 : H12AffineEnvironment.transform 17 179513 env11597 = env11598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env11597 == env11598) = true)

def env11599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165201,272392,169217,41310,8193,64,64604,163841,17664,283905,168005,411972,257,21793,46092,169745]

theorem envBound11599 : H12AffineFastState.Bounded env11599 := by
  intro p hp
  have h : env11599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11596_11599 : H12AffineEnvironment.transform 6 9 env11596 = env11599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11596 == env11599) = true)

theorem identity11599 : scanCanonicalize (H12AffineFastState.compose env11599 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound11599 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138341,1025,32769,165201,144493,169217,41310,8193,64,64604,163841,17664,149860,168005,21793,257,21793,46092,169745]

theorem envBound11600 : H12AffineFastState.Bounded env11600 := by
  intro p hp
  have h : env11600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11599_11600 : H12AffineEnvironment.transform 17 138341 env11599 = env11600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env11599 == env11600) = true)

theorem identity11600 : scanCanonicalize (H12AffineFastState.compose env11600 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound11600 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8202,131072,138341,1025,29993,159865,144493,155689,21622,8193,64,2420,161065,17664,149860,157037,21793,257,21793,16676,156217]

theorem envBound11601 : H12AffineFastState.Bounded env11601 := by
  intro p hp
  have h : env11601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11600_11601 : H12AffineEnvironment.transform 14 29992 env11600 = env11601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env11600 == env11601) = true)

theorem identity11601 : scanCanonicalize (H12AffineFastState.compose env11601 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 24633) := by decide +kernel

theorem selectedBound11601 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env11602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8202,24633,31836,1025,29993,4160,21588,16,21622,8193,64,2420,5392,17664,10589,1364,21793,257,21793,16676,512]

theorem envBound11602 : H12AffineFastState.Bounded env11602 := by
  intro p hp
  have h : env11602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11601_11602 : H12AffineEnvironment.transform 16 24633 env11601 = env11602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24633 env11601 == env11602) = true)

theorem identity11602 : scanCanonicalize (H12AffineFastState.compose env11602 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11602 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11603 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29709,8202,24633,31836,1025,29708,4160,21588,16,21622,8193,64,2129,5173,17445,10360,1137,21508,36,21508,16385,512]

theorem envBound11603 : H12AffineFastState.Bounded env11603 := by
  intro p hp
  have h : env11603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11602_11603 : H12AffineEnvironment.transform 7 37 env11602 = env11603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11602 == env11603) = true)

theorem identity11603 : scanCanonicalize (H12AffineFastState.compose env11603 (packedSelected [2,3,5,6,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound11603 : packedSelected [2,3,5,6,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env11604 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,1076,12345,8202,9229,14440,1025,12344,4160,4192,16,4162,8193,64,2129,5173,17,10360,1137,4144,36,4144,1077,512]

theorem envBound11604 : H12AffineFastState.Bounded env11604 := by
  intro p hp
  have h : env11604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11603_11604 : H12AffineEnvironment.transform 13 1076 env11603 = env11604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env11603 == env11604) = true)

theorem identity11604 : scanCanonicalize (H12AffineFastState.compose env11604 (packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound11604 : packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env11605 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,97,8192,1076,8280,8202,9229,10249,1025,8281,33,1,16,35,8193,64,2129,1108,17,10360,1137,81,36,81,1077,512]

theorem envBound11605 : H12AffineFastState.Bounded env11605 := by
  intro p hp
  have h : env11605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11604_11605 : H12AffineEnvironment.transform 11 97 env11604 = env11605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env11604 == env11605) = true)

theorem identity11605 : scanCanonicalize (H12AffineFastState.compose env11605 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11605 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env11606 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,65,8192,1044,8280,8202,9229,10249,1025,8281,1,1,16,3,8193,64,2129,1108,17,10328,1105,81,4,81,1045,512]

theorem envBound11606 : H12AffineFastState.Bounded env11606 := by
  intro p hp
  have h : env11606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11605_11606 : H12AffineEnvironment.transform 4 0 env11605 = env11606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11605 == env11606) = true)

theorem identity11606 : scanCanonicalize (H12AffineFastState.compose env11606 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound11606 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env11607 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,65,89,1044,1,83,1108,2128,1025,0,1,1,16,3,88,64,2129,1108,17,2049,1105,81,4,81,1045,512]

theorem envBound11607 : H12AffineFastState.Bounded env11607 := by
  intro p hp
  have h : env11607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11606_11607 : H12AffineEnvironment.transform 12 89 env11606 = env11607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env11606 == env11607) = true)

theorem identity11607 : scanCanonicalize (H12AffineFastState.compose env11607 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound11607 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env11608 : List Nat := [2,4,8,16,0,64,9,5,512,69,2048,65,89,81,1,83,17,2128,68,0,1,1,16,3,88,64,2129,17,17,2049,20,81,4,81,80,512]

theorem envBound11608 : H12AffineFastState.Bounded env11608 := by
  intro p hp
  have h : env11608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11607_11608 : H12AffineEnvironment.transform 9 69 env11607 = env11608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env11607 == env11608) = true)

theorem identity11608 : scanCanonicalize (H12AffineFastState.compose env11608 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11608 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11609 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,16,8,0,1,2,17,2049,21,0,1,1,16,3,9,17,2048,17,17,2049,20,0,4,0,1,512]

theorem envBound11609 : H12AffineFastState.Bounded env11609 := by
  intro p hp
  have h : env11609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11608_11609 : H12AffineEnvironment.transform 5 17 env11608 = env11609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11608 == env11609) = true)

theorem identity11609 : scanCanonicalize (H12AffineFastState.compose env11609 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound11609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11610 : List Nat := [2,1,8,16,0,17,9,0,512,17,2048,16,8,0,1,2,17,2049,16,0,1,1,16,3,9,17,2048,17,17,2049,17,0,1,0,1,512]

theorem envBound11610 : H12AffineFastState.Bounded env11610 := by
  intro p hp
  have h : env11610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11609_11610 : H12AffineEnvironment.transform 1 1 env11609 = env11610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env11609 == env11610) = true)

theorem identity11610 : scanCanonicalize (H12AffineFastState.compose env11610 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound11610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11611 : List Nat := [2,1,0,16,0,17,1,0,512,17,2048,16,0,0,1,2,17,2049,16,0,1,1,16,3,1,17,2048,17,17,2049,17,0,1,0,1,512]

theorem envBound11611 : H12AffineFastState.Bounded env11611 := by
  intro p hp
  have h : env11611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11610_11611 : H12AffineEnvironment.transform 2 0 env11610 = env11611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env11610 == env11611) = true)

def env11612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169353,98780,8328,64,4510804,163977,17665,284041,168005,4350404,257,21793,46213,243602]

theorem envBound11612 : H12AffineFastState.Bounded env11612 := by
  intro p hp
  have h : env11612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11569_11612 : H12AffineEnvironment.transform 22 169353 env11569 = env11612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env11569 == env11612) = true)

def env11613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169353,98780,8328,64,64724,163977,17665,284041,168005,411972,257,21793,46213,243602]

theorem envBound11613 : H12AffineFastState.Bounded env11613 := by
  intro p hp
  have h : env11613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11612_11613 : H12AffineEnvironment.transform 21 272512 env11612 = env11613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11612 == env11613) = true)

theorem identity11613 : scanCanonicalize (H12AffineFastState.compose env11613 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound11613 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115871,272512,120014,98780,8328,64,64724,115150,17665,284041,119042,329731,257,21793,46213,63189]

theorem envBound11614 : H12AffineFastState.Bounded env11614 := by
  intro p hp
  have h : env11614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11613_11614 : H12AffineEnvironment.transform 16 82247 env11613 = env11614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env11613 == env11614) = true)

def env11615 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115871,272512,119966,98700,8328,16,64644,115102,17665,284041,119042,329731,257,21793,46213,63109]

theorem envBound11615 : H12AffineFastState.Bounded env11615 := by
  intro p hp
  have h : env11615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11614_11615 : H12AffineEnvironment.transform 5 16 env11614 = env11615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11614 == env11615) = true)

theorem identity11615 : scanCanonicalize (H12AffineFastState.compose env11615 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound11615 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env11616 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,23589,1025,32769,115871,29861,119966,98700,8328,16,64644,115102,17665,2476,119042,87078,257,21793,46213,63109]

theorem envBound11616 : H12AffineFastState.Bounded env11616 := by
  intro p hp
  have h : env11616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11615_11616 : H12AffineEnvironment.transform 17 23589 env11615 = env11616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env11615 == env11616) = true)

theorem identity11616 : scanCanonicalize (H12AffineFastState.compose env11616 (packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound11616 : packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS < 2^1333 := by decide +kernel

def env11617 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,65536,82199,23589,1025,21760,70046,29861,65951,87181,8328,16,10629,70815,17665,2476,66563,87078,257,21793,24964,9092]

theorem envBound11617 : H12AffineFastState.Bounded env11617 := by
  intro p hp
  have h : env11617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11616_11617 : H12AffineEnvironment.transform 14 21761 env11616 = env11617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env11616 == env11617) = true)

theorem identity11617 : scanCanonicalize (H12AffineFastState.compose env11617 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11617 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env11618 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21761,65536,82199,23589,1025,21760,70046,21928,65951,87181,389,16,2184,70815,17665,2476,66563,87078,257,21793,16521,649]

theorem envBound11618 : H12AffineFastState.Bounded env11618 := by
  intro p hp
  have h : env11618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11617_11618 : H12AffineEnvironment.transform 12 269 env11617 = env11618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11617 == env11618) = true)

theorem identity11618 : scanCanonicalize (H12AffineFastState.compose env11618 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound11618 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21761,21511,5392,23589,1025,21760,17817,21928,21912,138,389,16,2184,16536,17665,2476,20484,33,257,21793,16521,649]

theorem envBound11619 : H12AffineFastState.Bounded env11619 := by
  intro p hp
  have h : env11619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11618_11619 : H12AffineEnvironment.transform 15 21511 env11618 = env11619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env11618 == env11619) = true)

theorem identity11619 : scanCanonicalize (H12AffineFastState.compose env11619 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11619 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env11620 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4248,169,153,138,389,16,2184,5529,4096,2476,1285,33,257,32,5512,649]

theorem envBound11620 : H12AffineFastState.Bounded env11620 := by
  intro p hp
  have h : env11620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11619_11620 : H12AffineEnvironment.transform 13 5377 env11619 = env11620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11619 == env11620) = true)

theorem identity11620 : scanCanonicalize (H12AffineFastState.compose env11620 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound11620 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env11621 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5293,0,170,5308,2184,1025,1,4248,169,153,138,41,16,2184,5173,4096,2048,1193,33,173,32,5156,649]

theorem envBound11621 : H12AffineFastState.Bounded env11621 := by
  intro p hp
  have h : env11621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11620_11621 : H12AffineEnvironment.transform 7 172 env11620 = env11621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env11620 == env11621) = true)

theorem identity11621 : scanCanonicalize (H12AffineFastState.compose env11621 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11621 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env11622 : List Nat := [2,4,8,16,1,16,128,141,512,1024,2048,4096,128,5260,0,139,5277,2184,1025,1,4248,136,153,138,8,16,2184,5140,4096,2048,1160,0,140,1,5125,649]

theorem envBound11622 : H12AffineFastState.Bounded env11622 := by
  intro p hp
  have h : env11622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11621_11622 : H12AffineEnvironment.transform 4 1 env11621 = env11622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11621 == env11622) = true)

def env11623 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115871,272512,119967,98701,8328,17,64645,115103,17665,284041,119042,329731,257,21793,46213,63108]

theorem envBound11623 : H12AffineFastState.Bounded env11623 := by
  intro p hp
  have h : env11623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11614_11623 : H12AffineEnvironment.transform 5 17 env11614 = env11623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11614 == env11623) = true)

theorem identity11623 : scanCanonicalize (H12AffineFastState.compose env11623 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound11623 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env11624 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,97326,1025,32769,115871,87214,119967,98701,8328,17,64645,115103,17665,76199,119042,29741,257,21793,46213,63108]

theorem envBound11624 : H12AffineFastState.Bounded env11624 := by
  intro p hp
  have h : env11624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11623_11624 : H12AffineEnvironment.transform 17 97326 env11623 = env11624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env11623 == env11624) = true)

theorem identity11624 : scanCanonicalize (H12AffineFastState.compose env11624 (packedSelected [5,8,19,24,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound11624 : packedSelected [5,8,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env11625 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,30083,13461,2477,1025,32769,45340,8493,41244,62478,8328,17,64645,46108,17665,23588,42113,29741,257,21793,46213,63108]

theorem envBound11625 : H12AffineFastState.Bounded env11625 := by
  intro p hp
  have h : env11625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11624_11625 : H12AffineEnvironment.transform 15 30083 env11624 = env11625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env11624 == env11625) = true)

def env11626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169353,98780,8328,64,64725,163977,17665,284041,168005,411973,257,21793,46213,243602]

theorem envBound11626 : H12AffineFastState.Bounded env11626 := by
  intro p hp
  have h : env11626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11612_11626 : H12AffineEnvironment.transform 21 272513 env11612 = env11626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11612 == env11626) = true)

theorem identity11626 : scanCanonicalize (H12AffineFastState.compose env11626 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound11626 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,165336,272513,169353,21763,8328,64,64725,163977,17665,284041,168005,411973,257,21793,46213,156493]

theorem envBound11627 : H12AffineFastState.Bounded env11627 := by
  intro p hp
  have h : env11627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11626_11627 : H12AffineEnvironment.transform 15 54495 env11626 = env11627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env11626 == env11627) = true)

def env11628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165200,272393,169217,21763,8192,64,64605,163841,17665,283905,168005,411973,257,21793,46093,156493]

theorem envBound11628 : H12AffineFastState.Bounded env11628 := by
  intro p hp
  have h : env11628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11627_11628 : H12AffineEnvironment.transform 6 8 env11627 = env11628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11627 == env11628) = true)

theorem identity11628 : scanCanonicalize (H12AffineFastState.compose env11628 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound11628 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env11629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149861,1025,32769,165200,156012,169217,21763,8192,64,64605,163841,17665,138340,168005,32,257,21793,46093,156493]

theorem envBound11629 : H12AffineFastState.Bounded env11629 := by
  intro p hp
  have h : env11629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11628_11629 : H12AffineEnvironment.transform 17 149861 env11628 = env11629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env11628 == env11629) = true)

theorem identity11629 : scanCanonicalize (H12AffineFastState.compose env11629 (packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound11629 : packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS < 2^1333 := by decide +kernel

def env11630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49216,35109,1025,32769,17680,41260,21825,21763,8192,64,64605,16449,17665,56356,20485,32,257,21793,46093,41741]

theorem envBound11630 : H12AffineFastState.Bounded env11630 := by
  intro p hp
  have h : env11630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11629_11630 : H12AffineEnvironment.transform 16 49216 env11629 = env11630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env11629 == env11630) = true)

theorem identity11630 : scanCanonicalize (H12AffineFastState.compose env11630 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound11630 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13340,32121,1025,29789,17680,21872,21825,21763,8192,64,2049,16449,17665,10360,20485,32,257,21793,16465,22353]

theorem envBound11631 : H12AffineFastState.Bounded env11631 := by
  intro p hp
  have h : env11631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11630_11631 : H12AffineEnvironment.transform 14 29788 env11630 = env11631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env11630 == env11631) = true)

theorem identity11631 : scanCanonicalize (H12AffineFastState.compose env11631 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound11631 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8203,13340,10281,1025,8461,4160,32,17,83,8192,64,2049,5393,4177,10360,1365,32,257,113,5377,513]

theorem envBound11632 : H12AffineFastState.Bounded env11632 := by
  intro p hp
  have h : env11632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11631_11632 : H12AffineEnvironment.transform 13 5456 env11631 = env11632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env11631 == env11632) = true)

theorem identity11632 : scanCanonicalize (H12AffineFastState.compose env11632 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11632 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,263,5392,2341,1025,1,4160,32,17,83,268,64,2049,5393,4177,2420,1365,32,257,113,5377,513]

theorem envBound11633 : H12AffineFastState.Bounded env11633 := by
  intro p hp
  have h : env11633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11632_11633 : H12AffineEnvironment.transform 12 268 env11632 = env11633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11632 == env11633) = true)

theorem identity11633 : scanCanonicalize (H12AffineFastState.compose env11633 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11633 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11634 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5392,2341,1025,1,4113,32,17,2,268,17,2049,5393,4096,2341,1284,32,257,32,5377,513]

theorem envBound11634 : H12AffineFastState.Bounded env11634 := by
  intro p hp
  have h : env11634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11633_11634 : H12AffineEnvironment.transform 5 17 env11633 = env11634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11633 == env11634) = true)

theorem identity11634 : scanCanonicalize (H12AffineFastState.compose env11634 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11634 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11635 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5377,0,263,5392,2309,1025,1,4113,0,17,2,268,17,2049,5393,4096,2309,1284,0,257,0,5377,513]

theorem envBound11635 : H12AffineFastState.Bounded env11635 := by
  intro p hp
  have h : env11635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11634_11635 : H12AffineEnvironment.transform 4 0 env11634 = env11635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11634 == env11635) = true)

theorem identity11635 : scanCanonicalize (H12AffineFastState.compose env11635 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2846) := by decide +kernel

theorem selectedBound11635 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11636 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,2846,268,3615,0,263,3598,2309,1025,1,2831,0,17,2,268,17,2049,3599,2846,2309,1284,0,257,0,3615,513]

theorem envBound11636 : H12AffineFastState.Bounded env11636 := by
  intro p hp
  have h : env11636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11635_11636 : H12AffineEnvironment.transform 11 2846 env11635 = env11636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2846 env11635 == env11636) = true)

theorem identity11636 : scanCanonicalize (H12AffineFastState.compose env11636 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound11636 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11637 : List Nat := [2,4,8,16,0,17,8,256,512,1024,11,789,268,1556,0,263,1541,270,1025,1,772,0,17,2,268,17,10,1540,789,270,1284,0,257,0,1556,513]

theorem envBound11637 : H12AffineFastState.Bounded env11637 := by
  intro p hp
  have h : env11637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11636_11637 : H12AffineEnvironment.transform 10 11 env11636 = env11637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env11636 == env11637) = true)

theorem identity11637 : scanCanonicalize (H12AffineFastState.compose env11637 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11637 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11638 : List Nat := [2,4,8,10,0,11,8,256,512,1024,11,783,268,1550,0,263,1541,270,1025,1,772,0,11,2,268,11,10,1540,783,270,1284,0,257,0,1550,513]

theorem envBound11638 : H12AffineFastState.Bounded env11638 := by
  intro p hp
  have h : env11638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11637_11638 : H12AffineEnvironment.transform 3 10 env11637 = env11638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11637 == env11638) = true)

theorem identity11638 : scanCanonicalize (H12AffineFastState.compose env11638 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound11638 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11639 : List Nat := [2,4,8,10,0,11,8,256,512,256,11,783,268,782,0,263,773,270,257,1,772,0,11,2,268,11,10,772,783,270,4,0,257,0,782,513]

theorem envBound11639 : H12AffineFastState.Bounded env11639 := by
  intro p hp
  have h : env11639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11638_11639 : H12AffineEnvironment.transform 9 256 env11638 = env11639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env11638 == env11639) = true)

theorem identity11639 : scanCanonicalize (H12AffineFastState.compose env11639 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound11639 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11640 : List Nat := [2,4,8,10,0,11,8,256,260,256,11,11,268,10,0,263,1,270,257,1,0,0,11,2,268,11,10,0,11,270,4,0,257,0,10,261]

theorem envBound11640 : H12AffineFastState.Bounded env11640 := by
  intro p hp
  have h : env11640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11639_11640 : H12AffineEnvironment.transform 8 260 env11639 = env11640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env11639 == env11640) = true)

theorem identity11640 : scanCanonicalize (H12AffineFastState.compose env11640 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11641 : List Nat := [2,4,6,4,0,5,6,256,260,256,5,5,258,4,0,263,1,256,257,1,0,0,5,2,258,5,4,0,5,256,4,0,257,0,4,261]

theorem envBound11641 : H12AffineFastState.Bounded env11641 := by
  intro p hp
  have h : env11641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11640_11641 : H12AffineEnvironment.transform 2 6 env11640 = env11641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11640 == env11641) = true)

theorem identity11641 : scanCanonicalize (H12AffineFastState.compose env11641 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound11641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11642 : List Nat := [0,4,4,4,0,5,4,256,260,256,5,5,256,4,0,261,1,256,257,1,0,0,5,0,256,5,4,0,5,256,4,0,257,0,4,261]

theorem envBound11642 : H12AffineFastState.Bounded env11642 := by
  intro p hp
  have h : env11642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11641_11642 : H12AffineEnvironment.transform 0 0 env11641 = env11642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env11641 == env11642) = true)

theorem identity11642 : scanCanonicalize (H12AffineFastState.compose env11642 (packedSelected [9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11642 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env11643 : List Nat := [0,4,4,4,0,5,4,4,0,4,5,5,4,4,0,1,1,4,5,1,0,0,5,0,4,5,4,0,5,4,4,0,5,0,4,1]

theorem envBound11643 : H12AffineFastState.Bounded env11643 := by
  intro p hp
  have h : env11643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11642_11643 : H12AffineEnvironment.transform 7 4 env11642 = env11643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11642 == env11643) = true)

def env11644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165201,272392,169216,21763,8193,64,64604,163840,17665,283904,168005,411973,257,21793,46092,156493]

theorem envBound11644 : H12AffineFastState.Bounded env11644 := by
  intro p hp
  have h : env11644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11627_11644 : H12AffineEnvironment.transform 6 9 env11627 = env11644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11627 == env11644) = true)

theorem identity11644 : scanCanonicalize (H12AffineFastState.compose env11644 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound11644 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env11645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157752,1025,32769,165201,147504,169216,21763,8193,64,64604,163840,17665,146744,168005,8573,257,21793,46092,156493]

theorem envBound11645 : H12AffineFastState.Bounded env11645 := by
  intro p hp
  have h : env11645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11644_11645 : H12AffineEnvironment.transform 17 157752 env11644 = env11645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env11644 == env11645) = true)

theorem identity11645 : scanCanonicalize (H12AffineFastState.compose env11645 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound11645 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,43048,1025,32769,17729,32800,21776,21763,8193,64,64604,16400,17665,64808,20565,8573,257,21793,46092,41821]

theorem envBound11646 : H12AffineFastState.Bounded env11646 := by
  intro p hp
  have h : env11646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11645_11646 : H12AffineEnvironment.transform 16 49168 env11645 = env11646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11645 == env11646) = true)

theorem identity11646 : scanCanonicalize (H12AffineFastState.compose env11646 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound11646 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env11647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,46157,43048,1025,32769,12572,32800,8525,8542,8193,64,34817,13389,12636,35189,9224,8573,257,8572,46092,41821]

theorem envBound11647 : H12AffineFastState.Bounded env11647 := by
  intro p hp
  have h : env11647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11646_11647 : H12AffineEnvironment.transform 13 13405 env11646 = env11647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env11646 == env11647) = true)

def env11648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound11648 : H12AffineFastState.Bounded env11648 := by
  intro p hp
  have h : env11648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11303_11648 : H12AffineEnvironment.transform 26 30393345 env11303 = env11648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env11303 == env11648) = true)

def env11649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound11649 : H12AffineFastState.Bounded env11649 := by
  intro p hp
  have h : env11649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11648_11649 : H12AffineEnvironment.transform 18 1024 env11648 = env11649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11648 == env11649) = true)

theorem identity11649 : scanCanonicalize (H12AffineFastState.compose env11649 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound11649 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,152,16777216,8328,64,21479577,18973836,2119112,442520,16876680,23160257,256,18990132,18949520,16819038]

theorem envBound11650 : H12AffineFastState.Bounded env11650 := by
  intro p hp
  have h : env11650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11649_11650 : H12AffineEnvironment.transform 22 152 env11649 = env11650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env11649 == env11650) = true)

def env11651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479441,18973700,2118976,442384,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound11651 : H12AffineFastState.Bounded env11651 := by
  intro p hp
  have h : env11651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11650_11651 : H12AffineEnvironment.transform 6 8 env11650 = env11651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11650 == env11651) = true)

theorem identity11651 : scanCanonicalize (H12AffineFastState.compose env11651 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound11651 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8192,64,4677966,2172251,2118976,442384,75103,6407190,256,2188651,2196551,513]

theorem envBound11652 : H12AffineFastState.Bounded env11652 := by
  intro p hp
  have h : env11652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11651_11652 : H12AffineEnvironment.transform 23 41311 env11651 = env11652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env11651 == env11652) = true)

def env11653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8192,64,4677966,115015,45404,442384,75103,4268042,256,98679,90203,513]

theorem envBound11653 : H12AffineFastState.Bounded env11653 := by
  intro p hp
  have h : env11653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11652_11653 : H12AffineEnvironment.transform 20 58396 env11652 = env11653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env11652 == env11653) = true)

def env11654 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8192,16,4677918,114967,45324,442384,75023,4268042,256,98599,90123,513]

theorem envBound11654 : H12AffineFastState.Bounded env11654 := by
  intro p hp
  have h : env11654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11653_11654 : H12AffineEnvironment.transform 5 16 env11653 = env11654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11653 == env11654) = true)

def env11655 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8192,16,4409654,114967,45324,190520,75023,4268042,256,98599,90123,513]

theorem envBound11655 : H12AffineFastState.Bounded env11655 := by
  intro p hp
  have h : env11655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11654_11655 : H12AffineEnvironment.transform 17 10280 env11654 = env11655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11654 == env11655) = true)

theorem identity11655 : scanCanonicalize (H12AffineFastState.compose env11655 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118035) := by decide +kernel

theorem selectedBound11655 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env11656 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,118035,16,41231,8192,16,164901,114967,45324,190520,75023,60697,256,98599,90123,513]

theorem envBound11656 : H12AffineFastState.Bounded env11656 := by
  intro p hp
  have h : env11656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11655_11656 : H12AffineEnvironment.transform 21 118035 env11655 = env11656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118035 env11655 == env11656) = true)

theorem identity11656 : scanCanonicalize (H12AffineFastState.compose env11656 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound11656 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env11657 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,118035,16,41231,8192,16,123966,114967,45324,100387,75023,60697,256,98599,90123,513]

theorem envBound11657 : H12AffineFastState.Bounded env11657 := by
  intro p hp
  have h : env11657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11656_11657 : H12AffineEnvironment.transform 16 90139 env11656 = env11657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env11656 == env11657) = true)

theorem identity11657 : scanCanonicalize (H12AffineFastState.compose env11657 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11292) := by decide +kernel

theorem selectedBound11657 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env11658 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11292,65536,90139,10280,1024,11293,18432,90383,16,3347,8192,16,84002,93451,7440,74815,75023,16645,256,77115,90123,513]

theorem envBound11658 : H12AffineFastState.Bounded env11658 := by
  intro p hp
  have h : env11658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11657_11658 : H12AffineEnvironment.transform 14 11292 env11657 = env11658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11292 env11657 == env11658) = true)

theorem identity11658 : scanCanonicalize (H12AffineFastState.compose env11658 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11658 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11659 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11292,8202,16401,10280,1024,11293,18432,16645,16,3347,8192,16,26664,19713,7440,1077,1285,16645,256,3377,16385,513]

theorem envBound11659 : H12AffineFastState.Bounded env11659 := by
  intro p hp
  have h : env11659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11658_11659 : H12AffineEnvironment.transform 15 8202 env11658 = env11659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11658 == env11659) = true)

theorem identity11659 : scanCanonicalize (H12AffineFastState.compose env11659 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11659 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11660 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4113,11292,8202,4096,10280,1024,11293,6161,4372,16,3347,8192,16,14393,7440,7440,1077,1285,4372,256,3377,4112,513]

theorem envBound11660 : H12AffineFastState.Bounded env11660 := by
  intro p hp
  have h : env11660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11659_11660 : H12AffineEnvironment.transform 13 4113 env11659 = env11660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11659 == env11660) = true)

theorem identity11660 : scanCanonicalize (H12AffineFastState.compose env11660 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound11660 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11661 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5417,4113,6453,5411,4096,7425,1024,6452,6161,4372,16,3347,5417,16,3344,7440,7440,1077,1285,4372,256,3377,4112,513]

theorem envBound11661 : H12AffineFastState.Bounded env11661 := by
  intro p hp
  have h : env11661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11660_11661 : H12AffineEnvironment.transform 12 5417 env11660 = env11661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env11660 == env11661) = true)

theorem identity11661 : scanCanonicalize (H12AffineFastState.compose env11661 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound11661 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11662 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3329,2088,3344,1076,2082,3329,0,1024,1077,1296,3093,16,3347,2088,16,3344,17,17,1077,1285,3093,256,3377,3345,513]

theorem envBound11662 : H12AffineFastState.Bounded env11662 := by
  intro p hp
  have h : env11662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11661_11662 : H12AffineEnvironment.transform 11 3329 env11661 = env11662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env11661 == env11662) = true)

theorem identity11662 : scanCanonicalize (H12AffineFastState.compose env11662 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound11662 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env11663 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1589,820,1565,805,1076,1559,820,0,1024,1077,1296,544,16,806,1565,16,805,17,17,1077,1285,544,256,772,804,513]

theorem envBound11663 : H12AffineFastState.Bounded env11663 := by
  intro p hp
  have h : env11663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11662_11663 : H12AffineEnvironment.transform 10 1589 env11662 = env11663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env11662 == env11663) = true)

theorem identity11663 : scanCanonicalize (H12AffineFastState.compose env11663 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11663 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11664 : List Nat := [2,4,8,16,32,16,8,256,512,52,513,820,553,805,0,547,820,0,52,1,292,544,16,806,553,16,805,17,17,1,305,544,256,772,804,513]

theorem envBound11664 : H12AffineFastState.Bounded env11664 := by
  intro p hp
  have h : env11664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11663_11664 : H12AffineEnvironment.transform 9 52 env11663 = env11664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11663 == env11664) = true)

theorem identity11664 : scanCanonicalize (H12AffineFastState.compose env11664 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11664 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11665 : List Nat := [2,4,8,16,32,16,8,37,512,52,513,529,553,512,0,547,529,0,52,1,1,544,16,515,553,16,512,17,17,1,20,544,37,545,513,513]

theorem envBound11665 : H12AffineFastState.Bounded env11665 := by
  intro p hp
  have h : env11665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11664_11665 : H12AffineEnvironment.transform 7 37 env11664 = env11665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11664 == env11665) = true)

theorem identity11665 : scanCanonicalize (H12AffineFastState.compose env11665 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound11665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11666 : List Nat := [2,4,8,16,32,16,8,37,49,52,48,32,24,49,0,18,32,0,52,1,1,17,16,50,24,16,49,17,17,1,20,17,37,16,48,48]

theorem envBound11666 : H12AffineFastState.Bounded env11666 := by
  intro p hp
  have h : env11666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11665_11666 : H12AffineEnvironment.transform 8 49 env11665 = env11666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env11665 == env11666) = true)

theorem identity11666 : scanCanonicalize (H12AffineFastState.compose env11666 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11667 : List Nat := [2,4,8,16,17,16,8,20,0,5,1,17,24,0,0,18,17,0,5,1,1,17,16,3,24,16,0,17,17,1,20,17,20,16,1,1]

theorem envBound11667 : H12AffineFastState.Bounded env11667 := by
  intro p hp
  have h : env11667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11666_11667 : H12AffineEnvironment.transform 4 17 env11666 = env11667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11666 == env11667) = true)

def env11668 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8192,16,4409655,114967,45324,190521,75023,4268042,256,98599,90123,513]

theorem envBound11668 : H12AffineFastState.Bounded env11668 := by
  intro p hp
  have h : env11668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11654_11668 : H12AffineEnvironment.transform 17 10281 env11654 = env11668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11654 == env11668) = true)

theorem identity11668 : scanCanonicalize (H12AffineFastState.compose env11668 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound11668 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env11669 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,246070,16,41231,8192,16,34817,114967,45324,190521,75023,188732,256,98599,90123,513]

theorem envBound11669 : H12AffineFastState.Bounded env11669 := by
  intro p hp
  have h : env11669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11668_11669 : H12AffineEnvironment.transform 21 246070 env11668 = env11669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env11668 == env11669) = true)

theorem identity11669 : scanCanonicalize (H12AffineFastState.compose env11669 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound11669 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env11670 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,114967,10281,1024,32769,58396,33,16,41231,8192,16,34817,114967,45324,76078,75023,73771,256,98599,90123,513]

theorem envBound11670 : H12AffineFastState.Bounded env11670 := by
  intro p hp
  have h : env11670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11669_11670 : H12AffineEnvironment.transform 16 114967 env11669 = env11670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env11669 == env11670) = true)

theorem identity11670 : scanCanonicalize (H12AffineFastState.compose env11670 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound11670 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env11671 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,49168,10281,1024,32769,58396,33,16,41231,8192,16,34817,49168,45324,10281,9224,8492,256,32800,24844,513]

theorem envBound11671 : H12AffineFastState.Bounded env11671 := by
  intro p hp
  have h : env11671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11670_11671 : H12AffineEnvironment.transform 15 263 env11670 = env11671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env11670 == env11671) = true)

theorem identity11671 : scanCanonicalize (H12AffineFastState.compose env11671 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound11671 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11672 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,263,24860,10281,1024,8461,17680,33,16,3,8192,16,10509,24860,4096,10281,9224,8492,256,8492,24844,513]

theorem envBound11672 : H12AffineFastState.Bounded env11672 := by
  intro p hp
  have h : env11672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11671_11672 : H12AffineEnvironment.transform 14 8460 env11671 = env11672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env11671 == env11672) = true)

theorem identity11672 : scanCanonicalize (H12AffineFastState.compose env11672 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11672 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11673 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16400,2341,1024,1,17680,33,16,3,268,16,2049,16400,4096,2341,1284,32,256,32,16384,513]

theorem envBound11673 : H12AffineFastState.Bounded env11673 := by
  intro p hp
  have h : env11673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11672_11673 : H12AffineEnvironment.transform 12 268 env11672 = env11673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11672 == env11673) = true)

theorem identity11673 : scanCanonicalize (H12AffineFastState.compose env11673 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11673 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11674 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,16,268,16384,0,263,16400,2341,1024,1,17680,33,16,3,268,16,2049,16400,16,2341,1284,32,256,32,16384,513]

theorem envBound11674 : H12AffineFastState.Bounded env11674 := by
  intro p hp
  have h : env11674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11673_11674 : H12AffineEnvironment.transform 11 16 env11673 = env11674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11673 == env11674) = true)

theorem identity11674 : scanCanonicalize (H12AffineFastState.compose env11674 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11674 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11675 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,16,268,16384,0,263,16400,2341,272,1,16384,33,16,3,268,16,2049,16400,16,2341,20,32,256,32,16384,513]

theorem envBound11675 : H12AffineFastState.Bounded env11675 := by
  intro p hp
  have h : env11675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11674_11675 : H12AffineEnvironment.transform 9 272 env11674 = env11675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11674 == env11675) = true)

theorem identity11675 : scanCanonicalize (H12AffineFastState.compose env11675 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11675 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11676 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,16,268,16384,0,263,16400,292,272,1,16384,33,16,3,268,16,0,16400,16,292,20,32,256,32,16384,513]

theorem envBound11676 : H12AffineFastState.Bounded env11676 := by
  intro p hp
  have h : env11676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11675_11676 : H12AffineEnvironment.transform 10 1 env11675 = env11676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11675 == env11676) = true)

theorem identity11676 : scanCanonicalize (H12AffineFastState.compose env11676 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11676 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env11677 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,16384,0,34,16400,1,53,1,16384,33,16,3,41,16,0,16400,16,1,20,32,37,32,16384,513]

theorem envBound11677 : H12AffineFastState.Bounded env11677 := by
  intro p hp
  have h : env11677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11676_11677 : H12AffineEnvironment.transform 7 37 env11676 = env11677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11676 == env11677) = true)

def env11678 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8192,17,4677919,114966,45325,442384,75022,4268042,256,98598,90122,513]

theorem envBound11678 : H12AffineFastState.Bounded env11678 := by
  intro p hp
  have h : env11678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11653_11678 : H12AffineEnvironment.transform 5 17 env11653 = env11678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11653 == env11678) = true)

theorem identity11678 : scanCanonicalize (H12AffineFastState.compose env11678 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound11678 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env11679 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8192,17,4409654,114966,45325,190521,75022,4268042,256,98598,90122,513]

theorem envBound11679 : H12AffineFastState.Bounded env11679 := by
  intro p hp
  have h : env11679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11678_11679 : H12AffineEnvironment.transform 17 10281 env11678 = env11679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11678 == env11679) = true)

theorem identity11679 : scanCanonicalize (H12AffineFastState.compose env11679 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound11679 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env11680 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58396,4194304,16,41230,8192,17,4385085,24861,45325,190521,34053,4227073,256,8493,49153,513]

theorem envBound11680 : H12AffineFastState.Bounded env11680 := by
  intro p hp
  have h : env11680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11679_11680 : H12AffineEnvironment.transform 15 40971 env11679 = env11680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env11679 == env11680) = true)

theorem identity11680 : scanCanonicalize (H12AffineFastState.compose env11680 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound11680 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11681 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58396,147505,16,41230,8192,17,43276,24861,45325,190521,34053,180272,256,8493,49153,513]

theorem envBound11681 : H12AffineFastState.Bounded env11681 := by
  intro p hp
  have h : env11681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11680_11681 : H12AffineEnvironment.transform 21 147505 env11680 = env11681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env11680 == env11681) = true)

theorem identity11681 : scanCanonicalize (H12AffineFastState.compose env11681 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound11681 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11682 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,24861,10281,1024,32769,58396,8492,16,41230,8192,17,43276,24861,45325,35108,34053,41261,256,8493,49153,513]

theorem envBound11682 : H12AffineFastState.Bounded env11682 := by
  intro p hp
  have h : env11682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11681_11682 : H12AffineEnvironment.transform 16 24861 env11681 = env11682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env11681 == env11682) = true)

def env11683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677966,115014,45405,442384,75103,4268043,256,98678,90202,513]

theorem envBound11683 : H12AffineFastState.Bounded env11683 := by
  intro p hp
  have h : env11683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11652_11683 : H12AffineEnvironment.transform 20 58397 env11652 = env11683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env11652 == env11683) = true)

theorem identity11683 : scanCanonicalize (H12AffineFastState.compose env11683 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11683 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4604229,57677,45405,442384,1364,4194304,256,41341,16465,513]

theorem envBound11684 : H12AffineFastState.Bounded env11684 := by
  intro p hp
  have h : env11684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11683_11684 : H12AffineEnvironment.transform 15 8203 env11683 = env11684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11683 == env11684) = true)

theorem identity11684 : scanCanonicalize (H12AffineFastState.compose env11684 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound11684 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env11685 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,419913,16,41311,8192,64,10508,57677,45405,442384,1364,419913,256,41341,16465,513]

theorem envBound11685 : H12AffineFastState.Bounded env11685 := by
  intro p hp
  have h : env11685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11684_11685 : H12AffineEnvironment.transform 21 419913 env11684 = env11685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env11684 == env11685) = true)

def env11686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58397,272393,16,41311,8192,64,10508,57677,45405,294992,1364,272393,256,41341,16465,513]

theorem envBound11686 : H12AffineFastState.Bounded env11686 := by
  intro p hp
  have h : env11686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11685_11686 : H12AffineEnvironment.transform 16 16448 env11685 = env11686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env11685 == env11686) = true)

theorem identity11686 : scanCanonicalize (H12AffineFastState.compose env11686 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound11686 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,8203,16448,262144,1024,8460,17680,272393,16,82,8192,64,10508,16448,4176,270685,1364,272393,256,112,16465,513]

theorem envBound11687 : H12AffineFastState.Bounded env11687 := by
  intro p hp
  have h : env11687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11686_11687 : H12AffineEnvironment.transform 14 8461 env11686 = env11687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env11686 == env11687) = true)

theorem identity11687 : scanCanonicalize (H12AffineFastState.compose env11687 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11687 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env11688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,342,16448,262144,1024,81,17680,264532,16,82,349,64,2129,16448,4176,262144,1364,264532,256,112,16465,513]

theorem envBound11688 : H12AffineFastState.Bounded env11688 := by
  intro p hp
  have h : env11688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11687_11688 : H12AffineEnvironment.transform 12 349 env11687 = env11688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11687 == env11688) = true)

theorem identity11688 : scanCanonicalize (H12AffineFastState.compose env11688 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound11688 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,342,16448,2420,1024,81,17680,32,16,82,349,64,2129,16448,4176,2420,1364,32,256,112,16465,513]

theorem envBound11689 : H12AffineFastState.Bounded env11689 := by
  intro p hp
  have h : env11689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11688_11689 : H12AffineEnvironment.transform 17 2420 env11688 = env11689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env11688 == env11689) = true)

theorem identity11689 : scanCanonicalize (H12AffineFastState.compose env11689 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11689 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11690 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,262,16400,2340,1024,1,17680,32,16,2,269,16,2049,16400,4096,2340,1284,32,256,32,16385,513]

theorem envBound11690 : H12AffineFastState.Bounded env11690 := by
  intro p hp
  have h : env11690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11689_11690 : H12AffineEnvironment.transform 5 16 env11689 = env11690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11689 == env11690) = true)

theorem identity11690 : scanCanonicalize (H12AffineFastState.compose env11690 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11691 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,16384,0,262,16400,2308,1024,1,17680,0,16,2,269,16,2049,16400,4096,2308,1284,0,256,0,16385,513]

theorem envBound11691 : H12AffineFastState.Bounded env11691 := by
  intro p hp
  have h : env11691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11690_11691 : H12AffineEnvironment.transform 4 0 env11690 = env11691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11690 == env11691) = true)

theorem identity11691 : scanCanonicalize (H12AffineFastState.compose env11691 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound11691 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11692 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,16,269,16384,0,262,16400,2308,1024,1,17680,0,16,2,269,16,2049,16400,16,2308,1284,0,256,0,16385,513]

theorem envBound11692 : H12AffineFastState.Bounded env11692 := by
  intro p hp
  have h : env11692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11691_11692 : H12AffineEnvironment.transform 11 16 env11691 = env11692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11691 == env11692) = true)

theorem identity11692 : scanCanonicalize (H12AffineFastState.compose env11692 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1809) := by decide +kernel

theorem selectedBound11692 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11693 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,16,269,1809,0,262,1793,2308,1024,1,513,0,16,2,269,16,2049,1793,16,2308,1284,0,256,0,1808,513]

theorem envBound11693 : H12AffineFastState.Bounded env11693 := by
  intro p hp
  have h : env11693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11692_11693 : H12AffineEnvironment.transform 13 1809 env11692 = env11693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1809 env11692 == env11693) = true)

theorem identity11693 : scanCanonicalize (H12AffineFastState.compose env11693 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound11693 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11694 : List Nat := [2,4,8,16,0,16,8,256,512,1024,529,16,269,1809,0,262,1793,789,1024,1,513,0,16,2,269,16,528,1793,16,789,1284,0,256,0,1808,513]

theorem envBound11694 : H12AffineFastState.Bounded env11694 := by
  intro p hp
  have h : env11694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11693_11694 : H12AffineEnvironment.transform 10 529 env11693 = env11694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env11693 == env11694) = true)

theorem identity11694 : scanCanonicalize (H12AffineFastState.compose env11694 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound11694 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11695 : List Nat := [2,4,8,16,0,16,8,256,512,257,529,16,269,528,0,262,512,789,257,1,513,0,16,2,269,16,528,512,16,789,5,0,256,0,529,513]

theorem envBound11695 : H12AffineFastState.Bounded env11695 := by
  intro p hp
  have h : env11695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11694_11695 : H12AffineEnvironment.transform 9 257 env11694 = env11695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env11694 == env11695) = true)

theorem identity11695 : scanCanonicalize (H12AffineFastState.compose env11695 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound11695 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11696 : List Nat := [2,4,8,16,0,16,8,256,261,257,276,16,269,277,0,262,261,16,257,1,260,0,16,2,269,16,277,261,16,16,5,0,256,0,276,260]

theorem envBound11696 : H12AffineFastState.Bounded env11696 := by
  intro p hp
  have h : env11696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11695_11696 : H12AffineEnvironment.transform 8 261 env11695 = env11696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env11695 == env11696) = true)

def env11697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58397,272392,16,41311,8192,64,10508,57677,45405,294993,1364,272392,256,41341,16465,513]

theorem envBound11697 : H12AffineFastState.Bounded env11697 := by
  intro p hp
  have h : env11697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11685_11697 : H12AffineEnvironment.transform 16 16449 env11685 = env11697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env11685 == env11697) = true)

theorem identity11697 : scanCanonicalize (H12AffineFastState.compose env11697 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11697 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16449,262144,1024,0,25628,272392,16,8542,8192,64,10508,24908,12636,262224,1364,272392,256,8572,16465,513]

theorem envBound11698 : H12AffineFastState.Bounded env11698 := by
  intro p hp
  have h : env11698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11697_11698 : H12AffineEnvironment.transform 14 1 env11697 = env11698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11697 == env11698) = true)

theorem identity11698 : scanCanonicalize (H12AffineFastState.compose env11698 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound11698 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16449,10361,1024,0,25628,113,16,8542,8192,64,10508,24908,12636,10281,1364,113,256,8572,16465,513]

theorem envBound11699 : H12AffineFastState.Bounded env11699 := by
  intro p hp
  have h : env11699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11698_11699 : H12AffineEnvironment.transform 17 10361 env11698 = env11699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env11698 == env11699) = true)

theorem identity11699 : scanCanonicalize (H12AffineFastState.compose env11699 (packedSelected [11,32] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11699 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env11700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,262,16449,2420,1024,0,17681,113,16,83,269,64,2049,16449,4177,2340,1364,113,256,113,16465,513]

theorem envBound11700 : H12AffineFastState.Bounded env11700 := by
  intro p hp
  have h : env11700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11699_11700 : H12AffineEnvironment.transform 12 269 env11699 = env11700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11699 == env11700) = true)

theorem identity11700 : scanCanonicalize (H12AffineFastState.compose env11700 (packedSelected [2,3,4,5,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound11700 : packedSelected [2,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env11701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,81,1,262,16,2420,1024,0,1344,113,16,83,269,64,2049,16,4177,2340,1364,113,256,113,0,513]

theorem envBound11701 : H12AffineFastState.Bounded env11701 := by
  intro p hp
  have h : env11701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11700_11701 : H12AffineEnvironment.transform 13 81 env11700 = env11701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env11700 == env11701) = true)

theorem identity11701 : scanCanonicalize (H12AffineFastState.compose env11701 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11701 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env11702 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,1,1,262,16,2340,1024,0,1296,33,16,3,269,16,2049,16,4097,2340,1284,33,256,33,0,513]

theorem envBound11702 : H12AffineFastState.Bounded env11702 := by
  intro p hp
  have h : env11702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11701_11702 : H12AffineEnvironment.transform 5 16 env11701 = env11702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11701 == env11702) = true)

theorem identity11702 : scanCanonicalize (H12AffineFastState.compose env11702 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11703 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,4096,269,1,1,262,1,2340,1024,0,1281,33,1,3,269,1,2049,1,4097,2340,1284,33,256,33,0,513]

theorem envBound11703 : H12AffineFastState.Bounded env11703 := by
  intro p hp
  have h : env11703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11702_11703 : H12AffineEnvironment.transform 3 1 env11702 = env11703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11702 == env11703) = true)

theorem identity11703 : scanCanonicalize (H12AffineFastState.compose env11703 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound11703 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11704 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,2351,269,1,1,262,1,2340,1024,0,1281,33,1,3,269,1,2049,1,2350,2340,1284,33,256,33,0,513]

theorem envBound11704 : H12AffineFastState.Bounded env11704 := by
  intro p hp
  have h : env11704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11703_11704 : H12AffineEnvironment.transform 11 2351 env11703 = env11704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env11703 == env11704) = true)

theorem identity11704 : scanCanonicalize (H12AffineFastState.compose env11704 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11704 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11705 : List Nat := [2,4,8,1,32,1,8,4,512,1024,2048,2091,9,1,1,2,1,2080,1024,0,1029,33,1,3,9,1,2049,1,2090,2080,1024,33,4,33,0,513]

theorem envBound11705 : H12AffineFastState.Bounded env11705 := by
  intro p hp
  have h : env11705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11704_11705 : H12AffineEnvironment.transform 7 4 env11704 = env11705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11704 == env11705) = true)

theorem identity11705 : scanCanonicalize (H12AffineFastState.compose env11705 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound11705 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11706 : List Nat := [2,4,8,1,32,1,8,4,512,1024,1038,1061,9,1,1,2,1,1070,1024,0,1029,33,1,3,9,1,1039,1,1060,1070,1024,33,4,33,0,513]

theorem envBound11706 : H12AffineFastState.Bounded env11706 := by
  intro p hp
  have h : env11706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11705_11706 : H12AffineEnvironment.transform 10 1038 env11705 = env11706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env11705 == env11706) = true)

theorem identity11706 : scanCanonicalize (H12AffineFastState.compose env11706 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11706 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11707 : List Nat := [2,4,8,1,10,1,8,4,512,1024,1038,1039,9,1,1,2,1,1028,1024,0,1029,11,1,3,9,1,1039,1,1038,1028,1024,11,4,11,0,513]

theorem envBound11707 : H12AffineFastState.Bounded env11707 := by
  intro p hp
  have h : env11707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11706_11707 : H12AffineEnvironment.transform 4 10 env11706 = env11707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11706 == env11707) = true)

def env11708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,16777216,8193,64,21479440,18973701,2118977,442385,16876545,23160136,256,18990132,18949401,16819038]

theorem envBound11708 : H12AffineFastState.Bounded env11708 := by
  intro p hp
  have h : env11708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11650_11708 : H12AffineEnvironment.transform 6 9 env11650 = env11708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11650 == env11708) = true)

theorem identity11708 : scanCanonicalize (H12AffineFastState.compose env11708 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound11708 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,272426,8193,64,4450362,2468911,2118977,442385,371755,6638946,256,2485278,2428211,297844]

theorem envBound11709 : H12AffineFastState.Bounded env11709 := by
  intro p hp
  have h : env11709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11708_11709 : H12AffineEnvironment.transform 23 272426 env11708 = env11709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env11708 == env11709) = true)

theorem identity11709 : scanCanonicalize (H12AffineFastState.compose env11709 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound11709 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env11710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,272426,8193,64,4229153,2468911,2118977,368650,371755,6638946,256,2485278,2428211,297844]

theorem envBound11710 : H12AffineFastState.Bounded env11710 := by
  intro p hp
  have h : env11710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11709_11710 : H12AffineEnvironment.transform 16 90139 env11709 = env11710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env11709 == env11710) = true)

def env11711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1024,32769,2097152,4194304,17,41310,8193,64,4229153,2172251,2118977,76158,75103,6407190,256,2188650,2196551,512]

theorem envBound11711 : H12AffineFastState.Bounded env11711 := by
  intro p hp
  have h : env11711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11710_11711 : H12AffineEnvironment.transform 17 35188 env11710 = env11711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env11710 == env11711) = true)

theorem identity11711 : scanCanonicalize (H12AffineFastState.compose env11711 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound11711 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1024,32769,17461,4194304,17,41310,8193,64,4229153,90478,4468,76158,75103,4292643,256,74079,114802,512]

theorem envBound11712 : H12AffineFastState.Bounded env11712 := by
  intro p hp
  have h : env11712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11711_11712 : H12AffineEnvironment.transform 20 17461 env11711 = env11712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env11711 == env11712) = true)

theorem identity11712 : scanCanonicalize (H12AffineFastState.compose env11712 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound11712 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,65536,78959,35188,1024,32769,4161,4194304,17,41310,8193,64,4229153,79130,4468,76158,75103,4292643,256,74079,103430,512]

theorem envBound11713 : H12AffineFastState.Bounded env11713 := by
  intro p hp
  have h : env11713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11712_11713 : H12AffineEnvironment.transform 13 5236 env11712 = env11713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env11712 == env11713) = true)

theorem identity11713 : scanCanonicalize (H12AffineFastState.compose env11713 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound11713 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,65536,78959,35188,1024,32769,4161,73738,17,41310,8193,64,108587,79130,4468,76158,75103,41001,256,74079,103430,512]

theorem envBound11714 : H12AffineFastState.Bounded env11714 := by
  intro p hp
  have h : env11714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11713_11714 : H12AffineEnvironment.transform 21 73738 env11713 = env11714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env11713 == env11714) = true)

theorem identity11714 : scanCanonicalize (H12AffineFastState.compose env11714 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 33143) := by decide +kernel

theorem selectedBound11714 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env11715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,33143,46360,35188,1024,32769,4161,41341,17,41310,8193,64,10588,46189,4468,43017,42024,41001,256,41000,5489,512]

theorem envBound11715 : H12AffineFastState.Bounded env11715 := by
  intro p hp
  have h : env11715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11714_11715 : H12AffineEnvironment.transform 15 33143 env11714 = env11715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33143 env11714 == env11715) = true)

theorem identity11715 : scanCanonicalize (H12AffineFastState.compose env11715 (packedSelected [6,14,17,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11715 : packedSelected [6,14,17,18,23] rootPS < 2^1333 := by decide +kernel

def env11716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,32768,33143,38193,35188,1024,32769,4161,33108,17,33143,40,64,2421,37956,4468,34848,33793,32768,256,32769,5489,512]

theorem envBound11716 : H12AffineFastState.Bounded env11716 := by
  intro p hp
  have h : env11716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11715_11716 : H12AffineEnvironment.transform 12 41 env11715 = env11716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11715 == env11716) = true)

theorem identity11716 : scanCanonicalize (H12AffineFastState.compose env11716 (packedSelected [3,5,6,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound11716 : packedSelected [3,5,6,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env11717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,293,82,5140,2129,1024,292,4161,113,17,82,40,64,2421,5473,4468,2309,1316,293,256,292,5489,512]

theorem envBound11717 : H12AffineFastState.Bounded env11717 := by
  intro p hp
  have h : env11717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11716_11717 : H12AffineEnvironment.transform 14 293 env11716 = env11717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env11716 == env11717) = true)

theorem identity11717 : scanCanonicalize (H12AffineFastState.compose env11717 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11717 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11718 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5236,0,82,5140,2129,1024,1,4161,113,17,82,40,64,2128,5188,4177,2080,1025,0,37,1,5204,512]

theorem envBound11718 : H12AffineFastState.Bounded env11718 := by
  intro p hp
  have h : env11718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11717_11718 : H12AffineEnvironment.transform 7 37 env11717 = env11718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11717 == env11718) = true)

theorem identity11718 : scanCanonicalize (H12AffineFastState.compose env11718 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11718 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11719 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,3,5140,2048,1024,1,4112,32,17,3,40,17,2049,5141,4096,2080,1025,0,37,1,5125,512]

theorem envBound11719 : H12AffineFastState.Bounded env11719 := by
  intro p hp
  have h : env11719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11718_11719 : H12AffineEnvironment.transform 5 17 env11718 = env11719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11718 == env11719) = true)

theorem identity11719 : scanCanonicalize (H12AffineFastState.compose env11719 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound11719 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11720 : List Nat := [2,4,8,16,32,17,9,37,512,1024,522,4096,41,5157,0,3,5140,522,1024,1,4112,32,17,3,40,17,523,5141,4096,554,1025,0,37,1,5125,512]

theorem envBound11720 : H12AffineFastState.Bounded env11720 := by
  intro p hp
  have h : env11720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11719_11720 : H12AffineEnvironment.transform 10 522 env11719 = env11720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env11719 == env11720) = true)

theorem identity11720 : scanCanonicalize (H12AffineFastState.compose env11720 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11720 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11721 : List Nat := [2,4,8,16,1,17,9,4,512,1024,522,4096,8,5124,0,3,5140,522,1024,1,4112,1,17,3,9,17,523,5141,4096,523,1025,0,4,1,5125,512]

theorem envBound11721 : H12AffineFastState.Bounded env11721 := by
  intro p hp
  have h : env11721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11720_11721 : H12AffineEnvironment.transform 4 1 env11720 = env11721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11720 == env11721) = true)

def env11722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1024,32769,2097152,4194304,17,41311,8193,64,4229153,2172250,2118977,76159,75102,6407191,256,2188651,2196550,513]

theorem envBound11722 : H12AffineFastState.Bounded env11722 := by
  intro p hp
  have h : env11722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11710_11722 : H12AffineEnvironment.transform 17 35189 env11710 = env11722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env11710 == env11722) = true)

theorem identity11722 : scanCanonicalize (H12AffineFastState.compose env11722 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound11722 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30776,1024,29004,2097152,4194304,17,20498,8193,64,4225388,2172250,2118977,76159,75102,6370650,256,2188651,2192651,513]

theorem envBound11723 : H12AffineFastState.Bounded env11723 := by
  intro p hp
  have h : env11723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11722_11723 : H12AffineEnvironment.transform 14 29005 env11722 = env11723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env11722 == env11723) = true)

def env11724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30776,1024,29004,5456,4194304,17,20498,8193,64,4225388,77834,16401,76159,75102,4268042,256,94267,90203,513]

theorem envBound11724 : H12AffineFastState.Bounded env11724 := by
  intro p hp
  have h : env11724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11723_11724 : H12AffineEnvironment.transform 20 5456 env11723 = env11724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env11723 == env11724) = true)

theorem identity11724 : scanCanonicalize (H12AffineFastState.compose env11724 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound11724 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30776,1024,29004,5456,73770,17,20498,8193,64,88390,77834,16401,76159,75102,32,256,94267,90203,513]

theorem envBound11725 : H12AffineFastState.Bounded env11725 := by
  intro p hp
  have h : env11725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11724_11725 : H12AffineEnvironment.transform 21 73770 env11724 = env11725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env11724 == env11725) = true)

theorem identity11725 : scanCanonicalize (H12AffineFastState.compose env11725 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11725 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,65536,77835,10280,1024,8540,5456,73770,17,2,8193,64,67926,77834,4097,76159,75102,32,256,73771,77899,513]

theorem envBound11726 : H12AffineFastState.Bounded env11726 := by
  intro p hp
  have h : env11726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11725_11726 : H12AffineEnvironment.transform 13 4112 env11725 = env11726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env11725 == env11726) = true)

theorem identity11726 : scanCanonicalize (H12AffineFastState.compose env11726 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound11726 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,8192,3172,8541,65536,76927,10280,1024,8540,2340,73770,17,2,8193,64,67926,76926,3189,76159,75102,32,256,73771,76863,513]

theorem envBound11727 : H12AffineFastState.Bounded env11727 := by
  intro p hp
  have h : env11727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11726_11727 : H12AffineEnvironment.transform 11 3188 env11726 = env11727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env11726 == env11727) = true)

def env11728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30776,1024,29004,5457,4194304,17,20498,8193,64,4225388,77835,16400,76159,75102,4268043,256,94266,90202,513]

theorem envBound11728 : H12AffineFastState.Bounded env11728 := by
  intro p hp
  have h : env11728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11723_11728 : H12AffineEnvironment.transform 20 5457 env11723 = env11728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env11723 == env11728) = true)

theorem identity11728 : scanCanonicalize (H12AffineFastState.compose env11728 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94267) := by decide +kernel

theorem selectedBound11728 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30776,1024,29004,5457,94267,17,20498,8193,64,67927,77835,16400,76159,75102,20528,256,94266,90202,513]

theorem envBound11729 : H12AffineFastState.Bounded env11729 := by
  intro p hp
  have h : env11729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11728_11729 : H12AffineEnvironment.transform 21 94267 env11728 = env11729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94267 env11728 == env11729) = true)

theorem identity11729 : scanCanonicalize (H12AffineFastState.compose env11729 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11729 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30776,1024,29004,5457,20528,17,20498,8193,64,10588,4096,16400,2420,1365,20528,256,20529,16465,513]

theorem envBound11730 : H12AffineFastState.Bounded env11730 := by
  intro p hp
  have h : env11730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11729_11730 : H12AffineEnvironment.transform 15 8203 env11729 = env11730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11729 == env11730) = true)

theorem identity11730 : scanCanonicalize (H12AffineFastState.compose env11730 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11730 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,8203,4097,10281,1024,8541,5457,33,17,3,8193,64,10588,4096,4097,2420,1365,33,256,32,4160,513]

theorem envBound11731 : H12AffineFastState.Bounded env11731 := by
  intro p hp
  have h : env11731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11730_11731 : H12AffineEnvironment.transform 13 4113 env11730 = env11731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11730 == env11731) = true)

def env11732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound11732 : H12AffineFastState.Bounded env11732 := by
  intro p hp
  have h : env11732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11648_11732 : H12AffineEnvironment.transform 18 1025 env11648 = env11732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env11648 == env11732) = true)

theorem identity11732 : scanCanonicalize (H12AffineFastState.compose env11732 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 253977) := by decide +kernel

theorem selectedBound11732 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,253977,8328,64,12853273,2253972,10507600,8830977,8545289,6456792,257,10626228,10667281,8602590]

theorem envBound11733 : H12AffineFastState.Bounded env11733 := by
  intro p hp
  have h : env11733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11732_11733 : H12AffineEnvironment.transform 23 253977 env11732 = env11733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 253977 env11732 == env11733) = true)

def env11734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257300,253977,8328,64,6705549,2253972,140484,2404757,2102685,6456792,257,21792,46213,2175562]

theorem envBound11734 : H12AffineFastState.Bounded env11734 := by
  intro p hp
  have h : env11734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11733_11734 : H12AffineEnvironment.transform 22 2257300 env11733 = env11734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257300 env11733 == env11734) = true)

def env11735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257300,253977,8328,64,2157597,2253972,140484,2404757,2102685,2373704,257,21792,46213,2175562]

theorem envBound11735 : H12AffineFastState.Bounded env11735 := by
  intro p hp
  have h : env11735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11734_11735 : H12AffineEnvironment.transform 21 441744 env11734 = env11735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env11734 == env11735) = true)

def env11736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,253977,8328,64,64605,160980,140484,303573,1501,272392,257,21792,46213,74250]

theorem envBound11736 : H12AffineFastState.Bounded env11736 := by
  intro p hp
  have h : env11736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11735_11736 : H12AffineEnvironment.transform 20 4160 env11735 = env11736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11735 == env11736) = true)

def env11737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169400,156116,253977,8328,64,64605,160980,140484,35325,1501,32,257,21792,46213,74250]

theorem envBound11737 : H12AffineFastState.Bounded env11737 := by
  intro p hp
  have h : env11737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11736_11737 : H12AffineEnvironment.transform 17 10280 env11736 = env11737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11736 == env11737) = true)

def env11738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21928,41412,73737,8328,64,64605,46276,58580,35325,1501,32,257,21792,46213,74250]

theorem envBound11738 : H12AffineFastState.Bounded env11738 := by
  intro p hp
  have h : env11738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11737_11738 : H12AffineEnvironment.transform 16 49168 env11737 = env11738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11737 == env11738) = true)

theorem identity11738 : scanCanonicalize (H12AffineFastState.compose env11738 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound11738 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,49168,10280,1025,32769,4160,21928,41412,41430,8328,64,64605,46276,58580,35325,1501,32,257,21792,46213,41941]

theorem envBound11739 : H12AffineFastState.Bounded env11739 := by
  intro p hp
  have h : env11739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11738_11739 : H12AffineEnvironment.transform 15 33247 env11738 = env11739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env11738 == env11739) = true)

theorem identity11739 : scanCanonicalize (H12AffineFastState.compose env11739 (packedSelected [1,3,8,10,16,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 20544) := by decide +kernel

theorem selectedBound11739 : packedSelected [1,3,8,10,16,20,24] rootPS < 2^1333 := by decide +kernel

def env11740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20544,20895,4176,10280,1025,20545,4160,21928,29060,29078,8328,64,11293,25732,13460,22973,1501,32,257,21792,25797,29589]

theorem envBound11740 : H12AffineFastState.Bounded env11740 := by
  intro p hp
  have h : env11740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11739_11740 : H12AffineEnvironment.transform 14 20544 env11739 = env11740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20544 env11739 == env11740) = true)

theorem identity11740 : scanCanonicalize (H12AffineFastState.compose env11740 (packedSelected [0,1,3,4,5,7,8,10,11,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound11740 : packedSelected [0,1,3,4,5,7,8,10,11,19,22,23] rootPS < 2^1333 := by decide +kernel

def env11741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,20544,20895,4176,2265,1025,20545,4160,21928,20853,20839,121,64,3308,17525,5221,22973,1501,32,257,21792,17460,21348]

theorem envBound11741 : H12AffineFastState.Bounded env11741 := by
  intro p hp
  have h : env11741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11740_11741 : H12AffineEnvironment.transform 12 241 env11740 = env11741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env11740 == env11741) = true)

theorem identity11741 : scanCanonicalize (H12AffineFastState.compose env11741 (packedSelected [0,1,2,4,6,7,8,9,11,14,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound11741 : packedSelected [0,1,2,4,6,7,8,9,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env11742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5156,1124,1467,4176,2265,1025,1125,4160,396,1361,1347,121,64,3308,4177,5221,3481,1501,32,257,260,4112,1856]

theorem envBound11742 : H12AffineFastState.Bounded env11742 := by
  intro p hp
  have h : env11742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11741_11742 : H12AffineEnvironment.transform 13 5156 env11741 = env11742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env11741 == env11742) = true)

theorem identity11742 : scanCanonicalize (H12AffineFastState.compose env11742 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound11742 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env11743 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,241,4248,216,263,4176,2265,189,217,4160,396,493,511,121,64,2128,4177,4313,2341,353,32,257,260,4112,1020]

theorem envBound11743 : H12AffineFastState.Bounded env11743 := by
  intro p hp
  have h : env11743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11742_11743 : H12AffineEnvironment.transform 9 188 env11742 = env11743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env11742 == env11743) = true)

theorem identity11743 : scanCanonicalize (H12AffineFastState.compose env11743 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11743 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env11744 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,160,4248,137,263,4097,2184,189,136,4113,396,444,430,40,17,2049,4096,4232,2341,304,32,257,260,4112,941]

theorem envBound11744 : H12AffineFastState.Bounded env11744 := by
  intro p hp
  have h : env11744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11743_11744 : H12AffineEnvironment.transform 5 17 env11743 = env11744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11743 == env11744) = true)

theorem identity11744 : scanCanonicalize (H12AffineFastState.compose env11744 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11744 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11745 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,4096,160,4248,137,34,4097,2184,189,136,4113,169,153,139,40,17,2049,4096,4232,2048,21,32,36,33,4112,648]

theorem envBound11745 : H12AffineFastState.Bounded env11745 := by
  intro p hp
  have h : env11745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11744_11745 : H12AffineEnvironment.transform 7 37 env11744 = env11745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11744 == env11745) = true)

theorem identity11745 : scanCanonicalize (H12AffineFastState.compose env11745 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound11745 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11746 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,2233,160,2081,137,34,2232,2184,189,136,2216,169,153,139,40,17,2049,2233,2097,2048,21,32,36,33,2217,648]

theorem envBound11746 : H12AffineFastState.Bounded env11746 := by
  intro p hp
  have h : env11746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11745_11746 : H12AffineEnvironment.transform 11 2233 env11745 = env11746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env11745 == env11746) = true)

theorem identity11746 : scanCanonicalize (H12AffineFastState.compose env11746 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11746 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env11747 : List Nat := [2,4,8,16,32,17,128,37,512,188,1,184,160,32,137,34,185,137,189,136,169,169,153,139,40,17,0,184,48,1,21,32,36,33,168,648]

theorem envBound11747 : H12AffineFastState.Bounded env11747 := by
  intro p hp
  have h : env11747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11746_11747 : H12AffineEnvironment.transform 10 1 env11746 = env11747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11746 == env11747) = true)

theorem identity11747 : scanCanonicalize (H12AffineFastState.compose env11747 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound11747 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env11748 : List Nat := [2,4,8,16,32,17,41,37,512,21,1,17,9,32,32,34,16,32,20,33,0,0,48,34,40,17,0,17,48,1,21,32,36,33,1,545]

theorem envBound11748 : H12AffineFastState.Bounded env11748 := by
  intro p hp
  have h : env11748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11747_11748 : H12AffineEnvironment.transform 6 41 env11747 = env11748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env11747 == env11748) = true)

theorem identity11748 : scanCanonicalize (H12AffineFastState.compose env11748 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11748 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env11749 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,1,1,3,16,1,20,0,0,0,17,3,9,17,0,17,17,1,21,1,5,0,1,512]

theorem envBound11749 : H12AffineFastState.Bounded env11749 := by
  intro p hp
  have h : env11749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11748_11749 : H12AffineEnvironment.transform 4 1 env11748 = env11749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11748 == env11749) = true)

theorem identity11749 : scanCanonicalize (H12AffineFastState.compose env11749 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound11749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11750 : List Nat := [2,4,8,16,1,17,8,4,4,21,1,17,9,1,1,3,16,1,20,0,0,0,17,3,9,17,0,17,17,1,21,1,5,0,1,4]

theorem envBound11750 : H12AffineFastState.Bounded env11750 := by
  intro p hp
  have h : env11750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11749_11750 : H12AffineEnvironment.transform 8 4 env11749 = env11750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env11749 == env11750) = true)

theorem identity11750 : scanCanonicalize (H12AffineFastState.compose env11750 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound11750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11751 : List Nat := [2,4,8,6,1,7,8,4,4,3,1,7,9,1,1,3,6,1,2,0,0,0,7,3,9,7,0,7,7,1,3,1,5,0,1,4]

theorem envBound11751 : H12AffineFastState.Bounded env11751 := by
  intro p hp
  have h : env11751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11750_11751 : H12AffineEnvironment.transform 3 6 env11750 = env11751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env11750 == env11751) = true)

def env11752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21929,41413,73736,8328,64,64605,46277,58581,35325,1501,32,257,21792,46213,74250]

theorem envBound11752 : H12AffineFastState.Bounded env11752 := by
  intro p hp
  have h : env11752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11737_11752 : H12AffineEnvironment.transform 16 49169 env11737 = env11752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env11737 == env11752) = true)

theorem identity11752 : scanCanonicalize (H12AffineFastState.compose env11752 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound11752 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,49169,10280,1025,32769,4160,21929,41413,41311,8328,64,64605,46277,58581,35325,1501,32,257,21792,46213,41821]

theorem envBound11753 : H12AffineFastState.Bounded env11753 := by
  intro p hp
  have h : env11753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11752_11753 : H12AffineEnvironment.transform 15 33111 env11752 = env11753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env11752 == env11753) = true)

theorem identity11753 : scanCanonicalize (H12AffineFastState.compose env11753 (packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11753 : packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env11754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,16384,32768,33111,49169,2049,1025,32769,4160,21929,33260,33142,161,64,56436,38124,50428,35325,1501,32,257,21792,38060,33652]

theorem envBound11754 : H12AffineFastState.Bounded env11754 := by
  intro p hp
  have h : env11754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11753_11754 : H12AffineEnvironment.transform 12 41 env11753 = env11754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11753 == env11754) = true)

theorem identity11754 : scanCanonicalize (H12AffineFastState.compose env11754 (packedSelected [0,1,5,7,8,9,14,16,18,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound11754 : packedSelected [0,1,5,7,8,9,14,16,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env11755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5373,32768,33111,38124,2049,1025,32769,4160,340,33260,33142,161,64,34953,38124,36865,35325,1501,32,257,477,38060,33652]

theorem envBound11755 : H12AffineFastState.Bounded env11755 := by
  intro p hp
  have h : env11755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11754_11755 : H12AffineEnvironment.transform 13 5373 env11754 = env11755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env11754 == env11755) = true)

theorem identity11755 : scanCanonicalize (H12AffineFastState.compose env11755 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound11755 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env11756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5373,372,35,5528,2049,1025,373,4160,340,152,2,161,64,2557,5528,4469,2185,1501,32,257,477,5592,512]

theorem envBound11756 : H12AffineFastState.Bounded env11756 := by
  intro p hp
  have h : env11756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11755_11756 : H12AffineEnvironment.transform 14 372 env11755 = env11756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env11755 == env11756) = true)

theorem identity11756 : scanCanonicalize (H12AffineFastState.compose env11756 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11756 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11757 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,41,4589,372,35,4232,2049,273,373,4160,340,152,2,161,64,2557,4232,4469,2185,205,32,257,477,4296,512]

theorem envBound11757 : H12AffineFastState.Bounded env11757 := by
  intro p hp
  have h : env11757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11756_11757 : H12AffineEnvironment.transform 9 272 env11756 = env11757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11756 == env11757) = true)

theorem identity11757 : scanCanonicalize (H12AffineFastState.compose env11757 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound11757 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11758 : List Nat := [2,4,8,16,32,64,128,220,512,204,2048,4096,41,4145,168,35,4232,2049,205,169,4160,136,152,2,161,64,2081,4232,4265,2185,205,32,221,1,4296,512]

theorem envBound11758 : H12AffineFastState.Bounded env11758 := by
  intro p hp
  have h : env11758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11757_11758 : H12AffineEnvironment.transform 7 220 env11757 = env11758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env11757 == env11758) = true)

theorem identity11758 : scanCanonicalize (H12AffineFastState.compose env11758 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound11758 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env11759 : List Nat := [2,4,8,16,32,49,128,173,512,189,2048,4096,41,4145,168,35,4232,2049,188,169,4145,136,152,2,161,49,2081,4232,4265,2185,188,32,172,1,4281,512]

theorem envBound11759 : H12AffineFastState.Bounded env11759 := by
  intro p hp
  have h : env11759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11758_11759 : H12AffineEnvironment.transform 5 49 env11758 = env11759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env11758 == env11759) = true)

theorem identity11759 : scanCanonicalize (H12AffineFastState.compose env11759 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound11759 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11760 : List Nat := [2,4,8,16,32,49,41,4,512,20,2048,4096,41,4145,1,35,4129,2049,21,0,4145,33,49,2,8,49,2081,4129,4096,2080,21,32,5,1,4112,512]

theorem envBound11760 : H12AffineFastState.Bounded env11760 := by
  intro p hp
  have h : env11760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11759_11760 : H12AffineEnvironment.transform 6 41 env11759 = env11760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env11759 == env11760) = true)

theorem identity11760 : scanCanonicalize (H12AffineFastState.compose env11760 (packedSelected [0,3] rootPS)) = affineNative (2^(11+1) ^^^ 30) := by decide +kernel

theorem selectedBound11760 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env11761 : List Nat := [2,4,8,16,32,49,41,4,512,20,2048,30,41,47,1,35,63,2049,21,0,47,33,49,2,8,49,2081,63,30,2080,21,32,5,1,14,512]

theorem envBound11761 : H12AffineFastState.Bounded env11761 := by
  intro p hp
  have h : env11761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11760_11761 : H12AffineEnvironment.transform 11 30 env11760 = env11761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 30 env11760 == env11761) = true)

theorem identity11761 : scanCanonicalize (H12AffineFastState.compose env11761 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 46) := by decide +kernel

theorem selectedBound11761 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env11762 : List Nat := [2,4,8,16,32,49,41,4,512,20,46,30,41,47,1,35,63,47,21,0,47,33,49,2,8,49,15,63,30,14,21,32,5,1,14,512]

theorem envBound11762 : H12AffineFastState.Bounded env11762 := by
  intro p hp
  have h : env11762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11761_11762 : H12AffineEnvironment.transform 10 46 env11761 = env11762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 46 env11761 == env11762) = true)

theorem identity11762 : scanCanonicalize (H12AffineFastState.compose env11762 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound11762 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env11763 : List Nat := [2,4,8,16,15,30,6,4,512,20,1,30,6,0,1,12,16,0,21,0,0,14,30,2,8,30,15,16,30,14,21,15,5,1,14,512]

theorem envBound11763 : H12AffineFastState.Bounded env11763 := by
  intro p hp
  have h : env11763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11762_11763 : H12AffineEnvironment.transform 4 15 env11762 = env11763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env11762 == env11763) = true)

end H12CloudChart1