import H12CloudChart1Data098

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity25075 : scanCanonicalize (H12AffineFastState.compose env25075 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3637) := by decide +kernel

theorem selectedBound25075 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env25076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3637,349,2917,80,342,2932,2420,1024,81,3701,32,16,83,348,64,2049,2852,3685,2341,1365,33,256,113,2869,513]

theorem envBound25076 : H12AffineFastState.Bounded env25076 := by
  intro p hp
  have h : env25076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25075_25076 : H12AffineEnvironment.transform 11 3637 env25075 = env25076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3637 env25075 == env25076) = true)

theorem identity25076 : scanCanonicalize (H12AffineFastState.compose env25076 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound25076 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env25077 : List Nat := [2,4,8,16,32,64,9,256,373,1024,2048,3392,349,2064,80,342,2049,2420,1024,81,3328,32,16,83,348,64,2049,2129,3344,2341,1365,33,256,113,2112,372]

theorem envBound25077 : H12AffineFastState.Bounded env25077 := by
  intro p hp
  have h : env25077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25076_25077 : H12AffineEnvironment.transform 8 373 env25076 = env25077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env25076 == env25077) = true)

theorem identity25077 : scanCanonicalize (H12AffineFastState.compose env25077 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound25077 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env25078 : List Nat := [2,4,8,16,32,64,9,53,64,1024,2048,3189,104,2064,80,99,2049,2113,1024,81,3125,32,16,83,105,64,2049,2129,3109,2064,1120,33,53,113,2112,65]

theorem envBound25078 : H12AffineFastState.Bounded env25078 := by
  intro p hp
  have h : env25078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25077_25078 : H12AffineEnvironment.transform 7 53 env25077 = env25078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env25077 == env25078) = true)

theorem identity25078 : scanCanonicalize (H12AffineFastState.compose env25078 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound25078 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env25079 : List Nat := [2,4,8,16,32,64,9,53,64,36,2048,2129,104,2064,80,99,2049,2113,36,81,2065,32,16,83,105,64,2049,2129,2049,2064,68,33,53,113,2112,65]

theorem envBound25079 : H12AffineFastState.Bounded env25079 := by
  intro p hp
  have h : env25079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25078_25079 : H12AffineEnvironment.transform 9 36 env25078 = env25079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env25078 == env25079) = true)

theorem identity25079 : scanCanonicalize (H12AffineFastState.compose env25079 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound25079 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25080 : List Nat := [2,4,8,16,32,64,9,53,64,36,17,64,104,1,80,99,16,80,36,81,0,32,16,83,105,64,16,64,16,1,68,33,53,113,81,65]

theorem envBound25080 : H12AffineFastState.Bounded env25080 := by
  intro p hp
  have h : env25080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25079_25080 : H12AffineEnvironment.transform 10 17 env25079 = env25080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env25079 == env25080) = true)

theorem identity25080 : scanCanonicalize (H12AffineFastState.compose env25080 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25080 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25081 : List Nat := [2,4,8,16,32,16,9,53,16,36,17,16,56,1,0,51,16,0,36,1,0,32,16,3,57,16,16,16,16,1,20,33,53,33,1,17]

theorem envBound25081 : H12AffineFastState.Bounded env25081 := by
  intro p hp
  have h : env25081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25080_25081 : H12AffineEnvironment.transform 5 16 env25080 = env25081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25080 == env25081) = true)

theorem identity25081 : scanCanonicalize (H12AffineFastState.compose env25081 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25082 : List Nat := [2,4,8,16,17,16,9,4,16,21,17,16,9,1,0,2,16,0,21,1,0,17,16,3,8,16,16,16,16,1,20,16,4,16,1,17]

theorem envBound25082 : H12AffineFastState.Bounded env25082 := by
  intro p hp
  have h : env25082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25081_25082 : H12AffineEnvironment.transform 4 17 env25081 = env25082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25081 == env25082) = true)

def env25083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,8388608,95496,8328,64,8560008,79130,8491471,8830976,8450328,392406,256,8484154,8492191,8509134]

theorem envBound25083 : H12AffineFastState.Bounded env25083 := by
  intro p hp
  have h : env25083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25027_25083 : H12AffineEnvironment.transform 21 272513 env25027 = env25083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25027 == env25083) = true)

theorem identity25083 : scanCanonicalize (H12AffineFastState.compose env25083 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound25083 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,272513,8388608,41431,8328,64,8560008,57797,8406288,8830976,8450328,272393,256,8430053,8405056,8389137]

theorem envBound25084 : H12AffineFastState.Bounded env25084 := by
  intro p hp
  have h : env25084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25083_25084 : H12AffineEnvironment.transform 15 54495 env25083 = env25084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env25083 == env25084) = true)

def env25085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,272393,8388608,41311,8192,64,8559872,57677,8406288,8830976,8450328,272393,256,8429933,8405056,8389137]

theorem envBound25085 : H12AffineFastState.Bounded env25085 := by
  intro p hp
  have h : env25085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25084_25085 : H12AffineEnvironment.transform 6 8 env25084 = env25085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25084 == env25085) = true)

def env25086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,272393,16,41311,8192,64,171280,57677,17664,442384,61704,272393,256,41341,16464,513]

theorem envBound25086 : H12AffineFastState.Bounded env25086 := by
  intro p hp
  have h : env25086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25085_25086 : H12AffineEnvironment.transform 22 16 env25085 = env25086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25085 == env25086) = true)

theorem identity25086 : scanCanonicalize (H12AffineFastState.compose env25086 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25086 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,131072,262144,1024,8540,4160,272393,16,2,8192,64,146509,16400,17664,418125,20565,272393,256,32,16464,513]

theorem envBound25087 : H12AffineFastState.Bounded env25087 := by
  intro p hp
  have h : env25087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25086_25087 : H12AffineEnvironment.transform 14 8541 env25086 = env25087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25086 == env25087) = true)

theorem identity25087 : scanCanonicalize (H12AffineFastState.compose env25087 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25087 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25088 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,131072,262144,272,8540,4160,272393,16,2,8192,64,145757,16400,16400,418125,20565,272393,256,32,16464,513]

theorem envBound25088 : H12AffineFastState.Bounded env25088 := by
  intro p hp
  have h : env25088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25087_25088 : H12AffineEnvironment.transform 9 272 env25087 = env25088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25087 == env25088) = true)

theorem identity25088 : scanCanonicalize (H12AffineFastState.compose env25088 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound25088 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env25089 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,4096,262144,272,8540,4160,272393,16,2,8192,64,10589,16400,16400,291149,20565,272393,256,32,16464,513]

theorem envBound25089 : H12AffineFastState.Bounded env25089 := by
  intro p hp
  have h : env25089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25088_25089 : H12AffineEnvironment.transform 16 4096 env25088 = env25089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env25088 == env25089) = true)

theorem identity25089 : scanCanonicalize (H12AffineFastState.compose env25089 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound25089 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env25090 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,4096,30777,272,8540,4160,20528,16,2,8192,64,10589,16400,16400,2420,20565,20528,256,32,16464,513]

theorem envBound25090 : H12AffineFastState.Bounded env25090 := by
  intro p hp
  have h : env25090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25089_25090 : H12AffineEnvironment.transform 17 30777 env25089 = env25090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env25089 == env25090) = true)

theorem identity25090 : scanCanonicalize (H12AffineFastState.compose env25090 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25090 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env25091 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,16384,372,20531,4096,22544,272,373,4160,20528,16,2,41,64,2420,16400,16400,2420,20565,20528,256,32,16464,513]

theorem envBound25091 : H12AffineFastState.Bounded env25091 := by
  intro p hp
  have h : env25091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25090_25091 : H12AffineEnvironment.transform 12 41 env25090 = env25091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25090 == env25091) = true)

theorem identity25091 : scanCanonicalize (H12AffineFastState.compose env25091 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound25091 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env25092 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,2048,372,6195,4096,4112,272,373,4160,6192,16,2,41,64,2420,2064,2064,2420,6229,6192,256,32,2128,513]

theorem envBound25092 : H12AffineFastState.Bounded env25092 := by
  intro p hp
  have h : env25092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25091_25092 : H12AffineEnvironment.transform 13 2048 env25091 = env25092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env25091 == env25092) = true)

theorem identity25092 : scanCanonicalize (H12AffineFastState.compose env25092 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound25092 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env25093 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,41,2048,372,343,2404,2420,272,373,2340,340,16,2,41,64,2420,2064,2064,2420,305,340,256,32,2128,513]

theorem envBound25093 : H12AffineFastState.Bounded env25093 := by
  intro p hp
  have h : env25093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25092_25093 : H12AffineEnvironment.transform 11 2404 env25092 = env25093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env25092 == env25093) = true)

theorem identity25093 : scanCanonicalize (H12AffineFastState.compose env25093 (packedSelected [1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound25093 : packedSelected [1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env25094 : List Nat := [2,4,8,16,32,64,8,256,512,272,32,324,41,32,372,343,324,340,272,373,260,340,16,2,41,64,340,48,48,340,305,340,256,32,112,513]

theorem envBound25094 : H12AffineFastState.Bounded env25094 := by
  intro p hp
  have h : env25094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25093_25094 : H12AffineEnvironment.transform 10 32 env25093 = env25094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env25093 == env25094) = true)

theorem identity25094 : scanCanonicalize (H12AffineFastState.compose env25094 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25094 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env25095 : List Nat := [2,4,8,16,32,1,8,256,512,272,32,261,41,32,309,278,261,277,272,308,260,277,16,2,41,1,277,48,48,277,305,277,256,32,49,513]

theorem envBound25095 : H12AffineFastState.Bounded env25095 := by
  intro p hp
  have h : env25095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25094_25095 : H12AffineEnvironment.transform 5 1 env25094 = env25095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25094 == env25095) = true)

theorem identity25095 : scanCanonicalize (H12AffineFastState.compose env25095 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25095 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25096 : List Nat := [2,4,8,0,32,1,8,256,512,256,32,261,41,32,293,262,261,261,256,292,260,261,0,2,41,1,261,32,32,261,289,261,256,32,33,513]

theorem envBound25096 : H12AffineFastState.Bounded env25096 := by
  intro p hp
  have h : env25096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25095_25096 : H12AffineEnvironment.transform 3 0 env25095 = env25096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25095 == env25096) = true)

theorem identity25096 : scanCanonicalize (H12AffineFastState.compose env25096 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25096 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25097 : List Nat := [2,4,8,0,32,1,8,4,512,4,32,1,41,32,33,2,1,1,4,32,0,1,0,2,41,1,1,32,32,1,37,1,4,32,33,513]

theorem envBound25097 : H12AffineFastState.Bounded env25097 := by
  intro p hp
  have h : env25097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25096_25097 : H12AffineEnvironment.transform 7 4 env25096 = env25097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25096 == env25097) = true)

theorem identity25097 : scanCanonicalize (H12AffineFastState.compose env25097 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25098 : List Nat := [2,4,8,0,0,1,8,4,512,4,0,1,9,0,1,2,1,1,4,0,0,1,0,2,9,1,1,0,0,1,5,1,4,0,1,513]

theorem envBound25098 : H12AffineFastState.Bounded env25098 := by
  intro p hp
  have h : env25098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25097_25098 : H12AffineEnvironment.transform 4 0 env25097 = env25098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25097 == env25098) = true)

theorem identity25098 : scanCanonicalize (H12AffineFastState.compose env25098 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25098 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25099 : List Nat := [2,4,8,0,0,1,8,4,0,4,0,1,9,0,1,2,1,1,4,0,0,1,0,2,9,1,1,0,0,1,5,1,4,0,1,1]

theorem envBound25099 : H12AffineFastState.Bounded env25099 := by
  intro p hp
  have h : env25099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25098_25099 : H12AffineEnvironment.transform 8 0 env25098 = env25099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25098 == env25099) = true)

def env25100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,272393,17,41311,8192,64,171281,57677,17665,442385,61705,272393,256,41340,16465,512]

theorem envBound25100 : H12AffineFastState.Bounded env25100 := by
  intro p hp
  have h : env25100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25085_25100 : H12AffineEnvironment.transform 22 17 env25085 = env25100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25085 == env25100) = true)

theorem identity25100 : scanCanonicalize (H12AffineFastState.compose env25100 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound25100 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56577,1024,32769,4160,62728,17,41311,8192,64,171281,57677,17665,138512,61705,62728,256,41340,16465,512]

theorem envBound25101 : H12AffineFastState.Bounded env25101 := by
  intro p hp
  have h : env25101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25100_25101 : H12AffineEnvironment.transform 17 56577 env25100 = env25101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env25100 == env25101) = true)

theorem identity25101 : scanCanonicalize (H12AffineFastState.compose env25101 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound25101 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32802,131072,35188,1024,32769,4160,41341,17,41311,8192,64,171281,46392,4468,138512,42364,41341,256,41340,5156,512]

theorem envBound25102 : H12AffineFastState.Bounded env25102 := by
  intro p hp
  have h : env25102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25101_25102 : H12AffineEnvironment.transform 13 5237 env25101 = env25102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env25101 == env25102) = true)

theorem identity25102 : scanCanonicalize (H12AffineFastState.compose env25102 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 46361) := by decide +kernel

theorem selectedBound25102 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env25103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32802,46361,35188,1024,32769,4160,41341,17,41311,8192,64,10248,46392,4468,43017,42364,41341,256,41340,5156,512]

theorem envBound25103 : H12AffineFastState.Bounded env25103 := by
  intro p hp
  have h : env25103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25102_25103 : H12AffineEnvironment.transform 16 46361 env25102 = env25103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46361 env25102 == env25103) = true)

theorem identity25103 : scanCanonicalize (H12AffineFastState.compose env25103 (packedSelected [6,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound25103 : packedSelected [6,14,18,23] rootPS < 2^1333 := by decide +kernel

def env25104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,340,374,13389,2080,1024,341,4160,8233,17,8203,8192,64,10248,13420,4468,10589,9256,8233,256,8232,5156,512]

theorem envBound25104 : H12AffineFastState.Bounded env25104 := by
  intro p hp
  have h : env25104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25103_25104 : H12AffineEnvironment.transform 14 340 env25103 = env25104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env25103 == env25104) = true)

theorem identity25104 : scanCanonicalize (H12AffineFastState.compose env25104 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25104 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env25105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,340,374,5440,2080,1024,341,4160,292,17,262,269,64,2309,5473,4468,2128,1317,292,256,293,5156,512]

theorem envBound25105 : H12AffineFastState.Bounded env25105 := by
  intro p hp
  have h : env25105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25104_25105 : H12AffineEnvironment.transform 12 269 env25104 = env25105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25104 == env25105) = true)

theorem identity25105 : scanCanonicalize (H12AffineFastState.compose env25105 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25105 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env25106 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5237,33,3,5173,2080,1024,32,4160,81,17,115,120,64,2160,5140,4097,2128,1104,81,117,80,5156,512]

theorem envBound25106 : H12AffineFastState.Bounded env25106 := by
  intro p hp
  have h : env25106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25105_25106 : H12AffineEnvironment.transform 7 117 env25105 = env25106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25105 == env25106) = true)

theorem identity25106 : scanCanonicalize (H12AffineFastState.compose env25106 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25106 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25107 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,89,5204,0,3,5140,2049,1024,1,4160,81,17,82,89,64,2129,5140,4097,2128,1104,81,84,80,5125,512]

theorem envBound25107 : H12AffineFastState.Bounded env25107 := by
  intro p hp
  have h : env25107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25106_25107 : H12AffineEnvironment.transform 4 1 env25106 = env25107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25106 == env25107) = true)

theorem identity25107 : scanCanonicalize (H12AffineFastState.compose env25107 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25107 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25108 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,5124,0,3,5140,2049,1024,1,4112,1,17,2,9,16,2049,5140,4097,2048,1024,1,4,0,5125,512]

theorem envBound25108 : H12AffineFastState.Bounded env25108 := by
  intro p hp
  have h : env25108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25107_25108 : H12AffineEnvironment.transform 5 16 env25107 = env25108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25107 == env25108) = true)

def env25109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,272392,8388608,41310,8193,64,8559873,57676,8406288,8830976,8450328,272393,256,8429932,8405056,8389137]

theorem envBound25109 : H12AffineFastState.Bounded env25109 := by
  intro p hp
  have h : env25109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25084_25109 : H12AffineEnvironment.transform 6 9 env25084 = env25109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25084 == env25109) = true)

def env25110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,272392,16,41310,8193,64,171281,57676,17664,442384,61704,272393,256,41340,16464,513]

theorem envBound25110 : H12AffineFastState.Bounded env25110 := by
  intro p hp
  have h : env25110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25109_25110 : H12AffineEnvironment.transform 22 16 env25109 = env25110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25109 == env25110) = true)

def env25111 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,272392,16,41230,8193,16,171281,57628,17664,442384,61704,272393,256,41260,16384,513]

theorem envBound25111 : H12AffineFastState.Bounded env25111 := by
  intro p hp
  have h : env25111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25110_25111 : H12AffineEnvironment.transform 5 16 env25110 = env25111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25110 == env25111) = true)

theorem identity25111 : scanCanonicalize (H12AffineFastState.compose env25111 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound25111 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env25112 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,262144,1024,29709,4112,272392,16,21762,8193,16,157981,5392,17664,406556,1284,272393,256,21792,16384,513]

theorem envBound25112 : H12AffineFastState.Bounded env25112 := by
  intro p hp
  have h : env25112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25111_25112 : H12AffineEnvironment.transform 14 29708 env25111 = env25112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env25111 == env25112) = true)

theorem identity25112 : scanCanonicalize (H12AffineFastState.compose env25112 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound25112 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25113 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,138292,1024,29709,4112,144444,16,21762,8193,16,157981,5392,17664,10280,1284,144445,256,21792,16384,513]

theorem envBound25113 : H12AffineFastState.Bounded env25113 := by
  intro p hp
  have h : env25113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25112_25113 : H12AffineEnvironment.transform 17 138292 env25112 = env25113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env25112 == env25113) = true)

theorem identity25113 : scanCanonicalize (H12AffineFastState.compose env25113 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound25113 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env25114 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,16400,23588,1024,29709,4112,29740,16,21762,8193,16,10509,5392,17664,10280,1284,29741,256,21792,16384,513]

theorem envBound25114 : H12AffineFastState.Bounded env25114 := by
  intro p hp
  have h : env25114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25113_25114 : H12AffineEnvironment.transform 16 16400 env25113 = env25114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25113 == env25114) = true)

theorem identity25114 : scanCanonicalize (H12AffineFastState.compose env25114 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound25114 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env25115 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,16384,20496,1046,16400,23588,1024,20497,4112,20528,16,21762,1053,16,3345,5392,17664,3124,1284,20529,256,21792,16384,513]

theorem envBound25115 : H12AffineFastState.Bounded env25115 := by
  intro p hp
  have h : env25115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25114_25115 : H12AffineEnvironment.transform 12 1052 env25114 = env25115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env25114 == env25115) = true)

theorem identity25115 : scanCanonicalize (H12AffineFastState.compose env25115 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound25115 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25116 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,5156,1076,1046,5172,2048,1024,1077,4112,1044,16,294,1053,16,3345,5392,4388,3124,1284,1045,256,260,5156,513]

theorem envBound25116 : H12AffineFastState.Bounded env25116 := by
  intro p hp
  have h : env25116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25115_25116 : H12AffineEnvironment.transform 13 5156 env25115 = env25116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env25115 == env25116) = true)

theorem identity25116 : scanCanonicalize (H12AffineFastState.compose env25116 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25116 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25117 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,40,4112,0,34,4096,2048,52,1,4112,32,16,294,41,16,2341,4388,4388,2048,304,33,256,260,4112,513]

theorem envBound25117 : H12AffineFastState.Bounded env25117 := by
  intro p hp
  have h : env25117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25116_25117 : H12AffineEnvironment.transform 9 52 env25116 = env25117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25116 == env25117) = true)

theorem identity25117 : scanCanonicalize (H12AffineFastState.compose env25117 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25117 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25118 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,40,4112,0,34,4096,2048,52,1,4112,32,16,2,41,16,2049,4096,4096,2048,20,33,36,32,4112,513]

theorem envBound25118 : H12AffineFastState.Bounded env25118 := by
  intro p hp
  have h : env25118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25117_25118 : H12AffineEnvironment.transform 7 36 env25117 = env25118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25117 == env25118) = true)

theorem identity25118 : scanCanonicalize (H12AffineFastState.compose env25118 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound25118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25119 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2096,40,2080,0,34,2096,2048,52,1,2080,32,16,2,41,16,2049,2096,2096,2048,20,33,36,32,2080,513]

theorem envBound25119 : H12AffineFastState.Bounded env25119 := by
  intro p hp
  have h : env25119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25118_25119 : H12AffineEnvironment.transform 11 2096 env25118 = env25119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env25118 == env25119) = true)

theorem identity25119 : scanCanonicalize (H12AffineFastState.compose env25119 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound25119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25120 : List Nat := [2,4,8,16,32,16,9,36,512,52,48,0,40,16,0,34,0,48,52,1,16,32,16,2,41,16,49,0,0,48,20,33,36,32,16,513]

theorem envBound25120 : H12AffineFastState.Bounded env25120 := by
  intro p hp
  have h : env25120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25119_25120 : H12AffineEnvironment.transform 10 48 env25119 = env25120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env25119 == env25120) = true)

theorem identity25120 : scanCanonicalize (H12AffineFastState.compose env25120 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25120 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25121 : List Nat := [2,4,8,0,32,0,9,36,512,36,32,0,40,0,0,34,0,32,36,1,0,32,0,2,41,0,33,0,0,32,4,33,36,32,0,513]

theorem envBound25121 : H12AffineFastState.Bounded env25121 := by
  intro p hp
  have h : env25121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25120_25121 : H12AffineEnvironment.transform 3 0 env25120 = env25121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25120 == env25121) = true)

theorem identity25121 : scanCanonicalize (H12AffineFastState.compose env25121 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25121 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25122 : List Nat := [2,4,8,0,1,0,9,5,512,5,1,0,9,0,0,3,0,1,5,1,0,1,0,2,8,0,0,0,0,1,4,0,5,1,0,513]

theorem envBound25122 : H12AffineFastState.Bounded env25122 := by
  intro p hp
  have h : env25122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25121_25122 : H12AffineEnvironment.transform 4 1 env25121 = env25122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25121 == env25122) = true)

def env25123 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,272392,16,41231,8193,17,171281,57629,17664,442384,61704,272393,256,41261,16385,513]

theorem envBound25123 : H12AffineFastState.Bounded env25123 := by
  intro p hp
  have h : env25123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25110_25123 : H12AffineEnvironment.transform 5 17 env25110 = env25123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25110 == env25123) = true)

theorem identity25123 : scanCanonicalize (H12AffineFastState.compose env25123 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound25123 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env25124 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,179513,1024,32769,4113,169265,16,41231,8193,17,171281,57629,17664,32041,61704,169264,256,41261,16385,513]

theorem envBound25124 : H12AffineFastState.Bounded env25124 := by
  intro p hp
  have h : env25124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25123_25124 : H12AffineEnvironment.transform 17 179513 env25123 = env25124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env25123 == env25124) = true)

theorem identity25124 : scanCanonicalize (H12AffineFastState.compose env25124 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound25124 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env25125 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,38160,10281,1024,32769,4113,33,16,41231,8193,17,2049,57629,17664,32041,61704,32,256,41261,16385,513]

theorem envBound25125 : H12AffineFastState.Bounded env25125 := by
  intro p hp
  have h : env25125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25124_25125 : H12AffineEnvironment.transform 16 38160 env25124 = env25125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env25124 == env25125) = true)

theorem identity25125 : scanCanonicalize (H12AffineFastState.compose env25125 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25125 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25126 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,54279,38160,2340,1024,32769,4113,33,16,32770,268,17,2049,49168,17664,23588,53253,32,256,32800,16385,513]

theorem envBound25126 : H12AffineFastState.Bounded env25126 := by
  intro p hp
  have h : env25126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25125_25126 : H12AffineEnvironment.transform 12 269 env25125 = env25126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25125 == env25126) = true)

theorem identity25126 : scanCanonicalize (H12AffineFastState.compose env25126 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25126 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25127 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,21510,5393,2340,1024,0,4113,33,16,3,268,17,2049,16401,17664,23588,20484,32,256,33,16385,513]

theorem envBound25127 : H12AffineFastState.Bounded env25127 := by
  intro p hp
  have h : env25127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25126_25127 : H12AffineEnvironment.transform 14 1 env25126 = env25127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25126 == env25127) = true)

theorem identity25127 : scanCanonicalize (H12AffineFastState.compose env25127 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25127 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25128 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1024,0,4113,33,16,3,268,17,2049,5392,4097,2341,1285,32,256,33,5376,513]

theorem envBound25128 : H12AffineFastState.Bounded env25128 := by
  intro p hp
  have h : env25128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25127_25128 : H12AffineEnvironment.transform 13 5377 env25127 = env25128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25127 == env25128) = true)

theorem identity25128 : scanCanonicalize (H12AffineFastState.compose env25128 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25129 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1024,0,4113,33,16,3,40,17,2049,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound25129 : H12AffineFastState.Bounded env25129 := by
  intro p hp
  have h : env25129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25128_25129 : H12AffineEnvironment.transform 7 36 env25128 = env25129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25128 == env25129) = true)

theorem identity25129 : scanCanonicalize (H12AffineFastState.compose env25129 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25129 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25130 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,1,35,4096,2048,53,0,4113,33,16,3,40,17,2049,4097,4097,2049,20,32,36,33,4113,513]

theorem envBound25130 : H12AffineFastState.Bounded env25130 := by
  intro p hp
  have h : env25130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25129_25130 : H12AffineEnvironment.transform 9 53 env25129 = env25130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25129 == env25130) = true)

theorem identity25130 : scanCanonicalize (H12AffineFastState.compose env25130 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound25130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25131 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,32,41,48,1,35,32,2048,53,0,49,33,16,3,40,17,2049,33,33,2049,20,32,36,33,49,513]

theorem envBound25131 : H12AffineFastState.Bounded env25131 := by
  intro p hp
  have h : env25131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25130_25131 : H12AffineEnvironment.transform 11 32 env25130 = env25131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env25130 == env25131) = true)

theorem identity25131 : scanCanonicalize (H12AffineFastState.compose env25131 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound25131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25132 : List Nat := [2,4,8,16,32,17,9,36,512,53,33,32,41,48,1,35,32,33,53,0,49,33,16,3,40,17,32,33,33,32,20,32,36,33,49,513]

theorem envBound25132 : H12AffineFastState.Bounded env25132 := by
  intro p hp
  have h : env25132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25131_25132 : H12AffineEnvironment.transform 10 33 env25131 = env25132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env25131 == env25132) = true)

theorem identity25132 : scanCanonicalize (H12AffineFastState.compose env25132 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25132 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25133 : List Nat := [2,4,8,0,32,1,9,36,512,37,33,32,41,32,1,35,32,33,37,0,33,33,0,3,40,1,32,33,33,32,4,32,36,33,33,513]

theorem envBound25133 : H12AffineFastState.Bounded env25133 := by
  intro p hp
  have h : env25133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25132_25133 : H12AffineEnvironment.transform 3 0 env25132 = env25133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25132 == env25133) = true)

def env25134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,272392,17,41310,8193,64,171280,57676,17665,442385,61705,272393,256,41341,16465,512]

theorem envBound25134 : H12AffineFastState.Bounded env25134 := by
  intro p hp
  have h : env25134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25109_25134 : H12AffineEnvironment.transform 22 17 env25109 = env25134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25109 == env25134) = true)

theorem identity25134 : scanCanonicalize (H12AffineFastState.compose env25134 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound25134 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56577,1024,32769,4160,62729,17,41310,8193,64,171280,57676,17665,138512,61705,62728,256,41341,16465,512]

theorem envBound25135 : H12AffineFastState.Bounded env25135 := by
  intro p hp
  have h : env25135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25134_25135 : H12AffineEnvironment.transform 17 56577 env25134 = env25135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env25134 == env25135) = true)

theorem identity25135 : scanCanonicalize (H12AffineFastState.compose env25135 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound25135 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8575,131072,10280,1024,29992,4160,32,17,21623,8193,64,157753,5221,17665,138512,1056,33,256,21588,16465,512]

theorem envBound25136 : H12AffineFastState.Bounded env25136 := by
  intro p hp
  have h : env25136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25135_25136 : H12AffineEnvironment.transform 14 29993 env25135 = env25136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env25135 == env25136) = true)

theorem identity25136 : scanCanonicalize (H12AffineFastState.compose env25136 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound25136 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,8575,131072,10280,1024,8540,4160,32,17,3,8193,64,146509,5221,4469,138512,1056,33,256,32,5157,512]

theorem envBound25137 : H12AffineFastState.Bounded env25137 := by
  intro p hp
  have h : env25137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25136_25137 : H12AffineEnvironment.transform 13 5236 env25136 = env25137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env25136 == env25137) = true)

theorem identity25137 : scanCanonicalize (H12AffineFastState.compose env25137 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 3441) := by decide +kernel

theorem selectedBound25137 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env25138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,8575,3441,10280,1024,8540,4160,32,17,3,8193,64,12604,5221,4469,4193,1056,33,256,32,5157,512]

theorem envBound25138 : H12AffineFastState.Bounded env25138 := by
  intro p hp
  have h : env25138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25137_25138 : H12AffineEnvironment.transform 16 3441 env25137 = env25138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3441 env25137 == env25138) = true)

theorem identity25138 : scanCanonicalize (H12AffineFastState.compose env25138 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25138 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env25139 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5236,8313,8283,3157,10280,1024,8312,4160,32,17,3,8193,64,12312,5221,4177,4193,1056,33,36,32,5157,512]

theorem envBound25139 : H12AffineFastState.Bounded env25139 := by
  intro p hp
  have h : env25139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25138_25139 : H12AffineEnvironment.transform 7 36 env25138 = env25139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25138 == env25139) = true)

theorem identity25139 : scanCanonicalize (H12AffineFastState.compose env25139 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound25139 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env25140 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,89,5236,32,2,3157,2161,1024,33,4160,32,17,3,88,64,4161,5221,4177,4193,1056,33,36,32,5157,512]

theorem envBound25140 : H12AffineFastState.Bounded env25140 := by
  intro p hp
  have h : env25140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25139_25140 : H12AffineEnvironment.transform 12 89 env25139 = env25140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env25139 == env25140) = true)

theorem identity25140 : scanCanonicalize (H12AffineFastState.compose env25140 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound25140 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env25141 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,4096,89,4192,32,2,2113,2161,20,33,4160,32,17,3,88,64,4161,4209,4177,4193,52,33,36,32,4145,512]

theorem envBound25141 : H12AffineFastState.Bounded env25141 := by
  intro p hp
  have h : env25141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25140_25141 : H12AffineEnvironment.transform 9 20 env25140 = env25141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env25140 == env25141) = true)

theorem identity25141 : scanCanonicalize (H12AffineFastState.compose env25141 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound25141 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env25142 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,2113,89,2081,32,2,2113,2161,20,33,2049,32,17,3,88,64,2048,2096,2064,2080,52,33,36,32,2160,512]

theorem envBound25142 : H12AffineFastState.Bounded env25142 := by
  intro p hp
  have h : env25142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25141_25142 : H12AffineEnvironment.transform 11 2113 env25141 = env25142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env25141 == env25142) = true)

theorem identity25142 : scanCanonicalize (H12AffineFastState.compose env25142 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound25142 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25143 : List Nat := [2,4,8,16,32,48,9,36,512,20,2048,2097,41,2081,32,2,2097,2049,20,33,2049,32,17,3,40,48,2048,2096,2064,2080,52,33,36,32,2048,512]

theorem envBound25143 : H12AffineFastState.Bounded env25143 := by
  intro p hp
  have h : env25143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25142_25143 : H12AffineEnvironment.transform 5 48 env25142 = env25143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env25142 == env25143) = true)

theorem identity25143 : scanCanonicalize (H12AffineFastState.compose env25143 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25143 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25144 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,1,2,2064,2049,20,0,2049,1,17,3,9,17,2048,2065,2064,2049,21,0,5,1,2048,512]

theorem envBound25144 : H12AffineFastState.Bounded env25144 := by
  intro p hp
  have h : env25144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25143_25144 : H12AffineEnvironment.transform 4 1 env25143 = env25144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25143 == env25144) = true)

theorem identity25144 : scanCanonicalize (H12AffineFastState.compose env25144 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound25144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25145 : List Nat := [2,4,8,16,1,17,9,5,512,20,21,5,8,21,1,2,5,20,20,0,20,1,17,3,9,17,21,4,5,20,21,0,5,1,21,512]

theorem envBound25145 : H12AffineFastState.Bounded env25145 := by
  intro p hp
  have h : env25145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25144_25145 : H12AffineEnvironment.transform 10 21 env25144 = env25145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env25144 == env25145) = true)

theorem identity25145 : scanCanonicalize (H12AffineFastState.compose env25145 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound25145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25146 : List Nat := [2,4,8,16,1,17,9,5,7,20,21,5,8,21,1,2,5,20,20,0,20,1,17,3,9,17,21,4,5,20,21,0,5,1,21,7]

theorem envBound25146 : H12AffineFastState.Bounded env25146 := by
  intro p hp
  have h : env25146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25145_25146 : H12AffineEnvironment.transform 8 7 env25145 = env25146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env25145 == env25146) = true)

theorem identity25146 : scanCanonicalize (H12AffineFastState.compose env25146 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound25146 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25147 : List Nat := [2,4,8,9,1,8,9,5,7,13,12,5,8,12,1,2,5,13,13,0,13,1,8,3,9,8,12,4,5,13,12,0,5,1,12,7]

theorem envBound25147 : H12AffineFastState.Bounded env25147 := by
  intro p hp
  have h : env25147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25146_25147 : H12AffineEnvironment.transform 3 9 env25146 = env25147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env25146 == env25147) = true)

def env25148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,4194304,8388608,95497,8328,64,13022472,79131,8491471,8830976,8450329,4314198,256,8484155,8492190,8509135]

theorem envBound25148 : H12AffineFastState.Bounded env25148 := by
  intro p hp
  have h : env25148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25026_25148 : H12AffineEnvironment.transform 23 95497 env25026 = env25148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env25026 == env25148) = true)

def env25149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272512,8388608,95497,8328,64,8560008,79131,8491471,8830976,8450329,392406,256,8484155,8492190,8509135]

theorem envBound25149 : H12AffineFastState.Bounded env25149 := by
  intro p hp
  have h : env25149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25148_25149 : H12AffineEnvironment.transform 21 272512 env25148 = env25149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25148 == env25149) = true)

def env25150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,8388608,95497,8192,64,8559872,79131,8491335,8830976,8450329,392286,256,8484155,8492054,8508999]

theorem envBound25150 : H12AffineFastState.Bounded env25150 := by
  intro p hp
  have h : env25150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25149_25150 : H12AffineEnvironment.transform 6 8 env25149 = env25150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25149 == env25150) = true)

def env25151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,16,95497,8192,64,171280,79131,102743,442384,61705,392286,256,95531,103430,120407]

theorem envBound25151 : H12AffineFastState.Bounded env25151 := by
  intro p hp
  have h : env25151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25150_25151 : H12AffineEnvironment.transform 22 16 env25150 = env25151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25150 == env25151) = true)

theorem identity25151 : scanCanonicalize (H12AffineFastState.compose env25151 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound25151 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,45340,272392,16,2,8192,64,171280,16400,58460,442384,61705,297301,256,32,57613,41820]

theorem envBound25152 : H12AffineFastState.Bounded env25152 := by
  intro p hp
  have h : env25152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25151_25152 : H12AffineEnvironment.transform 15 29963 env25151 = env25152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env25151 == env25152) = true)

theorem identity25152 : scanCanonicalize (H12AffineFastState.compose env25152 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound25152 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env25153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,35188,1024,32769,45340,41340,16,2,8192,64,171280,16400,58460,149860,61705,33,256,32,57613,41820]

theorem envBound25153 : H12AffineFastState.Bounded env25153 := by
  intro p hp
  have h : env25153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25152_25153 : H12AffineEnvironment.transform 17 35188 env25152 = env25153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env25152 == env25153) = true)

theorem identity25153 : scanCanonicalize (H12AffineFastState.compose env25153 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound25153 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env25154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,46156,35188,1024,32769,45340,41340,16,2,8192,64,10588,16400,58460,64808,61705,33,256,32,57613,41820]

theorem envBound25154 : H12AffineFastState.Bounded env25154 := by
  intro p hp
  have h : env25154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25153_25154 : H12AffineEnvironment.transform 16 46156 env25153 = env25154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env25153 == env25154) = true)

theorem identity25154 : scanCanonicalize (H12AffineFastState.compose env25154 (packedSelected [11,12,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25154 : packedSelected [11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env25155 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,16384,32768,28990,45177,35188,53,32769,45340,41340,16,2,8192,64,10588,16400,57449,63773,61705,33,256,32,57613,41820]

theorem envBound25155 : H12AffineFastState.Bounded env25155 := by
  intro p hp
  have h : env25155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25154_25155 : H12AffineEnvironment.transform 9 53 env25154 = env25155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25154 == env25155) = true)

theorem identity25155 : scanCanonicalize (H12AffineFastState.compose env25155 (packedSelected [0,4,7,9,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25155 : packedSelected [0,4,7,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env25156 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,16384,32768,20759,36944,35188,53,32769,37173,33109,16,2,41,64,2421,16400,49216,55604,53536,33,256,32,49444,33653]

theorem envBound25156 : H12AffineFastState.Bounded env25156 := by
  intro p hp
  have h : env25156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25155_25156 : H12AffineEnvironment.transform 12 41 env25155 = env25156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25155 == env25156) = true)

theorem identity25156 : scanCanonicalize (H12AffineFastState.compose env25156 (packedSelected [2,4,6,9,12,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 20789) := by decide +kernel

theorem selectedBound25156 : packedSelected [2,4,6,9,12,14,16,18] rootPS < 2^1333 := by decide +kernel

def env25157 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,16384,20789,20759,16741,22593,53,20788,16384,20576,16,2,41,64,2421,16400,4469,2049,21,33,256,32,4113,21056]

theorem envBound25157 : H12AffineFastState.Bounded env25157 := by
  intro p hp
  have h : env25157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25156_25157 : H12AffineEnvironment.transform 14 20789 env25156 = env25157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20789 env25156 == env25157) = true)

theorem identity25157 : scanCanonicalize (H12AffineFastState.compose env25157 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound25157 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env25158 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2357,41,16384,18432,18466,16741,16756,53,18433,16384,18773,16,2,41,64,2421,16400,2112,2049,21,33,256,32,2340,19317]

theorem envBound25158 : H12AffineFastState.Bounded env25158 := by
  intro p hp
  have h : env25158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25157_25158 : H12AffineEnvironment.transform 11 2357 env25157 = env25158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env25157 == env25158) = true)

theorem identity25158 : scanCanonicalize (H12AffineFastState.compose env25158 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2625) := by decide +kernel

theorem selectedBound25158 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25159 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2357,41,2625,577,611,2852,2869,53,576,2625,788,16,2,41,64,2421,2641,2112,2049,21,33,256,32,2340,308]

theorem envBound25159 : H12AffineFastState.Bounded env25159 := by
  intro p hp
  have h : env25159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25158_25159 : H12AffineEnvironment.transform 13 2625 env25158 = env25159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2625 env25158 == env25159) = true)

theorem identity25159 : scanCanonicalize (H12AffineFastState.compose env25159 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound25159 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25160 : List Nat := [2,4,8,16,32,64,8,256,512,53,373,64,41,820,577,611,593,576,53,576,820,788,16,2,41,64,0,804,309,372,21,33,256,32,81,308]

theorem envBound25160 : H12AffineFastState.Bounded env25160 := by
  intro p hp
  have h : env25160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25159_25160 : H12AffineEnvironment.transform 10 373 env25159 = env25160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env25159 == env25160) = true)

theorem identity25160 : scanCanonicalize (H12AffineFastState.compose env25160 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25160 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25161 : List Nat := [2,4,8,16,32,64,8,256,1,53,373,64,41,309,64,98,80,65,53,65,309,277,16,2,41,64,0,293,309,372,21,33,256,32,81,308]

theorem envBound25161 : H12AffineFastState.Bounded env25161 := by
  intro p hp
  have h : env25161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25160_25161 : H12AffineEnvironment.transform 8 1 env25160 = env25161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25160 == env25161) = true)

theorem identity25161 : scanCanonicalize (H12AffineFastState.compose env25161 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25161 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env25162 : List Nat := [2,4,8,1,32,64,8,256,1,36,356,64,41,292,64,98,65,65,36,65,292,260,1,2,41,64,0,293,292,357,4,33,256,32,64,293]

theorem envBound25162 : H12AffineFastState.Bounded env25162 := by
  intro p hp
  have h : env25162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25161_25162 : H12AffineEnvironment.transform 3 1 env25161 = env25162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25161 == env25162) = true)

theorem identity25162 : scanCanonicalize (H12AffineFastState.compose env25162 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound25162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25163 : List Nat := [2,4,8,1,32,64,8,100,1,36,0,64,41,64,64,98,65,65,36,65,64,96,1,2,41,64,0,65,64,1,4,33,100,32,64,65]

theorem envBound25163 : H12AffineFastState.Bounded env25163 := by
  intro p hp
  have h : env25163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25162_25163 : H12AffineEnvironment.transform 7 100 env25162 = env25163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env25162 == env25163) = true)

theorem identity25163 : scanCanonicalize (H12AffineFastState.compose env25163 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound25163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25164 : List Nat := [2,4,8,1,32,32,8,4,1,36,0,32,41,32,32,2,33,33,36,33,32,0,1,2,41,32,0,33,32,1,4,33,4,32,32,33]

theorem envBound25164 : H12AffineFastState.Bounded env25164 := by
  intro p hp
  have h : env25164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25163_25164 : H12AffineEnvironment.transform 5 32 env25163 = env25164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25163 == env25164) = true)

theorem identity25164 : scanCanonicalize (H12AffineFastState.compose env25164 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25164 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25165 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,0,9,0,0,2,1,1,4,1,0,0,1,2,9,0,0,1,0,1,4,1,4,0,0,1]

theorem envBound25165 : H12AffineFastState.Bounded env25165 := by
  intro p hp
  have h : env25165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25164_25165 : H12AffineEnvironment.transform 4 0 env25164 = env25165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25164 == env25165) = true)

theorem identity25165 : scanCanonicalize (H12AffineFastState.compose env25165 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25165 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25166 : List Nat := [2,4,7,1,0,0,7,4,1,4,0,0,6,0,0,2,1,1,4,1,0,0,1,2,6,0,0,1,0,1,4,1,4,0,0,1]

theorem envBound25166 : H12AffineFastState.Bounded env25166 := by
  intro p hp
  have h : env25166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25165_25166 : H12AffineEnvironment.transform 2 7 env25165 = env25166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25165 == env25166) = true)

def env25167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,17,95497,8192,64,171281,79131,102742,442385,61704,392286,256,95530,103431,120406]

theorem envBound25167 : H12AffineFastState.Bounded env25167 := by
  intro p hp
  have h : env25167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25150_25167 : H12AffineEnvironment.transform 22 17 env25150 = env25167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25150 == env25167) = true)

theorem identity25167 : scanCanonicalize (H12AffineFastState.compose env25167 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound25167 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1024,32769,115735,95530,17,95497,8192,64,171281,79131,102742,236851,61704,41340,256,95530,103431,120406]

theorem envBound25168 : H12AffineFastState.Bounded env25168 := by
  intro p hp
  have h : env25168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25167_25168 : H12AffineEnvironment.transform 17 89378 env25167 = env25168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env25167 == env25168) = true)

theorem identity25168 : scanCanonicalize (H12AffineFastState.compose env25168 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound25168 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env25169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,46157,89378,1024,32769,115735,95530,17,95497,8192,64,10588,79131,102742,76158,61704,41340,256,95530,103431,120406]

theorem envBound25169 : H12AffineFastState.Bounded env25169 := by
  intro p hp
  have h : env25169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25168_25169 : H12AffineEnvironment.transform 16 46157 env25168 = env25169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env25168 == env25169) = true)

theorem identity25169 : scanCanonicalize (H12AffineFastState.compose env25169 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound25169 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46157,35189,1024,32769,4160,41341,17,41310,8192,64,10588,57676,17665,64809,61704,41340,256,41341,16464,513]

theorem envBound25170 : H12AffineFastState.Bounded env25170 := by
  intro p hp
  have h : env25170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25169_25170 : H12AffineEnvironment.transform 15 54359 env25169 = env25170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env25169 == env25170) = true)

theorem identity25170 : scanCanonicalize (H12AffineFastState.compose env25170 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound25170 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,9499,17665,30777,1024,29005,4160,20529,17,20498,8192,64,10588,4096,17665,3173,68,20528,256,20529,16464,513]

theorem envBound25171 : H12AffineFastState.Bounded env25171 := by
  intro p hp
  have h : env25171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25170_25171 : H12AffineEnvironment.transform 14 29004 env25170 = env25171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env25170 == env25171) = true)

def env25172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,8388608,95497,8193,64,8559873,79131,8491334,8830976,8450329,392287,256,8484155,8492055,8508998]

theorem envBound25172 : H12AffineFastState.Bounded env25172 := by
  intro p hp
  have h : env25172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25149_25172 : H12AffineEnvironment.transform 6 9 env25149 = env25172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25149 == env25172) = true)

def env25173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,16,95497,8193,64,171281,79131,102742,442384,61705,392287,256,95531,103431,120406]

theorem envBound25173 : H12AffineFastState.Bounded env25173 := by
  intro p hp
  have h : env25173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25172_25173 : H12AffineEnvironment.transform 22 16 env25172 = env25173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25172 == env25173) = true)

theorem identity25173 : scanCanonicalize (H12AffineFastState.compose env25173 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound25173 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272393,16,41310,8193,64,171281,57676,17665,442384,61705,272392,256,41340,16464,513]

theorem envBound25174 : H12AffineFastState.Bounded env25174 := by
  intro p hp
  have h : env25174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25173_25174 : H12AffineEnvironment.transform 15 54359 env25173 = env25174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env25173 == env25174) = true)

def env25175 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,272393,16,41230,8193,16,171281,57628,17665,442384,61705,272392,256,41260,16384,513]

theorem envBound25175 : H12AffineFastState.Bounded env25175 := by
  intro p hp
  have h : env25175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25174_25175 : H12AffineEnvironment.transform 5 16 env25174 = env25175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25174 == env25175) = true)

theorem identity25175 : scanCanonicalize (H12AffineFastState.compose env25175 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound25175 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env25176 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,171061,1024,32769,4113,177212,16,41230,8193,16,171281,57628,17665,23589,61705,177213,256,41260,16384,513]

theorem envBound25176 : H12AffineFastState.Bounded env25176 := by
  intro p hp
  have h : env25176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25175_25176 : H12AffineEnvironment.transform 17 171061 env25175 = env25176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env25175 == env25176) = true)

theorem identity25176 : scanCanonicalize (H12AffineFastState.compose env25176 (packedSelected [1,2,3,4,6,9,14,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25176 : packedSelected [1,2,3,4,6,9,14,20,24,28] rootPS < 2^1333 := by decide +kernel

def env25177 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33031,131072,171061,1024,32769,4113,177212,16,41230,8193,16,171281,46108,4097,2341,41993,177213,256,41260,5376,513]

theorem envBound25177 : H12AffineFastState.Bounded env25177 := by
  intro p hp
  have h : env25177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25176_25177 : H12AffineEnvironment.transform 13 5376 env25176 = env25177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25176 == env25177) = true)

def env25178 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,272393,16,41231,8193,17,171281,57629,17665,442384,61705,272392,256,41261,16385,513]

theorem envBound25178 : H12AffineFastState.Bounded env25178 := by
  intro p hp
  have h : env25178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25174_25178 : H12AffineEnvironment.transform 5 17 env25174 = env25178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25174 == env25178) = true)

theorem identity25178 : scanCanonicalize (H12AffineFastState.compose env25178 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound25178 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env25179 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,263,131072,262144,1024,21760,4112,272393,16,29710,8193,17,149520,13340,17665,398609,9224,272392,256,29740,16385,513]

theorem envBound25179 : H12AffineFastState.Bounded env25179 := by
  intro p hp
  have h : env25179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25178_25179 : H12AffineEnvironment.transform 14 21761 env25178 = env25179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25178 == env25179) = true)

theorem identity25179 : scanCanonicalize (H12AffineFastState.compose env25179 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound25179 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25180 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,263,131072,138292,1024,21760,4112,144445,16,29710,8193,17,149520,13340,17665,2341,9224,144444,256,29740,16385,513]

theorem envBound25180 : H12AffineFastState.Bounded env25180 := by
  intro p hp
  have h : env25180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25179_25180 : H12AffineEnvironment.transform 17 138292 env25179 = env25180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env25179 == env25180) = true)

theorem identity25180 : scanCanonicalize (H12AffineFastState.compose env25180 (packedSelected [0,3,5,7,10,12,15,20] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound25180 : packedSelected [0,3,5,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env25181 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,263,24861,32041,1024,21760,4112,21792,16,29710,8193,17,10509,13340,17665,2341,9224,21793,256,29740,16385,513]

theorem envBound25181 : H12AffineFastState.Bounded env25181 := by
  intro p hp
  have h : env25181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25180_25181 : H12AffineEnvironment.transform 16 24861 env25180 = env25181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env25180 == env25181) = true)

theorem identity25181 : scanCanonicalize (H12AffineFastState.compose env25181 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25181 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env25182 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,263,13341,10281,1024,0,4112,32,16,8462,8193,17,10509,13340,4097,2341,9224,33,256,8492,5377,513]

theorem envBound25182 : H12AffineFastState.Bounded env25182 := by
  intro p hp
  have h : env25182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25181_25182 : H12AffineEnvironment.transform 13 5376 env25181 = env25182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25181 == env25182) = true)

theorem identity25182 : scanCanonicalize (H12AffineFastState.compose env25182 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 6941) := by decide +kernel

theorem selectedBound25182 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env25183 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6941,5376,1,263,3840,4916,1024,0,4112,32,16,6675,6940,17,4624,3841,4097,2341,7957,33,256,6705,5377,513]

theorem envBound25183 : H12AffineFastState.Bounded env25183 := by
  intro p hp
  have h : env25183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25182_25183 : H12AffineEnvironment.transform 12 6941 env25182 = env25183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6941 env25182 == env25183) = true)

theorem identity25183 : scanCanonicalize (H12AffineFastState.compose env25183 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound25183 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env25184 : List Nat := [2,4,8,16,32,17,9,256,512,36,2048,4096,6941,4388,1,263,2852,4916,36,0,4112,32,16,6675,6940,17,4624,2853,4097,2341,6961,33,256,6705,4389,513]

theorem envBound25184 : H12AffineFastState.Bounded env25184 := by
  intro p hp
  have h : env25184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25183_25184 : H12AffineEnvironment.transform 9 36 env25183 = env25184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env25183 == env25184) = true)

theorem identity25184 : scanCanonicalize (H12AffineFastState.compose env25184 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound25184 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env25185 : List Nat := [2,4,8,16,32,17,9,256,512,36,16,4096,4877,4388,1,263,820,4916,36,0,4112,32,16,4611,4876,17,4624,821,4097,309,4897,33,256,4641,4389,513]

theorem envBound25185 : H12AffineFastState.Bounded env25185 := by
  intro p hp
  have h : env25185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25184_25185 : H12AffineEnvironment.transform 10 16 env25184 = env25185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env25184 == env25185) = true)

theorem identity25185 : scanCanonicalize (H12AffineFastState.compose env25185 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound25185 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env25186 : List Nat := [2,4,8,16,32,17,9,256,293,36,16,4096,4136,4388,1,263,17,4113,36,0,4112,32,16,4390,4137,17,4405,16,4097,309,4100,33,256,4356,4389,292]

theorem envBound25186 : H12AffineFastState.Bounded env25186 := by
  intro p hp
  have h : env25186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25185_25186 : H12AffineEnvironment.transform 8 293 env25185 = env25186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env25185 == env25186) = true)

theorem identity25186 : scanCanonicalize (H12AffineFastState.compose env25186 (packedSelected [1,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound25186 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env25187 : List Nat := [2,4,8,16,32,17,9,256,293,36,16,292,268,0,1,263,17,309,36,0,308,32,16,2,269,17,17,16,293,309,288,33,256,32,1,292]

theorem envBound25187 : H12AffineFastState.Bounded env25187 := by
  intro p hp
  have h : env25187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25186_25187 : H12AffineEnvironment.transform 11 292 env25186 = env25187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env25186 == env25187) = true)

theorem identity25187 : scanCanonicalize (H12AffineFastState.compose env25187 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound25187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25188 : List Nat := [2,4,8,16,32,17,9,52,17,36,16,16,56,0,1,51,17,1,36,0,0,32,16,2,57,17,17,16,17,1,20,33,52,32,1,16]

theorem envBound25188 : H12AffineFastState.Bounded env25188 := by
  intro p hp
  have h : env25188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25187_25188 : H12AffineEnvironment.transform 7 52 env25187 = env25188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env25187 == env25188) = true)

theorem identity25188 : scanCanonicalize (H12AffineFastState.compose env25188 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound25188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25189 : List Nat := [2,4,8,16,27,17,9,15,17,31,16,16,3,0,1,8,17,1,31,0,0,27,16,2,2,17,17,16,17,1,20,26,15,27,1,16]

theorem envBound25189 : H12AffineFastState.Bounded env25189 := by
  intro p hp
  have h : env25189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25188_25189 : H12AffineEnvironment.transform 4 27 env25188 = env25189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env25188 == env25189) = true)

def env25190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,17,95497,8193,64,171280,79131,102743,442385,61704,392287,256,95530,103430,120407]

theorem envBound25190 : H12AffineFastState.Bounded env25190 := by
  intro p hp
  have h : env25190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25172_25190 : H12AffineEnvironment.transform 22 17 env25172 = env25190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25172 == env25190) = true)

theorem identity25190 : scanCanonicalize (H12AffineFastState.compose env25190 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound25190 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130175,1024,32769,115734,119926,17,95497,8193,64,171280,79131,102743,212078,61704,32,256,95530,103430,120407]

theorem envBound25191 : H12AffineFastState.Bounded env25191 := by
  intro p hp
  have h : env25191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25190_25191 : H12AffineEnvironment.transform 17 130175 env25190 = env25191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env25190 == env25191) = true)

theorem identity25191 : scanCanonicalize (H12AffineFastState.compose env25191 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound25191 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env25192 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46156,130175,1024,32769,115734,119926,17,95497,8193,64,10588,79131,102743,100386,61704,32,256,95530,103430,120407]

theorem envBound25192 : H12AffineFastState.Bounded env25192 := by
  intro p hp
  have h : env25192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25191_25192 : H12AffineEnvironment.transform 16 46156 env25191 = env25192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env25191 == env25192) = true)

theorem identity25192 : scanCanonicalize (H12AffineFastState.compose env25192 (packedSelected [1,3,4,8,9,10,11,14,18,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound25192 : packedSelected [1,3,4,8,9,10,11,14,18,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env25193 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,65536,24860,76079,1024,21841,69958,65830,17,95497,8193,64,10588,79131,82951,89458,9304,32,256,95530,82262,66311]

theorem envBound25193 : H12AffineFastState.Bounded env25193 := by
  intro p hp
  have h : env25193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25192_25193 : H12AffineEnvironment.transform 14 21840 env25192 = env25193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env25192 == env25193) = true)

theorem identity25193 : scanCanonicalize (H12AffineFastState.compose env25193 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound25193 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env25194 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,263,24860,10280,1024,21841,4161,33,17,29710,8193,64,10588,13340,17664,23669,9304,32,256,29741,16465,512]

theorem envBound25194 : H12AffineFastState.Bounded env25194 := by
  intro p hp
  have h : env25194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25193_25194 : H12AffineEnvironment.transform 15 263 env25193 = env25194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env25193 == env25194) = true)

theorem identity25194 : scanCanonicalize (H12AffineFastState.compose env25194 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound25194 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,16384,21840,263,17665,3125,1024,21841,4161,33,17,20499,1052,64,3393,4097,17664,23669,69,32,256,20528,16465,512]

theorem envBound25195 : H12AffineFastState.Bounded env25195 := by
  intro p hp
  have h : env25195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25194_25195 : H12AffineEnvironment.transform 12 1053 env25194 = env25195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env25194 == env25195) = true)

theorem identity25195 : scanCanonicalize (H12AffineFastState.compose env25195 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound25195 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,4453,1077,263,5220,3125,1024,1076,4161,33,17,374,1052,64,3393,4097,5221,3344,69,32,256,341,4404,512]

theorem envBound25196 : H12AffineFastState.Bounded env25196 := by
  intro p hp
  have h : env25196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25195_25196 : H12AffineEnvironment.transform 13 4453 env25195 = env25196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env25195 == env25196) = true)

theorem identity25196 : scanCanonicalize (H12AffineFastState.compose env25196 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound25196 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env25197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1053,3345,1077,263,2064,3125,1024,1076,3125,33,17,374,1052,64,3393,3189,2065,3344,69,32,256,341,3392,512]

theorem envBound25197 : H12AffineFastState.Bounded env25197 := by
  intro p hp
  have h : env25197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25196_25197 : H12AffineEnvironment.transform 11 3188 env25196 = env25197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env25196 == env25197) = true)

theorem identity25197 : scanCanonicalize (H12AffineFastState.compose env25197 (packedSelected [1,4,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25197 : packedSelected [1,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env25198 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,3188,1053,3093,1077,3,2064,3125,1024,1076,3125,33,17,114,1052,64,3141,3189,2065,3092,69,32,4,81,3140,512]

theorem envBound25198 : H12AffineFastState.Bounded env25198 := by
  intro p hp
  have h : env25198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25197_25198 : H12AffineEnvironment.transform 7 4 env25197 = env25198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25197 == env25198) = true)

theorem identity25198 : scanCanonicalize (H12AffineFastState.compose env25198 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25198 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25199 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,3109,1053,3093,1077,3,2064,3125,1024,1076,3125,33,17,35,1052,17,3092,3108,2065,3092,20,32,4,0,3093,512]

theorem envBound25199 : H12AffineFastState.Bounded env25199 := by
  intro p hp
  have h : env25199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25198_25199 : H12AffineEnvironment.transform 5 17 env25198 = env25199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25198 == env25199) = true)

theorem identity25199 : scanCanonicalize (H12AffineFastState.compose env25199 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25199 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env25200 : List Nat := [2,4,8,16,32,17,9,4,512,52,2048,2065,41,2081,1,3,2064,2049,52,0,2049,33,17,35,40,17,2080,2064,2065,2080,20,32,4,0,2081,512]

theorem envBound25200 : H12AffineFastState.Bounded env25200 := by
  intro p hp
  have h : env25200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25199_25200 : H12AffineEnvironment.transform 9 52 env25199 = env25200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25199 == env25200) = true)

theorem identity25200 : scanCanonicalize (H12AffineFastState.compose env25200 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound25200 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env25201 : List Nat := [2,4,8,16,32,17,9,4,512,52,544,561,41,513,1,3,560,545,52,0,545,33,17,35,40,17,512,560,561,512,20,32,4,0,513,512]

theorem envBound25201 : H12AffineFastState.Bounded env25201 := by
  intro p hp
  have h : env25201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25200_25201 : H12AffineEnvironment.transform 10 544 env25200 = env25201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env25200 == env25201) = true)

theorem identity25201 : scanCanonicalize (H12AffineFastState.compose env25201 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound25201 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25202 : List Nat := [2,4,8,16,32,17,9,4,21,52,53,36,41,20,1,3,37,52,52,0,52,33,17,35,40,17,21,37,36,21,20,32,4,0,20,21]

theorem envBound25202 : H12AffineFastState.Bounded env25202 := by
  intro p hp
  have h : env25202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25201_25202 : H12AffineEnvironment.transform 8 21 env25201 = env25202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env25201 == env25202) = true)

theorem identity25202 : scanCanonicalize (H12AffineFastState.compose env25202 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound25202 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25203 : List Nat := [2,4,8,16,21,17,9,4,21,1,0,17,28,20,1,3,16,1,1,0,1,20,17,22,29,17,21,16,17,21,20,21,4,0,20,21]

theorem envBound25203 : H12AffineFastState.Bounded env25203 := by
  intro p hp
  have h : env25203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25202_25203 : H12AffineEnvironment.transform 4 21 env25202 = env25203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env25202 == env25203) = true)

theorem identity25203 : scanCanonicalize (H12AffineFastState.compose env25203 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound25203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25204 : List Nat := [2,4,8,5,0,4,9,4,0,1,0,4,9,1,1,3,5,1,1,0,1,1,4,3,8,4,0,5,4,0,1,0,4,0,1,0]

theorem envBound25204 : H12AffineFastState.Bounded env25204 := by
  intro p hp
  have h : env25204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25203_25204 : H12AffineEnvironment.transform 3 5 env25203 = env25204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25203 == env25204) = true)

theorem identity25204 : scanCanonicalize (H12AffineFastState.compose env25204 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25205 : List Nat := [2,1,8,0,0,1,9,1,0,1,0,1,9,1,1,3,0,1,1,0,1,1,1,3,8,1,0,0,1,0,1,0,1,0,1,0]

theorem envBound25205 : H12AffineFastState.Bounded env25205 := by
  intro p hp
  have h : env25205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25204_25205 : H12AffineEnvironment.transform 1 1 env25204 = env25205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25204 == env25205) = true)

def env25206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,8388608,95497,8328,64,8560009,79131,8491471,8830976,8450329,392407,256,8484155,8492190,8509135]

theorem envBound25206 : H12AffineFastState.Bounded env25206 := by
  intro p hp
  have h : env25206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25148_25206 : H12AffineEnvironment.transform 21 272513 env25148 = env25206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25148 == env25206) = true)

theorem identity25206 : scanCanonicalize (H12AffineFastState.compose env25206 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound25206 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,16,95497,8328,64,171417,79131,102879,442384,61705,392407,256,95531,103566,120543]

theorem envBound25207 : H12AffineFastState.Bounded env25207 := by
  intro p hp
  have h : env25207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25206_25207 : H12AffineEnvironment.transform 22 16 env25206 = env25207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25206 == env25207) = true)

def env25208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,16,95497,8192,64,171281,79131,102743,442384,61705,392287,256,95531,103430,120407]

theorem envBound25208 : H12AffineFastState.Bounded env25208 := by
  intro p hp
  have h : env25208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25207_25208 : H12AffineEnvironment.transform 6 8 env25207 = env25208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25207 == env25208) = true)

theorem identity25208 : scanCanonicalize (H12AffineFastState.compose env25208 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound25208 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,45340,272393,16,2,8192,64,171281,16400,58460,442384,61705,297300,256,32,57613,41820]

theorem envBound25209 : H12AffineFastState.Bounded env25209 := by
  intro p hp
  have h : env25209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25208_25209 : H12AffineEnvironment.transform 15 29963 env25208 = env25209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env25208 == env25209) = true)

theorem identity25209 : scanCanonicalize (H12AffineFastState.compose env25209 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound25209 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env25210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,138292,1024,32769,45340,144445,16,2,8192,64,171281,16400,58460,56356,61705,169312,256,32,57613,41820]

theorem envBound25210 : H12AffineFastState.Bounded env25210 := by
  intro p hp
  have h : env25210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25209_25210 : H12AffineEnvironment.transform 17 138292 env25209 = env25210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env25209 == env25210) = true)

theorem identity25210 : scanCanonicalize (H12AffineFastState.compose env25210 (packedSelected [0,1,4,7,8,10,11,14,16,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 57448) := by decide +kernel

theorem selectedBound25210 : packedSelected [0,1,4,7,8,10,11,14,16,22,23] rootPS < 2^1333 := by decide +kernel

def env25211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,57448,64604,1024,32769,45340,54357,16,2,8192,64,32121,16400,58460,56356,61705,29960,256,32,57613,41820]

theorem envBound25211 : H12AffineFastState.Bounded env25211 := by
  intro p hp
  have h : env25211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25210_25211 : H12AffineEnvironment.transform 16 57448 env25210 = env25211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57448 env25210 == env25211) = true)

theorem identity25211 : scanCanonicalize (H12AffineFastState.compose env25211 (packedSelected [2,3,4,6,12,15,22,24,35] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound25211 : packedSelected [2,3,4,6,12,15,22,24,35] rootPS < 2^1333 := by decide +kernel

def env25212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,29963,5392,2340,1024,30073,17508,8493,16,2,8192,64,32121,16400,4388,10588,1137,29960,256,32,5237,22052]

theorem envBound25212 : H12AffineFastState.Bounded env25212 := by
  intro p hp
  have h : env25212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25211_25212 : H12AffineEnvironment.transform 14 30072 env25211 = env25212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env25211 == env25212) = true)

theorem identity25212 : scanCanonicalize (H12AffineFastState.compose env25212 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25212 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env25213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21540,21591,5392,2340,1024,21541,17508,113,16,2,348,64,23589,16400,4388,2048,1137,21588,256,32,5237,22052]

theorem envBound25213 : H12AffineFastState.Bounded env25213 := by
  intro p hp
  have h : env25213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25212_25213 : H12AffineEnvironment.transform 12 348 env25212 = env25213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25212 == env25213) = true)

theorem identity25213 : scanCanonicalize (H12AffineFastState.compose env25213 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound25213 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env25214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,81,34,5392,2340,1024,80,4113,113,16,2,348,64,2128,5221,4388,2048,1137,33,256,32,5237,593]

theorem envBound25214 : H12AffineFastState.Bounded env25214 := by
  intro p hp
  have h : env25214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25213_25214 : H12AffineEnvironment.transform 13 5237 env25213 = env25214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env25213 == env25214) = true)

theorem identity25214 : scanCanonicalize (H12AffineFastState.compose env25214 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound25214 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25215 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,81,34,5220,2128,1024,80,4113,113,16,2,40,64,2128,5221,4176,2048,1137,33,116,32,5237,593]

theorem envBound25215 : H12AffineFastState.Bounded env25215 := by
  intro p hp
  have h : env25215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25214_25215 : H12AffineEnvironment.transform 7 116 env25214 = env25215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env25214 == env25215) = true)

theorem identity25215 : scanCanonicalize (H12AffineFastState.compose env25215 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25215 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env25216 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,34,5173,2049,1024,1,4113,32,16,2,40,17,2049,5172,4097,2048,1056,33,37,32,5156,512]

theorem envBound25216 : H12AffineFastState.Bounded env25216 := by
  intro p hp
  have h : env25216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25215_25216 : H12AffineEnvironment.transform 5 17 env25215 = env25216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25215 == env25216) = true)

theorem identity25216 : scanCanonicalize (H12AffineFastState.compose env25216 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25217 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5124,0,2,5141,2049,1024,1,4113,0,16,2,8,17,2049,5140,4097,2048,1024,1,5,0,5124,512]

theorem envBound25217 : H12AffineFastState.Bounded env25217 := by
  intro p hp
  have h : env25217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25216_25217 : H12AffineEnvironment.transform 4 0 env25216 = env25217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25216 == env25217) = true)

def env25218 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1044,0,2,1029,2049,1024,1,1,0,16,2,8,17,2049,1028,17,2048,1024,1,5,0,1044,512]

theorem envBound25218 : H12AffineFastState.Bounded env25218 := by
  intro p hp
  have h : env25218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25217_25218 : H12AffineEnvironment.transform 11 16 env25217 = env25218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25217 == env25218) = true)

theorem identity25218 : scanCanonicalize (H12AffineFastState.compose env25218 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25218 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25219 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,8,1044,0,2,1029,1,1024,1,1,0,16,2,8,17,1,1028,17,0,1024,1,5,0,1044,512]

theorem envBound25219 : H12AffineFastState.Bounded env25219 := by
  intro p hp
  have h : env25219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25218_25219 : H12AffineEnvironment.transform 10 0 env25218 = env25219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25218 == env25219) = true)

def env25220 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,0,0,2,17,1,20,1,1,0,16,2,8,17,1,16,17,0,20,1,5,0,0,512]

theorem envBound25220 : H12AffineFastState.Bounded env25220 := by
  intro p hp
  have h : env25220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25219_25220 : H12AffineEnvironment.transform 9 20 env25219 = env25220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env25219 == env25220) = true)

theorem identity25220 : scanCanonicalize (H12AffineFastState.compose env25220 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound25220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25221 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,8,0,0,2,17,1,20,1,1,0,16,2,8,17,1,16,17,0,20,1,5,0,0,31]

theorem envBound25221 : H12AffineFastState.Bounded env25221 := by
  intro p hp
  have h : env25221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25220_25221 : H12AffineEnvironment.transform 8 31 env25220 = env25221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env25220 == env25221) = true)

def leafEnv25221 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,8,0,0,2,17,1,20,1,1,0,16,2,20,8,1,17,1,16,17,0,20,1,5,0,4,2,0,31,1,1,0]

def active25221 : List Nat := [0,1,2,3]

def tree25221 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25221 : H12WitnessSearch.Good tree25221 := H12GlobalWitnessIndex.good

theorem leafIdentity25221 : H12AffineFastState.composeSystem env25221 rootObs = leafEnv25221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25221 rootObs == leafEnv25221) = true)

theorem terminalChecked25221 : H12PackedTerminal.terminalCheckFast leafEnv25221 active25221 tree25221 = true := by decide +kernel

def env25222 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,0,2,16,1,21,1,1,0,16,2,8,17,1,17,17,0,21,1,5,0,1,512]

theorem envBound25222 : H12AffineFastState.Bounded env25222 := by
  intro p hp
  have h : env25222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25219_25222 : H12AffineEnvironment.transform 9 21 env25219 = env25222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env25219 == env25222) = true)

theorem identity25222 : scanCanonicalize (H12AffineFastState.compose env25222 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound25222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25223 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,0,2,5,1,0,1,1,0,5,2,8,4,1,4,4,0,0,1,5,0,1,512]

theorem envBound25223 : H12AffineFastState.Bounded env25223 := by
  intro p hp
  have h : env25223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25222_25223 : H12AffineEnvironment.transform 3 5 env25222 = env25223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25222 == env25223) = true)

def leafEnv25223 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,0,2,5,1,0,1,1,0,5,2,0,8,1,4,1,4,4,0,0,1,5,0,4,2,1,512,1,1,0]

def active25223 : List Nat := [0,1,2,8]

def tree25223 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25223 : H12WitnessSearch.Good tree25223 := H12GlobalWitnessIndex.good

theorem leafIdentity25223 : H12AffineFastState.composeSystem env25223 rootObs = leafEnv25223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25223 rootObs == leafEnv25223) = true)

theorem terminalChecked25223 : H12PackedTerminal.terminalCheckFast leafEnv25223 active25223 tree25223 = true := by decide +kernel

def env25224 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1045,0,2,1028,2049,1024,1,0,0,16,2,8,17,2049,1029,16,2048,1024,1,5,0,1045,512]

theorem envBound25224 : H12AffineFastState.Bounded env25224 := by
  intro p hp
  have h : env25224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25217_25224 : H12AffineEnvironment.transform 11 17 env25217 = env25224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25217 == env25224) = true)

theorem identity25224 : scanCanonicalize (H12AffineFastState.compose env25224 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound25224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25225 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,17,8,1045,0,2,1028,1045,1024,1,0,0,16,2,8,17,1045,1029,16,1044,1024,1,5,0,1045,512]

theorem envBound25225 : H12AffineFastState.Bounded env25225 := by
  intro p hp
  have h : env25225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25224_25225 : H12AffineEnvironment.transform 10 1044 env25224 = env25225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env25224 == env25225) = true)

def env25226 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,1,0,2,16,1,20,1,0,0,16,2,8,17,1,17,16,0,20,1,5,0,1,512]

theorem envBound25226 : H12AffineFastState.Bounded env25226 := by
  intro p hp
  have h : env25226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25225_25226 : H12AffineEnvironment.transform 9 20 env25225 = env25226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env25225 == env25226) = true)

theorem identity25226 : scanCanonicalize (H12AffineFastState.compose env25226 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound25226 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25227 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,17,8,1,0,2,16,1,20,1,0,0,16,2,8,17,1,17,16,0,20,1,5,0,1,31]

theorem envBound25227 : H12AffineFastState.Bounded env25227 := by
  intro p hp
  have h : env25227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25226_25227 : H12AffineEnvironment.transform 8 31 env25226 = env25227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env25226 == env25227) = true)

def leafEnv25227 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,17,8,1,0,2,16,1,20,1,0,0,16,2,20,8,1,17,1,17,16,0,20,1,5,0,4,2,1,31,1,0,0]

def active25227 : List Nat := [0,1,2,3]

def tree25227 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25227 : H12WitnessSearch.Good tree25227 := H12GlobalWitnessIndex.good

theorem leafIdentity25227 : H12AffineFastState.composeSystem env25227 rootObs = leafEnv25227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25227 rootObs == leafEnv25227) = true)

theorem terminalChecked25227 : H12PackedTerminal.terminalCheckFast leafEnv25227 active25227 tree25227 = true := by decide +kernel

def env25228 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,17,8,0,0,2,17,0,21,1,0,0,16,2,8,17,0,16,16,1,21,1,5,0,0,512]

theorem envBound25228 : H12AffineFastState.Bounded env25228 := by
  intro p hp
  have h : env25228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25225_25228 : H12AffineEnvironment.transform 9 21 env25225 = env25228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env25225 == env25228) = true)

theorem identity25228 : scanCanonicalize (H12AffineFastState.compose env25228 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound25228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25229 : List Nat := [2,4,8,5,0,4,8,5,512,0,1,4,8,0,0,2,4,0,0,1,0,0,5,2,8,4,0,5,5,1,0,1,5,0,0,512]

theorem envBound25229 : H12AffineFastState.Bounded env25229 := by
  intro p hp
  have h : env25229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25228_25229 : H12AffineEnvironment.transform 3 5 env25228 = env25229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25228 == env25229) = true)

def leafEnv25229 : List Nat := [2,4,8,5,0,4,8,5,512,0,1,4,8,0,0,2,4,0,0,1,0,0,5,2,0,8,1,4,0,5,5,1,0,1,5,0,4,2,0,512,1,0,0]

def active25229 : List Nat := [0,1,2,8]

def tree25229 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25229 : H12WitnessSearch.Good tree25229 := H12GlobalWitnessIndex.good

theorem leafIdentity25229 : H12AffineFastState.composeSystem env25229 rootObs = leafEnv25229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25229 rootObs == leafEnv25229) = true)

theorem terminalChecked25229 : H12PackedTerminal.terminalCheckFast leafEnv25229 active25229 tree25229 = true := by decide +kernel

def env25230 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,16,95497,8193,64,171280,79131,102742,442384,61705,392286,256,95531,103431,120406]

theorem envBound25230 : H12AffineFastState.Bounded env25230 := by
  intro p hp
  have h : env25230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25207_25230 : H12AffineEnvironment.transform 6 9 env25207 = env25230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25207 == env25230) = true)

theorem identity25230 : scanCanonicalize (H12AffineFastState.compose env25230 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound25230 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25231 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272392,16,41310,8193,64,171280,57676,17665,442384,61705,272393,256,41340,16464,513]

theorem envBound25231 : H12AffineFastState.Bounded env25231 := by
  intro p hp
  have h : env25231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25230_25231 : H12AffineEnvironment.transform 15 54359 env25230 = env25231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env25230 == env25231) = true)

def env25232 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,272392,16,41230,8193,16,171280,57628,17665,442384,61705,272393,256,41260,16384,513]

theorem envBound25232 : H12AffineFastState.Bounded env25232 := by
  intro p hp
  have h : env25232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25231_25232 : H12AffineEnvironment.transform 5 16 env25231 = env25232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25231 == env25232) = true)

theorem identity25232 : scanCanonicalize (H12AffineFastState.compose env25232 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound25232 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env25233 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,56356,1024,32769,4113,62508,16,41230,8193,16,171280,57628,17665,138292,61705,62509,256,41260,16384,513]

theorem envBound25233 : H12AffineFastState.Bounded env25233 := by
  intro p hp
  have h : env25233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25232_25233 : H12AffineEnvironment.transform 17 56356 env25232 = env25233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env25232 == env25233) = true)

theorem identity25233 : scanCanonicalize (H12AffineFastState.compose env25233 (packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound25233 : packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env25234 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,49169,56356,1024,32769,4113,62508,16,41230,8193,16,23809,57628,17665,56357,61705,62509,256,41260,16384,513]

theorem envBound25234 : H12AffineFastState.Bounded env25234 := by
  intro p hp
  have h : env25234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25233_25234 : H12AffineEnvironment.transform 16 49169 env25233 = env25234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25233 == env25234) = true)

theorem identity25234 : scanCanonicalize (H12AffineFastState.compose env25234 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25234 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env25235 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,21510,16400,23589,1024,0,4113,29741,16,8463,8193,16,23809,24861,17665,23588,28936,29740,256,8493,16384,513]

theorem envBound25235 : H12AffineFastState.Bounded env25235 := by
  intro p hp
  have h : env25235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25234_25235 : H12AffineEnvironment.transform 14 1 env25234 = env25235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25234 == env25235) = true)

def env25236 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,272392,16,41231,8193,17,171280,57629,17665,442384,61705,272393,256,41261,16385,513]

theorem envBound25236 : H12AffineFastState.Bounded env25236 := by
  intro p hp
  have h : env25236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25231_25236 : H12AffineEnvironment.transform 5 17 env25231 = env25236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25231 == env25236) = true)

theorem identity25236 : scanCanonicalize (H12AffineFastState.compose env25236 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound25236 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env25237 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,38161,262144,1024,32769,4112,272392,16,41231,8193,17,2049,57629,17665,283905,61705,272393,256,41261,16385,513]

theorem envBound25237 : H12AffineFastState.Bounded env25237 := by
  intro p hp
  have h : env25237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25236_25237 : H12AffineEnvironment.transform 16 38161 env25236 = env25237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env25236 == env25237) = true)

theorem identity25237 : scanCanonicalize (H12AffineFastState.compose env25237 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound25237 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25238 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,38161,35108,1024,32769,4112,41260,16,41231,8193,17,2049,57629,17665,56357,61705,41261,256,41261,16385,513]

theorem envBound25238 : H12AffineFastState.Bounded env25238 := by
  intro p hp
  have h : env25238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25237_25238 : H12AffineEnvironment.transform 17 35108 env25237 = env25238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env25237 == env25238) = true)

theorem identity25238 : scanCanonicalize (H12AffineFastState.compose env25238 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound25238 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env25239 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,3344,32768,39190,38161,35108,1024,32769,4112,41260,16,41231,8193,17,2049,44045,2065,37173,48153,41261,256,41261,3345,513]

theorem envBound25239 : H12AffineFastState.Bounded env25239 := by
  intro p hp
  have h : env25239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25238_25239 : H12AffineEnvironment.transform 13 3344 env25238 = env25239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env25238 == env25239) = true)

theorem identity25239 : scanCanonicalize (H12AffineFastState.compose env25239 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25239 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env25240 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,3344,32768,39190,38161,35108,1024,32769,4112,32801,16,32770,268,17,2049,36096,2065,37173,40212,32800,256,32800,3345,513]

theorem envBound25240 : H12AffineFastState.Bounded env25240 := by
  intro p hp
  have h : env25240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25239_25240 : H12AffineEnvironment.transform 12 269 env25239 = env25240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25239 == env25240) = true)

theorem identity25240 : scanCanonicalize (H12AffineFastState.compose env25240 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 7205) := by decide +kernel

theorem selectedBound25240 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env25241 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,3344,7205,1331,2356,5377,1024,7204,4112,7172,16,7207,268,17,2049,4389,2065,3344,305,7173,256,7173,3345,513]

theorem envBound25241 : H12AffineFastState.Bounded env25241 := by
  intro p hp
  have h : env25241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25240_25241 : H12AffineEnvironment.transform 14 7205 env25240 = env25241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7205 env25240 == env25241) = true)

theorem identity25241 : scanCanonicalize (H12AffineFastState.compose env25241 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25241 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env25242 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2064,269,3344,1077,1331,2356,3345,1024,1076,2048,1044,16,1079,268,17,2049,2357,2065,3344,305,1045,256,1045,3345,513]

theorem envBound25242 : H12AffineFastState.Bounded env25242 := by
  intro p hp
  have h : env25242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25241_25242 : H12AffineEnvironment.transform 11 2064 env25241 = env25242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25241 == env25242) = true)

theorem identity25242 : scanCanonicalize (H12AffineFastState.compose env25242 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25242 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25243 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2064,269,2341,0,262,2356,2340,53,1,2048,33,16,2,268,17,2049,2357,2065,2341,305,32,256,32,2340,513]

theorem envBound25243 : H12AffineFastState.Bounded env25243 := by
  intro p hp
  have h : env25243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25242_25243 : H12AffineEnvironment.transform 9 53 env25242 = env25243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25242 == env25243) = true)

theorem identity25243 : scanCanonicalize (H12AffineFastState.compose env25243 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25244 : List Nat := [2,4,8,16,17,17,9,256,512,4,2048,2064,269,2324,0,262,2309,2325,4,1,2048,16,16,2,268,17,2049,2308,2065,2324,256,17,256,17,2325,513]

theorem envBound25244 : H12AffineFastState.Bounded env25244 := by
  intro p hp
  have h : env25244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25243_25244 : H12AffineEnvironment.transform 4 17 env25243 = env25244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25243 == env25244) = true)

theorem identity25244 : scanCanonicalize (H12AffineFastState.compose env25244 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound25244 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25245 : List Nat := [2,4,8,16,17,17,9,256,277,4,2048,2064,269,2324,0,262,2309,2325,4,1,2048,16,16,2,268,17,2049,2308,2065,2324,256,17,256,17,2325,276]

theorem envBound25245 : H12AffineFastState.Bounded env25245 := by
  intro p hp
  have h : env25245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25244_25245 : H12AffineEnvironment.transform 8 277 env25244 = env25245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env25244 == env25245) = true)

theorem identity25245 : scanCanonicalize (H12AffineFastState.compose env25245 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound25245 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25246 : List Nat := [2,4,8,16,17,17,9,5,16,4,2048,2064,8,2065,0,3,2048,2064,4,1,2048,16,16,2,9,17,2049,2049,2065,2065,5,17,5,17,2064,17]

theorem envBound25246 : H12AffineFastState.Bounded env25246 := by
  intro p hp
  have h : env25246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25245_25246 : H12AffineEnvironment.transform 7 5 env25245 = env25246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env25245 == env25246) = true)

theorem identity25246 : scanCanonicalize (H12AffineFastState.compose env25246 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25247 : List Nat := [2,4,8,0,1,1,9,5,0,4,2048,2048,8,2049,0,3,2048,2048,4,1,2048,0,0,2,9,1,2049,2049,2049,2049,5,1,5,1,2048,1]

theorem envBound25247 : H12AffineFastState.Bounded env25247 := by
  intro p hp
  have h : env25247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25246_25247 : H12AffineEnvironment.transform 3 0 env25246 = env25247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25246 == env25247) = true)

def env25248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound25248 : H12AffineFastState.Bounded env25248 := by
  intro p hp
  have h : env25248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25024_25248 : H12AffineEnvironment.transform 18 1025 env25024 = env25248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25024 == env25248) = true)

theorem identity25248 : scanCanonicalize (H12AffineFastState.compose env25248 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626079) := by decide +kernel

theorem selectedBound25248 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626079,8328,64,6677535,8626323,10507600,8830977,2334735,12796383,257,254131,196887,2263000]

theorem envBound25249 : H12AffineFastState.Bounded env25249 := by
  intro p hp
  have h : env25249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25248_25249 : H12AffineEnvironment.transform 23 10626079 env25248 = env25249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626079 env25248 == env25249) = true)

def env25250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155996,2114883,8328,64,6677535,115151,2241548,303453,2334735,4268163,257,254131,196887,2263000]

theorem envBound25250 : H12AffineFastState.Bounded env25250 := by
  intro p hp
  have h : env25250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25249_25250 : H12AffineEnvironment.transform 22 155996 env25249 = env25250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155996 env25249 == env25250) = true)

def env25251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155996,2114883,8328,64,215367,115151,2241548,303453,2334735,2592219,257,254131,196887,2263000]

theorem envBound25251 : H12AffineFastState.Bounded env25251 := by
  intro p hp
  have h : env25251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25250_25251 : H12AffineEnvironment.transform 21 2534744 env25250 = env25251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env25250 == env25251) = true)

def env25252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,21763,8328,64,215367,115151,140364,303453,241743,499099,257,254131,196887,169880]

theorem envBound25252 : H12AffineFastState.Bounded env25252 := by
  intro p hp
  have h : env25252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25251_25252 : H12AffineEnvironment.transform 20 4160 env25251 = env25252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25251 == env25252) = true)

theorem identity25252 : scanCanonicalize (H12AffineFastState.compose env25252 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound25252 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,412108,155996,21763,8328,64,215367,79131,140364,284041,214171,485711,257,201831,196887,156492]

theorem envBound25253 : H12AffineFastState.Bounded env25253 := by
  intro p hp
  have h : env25253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25252_25253 : H12AffineEnvironment.transform 14 29908 env25252 = env25253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env25252 == env25253) = true)

def env25254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,411972,155996,21763,8192,64,215367,79131,140364,283905,214035,485711,257,201831,196887,156492]

theorem envBound25254 : H12AffineFastState.Bounded env25254 := by
  intro p hp
  have h : env25254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25253_25254 : H12AffineEnvironment.transform 6 8 env25253 = env25254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25253 == env25254) = true)

theorem identity25254 : scanCanonicalize (H12AffineFastState.compose env25254 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound25254 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env25255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,131072,262144,1025,29789,4160,411972,155996,21763,8192,64,146508,16400,140364,283905,143640,400452,257,156012,160796,156492]

theorem envBound25255 : H12AffineFastState.Bounded env25255 := by
  intro p hp
  have h : env25255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25254_25255 : H12AffineEnvironment.transform 15 29963 env25254 = env25255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env25254 == env25255) = true)

theorem identity25255 : scanCanonicalize (H12AffineFastState.compose env25255 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound25255 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env25256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,131072,149860,1025,29789,4160,32,155996,21763,8192,64,146508,16400,140364,138341,143640,21792,257,156012,160796,156492]

theorem envBound25256 : H12AffineFastState.Bounded env25256 := by
  intro p hp
  have h : env25256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25255_25256 : H12AffineEnvironment.transform 17 149860 env25255 = env25256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env25255 == env25256) = true)

theorem identity25256 : scanCanonicalize (H12AffineFastState.compose env25256 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25256 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env25257 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,29963,131072,149813,1025,29708,4113,32,155917,21763,8192,17,146461,16400,140317,138292,143640,21792,257,155965,160796,156445]

theorem envBound25257 : H12AffineFastState.Bounded env25257 := by
  intro p hp
  have h : env25257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25256_25257 : H12AffineEnvironment.transform 5 17 env25256 = env25257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25256 == env25257) = true)

theorem identity25257 : scanCanonicalize (H12AffineFastState.compose env25257 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25257 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25258 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,131072,138293,1025,8460,4113,32,144397,3,8192,17,146461,5392,140317,138292,143640,32,257,144445,139548,144925]

theorem envBound25258 : H12AffineFastState.Bounded env25258 := by
  intro p hp
  have h : env25258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25257_25258 : H12AffineEnvironment.transform 13 5376 env25257 = env25258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25257 == env25258) = true)

theorem identity25258 : scanCanonicalize (H12AffineFastState.compose env25258 (packedSelected [0,2,3,5,7,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 12297) := by decide +kernel

theorem selectedBound25258 : packedSelected [0,2,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env25259 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,12297,11324,1025,8460,4113,32,1028,3,8192,17,3092,5392,5140,11325,273,32,257,1076,4373,1556]

theorem envBound25259 : H12AffineFastState.Bounded env25259 := by
  intro p hp
  have h : env25259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25258_25259 : H12AffineEnvironment.transform 16 12297 env25258 = env25259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12297 env25258 == env25259) = true)

theorem identity25259 : scanCanonicalize (H12AffineFastState.compose env25259 (packedSelected [3,4,5,6,9,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound25259 : packedSelected [3,4,5,6,9,10,16] rootPS < 2^1333 := by decide +kernel

def env25260 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,5376,33,295,4389,3344,1025,32,4113,32,1028,3,300,17,3092,5392,5140,3345,273,32,257,1076,4373,1556]

theorem envBound25260 : H12AffineFastState.Bounded env25260 := by
  intro p hp
  have h : env25260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25259_25260 : H12AffineEnvironment.transform 12 300 env25259 = env25260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env25259 == env25260) = true)

theorem identity25260 : scanCanonicalize (H12AffineFastState.compose env25260 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25260 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25261 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,269,5376,0,262,4356,3344,1025,1,4113,1,1028,3,269,17,3092,5392,5140,3345,273,1,257,1045,4373,1556]

theorem envBound25261 : H12AffineFastState.Bounded env25261 := by
  intro p hp
  have h : env25261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25260_25261 : H12AffineEnvironment.transform 4 1 env25260 = env25261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25260 == env25261) = true)

theorem identity25261 : scanCanonicalize (H12AffineFastState.compose env25261 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25261 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env25262 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,2064,269,3344,0,262,2324,3344,1025,1,2049,1,1028,3,269,17,3092,3328,3076,3345,273,1,257,1045,2309,1556]

theorem envBound25262 : H12AffineFastState.Bounded env25262 := by
  intro p hp
  have h : env25262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25261_25262 : H12AffineEnvironment.transform 11 2064 env25261 = env25262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25261 == env25262) = true)

theorem identity25262 : scanCanonicalize (H12AffineFastState.compose env25262 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound25262 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env25263 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1044,1028,269,260,0,262,1280,260,1025,1,1045,1,1028,3,269,17,0,276,16,261,273,1,257,1045,1297,1556]

theorem envBound25263 : H12AffineFastState.Bounded env25263 := by
  intro p hp
  have h : env25263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25262_25263 : H12AffineEnvironment.transform 10 1044 env25262 = env25263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env25262 == env25263) = true)

theorem identity25263 : scanCanonicalize (H12AffineFastState.compose env25263 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound25263 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25264 : List Nat := [2,4,8,16,1,17,8,256,512,21,1,17,269,260,0,262,277,260,20,1,0,1,17,3,269,17,0,276,16,261,273,1,257,0,260,513]

theorem envBound25264 : H12AffineFastState.Bounded env25264 := by
  intro p hp
  have h : env25264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25263_25264 : H12AffineEnvironment.transform 9 21 env25263 = env25264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env25263 == env25264) = true)

theorem identity25264 : scanCanonicalize (H12AffineFastState.compose env25264 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25265 : List Nat := [2,4,8,0,1,1,8,256,512,5,1,1,269,260,0,262,261,260,4,1,0,1,1,3,269,1,0,260,0,261,257,1,257,0,260,513]

theorem envBound25265 : H12AffineFastState.Bounded env25265 := by
  intro p hp
  have h : env25265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25264_25265 : H12AffineEnvironment.transform 3 0 env25264 = env25265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25264 == env25265) = true)

theorem identity25265 : scanCanonicalize (H12AffineFastState.compose env25265 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound25265 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25266 : List Nat := [2,4,8,0,1,1,8,256,260,5,1,1,269,260,0,262,261,260,4,1,0,1,1,3,269,1,0,260,0,261,257,1,257,0,260,261]

theorem envBound25266 : H12AffineFastState.Bounded env25266 := by
  intro p hp
  have h : env25266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25265_25266 : H12AffineEnvironment.transform 8 260 env25265 = env25266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env25265 == env25266) = true)

def env25267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,411973,155996,21763,8193,64,215367,79131,140364,283904,214034,485711,257,201831,196887,156492]

theorem envBound25267 : H12AffineFastState.Bounded env25267 := by
  intro p hp
  have h : env25267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25253_25267 : H12AffineEnvironment.transform 6 9 env25253 = env25267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25253 == env25267) = true)

def env25268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,21762,8328,64,215367,115151,140365,303453,241742,499098,257,254131,196887,169881]

theorem envBound25268 : H12AffineFastState.Bounded env25268 := by
  intro p hp
  have h : env25268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25251_25268 : H12AffineEnvironment.transform 20 4161 env25251 = env25268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25251 == env25268) = true)

theorem identity25268 : scanCanonicalize (H12AffineFastState.compose env25268 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound25268 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,21762,8328,64,75786,115151,17664,303453,119043,392407,257,98814,90202,63188]

theorem envBound25269 : H12AffineFastState.Bounded env25269 := by
  intro p hp
  have h : env25269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25268_25269 : H12AffineEnvironment.transform 16 24909 env25268 = env25269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env25268 == env25269) = true)

def env25270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,21762,8192,64,75786,115015,17664,303453,119043,392287,257,98678,90202,63068]

theorem envBound25270 : H12AffineFastState.Bounded env25270 := by
  intro p hp
  have h : env25270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25269_25270 : H12AffineEnvironment.transform 6 8 env25269 = env25270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25269 == env25270) = true)

theorem identity25270 : scanCanonicalize (H12AffineFastState.compose env25270 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound25270 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,56436,1025,32769,4161,32,17,21762,8192,64,75786,115015,17664,32041,119043,73771,257,98678,90202,63068]

theorem envBound25271 : H12AffineFastState.Bounded env25271 := by
  intro p hp
  have h : env25271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25270_25271 : H12AffineEnvironment.transform 17 56436 env25270 = env25271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env25270 == env25271) = true)

theorem identity25271 : scanCanonicalize (H12AffineFastState.compose env25271 (packedSelected [0,3,7,11,12,14,16,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25271 : packedSelected [0,3,7,11,12,14,16,20,24] rootPS < 2^1333 := by decide +kernel

def env25272 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,56356,1025,32769,4113,32,17,21762,8192,16,75786,114967,17664,32041,119043,73771,257,98598,90122,62988]

theorem envBound25272 : H12AffineFastState.Bounded env25272 := by
  intro p hp
  have h : env25272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25271_25272 : H12AffineEnvironment.transform 5 16 env25271 = env25272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25271 == env25272) = true)

theorem identity25272 : scanCanonicalize (H12AffineFastState.compose env25272 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound25272 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env25273 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,65536,24861,2340,1025,21761,4113,32,17,21762,8192,16,75786,70679,17664,32041,66563,73771,257,87078,90122,8972]

theorem envBound25273 : H12AffineFastState.Bounded env25273 := by
  intro p hp
  have h : env25273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25272_25273 : H12AffineEnvironment.transform 14 21760 env25272 = env25273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env25272 == env25273) = true)

theorem identity25273 : scanCanonicalize (H12AffineFastState.compose env25273 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound25273 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env25274 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,29963,24861,2340,1025,21761,4113,32,17,21762,8192,16,23809,24860,17664,32041,28936,21792,257,8493,5377,8972]

theorem envBound25274 : H12AffineFastState.Bounded env25274 := by
  intro p hp
  have h : env25274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25273_25274 : H12AffineEnvironment.transform 15 29963 env25273 = env25274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env25273 == env25274) = true)

theorem identity25274 : scanCanonicalize (H12AffineFastState.compose env25274 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound25274 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25275 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8460,263,5393,2340,1025,8461,4113,32,17,8462,8192,16,10509,5392,12556,2341,1284,8492,257,8493,5377,8972]

theorem envBound25275 : H12AffineFastState.Bounded env25275 := by
  intro p hp
  have h : env25275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25274_25275 : H12AffineEnvironment.transform 13 13324 env25274 = env25275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env25274 == env25275) = true)

theorem identity25275 : scanCanonicalize (H12AffineFastState.compose env25275 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25275 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env25276 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,8192,12345,8460,263,4388,2340,52,8461,4113,32,17,8462,8192,16,10509,4389,12556,2341,305,8492,257,8493,4404,8972]

theorem envBound25276 : H12AffineFastState.Bounded env25276 := by
  intro p hp
  have h : env25276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25275_25276 : H12AffineEnvironment.transform 9 53 env25275 = env25276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25275 == env25276) = true)

theorem identity25276 : scanCanonicalize (H12AffineFastState.compose env25276 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25276 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env25277 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,4112,293,263,4388,2340,52,292,4113,32,17,295,41,16,2340,4389,4389,2341,305,261,257,260,4404,805]

theorem envBound25277 : H12AffineFastState.Bounded env25277 := by
  intro p hp
  have h : env25277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25276_25277 : H12AffineEnvironment.transform 12 41 env25276 = env25277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25276 == env25277) = true)

theorem identity25277 : scanCanonicalize (H12AffineFastState.compose env25277 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25277 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env25278 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,41,4112,1,35,4096,2048,52,0,4113,32,17,3,41,16,2048,4097,4097,2049,21,33,37,32,4112,513]

theorem envBound25278 : H12AffineFastState.Bounded env25278 := by
  intro p hp
  have h : env25278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25277_25278 : H12AffineEnvironment.transform 7 36 env25277 = env25278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25277 == env25278) = true)

theorem identity25278 : scanCanonicalize (H12AffineFastState.compose env25278 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25279 : List Nat := [2,4,8,16,17,16,8,21,512,4,2048,4096,24,4112,1,18,4096,2048,5,0,4113,17,17,3,24,16,2048,4097,4097,2049,21,16,20,17,4112,513]

theorem envBound25279 : H12AffineFastState.Bounded env25279 := by
  intro p hp
  have h : env25279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25278_25279 : H12AffineEnvironment.transform 4 17 env25278 = env25279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25278 == env25279) = true)

theorem identity25279 : scanCanonicalize (H12AffineFastState.compose env25279 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound25279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25280 : List Nat := [2,4,8,16,17,16,8,21,512,4,513,4096,24,4112,1,18,4096,513,5,0,4113,17,17,3,24,16,513,4097,4097,512,21,16,20,17,4112,513]

theorem envBound25280 : H12AffineFastState.Bounded env25280 := by
  intro p hp
  have h : env25280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25279_25280 : H12AffineEnvironment.transform 10 513 env25279 = env25280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env25279 == env25280) = true)

theorem identity25280 : scanCanonicalize (H12AffineFastState.compose env25280 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25281 : List Nat := [2,4,8,16,17,16,8,21,512,4,513,16,24,0,1,18,16,513,5,0,1,17,17,3,24,16,513,17,17,512,21,16,20,17,0,513]

theorem envBound25281 : H12AffineFastState.Bounded env25281 := by
  intro p hp
  have h : env25281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25280_25281 : H12AffineEnvironment.transform 11 16 env25280 = env25281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25280 == env25281) = true)

theorem identity25281 : scanCanonicalize (H12AffineFastState.compose env25281 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25281 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25282 : List Nat := [2,4,8,16,17,16,8,21,1,4,0,16,24,0,1,18,16,0,5,0,1,17,17,3,24,16,0,17,17,1,21,16,20,17,0,0]

theorem envBound25282 : H12AffineFastState.Bounded env25282 := by
  intro p hp
  have h : env25282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25281_25282 : H12AffineEnvironment.transform 8 1 env25281 = env25282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25281 == env25282) = true)

def env25283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,21762,8193,64,75786,115014,17664,303453,119043,392286,257,98679,90202,63069]

theorem envBound25283 : H12AffineFastState.Bounded env25283 := by
  intro p hp
  have h : env25283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25269_25283 : H12AffineEnvironment.transform 6 9 env25269 = env25283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25269 == env25283) = true)

theorem identity25283 : scanCanonicalize (H12AffineFastState.compose env25283 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound25283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32040,1025,32769,4161,41340,17,21762,8193,64,75786,115014,17664,56437,119043,98678,257,98679,90202,63069]

theorem envBound25284 : H12AffineFastState.Bounded env25284 := by
  intro p hp
  have h : env25284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25283_25284 : H12AffineEnvironment.transform 17 32040 env25283 = env25284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env25283 == env25284) = true)

theorem identity25284 : scanCanonicalize (H12AffineFastState.compose env25284 (packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound25284 : packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env25285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41051,24909,32040,1025,32769,4161,41340,17,21762,8193,64,34897,24861,17664,56437,29016,8493,257,8492,49153,63069]

theorem envBound25285 : H12AffineFastState.Bounded env25285 := by
  intro p hp
  have h : env25285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25284_25285 : H12AffineEnvironment.transform 15 41051 env25284 = env25285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env25284 == env25285) = true)

theorem identity25285 : scanCanonicalize (H12AffineFastState.compose env25285 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25285 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,263,24909,32040,1025,8541,4161,32,17,21762,8193,64,10509,24861,17664,32041,29016,8493,257,8492,24925,22273]

theorem envBound25286 : H12AffineFastState.Bounded env25286 := by
  intro p hp
  have h : env25286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25285_25286 : H12AffineEnvironment.transform 14 8540 env25285 = env25286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25285 == env25286) = true)

theorem identity25286 : scanCanonicalize (H12AffineFastState.compose env25286 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound25286 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env25287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8540,263,13672,10509,1025,8541,4161,32,17,295,8193,64,10509,13624,4389,10508,9597,8493,257,8492,13688,804]

theorem envBound25287 : H12AffineFastState.Bounded env25287 := by
  intro p hp
  have h : env25287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25286_25287 : H12AffineEnvironment.transform 13 5157 env25286 = env25287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env25286 == env25287) = true)

theorem identity25287 : scanCanonicalize (H12AffineFastState.compose env25287 (packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound25287 : packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS < 2^1333 := by decide +kernel

def env25288 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5157,8232,115,13340,10361,1025,8233,4161,32,17,83,8193,64,10361,13388,4177,10360,9225,8281,117,8280,13324,592]

theorem envBound25288 : H12AffineFastState.Bounded env25288 := by
  intro p hp
  have h : env25288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25287_25288 : H12AffineEnvironment.transform 7 116 env25287 = env25288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env25287 == env25288) = true)

def env25289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155996,2114883,8328,64,215366,115151,2241548,303453,2334735,2592218,257,254131,196887,2263000]

theorem envBound25289 : H12AffineFastState.Bounded env25289 := by
  intro p hp
  have h : env25289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25250_25289 : H12AffineEnvironment.transform 21 2534745 env25250 = env25289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env25250 == env25289) = true)

def env25290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,21763,8328,64,215366,115151,140364,303453,241743,499098,257,254131,196887,169880]

theorem envBound25290 : H12AffineFastState.Bounded env25290 := by
  intro p hp
  have h : env25290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25289_25290 : H12AffineEnvironment.transform 20 4160 env25289 = env25290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25289 == env25290) = true)

theorem identity25290 : scanCanonicalize (H12AffineFastState.compose env25290 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound25290 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,272512,62661,21763,8328,64,122079,115151,45525,303453,75222,329731,257,95530,103566,513]

theorem envBound25291 : H12AffineFastState.Bounded env25291 := by
  intro p hp
  have h : env25291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25290_25291 : H12AffineEnvironment.transform 16 38297 env25290 = env25291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env25290 == env25291) = true)

def env25292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272392,62541,21763,8192,64,121943,115015,45405,303453,75102,329731,257,95530,103430,513]

theorem envBound25292 : H12AffineFastState.Bounded env25292 := by
  intro p hp
  have h : env25292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25291_25292 : H12AffineEnvironment.transform 6 8 env25291 = env25292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25291 == env25292) = true)

def env25293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,32,62541,21763,8192,64,121943,115015,45405,35189,75102,73771,257,95530,103430,513]

theorem envBound25293 : H12AffineFastState.Bounded env25293 := by
  intro p hp
  have h : env25293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25292_25293 : H12AffineEnvironment.transform 17 10280 env25292 = env25293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25292 == env25293) = true)

theorem identity25293 : scanCanonicalize (H12AffineFastState.compose env25293 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound25293 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,24908,10280,1025,29788,4160,32,16,21763,8192,64,75786,79130,17664,32040,75102,73771,257,95530,90203,513]

theorem envBound25294 : H12AffineFastState.Bounded env25294 := by
  intro p hp
  have h : env25294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25293_25294 : H12AffineEnvironment.transform 14 29789 env25293 = env25294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env25293 == env25294) = true)

theorem identity25294 : scanCanonicalize (H12AffineFastState.compose env25294 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound25294 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env25295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,16384,17728,65536,20561,6453,1025,17729,4160,32,16,21763,4381,64,71959,66567,17664,19509,70723,69942,257,82999,86342,513]

theorem envBound25295 : H12AffineFastState.Bounded env25295 := by
  intro p hp
  have h : env25295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25294_25295 : H12AffineEnvironment.transform 12 4381 env25294 = env25295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env25294 == env25295) = true)

theorem identity25295 : scanCanonicalize (H12AffineFastState.compose env25295 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound25295 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,16384,17728,342,20561,6453,1025,17729,4160,32,16,21763,4381,64,6209,1361,17664,19509,5397,4192,257,17761,20496,513]

theorem envBound25296 : H12AffineFastState.Bounded env25296 := by
  intro p hp
  have h : env25296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25295_25296 : H12AffineEnvironment.transform 15 342 env25295 = env25296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env25295 == env25296) = true)

theorem identity25296 : scanCanonicalize (H12AffineFastState.compose env25296 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound25296 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,1344,0,342,5393,6453,1025,1,4160,32,16,4163,4381,64,6209,1361,64,2421,5397,4192,257,33,5456,513]

theorem envBound25297 : H12AffineFastState.Bounded env25297 := by
  intro p hp
  have h : env25297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25296_25297 : H12AffineEnvironment.transform 13 1344 env25296 = env25297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env25296 == env25297) = true)

theorem identity25297 : scanCanonicalize (H12AffineFastState.compose env25297 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound25297 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1100,1344,0,342,64,3172,1025,1,1297,32,16,1298,1100,64,3344,1361,64,2421,68,1329,257,33,1,513]

theorem envBound25298 : H12AffineFastState.Bounded env25298 := by
  intro p hp
  have h : env25298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25297_25298 : H12AffineEnvironment.transform 11 1361 env25297 = env25298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env25297 == env25298) = true)

theorem identity25298 : scanCanonicalize (H12AffineFastState.compose env25298 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound25298 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1361,1100,1344,0,342,64,372,1025,1,1297,32,16,1298,1100,64,0,1361,64,1125,68,1329,257,33,1,513]

theorem envBound25299 : H12AffineFastState.Bounded env25299 := by
  intro p hp
  have h : env25299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25298_25299 : H12AffineEnvironment.transform 10 1296 env25298 = env25299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env25298 == env25299) = true)

theorem identity25299 : scanCanonicalize (H12AffineFastState.compose env25299 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound25299 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25300 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,1061,1100,1076,0,34,64,0,1025,1,1125,32,16,1126,1100,64,0,1061,64,1125,68,1093,117,33,1,513]

theorem envBound25300 : H12AffineFastState.Bounded env25300 := by
  intro p hp
  have h : env25300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25299_25300 : H12AffineEnvironment.transform 7 116 env25299 = env25300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env25299 == env25300) = true)

theorem identity25300 : scanCanonicalize (H12AffineFastState.compose env25300 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25300 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25301 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,17,120,0,0,34,64,0,53,1,81,32,16,82,120,64,0,17,64,81,68,113,117,33,1,513]

theorem envBound25301 : H12AffineFastState.Bounded env25301 := by
  intro p hp
  have h : env25301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25300_25301 : H12AffineEnvironment.transform 9 52 env25300 = env25301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25300 == env25301) = true)

theorem identity25301 : scanCanonicalize (H12AffineFastState.compose env25301 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25301 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env25302 : List Nat := [2,4,8,0,32,64,8,100,512,36,64,1,104,0,0,34,64,0,37,1,65,32,0,66,104,64,0,1,64,65,68,97,101,33,1,513]

theorem envBound25302 : H12AffineFastState.Bounded env25302 := by
  intro p hp
  have h : env25302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25301_25302 : H12AffineEnvironment.transform 3 0 env25301 = env25302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25301 == env25302) = true)

theorem identity25302 : scanCanonicalize (H12AffineFastState.compose env25302 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25302 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25303 : List Nat := [2,4,8,0,32,1,8,37,512,36,1,1,41,0,0,34,1,0,37,1,0,32,0,3,41,1,0,1,1,0,5,32,36,33,1,513]

theorem envBound25303 : H12AffineFastState.Bounded env25303 := by
  intro p hp
  have h : env25303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25302_25303 : H12AffineEnvironment.transform 5 1 env25302 = env25303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25302 == env25303) = true)

theorem identity25303 : scanCanonicalize (H12AffineFastState.compose env25303 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25303 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25304 : List Nat := [2,4,8,0,11,1,8,14,512,15,1,1,2,0,0,9,1,0,14,1,0,11,0,3,2,1,0,1,1,0,5,11,15,10,1,513]

theorem envBound25304 : H12AffineFastState.Bounded env25304 := by
  intro p hp
  have h : env25304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25303_25304 : H12AffineEnvironment.transform 4 11 env25303 = env25304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25303 == env25304) = true)

def env25305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,33,62541,21763,8192,64,121943,115015,45405,35188,75102,73770,257,95530,103430,513]

theorem envBound25305 : H12AffineFastState.Bounded env25305 := by
  intro p hp
  have h : env25305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25292_25305 : H12AffineEnvironment.transform 17 10281 env25292 = env25305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25292 == env25305) = true)

theorem identity25305 : scanCanonicalize (H12AffineFastState.compose env25305 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound25305 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env25306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,65536,5441,10281,1025,81,4160,33,29725,21763,8192,64,89095,82199,12557,2340,75102,73770,257,95530,70742,513]

theorem envBound25306 : H12AffineFastState.Bounded env25306 := by
  intro p hp
  have h : env25306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25305_25306 : H12AffineEnvironment.transform 14 80 env25305 = env25306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env25305 == env25306) = true)

theorem identity25306 : scanCanonicalize (H12AffineFastState.compose env25306 (packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound25306 : packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env25307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,21510,5441,10281,1025,81,4160,33,29725,21763,8192,64,2049,5393,12557,2340,29016,29740,257,8492,16464,513]

theorem envBound25307 : H12AffineFastState.Bounded env25307 := by
  intro p hp
  have h : env25307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25306_25307 : H12AffineEnvironment.transform 15 21510 env25306 = env25307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env25306 == env25307) = true)

theorem identity25307 : scanCanonicalize (H12AffineFastState.compose env25307 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25307 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env25308 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,21510,5392,10281,1025,0,4113,33,29725,21763,8192,17,2049,5393,12557,2340,28937,29740,257,8492,16385,513]

theorem envBound25308 : H12AffineFastState.Bounded env25308 := by
  intro p hp
  have h : env25308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25307_25308 : H12AffineEnvironment.transform 5 17 env25307 = env25308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25307 == env25308) = true)

theorem identity25308 : scanCanonicalize (H12AffineFastState.compose env25308 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound25308 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25309 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,1,8202,5392,10281,1025,0,4113,33,17,8463,8192,17,2049,5393,12557,2340,1285,32,257,8492,13325,513]

theorem envBound25309 : H12AffineFastState.Bounded env25309 := by
  intro p hp
  have h : env25309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25308_25309 : H12AffineEnvironment.transform 13 13324 env25308 = env25309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env25308 == env25309) = true)

theorem identity25309 : scanCanonicalize (H12AffineFastState.compose env25309 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound25309 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env25310 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1588,8192,8760,1,8202,804,10281,1025,0,1573,33,17,8463,8192,17,2049,805,10041,2340,1285,32,257,8492,8761,513]

theorem envBound25310 : H12AffineFastState.Bounded env25310 := by
  intro p hp
  have h : env25310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25309_25310 : H12AffineEnvironment.transform 11 1588 env25309 = env25310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env25309 == env25310) = true)

theorem identity25310 : scanCanonicalize (H12AffineFastState.compose env25310 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25310 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25311 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1588,269,821,1,263,804,2340,1025,0,1573,33,17,2,269,17,2049,805,1588,2340,1285,32,257,33,820,513]

theorem envBound25311 : H12AffineFastState.Bounded env25311 := by
  intro p hp
  have h : env25311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25310_25311 : H12AffineEnvironment.transform 12 269 env25310 = env25311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25310 == env25311) = true)

theorem identity25311 : scanCanonicalize (H12AffineFastState.compose env25311 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25312 : List Nat := [2,4,8,16,32,17,8,20,512,1024,2048,1588,25,545,1,19,560,2096,1025,0,1573,33,17,2,25,17,2049,561,1588,2096,1041,32,21,33,544,513]

theorem envBound25312 : H12AffineFastState.Bounded env25312 := by
  intro p hp
  have h : env25312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25311_25312 : H12AffineEnvironment.transform 7 20 env25311 = env25312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25311 == env25312) = true)

theorem identity25312 : scanCanonicalize (H12AffineFastState.compose env25312 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound25312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25313 : List Nat := [2,4,8,16,32,17,8,20,512,1024,539,1588,25,545,1,19,560,555,1025,0,1573,33,17,2,25,17,538,561,1588,555,1041,32,21,33,544,513]

theorem envBound25313 : H12AffineFastState.Bounded env25313 := by
  intro p hp
  have h : env25313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25312_25313 : H12AffineEnvironment.transform 10 539 env25312 = env25313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env25312 == env25313) = true)

theorem identity25313 : scanCanonicalize (H12AffineFastState.compose env25313 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound25313 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25314 : List Nat := [2,4,8,16,32,17,8,20,17,1024,10,1061,25,48,1,19,33,58,1025,0,1076,33,17,2,25,17,11,32,1061,58,1041,32,21,33,49,16]

theorem envBound25314 : H12AffineFastState.Bounded env25314 := by
  intro p hp
  have h : env25314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25313_25314 : H12AffineEnvironment.transform 8 17 env25313 = env25314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env25313 == env25314) = true)

theorem identity25314 : scanCanonicalize (H12AffineFastState.compose env25314 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound25314 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25315 : List Nat := [2,4,8,16,32,17,8,20,17,15,10,42,25,48,1,19,33,58,14,0,59,33,17,2,25,17,11,32,42,58,30,32,21,33,49,16]

theorem envBound25315 : H12AffineFastState.Bounded env25315 := by
  intro p hp
  have h : env25315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25314_25315 : H12AffineEnvironment.transform 9 15 env25314 = env25315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env25314 == env25315) = true)

theorem identity25315 : scanCanonicalize (H12AffineFastState.compose env25315 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25315 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25316 : List Nat := [2,4,8,16,11,17,8,20,17,15,10,1,25,27,1,19,10,17,14,0,16,10,17,2,25,17,11,11,1,17,30,11,21,10,26,16]

theorem envBound25316 : H12AffineFastState.Bounded env25316 := by
  intro p hp
  have h : env25316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25315_25316 : H12AffineEnvironment.transform 4 11 env25315 = env25316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25315 == env25316) = true)

theorem identity25316 : scanCanonicalize (H12AffineFastState.compose env25316 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25317 : List Nat := [2,4,8,4,11,5,8,0,5,15,10,1,13,15,1,7,10,5,14,0,4,10,5,2,13,5,11,11,1,5,10,11,1,10,14,4]

theorem envBound25317 : H12AffineFastState.Bounded env25317 := by
  intro p hp
  have h : env25317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25316_25317 : H12AffineEnvironment.transform 3 4 env25316 = env25317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25316 == env25317) = true)

theorem identity25317 : scanCanonicalize (H12AffineFastState.compose env25317 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25318 : List Nat := [2,4,5,4,6,5,5,0,5,2,7,1,0,2,1,7,7,5,3,0,4,7,5,2,0,5,6,6,1,5,7,6,1,7,3,4]

theorem envBound25318 : H12AffineFastState.Bounded env25318 := by
  intro p hp
  have h : env25318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25317_25318 : H12AffineEnvironment.transform 2 5 env25317 = env25318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25317 == env25318) = true)

theorem identity25318 : scanCanonicalize (H12AffineFastState.compose env25318 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound25318 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env25319 : List Nat := [2,2,3,2,0,3,3,0,3,2,1,1,0,2,1,1,1,3,3,0,2,1,3,2,0,3,0,0,1,3,1,0,1,1,3,2]

theorem envBound25319 : H12AffineFastState.Bounded env25319 := by
  intro p hp
  have h : env25319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25318_25319 : H12AffineEnvironment.transform 1 2 env25318 = env25319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env25318 == env25319) = true)

def env25320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272393,62540,21763,8193,64,121942,115014,45404,303453,75103,329731,257,95530,103431,513]

theorem envBound25320 : H12AffineFastState.Bounded env25320 := by
  intro p hp
  have h : env25320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25291_25320 : H12AffineEnvironment.transform 6 9 env25291 = env25320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25291 == env25320) = true)

theorem identity25320 : scanCanonicalize (H12AffineFastState.compose env25320 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound25320 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4160,272393,62540,21763,8193,64,10588,13388,45404,303453,53333,326921,257,32800,24845,513]

theorem envBound25321 : H12AffineFastState.Bounded env25321 := by
  intro p hp
  have h : env25321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25320_25321 : H12AffineEnvironment.transform 15 62730 env25320 = env25321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env25320 == env25321) = true)

theorem identity25321 : scanCanonicalize (H12AffineFastState.compose env25321 (packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound25321 : packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS < 2^1333 := by decide +kernel

def env25322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1124,29038,4468,262144,1025,1125,4160,272393,28712,21763,8193,64,10588,13388,13624,271673,21553,293229,257,1092,24845,513]

theorem envBound25322 : H12AffineFastState.Bounded env25322 := by
  intro p hp
  have h : env25322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25321_25322 : H12AffineEnvironment.transform 14 1124 env25321 = env25322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env25321 == env25322) = true)

theorem identity25322 : scanCanonicalize (H12AffineFastState.compose env25322 (packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25322 : packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS < 2^1333 := by decide +kernel

def env25323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,1124,8575,4468,262144,1025,1125,4160,272393,8249,1298,8193,64,10588,13388,13624,271673,1056,272764,257,1092,12572,513]

theorem envBound25323 : H12AffineFastState.Bounded env25323 := by
  intro p hp
  have h : env25323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25322_25323 : H12AffineEnvironment.transform 13 4113 env25322 = env25323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25322 == env25323) = true)

theorem identity25323 : scanCanonicalize (H12AffineFastState.compose env25323 (packedSelected [2,6,7,14,20,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25323 : packedSelected [2,6,7,14,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env25324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4113,1124,342,4468,262144,1025,1125,4160,264224,16,1298,40,64,2421,5221,5393,263440,1056,264533,257,1092,4405,513]

theorem envBound25324 : H12AffineFastState.Bounded env25324 := by
  intro p hp
  have h : env25324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25323_25324 : H12AffineEnvironment.transform 12 41 env25323 = env25324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25323 == env25324) = true)

theorem identity25324 : scanCanonicalize (H12AffineFastState.compose env25324 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound25324 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4113,1124,342,4468,3172,1025,1125,4160,1092,16,1298,40,64,2421,5221,5393,2420,1056,1329,257,1092,4405,513]

theorem envBound25325 : H12AffineFastState.Bounded env25325 := by
  intro p hp
  have h : env25325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25324_25325 : H12AffineEnvironment.transform 17 3172 env25324 = env25325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env25324 == env25325) = true)

theorem identity25325 : scanCanonicalize (H12AffineFastState.compose env25325 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25325 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25326 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4113,373,342,4468,2421,272,372,4160,341,16,3,40,64,2421,4468,4096,2420,305,32,257,341,4405,513]

theorem envBound25326 : H12AffineFastState.Bounded env25326 := by
  intro p hp
  have h : env25326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25325_25326 : H12AffineEnvironment.transform 9 273 env25325 = env25326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25325 == env25326) = true)

theorem identity25326 : scanCanonicalize (H12AffineFastState.compose env25326 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25326 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env25327 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,41,4113,292,263,4389,2340,272,293,4113,260,16,3,40,17,2340,4389,4096,2341,305,32,257,260,4405,513]

theorem envBound25327 : H12AffineFastState.Bounded env25327 := by
  intro p hp
  have h : env25327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25326_25327 : H12AffineEnvironment.transform 5 17 env25326 = env25327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25326 == env25327) = true)

theorem identity25327 : scanCanonicalize (H12AffineFastState.compose env25327 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound25327 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25328 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2357,41,2340,292,263,2064,2340,272,293,2340,260,16,3,40,17,2340,2064,2357,2341,305,32,257,260,2048,513]

theorem envBound25328 : H12AffineFastState.Bounded env25328 := by
  intro p hp
  have h : env25328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25327_25328 : H12AffineEnvironment.transform 11 2357 env25327 = env25328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env25327 == env25328) = true)

theorem identity25328 : scanCanonicalize (H12AffineFastState.compose env25328 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

end H12CloudChart1