import H12CloudChart1Data106

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans27109_27110 : H12AffineEnvironment.transform 8 17 env27109 = env27110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env27109 == env27110) = true)

theorem identity27110 : scanCanonicalize (H12AffineFastState.compose env27110 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 59) := by decide +kernel

theorem selectedBound27110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27111 : List Nat := [2,4,8,16,32,16,8,36,17,52,2048,59,41,43,1,35,59,2049,52,0,43,32,17,2,41,17,2048,58,58,2049,20,32,36,32,43,16]

theorem envBound27111 : H12AffineFastState.Bounded env27111 := by
  intro p hp
  have h : env27111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27110_27111 : H12AffineEnvironment.transform 11 59 env27110 = env27111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 59 env27110 == env27111) = true)

def env27112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510122,499129,8328,65,349474,395637,495035,67754,119042,272393,256,98815,90203,63189]

theorem envBound27112 : H12AffineFastState.Bounded env27112 := by
  intro p hp
  have h : env27112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27084_27112 : H12AffineEnvironment.transform 20 4161 env27084 = env27112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27084 == env27112) = true)

def env27113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4161,180273,253962,242969,8328,65,97666,139733,238875,67754,119042,169,256,98815,90203,63189]

theorem envBound27113 : H12AffineFastState.Bounded env27113 := by
  intro p hp
  have h : env27113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27112_27113 : H12AffineEnvironment.transform 17 10400 env27112 = env27113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27112 == env27113) = true)

def env27114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180273,253962,242969,8192,65,97546,139613,238875,67618,119042,33,256,98679,90203,63069]

theorem envBound27114 : H12AffineFastState.Bounded env27114 := by
  intro p hp
  have h : env27114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27113_27114 : H12AffineEnvironment.transform 6 8 env27113 = env27114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27113 == env27114) = true)

theorem identity27114 : scanCanonicalize (H12AffineFastState.compose env27114 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound27114 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1024,32769,4161,95530,21777,2,8192,65,97546,103494,4096,67618,119042,33,256,98679,90203,63069]

theorem envBound27115 : H12AffineFastState.Bounded env27115 := by
  intro p hp
  have h : env27115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27114_27115 : H12AffineEnvironment.transform 16 111899 env27114 = env27115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env27114 == env27115) = true)

theorem identity27115 : scanCanonicalize (H12AffineFastState.compose env27115 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27115 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,103494,2421,1024,32769,4161,87159,21777,2,349,65,89175,103494,4096,67618,119042,33,256,98679,82182,55040]

theorem envBound27116 : H12AffineFastState.Bounded env27116 := by
  intro p hp
  have h : env27116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27115_27116 : H12AffineEnvironment.transform 12 349 env27115 = env27116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27115 == env27116) = true)

theorem identity27116 : scanCanonicalize (H12AffineFastState.compose env27116 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound27116 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,38161,2421,1024,32769,4161,21792,21777,2,349,65,23808,38161,4096,2421,53333,33,256,32800,16465,55040]

theorem envBound27117 : H12AffineFastState.Bounded env27117 := by
  intro p hp
  have h : env27117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27116_27117 : H12AffineEnvironment.transform 15 343 env27116 = env27117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env27116 == env27117) = true)

theorem identity27117 : scanCanonicalize (H12AffineFastState.compose env27117 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound27117 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env27118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,343,5441,2421,1024,81,4161,21792,21777,2,349,65,23808,5441,4096,2421,20485,33,256,112,16465,22352]

theorem envBound27118 : H12AffineFastState.Bounded env27118 := by
  intro p hp
  have h : env27118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27117_27118 : H12AffineEnvironment.transform 14 80 env27117 = env27118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env27117 == env27118) = true)

theorem identity27118 : scanCanonicalize (H12AffineFastState.compose env27118 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27118 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27119 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,80,115,5221,2129,1024,81,4161,21508,21557,2,121,65,23588,5221,4096,2129,20485,33,36,112,16465,22132]

theorem envBound27119 : H12AffineFastState.Bounded env27119 := by
  intro p hp
  have h : env27119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27118_27119 : H12AffineEnvironment.transform 7 36 env27118 = env27119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27118 == env27119) = true)

theorem identity27119 : scanCanonicalize (H12AffineFastState.compose env27119 (packedSelected [3,5,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound27119 : packedSelected [3,5,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27120 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,3173,80,115,5221,2129,1024,81,4161,6241,6224,2,121,65,4161,5221,4096,2129,7264,33,36,112,3124,6673]

theorem envBound27120 : H12AffineFastState.Bounded env27120 := by
  intro p hp
  have h : env27120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27119_27120 : H12AffineEnvironment.transform 13 3173 env27119 = env27120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env27119 == env27120) = true)

theorem identity27120 : scanCanonicalize (H12AffineFastState.compose env27120 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound27120 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env27121 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2113,121,3173,80,115,3108,2129,1024,81,2048,32,17,2,121,65,2048,3108,2113,2129,1057,33,36,112,3124,592]

theorem envBound27121 : H12AffineFastState.Bounded env27121 := by
  intro p hp
  have h : env27121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27120_27121 : H12AffineEnvironment.transform 11 2113 env27120 = env27121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env27120 == env27121) = true)

theorem identity27121 : scanCanonicalize (H12AffineFastState.compose env27121 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27121 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27122 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2065,41,3125,0,35,3108,2049,1024,1,2048,32,17,2,41,17,2048,3108,2065,2049,1057,33,36,32,3124,512]

theorem envBound27122 : H12AffineFastState.Bounded env27122 := by
  intro p hp
  have h : env27122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27121_27122 : H12AffineEnvironment.transform 5 16 env27121 = env27122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27121 == env27122) = true)

theorem identity27122 : scanCanonicalize (H12AffineFastState.compose env27122 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound27122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27123 : List Nat := [2,4,8,16,32,16,8,36,512,20,2048,2065,41,2081,0,35,2096,2049,20,1,2048,32,17,2,41,17,2048,2096,2065,2049,53,33,36,32,2080,512]

theorem envBound27123 : H12AffineFastState.Bounded env27123 := by
  intro p hp
  have h : env27123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27122_27123 : H12AffineEnvironment.transform 9 20 env27122 = env27123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env27122 == env27123) = true)

theorem identity27123 : scanCanonicalize (H12AffineFastState.compose env27123 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27123 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27124 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,2065,8,2048,0,2,2065,2049,20,1,2048,1,17,2,8,17,2048,2065,2065,2049,20,0,5,1,2049,512]

theorem envBound27124 : H12AffineFastState.Bounded env27124 := by
  intro p hp
  have h : env27124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27123_27124 : H12AffineEnvironment.transform 4 1 env27123 = env27124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27123 == env27124) = true)

theorem identity27124 : scanCanonicalize (H12AffineFastState.compose env27124 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27125 : List Nat := [2,4,8,16,1,16,8,5,0,20,2048,2065,8,2048,0,2,2065,2049,20,1,2048,1,17,2,8,17,2048,2065,2065,2049,20,0,5,1,2049,0]

theorem envBound27125 : H12AffineFastState.Bounded env27125 := by
  intro p hp
  have h : env27125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27124_27125 : H12AffineEnvironment.transform 8 0 env27124 = env27125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27124 == env27125) = true)

theorem identity27125 : scanCanonicalize (H12AffineFastState.compose env27125 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound27125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27126 : List Nat := [2,4,8,16,1,16,8,5,0,20,14,31,8,14,0,2,31,15,20,1,14,1,17,2,8,17,14,31,31,15,20,0,5,1,15,0]

theorem envBound27126 : H12AffineFastState.Bounded env27126 := by
  intro p hp
  have h : env27126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27125_27126 : H12AffineEnvironment.transform 10 14 env27125 = env27126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env27125 == env27126) = true)

def env27127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180273,253962,242969,8193,65,97547,139612,238875,67619,119042,32,256,98678,90203,63068]

theorem envBound27127 : H12AffineFastState.Bounded env27127 := by
  intro p hp
  have h : env27127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27113_27127 : H12AffineEnvironment.transform 6 9 env27113 = env27127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27113 == env27127) = true)

theorem identity27127 : scanCanonicalize (H12AffineFastState.compose env27127 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound27127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10281,1024,32769,4161,119927,62540,41311,8193,65,97547,79130,45405,67619,119042,32,256,98678,90203,63068]

theorem envBound27128 : H12AffineFastState.Bounded env27128 := by
  intro p hp
  have h : env27128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27127_27128 : H12AffineEnvironment.transform 16 70726 env27127 = env27128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env27127 == env27128) = true)

theorem identity27128 : scanCanonicalize (H12AffineFastState.compose env27128 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27128 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env27129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,70726,10281,1024,8540,4161,95530,21777,2,8193,65,97547,79130,4096,67619,94303,32,256,73771,90203,22273]

theorem envBound27129 : H12AffineFastState.Bounded env27129 := by
  intro p hp
  have h : env27129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27128_27129 : H12AffineEnvironment.transform 14 8541 env27128 = env27129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27128 == env27129) = true)

theorem identity27129 : scanCanonicalize (H12AffineFastState.compose env27129 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound27129 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS < 2^1333 := by decide +kernel

def env27130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,65536,70726,10281,1024,8540,4161,74078,357,2,8193,65,76159,79130,4096,67619,74795,32,256,73771,78895,885]

theorem envBound27130 : H12AffineFastState.Bounded env27130 := by
  intro p hp
  have h : env27130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27129_27130 : H12AffineEnvironment.transform 13 5236 env27129 = env27130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env27129 == env27130) = true)

theorem identity27130 : scanCanonicalize (H12AffineFastState.compose env27130 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound27130 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env27131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,1047,4177,10281,1024,8540,4161,9545,357,2,8193,65,11624,12557,4096,3124,8252,32,256,9276,12344,885]

theorem envBound27131 : H12AffineFastState.Bounded env27131 := by
  intro p hp
  have h : env27131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27130_27131 : H12AffineEnvironment.transform 15 1047 env27130 = env27131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env27130 == env27131) = true)

theorem identity27131 : scanCanonicalize (H12AffineFastState.compose env27131 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27131 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,373,1047,4177,2049,1024,372,4161,1377,357,2,41,65,3392,4389,4096,3124,20,32,256,1044,4112,885]

theorem envBound27132 : H12AffineFastState.Bounded env27132 := by
  intro p hp
  have h : env27132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27131_27132 : H12AffineEnvironment.transform 12 40 env27131 = env27132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27131 == env27132) = true)

theorem identity27132 : scanCanonicalize (H12AffineFastState.compose env27132 (packedSelected [11,18] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound27132 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env27133 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,40,4113,373,114,4177,2049,101,372,4161,260,357,2,41,65,2341,4389,4096,2129,20,32,256,113,4112,885]

theorem envBound27133 : H12AffineFastState.Bounded env27133 := by
  intro p hp
  have h : env27133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27132_27133 : H12AffineEnvironment.transform 9 101 env27132 = env27133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env27132 == env27133) = true)

theorem identity27133 : scanCanonicalize (H12AffineFastState.compose env27133 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27133 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27134 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,40,4113,1,114,4177,2049,101,0,4161,112,17,2,41,65,2129,4177,4096,2129,20,32,116,113,4112,513]

theorem envBound27134 : H12AffineFastState.Bounded env27134 := by
  intro p hp
  have h : env27134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27133_27134 : H12AffineEnvironment.transform 7 116 env27133 = env27134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27133 == env27134) = true)

theorem identity27134 : scanCanonicalize (H12AffineFastState.compose env27134 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27134 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27135 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,40,4113,1,34,4097,2049,53,0,4113,32,17,2,41,17,2049,4097,4096,2049,20,32,36,33,4112,513]

theorem envBound27135 : H12AffineFastState.Bounded env27135 := by
  intro p hp
  have h : env27135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27134_27135 : H12AffineEnvironment.transform 5 16 env27134 = env27135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27134 == env27135) = true)

theorem identity27135 : scanCanonicalize (H12AffineFastState.compose env27135 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound27135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27136 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,545,40,560,1,34,544,2049,53,0,560,32,17,2,41,17,2049,544,545,2049,20,32,36,33,561,513]

theorem envBound27136 : H12AffineFastState.Bounded env27136 := by
  intro p hp
  have h : env27136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27135_27136 : H12AffineEnvironment.transform 11 545 env27135 = env27136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env27135 == env27136) = true)

theorem identity27136 : scanCanonicalize (H12AffineFastState.compose env27136 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound27136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27137 : List Nat := [2,4,8,16,32,16,9,36,512,53,49,545,40,560,1,34,544,48,53,0,560,32,17,2,41,17,48,544,545,48,20,32,36,33,561,513]

theorem envBound27137 : H12AffineFastState.Bounded env27137 := by
  intro p hp
  have h : env27137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27136_27137 : H12AffineEnvironment.transform 10 49 env27136 = env27137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env27136 == env27137) = true)

theorem identity27137 : scanCanonicalize (H12AffineFastState.compose env27137 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound27137 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27138 : List Nat := [2,4,8,16,32,16,9,36,48,53,49,17,40,0,1,34,16,48,53,0,0,32,17,2,41,17,48,16,17,48,20,32,36,33,1,49]

theorem envBound27138 : H12AffineFastState.Bounded env27138 := by
  intro p hp
  have h : env27138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27137_27138 : H12AffineEnvironment.transform 8 48 env27137 = env27138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env27137 == env27138) = true)

theorem identity27138 : scanCanonicalize (H12AffineFastState.compose env27138 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27138 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27139 : List Nat := [2,4,8,16,16,16,9,20,0,5,1,17,24,0,1,18,16,0,5,0,0,16,17,2,25,17,0,16,17,0,20,16,20,17,1,1]

theorem envBound27139 : H12AffineFastState.Bounded env27139 := by
  intro p hp
  have h : env27139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27138_27139 : H12AffineEnvironment.transform 4 16 env27138 = env27139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27138 == env27139) = true)

def env27140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4161,180273,253963,242968,8328,65,97667,139732,238874,67754,119042,168,256,98815,90203,63189]

theorem envBound27140 : H12AffineFastState.Bounded env27140 := by
  intro p hp
  have h : env27140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27112_27140 : H12AffineEnvironment.transform 17 10401 env27112 = env27140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27112 == env27140) = true)

def env27141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180273,253963,242968,8192,65,97547,139612,238874,67618,119042,32,256,98679,90203,63069]

theorem envBound27141 : H12AffineFastState.Bounded env27141 := by
  intro p hp
  have h : env27141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27140_27141 : H12AffineEnvironment.transform 6 8 env27140 = env27141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27140 == env27141) = true)

theorem identity27141 : scanCanonicalize (H12AffineFastState.compose env27141 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27141 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4161,169265,242955,242968,8192,65,75787,139612,238874,67618,99330,32,256,98679,79195,41821]

theorem envBound27142 : H12AffineFastState.Bounded env27142 := by
  intro p hp
  have h : env27142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27141_27142 : H12AffineEnvironment.transform 13 5376 env27141 = env27142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27141 == env27142) = true)

theorem identity27142 : scanCanonicalize (H12AffineFastState.compose env27142 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 36945) := by decide +kernel

theorem selectedBound27142 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env27143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,36945,10281,1024,32769,4161,1376,75098,75081,8192,65,75787,45325,79179,67618,99330,32,256,98679,79195,41821]

theorem envBound27143 : H12AffineFastState.Bounded env27143 := by
  intro p hp
  have h : env27143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27142_27143 : H12AffineEnvironment.transform 16 36945 env27142 = env27143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 36945 env27142 == env27143) = true)

theorem identity27143 : scanCanonicalize (H12AffineFastState.compose env27143 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27143 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env27144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,12557,10281,1024,8541,4161,1376,75098,75081,8192,65,75787,4177,79179,67618,75102,32,256,73771,79195,513]

theorem envBound27144 : H12AffineFastState.Bounded env27144 := by
  intro p hp
  have h : env27144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27143_27144 : H12AffineEnvironment.transform 14 8540 env27143 = env27144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27143 == env27144) = true)

theorem identity27144 : scanCanonicalize (H12AffineFastState.compose env27144 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound27144 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env27145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6248,5376,6452,65536,2405,4161,1024,6453,4161,1376,73010,72993,6248,65,69731,4177,68899,67618,73014,32,256,71747,68915,513]

theorem envBound27145 : H12AffineFastState.Bounded env27145 := by
  intro p hp
  have h : env27145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27144_27145 : H12AffineEnvironment.transform 12 6248 env27144 = env27145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env27144 == env27145) = true)

theorem identity27145 : scanCanonicalize (H12AffineFastState.compose env27145 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound27145 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,1053,2421,1345,65536,2405,3124,1024,1344,3124,1376,65863,65876,1053,65,68630,3108,68899,67618,65859,32,256,66614,68915,513]

theorem envBound27146 : H12AffineFastState.Bounded env27146 := by
  intro p hp
  have h : env27146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27145_27146 : H12AffineEnvironment.transform 11 3189 env27145 = env27146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env27145 == env27146) = true)

theorem identity27146 : scanCanonicalize (H12AffineFastState.compose env27146 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound27146 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env27147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,1053,2421,1345,114,2405,3124,1024,1344,3124,1376,309,294,1053,65,3172,3108,3409,2128,305,32,256,1092,3393,513]

theorem envBound27147 : H12AffineFastState.Bounded env27147 := by
  intro p hp
  have h : env27147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27146_27147 : H12AffineEnvironment.transform 15 114 env27146 = env27147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env27146 == env27147) = true)

theorem identity27147 : scanCanonicalize (H12AffineFastState.compose env27147 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27147 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env27148 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,2113,41,2421,373,114,2405,2048,52,372,2048,340,309,294,41,65,2128,2064,2405,2128,305,32,256,112,2421,513]

theorem envBound27148 : H12AffineFastState.Bounded env27148 := by
  intro p hp
  have h : env27148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27147_27148 : H12AffineEnvironment.transform 9 52 env27147 = env27148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27147 == env27148) = true)

theorem identity27148 : scanCanonicalize (H12AffineFastState.compose env27148 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27148 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env27149 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,41,2340,292,35,2356,2048,52,293,2048,261,309,294,41,16,2049,2064,2356,2049,305,32,256,33,2340,513]

theorem envBound27149 : H12AffineFastState.Bounded env27149 := by
  intro p hp
  have h : env27149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27148_27149 : H12AffineEnvironment.transform 5 17 env27148 = env27149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27148 == env27149) = true)

theorem identity27149 : scanCanonicalize (H12AffineFastState.compose env27149 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound27149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27150 : List Nat := [2,4,8,16,32,17,8,256,16,52,2048,2064,41,2340,292,35,2356,2048,52,293,2048,261,309,294,41,16,2049,2064,2356,2049,305,32,256,33,2340,17]

theorem envBound27150 : H12AffineFastState.Bounded env27150 := by
  intro p hp
  have h : env27150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27149_27150 : H12AffineEnvironment.transform 8 16 env27149 = env27150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env27149 == env27150) = true)

theorem identity27150 : scanCanonicalize (H12AffineFastState.compose env27150 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27150 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env27151 : List Nat := [2,4,8,16,32,17,8,256,16,52,0,16,41,292,292,35,308,0,52,293,0,261,309,294,41,16,1,16,308,1,305,32,256,33,292,17]

theorem envBound27151 : H12AffineFastState.Bounded env27151 := by
  intro p hp
  have h : env27151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27150_27151 : H12AffineEnvironment.transform 10 0 env27150 = env27151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27150 == env27151) = true)

theorem identity27151 : scanCanonicalize (H12AffineFastState.compose env27151 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27151 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27152 : List Nat := [2,4,2,16,32,17,2,256,16,52,0,16,35,292,292,35,308,0,52,293,0,261,309,294,35,16,1,16,308,1,305,32,256,33,292,17]

theorem envBound27152 : H12AffineFastState.Bounded env27152 := by
  intro p hp
  have h : env27152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27151_27152 : H12AffineEnvironment.transform 2 2 env27151 = env27152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27151 == env27152) = true)

theorem identity27152 : scanCanonicalize (H12AffineFastState.compose env27152 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27152 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27153 : List Nat := [2,4,2,16,32,17,2,37,16,52,0,16,35,1,1,35,17,0,52,0,0,32,16,3,35,16,1,16,17,1,20,32,37,33,1,17]

theorem envBound27153 : H12AffineFastState.Bounded env27153 := by
  intro p hp
  have h : env27153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27152_27153 : H12AffineEnvironment.transform 7 37 env27152 = env27153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27152 == env27153) = true)

theorem identity27153 : scanCanonicalize (H12AffineFastState.compose env27153 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27153 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27154 : List Nat := [2,4,2,16,16,17,2,21,16,4,0,16,19,1,1,19,17,0,4,0,0,16,16,3,19,16,1,16,17,1,20,16,21,17,1,17]

theorem envBound27154 : H12AffineFastState.Bounded env27154 := by
  intro p hp
  have h : env27154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27153_27154 : H12AffineEnvironment.transform 4 16 env27153 = env27154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27153 == env27154) = true)

theorem identity27154 : scanCanonicalize (H12AffineFastState.compose env27154 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27154 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27155 : List Nat := [2,4,2,0,0,1,2,5,0,4,0,0,3,1,1,3,1,0,4,0,0,0,0,3,3,0,1,0,1,1,4,0,5,1,1,1]

theorem envBound27155 : H12AffineFastState.Bounded env27155 := by
  intro p hp
  have h : env27155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27154_27155 : H12AffineEnvironment.transform 3 0 env27154 = env27155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27154 == env27155) = true)

def env27156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180273,253963,242968,8193,65,97546,139613,238874,67619,119042,33,256,98678,90203,63068]

theorem envBound27156 : H12AffineFastState.Bounded env27156 := by
  intro p hp
  have h : env27156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27140_27156 : H12AffineEnvironment.transform 6 9 env27140 = env27156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27140 == env27156) = true)

theorem identity27156 : scanCanonicalize (H12AffineFastState.compose env27156 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27156 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,4161,144492,201814,213317,8193,65,97546,139613,217415,67619,75103,33,256,95531,90203,513]

theorem envBound27157 : H12AffineFastState.Bounded env27157 := by
  intro p hp
  have h : env27157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27156_27157 : H12AffineEnvironment.transform 14 29789 env27156 = env27157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27156 == env27157) = true)

theorem identity27157 : scanCanonicalize (H12AffineFastState.compose env27157 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound27157 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env27158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,131072,10280,1024,29788,4161,144492,155997,144462,8193,65,2049,139613,140364,32040,20564,33,256,32,5456,513]

theorem envBound27158 : H12AffineFastState.Bounded env27158 := by
  intro p hp
  have h : env27158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27157_27158 : H12AffineEnvironment.transform 15 29963 env27157 = env27158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env27157 == env27158) = true)

theorem identity27158 : scanCanonicalize (H12AffineFastState.compose env27158 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27158 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,131072,2421,1024,21761,4161,136497,147456,136467,348,65,2049,131072,132369,23669,20564,33,256,32,5456,513]

theorem envBound27159 : H12AffineFastState.Bounded env27159 := by
  intro p hp
  have h : env27159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27158_27159 : H12AffineEnvironment.transform 12 349 env27158 = env27159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27158 == env27159) = true)

theorem identity27159 : scanCanonicalize (H12AffineFastState.compose env27159 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27159 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env27160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,131072,2421,1024,1,4161,136497,136448,136467,348,65,2049,131072,132369,2421,1364,33,256,32,5456,513]

theorem envBound27160 : H12AffineFastState.Bounded env27160 := by
  intro p hp
  have h : env27160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27159_27160 : H12AffineEnvironment.transform 13 5376 env27159 = env27160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27159 == env27160) = true)

theorem identity27160 : scanCanonicalize (H12AffineFastState.compose env27160 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound27160 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2421,1024,1,4161,33,16,3,348,65,2049,5392,4097,2421,1364,33,256,32,5456,513]

theorem envBound27161 : H12AffineFastState.Bounded env27161 := by
  intro p hp
  have h : env27161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27160_27161 : H12AffineEnvironment.transform 16 5392 env27160 = env27161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env27160 == env27161) = true)

theorem identity27161 : scanCanonicalize (H12AffineFastState.compose env27161 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3419) := by decide +kernel

theorem selectedBound27161 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3419,349,2139,0,342,2123,2421,1024,1,3354,33,16,3,348,65,2049,2123,3418,2421,1364,33,256,32,2059,513]

theorem envBound27162 : H12AffineFastState.Bounded env27162 := by
  intro p hp
  have h : env27162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27161_27162 : H12AffineEnvironment.transform 11 3419 env27161 = env27162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3419 env27161 == env27162) = true)

theorem identity27162 : scanCanonicalize (H12AffineFastState.compose env27162 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound27162 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27163 : List Nat := [2,4,8,16,32,10,9,256,512,1024,2048,3345,279,2065,0,284,2049,2367,1024,1,3354,33,16,3,278,11,2049,2049,3344,2367,1310,33,256,32,2059,513]

theorem envBound27163 : H12AffineFastState.Bounded env27163 := by
  intro p hp
  have h : env27163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27162_27163 : H12AffineEnvironment.transform 5 10 env27162 = env27163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env27162 == env27163) = true)

theorem identity27163 : scanCanonicalize (H12AffineFastState.compose env27163 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27163 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27164 : List Nat := [2,4,8,16,0,10,9,256,512,1024,2048,3345,279,2065,0,284,2049,2335,1024,1,3354,1,16,3,278,11,2049,2049,3344,2335,1310,1,256,0,2059,513]

theorem envBound27164 : H12AffineFastState.Bounded env27164 := by
  intro p hp
  have h : env27164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27163_27164 : H12AffineEnvironment.transform 4 0 env27163 = env27164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27163 == env27164) = true)

theorem identity27164 : scanCanonicalize (H12AffineFastState.compose env27164 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27164 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env27165 : List Nat := [2,4,8,11,0,10,9,256,512,1024,2048,3338,268,2058,0,263,2049,2308,1024,1,3329,1,11,3,269,11,2049,2049,3339,2308,1285,1,256,0,2059,513]

theorem envBound27165 : H12AffineFastState.Bounded env27165 := by
  intro p hp
  have h : env27165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27164_27165 : H12AffineEnvironment.transform 3 11 env27164 = env27165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27164 == env27165) = true)

theorem identity27165 : scanCanonicalize (H12AffineFastState.compose env27165 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound27165 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27166 : List Nat := [2,4,8,11,0,10,9,14,512,1024,2048,3076,2,2058,0,9,2049,2058,1024,1,3087,1,11,3,3,11,2049,2049,3077,2058,1035,1,14,0,2059,513]

theorem envBound27166 : H12AffineFastState.Bounded env27166 := by
  intro p hp
  have h : env27166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27165_27166 : H12AffineEnvironment.transform 7 14 env27165 = env27166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env27165 == env27166) = true)

theorem identity27166 : scanCanonicalize (H12AffineFastState.compose env27166 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound27166 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27167 : List Nat := [2,4,8,11,0,10,9,14,11,1024,2048,3076,2,2058,0,9,2049,2058,1024,1,3087,1,11,3,3,11,2049,2049,3077,2058,1035,1,14,0,2059,10]

theorem envBound27167 : H12AffineFastState.Bounded env27167 := by
  intro p hp
  have h : env27167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27166_27167 : H12AffineEnvironment.transform 8 11 env27166 = env27167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env27166 == env27167) = true)

theorem identity27167 : scanCanonicalize (H12AffineFastState.compose env27167 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27167 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27168 : List Nat := [2,4,1,2,0,3,0,7,2,1024,2048,3076,2,2051,0,0,2049,2051,1024,1,3078,1,2,3,3,2,2049,2049,3077,2051,1026,1,7,0,2050,3]

theorem envBound27168 : H12AffineFastState.Bounded env27168 := by
  intro p hp
  have h : env27168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27167_27168 : H12AffineEnvironment.transform 2 1 env27167 = env27168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27167 == env27168) = true)

theorem identity27168 : scanCanonicalize (H12AffineFastState.compose env27168 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1030) := by decide +kernel

theorem selectedBound27168 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27169 : List Nat := [2,4,1,2,0,3,0,7,2,1024,1030,2,2,1029,0,0,1031,1029,1024,1,0,1,2,3,3,2,1031,1031,3,1029,1026,1,7,0,1028,3]

theorem envBound27169 : H12AffineFastState.Bounded env27169 := by
  intro p hp
  have h : env27169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27168_27169 : H12AffineEnvironment.transform 10 1030 env27168 = env27169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1030 env27168 == env27169) = true)

theorem identity27169 : scanCanonicalize (H12AffineFastState.compose env27169 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound27169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27170 : List Nat := [2,4,1,2,0,3,0,7,2,0,6,2,2,5,0,0,7,5,0,1,0,1,2,3,3,2,7,7,3,5,2,1,7,0,4,3]

theorem envBound27170 : H12AffineFastState.Bounded env27170 := by
  intro p hp
  have h : env27170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27169_27170 : H12AffineEnvironment.transform 9 0 env27169 = env27170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env27169 == env27170) = true)

theorem identity27170 : scanCanonicalize (H12AffineFastState.compose env27170 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27170 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env27171 : List Nat := [2,0,1,2,0,3,0,3,2,0,2,2,2,1,0,0,3,1,0,1,0,1,2,3,3,2,3,3,3,1,2,1,3,0,0,3]

theorem envBound27171 : H12AffineFastState.Bounded env27171 := by
  intro p hp
  have h : env27171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27170_27171 : H12AffineEnvironment.transform 1 0 env27170 = env27171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27170 == env27171) = true)

def env27172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound27172 : H12AffineFastState.Bounded env27172 := by
  intro p hp
  have h : env27172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26945_27172 : H12AffineEnvironment.transform 18 1025 env26945 = env27172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26945 == env27172) = true)

theorem identity27172 : scanCanonicalize (H12AffineFastState.compose env27172 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound27172 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272426,8328,65,12838955,2469030,10507600,8830977,8760379,6639082,257,10873990,10816803,8686573]

theorem envBound27173 : H12AffineFastState.Bounded env27173 := by
  intro p hp
  have h : env27173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27172_27173 : H12AffineEnvironment.transform 23 272426 env27172 = env27173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env27172 == env27173) = true)

def env27174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272426,8328,65,4303011,2469030,2233816,295049,519347,6639082,257,2599950,2575787,445285]

theorem envBound27174 : H12AffineFastState.Bounded env27174 := by
  intro p hp
  have h : env27174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27173_27174 : H12AffineEnvironment.transform 22 147592 env27173 = env27174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env27173 == env27174) = true)

def env27175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303011,2469030,2119112,295049,371875,6639082,257,2485278,2428347,297845]

theorem envBound27175 : H12AffineFastState.Bounded env27175 := by
  intro p hp
  have h : env27175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27174_27175 : H12AffineEnvironment.transform 16 16400 env27174 = env27175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27174 == env27175) = true)

theorem identity27175 : scanCanonicalize (H12AffineFastState.compose env27175 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound27175 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1025,32769,2097152,4194304,152,138,8328,65,4303011,2196486,2119112,43049,99331,6382922,257,2213054,2172187,41941]

theorem envBound27176 : H12AffineFastState.Bounded env27176 := by
  intro p hp
  have h : env27176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27175_27176 : H12AffineEnvironment.transform 17 10400 env27175 = env27176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27175 == env27176) = true)

theorem identity27176 : scanCanonicalize (H12AffineFastState.compose env27176 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound27176 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env27177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16400,10400,1025,8661,2097152,4194304,152,138,8328,65,4262263,2172370,2119112,2557,75223,6382922,257,2188650,2172187,513]

theorem envBound27177 : H12AffineFastState.Bounded env27177 := by
  intro p hp
  have h : env27177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27176_27177 : H12AffineEnvironment.transform 14 8660 env27176 = env27177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env27176 == env27177) = true)

theorem identity27177 : scanCanonicalize (H12AffineFastState.compose env27177 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27177 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env27178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16400,10400,1025,8661,2097152,4194304,152,138,8328,65,4204925,2098648,2119112,2557,1501,6309184,257,2114912,2098449,513]

theorem envBound27178 : H12AffineFastState.Bounded env27178 := by
  intro p hp
  have h : env27178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27177_27178 : H12AffineEnvironment.transform 15 8202 env27177 = env27178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27177 == env27178) = true)

theorem identity27178 : scanCanonicalize (H12AffineFastState.compose env27178 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound27178 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env27179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16400,10400,1025,8661,2097152,169,152,138,8328,65,10708,2098648,2119112,2557,1501,2115049,257,2114912,2098449,513]

theorem envBound27179 : H12AffineFastState.Bounded env27179 := by
  intro p hp
  have h : env27179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27178_27179 : H12AffineEnvironment.transform 21 169 env27178 = env27179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env27178 == env27179) = true)

theorem identity27179 : scanCanonicalize (H12AffineFastState.compose env27179 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27179 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env27180 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8202,16400,10400,1025,8580,2097152,169,152,138,8328,16,10629,2098569,2119065,2476,1420,2115000,257,2114865,2098449,513]

theorem envBound27180 : H12AffineFastState.Bounded env27180 := by
  intro p hp
  have h : env27180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27179_27180 : H12AffineEnvironment.transform 5 17 env27179 = env27180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27179 == env27180) = true)

theorem identity27180 : scanCanonicalize (H12AffineFastState.compose env27180 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound27180 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27181 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8202,16400,10400,1025,8580,17681,169,152,138,8328,16,10629,16536,4232,2476,1420,169,257,32,16384,513]

theorem envBound27181 : H12AffineFastState.Bounded env27181 := by
  intro p hp
  have h : env27181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27180_27181 : H12AffineEnvironment.transform 20 17681 env27180 = env27181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env27180 == env27181) = true)

def env27182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303011,2469030,2119113,295049,371874,6639082,257,2485279,2428346,297844]

theorem envBound27182 : H12AffineFastState.Bounded env27182 := by
  intro p hp
  have h : env27182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27174_27182 : H12AffineEnvironment.transform 16 16401 env27174 = env27182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27174 == env27182) = true)

theorem identity27182 : scanCanonicalize (H12AffineFastState.compose env27182 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27182 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,272426,8192,65,4302891,2468910,2118977,294913,371754,6638946,257,2485279,2428210,297844]

theorem envBound27183 : H12AffineFastState.Bounded env27183 := by
  intro p hp
  have h : env27183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27182_27183 : H12AffineEnvironment.transform 6 8 env27182 = env27183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27182 == env27183) = true)

theorem identity27183 : scanCanonicalize (H12AffineFastState.compose env27183 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound27183 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302891,2172251,2118977,2420,75103,6407191,257,2188650,2196551,513]

theorem envBound27184 : H12AffineFastState.Bounded env27184 := by
  intro p hp
  have h : env27184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27183_27184 : H12AffineEnvironment.transform 17 35189 env27183 = env27184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env27183 == env27184) = true)

theorem identity27184 : scanCanonicalize (H12AffineFastState.compose env27184 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound27184 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115735,4194304,17,41311,8192,65,4302891,57676,102742,2420,75103,4194304,257,41341,16464,513]

theorem envBound27185 : H12AffineFastState.Bounded env27185 := by
  intro p hp
  have h : env27185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27184_27185 : H12AffineEnvironment.transform 20 115735 env27184 = env27185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env27184 == env27185) = true)

def env27186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91199,4194304,17,375,8192,65,4261891,16740,78206,2420,75103,4194304,257,341,16464,513]

theorem envBound27186 : H12AffineFastState.Bounded env27186 := by
  intro p hp
  have h : env27186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27185_27186 : H12AffineEnvironment.transform 14 8232 env27185 = env27186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env27185 == env27186) = true)

theorem identity27186 : scanCanonicalize (H12AffineFastState.compose env27186 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27186 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env27187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,0,65536,16401,2421,1025,1,82967,4194304,17,375,40,65,4261891,16740,69974,2420,66935,4194304,257,341,16464,513]

theorem envBound27187 : H12AffineFastState.Bounded env27187 := by
  intro p hp
  have h : env27187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27186_27187 : H12AffineEnvironment.transform 12 40 env27186 = env27187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27186 == env27187) = true)

theorem identity27187 : scanCanonicalize (H12AffineFastState.compose env27187 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound27187 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,0,65536,16401,2421,1025,1,82967,32,17,375,40,65,67619,16740,69974,2420,66935,32,257,341,16464,513]

theorem envBound27188 : H12AffineFastState.Bounded env27188 := by
  intro p hp
  have h : env27188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27187_27188 : H12AffineEnvironment.transform 21 32 env27187 = env27188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env27187 == env27188) = true)

theorem identity27188 : scanCanonicalize (H12AffineFastState.compose env27188 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27188 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env27189 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,0,65536,16401,2048,1025,1,82967,32,17,2,40,65,67619,16401,69667,2049,66562,32,116,32,16464,513]

theorem envBound27189 : H12AffineFastState.Bounded env27189 := by
  intro p hp
  have h : env27189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27188_27189 : H12AffineEnvironment.transform 7 117 env27188 = env27189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27188 == env27189) = true)

theorem identity27189 : scanCanonicalize (H12AffineFastState.compose env27189 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound27189 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27190 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,0,35,16401,2048,1025,1,17460,32,17,2,40,65,2048,16401,4096,2049,1057,32,116,32,16464,513]

theorem envBound27190 : H12AffineFastState.Bounded env27190 := by
  intro p hp
  have h : env27190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27189_27190 : H12AffineEnvironment.transform 15 35 env27189 = env27190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env27189 == env27190) = true)

theorem identity27190 : scanCanonicalize (H12AffineFastState.compose env27190 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound27190 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27191 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,40,16384,0,35,16401,2048,1025,1,17460,32,17,2,40,65,2048,16401,1141,2049,1057,32,116,32,16464,513]

theorem envBound27191 : H12AffineFastState.Bounded env27191 := by
  intro p hp
  have h : env27191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27190_27191 : H12AffineEnvironment.transform 11 1141 env27190 = env27191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env27190 == env27191) = true)

theorem identity27191 : scanCanonicalize (H12AffineFastState.compose env27191 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 3685) := by decide +kernel

theorem selectedBound27191 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27192 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,40,3685,0,35,3700,2048,1025,1,2641,32,17,2,40,65,2048,3700,1141,2049,1057,32,116,32,3637,513]

theorem envBound27192 : H12AffineFastState.Bounded env27192 := by
  intro p hp
  have h : env27192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27191_27192 : H12AffineEnvironment.transform 13 3685 env27191 = env27192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3685 env27191 == env27192) = true)

theorem identity27192 : scanCanonicalize (H12AffineFastState.compose env27192 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27192 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27193 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1060,40,3636,0,35,3621,2048,1025,1,2560,32,17,2,40,16,2048,3621,1060,2049,1057,32,37,32,3637,513]

theorem envBound27193 : H12AffineFastState.Bounded env27193 := by
  intro p hp
  have h : env27193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27192_27193 : H12AffineEnvironment.transform 5 17 env27192 = env27193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27192 == env27193) = true)

theorem identity27193 : scanCanonicalize (H12AffineFastState.compose env27193 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27194 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1029,9,3605,0,2,3588,2048,1025,1,2560,1,17,2,9,16,2048,3588,1029,2049,1024,1,4,1,3604,513]

theorem envBound27194 : H12AffineFastState.Bounded env27194 := by
  intro p hp
  have h : env27194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27193_27194 : H12AffineEnvironment.transform 4 1 env27193 = env27194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27193 == env27194) = true)

theorem identity27194 : scanCanonicalize (H12AffineFastState.compose env27194 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound27194 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27195 : List Nat := [2,4,8,16,1,17,8,5,512,517,2048,512,9,2064,0,2,2049,2048,516,1,2560,1,17,2,9,16,2048,2049,512,2049,517,1,4,1,2065,513]

theorem envBound27195 : H12AffineFastState.Bounded env27195 := by
  intro p hp
  have h : env27195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27194_27195 : H12AffineEnvironment.transform 9 517 env27194 = env27195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env27194 == env27195) = true)

theorem identity27195 : scanCanonicalize (H12AffineFastState.compose env27195 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27195 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27196 : List Nat := [2,4,8,16,1,17,8,5,1,4,2048,1,9,2064,0,2,2049,2048,5,1,2049,1,17,2,9,16,2048,2049,1,2049,4,1,4,1,2065,0]

theorem envBound27196 : H12AffineFastState.Bounded env27196 := by
  intro p hp
  have h : env27196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27195_27196 : H12AffineEnvironment.transform 8 1 env27195 = env27196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27195 == env27196) = true)

theorem identity27196 : scanCanonicalize (H12AffineFastState.compose env27196 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27196 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27197 : List Nat := [2,4,8,16,1,17,8,5,1,4,0,1,9,16,0,2,1,0,5,1,1,1,17,2,9,16,0,1,1,1,4,1,4,1,17,0]

theorem envBound27197 : H12AffineFastState.Bounded env27197 := by
  intro p hp
  have h : env27197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27196_27197 : H12AffineEnvironment.transform 10 0 env27196 = env27197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27196 == env27197) = true)

theorem identity27197 : scanCanonicalize (H12AffineFastState.compose env27197 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27197 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27198 : List Nat := [2,4,8,0,1,1,8,5,1,4,0,1,9,0,0,2,1,0,5,1,1,1,1,2,9,0,0,1,1,1,4,1,4,1,1,0]

theorem envBound27198 : H12AffineFastState.Bounded env27198 := by
  intro p hp
  have h : env27198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27197_27198 : H12AffineEnvironment.transform 3 0 env27197 = env27198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27197 == env27198) = true)

def env27199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91198,4194304,17,374,8192,65,4261890,16741,78207,2420,75103,4194304,257,340,16464,513]

theorem envBound27199 : H12AffineFastState.Bounded env27199 := by
  intro p hp
  have h : env27199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27185_27199 : H12AffineEnvironment.transform 14 8233 env27185 = env27199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env27185 == env27199) = true)

theorem identity27199 : scanCanonicalize (H12AffineFastState.compose env27199 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27199 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env27200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,372,65536,16401,2049,1025,373,83299,4194304,17,374,349,65,4261890,16741,69666,2420,66562,4194304,257,340,16464,513]

theorem envBound27200 : H12AffineFastState.Bounded env27200 := by
  intro p hp
  have h : env27200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27199_27200 : H12AffineEnvironment.transform 12 349 env27199 = env27200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27199 == env27200) = true)

theorem identity27200 : scanCanonicalize (H12AffineFastState.compose env27200 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27200 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env27201 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,0,65536,16401,2049,1025,1,82967,4194304,17,2,41,65,4261890,16401,69666,2048,66562,4194304,117,32,16464,513]

theorem envBound27201 : H12AffineFastState.Bounded env27201 := by
  intro p hp
  have h : env27201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27200_27201 : H12AffineEnvironment.transform 7 116 env27200 = env27201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27200 == env27201) = true)

theorem identity27201 : scanCanonicalize (H12AffineFastState.compose env27201 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound27201 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27202 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,0,34,16401,2049,1025,1,17461,4194304,17,2,41,65,4196384,16401,4096,2048,1056,4194304,117,32,16464,513]

theorem envBound27202 : H12AffineFastState.Bounded env27202 := by
  intro p hp
  have h : env27202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27201_27202 : H12AffineEnvironment.transform 15 34 env27201 = env27202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env27201 == env27202) = true)

theorem identity27202 : scanCanonicalize (H12AffineFastState.compose env27202 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27202 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27203 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,0,34,16401,2049,1025,1,17461,4194304,17,2,41,16,4196384,16401,4096,2048,1056,4194304,36,32,16385,513]

theorem envBound27203 : H12AffineFastState.Bounded env27203 := by
  intro p hp
  have h : env27203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27202_27203 : H12AffineEnvironment.transform 5 17 env27202 = env27203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27202 == env27203) = true)

theorem identity27203 : scanCanonicalize (H12AffineFastState.compose env27203 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound27203 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env27204 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5172,2049,1025,1,4112,4194304,17,2,41,16,4196384,5172,4096,2048,1056,4194304,36,32,5156,513]

theorem envBound27204 : H12AffineFastState.Bounded env27204 := by
  intro p hp
  have h : env27204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27203_27204 : H12AffineEnvironment.transform 13 5157 env27203 = env27204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env27203 == env27204) = true)

theorem identity27204 : scanCanonicalize (H12AffineFastState.compose env27204 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound27204 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27205 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5172,2049,1025,1,4112,33,17,2,41,16,2049,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound27205 : H12AffineFastState.Bounded env27205 := by
  intro p hp
  have h : env27205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27204_27205 : H12AffineEnvironment.transform 21 33 env27204 = env27205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env27204 == env27205) = true)

def env27206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272426,8328,65,4303010,2469030,2233817,295048,519346,6639082,257,2599951,2575786,445284]

theorem envBound27206 : H12AffineFastState.Bounded env27206 := by
  intro p hp
  have h : env27206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27173_27206 : H12AffineEnvironment.transform 22 147593 env27173 = env27206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env27173 == env27206) = true)

def env27207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303010,2469030,2119113,295048,371874,6639082,257,2485279,2428346,297844]

theorem envBound27207 : H12AffineFastState.Bounded env27207 := by
  intro p hp
  have h : env27207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27206_27207 : H12AffineEnvironment.transform 16 16400 env27206 = env27207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27206 == env27207) = true)

theorem identity27207 : scanCanonicalize (H12AffineFastState.compose env27207 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound27207 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35325,1025,32769,2097152,4194304,153,41431,8328,65,4303010,2172251,2119113,2421,75103,6407191,257,2188770,2196551,649]

theorem envBound27208 : H12AffineFastState.Bounded env27208 := by
  intro p hp
  have h : env27208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27207_27208 : H12AffineEnvironment.transform 17 35325 env27207 = env27208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env27207 == env27208) = true)

theorem identity27208 : scanCanonicalize (H12AffineFastState.compose env27208 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27208 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302890,2172251,2118977,2421,75103,6407191,257,2188650,2196551,513]

theorem envBound27209 : H12AffineFastState.Bounded env27209 := by
  intro p hp
  have h : env27209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27208_27209 : H12AffineEnvironment.transform 6 8 env27208 = env27209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27208 == env27209) = true)

theorem identity27209 : scanCanonicalize (H12AffineFastState.compose env27209 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound27209 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env27210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115735,4194304,17,41311,8192,65,4302890,57676,102742,2421,75103,4194304,257,41341,16464,513]

theorem envBound27210 : H12AffineFastState.Bounded env27210 := by
  intro p hp
  have h : env27210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27209_27210 : H12AffineEnvironment.transform 20 115735 env27209 = env27210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env27209 == env27210) = true)

theorem identity27210 : scanCanonicalize (H12AffineFastState.compose env27210 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27210 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env27211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,91466,4194304,17,2,8192,65,4262263,16401,77835,2421,75103,4194304,257,32,16464,513]

theorem envBound27211 : H12AffineFastState.Bounded env27211 := by
  intro p hp
  have h : env27211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27210_27211 : H12AffineEnvironment.transform 14 8541 env27210 = env27211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27210 == env27211) = true)

theorem identity27211 : scanCanonicalize (H12AffineFastState.compose env27211 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound27211 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env27212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,91466,32,17,2,8192,65,67927,16401,77835,2421,75103,32,257,32,16464,513]

theorem envBound27212 : H12AffineFastState.Bounded env27212 := by
  intro p hp
  have h : env27212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27211_27212 : H12AffineEnvironment.transform 21 32 env27211 = env27212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env27211 == env27212) = true)

def env27213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303010,2469030,2119112,295048,371875,6639082,257,2485278,2428347,297845]

theorem envBound27213 : H12AffineFastState.Bounded env27213 := by
  intro p hp
  have h : env27213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27206_27213 : H12AffineEnvironment.transform 16 16401 env27206 = env27213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27206 == env27213) = true)

theorem identity27213 : scanCanonicalize (H12AffineFastState.compose env27213 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound27213 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16401,262144,1025,8661,2097152,4194304,152,272426,8328,65,4262262,2428274,2119112,270684,331127,6639082,257,2444746,2428347,273057]

theorem envBound27214 : H12AffineFastState.Bounded env27214 := by
  intro p hp
  have h : env27214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27213_27214 : H12AffineEnvironment.transform 14 8660 env27213 = env27214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env27213 == env27214) = true)

def env27215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16401,10400,1025,8661,2097152,4194304,152,138,8328,65,4262262,2172370,2119112,2556,75223,6382922,257,2188650,2172187,513]

theorem envBound27215 : H12AffineFastState.Bounded env27215 := by
  intro p hp
  have h : env27215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27214_27215 : H12AffineEnvironment.transform 17 10400 env27214 = env27215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27214 == env27215) = true)

theorem identity27215 : scanCanonicalize (H12AffineFastState.compose env27215 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27215 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env27216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8203,16401,10400,1025,8661,2097152,4194304,152,138,8328,65,4204925,2098649,2119112,2556,1500,6309185,257,2114913,2098448,513]

theorem envBound27216 : H12AffineFastState.Bounded env27216 := by
  intro p hp
  have h : env27216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27215_27216 : H12AffineEnvironment.transform 15 8203 env27215 = env27216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27215 == env27216) = true)

theorem identity27216 : scanCanonicalize (H12AffineFastState.compose env27216 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 2114864) := by decide +kernel

theorem selectedBound27216 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env27217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8203,16401,10400,1025,8661,2097152,2114864,152,138,8328,65,2124877,2098649,2119112,2556,1500,113,257,2114913,2098448,513]

theorem envBound27217 : H12AffineFastState.Bounded env27217 := by
  intro p hp
  have h : env27217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27216_27217 : H12AffineEnvironment.transform 21 2114864 env27216 = env27217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114864 env27216 == env27217) = true)

theorem identity27217 : scanCanonicalize (H12AffineFastState.compose env27217 (packedSelected [4,9,11,12,14,15,17,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound27217 : packedSelected [4,9,11,12,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8203,16401,10400,1025,8661,17816,168,152,138,8328,65,10709,16449,4176,2556,1500,113,257,249,16520,513]

theorem envBound27218 : H12AffineFastState.Bounded env27218 := by
  intro p hp
  have h : env27218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27217_27218 : H12AffineEnvironment.transform 20 17816 env27217 = env27218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env27217 == env27218) = true)

theorem identity27218 : scanCanonicalize (H12AffineFastState.compose env27218 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound27218 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env27219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,80,399,16401,2340,1025,81,17816,168,152,138,268,65,2129,16449,4176,2556,1500,113,257,249,16520,513]

theorem envBound27219 : H12AffineFastState.Bounded env27219 := by
  intro p hp
  have h : env27219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27218_27219 : H12AffineEnvironment.transform 12 388 env27218 = env27219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env27218 == env27219) = true)

theorem identity27219 : scanCanonicalize (H12AffineFastState.compose env27219 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound27219 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27220 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,80,342,16401,2340,1025,81,17729,113,65,83,268,65,2129,16449,4176,2341,1285,113,257,32,16465,513]

theorem envBound27220 : H12AffineFastState.Bounded env27220 := by
  intro p hp
  have h : env27220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27219_27220 : H12AffineEnvironment.transform 6 89 env27219 = env27220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env27219 == env27220) = true)

theorem identity27220 : scanCanonicalize (H12AffineFastState.compose env27220 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound27220 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27221 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2113,349,16384,80,342,16401,2340,1025,81,17729,113,65,83,268,65,2129,16449,2065,2341,1285,113,257,32,16465,513]

theorem envBound27221 : H12AffineFastState.Bounded env27221 := by
  intro p hp
  have h : env27221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27220_27221 : H12AffineEnvironment.transform 11 2113 env27220 = env27221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env27220 == env27221) = true)

theorem identity27221 : scanCanonicalize (H12AffineFastState.compose env27221 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27221 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env27222 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,269,16384,0,262,16401,2340,1025,1,17681,33,17,3,268,17,2049,16401,2065,2341,1285,33,257,32,16385,513]

theorem envBound27222 : H12AffineFastState.Bounded env27222 := by
  intro p hp
  have h : env27222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27221_27222 : H12AffineEnvironment.transform 5 16 env27221 = env27222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27221 == env27222) = true)

def env27223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16401,10401,1025,8661,2097152,4194304,152,139,8328,65,4262262,2172371,2119112,2557,75222,6382923,257,2188651,2172186,512]

theorem envBound27223 : H12AffineFastState.Bounded env27223 := by
  intro p hp
  have h : env27223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27214_27223 : H12AffineEnvironment.transform 17 10401 env27214 = env27223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27214 == env27223) = true)

theorem identity27223 : scanCanonicalize (H12AffineFastState.compose env27223 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27223 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,2097152,4194304,16,3,8192,65,4262262,2172251,2118976,2421,75102,6382923,257,2188651,2172186,512]

theorem envBound27224 : H12AffineFastState.Bounded env27224 := by
  intro p hp
  have h : env27224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27223_27224 : H12AffineEnvironment.transform 6 8 env27223 = env27224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27223 == env27224) = true)

theorem identity27224 : scanCanonicalize (H12AffineFastState.compose env27224 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound27224 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,17460,4194304,16,3,8192,65,4262262,90479,4468,2421,75102,4268415,257,74079,90414,512]

theorem envBound27225 : H12AffineFastState.Bounded env27225 := by
  intro p hp
  have h : env27225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27224_27225 : H12AffineEnvironment.transform 20 17460 env27224 = env27225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env27224 == env27225) = true)

theorem identity27225 : scanCanonicalize (H12AffineFastState.compose env27225 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound27225 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env27226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,17460,33,16,3,8192,65,67927,90479,4468,2421,75102,74078,257,74079,90414,512]

theorem envBound27226 : H12AffineFastState.Bounded env27226 := by
  intro p hp
  have h : env27226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27225_27226 : H12AffineEnvironment.transform 21 33 env27225 = env27226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env27225 == env27226) = true)

theorem identity27226 : scanCanonicalize (H12AffineFastState.compose env27226 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 19810) := by decide +kernel

theorem selectedBound27226 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env27227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,19810,16401,10281,1025,8541,17460,33,16,3,8192,65,17461,11277,4468,2421,26684,27708,257,27709,11340,512]

theorem envBound27227 : H12AffineFastState.Bounded env27227 := by
  intro p hp
  have h : env27227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27226_27227 : H12AffineEnvironment.transform 15 19810 env27226 = env27227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19810 env27226 == env27227) = true)

theorem identity27227 : scanCanonicalize (H12AffineFastState.compose env27227 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound27227 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5408,8540,6210,5425,10281,1025,8541,4372,33,16,3,8192,65,4373,11277,4468,2421,15644,14620,257,14621,11340,512]

theorem envBound27228 : H12AffineFastState.Bounded env27228 := by
  intro p hp
  have h : env27228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27227_27228 : H12AffineEnvironment.transform 13 5408 env27227 = env27228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env27227 == env27228) = true)

theorem identity27228 : scanCanonicalize (H12AffineFastState.compose env27228 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound27228 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env27229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5408,1076,6210,5425,3393,1025,1077,4372,33,16,3,1384,65,4373,2405,4468,2421,6260,7284,257,7285,2340,512]

theorem envBound27229 : H12AffineFastState.Bounded env27229 := by
  intro p hp
  have h : env27229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27228_27229 : H12AffineEnvironment.transform 12 1384 env27228 = env27229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env27228 == env27229) = true)

theorem identity27229 : scanCanonicalize (H12AffineFastState.compose env27229 (packedSelected [2,3,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound27229 : packedSelected [2,3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env27230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,1384,3377,1076,83,3360,3393,1025,1077,2309,33,16,3,1384,65,2308,2405,2405,2421,101,1125,257,1124,2340,512]

theorem envBound27230 : H12AffineFastState.Bounded env27230 := by
  intro p hp
  have h : env27230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27229_27230 : H12AffineEnvironment.transform 11 2065 env27229 = env27230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env27229 == env27230) = true)

theorem identity27230 : scanCanonicalize (H12AffineFastState.compose env27230 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound27230 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27231 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,2065,88,2049,260,83,2064,2161,305,261,2309,33,16,3,88,65,2308,2405,2405,2421,101,341,257,340,2340,512]

theorem envBound27231 : H12AffineFastState.Bounded env27231 := by
  intro p hp
  have h : env27231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27230_27231 : H12AffineEnvironment.transform 9 304 env27230 = env27231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env27230 == env27231) = true)

theorem identity27231 : scanCanonicalize (H12AffineFastState.compose env27231 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound27231 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27232 : List Nat := [2,4,8,16,32,64,8,256,512,304,555,570,88,554,260,83,571,602,305,261,814,33,16,3,88,65,815,846,846,862,101,341,257,340,783,512]

theorem envBound27232 : H12AffineFastState.Bounded env27232 := by
  intro p hp
  have h : env27232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27231_27232 : H12AffineEnvironment.transform 10 555 env27231 = env27232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env27231 == env27232) = true)

theorem identity27232 : scanCanonicalize (H12AffineFastState.compose env27232 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27232 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27233 : List Nat := [2,4,8,16,32,64,8,36,512,20,555,570,88,554,32,83,571,602,21,33,522,33,16,3,88,65,523,618,618,634,101,113,37,112,555,512]

theorem envBound27233 : H12AffineFastState.Bounded env27233 := by
  intro p hp
  have h : env27233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27232_27233 : H12AffineEnvironment.transform 7 36 env27232 = env27233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27232 == env27233) = true)

theorem identity27233 : scanCanonicalize (H12AffineFastState.compose env27233 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound27233 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27234 : List Nat := [2,4,8,16,26,64,8,30,512,20,529,512,88,528,26,83,513,602,21,27,522,27,16,3,88,65,523,592,592,576,95,75,31,74,529,512]

theorem envBound27234 : H12AffineFastState.Bounded env27234 := by
  intro p hp
  have h : env27234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27233_27234 : H12AffineEnvironment.transform 4 26 env27233 = env27234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env27233 == env27234) = true)

theorem identity27234 : scanCanonicalize (H12AffineFastState.compose env27234 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 66) := by decide +kernel

theorem selectedBound27234 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env27235 : List Nat := [2,4,8,16,26,64,8,30,66,20,83,66,88,82,26,83,67,24,21,27,72,27,16,3,88,65,73,18,18,2,95,75,31,74,83,66]

theorem envBound27235 : H12AffineFastState.Bounded env27235 := by
  intro p hp
  have h : env27235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27234_27235 : H12AffineEnvironment.transform 8 66 env27234 = env27235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 66 env27234 == env27235) = true)

theorem identity27235 : scanCanonicalize (H12AffineFastState.compose env27235 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27235 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27236 : List Nat := [2,4,8,16,26,17,8,30,19,20,2,19,9,3,26,2,18,24,21,27,25,27,16,3,9,16,24,18,18,2,14,26,31,27,2,19]

theorem envBound27236 : H12AffineFastState.Bounded env27236 := by
  intro p hp
  have h : env27236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27235_27236 : H12AffineEnvironment.transform 5 17 env27235 = env27236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27235 == env27236) = true)

theorem identity27236 : scanCanonicalize (H12AffineFastState.compose env27236 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27237 : List Nat := [2,4,8,10,0,11,8,4,9,14,2,9,9,3,0,2,8,2,15,1,3,1,10,3,9,10,2,8,8,2,14,0,5,1,2,9]

theorem envBound27237 : H12AffineFastState.Bounded env27237 := by
  intro p hp
  have h : env27237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27236_27237 : H12AffineEnvironment.transform 3 10 env27236 = env27237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27236 == env27237) = true)

theorem identity27237 : scanCanonicalize (H12AffineFastState.compose env27237 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound27237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27238 : List Nat := [2,1,8,10,0,11,8,1,9,11,2,9,9,3,0,2,8,2,10,1,3,1,10,3,9,10,2,8,8,2,11,0,0,1,2,9]

theorem envBound27238 : H12AffineFastState.Bounded env27238 := by
  intro p hp
  have h : env27238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27237_27238 : H12AffineEnvironment.transform 1 1 env27237 = env27238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env27237 == env27238) = true)

theorem identity27238 : scanCanonicalize (H12AffineFastState.compose env27238 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27239 : List Nat := [2,1,2,0,0,1,2,1,3,1,2,3,3,3,0,2,2,2,0,1,3,1,0,3,3,0,2,2,2,2,1,0,0,1,2,3]

theorem envBound27239 : H12AffineFastState.Bounded env27239 := by
  intro p hp
  have h : env27239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27238_27239 : H12AffineEnvironment.transform 2 2 env27238 = env27239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27238 == env27239) = true)

def env27240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound27240 : H12AffineFastState.Bounded env27240 := by
  intro p hp
  have h : env27240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26944_27240 : H12AffineEnvironment.transform 26 30393345 env26944 = env27240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env26944 == env27240) = true)

def env27241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound27241 : H12AffineFastState.Bounded env27241 := by
  intro p hp
  have h : env27241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27240_27241 : H12AffineEnvironment.transform 18 1024 env27240 = env27241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env27240 == env27241) = true)

theorem identity27241 : scanCanonicalize (H12AffineFastState.compose env27241 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923370) := by decide +kernel

theorem selectedBound27241 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923370,8328,65,6385003,8858087,10507600,8830977,2566523,13093035,256,485830,493667,2494124]

theorem envBound27242 : H12AffineFastState.Bounded env27242 := by
  intro p hp
  have h : env27242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27241_27242 : H12AffineEnvironment.transform 23 10923370 env27241 = env27242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923370 env27241 == env27242) = true)

def env27243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452648,2114882,8328,65,6385003,115151,2538872,10281,2566523,4268163,256,485830,493667,2494124]

theorem envBound27243 : H12AffineFastState.Bounded env27243 := by
  intro p hp
  have h : env27243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27242_27243 : H12AffineEnvironment.transform 22 452648 env27242 = env27243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env27242 == env27243) = true)

def env27244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,441658,8328,65,4691219,115151,17664,10281,119043,4268163,256,485830,493667,63188]

theorem envBound27244 : H12AffineFastState.Bounded env27244 := by
  intro p hp
  have h : env27244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27243_27244 : H12AffineEnvironment.transform 20 456824 env27243 = env27244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env27243 == env27244) = true)

def env27245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,441658,8328,65,245139,115151,17664,10281,119043,329731,256,485830,493667,63188]

theorem envBound27245 : H12AffineFastState.Bounded env27245 := by
  intro p hp
  have h : env27245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27244_27245 : H12AffineEnvironment.transform 21 272512 env27244 = env27245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27244 == env27245) = true)

theorem identity27245 : scanCanonicalize (H12AffineFastState.compose env27245 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound27245 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,58517,144493,62661,41431,8328,65,245139,115151,17664,10281,119043,201966,256,95531,103566,63188]

theorem envBound27246 : H12AffineFastState.Bounded env27246 := by
  intro p hp
  have h : env27246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27245_27246 : H12AffineEnvironment.transform 17 138477 env27245 = env27246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env27245 == env27246) = true)

def env27247 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138429,1024,32769,58517,144445,62613,41351,8328,17,245139,115103,17664,10281,119043,201918,256,95531,103566,63108]

theorem envBound27247 : H12AffineFastState.Bounded env27247 := by
  intro p hp
  have h : env27247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27246_27247 : H12AffineEnvironment.transform 5 16 env27246 = env27247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27246 == env27247) = true)

theorem identity27247 : scanCanonicalize (H12AffineFastState.compose env27247 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound27247 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env27248 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33031,131072,138429,1024,32769,58517,144445,62613,41351,8328,17,146580,16536,17664,10281,20484,169401,256,62508,5513,63108]

theorem envBound27248 : H12AffineFastState.Bounded env27248 := by
  intro p hp
  have h : env27248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27247_27248 : H12AffineEnvironment.transform 15 33031 env27247 = env27248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env27247 == env27248) = true)

theorem identity27248 : scanCanonicalize (H12AffineFastState.compose env27248 (packedSelected [4,7,9,16,17,18,20,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound27248 : packedSelected [4,7,9,16,17,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env27249 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33031,131072,138429,1024,32769,45340,144445,41244,41351,8328,17,146580,5393,4233,10281,1421,169401,256,41381,5513,41741]

theorem envBound27249 : H12AffineFastState.Bounded env27249 := by
  intro p hp
  have h : env27249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27248_27249 : H12AffineEnvironment.transform 13 5513 env27248 = env27249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27248 == env27249) = true)

theorem identity27249 : scanCanonicalize (H12AffineFastState.compose env27249 (packedSelected [16,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound27249 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env27250 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33031,13341,10400,1024,32769,45340,32,41244,41351,8328,17,2185,5393,4233,10281,1421,41380,256,41381,5513,41741]

theorem envBound27250 : H12AffineFastState.Bounded env27250 := by
  intro p hp
  have h : env27250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27249_27250 : H12AffineEnvironment.transform 16 13341 env27249 = env27250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env27249 == env27250) = true)

theorem identity27250 : scanCanonicalize (H12AffineFastState.compose env27250 (packedSelected [2,4,6,9,14,15,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27250 : packedSelected [2,4,6,9,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27251 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4541,32768,33031,12329,10400,52,32769,45340,32,41244,41351,8328,17,2185,4389,4233,10281,441,41380,256,41381,4541,41741]

theorem envBound27251 : H12AffineFastState.Bounded env27251 := by
  intro p hp
  have h : env27251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27250_27251 : H12AffineEnvironment.transform 9 52 env27250 = env27251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27250 == env27251) = true)

theorem identity27251 : scanCanonicalize (H12AffineFastState.compose env27251 (packedSelected [6,14] rootPS)) = affineNative (2^(14+1) ^^^ 8492) := by decide +kernel

theorem selectedBound27251 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env27252 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4541,8492,8235,12329,10400,52,8493,4144,32,48,171,8328,17,2185,4389,4233,10281,441,136,256,137,4541,545]

theorem envBound27252 : H12AffineFastState.Bounded env27252 := by
  intro p hp
  have h : env27252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27251_27252 : H12AffineEnvironment.transform 14 8492 env27251 = env27252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8492 env27251 == env27252) = true)

theorem identity27252 : scanCanonicalize (H12AffineFastState.compose env27252 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound27252 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env27253 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,301,4541,1,262,4356,2445,52,0,4144,32,48,171,421,17,2185,4389,4233,2308,441,136,256,137,4541,545]

theorem envBound27253 : H12AffineFastState.Bounded env27253 := by
  intro p hp
  have h : env27253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27252_27253 : H12AffineEnvironment.transform 12 301 env27252 = env27253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env27252 == env27253) = true)

theorem identity27253 : scanCanonicalize (H12AffineFastState.compose env27253 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27253 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27254 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,301,4405,1,262,4356,2309,52,0,4144,32,48,35,301,17,2049,4389,4097,2308,305,0,256,1,4405,545]

theorem envBound27254 : H12AffineFastState.Bounded env27254 := by
  intro p hp
  have h : env27254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27253_27254 : H12AffineEnvironment.transform 6 8 env27253 = env27254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27253 == env27254) = true)

theorem identity27254 : scanCanonicalize (H12AffineFastState.compose env27254 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27254 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27255 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,269,4373,1,262,4356,2309,20,0,4112,0,16,3,269,17,2049,4357,4097,2308,273,0,256,1,4373,513]

theorem envBound27255 : H12AffineFastState.Bounded env27255 := by
  intro p hp
  have h : env27255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27254_27255 : H12AffineEnvironment.transform 4 0 env27254 = env27255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27254 == env27255) = true)

theorem identity27255 : scanCanonicalize (H12AffineFastState.compose env27255 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound27255 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27256 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,1,269,276,1,262,261,2309,20,0,17,0,16,3,269,17,2049,260,0,2308,273,0,256,1,276,513]

theorem envBound27256 : H12AffineFastState.Bounded env27256 := by
  intro p hp
  have h : env27256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27255_27256 : H12AffineEnvironment.transform 11 1 env27255 = env27256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27255 == env27256) = true)

theorem identity27256 : scanCanonicalize (H12AffineFastState.compose env27256 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound27256 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27257 : List Nat := [2,4,8,16,0,16,8,256,261,20,2048,1,269,276,1,262,261,2309,20,0,17,0,16,3,269,17,2049,260,0,2308,273,0,256,1,276,260]

theorem envBound27257 : H12AffineFastState.Bounded env27257 := by
  intro p hp
  have h : env27257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27256_27257 : H12AffineEnvironment.transform 8 261 env27256 = env27257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env27256 == env27257) = true)

theorem identity27257 : scanCanonicalize (H12AffineFastState.compose env27257 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27257 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27258 : List Nat := [2,4,8,16,0,16,8,256,261,20,0,1,269,276,1,262,261,261,20,0,17,0,16,3,269,17,1,260,0,260,273,0,256,1,276,260]

theorem envBound27258 : H12AffineFastState.Bounded env27258 := by
  intro p hp
  have h : env27258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27257_27258 : H12AffineEnvironment.transform 10 0 env27257 = env27258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27257 == env27258) = true)

theorem identity27258 : scanCanonicalize (H12AffineFastState.compose env27258 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27258 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27259 : List Nat := [2,4,8,1,0,1,8,256,261,5,0,1,269,261,1,262,261,261,5,0,0,0,1,3,269,0,1,260,0,260,256,0,256,1,261,260]

theorem envBound27259 : H12AffineFastState.Bounded env27259 := by
  intro p hp
  have h : env27259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27258_27259 : H12AffineEnvironment.transform 3 1 env27258 = env27259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27258 == env27259) = true)

theorem identity27259 : scanCanonicalize (H12AffineFastState.compose env27259 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27259 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27260 : List Nat := [2,4,8,1,0,1,8,5,0,5,0,1,8,0,1,3,0,0,5,0,0,0,1,3,8,0,1,1,0,1,5,0,5,1,0,1]

theorem envBound27260 : H12AffineFastState.Bounded env27260 := by
  intro p hp
  have h : env27260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27259_27260 : H12AffineEnvironment.transform 7 5 env27259 = env27260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27259 == env27260) = true)

theorem identity27260 : scanCanonicalize (H12AffineFastState.compose env27260 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27261 : List Nat := [2,4,3,1,0,1,3,5,0,5,0,1,3,0,1,3,0,0,5,0,0,0,1,3,3,0,1,1,0,1,5,0,5,1,0,1]

theorem envBound27261 : H12AffineFastState.Bounded env27261 := by
  intro p hp
  have h : env27261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27260_27261 : H12AffineEnvironment.transform 2 3 env27260 = env27261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27260 == env27261) = true)

def env27262 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138428,1024,32769,58517,144444,62612,41350,8328,16,245139,115102,17664,10281,119043,201919,256,95531,103566,63109]

theorem envBound27262 : H12AffineFastState.Bounded env27262 := by
  intro p hp
  have h : env27262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27246_27262 : H12AffineEnvironment.transform 5 17 env27246 = env27262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27246 == env27262) = true)

theorem identity27262 : scanCanonicalize (H12AffineFastState.compose env27262 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound27262 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env27263 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,131072,138428,1024,32769,58517,144444,62612,41350,8328,16,171280,57629,17664,10281,61824,144444,256,21928,46093,63109]

theorem envBound27263 : H12AffineFastState.Bounded env27263 := by
  intro p hp
  have h : env27263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27262_27263 : H12AffineEnvironment.transform 15 8323 env27262 = env27263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env27262 == env27263) = true)

theorem identity27263 : scanCanonicalize (H12AffineFastState.compose env27263 (packedSelected [3,4,7,9,17,18,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 46229) := by decide +kernel

theorem selectedBound27263 : packedSelected [3,4,7,9,17,18,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env27264 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,46229,43049,1024,32769,58517,32937,62612,41350,8328,16,10629,57629,17664,10281,61824,32937,256,21928,46093,63109]

theorem envBound27264 : H12AffineFastState.Bounded env27264 := by
  intro p hp
  have h : env27264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27263_27264 : H12AffineEnvironment.transform 16 46229 env27263 = env27264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46229 env27263 == env27264) = true)

theorem identity27264 : scanCanonicalize (H12AffineFastState.compose env27264 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound27264 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env27265 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,46229,43049,1024,32769,45340,32937,41245,41350,8328,16,10629,46228,4233,10281,41993,32937,256,33,46093,41740]

theorem envBound27265 : H12AffineFastState.Bounded env27265 := by
  intro p hp
  have h : env27265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27264_27265 : H12AffineEnvironment.transform 13 5513 env27264 = env27265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27264 == env27265) = true)

theorem identity27265 : scanCanonicalize (H12AffineFastState.compose env27265 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27265 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env27266 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,32768,399,38297,35109,1024,32769,36880,32937,32785,32906,388,16,2185,38296,4233,2341,34053,32937,256,33,38145,33280]

theorem envBound27266 : H12AffineFastState.Bounded env27266 := by
  intro p hp
  have h : env27266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27265_27266 : H12AffineEnvironment.transform 12 268 env27265 = env27266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27265 == env27266) = true)

theorem identity27266 : scanCanonicalize (H12AffineFastState.compose env27266 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound27266 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27267 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,137,399,5392,2476,1024,136,4249,32,152,3,388,16,2185,5393,4233,2341,1420,32,256,33,5512,649]

theorem envBound27267 : H12AffineFastState.Bounded env27267 := by
  intro p hp
  have h : env27267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27266_27267 : H12AffineEnvironment.transform 14 137 env27266 = env27267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env27266 == env27267) = true)

theorem identity27267 : scanCanonicalize (H12AffineFastState.compose env27267 (packedSelected [4,6,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound27267 : packedSelected [4,6,9,10] rootPS < 2^1333 := by decide +kernel

def env27268 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2233,268,3376,137,399,3497,2476,1024,136,2080,32,152,3,388,16,2185,3496,2096,2341,1420,32,256,33,3377,649]

theorem envBound27268 : H12AffineFastState.Bounded env27268 := by
  intro p hp
  have h : env27268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27267_27268 : H12AffineEnvironment.transform 11 2233 env27267 = env27268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env27267 == env27268) = true)

theorem identity27268 : scanCanonicalize (H12AffineFastState.compose env27268 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27268 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env27269 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2097,268,3376,1,263,3361,2340,1024,0,2080,32,16,3,268,16,2049,3360,2096,2341,1284,32,256,33,3377,513]

theorem envBound27269 : H12AffineFastState.Bounded env27269 := by
  intro p hp
  have h : env27269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27268_27269 : H12AffineEnvironment.transform 6 8 env27268 = env27269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27268 == env27269) = true)

theorem identity27269 : scanCanonicalize (H12AffineFastState.compose env27269 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound27269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27270 : List Nat := [2,4,8,16,32,17,8,256,512,1024,309,260,268,1029,1,263,1044,17,1024,0,277,32,16,3,268,16,308,1045,261,16,1284,32,256,33,1028,513]

theorem envBound27270 : H12AffineFastState.Bounded env27270 := by
  intro p hp
  have h : env27270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27269_27270 : H12AffineEnvironment.transform 10 309 env27269 = env27270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env27269 == env27270) = true)

theorem identity27270 : scanCanonicalize (H12AffineFastState.compose env27270 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound27270 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27271 : List Nat := [2,4,8,16,32,17,8,256,512,784,309,260,268,789,1,263,772,17,784,0,277,32,16,3,268,16,308,773,261,16,532,32,256,33,788,513]

theorem envBound27271 : H12AffineFastState.Bounded env27271 := by
  intro p hp
  have h : env27271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27270_27271 : H12AffineEnvironment.transform 9 784 env27270 = env27271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env27270 == env27271) = true)

theorem identity27271 : scanCanonicalize (H12AffineFastState.compose env27271 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27271 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27272 : List Nat := [2,4,8,16,32,17,8,5,512,533,48,1,9,528,1,2,513,17,533,0,16,32,16,3,9,16,49,512,0,16,532,32,5,33,529,513]

theorem envBound27272 : H12AffineFastState.Bounded env27272 := by
  intro p hp
  have h : env27272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27271_27272 : H12AffineEnvironment.transform 7 5 env27271 = env27272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27271 == env27272) = true)

theorem identity27272 : scanCanonicalize (H12AffineFastState.compose env27272 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27272 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27273 : List Nat := [2,4,8,16,1,17,8,5,512,533,17,1,9,528,1,2,513,17,533,0,16,1,16,3,9,16,16,512,0,16,532,1,5,0,529,513]

theorem envBound27273 : H12AffineFastState.Bounded env27273 := by
  intro p hp
  have h : env27273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27272_27273 : H12AffineEnvironment.transform 4 1 env27272 = env27273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27272 == env27273) = true)

def env27274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,441658,8328,65,245138,115151,17664,10281,119043,329730,256,485830,493667,63188]

theorem envBound27274 : H12AffineFastState.Bounded env27274 := by
  intro p hp
  have h : env27274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27244_27274 : H12AffineEnvironment.transform 21 272513 env27244 = env27274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27244 == env27274) = true)

theorem identity27274 : scanCanonicalize (H12AffineFastState.compose env27274 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound27274 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396461,272513,400637,412143,8328,65,215367,79130,17664,10281,75222,329730,256,485830,490678,513]

theorem envBound27275 : H12AffineFastState.Bounded env27275 := by
  intro p hp
  have h : env27275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27274_27275 : H12AffineEnvironment.transform 14 29909 env27274 = env27275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env27274 == env27275) = true)

def env27276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396325,272393,400501,412007,8192,65,215367,79130,17664,10281,75102,329730,256,485710,490558,513]

theorem envBound27276 : H12AffineFastState.Bounded env27276 := by
  intro p hp
  have h : env27276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27275_27276 : H12AffineEnvironment.transform 6 8 env27275 = env27276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27275 == env27276) = true)

theorem identity27276 : scanCanonicalize (H12AffineFastState.compose env27276 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound27276 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,140301,33,144477,155983,8192,65,215367,79130,17664,10281,75102,73770,256,213350,218134,513]

theorem envBound27277 : H12AffineFastState.Bounded env27277 := by
  intro p hp
  have h : env27277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27276_27277 : H12AffineEnvironment.transform 17 10280 env27276 = env27277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env27276 == env27277) = true)

theorem identity27277 : scanCanonicalize (H12AffineFastState.compose env27277 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27277 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env27278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,140301,33,144477,144463,8192,65,203847,79130,4096,10281,75102,73770,256,201830,196886,513]

theorem envBound27278 : H12AffineFastState.Bounded env27278 := by
  intro p hp
  have h : env27278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27277_27278 : H12AffineEnvironment.transform 13 5376 env27277 = env27278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27277 == env27278) = true)

theorem identity27278 : scanCanonicalize (H12AffineFastState.compose env27278 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound27278 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,5393,10280,1024,8540,12572,33,8524,8542,8192,65,67926,79130,4096,10281,75102,73770,256,65911,70663,513]

theorem envBound27279 : H12AffineFastState.Bounded env27279 := by
  intro p hp
  have h : env27279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27278_27279 : H12AffineEnvironment.transform 16 5393 env27278 = env27279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env27278 == env27279) = true)

theorem identity27279 : scanCanonicalize (H12AffineFastState.compose env27279 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27279 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,65536,5393,2420,1024,0,4160,33,16,2,348,65,67926,70726,4096,2421,66562,65910,256,65911,70663,513]

theorem envBound27280 : H12AffineFastState.Bounded env27280 := by
  intro p hp
  have h : env27280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27279_27280 : H12AffineEnvironment.transform 12 348 env27279 = env27280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27279 == env27280) = true)

theorem identity27280 : scanCanonicalize (H12AffineFastState.compose env27280 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound27280 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,5393,2420,1024,0,4160,33,16,2,348,65,2049,5393,4096,2421,1365,33,256,32,5456,513]

theorem envBound27281 : H12AffineFastState.Bounded env27281 := by
  intro p hp
  have h : env27281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27280_27281 : H12AffineEnvironment.transform 15 343 env27280 = env27281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env27280 == env27281) = true)

theorem identity27281 : scanCanonicalize (H12AffineFastState.compose env27281 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound27281 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27282 : List Nat := [2,4,8,16,32,64,8,256,512,564,2048,4096,348,4916,1,343,4901,2420,564,0,4160,33,16,2,348,65,2049,4901,4096,2421,865,33,256,32,4964,513]

theorem envBound27282 : H12AffineFastState.Bounded env27282 := by
  intro p hp
  have h : env27282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27281_27282 : H12AffineEnvironment.transform 9 564 env27281 = env27282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env27281 == env27282) = true)

theorem identity27282 : scanCanonicalize (H12AffineFastState.compose env27282 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27282 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27283 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,4096,269,4916,1,262,4901,2341,564,0,4113,33,16,2,269,16,2049,4901,4096,2340,816,33,256,32,4917,513]

theorem envBound27283 : H12AffineFastState.Bounded env27283 := by
  intro p hp
  have h : env27283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27282_27283 : H12AffineEnvironment.transform 5 17 env27282 = env27283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27282 == env27283) = true)

theorem identity27283 : scanCanonicalize (H12AffineFastState.compose env27283 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound27283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27284 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,512,269,308,1,262,293,2341,564,0,529,33,16,2,269,16,2049,293,512,2340,816,33,256,32,309,513]

theorem envBound27284 : H12AffineFastState.Bounded env27284 := by
  intro p hp
  have h : env27284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27283_27284 : H12AffineEnvironment.transform 11 512 env27283 = env27284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env27283 == env27284) = true)

theorem identity27284 : scanCanonicalize (H12AffineFastState.compose env27284 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound27284 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27285 : List Nat := [2,4,8,16,32,17,8,256,512,564,821,512,269,308,1,262,293,528,564,0,529,33,16,2,269,16,820,293,512,529,816,33,256,32,309,513]

theorem envBound27285 : H12AffineFastState.Bounded env27285 := by
  intro p hp
  have h : env27285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27284_27285 : H12AffineEnvironment.transform 10 821 env27284 = env27285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env27284 == env27285) = true)

theorem identity27285 : scanCanonicalize (H12AffineFastState.compose env27285 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound27285 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27286 : List Nat := [2,4,8,16,32,17,8,256,293,273,16,293,269,308,1,262,293,309,273,0,308,33,16,2,269,16,17,293,293,308,21,33,256,32,309,292]

theorem envBound27286 : H12AffineFastState.Bounded env27286 := by
  intro p hp
  have h : env27286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27285_27286 : H12AffineEnvironment.transform 8 293 env27285 = env27286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env27285 == env27286) = true)

theorem identity27286 : scanCanonicalize (H12AffineFastState.compose env27286 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27286 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27287 : List Nat := [2,4,8,16,17,17,8,256,276,273,16,276,269,261,1,262,276,260,273,0,261,16,16,2,269,16,17,276,276,261,21,16,256,17,260,277]

theorem envBound27287 : H12AffineFastState.Bounded env27287 := by
  intro p hp
  have h : env27287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27286_27287 : H12AffineEnvironment.transform 4 17 env27286 = env27287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27286 == env27287) = true)

theorem identity27287 : scanCanonicalize (H12AffineFastState.compose env27287 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27287 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27288 : List Nat := [2,4,8,16,17,17,8,20,0,5,16,0,25,17,1,18,0,16,5,0,17,16,16,2,25,16,17,0,0,17,21,16,20,17,16,1]

theorem envBound27288 : H12AffineFastState.Bounded env27288 := by
  intro p hp
  have h : env27288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27287_27288 : H12AffineEnvironment.transform 7 20 env27287 = env27288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27287 == env27288) = true)

def env27289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396324,272392,400500,412006,8193,65,215367,79130,17664,10281,75103,329730,256,485711,490559,513]

theorem envBound27289 : H12AffineFastState.Bounded env27289 := by
  intro p hp
  have h : env27289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27275_27289 : H12AffineEnvironment.transform 6 9 env27275 = env27289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27275 == env27289) = true)

theorem identity27289 : scanCanonicalize (H12AffineFastState.compose env27289 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound27289 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,355390,272392,359534,338300,8193,65,10589,79130,17664,10281,75103,329730,256,264533,269349,513]

theorem envBound27290 : H12AffineFastState.Bounded env27290 := by
  intro p hp
  have h : env27290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27289_27290 : H12AffineEnvironment.transform 16 90138 env27289 = env27290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env27289 == env27290) = true)

theorem identity27290 : scanCanonicalize (H12AffineFastState.compose env27290 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound27290 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21511,13341,262144,1024,29789,276537,272392,272489,294267,8193,65,10589,24861,17664,10281,29016,285701,256,264533,269349,513]

theorem envBound27291 : H12AffineFastState.Bounded env27291 := by
  intro p hp
  have h : env27291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27290_27291 : H12AffineEnvironment.transform 15 21511 env27290 = env27291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env27290 == env27291) = true)

theorem identity27291 : scanCanonicalize (H12AffineFastState.compose env27291 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 22592) := by decide +kernel

theorem selectedBound27291 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env27292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21511,13341,22592,1024,29789,24697,28744,28713,9531,8193,65,10589,24861,17664,10281,29016,1093,256,20757,17509,513]

theorem envBound27292 : H12AffineFastState.Bounded env27292 := by
  intro p hp
  have h : env27292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27291_27292 : H12AffineEnvironment.transform 17 22592 env27291 = env27292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22592 env27291 == env27292) = true)

theorem identity27292 : scanCanonicalize (H12AffineFastState.compose env27292 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound27292 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env27293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12345,1125,9278,13341,10361,1024,1124,4160,113,16,9531,8193,65,10589,4388,13625,10281,353,1093,256,8492,13404,513]

theorem envBound27293 : H12AffineFastState.Bounded env27293 := by
  intro p hp
  have h : env27293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27292_27293 : H12AffineEnvironment.transform 13 12345 env27292 = env27293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env27292 == env27293) = true)

theorem identity27293 : scanCanonicalize (H12AffineFastState.compose env27293 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound27293 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27294 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,12345,292,8575,12636,10361,321,293,4160,113,16,8314,8193,65,10589,4388,12408,10281,353,260,256,8492,12573,513]

theorem envBound27294 : H12AffineFastState.Bounded env27294 := by
  intro p hp
  have h : env27294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27293_27294 : H12AffineEnvironment.transform 9 321 env27293 = env27294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27293 == env27294) = true)

theorem identity27294 : scanCanonicalize (H12AffineFastState.compose env27294 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27294 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27295 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,40,4113,292,343,4468,2129,321,293,4160,113,16,82,41,65,2421,4388,4176,2049,353,260,256,260,4405,513]

theorem envBound27295 : H12AffineFastState.Bounded env27295 := by
  intro p hp
  have h : env27295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27294_27295 : H12AffineEnvironment.transform 12 40 env27294 = env27295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27294 == env27295) = true)

theorem identity27295 : scanCanonicalize (H12AffineFastState.compose env27295 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound27295 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27296 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,512,40,529,292,343,884,2129,321,293,576,113,16,82,41,65,2421,804,592,2049,353,260,256,260,821,513]

theorem envBound27296 : H12AffineFastState.Bounded env27296 := by
  intro p hp
  have h : env27296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27295_27296 : H12AffineEnvironment.transform 11 512 env27295 = env27296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env27295 == env27296) = true)

theorem identity27296 : scanCanonicalize (H12AffineFastState.compose env27296 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound27296 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27297 : List Nat := [2,4,8,16,32,64,9,256,512,321,17,512,40,529,292,343,884,64,321,293,576,113,16,82,41,65,356,804,592,16,353,260,256,260,821,513]

theorem envBound27297 : H12AffineFastState.Bounded env27297 := by
  intro p hp
  have h : env27297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27296_27297 : H12AffineEnvironment.transform 10 17 env27296 = env27297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env27296 == env27297) = true)

theorem identity27297 : scanCanonicalize (H12AffineFastState.compose env27297 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27297 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env27298 : List Nat := [2,4,8,16,0,64,9,256,512,321,17,512,8,529,260,343,852,64,321,261,576,81,16,82,9,65,324,772,592,16,321,260,256,260,789,513]

theorem envBound27298 : H12AffineFastState.Bounded env27298 := by
  intro p hp
  have h : env27298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27297_27298 : H12AffineEnvironment.transform 4 0 env27297 = env27298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27297 == env27298) = true)

theorem identity27298 : scanCanonicalize (H12AffineFastState.compose env27298 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27298 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27299 : List Nat := [2,4,8,16,0,64,9,4,512,69,17,512,8,529,0,83,592,64,69,1,576,81,16,82,9,65,64,512,592,16,69,0,4,0,529,513]

theorem envBound27299 : H12AffineFastState.Bounded env27299 := by
  intro p hp
  have h : env27299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27298_27299 : H12AffineEnvironment.transform 7 4 env27298 = env27299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27298 == env27299) = true)

theorem identity27299 : scanCanonicalize (H12AffineFastState.compose env27299 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27300 : List Nat := [2,4,8,0,0,64,9,4,512,69,1,512,8,513,0,67,576,64,69,1,576,65,0,66,9,65,64,512,576,0,69,0,4,0,513,513]

theorem envBound27300 : H12AffineFastState.Bounded env27300 := by
  intro p hp
  have h : env27300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27299_27300 : H12AffineEnvironment.transform 3 0 env27299 = env27300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27299 == env27300) = true)

theorem identity27300 : scanCanonicalize (H12AffineFastState.compose env27300 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27301 : List Nat := [2,4,8,0,0,64,9,4,0,69,1,0,8,1,0,67,64,64,69,1,64,65,0,66,9,65,64,0,64,0,69,0,4,0,1,1]

theorem envBound27301 : H12AffineFastState.Bounded env27301 := by
  intro p hp
  have h : env27301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27300_27301 : H12AffineEnvironment.transform 8 0 env27300 = env27301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27300 == env27301) = true)

def env27302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,441659,8328,65,4691218,115151,17665,10281,119042,4268163,256,485830,493667,63189]

theorem envBound27302 : H12AffineFastState.Bounded env27302 := by
  intro p hp
  have h : env27302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27243_27302 : H12AffineEnvironment.transform 20 456825 env27243 = env27302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env27243 == env27302) = true)

def env27303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,441659,8328,65,245138,115151,17665,10281,119042,329731,256,485830,493667,63189]

theorem envBound27303 : H12AffineFastState.Bounded env27303 := by
  intro p hp
  have h : env27303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27302_27303 : H12AffineEnvironment.transform 21 272512 env27302 = env27303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27302 == env27303) = true)

theorem identity27303 : scanCanonicalize (H12AffineFastState.compose env27303 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound27303 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180408,16,21763,8328,65,245138,115151,17665,10281,119042,254011,256,98814,90203,63189]

theorem envBound27304 : H12AffineFastState.Bounded env27304 := by
  intro p hp
  have h : env27304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27303_27304 : H12AffineEnvironment.transform 17 190520 env27303 = env27304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env27303 == env27304) = true)

def env27305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180272,16,21763,8192,65,245018,115015,17665,10281,119042,254011,256,98678,90203,63069]

theorem envBound27305 : H12AffineFastState.Bounded env27305 := by
  intro p hp
  have h : env27305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27304_27305 : H12AffineEnvironment.transform 6 8 env27304 = env27305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27304 == env27305) = true)

theorem identity27305 : scanCanonicalize (H12AffineFastState.compose env27305 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound27305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56436,1024,32769,4161,62588,16,21763,8192,65,100694,115015,17665,10281,119042,119927,256,98678,90203,63069]

theorem envBound27306 : H12AffineFastState.Bounded env27306 := by
  intro p hp
  have h : env27306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27305_27306 : H12AffineEnvironment.transform 16 13388 env27305 = env27306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env27305 == env27306) = true)

theorem identity27306 : scanCanonicalize (H12AffineFastState.compose env27306 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27306 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env27307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,13388,23668,1024,1,4161,29820,16,21763,8192,65,67926,82247,17665,10281,86274,87159,256,65910,90203,30301]

theorem envBound27307 : H12AffineFastState.Bounded env27307 := by
  intro p hp
  have h : env27307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27306_27307 : H12AffineEnvironment.transform 14 0 env27306 = env27307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27306 == env27307) = true)

theorem identity27307 : scanCanonicalize (H12AffineFastState.compose env27307 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound27307 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,65536,13388,2341,1024,1,4161,8493,16,82,8192,65,67926,70678,4176,10281,66643,65830,256,65910,79114,8972]

theorem envBound27308 : H12AffineFastState.Bounded env27308 := by
  intro p hp
  have h : env27308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27307_27308 : H12AffineEnvironment.transform 13 5457 env27307 = env27308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env27307 == env27308) = true)

theorem identity27308 : scanCanonicalize (H12AffineFastState.compose env27308 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27308 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env27309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,342,13388,2341,1024,1,4161,8493,16,82,8192,65,2048,5440,4176,10281,1285,112,256,32,13404,8972]

theorem envBound27309 : H12AffineFastState.Bounded env27309 := by
  intro p hp
  have h : env27309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27308_27309 : H12AffineEnvironment.transform 15 342 env27308 = env27309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27308 == env27309) = true)

theorem identity27309 : scanCanonicalize (H12AffineFastState.compose env27309 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27309 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,0,342,5441,2341,1024,1,4161,32,16,82,269,65,2048,5440,4176,2340,1285,112,256,32,5457,513]

theorem envBound27310 : H12AffineFastState.Bounded env27310 := by
  intro p hp
  have h : env27310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27309_27310 : H12AffineEnvironment.transform 12 269 env27309 = env27310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27309 == env27310) = true)

def env27311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180273,16,21763,8193,65,245019,115014,17665,10281,119042,254011,256,98679,90203,63068]

theorem envBound27311 : H12AffineFastState.Bounded env27311 := by
  intro p hp
  have h : env27311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27304_27311 : H12AffineEnvironment.transform 6 9 env27304 = env27311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27304 == env27311) = true)

theorem identity27311 : scanCanonicalize (H12AffineFastState.compose env27311 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound27311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,32040,1024,32769,4161,21793,16,21763,8193,65,75787,115014,17665,10281,119042,95531,256,98679,90203,63068]

theorem envBound27312 : H12AffineFastState.Bounded env27312 := by
  intro p hp
  have h : env27312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27311_27312 : H12AffineEnvironment.transform 16 38160 env27311 = env27312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env27311 == env27312) = true)

theorem identity27312 : scanCanonicalize (H12AffineFastState.compose env27312 (packedSelected [10,16,18,20,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound27312 : packedSelected [10,16,18,20,23,31] rootPS < 2^1333 := by decide +kernel

def env27313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,32040,1024,32769,4161,21793,16,21763,8193,65,56577,13388,17665,10281,9224,32801,256,29821,38225,63068]

theorem envBound27313 : H12AffineFastState.Bounded env27313 := by
  intro p hp
  have h : env27313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27312_27313 : H12AffineEnvironment.transform 15 62730 env27312 = env27313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env27312 == env27313) = true)

theorem identity27313 : scanCanonicalize (H12AffineFastState.compose env27313 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27313 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,24909,32040,1024,29788,4161,21793,16,21763,8193,65,10588,13388,17665,10281,9224,29820,256,29821,24844,513]

theorem envBound27314 : H12AffineFastState.Bounded env27314 := by
  intro p hp
  have h : env27314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27313_27314 : H12AffineEnvironment.transform 14 29789 env27313 = env27314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27313 == env27314) = true)

theorem identity27314 : scanCanonicalize (H12AffineFastState.compose env27314 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound27314 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,20497,343,17665,22884,1024,20496,4161,21793,16,21763,1101,65,3344,4096,17665,3173,68,20528,256,20529,17728,513]

theorem envBound27315 : H12AffineFastState.Bounded env27315 := by
  intro p hp
  have h : env27315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27314_27315 : H12AffineEnvironment.transform 12 1100 env27314 = env27315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env27314 == env27315) = true)

theorem identity27315 : scanCanonicalize (H12AffineFastState.compose env27315 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound27315 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27316 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,40,16384,20497,343,16741,22884,100,20496,4161,20805,16,20839,41,65,2420,4096,16741,2049,68,20528,256,20529,16676,513]

theorem envBound27316 : H12AffineFastState.Bounded env27316 := by
  intro p hp
  have h : env27316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27315_27316 : H12AffineEnvironment.transform 9 100 env27315 = env27316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env27315 == env27316) = true)

theorem identity27316 : scanCanonicalize (H12AffineFastState.compose env27316 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound27316 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env27317 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,40,4112,1,343,4469,2420,100,0,4161,341,16,375,41,65,2420,4096,4469,2049,68,32,256,33,4404,513]

theorem envBound27317 : H12AffineFastState.Bounded env27317 := by
  intro p hp
  have h : env27317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27316_27317 : H12AffineEnvironment.transform 13 4112 env27316 = env27317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env27316 == env27317) = true)

theorem identity27317 : scanCanonicalize (H12AffineFastState.compose env27317 (packedSelected [0,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2885) := by decide +kernel

theorem selectedBound27317 : packedSelected [0,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27318 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2885,40,2901,1,343,2608,2420,100,0,2820,341,16,375,41,65,2420,2885,2608,2049,68,32,256,33,2673,513]

theorem envBound27318 : H12AffineFastState.Bounded env27318 := by
  intro p hp
  have h : env27318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27317_27318 : H12AffineEnvironment.transform 11 2885 env27317 = env27318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2885 env27317 == env27318) = true)

theorem identity27318 : scanCanonicalize (H12AffineFastState.compose env27318 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound27318 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env27319 : List Nat := [2,4,8,16,32,64,9,256,512,100,545,356,40,372,1,343,17,853,100,0,293,341,16,375,41,65,853,356,17,544,68,32,256,33,80,513]

theorem envBound27319 : H12AffineFastState.Bounded env27319 := by
  intro p hp
  have h : env27319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27318_27319 : H12AffineEnvironment.transform 10 545 env27318 = env27319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env27318 == env27319) = true)

theorem identity27319 : scanCanonicalize (H12AffineFastState.compose env27319 (packedSelected [2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound27319 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env27320 : List Nat := [2,4,8,16,32,64,9,256,260,100,293,356,40,372,1,343,17,81,100,0,293,341,16,375,41,65,81,356,17,292,68,32,256,33,80,261]

theorem envBound27320 : H12AffineFastState.Bounded env27320 := by
  intro p hp
  have h : env27320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27319_27320 : H12AffineEnvironment.transform 8 260 env27319 = env27320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env27319 == env27320) = true)

theorem identity27320 : scanCanonicalize (H12AffineFastState.compose env27320 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27320 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27321 : List Nat := [2,4,8,16,32,64,9,117,113,100,80,17,40,1,1,34,17,81,100,0,80,32,16,2,41,65,81,17,17,81,68,32,117,33,80,112]

theorem envBound27321 : H12AffineFastState.Bounded env27321 := by
  intro p hp
  have h : env27321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27320_27321 : H12AffineEnvironment.transform 7 117 env27320 = env27321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27320 == env27321) = true)

theorem identity27321 : scanCanonicalize (H12AffineFastState.compose env27321 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27322 : List Nat := [2,4,8,16,32,16,9,37,33,52,0,17,40,1,1,34,17,1,52,0,0,32,16,2,41,17,1,17,17,1,20,32,37,33,0,32]

theorem envBound27322 : H12AffineFastState.Bounded env27322 := by
  intro p hp
  have h : env27322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27321_27322 : H12AffineEnvironment.transform 5 16 env27321 = env27322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27321 == env27322) = true)

theorem identity27322 : scanCanonicalize (H12AffineFastState.compose env27322 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27323 : List Nat := [2,4,8,16,1,16,9,4,0,21,0,17,9,1,1,3,17,1,21,0,0,1,16,2,8,17,1,17,17,1,20,1,4,0,0,1]

theorem envBound27323 : H12AffineFastState.Bounded env27323 := by
  intro p hp
  have h : env27323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27322_27323 : H12AffineEnvironment.transform 4 1 env27322 = env27323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27322 == env27323) = true)

def env27324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,441659,8328,65,245139,115151,17665,10281,119042,329730,256,485830,493667,63189]

theorem envBound27324 : H12AffineFastState.Bounded env27324 := by
  intro p hp
  have h : env27324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27302_27324 : H12AffineEnvironment.transform 21 272513 env27302 = env27324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27302 == env27324) = true)

def env27325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452648,441659,8192,65,245019,115015,17665,10281,119042,329730,256,485710,493667,63069]

theorem envBound27325 : H12AffineFastState.Bounded env27325 := by
  intro p hp
  have h : env27325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27324_27325 : H12AffineEnvironment.transform 6 8 env27324 = env27325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27324 == env27325) = true)

def env27326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272393,272440,294187,8192,65,97547,115015,17665,10281,119042,329730,256,371038,346227,63069]

theorem envBound27326 : H12AffineFastState.Bounded env27326 := by
  intro p hp
  have h : env27326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27325_27326 : H12AffineEnvironment.transform 16 49168 env27325 = env27326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27325 == env27326) = true)

theorem identity27326 : scanCanonicalize (H12AffineFastState.compose env27326 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound27326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1024,29789,276585,272393,272440,294187,8192,65,97547,79131,17665,10281,75102,329730,256,351490,346227,513]

theorem envBound27327 : H12AffineFastState.Bounded env27327 := by
  intro p hp
  have h : env27327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27326_27327 : H12AffineEnvironment.transform 14 29788 env27326 = env27327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env27326 == env27327) = true)

theorem identity27327 : scanCanonicalize (H12AffineFastState.compose env27327 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound27327 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10280,1024,29789,4161,33,16,21763,8192,65,97547,79131,17665,10281,75102,73770,256,95530,90203,513]

theorem envBound27328 : H12AffineFastState.Bounded env27328 := by
  intro p hp
  have h : env27328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27327_27328 : H12AffineEnvironment.transform 17 10280 env27327 = env27328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env27327 == env27328) = true)

theorem identity27328 : scanCanonicalize (H12AffineFastState.compose env27328 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound27328 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,262,13388,10280,1024,29789,4161,33,16,21763,8192,65,31757,13341,17665,10281,9304,8492,256,29740,24925,513]

theorem envBound27329 : H12AffineFastState.Bounded env27329 := by
  intro p hp
  have h : env27329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27328_27329 : H12AffineEnvironment.transform 15 262 env27328 = env27329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env27328 == env27329) = true)

theorem identity27329 : scanCanonicalize (H12AffineFastState.compose env27329 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound27329 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,262,13388,10280,1024,8461,4161,33,16,83,8192,65,10589,13341,4177,10281,9304,8492,256,8572,13325,513]

theorem envBound27330 : H12AffineFastState.Bounded env27330 := by
  intro p hp
  have h : env27330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27329_27330 : H12AffineEnvironment.transform 13 5456 env27329 = env27330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env27329 == env27330) = true)

theorem identity27330 : scanCanonicalize (H12AffineFastState.compose env27330 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27330 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,80,262,5392,2420,1024,81,4161,33,16,83,348,65,2049,5441,4177,2421,1284,112,256,32,5457,513]

theorem envBound27331 : H12AffineFastState.Bounded env27331 := by
  intro p hp
  have h : env27331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27330_27331 : H12AffineEnvironment.transform 12 348 env27330 = env27331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27330 == env27331) = true)

theorem identity27331 : scanCanonicalize (H12AffineFastState.compose env27331 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound27331 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env27332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1280,4096,348,5456,80,262,5392,1140,1024,81,4161,33,16,83,348,65,1281,5441,4177,1141,1284,112,256,32,5457,513]

theorem envBound27332 : H12AffineFastState.Bounded env27332 := by
  intro p hp
  have h : env27332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27331_27332 : H12AffineEnvironment.transform 10 1280 env27331 = env27332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env27331 == env27332) = true)

theorem identity27332 : scanCanonicalize (H12AffineFastState.compose env27332 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound27332 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env27333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1280,81,348,1281,80,262,1345,1140,1024,81,16,33,16,83,348,65,1281,1296,0,1141,1284,112,256,32,1280,513]

theorem envBound27333 : H12AffineFastState.Bounded env27333 := by
  intro p hp
  have h : env27333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27332_27333 : H12AffineEnvironment.transform 11 81 env27332 = env27333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env27332 == env27333) = true)

theorem identity27333 : scanCanonicalize (H12AffineFastState.compose env27333 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27333 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env27334 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1280,0,269,1281,1,262,1296,1061,1024,0,16,33,16,2,269,16,1281,1296,0,1060,1284,33,256,32,1280,513]

theorem envBound27334 : H12AffineFastState.Bounded env27334 := by
  intro p hp
  have h : env27334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27333_27334 : H12AffineEnvironment.transform 5 17 env27333 = env27334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27333 == env27334) = true)

theorem identity27334 : scanCanonicalize (H12AffineFastState.compose env27334 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound27334 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27335 : List Nat := [2,4,8,16,32,17,8,256,512,53,309,0,269,308,1,262,293,16,53,0,16,33,16,2,269,16,308,293,0,17,305,33,256,32,309,513]

theorem envBound27335 : H12AffineFastState.Bounded env27335 := by
  intro p hp
  have h : env27335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27334_27335 : H12AffineEnvironment.transform 9 53 env27334 = env27335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env27334 == env27335) = true)

theorem identity27335 : scanCanonicalize (H12AffineFastState.compose env27335 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27335 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27336 : List Nat := [2,4,8,16,32,17,8,256,0,53,309,0,269,308,1,262,293,16,53,0,16,33,16,2,269,16,308,293,0,17,305,33,256,32,309,1]

theorem envBound27336 : H12AffineFastState.Bounded env27336 := by
  intro p hp
  have h : env27336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27335_27336 : H12AffineEnvironment.transform 8 0 env27335 = env27336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27335 == env27336) = true)

theorem identity27336 : scanCanonicalize (H12AffineFastState.compose env27336 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27336 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27337 : List Nat := [2,4,8,16,32,17,8,37,0,53,16,0,40,17,1,35,0,16,53,0,16,33,16,2,40,16,17,0,0,17,20,33,37,32,16,1]

theorem envBound27337 : H12AffineFastState.Bounded env27337 := by
  intro p hp
  have h : env27337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27336_27337 : H12AffineEnvironment.transform 7 37 env27336 = env27337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27336 == env27337) = true)

theorem identity27337 : scanCanonicalize (H12AffineFastState.compose env27337 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27338 : List Nat := [2,4,8,16,0,17,8,5,0,21,16,0,8,17,1,3,0,16,21,0,16,1,16,2,8,16,17,0,0,17,20,1,5,0,16,1]

theorem envBound27338 : H12AffineFastState.Bounded env27338 := by
  intro p hp
  have h : env27338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27337_27338 : H12AffineEnvironment.transform 4 0 env27337 = env27338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27337 == env27338) = true)

theorem identity27338 : scanCanonicalize (H12AffineFastState.compose env27338 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27339 : List Nat := [2,4,8,0,0,1,8,5,0,5,0,0,8,1,1,3,0,0,5,0,0,1,0,2,8,0,1,0,0,1,4,1,5,0,0,1]

theorem envBound27339 : H12AffineFastState.Bounded env27339 := by
  intro p hp
  have h : env27339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27338_27339 : H12AffineEnvironment.transform 3 0 env27338 = env27339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27338 == env27339) = true)

def env27340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272393,272441,294186,8192,65,97546,115015,17665,10281,119042,329730,256,371039,346226,63069]

theorem envBound27340 : H12AffineFastState.Bounded env27340 := by
  intro p hp
  have h : env27340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27325_27340 : H12AffineEnvironment.transform 16 49169 env27325 = env27340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27325 == env27340) = true)

theorem identity27340 : scanCanonicalize (H12AffineFastState.compose env27340 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound27340 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56436,1024,32769,58396,62589,62541,41310,8192,65,97546,115015,17665,10281,119042,119926,256,95531,103430,63069]

theorem envBound27341 : H12AffineFastState.Bounded env27341 := by
  intro p hp
  have h : env27341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27340_27341 : H12AffineEnvironment.transform 17 56436 env27340 = env27341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env27340 == env27341) = true)

theorem identity27341 : scanCanonicalize (H12AffineFastState.compose env27341 (packedSelected [0,4,5,7,9,10,11,15,16,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound27341 : packedSelected [0,4,5,7,9,10,11,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env27342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,65536,5441,2340,1024,21841,12620,8493,8477,29710,8192,65,97546,70679,17665,10281,66642,65830,256,95531,82262,8973]

theorem envBound27342 : H12AffineFastState.Bounded env27342 := by
  intro p hp
  have h : env27342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27341_27342 : H12AffineEnvironment.transform 14 21840 env27341 = env27342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env27341 == env27342) = true)

theorem identity27342 : scanCanonicalize (H12AffineFastState.compose env27342 (packedSelected [1,3,4,5,8,14,15,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27342 : packedSelected [1,3,4,5,8,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env27343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8460,65536,5441,2340,1024,8461,12620,8493,8477,82,8192,65,67926,70679,12637,10281,66642,65830,256,65911,79114,8973]

theorem envBound27343 : H12AffineFastState.Bounded env27343 := by
  intro p hp
  have h : env27343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27342_27343 : H12AffineEnvironment.transform 13 13404 env27342 = env27343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27342 == env27343) = true)

theorem identity27343 : scanCanonicalize (H12AffineFastState.compose env27343 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27343 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,80,65536,5441,2340,1024,81,4112,113,65,82,348,65,67926,70679,4097,2421,66642,65830,256,65911,70742,593]

theorem envBound27344 : H12AffineFastState.Bounded env27344 := by
  intro p hp
  have h : env27344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27343_27344 : H12AffineEnvironment.transform 12 348 env27343 = env27344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27343 == env27344) = true)

theorem identity27344 : scanCanonicalize (H12AffineFastState.compose env27344 (packedSelected [1,2,3,5,6,8,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound27344 : packedSelected [1,2,3,5,6,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,80,343,5441,2340,1024,81,4112,113,65,82,348,65,2049,5440,4097,2421,1285,113,256,32,5377,593]

theorem envBound27345 : H12AffineFastState.Bounded env27345 := by
  intro p hp
  have h : env27345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27344_27345 : H12AffineEnvironment.transform 15 343 env27344 = env27345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env27344 == env27345) = true)

theorem identity27345 : scanCanonicalize (H12AffineFastState.compose env27345 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound27345 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env27346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,348,3392,80,343,3329,2340,1024,81,2128,113,65,82,348,65,2049,3328,2113,2421,1285,113,256,32,3393,593]

theorem envBound27346 : H12AffineFastState.Bounded env27346 := by
  intro p hp
  have h : env27346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27345_27346 : H12AffineEnvironment.transform 11 2112 env27345 = env27346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env27345 == env27346) = true)

theorem identity27346 : scanCanonicalize (H12AffineFastState.compose env27346 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27346 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27347 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,269,3345,1,262,3329,2340,1024,0,2049,32,16,3,269,16,2049,3328,2064,2340,1285,32,256,32,3344,512]

theorem envBound27347 : H12AffineFastState.Bounded env27347 := by
  intro p hp
  have h : env27347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27346_27347 : H12AffineEnvironment.transform 5 17 env27346 = env27347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27346 == env27347) = true)

theorem identity27347 : scanCanonicalize (H12AffineFastState.compose env27347 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound27347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27348 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1313,1328,269,48,1,262,32,1029,1024,0,1312,32,16,3,269,16,1312,33,1329,1029,1285,32,256,32,49,512]

theorem envBound27348 : H12AffineFastState.Bounded env27348 := by
  intro p hp
  have h : env27348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27347_27348 : H12AffineEnvironment.transform 10 1313 env27347 = env27348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env27347 == env27348) = true)

theorem identity27348 : scanCanonicalize (H12AffineFastState.compose env27348 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound27348 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27349 : List Nat := [2,4,8,16,32,17,8,256,512,549,772,789,269,48,1,262,32,544,549,0,773,32,16,3,269,16,773,33,788,544,800,32,256,32,49,512]

theorem envBound27349 : H12AffineFastState.Bounded env27349 := by
  intro p hp
  have h : env27349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27348_27349 : H12AffineEnvironment.transform 9 549 env27348 = env27349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env27348 == env27349) = true)

theorem identity27349 : scanCanonicalize (H12AffineFastState.compose env27349 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound27349 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27350 : List Nat := [2,4,8,16,32,17,8,256,49,20,309,292,269,48,1,262,32,17,20,0,308,32,16,3,269,16,308,33,293,17,273,32,256,32,49,49]

theorem envBound27350 : H12AffineFastState.Bounded env27350 := by
  intro p hp
  have h : env27350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27349_27350 : H12AffineEnvironment.transform 8 49 env27349 = env27350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env27349 == env27350) = true)

theorem identity27350 : scanCanonicalize (H12AffineFastState.compose env27350 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27350 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27351 : List Nat := [2,4,8,1,32,0,8,256,32,5,292,292,269,33,1,262,32,0,5,0,293,32,1,3,269,1,293,33,293,0,256,32,256,32,32,32]

theorem envBound27351 : H12AffineFastState.Bounded env27351 := by
  intro p hp
  have h : env27351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27350_27351 : H12AffineEnvironment.transform 3 1 env27350 = env27351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27350 == env27351) = true)

theorem identity27351 : scanCanonicalize (H12AffineFastState.compose env27351 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27352 : List Nat := [2,4,8,1,32,0,8,36,32,5,0,0,41,33,1,34,32,0,5,0,1,32,1,3,41,1,1,33,1,0,36,32,36,32,32,32]

theorem envBound27352 : H12AffineFastState.Bounded env27352 := by
  intro p hp
  have h : env27352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27351_27352 : H12AffineEnvironment.transform 7 36 env27351 = env27352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27351 == env27352) = true)

theorem identity27352 : scanCanonicalize (H12AffineFastState.compose env27352 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27352 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27353 : List Nat := [2,4,8,1,1,0,8,5,1,5,0,0,8,0,1,3,1,0,5,0,1,1,1,3,8,1,1,0,1,0,5,1,5,1,1,1]

theorem envBound27353 : H12AffineFastState.Bounded env27353 := by
  intro p hp
  have h : env27353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27352_27353 : H12AffineEnvironment.transform 4 1 env27352 = env27353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27352 == env27353) = true)

theorem identity27353 : scanCanonicalize (H12AffineFastState.compose env27353 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound27353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27354 : List Nat := [2,4,6,1,1,0,6,5,1,5,0,0,6,0,1,3,1,0,5,0,1,1,1,3,6,1,1,0,1,0,5,1,5,1,1,1]

theorem envBound27354 : H12AffineFastState.Bounded env27354 := by
  intro p hp
  have h : env27354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27353_27354 : H12AffineEnvironment.transform 2 6 env27353 = env27354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env27353 == env27354) = true)

def env27355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452648,441659,8193,65,245018,115014,17665,10281,119042,329730,256,485711,493667,63068]

theorem envBound27355 : H12AffineFastState.Bounded env27355 := by
  intro p hp
  have h : env27355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27324_27355 : H12AffineEnvironment.transform 6 9 env27324 = env27355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27324 == env27355) = true)

def env27356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272392,272440,294187,8193,65,97546,115014,17665,10281,119042,329730,256,371039,346227,63068]

theorem envBound27356 : H12AffineFastState.Bounded env27356 := by
  intro p hp
  have h : env27356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27355_27356 : H12AffineEnvironment.transform 16 49168 env27355 = env27356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27355 == env27356) = true)

theorem identity27356 : scanCanonicalize (H12AffineFastState.compose env27356 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound27356 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1024,32769,17729,21792,21776,3,8193,65,97546,115014,17665,10281,119042,95530,256,119927,79195,63068]

theorem envBound27357 : H12AffineFastState.Bounded env27357 := by
  intro p hp
  have h : env27357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27356_27357 : H12AffineEnvironment.transform 17 32040 env27356 = env27357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env27356 == env27357) = true)

theorem identity27357 : scanCanonicalize (H12AffineFastState.compose env27357 (packedSelected [0,1,4,5,10,12,14,15,18,19,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound27357 : packedSelected [0,1,4,5,10,12,14,15,18,19,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29823,49168,32040,1024,32769,17729,21792,21776,3,8193,65,2421,46393,17665,10281,42365,341,256,40968,16676,63068]

theorem envBound27358 : H12AffineFastState.Bounded env27358 := by
  intro p hp
  have h : env27358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27357_27358 : H12AffineEnvironment.transform 15 29823 env27357 = env27358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env27357 == env27358) = true)

theorem identity27358 : scanCanonicalize (H12AffineFastState.compose env27358 (packedSelected [0,1,2,5,6,8,11,14,16,18,19,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27358 : packedSelected [0,1,2,5,6,8,11,14,16,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,21794,49168,23669,1024,32769,17729,21792,21776,3,348,65,2421,37988,17665,2420,33824,341,256,33109,16676,55041]

theorem envBound27359 : H12AffineFastState.Bounded env27359 := by
  intro p hp
  have h : env27359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27358_27359 : H12AffineEnvironment.transform 12 349 env27358 = env27359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27358 == env27359) = true)

theorem identity27359 : scanCanonicalize (H12AffineFastState.compose env27359 (packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound27359 : packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env27360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5157,32768,263,37941,2128,1024,32769,4452,261,309,3,348,65,2421,37988,4388,2420,33824,341,256,33109,5377,33572]

theorem envBound27360 : H12AffineFastState.Bounded env27360 := by
  intro p hp
  have h : env27360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27359_27360 : H12AffineEnvironment.transform 13 5157 env27359 = env27360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env27359 == env27360) = true)

theorem identity27360 : scanCanonicalize (H12AffineFastState.compose env27360 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27360 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27361 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5157,32768,115,37941,2128,1024,32769,4112,113,65,3,40,65,2049,37988,4176,2048,33824,33,116,32801,5237,33360]

theorem envBound27361 : H12AffineFastState.Bounded env27361 := by
  intro p hp
  have h : env27361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27360_27361 : H12AffineEnvironment.transform 7 116 env27360 = env27361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27360 == env27361) = true)

theorem identity27361 : scanCanonicalize (H12AffineFastState.compose env27361 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27361 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env27362 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,32768,35,37941,2048,1024,32769,4112,33,17,3,40,17,2049,37940,4096,2048,33824,33,36,32801,5157,33280]

theorem envBound27362 : H12AffineFastState.Bounded env27362 := by
  intro p hp
  have h : env27362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27361_27362 : H12AffineEnvironment.transform 5 16 env27361 = env27362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27361 == env27362) = true)

theorem identity27362 : scanCanonicalize (H12AffineFastState.compose env27362 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 6682) := by decide +kernel

theorem selectedBound27362 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env27363 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,6682,35,3631,2048,1024,6683,4112,33,17,3,40,17,2049,3630,4096,2048,7738,33,36,6715,5157,6170]

theorem envBound27363 : H12AffineFastState.Bounded env27363 := by
  intro p hp
  have h : env27363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27362_27363 : H12AffineEnvironment.transform 14 6682 env27362 = env27363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6682 env27362 == env27363) = true)

theorem identity27363 : scanCanonicalize (H12AffineFastState.compose env27363 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound27363 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env27364 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,3077,41,2080,1567,35,3631,2048,1024,1566,3093,33,17,3,40,17,2049,3630,3077,2048,575,33,36,1598,2080,1055]

theorem envBound27364 : H12AffineFastState.Bounded env27364 := by
  intro p hp
  have h : env27364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27363_27364 : H12AffineEnvironment.transform 11 3077 env27363 = env27364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env27363 == env27364) = true)

theorem identity27364 : scanCanonicalize (H12AffineFastState.compose env27364 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27364 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27365 : List Nat := [2,4,8,10,32,10,9,36,512,1024,2048,3077,41,2080,1541,35,3631,2048,1024,1540,3087,33,11,3,40,11,2049,3630,3077,2048,549,33,36,1572,2080,1029]

theorem envBound27365 : H12AffineFastState.Bounded env27365 := by
  intro p hp
  have h : env27365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27364_27365 : H12AffineEnvironment.transform 3 10 env27364 = env27365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27364 == env27365) = true)

end H12CloudChart1