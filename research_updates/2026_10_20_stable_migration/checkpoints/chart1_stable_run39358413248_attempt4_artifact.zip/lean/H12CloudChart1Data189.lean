import H12CloudChart1Data188

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def tree47875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47875 : H12WitnessSearch.Good tree47875 := H12GlobalWitnessIndex.good

theorem leafIdentity47875 : H12AffineFastState.composeSystem env47875 rootObs = leafEnv47875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47875 rootObs == leafEnv47875) = true)

theorem terminalChecked47875 : H12PackedTerminal.terminalCheckFast leafEnv47875 active47875 tree47875 = true := by decide +kernel

def env47876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787196,79131,8466459,8820104,8389957,98814,256,8462514,8492191,8462995]

theorem envBound47876 : H12AffineFastState.Bounded env47876 := by
  intro p hp
  have h : env47876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47842_47876 : H12AffineEnvironment.transform 21 33 env47842 = env47876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47842 == env47876) = true)

theorem identity47876 : scanCanonicalize (H12AffineFastState.compose env47876 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound47876 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,262144,1024,32769,45340,33,8388608,138,8328,64,8787196,46276,8434116,8820104,8389957,33,256,8429933,8394048,8430412]

theorem envBound47877 : H12AffineFastState.Bounded env47877 := by
  intro p hp
  have h : env47877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47876_47877 : H12AffineEnvironment.transform 15 33247 env47876 = env47877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env47876 == env47877) = true)

theorem identity47877 : scanCanonicalize (H12AffineFastState.compose env47877 (packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 297453) := by decide +kernel

theorem selectedBound47877 : packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env47878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,262144,1024,32769,45340,33,297453,138,8328,64,171281,46276,276521,138341,298152,33,256,272512,302253,273057]

theorem envBound47878 : H12AffineFastState.Bounded env47878 := by
  intro p hp
  have h : env47878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47877_47878 : H12AffineEnvironment.transform 22 297453 env47877 = env47878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297453 env47877 == env47878) = true)

def env47879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,10280,1024,32769,45340,33,41413,138,8328,64,171281,46276,4097,138341,42112,33,256,168,46213,649]

theorem envBound47879 : H12AffineFastState.Bounded env47879 := by
  intro p hp
  have h : env47879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47878_47879 : H12AffineEnvironment.transform 17 10280 env47878 = env47879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47878 == env47879) = true)

theorem identity47879 : scanCanonicalize (H12AffineFastState.compose env47879 (packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound47879 : packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env47880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,13461,10280,1024,32769,45340,33,41413,138,8328,64,43396,46276,4097,10480,42112,33,256,168,46213,649]

theorem envBound47880 : H12AffineFastState.Bounded env47880 := by
  intro p hp
  have h : env47880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47879_47880 : H12AffineEnvironment.transform 16 13461 env47879 = env47880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env47879 == env47880) = true)

theorem identity47880 : scanCanonicalize (H12AffineFastState.compose env47880 (packedSelected [0,1,2,6,7,8,10,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47880 : packedSelected [0,1,2,6,7,8,10,15,16] rootPS < 2^1333 := by decide +kernel

def env47881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,32768,33247,5528,2341,1024,32769,36881,33,32968,138,389,64,34953,38345,4097,2557,34189,33,256,168,38280,649]

theorem envBound47881 : H12AffineFastState.Bounded env47881 := by
  intro p hp
  have h : env47881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47880_47881 : H12AffineEnvironment.transform 12 269 env47880 = env47881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47880 == env47881) = true)

theorem identity47881 : scanCanonicalize (H12AffineFastState.compose env47881 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound47881 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,217,262,5528,2341,1024,216,4296,33,17,138,389,64,2128,5392,4097,2557,1364,33,256,168,5457,649]

theorem envBound47882 : H12AffineFastState.Bounded env47882 := by
  intro p hp
  have h : env47882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47881_47882 : H12AffineEnvironment.transform 14 217 env47881 = env47882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env47881 == env47882) = true)

theorem identity47882 : scanCanonicalize (H12AffineFastState.compose env47882 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47882 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env47883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,262,5392,2341,1024,80,4160,33,17,2,269,64,2128,5392,4097,2421,1364,33,256,32,5457,513]

theorem envBound47883 : H12AffineFastState.Bounded env47883 := by
  intro p hp
  have h : env47883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47882_47883 : H12AffineEnvironment.transform 6 8 env47882 = env47883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47882 == env47883) = true)

theorem identity47883 : scanCanonicalize (H12AffineFastState.compose env47883 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound47883 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,815,4096,269,5376,81,262,5392,522,1024,80,4160,33,17,2,269,64,895,5392,4097,602,1364,33,256,32,5457,513]

theorem envBound47884 : H12AffineFastState.Bounded env47884 := by
  intro p hp
  have h : env47884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47883_47884 : H12AffineEnvironment.transform 10 815 env47883 = env47884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env47883 == env47884) = true)

theorem identity47884 : scanCanonicalize (H12AffineFastState.compose env47884 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47884 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47885 : List Nat := [2,4,8,16,32,64,8,36,512,1024,523,4096,41,5156,81,34,5172,522,1024,80,4160,33,17,2,41,64,603,5172,4097,602,1136,33,36,32,5237,513]

theorem envBound47885 : H12AffineFastState.Bounded env47885 := by
  intro p hp
  have h : env47885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47884_47885 : H12AffineEnvironment.transform 7 36 env47884 = env47885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47884 == env47885) = true)

theorem identity47885 : scanCanonicalize (H12AffineFastState.compose env47885 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47885 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47886 : List Nat := [2,4,8,16,32,17,8,36,512,1024,523,4096,41,5156,0,34,5172,522,1024,1,4113,33,17,2,41,17,522,5172,4097,523,1057,33,36,32,5156,513]

theorem envBound47886 : H12AffineFastState.Bounded env47886 := by
  intro p hp
  have h : env47886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47885_47886 : H12AffineEnvironment.transform 5 17 env47885 = env47886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47885 == env47886) = true)

theorem identity47886 : scanCanonicalize (H12AffineFastState.compose env47886 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47887 : List Nat := [2,4,8,16,32,17,8,36,512,52,523,4096,41,4112,0,34,4096,522,52,1,4113,33,17,2,41,17,522,4096,4097,523,21,33,36,32,4112,513]

theorem envBound47887 : H12AffineFastState.Bounded env47887 := by
  intro p hp
  have h : env47887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47886_47887 : H12AffineEnvironment.transform 9 52 env47886 = env47887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47886 == env47887) = true)

theorem identity47887 : scanCanonicalize (H12AffineFastState.compose env47887 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 542) := by decide +kernel

theorem selectedBound47887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47888 : List Nat := [2,4,8,16,32,17,8,36,512,52,523,542,41,526,0,34,542,522,52,1,527,33,17,2,41,17,522,542,543,523,21,33,36,32,526,513]

theorem envBound47888 : H12AffineFastState.Bounded env47888 := by
  intro p hp
  have h : env47888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47887_47888 : H12AffineEnvironment.transform 11 542 env47887 = env47888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 542 env47887 == env47888) = true)

theorem identity47888 : scanCanonicalize (H12AffineFastState.compose env47888 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound47888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47889 : List Nat := [2,4,8,16,32,17,8,36,7,52,12,25,41,9,0,34,25,13,52,1,8,33,17,2,41,17,13,25,24,12,21,33,36,32,9,6]

theorem envBound47889 : H12AffineFastState.Bounded env47889 := by
  intro p hp
  have h : env47889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47888_47889 : H12AffineEnvironment.transform 8 7 env47888 = env47889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env47888 == env47889) = true)

theorem identity47889 : scanCanonicalize (H12AffineFastState.compose env47889 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound47889 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47890 : List Nat := [2,4,8,16,5,17,8,1,7,17,12,25,12,9,0,7,25,13,17,1,8,4,17,2,12,17,13,25,24,12,21,4,1,5,9,6]

theorem envBound47890 : H12AffineFastState.Bounded env47890 := by
  intro p hp
  have h : env47890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47889_47890 : H12AffineEnvironment.transform 4 5 env47889 = env47890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env47889 == env47890) = true)

def env47891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,10281,1024,32769,45340,33,41412,138,8328,64,171281,46276,4096,138341,42113,33,256,169,46212,648]

theorem envBound47891 : H12AffineFastState.Bounded env47891 := by
  intro p hp
  have h : env47891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47878_47891 : H12AffineEnvironment.transform 17 10281 env47878 = env47891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47878 == env47891) = true)

theorem identity47891 : scanCanonicalize (H12AffineFastState.compose env47891 (packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound47891 : packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env47892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2049,32768,33247,131072,10281,1024,32769,44181,33,41412,138,8328,64,163992,43341,3465,131564,42113,33,256,169,43277,648]

theorem envBound47892 : H12AffineFastState.Bounded env47892 := by
  intro p hp
  have h : env47892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47891_47892 : H12AffineEnvironment.transform 11 3465 env47891 = env47892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env47891 == env47892) = true)

theorem identity47892 : scanCanonicalize (H12AffineFastState.compose env47892 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound47892 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2049,8660,8203,131072,10281,1024,8661,3393,33,16,138,8328,64,139596,2201,3465,131564,1365,33,256,169,2265,648]

theorem envBound47893 : H12AffineFastState.Bounded env47893 := by
  intro p hp
  have h : env47893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47892_47893 : H12AffineEnvironment.transform 14 8660 env47892 = env47893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env47892 == env47893) = true)

theorem identity47893 : scanCanonicalize (H12AffineFastState.compose env47893 (packedSelected [1,2,4,8,9,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound47893 : packedSelected [1,2,4,8,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env47894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,1221,2049,1297,1230,131072,3308,1024,1296,3393,33,16,138,1101,64,132489,2201,3465,131564,1365,33,256,169,2265,648]

theorem envBound47894 : H12AffineFastState.Bounded env47894 := by
  intro p hp
  have h : env47894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47893_47894 : H12AffineEnvironment.transform 12 1221 env47893 = env47894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env47893 == env47894) = true)

theorem identity47894 : scanCanonicalize (H12AffineFastState.compose env47894 (packedSelected [0,1,2,6,7,8,10,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47894 : packedSelected [0,1,2,6,7,8,10,15,16] rootPS < 2^1333 := by decide +kernel

def env47895 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2200,468,2049,0,479,131072,2557,273,1,2128,33,16,138,348,64,131224,2201,2200,131564,68,33,256,169,2265,648]

theorem envBound47895 : H12AffineFastState.Bounded env47895 := by
  intro p hp
  have h : env47895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47894_47895 : H12AffineEnvironment.transform 9 273 env47894 = env47895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47894 == env47895) = true)

theorem identity47895 : scanCanonicalize (H12AffineFastState.compose env47895 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound47895 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47896 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,2200,120,2049,0,115,131072,2129,189,1,2128,33,16,138,240,64,131224,2201,2200,131136,68,33,172,169,2265,648]

theorem envBound47896 : H12AffineFastState.Bounded env47896 := by
  intro p hp
  have h : env47896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47895_47896 : H12AffineEnvironment.transform 7 172 env47895 = env47896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env47895 == env47896) = true)

theorem identity47896 : scanCanonicalize (H12AffineFastState.compose env47896 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 2201) := by decide +kernel

theorem selectedBound47896 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env47897 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,2200,120,2049,0,115,2201,2129,189,1,2128,33,16,138,240,64,2049,2201,2200,2265,68,33,172,169,2265,648]

theorem envBound47897 : H12AffineFastState.Bounded env47897 := by
  intro p hp
  have h : env47897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47896_47897 : H12AffineEnvironment.transform 16 2201 env47896 = env47897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2201 env47896 == env47897) = true)

theorem identity47897 : scanCanonicalize (H12AffineFastState.compose env47897 (packedSelected [5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47897 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env47898 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,2065,120,2049,0,115,2064,2129,52,1,2128,33,16,3,121,64,2049,2064,2065,2128,68,33,37,32,2128,513]

theorem envBound47898 : H12AffineFastState.Bounded env47898 := by
  intro p hp
  have h : env47898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47897_47898 : H12AffineEnvironment.transform 6 9 env47897 = env47898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47897 == env47898) = true)

theorem identity47898 : scanCanonicalize (H12AffineFastState.compose env47898 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47899 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,2049,0,34,2064,2048,52,1,2049,33,16,3,40,17,2049,2064,2065,2049,21,33,37,32,2049,513]

theorem envBound47899 : H12AffineFastState.Bounded env47899 := by
  intro p hp
  have h : env47899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47898_47899 : H12AffineEnvironment.transform 5 17 env47898 = env47899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47898 == env47899) = true)

def env47900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981469,79131,8466459,8820105,8389956,4293086,256,8462515,8492191,8462994]

theorem envBound47900 : H12AffineFastState.Bounded env47900 := by
  intro p hp
  have h : env47900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47841_47900 : H12AffineEnvironment.transform 13 5513 env47841 = env47900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47841 == env47900) = true)

def env47901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787197,79131,8466459,8820105,8389956,98814,256,8462515,8492191,8462994]

theorem envBound47901 : H12AffineFastState.Bounded env47901 := by
  intro p hp
  have h : env47901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47900_47901 : H12AffineEnvironment.transform 21 32 env47900 = env47901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47900 == env47901) = true)

theorem identity47901 : scanCanonicalize (H12AffineFastState.compose env47901 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound47901 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,73755,98644,8328,64,472294,79131,4096,505234,75103,98814,256,168,46212,649]

theorem envBound47902 : H12AffineFastState.Bounded env47902 := by
  intro p hp
  have h : env47902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47901_47902 : H12AffineEnvironment.transform 22 73755 env47901 = env47902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env47901 == env47902) = true)

theorem identity47902 : scanCanonicalize (H12AffineFastState.compose env47902 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47902 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env47903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98644,8192,64,472174,79131,4096,505114,75103,98678,256,32,46092,513]

theorem envBound47903 : H12AffineFastState.Bounded env47903 := by
  intro p hp
  have h : env47903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47902_47903 : H12AffineEnvironment.transform 6 8 env47902 = env47903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47902 == env47903) = true)

theorem identity47903 : scanCanonicalize (H12AffineFastState.compose env47903 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47903 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env47904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,32,73755,73737,8192,64,472174,79131,4096,463943,75103,73771,256,32,5457,513]

theorem envBound47904 : H12AffineFastState.Bounded env47904 := by
  intro p hp
  have h : env47904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47903_47904 : H12AffineEnvironment.transform 14 8541 env47903 = env47904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47903 == env47904) = true)

theorem identity47904 : scanCanonicalize (H12AffineFastState.compose env47904 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47904 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4161,32,16,2,8192,64,398437,5392,4096,406604,1364,32,256,32,5457,513]

theorem envBound47905 : H12AffineFastState.Bounded env47905 := by
  intro p hp
  have h : env47905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47904_47905 : H12AffineEnvironment.transform 15 8203 env47904 = env47905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47904 == env47905) = true)

theorem identity47905 : scanCanonicalize (H12AffineFastState.compose env47905 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound47905 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10360,1024,8540,4161,32,16,2,8192,64,146461,5392,4096,138292,1364,32,256,32,5457,513]

theorem envBound47906 : H12AffineFastState.Bounded env47906 := by
  intro p hp
  have h : env47906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47905_47906 : H12AffineEnvironment.transform 17 10360 env47905 = env47906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env47905 == env47906) = true)

def env47907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787196,79131,8466459,8820105,8389956,98815,256,8462515,8492191,8462994]

theorem envBound47907 : H12AffineFastState.Bounded env47907 := by
  intro p hp
  have h : env47907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47900_47907 : H12AffineEnvironment.transform 21 33 env47900 = env47907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47900 == env47907) = true)

theorem identity47907 : scanCanonicalize (H12AffineFastState.compose env47907 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47907 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,131072,262144,1024,32769,4297,33,8388608,41311,8328,64,8787196,5392,8392720,8820105,8389956,41460,256,8388792,8434836,8389273]

theorem envBound47908 : H12AffineFastState.Bounded env47908 := by
  intro p hp
  have h : env47908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47907_47908 : H12AffineEnvironment.transform 15 8203 env47907 = env47908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47907 == env47908) = true)

def env47909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,33,8388608,41311,8192,64,8787060,5392,8392720,8819969,8389956,41340,256,8388656,8434716,8389137]

theorem envBound47909 : H12AffineFastState.Bounded env47909 := by
  intro p hp
  have h : env47909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47908_47909 : H12AffineEnvironment.transform 6 8 env47908 = env47909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47908 == env47909) = true)

theorem identity47909 : scanCanonicalize (H12AffineFastState.compose env47909 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297269) := by decide +kernel

theorem selectedBound47909 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,33,297269,41311,8192,64,171329,5392,301349,138292,298097,41340,256,297221,277801,297764]

theorem envBound47910 : H12AffineFastState.Bounded env47910 := by
  intro p hp
  have h : env47910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47909_47910 : H12AffineEnvironment.transform 22 297269 env47909 = env47910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297269 env47909 == env47910) = true)

theorem identity47910 : scanCanonicalize (H12AffineFastState.compose env47910 (packedSelected [0,1,5,7,9,10,12,14,15,16,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound47910 : packedSelected [0,1,5,7,9,10,12,14,15,16,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10360,1024,32769,4161,33,41293,41311,8192,64,171329,5392,45405,138292,41993,41340,256,41341,5457,41820]

theorem envBound47911 : H12AffineFastState.Bounded env47911 := by
  intro p hp
  have h : env47911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47910_47911 : H12AffineEnvironment.transform 17 10360 env47910 = env47911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env47910 == env47911) = true)

theorem identity47911 : scanCanonicalize (H12AffineFastState.compose env47911 (packedSelected [0,5,7,9,12,14,15,16,18,19,21,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound47911 : packedSelected [0,5,7,9,12,14,15,16,18,19,21,22,23,24] rootPS < 2^1333 := by decide +kernel

def env47912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8461,8203,131072,10360,1024,8460,4161,33,64,82,8192,64,146508,5392,4176,138292,1284,113,256,112,5457,593]

theorem envBound47912 : H12AffineFastState.Bounded env47912 := by
  intro p hp
  have h : env47912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47911_47912 : H12AffineEnvironment.transform 14 8461 env47911 = env47912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env47911 == env47912) = true)

theorem identity47912 : scanCanonicalize (H12AffineFastState.compose env47912 (packedSelected [1,2,4,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47912 : packedSelected [1,2,4,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env47913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,81,343,131072,2340,1024,80,4161,33,64,82,348,64,138512,5392,4176,138292,1284,113,256,112,5457,593]

theorem envBound47913 : H12AffineFastState.Bounded env47913 := by
  intro p hp
  have h : env47913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47912_47913 : H12AffineEnvironment.transform 12 348 env47912 = env47913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47912 == env47913) = true)

theorem identity47913 : scanCanonicalize (H12AffineFastState.compose env47913 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound47913 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env47914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,81,343,5440,2340,1024,80,4161,33,64,82,348,64,2128,5392,4176,2420,1284,113,256,112,5457,593]

theorem envBound47914 : H12AffineFastState.Bounded env47914 := by
  intro p hp
  have h : env47914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47913_47914 : H12AffineEnvironment.transform 16 5440 env47913 = env47914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env47913 == env47914) = true)

theorem identity47914 : scanCanonicalize (H12AffineFastState.compose env47914 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47914 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env47915 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5392,2340,1024,0,4113,33,16,2,268,16,2048,5392,4096,2340,1284,33,256,32,5377,513]

theorem envBound47915 : H12AffineFastState.Bounded env47915 := by
  intro p hp
  have h : env47915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47914_47915 : H12AffineEnvironment.transform 5 16 env47914 = env47915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47914 == env47915) = true)

theorem identity47915 : scanCanonicalize (H12AffineFastState.compose env47915 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47916 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5172,2048,1024,0,4113,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound47916 : H12AffineFastState.Bounded env47916 := by
  intro p hp
  have h : env47916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47915_47916 : H12AffineEnvironment.transform 7 36 env47915 = env47916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47915 == env47916) = true)

def env47917 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,1,35,1028,2048,1024,0,33,33,16,2,40,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound47917 : H12AffineFastState.Bounded env47917 := by
  intro p hp
  have h : env47917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47916_47917 : H12AffineEnvironment.transform 11 48 env47916 = env47917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47916 == env47917) = true)

theorem identity47917 : scanCanonicalize (H12AffineFastState.compose env47917 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47918 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,48,40,1045,1,35,1028,1076,1024,0,33,33,16,2,40,16,1076,1028,48,1076,1056,33,36,32,1045,513]

theorem envBound47918 : H12AffineFastState.Bounded env47918 := by
  intro p hp
  have h : env47918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47917_47918 : H12AffineEnvironment.transform 10 1076 env47917 = env47918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env47917 == env47918) = true)

def env47919 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,40,33,1,35,48,0,52,0,33,33,16,2,40,16,0,48,48,0,20,33,36,32,33,513]

theorem envBound47919 : H12AffineFastState.Bounded env47919 := by
  intro p hp
  have h : env47919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47918_47919 : H12AffineEnvironment.transform 9 52 env47918 = env47919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47918 == env47919) = true)

def env47920 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,48,40,32,1,35,49,1,53,0,33,33,16,2,40,16,1,49,48,1,21,33,36,32,32,513]

theorem envBound47920 : H12AffineFastState.Bounded env47920 := by
  intro p hp
  have h : env47920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47918_47920 : H12AffineEnvironment.transform 9 53 env47918 = env47920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47918 == env47920) = true)

theorem identity47920 : scanCanonicalize (H12AffineFastState.compose env47920 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47921 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,48,40,32,1,35,49,1,53,0,33,33,16,2,40,16,1,49,48,1,21,33,36,32,32,42]

theorem envBound47921 : H12AffineFastState.Bounded env47921 := by
  intro p hp
  have h : env47921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47920_47921 : H12AffineEnvironment.transform 8 43 env47920 = env47921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47920 == env47921) = true)

def leafEnv47921 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,48,40,32,1,35,49,1,53,0,33,33,16,2,21,40,1,16,1,49,48,1,21,33,36,32,4,35,32,42,1,33,0]

def active47921 : List Nat := [0,1,2,3,4]

def tree47921 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47921 : H12WitnessSearch.Good tree47921 := H12GlobalWitnessIndex.good

theorem leafIdentity47921 : H12AffineFastState.composeSystem env47921 rootObs = leafEnv47921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47921 rootObs == leafEnv47921) = true)

theorem terminalChecked47921 : H12PackedTerminal.terminalCheckFast leafEnv47921 active47921 tree47921 = true := by decide +kernel

def env47922 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,1,35,1029,2048,1024,0,32,33,16,2,40,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound47922 : H12AffineFastState.Bounded env47922 := by
  intro p hp
  have h : env47922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47916_47922 : H12AffineEnvironment.transform 11 49 env47916 = env47922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47916 == env47922) = true)

theorem identity47922 : scanCanonicalize (H12AffineFastState.compose env47922 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47923 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,49,40,1044,1,35,1029,1,1024,0,32,33,16,2,40,16,1,1029,49,1,1056,33,36,32,1044,513]

theorem envBound47923 : H12AffineFastState.Bounded env47923 := by
  intro p hp
  have h : env47923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47922_47923 : H12AffineEnvironment.transform 10 1 env47922 = env47923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47922 == env47923) = true)

def env47924 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,49,40,32,1,35,49,1,52,0,32,33,16,2,40,16,1,49,49,1,20,33,36,32,32,513]

theorem envBound47924 : H12AffineFastState.Bounded env47924 := by
  intro p hp
  have h : env47924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47923_47924 : H12AffineEnvironment.transform 9 52 env47923 = env47924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47923 == env47924) = true)

def env47925 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,40,33,1,35,48,1,53,0,32,33,16,2,40,16,1,48,49,1,21,33,36,32,33,513]

theorem envBound47925 : H12AffineFastState.Bounded env47925 := by
  intro p hp
  have h : env47925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47923_47925 : H12AffineEnvironment.transform 9 53 env47923 = env47925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47923 == env47925) = true)

theorem identity47925 : scanCanonicalize (H12AffineFastState.compose env47925 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47926 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,49,40,33,1,35,48,1,53,0,32,33,16,2,40,16,1,48,49,1,21,33,36,32,33,42]

theorem envBound47926 : H12AffineFastState.Bounded env47926 := by
  intro p hp
  have h : env47926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47925_47926 : H12AffineEnvironment.transform 8 43 env47925 = env47926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47925 == env47926) = true)

def leafEnv47926 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,49,40,33,1,35,48,1,53,0,32,33,16,2,21,40,1,16,1,48,49,1,21,33,36,32,4,35,33,42,1,32,0]

def active47926 : List Nat := [0,1,2,3,4]

def tree47926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47926 : H12WitnessSearch.Good tree47926 := H12GlobalWitnessIndex.good

theorem leafIdentity47926 : H12AffineFastState.composeSystem env47926 rootObs = leafEnv47926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47926 rootObs == leafEnv47926) = true)

theorem terminalChecked47926 : H12PackedTerminal.terminalCheckFast leafEnv47926 active47926 tree47926 = true := by decide +kernel

def env47927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,8388608,41311,8193,64,8787061,5392,8392720,8819968,8389956,41341,256,8388657,8434717,8389136]

theorem envBound47927 : H12AffineFastState.Bounded env47927 := by
  intro p hp
  have h : env47927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47908_47927 : H12AffineEnvironment.transform 6 9 env47908 = env47927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47908 == env47927) = true)

theorem identity47927 : scanCanonicalize (H12AffineFastState.compose env47927 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound47927 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,262144,1024,32769,4160,33,8388608,41311,8193,64,8651061,5392,8392720,8683584,8389956,41341,256,8388657,8434717,8389136]

theorem envBound47928 : H12AffineFastState.Bounded env47928 := by
  intro p hp
  have h : env47928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47927_47928 : H12AffineEnvironment.transform 16 5440 env47927 = env47928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env47927 == env47928) = true)

theorem identity47928 : scanCanonicalize (H12AffineFastState.compose env47928 (packedSelected [0,9,18,19,22,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound47928 : packedSelected [0,9,18,19,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,2340,1024,32769,4160,33,8388608,41311,8193,64,8390673,5392,8392720,8423780,8389956,41341,256,8388657,8434717,8389136]

theorem envBound47929 : H12AffineFastState.Bounded env47929 := by
  intro p hp
  have h : env47929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47928_47929 : H12AffineEnvironment.transform 17 2340 env47928 = env47929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env47928 == env47929) = true)

theorem identity47929 : scanCanonicalize (H12AffineFastState.compose env47929 (packedSelected [0,1,7,8,9,12,14,15,19,20,21,22] rootPS)) = affineNative (2^(22+1) ^^^ 33125) := by decide +kernel

theorem selectedBound47929 : packedSelected [0,1,7,8,9,12,14,15,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env47930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,2340,1024,32769,4160,33,33125,41311,8193,64,35188,5392,37237,2049,33825,41341,256,33108,13688,33653]

theorem envBound47930 : H12AffineFastState.Bounded env47930 := by
  intro p hp
  have h : env47930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47929_47930 : H12AffineEnvironment.transform 22 33125 env47929 = env47930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 33125 env47929 == env47930) = true)

theorem identity47930 : scanCanonicalize (H12AffineFastState.compose env47930 (packedSelected [0,2,6,7,11,16,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47930 : packedSelected [0,2,6,7,11,16,23] rootPS < 2^1333 := by decide +kernel

def env47931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,262,5440,2340,1024,32769,4160,33,33125,32850,268,64,35188,5392,37237,2049,33825,32880,256,33108,5237,33653]

theorem envBound47931 : H12AffineFastState.Bounded env47931 := by
  intro p hp
  have h : env47931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47930_47931 : H12AffineEnvironment.transform 12 269 env47930 = env47931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47930 == env47931) = true)

theorem identity47931 : scanCanonicalize (H12AffineFastState.compose env47931 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound47931 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,293,262,5440,2340,1024,292,4160,33,64,375,268,64,2129,5392,4176,2049,1284,341,256,113,5237,592]

theorem envBound47932 : H12AffineFastState.Bounded env47932 := by
  intro p hp
  have h : env47932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47931_47932 : H12AffineEnvironment.transform 14 293 env47931 = env47932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env47931 == env47932) = true)

theorem identity47932 : scanCanonicalize (H12AffineFastState.compose env47932 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound47932 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47933 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,269,4160,293,262,4096,2340,320,292,4160,33,64,375,268,64,2129,4176,4176,2049,68,341,256,113,4405,592]

theorem envBound47933 : H12AffineFastState.Bounded env47933 := by
  intro p hp
  have h : env47933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47932_47933 : H12AffineEnvironment.transform 9 320 env47932 = env47933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47932 == env47933) = true)

theorem identity47933 : scanCanonicalize (H12AffineFastState.compose env47933 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound47933 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env47934 : List Nat := [2,4,8,16,32,64,9,256,512,320,372,4096,269,4160,293,262,4096,80,320,292,4160,33,64,375,268,64,293,4176,4176,373,68,341,256,113,4405,592]

theorem envBound47934 : H12AffineFastState.Bounded env47934 := by
  intro p hp
  have h : env47934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47933_47934 : H12AffineEnvironment.transform 10 372 env47933 = env47934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env47933 == env47934) = true)

theorem identity47934 : scanCanonicalize (H12AffineFastState.compose env47934 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47934 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47935 : List Nat := [2,4,8,16,32,16,9,256,512,272,292,4096,269,4112,293,262,4096,0,272,292,4112,33,16,295,268,16,293,4096,4096,293,20,261,256,33,4405,512]

theorem envBound47935 : H12AffineFastState.Bounded env47935 := by
  intro p hp
  have h : env47935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47934_47935 : H12AffineEnvironment.transform 5 16 env47934 = env47935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47934 == env47935) = true)

theorem identity47935 : scanCanonicalize (H12AffineFastState.compose env47935 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47936 : List Nat := [2,4,8,16,32,16,9,4,512,20,32,4096,9,4112,33,2,4096,0,20,32,4112,33,16,35,8,16,33,4096,4096,33,20,1,4,33,4145,512]

theorem envBound47936 : H12AffineFastState.Bounded env47936 := by
  intro p hp
  have h : env47936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47935_47936 : H12AffineEnvironment.transform 7 4 env47935 = env47936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47935 == env47936) = true)

theorem identity47936 : scanCanonicalize (H12AffineFastState.compose env47936 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound47936 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env47937 : List Nat := [2,4,8,16,32,16,9,4,21,20,32,4096,9,4112,33,2,4096,0,20,32,4112,33,16,35,8,16,33,4096,4096,33,20,1,4,33,4145,21]

theorem envBound47937 : H12AffineFastState.Bounded env47937 := by
  intro p hp
  have h : env47937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47936_47937 : H12AffineEnvironment.transform 8 21 env47936 = env47937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env47936 == env47937) = true)

theorem identity47937 : scanCanonicalize (H12AffineFastState.compose env47937 (packedSelected [1,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound47937 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env47938 : List Nat := [2,4,8,16,32,16,9,4,21,20,32,48,9,32,33,2,48,0,20,32,32,33,16,35,8,16,33,48,48,33,20,1,4,33,1,21]

theorem envBound47938 : H12AffineFastState.Bounded env47938 := by
  intro p hp
  have h : env47938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47937_47938 : H12AffineEnvironment.transform 11 48 env47937 = env47938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47937 == env47938) = true)

theorem identity47938 : scanCanonicalize (H12AffineFastState.compose env47938 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47938 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47939 : List Nat := [2,4,8,16,0,16,9,4,21,20,0,16,9,0,1,2,16,0,20,0,0,1,16,3,8,16,1,16,16,1,20,1,4,1,1,21]

theorem envBound47939 : H12AffineFastState.Bounded env47939 := by
  intro p hp
  have h : env47939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47938_47939 : H12AffineEnvironment.transform 4 0 env47938 = env47939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47938 == env47939) = true)

def env47940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound47940 : H12AffineFastState.Bounded env47940 := by
  intro p hp
  have h : env47940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47758_47940 : H12AffineEnvironment.transform 18 1025 env47758 = env47940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env47758 == env47940) = true)

theorem identity47940 : scanCanonicalize (H12AffineFastState.compose env47940 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10651082) := by decide +kernel

theorem selectedBound47940 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10651082,8328,64,6637003,8585542,10507600,8830977,2294234,12836875,257,213351,237763,2237965]

theorem envBound47941 : H12AffineFastState.Bounded env47941 := by
  intro p hp
  have h : env47941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47940_47941 : H12AffineEnvironment.transform 23 10651082 env47940 = env47941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10651082 env47940 == env47941) = true)

def env47942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180360,2114882,8328,64,6637003,115150,2266584,262281,2294234,4268163,257,213351,237763,2237965]

theorem envBound47942 : H12AffineFastState.Bounded env47942 := by
  intro p hp
  have h : env47942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47941_47942 : H12AffineEnvironment.transform 22 180360 env47941 = env47942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env47941 == env47942) = true)

def env47943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,169370,8328,64,4691219,115150,17664,262281,119042,4268163,257,213351,237763,63189]

theorem envBound47943 : H12AffineFastState.Bounded env47943 := by
  intro p hp
  have h : env47943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47942_47943 : H12AffineEnvironment.transform 20 184536 env47942 = env47943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env47942 == env47943) = true)

def env47944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,169370,8328,64,245139,115150,17664,262281,119042,329731,257,213351,237763,63189]

theorem envBound47944 : H12AffineFastState.Bounded env47944 := by
  intro p hp
  have h : env47944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47943_47944 : H12AffineEnvironment.transform 21 272512 env47943 = env47944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47943 == env47944) = true)

theorem identity47944 : scanCanonicalize (H12AffineFastState.compose env47944 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound47944 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,77898,272512,73754,95496,8328,64,23809,115150,17664,262281,119042,329731,257,41461,16465,63189]

theorem envBound47945 : H12AffineFastState.Bounded env47945 := by
  intro p hp
  have h : env47945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47944_47945 : H12AffineEnvironment.transform 16 123026 env47944 = env47945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env47944 == env47945) = true)

def env47946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,77898,32,73754,95496,8328,64,23809,115150,17664,10281,119042,73891,257,41461,16465,63189]

theorem envBound47946 : H12AffineFastState.Bounded env47946 := by
  intro p hp
  have h : env47946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47945_47946 : H12AffineEnvironment.transform 17 10400 env47945 = env47946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47945 == env47946) = true)

theorem identity47946 : scanCanonicalize (H12AffineFastState.compose env47946 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound47946 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env47947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,16401,10400,1025,32769,37065,32,32921,54667,8328,64,23809,24909,17664,10281,29057,32800,257,41461,16465,63189]

theorem envBound47947 : H12AffineFastState.Bounded env47947 := by
  intro p hp
  have h : env47947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47946_47947 : H12AffineEnvironment.transform 15 41091 env47946 = env47947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env47946 == env47947) = true)

theorem identity47947 : scanCanonicalize (H12AffineFastState.compose env47947 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound47947 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env47948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,41091,13389,10400,1025,32769,37065,32,32921,41431,8328,64,10589,5393,12636,10281,1501,32800,257,41461,13325,33417]

theorem envBound47948 : H12AffineFastState.Bounded env47948 := by
  intro p hp
  have h : env47948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47947_47948 : H12AffineEnvironment.transform 13 13404 env47947 = env47948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env47947 == env47948) = true)

theorem identity47948 : scanCanonicalize (H12AffineFastState.compose env47948 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound47948 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env47949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8660,343,13389,10400,1025,8661,12573,32,8525,3,8328,64,10589,5393,12636,10281,1501,8692,257,33,13325,9053]

theorem envBound47949 : H12AffineFastState.Bounded env47949 := by
  intro p hp
  have h : env47949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47948_47949 : H12AffineEnvironment.transform 14 8660 env47948 = env47949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env47948 == env47949) = true)

theorem identity47949 : scanCanonicalize (H12AffineFastState.compose env47949 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47949 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,343,5392,2557,1025,136,4160,32,16,3,469,64,2048,5393,4097,2420,1501,169,257,33,5456,512]

theorem envBound47950 : H12AffineFastState.Bounded env47950 := by
  intro p hp
  have h : env47950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47949_47950 : H12AffineEnvironment.transform 12 349 env47949 = env47950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47949 == env47950) = true)

theorem identity47950 : scanCanonicalize (H12AffineFastState.compose env47950 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound47950 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47951 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,349,5377,32,343,5392,2388,1025,33,4160,32,16,3,380,64,2048,5393,4097,2420,1396,0,257,33,5456,512]

theorem envBound47951 : H12AffineFastState.Bounded env47951 := by
  intro p hp
  have h : env47951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47950_47951 : H12AffineEnvironment.transform 6 41 env47950 = env47951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env47950 == env47951) = true)

theorem identity47951 : scanCanonicalize (H12AffineFastState.compose env47951 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47951 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47952 : List Nat := [2,4,8,16,32,64,41,37,512,1024,2048,4096,120,5156,32,114,5173,2161,1025,33,4160,32,16,3,89,64,2048,5172,4097,2129,1105,0,36,33,5237,512]

theorem envBound47952 : H12AffineFastState.Bounded env47952 := by
  intro p hp
  have h : env47952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47951_47952 : H12AffineEnvironment.transform 7 37 env47951 = env47952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47951 == env47952) = true)

theorem identity47952 : scanCanonicalize (H12AffineFastState.compose env47952 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47952 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47953 : List Nat := [2,4,8,16,32,64,41,37,512,101,2048,4096,120,4161,32,114,4176,2161,100,33,4160,32,16,3,89,64,2048,4177,4097,2129,52,0,36,33,4112,512]

theorem envBound47953 : H12AffineFastState.Bounded env47953 := by
  intro p hp
  have h : env47953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47952_47953 : H12AffineEnvironment.transform 9 101 env47952 = env47953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47952 == env47953) = true)

theorem identity47953 : scanCanonicalize (H12AffineFastState.compose env47953 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound47953 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env47954 : List Nat := [2,4,8,16,32,64,41,37,512,101,2048,2144,120,2081,32,114,2096,2161,100,33,2080,32,16,3,89,64,2048,2097,2145,2129,52,0,36,33,2160,512]

theorem envBound47954 : H12AffineFastState.Bounded env47954 := by
  intro p hp
  have h : env47954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47953_47954 : H12AffineEnvironment.transform 11 2144 env47953 = env47954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env47953 == env47954) = true)

theorem identity47954 : scanCanonicalize (H12AffineFastState.compose env47954 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound47954 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47955 : List Nat := [2,4,8,16,32,48,41,37,512,21,2048,2064,8,2081,32,2,2096,2049,20,33,2080,32,16,3,41,48,2048,2097,2065,2081,52,0,36,33,2048,512]

theorem envBound47955 : H12AffineFastState.Bounded env47955 := by
  intro p hp
  have h : env47955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47954_47955 : H12AffineEnvironment.transform 5 48 env47954 = env47955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env47954 == env47955) = true)

theorem identity47955 : scanCanonicalize (H12AffineFastState.compose env47955 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47956 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,2064,8,2049,0,2,2064,2049,20,1,2048,0,16,3,9,16,2048,2065,2065,2049,20,0,4,1,2048,512]

theorem envBound47956 : H12AffineFastState.Bounded env47956 := by
  intro p hp
  have h : env47956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47955_47956 : H12AffineEnvironment.transform 4 0 env47955 = env47956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47955 == env47956) = true)

theorem identity47956 : scanCanonicalize (H12AffineFastState.compose env47956 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound47956 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47957 : List Nat := [2,4,8,16,0,16,9,5,14,21,2048,2064,8,2049,0,2,2064,2049,20,1,2048,0,16,3,9,16,2048,2065,2065,2049,20,0,4,1,2048,14]

theorem envBound47957 : H12AffineFastState.Bounded env47957 := by
  intro p hp
  have h : env47957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47956_47957 : H12AffineEnvironment.transform 8 14 env47956 = env47957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env47956 == env47957) = true)

def env47958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,77898,33,73754,95496,8328,64,23809,115150,17664,10280,119042,73890,257,41461,16465,63189]

theorem envBound47958 : H12AffineFastState.Bounded env47958 := by
  intro p hp
  have h : env47958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47945_47958 : H12AffineEnvironment.transform 17 10401 env47945 = env47958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47945 == env47958) = true)

theorem identity47958 : scanCanonicalize (H12AffineFastState.compose env47958 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound47958 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env47959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57676,10401,1025,32769,12692,33,8644,29910,8328,64,23809,49168,17664,10280,53468,8572,257,41461,16465,63189]

theorem envBound47959 : H12AffineFastState.Bounded env47959 := by
  intro p hp
  have h : env47959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47958_47959 : H12AffineEnvironment.transform 15 478 env47958 = env47959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env47958 == env47959) = true)

theorem identity47959 : scanCanonicalize (H12AffineFastState.compose env47959 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound47959 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,5528,10401,1025,29909,12692,33,8644,29910,8328,64,23809,13508,17664,10280,9224,8572,257,21793,16465,513]

theorem envBound47960 : H12AffineFastState.Bounded env47960 := by
  intro p hp
  have h : env47960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47959_47960 : H12AffineEnvironment.transform 14 29908 env47959 = env47960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env47959 == env47960) = true)

theorem identity47960 : scanCanonicalize (H12AffineFastState.compose env47960 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47960 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,478,5528,2421,1025,21761,4160,33,16,21762,348,64,23809,5392,17664,2556,1500,168,257,21793,16465,513]

theorem envBound47961 : H12AffineFastState.Bounded env47961 := by
  intro p hp
  have h : env47961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47960_47961 : H12AffineEnvironment.transform 12 468 env47960 = env47961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47960 == env47961) = true)

theorem identity47961 : scanCanonicalize (H12AffineFastState.compose env47961 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound47961 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env47962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,478,5528,2421,1025,137,4160,33,16,138,348,64,2185,5392,4232,2556,1500,168,257,169,5593,513]

theorem envBound47962 : H12AffineFastState.Bounded env47962 := by
  intro p hp
  have h : env47962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47961_47962 : H12AffineEnvironment.transform 13 5512 env47961 = env47962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env47961 == env47962) = true)

theorem identity47962 : scanCanonicalize (H12AffineFastState.compose env47962 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound47962 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env47963 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,136,34,5220,2185,1025,137,4160,33,16,138,160,64,2185,5356,4232,2048,1056,168,253,169,5157,513]

theorem envBound47963 : H12AffineFastState.Bounded env47963 := by
  intro p hp
  have h : env47963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47962_47963 : H12AffineEnvironment.transform 7 252 env47962 = env47963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env47962 == env47963) = true)

theorem identity47963 : scanCanonicalize (H12AffineFastState.compose env47963 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound47963 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47964 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,40,5236,80,34,5220,2129,1025,81,4160,33,16,82,120,64,2129,5172,4176,2048,1056,112,37,113,5157,513]

theorem envBound47964 : H12AffineFastState.Bounded env47964 := by
  intro p hp
  have h : env47964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47963_47964 : H12AffineEnvironment.transform 6 88 env47963 = env47964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env47963 == env47964) = true)

theorem identity47964 : scanCanonicalize (H12AffineFastState.compose env47964 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47964 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env47965 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5173,2048,1025,0,4113,33,16,3,41,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound47965 : H12AffineFastState.Bounded env47965 := by
  intro p hp
  have h : env47965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47964_47965 : H12AffineEnvironment.transform 5 17 env47964 = env47965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47964 == env47965) = true)

def env47966 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,1,34,1029,2048,1025,0,33,33,16,3,41,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound47966 : H12AffineFastState.Bounded env47966 := by
  intro p hp
  have h : env47966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47965_47966 : H12AffineEnvironment.transform 11 48 env47965 = env47966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47965 == env47966) = true)

theorem identity47966 : scanCanonicalize (H12AffineFastState.compose env47966 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound47966 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47967 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,48,40,1045,1,34,1029,529,1025,0,33,33,16,3,41,17,529,1028,49,529,1056,33,37,32,1045,513]

theorem envBound47967 : H12AffineFastState.Bounded env47967 := by
  intro p hp
  have h : env47967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47966_47967 : H12AffineEnvironment.transform 10 529 env47966 = env47967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env47966 == env47967) = true)

def env47968 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,40,33,1,34,49,529,53,0,33,33,16,3,41,17,529,48,49,529,20,33,37,32,33,513]

theorem envBound47968 : H12AffineFastState.Bounded env47968 := by
  intro p hp
  have h : env47968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47967_47968 : H12AffineEnvironment.transform 9 52 env47967 = env47968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47967 == env47968) = true)

def env47969 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,32,1,34,48,529,52,0,33,33,16,3,41,17,529,49,49,529,21,33,37,32,32,513]

theorem envBound47969 : H12AffineFastState.Bounded env47969 := by
  intro p hp
  have h : env47969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47967_47969 : H12AffineEnvironment.transform 9 53 env47967 = env47969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47967 == env47969) = true)

theorem identity47969 : scanCanonicalize (H12AffineFastState.compose env47969 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound47969 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47970 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,48,40,32,1,34,48,59,52,0,33,33,16,3,41,17,59,49,49,59,21,33,37,32,32,43]

theorem envBound47970 : H12AffineFastState.Bounded env47970 := by
  intro p hp
  have h : env47970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47969_47970 : H12AffineEnvironment.transform 8 42 env47969 = env47970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env47969 == env47970) = true)

def leafEnv47970 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,48,40,32,1,34,48,59,52,0,33,33,16,3,20,41,1,17,59,49,49,59,21,33,37,32,5,35,32,43,1,33,0]

def active47970 : List Nat := [0,1,2,3,4]

def tree47970 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47970 : H12WitnessSearch.Good tree47970 := H12GlobalWitnessIndex.good

theorem leafIdentity47970 : H12AffineFastState.composeSystem env47970 rootObs = leafEnv47970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47970 rootObs == leafEnv47970) = true)

theorem terminalChecked47970 : H12PackedTerminal.terminalCheckFast leafEnv47970 active47970 tree47970 = true := by decide +kernel

def env47971 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,1,34,1028,2048,1025,0,32,33,16,3,41,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound47971 : H12AffineFastState.Bounded env47971 := by
  intro p hp
  have h : env47971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47965_47971 : H12AffineEnvironment.transform 11 49 env47965 = env47971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47965 == env47971) = true)

theorem identity47971 : scanCanonicalize (H12AffineFastState.compose env47971 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound47971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47972 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,49,40,1044,1,34,1028,1572,1025,0,32,33,16,3,41,17,1572,1029,48,1572,1056,33,37,32,1044,513]

theorem envBound47972 : H12AffineFastState.Bounded env47972 := by
  intro p hp
  have h : env47972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47971_47972 : H12AffineEnvironment.transform 10 1572 env47971 = env47972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env47971 == env47972) = true)

def env47973 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,32,1,34,48,528,53,0,32,33,16,3,41,17,528,49,48,528,20,33,37,32,32,513]

theorem envBound47973 : H12AffineFastState.Bounded env47973 := by
  intro p hp
  have h : env47973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47972_47973 : H12AffineEnvironment.transform 9 52 env47972 = env47973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47972 == env47973) = true)

def env47974 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,40,33,1,34,49,529,52,0,32,33,16,3,41,17,529,48,48,529,21,33,37,32,33,513]

theorem envBound47974 : H12AffineFastState.Bounded env47974 := by
  intro p hp
  have h : env47974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47972_47974 : H12AffineEnvironment.transform 9 53 env47972 = env47974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47972 == env47974) = true)

theorem identity47974 : scanCanonicalize (H12AffineFastState.compose env47974 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47975 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,49,40,33,1,34,49,58,52,0,32,33,16,3,41,17,58,48,48,58,21,33,37,32,33,42]

theorem envBound47975 : H12AffineFastState.Bounded env47975 := by
  intro p hp
  have h : env47975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47974_47975 : H12AffineEnvironment.transform 8 43 env47974 = env47975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47974 == env47975) = true)

def leafEnv47975 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,49,40,33,1,34,49,58,52,0,32,33,16,3,20,41,1,17,58,48,48,58,21,33,37,32,5,35,33,42,1,32,0]

def active47975 : List Nat := [0,1,2,3,4]

def tree47975 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47975 : H12WitnessSearch.Good tree47975 := H12GlobalWitnessIndex.good

theorem leafIdentity47975 : H12AffineFastState.composeSystem env47975 rootObs = leafEnv47975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47975 rootObs == leafEnv47975) = true)

theorem terminalChecked47975 : H12PackedTerminal.terminalCheckFast leafEnv47975 active47975 tree47975 = true := by decide +kernel

def env47976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,169370,8328,64,245138,115150,17664,262281,119042,329730,257,213351,237763,63189]

theorem envBound47976 : H12AffineFastState.Bounded env47976 := by
  intro p hp
  have h : env47976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47943_47976 : H12AffineEnvironment.transform 21 272513 env47943 = env47976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47943 == env47976) = true)

theorem identity47976 : scanCanonicalize (H12AffineFastState.compose env47976 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47976 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184536,272513,180360,169370,8328,64,171417,57797,17664,262281,61705,272393,257,156012,164040,63189]

theorem envBound47977 : H12AffineFastState.Bounded env47977 := by
  intro p hp
  have h : env47977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47976_47977 : H12AffineEnvironment.transform 15 8203 env47976 = env47977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47976 == env47977) = true)

def env47978 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184456,272513,180360,169370,8328,16,171417,57749,17664,262281,61705,272393,257,155964,163992,63109]

theorem envBound47978 : H12AffineFastState.Bounded env47978 := by
  intro p hp
  have h : env47978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47977_47978 : H12AffineEnvironment.transform 5 16 env47977 = env47978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47977 == env47978) = true)

theorem identity47978 : scanCanonicalize (H12AffineFastState.compose env47978 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound47978 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env47979 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8203,131072,262144,1025,29708,140421,272513,144517,156055,8328,16,158100,5528,17664,262281,1284,272393,257,155964,160917,648]

theorem envBound47979 : H12AffineFastState.Bounded env47979 := by
  intro p hp
  have h : env47979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47978_47979 : H12AffineEnvironment.transform 14 29709 env47978 = env47979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env47978 == env47979) = true)

theorem identity47979 : scanCanonicalize (H12AffineFastState.compose env47979 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47979 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env47980 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8203,131072,10280,1025,29708,140421,169,144517,156055,8328,16,158100,5528,17664,10401,1284,33,257,155964,160917,648]

theorem envBound47980 : H12AffineFastState.Bounded env47980 := by
  intro p hp
  have h : env47980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47979_47980 : H12AffineEnvironment.transform 17 10280 env47979 = env47980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47979 == env47980) = true)

theorem identity47980 : scanCanonicalize (H12AffineFastState.compose env47980 (packedSelected [1,8,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound47980 : packedSelected [1,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env47981 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8580,8203,131072,10280,1025,8581,140421,169,144517,144414,8328,16,146461,5528,4233,10401,1284,33,257,144565,139548,648]

theorem envBound47981 : H12AffineFastState.Bounded env47981 := by
  intro p hp
  have h : env47981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47980_47981 : H12AffineEnvironment.transform 13 5513 env47980 = env47981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47980 == env47981) = true)

theorem identity47981 : scanCanonicalize (H12AffineFastState.compose env47981 (packedSelected [0,1,2,3,5,6,7,8,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound47981 : packedSelected [0,1,2,3,5,6,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env47982 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8580,8203,5528,10280,1025,8581,12573,169,8477,8582,8328,16,10629,5528,4233,10401,1284,33,257,8493,13444,648]

theorem envBound47982 : H12AffineFastState.Bounded env47982 := by
  intro p hp
  have h : env47982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47981_47982 : H12AffineEnvironment.transform 16 5528 env47981 = env47982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env47981 == env47982) = true)

theorem identity47982 : scanCanonicalize (H12AffineFastState.compose env47982 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound47982 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47983 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,1,398,5528,2477,1025,0,4248,169,152,3,269,16,2048,5528,4233,2340,1284,33,257,168,5377,648]

theorem envBound47983 : H12AffineFastState.Bounded env47983 := by
  intro p hp
  have h : env47983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47982_47983 : H12AffineEnvironment.transform 12 389 env47982 = env47983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env47982 == env47983) = true)

theorem identity47983 : scanCanonicalize (H12AffineFastState.compose env47983 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound47983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47984 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,309,389,1212,1,398,1197,2477,1025,0,429,169,152,3,269,16,2048,1197,444,2340,1284,33,257,168,1076,648]

theorem envBound47984 : H12AffineFastState.Bounded env47984 := by
  intro p hp
  have h : env47984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47983_47984 : H12AffineEnvironment.transform 11 309 env47983 = env47984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env47983 == env47984) = true)

theorem identity47984 : scanCanonicalize (H12AffineFastState.compose env47984 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound47984 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47985 : List Nat := [2,4,8,16,32,16,128,256,512,188,2048,309,389,0,1,398,17,2477,189,0,429,169,152,3,269,16,2048,17,444,2340,440,33,257,168,136,648]

theorem envBound47985 : H12AffineFastState.Bounded env47985 := by
  intro p hp
  have h : env47985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47984_47985 : H12AffineEnvironment.transform 9 188 env47984 = env47985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env47984 == env47985) = true)

theorem identity47985 : scanCanonicalize (H12AffineFastState.compose env47985 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound47985 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env47986 : List Nat := [2,4,8,16,32,16,128,256,512,188,136,309,389,0,1,398,17,293,189,0,429,169,152,3,269,16,136,17,444,428,440,33,257,168,136,648]

theorem envBound47986 : H12AffineFastState.Bounded env47986 := by
  intro p hp
  have h : env47986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47985_47986 : H12AffineEnvironment.transform 10 136 env47985 = env47986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env47985 == env47986) = true)

theorem identity47986 : scanCanonicalize (H12AffineFastState.compose env47986 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47986 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47987 : List Nat := [2,4,8,16,32,16,128,36,512,188,136,17,161,0,1,170,17,1,189,0,137,169,152,3,41,16,136,17,152,136,156,33,37,168,136,648]

theorem envBound47987 : H12AffineFastState.Bounded env47987 := by
  intro p hp
  have h : env47987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47986_47987 : H12AffineEnvironment.transform 7 36 env47986 = env47987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47986 == env47987) = true)

theorem identity47987 : scanCanonicalize (H12AffineFastState.compose env47987 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47987 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47988 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,0,1,35,17,1,52,0,0,32,17,3,41,16,1,17,17,1,21,33,37,33,1,513]

theorem envBound47988 : H12AffineFastState.Bounded env47988 := by
  intro p hp
  have h : env47988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47987_47988 : H12AffineEnvironment.transform 6 9 env47987 = env47988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47987 == env47988) = true)

theorem identity47988 : scanCanonicalize (H12AffineFastState.compose env47988 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound47988 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47989 : List Nat := [2,4,8,16,32,16,9,36,48,53,1,17,40,0,1,35,17,1,52,0,0,32,17,3,41,16,1,17,17,1,21,33,37,33,1,49]

theorem envBound47989 : H12AffineFastState.Bounded env47989 := by
  intro p hp
  have h : env47989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47988_47989 : H12AffineEnvironment.transform 8 48 env47988 = env47989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47988 == env47989) = true)

theorem identity47989 : scanCanonicalize (H12AffineFastState.compose env47989 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47990 : List Nat := [2,4,8,0,32,0,9,36,32,37,1,1,40,0,1,35,1,1,36,0,0,32,1,3,41,0,1,1,1,1,5,33,37,33,1,33]

theorem envBound47990 : H12AffineFastState.Bounded env47990 := by
  intro p hp
  have h : env47990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47989_47990 : H12AffineEnvironment.transform 3 0 env47989 = env47990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47989 == env47990) = true)

def env47991 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184457,272513,180360,169370,8328,17,171417,57748,17664,262281,61705,272393,257,155965,163993,63108]

theorem envBound47991 : H12AffineFastState.Bounded env47991 := by
  intro p hp
  have h : env47991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47977_47991 : H12AffineEnvironment.transform 5 17 env47977 = env47991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47977 == env47991) = true)

theorem identity47991 : scanCanonicalize (H12AffineFastState.compose env47991 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound47991 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env47992 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56356,1025,32769,184457,62629,180360,169370,8328,17,171417,57748,17664,56493,61705,62509,257,155965,163993,63108]

theorem envBound47992 : H12AffineFastState.Bounded env47992 := by
  intro p hp
  have h : env47992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47991_47992 : H12AffineEnvironment.transform 17 56356 env47991 = env47992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env47991 == env47992) = true)

theorem identity47992 : scanCanonicalize (H12AffineFastState.compose env47992 (packedSelected [1,3,11,12,15,17,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57749) := by decide +kernel

theorem selectedBound47992 : packedSelected [1,3,11,12,15,17,23,24,28] rootPS < 2^1333 := by decide +kernel

def env47993 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,57749,56356,1025,32769,12572,62629,8477,29711,8328,17,31756,57748,17664,56493,61705,62509,257,32936,24844,63108]

theorem envBound47993 : H12AffineFastState.Bounded env47993 := by
  intro p hp
  have h : env47993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47992_47993 : H12AffineEnvironment.transform 16 57749 env47992 = env47993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57749 env47992 == env47993) = true)

theorem identity47993 : scanCanonicalize (H12AffineFastState.compose env47993 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound47993 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env47994 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8203,5529,10280,1025,29709,12572,169,8477,29711,8328,17,31756,5528,17664,10401,1285,33,257,29860,24844,648]

theorem envBound47994 : H12AffineFastState.Bounded env47994 := by
  intro p hp
  have h : env47994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47993_47994 : H12AffineEnvironment.transform 14 29708 env47993 = env47994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env47993 == env47994) = true)

theorem identity47994 : scanCanonicalize (H12AffineFastState.compose env47994 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound47994 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env47995 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8581,8203,5529,10280,1025,8580,12572,169,8477,8582,8328,17,10629,5528,4233,10401,1285,33,257,8493,13445,648]

theorem envBound47995 : H12AffineFastState.Bounded env47995 := by
  intro p hp
  have h : env47995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47994_47995 : H12AffineEnvironment.transform 13 5513 env47994 = env47995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47994 == env47995) = true)

theorem identity47995 : scanCanonicalize (H12AffineFastState.compose env47995 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47995 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47996 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,5392,10280,1025,8461,12572,32,8477,8463,8193,17,10508,5393,4096,10280,1285,33,257,8493,13324,513]

theorem envBound47996 : H12AffineFastState.Bounded env47996 := by
  intro p hp
  have h : env47996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47995_47996 : H12AffineEnvironment.transform 6 9 env47995 = env47996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47995 == env47996) = true)

theorem identity47996 : scanCanonicalize (H12AffineFastState.compose env47996 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47996 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47997 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2340,1025,1,4112,32,17,3,269,17,2048,5393,4096,2340,1285,33,257,33,5376,513]

theorem envBound47997 : H12AffineFastState.Bounded env47997 := by
  intro p hp
  have h : env47997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47996_47997 : H12AffineEnvironment.transform 12 268 env47996 = env47997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47996 == env47997) = true)

theorem identity47997 : scanCanonicalize (H12AffineFastState.compose env47997 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47998 : List Nat := [2,4,8,1,32,0,9,256,512,1024,2048,4096,268,5376,0,263,5377,2340,1025,1,4097,32,0,3,269,0,2048,5376,4096,2340,1285,33,257,33,5376,513]

theorem envBound47998 : H12AffineFastState.Bounded env47998 := by
  intro p hp
  have h : env47998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47997_47998 : H12AffineEnvironment.transform 3 1 env47997 = env47998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47997 == env47998) = true)

theorem identity47998 : scanCanonicalize (H12AffineFastState.compose env47998 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound47998 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47999 : List Nat := [2,4,8,1,32,0,9,256,512,1024,1070,4096,268,5376,0,263,5377,1290,1025,1,4097,32,0,3,269,0,1070,5376,4096,1290,1285,33,257,33,5376,513]

theorem envBound47999 : H12AffineFastState.Bounded env47999 := by
  intro p hp
  have h : env47999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47998_47999 : H12AffineEnvironment.transform 10 1070 env47998 = env47999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env47998 == env47999) = true)

theorem identity47999 : scanCanonicalize (H12AffineFastState.compose env47999 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound47999 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48000 : List Nat := [2,4,8,1,32,0,9,256,512,1024,1070,33,268,1313,0,263,1312,1290,1025,1,32,32,0,3,269,0,1070,1313,33,1290,1285,33,257,33,1313,513]

theorem envBound48000 : H12AffineFastState.Bounded env48000 := by
  intro p hp
  have h : env48000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47999_48000 : H12AffineEnvironment.transform 11 33 env47999 = env48000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env47999 == env48000) = true)

theorem identity48000 : scanCanonicalize (H12AffineFastState.compose env48000 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound48000 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48001 : List Nat := [2,4,8,1,32,0,9,256,512,5,43,33,268,292,0,263,293,271,4,1,32,32,0,3,269,0,43,292,33,271,256,33,257,33,292,513]

theorem envBound48001 : H12AffineFastState.Bounded env48001 := by
  intro p hp
  have h : env48001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48000_48001 : H12AffineEnvironment.transform 9 5 env48000 = env48001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env48000 == env48001) = true)

theorem identity48001 : scanCanonicalize (H12AffineFastState.compose env48001 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48001 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48002 : List Nat := [2,4,8,1,32,0,9,5,512,5,43,33,9,33,0,2,32,10,4,1,32,32,0,3,8,0,43,33,33,10,5,33,4,33,33,513]

theorem envBound48002 : H12AffineFastState.Bounded env48002 := by
  intro p hp
  have h : env48002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48001_48002 : H12AffineEnvironment.transform 7 5 env48001 = env48002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48001 == env48002) = true)

theorem identity48002 : scanCanonicalize (H12AffineFastState.compose env48002 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound48002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48003 : List Nat := [2,4,8,1,32,0,9,5,34,5,43,33,9,33,0,2,32,10,4,1,32,32,0,3,8,0,43,33,33,10,5,33,4,33,33,35]

theorem envBound48003 : H12AffineFastState.Bounded env48003 := by
  intro p hp
  have h : env48003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48002_48003 : H12AffineEnvironment.transform 8 34 env48002 = env48003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env48002 == env48003) = true)

theorem identity48003 : scanCanonicalize (H12AffineFastState.compose env48003 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48003 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env48004 : List Nat := [2,4,8,1,11,0,9,5,9,5,0,10,9,10,0,2,11,10,4,1,11,11,0,3,8,0,0,10,10,10,5,10,4,10,10,8]

theorem envBound48004 : H12AffineFastState.Bounded env48004 := by
  intro p hp
  have h : env48004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48003_48004 : H12AffineEnvironment.transform 4 11 env48003 = env48004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48003 == env48004) = true)

theorem identity48004 : scanCanonicalize (H12AffineFastState.compose env48004 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48004 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env48005 : List Nat := [2,4,3,1,0,0,2,5,2,5,0,1,2,1,0,2,0,1,4,1,0,0,0,3,3,0,0,1,1,1,5,1,4,1,1,3]

theorem envBound48005 : H12AffineFastState.Bounded env48005 := by
  intro p hp
  have h : env48005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48004_48005 : H12AffineEnvironment.transform 2 3 env48004 = env48005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48004 == env48005) = true)

theorem identity48005 : scanCanonicalize (H12AffineFastState.compose env48005 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48006 : List Nat := [2,0,3,1,0,0,2,1,2,1,0,1,2,1,0,2,0,1,0,1,0,0,0,3,3,0,0,1,1,1,1,1,0,1,1,3]

theorem envBound48006 : H12AffineFastState.Bounded env48006 := by
  intro p hp
  have h : env48006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48005_48006 : H12AffineEnvironment.transform 1 0 env48005 = env48006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48005 == env48006) = true)

def env48007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,169371,8328,64,4691218,115150,17665,262281,119043,4268163,257,213351,237763,63188]

theorem envBound48007 : H12AffineFastState.Bounded env48007 := by
  intro p hp
  have h : env48007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47942_48007 : H12AffineEnvironment.transform 20 184537 env47942 = env48007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env47942 == env48007) = true)

def env48008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,169371,8328,64,245138,115150,17665,262281,119043,329731,257,213351,237763,63188]

theorem envBound48008 : H12AffineFastState.Bounded env48008 := by
  intro p hp
  have h : env48008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48007_48008 : H12AffineEnvironment.transform 21 272512 env48007 = env48008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48007 == env48008) = true)

theorem identity48008 : scanCanonicalize (H12AffineFastState.compose env48008 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound48008 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,115870,272512,120015,98780,8328,64,43477,115150,17665,262281,119043,329731,257,21792,46212,63188]

theorem envBound48009 : H12AffineFastState.Bounded env48009 := by
  intro p hp
  have h : env48009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48008_48009 : H12AffineEnvironment.transform 16 70727 env48008 = env48009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env48008 == env48009) = true)

def env48010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10400,1025,32769,115870,32,120015,98780,8328,64,43477,115150,17665,10281,119043,73891,257,21792,46212,63188]

theorem envBound48010 : H12AffineFastState.Bounded env48010 := by
  intro p hp
  have h : env48010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48009_48010 : H12AffineEnvironment.transform 17 10400 env48009 = env48010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48009 == env48010) = true)

theorem identity48010 : scanCanonicalize (H12AffineFastState.compose env48010 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound48010 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env48011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,70727,10400,1025,21761,70046,32,65999,87260,8328,64,31957,70862,17665,10281,66563,73891,257,21792,24964,9172]

theorem envBound48011 : H12AffineFastState.Bounded env48011 := by
  intro p hp
  have h : env48011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48010_48011 : H12AffineEnvironment.transform 14 21760 env48010 = env48011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env48010 == env48011) = true)

theorem identity48011 : scanCanonicalize (H12AffineFastState.compose env48011 (packedSelected [0,1,9,16,17,18,20,22,23,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound48011 : packedSelected [0,1,9,16,17,18,20,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env48012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,21590,16401,10400,1025,21761,17864,32,21913,138,8328,64,31957,16536,17665,10281,20565,29941,257,21792,24964,9172]

theorem envBound48012 : H12AffineFastState.Bounded env48012 := by
  intro p hp
  have h : env48012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48011_48012 : H12AffineEnvironment.transform 15 21590 env48011 = env48012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env48011 == env48012) = true)

theorem identity48012 : scanCanonicalize (H12AffineFastState.compose env48012 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48012 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env48013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,0,342,5393,10400,1025,1,4296,32,153,138,8328,64,10709,5528,4097,10281,1365,8693,257,32,13444,9172]

theorem envBound48013 : H12AffineFastState.Bounded env48013 := by
  intro p hp
  have h : env48013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48012_48013 : H12AffineEnvironment.transform 13 5376 env48012 = env48013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48012 == env48013) = true)

theorem identity48013 : scanCanonicalize (H12AffineFastState.compose env48013 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48013 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env48014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,342,5393,10281,1025,1,4161,32,16,3,8193,64,10588,5393,4097,10281,1365,8572,257,32,13325,9053]

theorem envBound48014 : H12AffineFastState.Bounded env48014 := by
  intro p hp
  have h : env48014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48013_48014 : H12AffineEnvironment.transform 6 9 env48013 = env48014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48013 == env48014) = true)

theorem identity48014 : scanCanonicalize (H12AffineFastState.compose env48014 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound48014 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5376,0,342,5393,3173,1025,1,4161,32,16,3,1101,64,3344,5393,4097,3173,1365,1328,257,32,4161,1809]

theorem envBound48015 : H12AffineFastState.Bounded env48015 := by
  intro p hp
  have h : env48015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48014_48015 : H12AffineEnvironment.transform 12 1100 env48014 = env48015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env48014 == env48015) = true)

theorem identity48015 : scanCanonicalize (H12AffineFastState.compose env48015 (packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound48015 : packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,1100,2048,0,342,2065,3173,1025,1,3393,32,16,3,1101,64,3344,2065,3329,3173,1365,1328,257,32,3393,1809]

theorem envBound48016 : H12AffineFastState.Bounded env48016 := by
  intro p hp
  have h : env48016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48015_48016 : H12AffineEnvironment.transform 11 3328 env48015 = env48016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env48015 == env48016) = true)

theorem identity48016 : scanCanonicalize (H12AffineFastState.compose env48016 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48016 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env48017 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,1052,2048,0,262,2065,3125,1025,1,3345,32,16,3,1053,16,3344,2065,3329,3125,1285,1328,257,32,3345,1809]

theorem envBound48017 : H12AffineFastState.Bounded env48017 := by
  intro p hp
  have h : env48017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48016_48017 : H12AffineEnvironment.transform 5 16 env48016 = env48017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48016 == env48017) = true)

theorem identity48017 : scanCanonicalize (H12AffineFastState.compose env48017 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound48017 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48018 : List Nat := [2,4,8,16,32,16,9,256,512,47,2048,2351,51,2048,0,262,2065,2074,46,1,2366,32,16,3,50,16,2367,2065,2350,2074,298,287,257,32,2366,830]

theorem envBound48018 : H12AffineFastState.Bounded env48018 := by
  intro p hp
  have h : env48018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48017_48018 : H12AffineEnvironment.transform 9 47 env48017 = env48018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env48017 == env48018) = true)

theorem identity48018 : scanCanonicalize (H12AffineFastState.compose env48018 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48018 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env48019 : List Nat := [2,4,8,16,32,16,9,37,512,47,2048,2058,51,2048,0,35,2065,2074,46,1,2075,32,16,3,50,16,2074,2065,2059,2074,15,58,36,32,2075,539]

theorem envBound48019 : H12AffineFastState.Bounded env48019 := by
  intro p hp
  have h : env48019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48018_48019 : H12AffineEnvironment.transform 7 37 env48018 = env48019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48018 == env48019) = true)

theorem identity48019 : scanCanonicalize (H12AffineFastState.compose env48019 (packedSelected [0,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 565) := by decide +kernel

theorem selectedBound48019 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env48020 : List Nat := [2,4,8,16,32,16,9,37,512,47,565,575,51,565,0,35,548,559,46,1,558,32,16,3,50,16,559,548,574,559,15,58,36,32,558,539]

theorem envBound48020 : H12AffineFastState.Bounded env48020 := by
  intro p hp
  have h : env48020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48019_48020 : H12AffineEnvironment.transform 10 565 env48019 = env48020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 565 env48019 == env48020) = true)

theorem identity48020 : scanCanonicalize (H12AffineFastState.compose env48020 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48020 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48021 : List Nat := [2,4,4,16,32,16,5,37,512,35,565,563,51,565,0,35,548,547,34,1,546,32,16,3,50,16,547,548,562,547,3,54,36,32,546,535]

theorem envBound48021 : H12AffineFastState.Bounded env48021 := by
  intro p hp
  have h : env48021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48020_48021 : H12AffineEnvironment.transform 2 4 env48020 = env48021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48020 == env48021) = true)

def env48022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10401,1025,32769,115870,33,120015,98780,8328,64,43477,115150,17665,10280,119043,73890,257,21792,46212,63188]

theorem envBound48022 : H12AffineFastState.Bounded env48022 := by
  intro p hp
  have h : env48022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48009_48022 : H12AffineEnvironment.transform 17 10401 env48009 = env48022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48009 == env48022) = true)

theorem identity48022 : scanCanonicalize (H12AffineFastState.compose env48022 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound48022 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env48023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,5529,10401,1025,32769,50496,33,54545,32770,8328,64,43477,49168,17665,10280,53469,8572,257,21792,46212,63188]

theorem envBound48023 : H12AffineFastState.Bounded env48023 := by
  intro p hp
  have h : env48023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48022_48023 : H12AffineEnvironment.transform 15 478 env48022 = env48023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env48022 == env48023) = true)

theorem identity48023 : scanCanonicalize (H12AffineFastState.compose env48023 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48023 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env48024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,5529,10401,1025,29908,12693,33,8644,29911,8328,64,23808,13509,17665,10280,9224,8572,257,21792,16465,513]

theorem envBound48024 : H12AffineFastState.Bounded env48024 := by
  intro p hp
  have h : env48024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48023_48024 : H12AffineEnvironment.transform 14 29909 env48023 = env48024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48023 == env48024) = true)

theorem identity48024 : scanCanonicalize (H12AffineFastState.compose env48024 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound48024 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,478,5529,2421,1025,21760,4161,33,16,21763,348,64,23808,5393,17665,2556,1500,168,257,21792,16465,513]

theorem envBound48025 : H12AffineFastState.Bounded env48025 := by
  intro p hp
  have h : env48025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48024_48025 : H12AffineEnvironment.transform 12 468 env48024 = env48025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env48024 == env48025) = true)

theorem identity48025 : scanCanonicalize (H12AffineFastState.compose env48025 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound48025 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env48026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,478,5529,2421,1025,137,4161,33,16,138,348,64,2185,5393,4232,2556,1500,168,257,169,5592,513]

theorem envBound48026 : H12AffineFastState.Bounded env48026 := by
  intro p hp
  have h : env48026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48025_48026 : H12AffineEnvironment.transform 13 5513 env48025 = env48026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env48025 == env48026) = true)

theorem identity48026 : scanCanonicalize (H12AffineFastState.compose env48026 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48026 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env48027 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,160,5373,136,170,5357,2049,1025,137,4161,33,16,138,40,64,2185,5221,4232,2184,1192,168,117,169,5292,513]

theorem envBound48027 : H12AffineFastState.Bounded env48027 := by
  intro p hp
  have h : env48027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48026_48027 : H12AffineEnvironment.transform 7 116 env48026 = env48027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48026 == env48027) = true)

theorem identity48027 : scanCanonicalize (H12AffineFastState.compose env48027 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound48027 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48028 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,120,5157,80,114,5173,2049,1025,81,4161,33,16,82,40,64,2129,5221,4176,2128,1136,112,117,113,5236,513]

theorem envBound48028 : H12AffineFastState.Bounded env48028 := by
  intro p hp
  have h : env48028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48027_48028 : H12AffineEnvironment.transform 6 88 env48027 = env48028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48027 == env48028) = true)

def env48029 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,34,5173,2049,1025,1,4113,33,16,2,40,16,2049,5173,4096,2048,1056,32,37,33,5156,513]

theorem envBound48029 : H12AffineFastState.Bounded env48029 := by
  intro p hp
  have h : env48029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48028_48029 : H12AffineEnvironment.transform 5 16 env48028 = env48029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48028 == env48029) = true)

theorem identity48029 : scanCanonicalize (H12AffineFastState.compose env48029 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48029 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48030 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,40,4113,0,34,4097,2049,53,1,4113,33,16,2,40,16,2049,4097,4096,2048,20,32,37,33,4112,513]

theorem envBound48030 : H12AffineFastState.Bounded env48030 := by
  intro p hp
  have h : env48030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48029_48030 : H12AffineEnvironment.transform 9 52 env48029 = env48030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48029 == env48030) = true)

theorem identity48030 : scanCanonicalize (H12AffineFastState.compose env48030 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound48030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48031 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,4096,40,4113,0,34,4097,49,53,1,4113,33,16,2,40,16,49,4097,4096,48,20,32,37,33,4112,513]

theorem envBound48031 : H12AffineFastState.Bounded env48031 := by
  intro p hp
  have h : env48031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48030_48031 : H12AffineEnvironment.transform 10 48 env48030 = env48031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env48030 == env48031) = true)

theorem identity48031 : scanCanonicalize (H12AffineFastState.compose env48031 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound48031 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48032 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,40,49,0,34,33,49,53,1,49,33,16,2,40,16,49,33,32,48,20,32,37,33,48,513]

theorem envBound48032 : H12AffineFastState.Bounded env48032 := by
  intro p hp
  have h : env48032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48031_48032 : H12AffineEnvironment.transform 11 32 env48031 = env48032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env48031 == env48032) = true)

def leafEnv48032 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,40,49,0,34,33,49,53,1,49,33,16,2,21,40,1,16,49,33,32,48,20,32,37,33,5,34,48,513,1,48,0]

def active48032 : List Nat := [0,1,2,3,4,8]

def tree48032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48032 : H12WitnessSearch.Good tree48032 := H12GlobalWitnessIndex.good

theorem leafIdentity48032 : H12AffineFastState.composeSystem env48032 rootObs = leafEnv48032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48032 rootObs == leafEnv48032) = true)

theorem terminalChecked48032 : H12PackedTerminal.terminalCheckFast leafEnv48032 active48032 tree48032 = true := by decide +kernel

def env48033 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4112,33,16,3,40,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound48033 : H12AffineFastState.Bounded env48033 := by
  intro p hp
  have h : env48033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48028_48033 : H12AffineEnvironment.transform 5 17 env48028 = env48033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48028 == env48033) = true)

def env48034 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1045,1,35,1029,2049,1025,0,32,33,16,3,40,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound48034 : H12AffineFastState.Bounded env48034 := by
  intro p hp
  have h : env48034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48033_48034 : H12AffineEnvironment.transform 11 48 env48033 = env48034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48033 == env48034) = true)

theorem identity48034 : scanCanonicalize (H12AffineFastState.compose env48034 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48035 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,41,33,1,35,49,2049,53,0,32,33,16,3,40,17,2048,48,49,2049,21,33,36,32,33,513]

theorem envBound48035 : H12AffineFastState.Bounded env48035 := by
  intro p hp
  have h : env48035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48034_48035 : H12AffineEnvironment.transform 9 52 env48034 = env48035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48034 == env48035) = true)

def env48036 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1044,1,35,1028,2049,1025,0,33,33,16,3,40,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound48036 : H12AffineFastState.Bounded env48036 := by
  intro p hp
  have h : env48036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48033_48036 : H12AffineEnvironment.transform 11 49 env48033 = env48036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48033 == env48036) = true)

def env48037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,169371,8328,64,245139,115150,17665,262281,119043,329730,257,213351,237763,63188]

theorem envBound48037 : H12AffineFastState.Bounded env48037 := by
  intro p hp
  have h : env48037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48007_48037 : H12AffineEnvironment.transform 21 272513 env48007 = env48037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48007 == env48037) = true)

theorem identity48037 : scanCanonicalize (H12AffineFastState.compose env48037 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound48037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184537,272513,180360,169371,8328,64,158029,5392,17665,262281,1501,318684,257,169401,160797,63188]

theorem envBound48038 : H12AffineFastState.Bounded env48038 := by
  intro p hp
  have h : env48038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48037_48038 : H12AffineEnvironment.transform 15 54494 env48037 = env48038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env48037 == env48038) = true)

theorem identity48038 : scanCanonicalize (H12AffineFastState.compose env48038 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48038 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,131072,262144,1025,29908,140300,272513,144477,155982,8328,64,158029,5392,17665,262281,1501,272393,257,156012,160797,513]

theorem envBound48039 : H12AffineFastState.Bounded env48039 := by
  intro p hp
  have h : env48039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48038_48039 : H12AffineEnvironment.transform 14 29909 env48038 = env48039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48038 == env48039) = true)

theorem identity48039 : scanCanonicalize (H12AffineFastState.compose env48039 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound48039 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env48040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,131072,262144,1025,21760,132568,264533,136585,147610,348,64,149657,5392,17665,262281,1501,264669,257,147640,153033,513]

theorem envBound48040 : H12AffineFastState.Bounded env48040 := by
  intro p hp
  have h : env48040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48039_48040 : H12AffineEnvironment.transform 12 468 env48039 = env48040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env48039 == env48040) = true)

theorem identity48040 : scanCanonicalize (H12AffineFastState.compose env48040 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound48040 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env48041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,131072,2420,1025,21760,132568,33,136585,147610,348,64,149657,5392,17665,2557,1501,169,257,147640,153033,513]

theorem envBound48041 : H12AffineFastState.Bounded env48041 := by
  intro p hp
  have h : env48041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48040_48041 : H12AffineEnvironment.transform 17 2420 env48040 = env48041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env48040 == env48041) = true)

theorem identity48041 : scanCanonicalize (H12AffineFastState.compose env48041 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound48041 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env48042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,1296,479,131072,2420,1025,1297,132568,33,136585,135307,348,64,137352,5392,5392,2557,1501,169,257,135337,132568,513]

theorem envBound48042 : H12AffineFastState.Bounded env48042 := by
  intro p hp
  have h : env48042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48041_48042 : H12AffineEnvironment.transform 13 4113 env48041 = env48042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env48041 == env48042) = true)

theorem identity48042 : scanCanonicalize (H12AffineFastState.compose env48042 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound48042 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env48043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3464,468,3481,1296,479,131072,2420,1025,1297,132568,33,133121,134403,348,64,132352,2200,2200,2557,1501,169,257,134433,132568,513]

theorem envBound48043 : H12AffineFastState.Bounded env48043 := by
  intro p hp
  have h : env48043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48042_48043 : H12AffineEnvironment.transform 11 3464 env48042 = env48043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env48042 == env48043) = true)

theorem identity48043 : scanCanonicalize (H12AffineFastState.compose env48043 (packedSelected [6,7,9,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound48043 : packedSelected [6,7,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,1141,468,1124,1296,479,131072,137,1025,1297,132568,33,131580,132350,348,64,132352,357,357,0,1501,169,257,132316,132568,513]

theorem envBound48044 : H12AffineFastState.Bounded env48044 := by
  intro p hp
  have h : env48044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48043_48044 : H12AffineEnvironment.transform 10 509 env48043 = env48044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env48043 == env48044) = true)

theorem identity48044 : scanCanonicalize (H12AffineFastState.compose env48044 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 356) := by decide +kernel

theorem selectedBound48044 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,1141,468,1124,1296,479,356,137,1025,1297,1212,33,152,1434,348,64,1124,357,357,0,1501,169,257,1464,1212,513]

theorem envBound48045 : H12AffineFastState.Bounded env48045 := by
  intro p hp
  have h : env48045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48044_48045 : H12AffineEnvironment.transform 16 356 env48044 = env48045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 356 env48044 == env48045) = true)

theorem identity48045 : scanCanonicalize (H12AffineFastState.compose env48045 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48045 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,1141,349,1124,1296,342,356,0,1025,1297,1077,33,17,1299,348,64,1124,357,357,0,1364,32,257,1329,1077,513]

theorem envBound48046 : H12AffineFastState.Bounded env48046 := by
  intro p hp
  have h : env48046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48045_48046 : H12AffineEnvironment.transform 6 9 env48045 = env48046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48045 == env48046) = true)

theorem identity48046 : scanCanonicalize (H12AffineFastState.compose env48046 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48046 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48047 : List Nat := [2,4,8,16,32,64,9,36,512,1024,80,1141,121,1124,1076,114,64,0,1025,1077,1077,33,17,1079,120,64,1124,65,65,0,1136,32,37,1045,1077,513]

theorem envBound48047 : H12AffineFastState.Bounded env48047 := by
  intro p hp
  have h : env48047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48046_48047 : H12AffineEnvironment.transform 7 36 env48046 = env48047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48046 == env48047) = true)

theorem identity48047 : scanCanonicalize (H12AffineFastState.compose env48047 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48047 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48048 : List Nat := [2,4,8,16,32,16,9,36,512,1024,0,1061,41,1076,1076,34,16,0,1025,1077,1077,33,17,1079,40,16,1076,17,17,0,1056,32,37,1045,1077,513]

theorem envBound48048 : H12AffineFastState.Bounded env48048 := by
  intro p hp
  have h : env48048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48047_48048 : H12AffineEnvironment.transform 5 16 env48047 = env48048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48047 == env48048) = true)

def env48049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180361,2114883,8328,64,6637003,115151,2266585,262280,2294234,4268162,257,213351,237763,2237965]

theorem envBound48049 : H12AffineFastState.Bounded env48049 := by
  intro p hp
  have h : env48049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47941_48049 : H12AffineEnvironment.transform 22 180361 env47941 = env48049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env47941 == env48049) = true)

def env48050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,169371,8328,64,4691219,115151,17665,262280,119042,4268162,257,213351,237763,63189]

theorem envBound48050 : H12AffineFastState.Bounded env48050 := by
  intro p hp
  have h : env48050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48049_48050 : H12AffineEnvironment.transform 20 184536 env48049 = env48050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env48049 == env48050) = true)

def env48051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,169371,8328,64,245139,115151,17665,262280,119042,329730,257,213351,237763,63189]

theorem envBound48051 : H12AffineFastState.Bounded env48051 := by
  intro p hp
  have h : env48051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48050_48051 : H12AffineEnvironment.transform 21 272512 env48050 = env48051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48050 == env48051) = true)

def env48052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180225,169235,8192,64,245019,115015,17665,262144,119042,329730,257,213351,237643,63069]

theorem envBound48052 : H12AffineFastState.Bounded env48052 := by
  intro p hp
  have h : env48052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48051_48052 : H12AffineEnvironment.transform 6 8 env48051 = env48052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48051 == env48052) = true)

def env48053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21763,8192,64,97547,115015,17665,262144,119042,329730,257,98679,90203,63069]

theorem envBound48053 : H12AffineFastState.Bounded env48053 := by
  intro p hp
  have h : env48053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48052_48053 : H12AffineEnvironment.transform 16 49168 env48052 = env48053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env48052 == env48053) = true)

theorem identity48053 : scanCanonicalize (H12AffineFastState.compose env48053 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48053 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,4160,41341,17,21763,8192,64,97547,115015,17665,35189,119042,98679,257,98679,90203,63069]

theorem envBound48054 : H12AffineFastState.Bounded env48054 := by
  intro p hp
  have h : env48054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48053_48054 : H12AffineEnvironment.transform 17 35189 env48053 = env48054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48053 == env48054) = true)

theorem identity48054 : scanCanonicalize (H12AffineFastState.compose env48054 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound48054 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env48055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,65536,13672,31757,1025,30073,4160,21509,17,21763,8192,64,97547,78911,17665,31757,74874,95247,257,95247,90203,805]

theorem envBound48055 : H12AffineFastState.Bounded env48055 := by
  intro p hp
  have h : env48055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48054_48055 : H12AffineEnvironment.transform 14 30072 env48054 = env48055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env48054 == env48055) = true)

theorem identity48055 : scanCanonicalize (H12AffineFastState.compose env48055 (packedSelected [0,3,4,5,7,10,12,15,18,19,22,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound48055 : packedSelected [0,3,4,5,7,10,12,15,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env48056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,263,13672,31757,1025,30073,4160,21509,17,21763,8192,64,31756,13624,17665,31757,9597,29960,257,29960,24924,805]

theorem envBound48056 : H12AffineFastState.Bounded env48056 := by
  intro p hp
  have h : env48056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48055_48056 : H12AffineEnvironment.transform 15 263 env48055 = env48056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env48055 == env48056) = true)

theorem identity48056 : scanCanonicalize (H12AffineFastState.compose env48056 (packedSelected [2,6,9,11,14,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48056 : packedSelected [2,6,9,11,14,22,23] rootPS < 2^1333 := by decide +kernel

def env48057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21840,263,5440,23589,1025,21841,4160,21509,17,21763,40,64,23588,5392,17665,23589,1365,21792,257,21792,16756,805]

theorem envBound48057 : H12AffineFastState.Bounded env48057 := by
  intro p hp
  have h : env48057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48056_48057 : H12AffineEnvironment.transform 12 40 env48056 = env48057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48056 == env48057) = true)

theorem identity48057 : scanCanonicalize (H12AffineFastState.compose env48057 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound48057 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env48058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,277,40,16384,17477,263,1109,19760,1025,17476,341,17680,17,17430,40,64,19761,1029,17665,19760,1365,17461,257,17461,16756,805]

theorem envBound48058 : H12AffineFastState.Bounded env48058 := by
  intro p hp
  have h : env48058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48057_48058 : H12AffineEnvironment.transform 11 277 env48057 = env48058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env48057 == env48058) = true)

theorem identity48058 : scanCanonicalize (H12AffineFastState.compose env48058 (packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound48058 : packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env48059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,277,40,1344,261,263,1109,2160,1025,260,341,80,17,342,40,64,2161,1029,65,2160,1365,373,257,373,1076,805]

theorem envBound48059 : H12AffineFastState.Bounded env48059 := by
  intro p hp
  have h : env48059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48058_48059 : H12AffineEnvironment.transform 13 1344 env48058 = env48059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env48058 == env48059) = true)

theorem identity48059 : scanCanonicalize (H12AffineFastState.compose env48059 (packedSelected [2,6,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48059 : packedSelected [2,6,15] rootPS < 2^1333 := by decide +kernel

def env48060 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,96,40,1077,112,114,1109,2160,1025,113,32,80,17,35,40,64,2161,1029,65,2160,1056,0,116,0,1076,592]

theorem envBound48060 : H12AffineFastState.Bounded env48060 := by
  intro p hp
  have h : env48060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48059_48060 : H12AffineEnvironment.transform 7 117 env48059 = env48060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48059 == env48060) = true)

theorem identity48060 : scanCanonicalize (H12AffineFastState.compose env48060 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48060 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48061 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1077,33,35,1028,2081,1025,32,32,1,17,35,40,17,2080,1029,16,2081,1056,0,37,0,1076,513]

theorem envBound48061 : H12AffineFastState.Bounded env48061 := by
  intro p hp
  have h : env48061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48060_48061 : H12AffineEnvironment.transform 5 17 env48060 = env48061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48060 == env48061) = true)

theorem identity48061 : scanCanonicalize (H12AffineFastState.compose env48061 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48061 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48062 : List Nat := [2,4,8,16,32,17,8,36,33,1024,2048,49,40,1077,33,35,1028,2081,1025,32,32,1,17,35,40,17,2080,1029,16,2081,1056,0,37,0,1076,32]

theorem envBound48062 : H12AffineFastState.Bounded env48062 := by
  intro p hp
  have h : env48062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48061_48062 : H12AffineEnvironment.transform 8 33 env48061 = env48062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48061 == env48062) = true)

theorem identity48062 : scanCanonicalize (H12AffineFastState.compose env48062 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48062 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48063 : List Nat := [2,4,8,16,1,17,8,5,0,1024,2048,16,9,1044,0,2,1028,2048,1025,1,1,1,17,2,9,17,2049,1029,16,2048,1025,0,4,0,1045,1]

theorem envBound48063 : H12AffineFastState.Bounded env48063 := by
  intro p hp
  have h : env48063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48062_48063 : H12AffineEnvironment.transform 4 1 env48062 = env48063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48062 == env48063) = true)

theorem identity48063 : scanCanonicalize (H12AffineFastState.compose env48063 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1024) := by decide +kernel

theorem selectedBound48063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48064 : List Nat := [2,4,8,16,1,17,8,5,0,1024,1024,16,9,1044,0,2,1028,1024,1025,1,1,1,17,2,9,17,1025,1029,16,1024,1025,0,4,0,1045,1]

theorem envBound48064 : H12AffineFastState.Bounded env48064 := by
  intro p hp
  have h : env48064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48063_48064 : H12AffineEnvironment.transform 10 1024 env48063 = env48064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1024 env48063 == env48064) = true)

theorem identity48064 : scanCanonicalize (H12AffineFastState.compose env48064 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48065 : List Nat := [2,4,8,16,1,17,8,5,0,4,4,16,9,16,0,2,0,4,5,1,1,1,17,2,9,17,5,1,16,4,5,0,4,0,17,1]

theorem envBound48065 : H12AffineFastState.Bounded env48065 := by
  intro p hp
  have h : env48065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48064_48065 : H12AffineEnvironment.transform 9 4 env48064 = env48065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48064 == env48065) = true)

theorem identity48065 : scanCanonicalize (H12AffineFastState.compose env48065 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound48065 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48066 : List Nat := [2,4,6,16,1,17,6,5,0,4,4,16,7,16,0,2,0,4,5,1,1,1,17,2,7,17,5,1,16,4,5,0,4,0,17,1]

theorem envBound48066 : H12AffineFastState.Bounded env48066 := by
  intro p hp
  have h : env48066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48065_48066 : H12AffineEnvironment.transform 2 6 env48065 = env48066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env48065 == env48066) = true)

theorem identity48066 : scanCanonicalize (H12AffineFastState.compose env48066 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48066 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48067 : List Nat := [2,4,6,5,1,4,6,5,0,4,4,5,7,5,0,2,0,4,5,1,1,1,4,2,7,4,5,1,5,4,5,0,4,0,4,1]

theorem envBound48067 : H12AffineFastState.Bounded env48067 := by
  intro p hp
  have h : env48067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48066_48067 : H12AffineEnvironment.transform 3 5 env48066 = env48067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48066 == env48067) = true)

theorem identity48067 : scanCanonicalize (H12AffineFastState.compose env48067 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48067 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48068 : List Nat := [2,2,0,3,1,2,0,3,0,2,2,3,1,3,0,2,0,2,3,1,1,1,2,2,1,2,3,1,3,2,3,0,2,0,2,1]

theorem envBound48068 : H12AffineFastState.Bounded env48068 := by
  intro p hp
  have h : env48068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48067_48068 : H12AffineEnvironment.transform 1 2 env48067 = env48068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48067 == env48068) = true)

theorem identity48068 : scanCanonicalize (H12AffineFastState.compose env48068 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48068 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env48069 : List Nat := [0,0,0,1,1,0,0,1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,0,1,0,1,1,1,0,1,0,0,0,0,1]

theorem envBound48069 : H12AffineFastState.Bounded env48069 := by
  intro p hp
  have h : env48069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48068_48069 : H12AffineEnvironment.transform 0 0 env48068 = env48069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48068 == env48069) = true)

def env48070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,16,21762,8192,64,97546,115015,17665,262144,119042,329730,257,98678,90202,63069]

theorem envBound48070 : H12AffineFastState.Bounded env48070 := by
  intro p hp
  have h : env48070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48052_48070 : H12AffineEnvironment.transform 16 49169 env48052 = env48070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48052 == env48070) = true)

theorem identity48070 : scanCanonicalize (H12AffineFastState.compose env48070 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48070 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,262144,1025,8541,4161,272392,16,21762,8192,64,97546,90139,17665,262144,94302,329730,257,73770,90202,22273]

theorem envBound48071 : H12AffineFastState.Bounded env48071 := by
  intro p hp
  have h : env48071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48070_48071 : H12AffineEnvironment.transform 14 8540 env48070 = env48071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48070 == env48071) = true)

theorem identity48071 : scanCanonicalize (H12AffineFastState.compose env48071 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound48071 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,2421,1025,8541,4161,8573,16,21762,8192,64,97546,90139,17665,2421,94302,65911,257,73770,90202,22273]

theorem envBound48072 : H12AffineFastState.Bounded env48072 := by
  intro p hp
  have h : env48072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48071_48072 : H12AffineEnvironment.transform 17 2421 env48071 = env48072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env48071 == env48072) = true)

theorem identity48072 : scanCanonicalize (H12AffineFastState.compose env48072 (packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound48072 : packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS < 2^1333 := by decide +kernel

def env48073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,30043,24909,2421,1025,8541,4161,8573,16,21762,8192,64,2129,5440,17665,2421,1285,29740,257,21873,5377,22273]

theorem envBound48073 : H12AffineFastState.Bounded env48073 := by
  intro p hp
  have h : env48073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48072_48073 : H12AffineEnvironment.transform 15 30043 env48072 = env48073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env48072 == env48073) = true)

theorem identity48073 : scanCanonicalize (H12AffineFastState.compose env48073 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48073 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env48074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,373,21874,16740,2421,1025,372,4161,340,16,21762,41,64,2129,5440,17665,2421,1285,21509,257,21873,5377,22273]

theorem envBound48074 : H12AffineFastState.Bounded env48074 := by
  intro p hp
  have h : env48074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48073_48074 : H12AffineEnvironment.transform 12 41 env48073 = env48074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48073 == env48074) = true)

theorem identity48074 : scanCanonicalize (H12AffineFastState.compose env48074 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48074 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env48075 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,16384,80,21591,16449,2128,1025,81,4161,113,16,21543,41,64,2129,5221,17444,2128,1056,21509,36,21588,5156,22052]

theorem envBound48075 : H12AffineFastState.Bounded env48075 := by
  intro p hp
  have h : env48075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48074_48075 : H12AffineEnvironment.transform 7 37 env48074 = env48075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48074 == env48075) = true)

theorem identity48075 : scanCanonicalize (H12AffineFastState.compose env48075 (packedSelected [4,5,7,8,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound48075 : packedSelected [4,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env48076 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,41,16384,80,20530,16449,2128,100,81,4161,113,16,20546,41,64,2129,4096,16449,2128,69,20576,36,20529,4161,21057]

theorem envBound48076 : H12AffineFastState.Bounded env48076 := by
  intro p hp
  have h : env48076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48075_48076 : H12AffineEnvironment.transform 9 101 env48075 = env48076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env48075 == env48076) = true)

theorem identity48076 : scanCanonicalize (H12AffineFastState.compose env48076 (packedSelected [0,2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 624) := by decide +kernel

theorem selectedBound48076 : packedSelected [0,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env48077 : List Nat := [2,4,8,16,32,64,8,37,512,101,624,4096,41,16384,80,20530,16449,544,100,81,4161,113,16,20546,41,64,545,4096,16449,544,69,20576,36,20529,4161,21057]

theorem envBound48077 : H12AffineFastState.Bounded env48077 := by
  intro p hp
  have h : env48077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48076_48077 : H12AffineEnvironment.transform 10 624 env48076 = env48077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 624 env48076 == env48077) = true)

theorem identity48077 : scanCanonicalize (H12AffineFastState.compose env48077 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound48077 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48078 : List Nat := [2,4,8,16,32,64,8,37,512,101,624,4096,41,4160,80,114,4097,544,100,81,4161,113,16,2,41,64,545,4096,4097,544,69,32,36,113,4161,513]

theorem envBound48078 : H12AffineFastState.Bounded env48078 := by
  intro p hp
  have h : env48078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48077_48078 : H12AffineEnvironment.transform 13 4160 env48077 = env48078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env48077 == env48078) = true)

theorem identity48078 : scanCanonicalize (H12AffineFastState.compose env48078 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 609) := by decide +kernel

theorem selectedBound48078 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env48079 : List Nat := [2,4,8,16,32,64,8,37,512,101,624,609,41,545,80,114,608,544,100,81,544,113,16,2,41,64,545,609,608,544,69,32,36,113,544,513]

theorem envBound48079 : H12AffineFastState.Bounded env48079 := by
  intro p hp
  have h : env48079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48078_48079 : H12AffineEnvironment.transform 11 609 env48078 = env48079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 609 env48078 == env48079) = true)

theorem identity48079 : scanCanonicalize (H12AffineFastState.compose env48079 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound48079 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48080 : List Nat := [2,4,8,16,32,49,8,37,512,20,513,528,41,545,33,3,529,544,21,32,544,0,16,2,41,49,545,528,529,544,52,32,36,0,544,513]

theorem envBound48080 : H12AffineFastState.Bounded env48080 := by
  intro p hp
  have h : env48080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48079_48080 : H12AffineEnvironment.transform 5 49 env48079 = env48080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env48079 == env48080) = true)

theorem identity48080 : scanCanonicalize (H12AffineFastState.compose env48080 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48080 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48081 : List Nat := [2,4,8,16,1,16,8,4,512,20,513,528,8,512,0,3,529,513,21,1,513,0,16,2,8,16,512,528,529,513,21,1,5,0,513,513]

theorem envBound48081 : H12AffineFastState.Bounded env48081 := by
  intro p hp
  have h : env48081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48080_48081 : H12AffineEnvironment.transform 4 1 env48080 = env48081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48080 == env48081) = true)

theorem identity48081 : scanCanonicalize (H12AffineFastState.compose env48081 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48082 : List Nat := [2,4,8,1,1,1,8,4,512,5,513,513,8,512,0,3,512,513,4,1,513,0,1,2,8,1,512,513,512,513,4,1,5,0,513,513]

theorem envBound48082 : H12AffineFastState.Bounded env48082 := by
  intro p hp
  have h : env48082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48081_48082 : H12AffineEnvironment.transform 3 1 env48081 = env48082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48081 == env48082) = true)

def env48083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180224,169234,8193,64,245018,115014,17665,262145,119042,329730,257,213351,237642,63068]

theorem envBound48083 : H12AffineFastState.Bounded env48083 := by
  intro p hp
  have h : env48083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48051_48083 : H12AffineEnvironment.transform 6 9 env48051 = env48083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48051 == env48083) = true)

def env48084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,16,21762,8193,64,97546,115014,17665,262145,119042,329730,257,98679,90202,63068]

theorem envBound48084 : H12AffineFastState.Bounded env48084 := by
  intro p hp
  have h : env48084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48083_48084 : H12AffineEnvironment.transform 16 49168 env48083 = env48084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env48083 == env48084) = true)

theorem identity48084 : scanCanonicalize (H12AffineFastState.compose env48084 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound48084 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env48085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,76079,1025,32769,4161,65830,16,21762,8193,64,97546,115014,17665,76078,119042,8493,257,98679,90202,63068]

theorem envBound48085 : H12AffineFastState.Bounded env48085 := by
  intro p hp
  have h : env48085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48084_48085 : H12AffineEnvironment.transform 17 76079 env48084 = env48085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env48084 == env48085) = true)

theorem identity48085 : scanCanonicalize (H12AffineFastState.compose env48085 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound48085 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env48086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,49168,10361,1025,32769,4161,112,16,21762,8193,64,31836,49168,17665,10360,53332,8493,257,32801,24844,63068]

theorem envBound48086 : H12AffineFastState.Bounded env48086 := by
  intro p hp
  have h : env48086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48085_48086 : H12AffineEnvironment.transform 15 342 env48085 = env48086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env48085 == env48086) = true)

theorem identity48086 : scanCanonicalize (H12AffineFastState.compose env48086 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound48086 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,342,5441,10361,1025,21840,4161,112,16,21762,8193,64,31836,5441,17665,10360,1285,8493,257,21872,24844,8973]

theorem envBound48087 : H12AffineFastState.Bounded env48087 := by
  intro p hp
  have h : env48087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48086_48087 : H12AffineEnvironment.transform 14 21841 env48086 = env48087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env48086 == env48087) = true)

theorem identity48087 : scanCanonicalize (H12AffineFastState.compose env48087 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48087 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env48088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8540,342,5441,10361,1025,8541,4161,112,16,8463,8193,64,2129,5441,12556,10360,1285,8493,257,8573,5377,8973]

theorem envBound48088 : H12AffineFastState.Bounded env48088 := by
  intro p hp
  have h : env48088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48087_48088 : H12AffineEnvironment.transform 13 13325 env48087 = env48088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48087 == env48088) = true)

theorem identity48088 : scanCanonicalize (H12AffineFastState.compose env48088 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48088 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,342,5441,2421,1025,81,4161,112,16,3,269,64,2129,5441,4096,2420,1285,33,257,113,5377,513]

theorem envBound48089 : H12AffineFastState.Bounded env48089 := by
  intro p hp
  have h : env48089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48088_48089 : H12AffineEnvironment.transform 12 268 env48088 = env48089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48088 == env48089) = true)

theorem identity48089 : scanCanonicalize (H12AffineFastState.compose env48089 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48089 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48090 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1025,1,4113,32,16,3,269,16,2049,5393,4096,2340,1285,33,257,33,5377,513]

theorem envBound48090 : H12AffineFastState.Bounded env48090 := by
  intro p hp
  have h : env48090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48089_48090 : H12AffineEnvironment.transform 5 16 env48089 = env48090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48089 == env48090) = true)

theorem identity48090 : scanCanonicalize (H12AffineFastState.compose env48090 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48091 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5172,2048,1025,1,4113,32,16,3,40,16,2049,5172,4096,2049,1056,33,36,33,5156,513]

theorem envBound48091 : H12AffineFastState.Bounded env48091 := by
  intro p hp
  have h : env48091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48090_48091 : H12AffineEnvironment.transform 7 37 env48090 = env48091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48090 == env48091) = true)

theorem identity48091 : scanCanonicalize (H12AffineFastState.compose env48091 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48091 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48092 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,0,35,4097,2048,52,1,4113,32,16,3,40,16,2049,4097,4096,2049,21,33,36,33,4113,513]

theorem envBound48092 : H12AffineFastState.Bounded env48092 := by
  intro p hp
  have h : env48092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48091_48092 : H12AffineEnvironment.transform 9 53 env48091 = env48092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48091 == env48092) = true)

theorem identity48092 : scanCanonicalize (H12AffineFastState.compose env48092 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound48092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48093 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,32,41,49,0,35,33,2048,52,1,49,32,16,3,40,16,2049,33,32,2049,21,33,36,33,49,513]

theorem envBound48093 : H12AffineFastState.Bounded env48093 := by
  intro p hp
  have h : env48093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48092_48093 : H12AffineEnvironment.transform 11 32 env48092 = env48093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env48092 == env48093) = true)

theorem identity48093 : scanCanonicalize (H12AffineFastState.compose env48093 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound48093 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48094 : List Nat := [2,4,8,16,32,16,9,37,512,53,513,32,41,49,0,35,33,513,52,1,49,32,16,3,40,16,512,33,32,512,21,33,36,33,49,513]

theorem envBound48094 : H12AffineFastState.Bounded env48094 := by
  intro p hp
  have h : env48094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48093_48094 : H12AffineEnvironment.transform 10 513 env48093 = env48094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env48093 == env48094) = true)

theorem identity48094 : scanCanonicalize (H12AffineFastState.compose env48094 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48094 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48095 : List Nat := [2,4,8,16,32,16,9,37,0,53,1,32,41,49,0,35,33,1,52,1,49,32,16,3,40,16,0,33,32,0,21,33,36,33,49,1]

theorem envBound48095 : H12AffineFastState.Bounded env48095 := by
  intro p hp
  have h : env48095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48094_48095 : H12AffineEnvironment.transform 8 0 env48094 = env48095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48094 == env48095) = true)

theorem identity48095 : scanCanonicalize (H12AffineFastState.compose env48095 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48095 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48096 : List Nat := [2,4,8,16,17,16,9,20,0,4,1,17,24,0,0,18,16,1,5,1,0,17,16,3,25,16,0,16,17,0,21,16,21,16,0,1]

theorem envBound48096 : H12AffineFastState.Bounded env48096 := by
  intro p hp
  have h : env48096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48095_48096 : H12AffineEnvironment.transform 4 17 env48095 = env48096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48095 == env48096) = true)

def env48097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21763,8193,64,97547,115014,17665,262145,119042,329730,257,98678,90203,63068]

theorem envBound48097 : H12AffineFastState.Bounded env48097 := by
  intro p hp
  have h : env48097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48083_48097 : H12AffineEnvironment.transform 16 49169 env48083 = env48097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48083 == env48097) = true)

theorem identity48097 : scanCanonicalize (H12AffineFastState.compose env48097 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48097 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,33,17,21763,8193,64,97547,115014,17665,10281,119042,73770,257,98678,90203,63068]

theorem envBound48098 : H12AffineFastState.Bounded env48098 := by
  intro p hp
  have h : env48098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48097_48098 : H12AffineEnvironment.transform 17 10280 env48097 = env48098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48097 == env48098) = true)

theorem identity48098 : scanCanonicalize (H12AffineFastState.compose env48098 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound48098 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env48099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8282,49169,10280,1025,32769,4160,33,17,21763,8193,64,23889,57628,17665,10281,61784,112,257,41260,16385,63068]

theorem envBound48099 : H12AffineFastState.Bounded env48099 := by
  intro p hp
  have h : env48099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48098_48099 : H12AffineEnvironment.transform 15 8282 env48098 = env48099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env48098 == env48099) = true)

theorem identity48099 : scanCanonicalize (H12AffineFastState.compose env48099 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48099 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48100 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10280,1025,32769,4112,33,17,21763,8193,16,23809,57628,17665,10281,61704,32,257,41260,16385,62988]

theorem envBound48100 : H12AffineFastState.Bounded env48100 := by
  intro p hp
  have h : env48100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48099_48100 : H12AffineEnvironment.transform 5 16 env48099 = env48100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48099 == env48100) = true)

theorem identity48100 : scanCanonicalize (H12AffineFastState.compose env48100 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48100 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48101 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,8202,46109,10280,1025,32769,4112,33,17,8463,8193,16,10509,38160,12557,10281,34052,32,257,41260,13325,33280]

theorem envBound48101 : H12AffineFastState.Bounded env48101 := by
  intro p hp
  have h : env48101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48100_48101 : H12AffineEnvironment.transform 13 13324 env48100 = env48101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48100 == env48101) = true)

theorem identity48101 : scanCanonicalize (H12AffineFastState.compose env48101 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 6453) := by decide +kernel

theorem selectedBound48101 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48102 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,6453,8202,11560,10280,1025,6452,4112,33,17,8463,8193,16,10509,3109,12557,10281,7217,32,257,14361,13325,6965]

theorem envBound48102 : H12AffineFastState.Bounded env48102 := by
  intro p hp
  have h : env48102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48101_48102 : H12AffineEnvironment.transform 14 6453 env48101 = env48102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6453 env48101 == env48102) = true)

theorem identity48102 : scanCanonicalize (H12AffineFastState.compose env48102 (packedSelected [0,3,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound48102 : packedSelected [0,3,6,8,9] rootPS < 2^1333 := by decide +kernel

def env48103 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,513,8192,9741,2868,8202,11560,10280,1025,2869,529,33,17,8463,8193,16,10509,3109,8972,10281,3632,32,257,10776,9740,2356]

theorem envBound48103 : H12AffineFastState.Bounded env48103 := by
  intro p hp
  have h : env48103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48102_48103 : H12AffineEnvironment.transform 11 513 env48102 = env48103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env48102 == env48103) = true)

theorem identity48103 : scanCanonicalize (H12AffineFastState.compose env48103 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound48103 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env48104 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1280,513,8192,9741,1588,8202,8232,9512,1025,1589,529,33,17,8463,8193,16,9229,293,8972,9513,816,32,257,10008,9740,1076]

theorem envBound48104 : H12AffineFastState.Bounded env48104 := by
  intro p hp
  have h : env48104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48103_48104 : H12AffineEnvironment.transform 10 1280 env48103 = env48104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env48103 == env48104) = true)

theorem identity48104 : scanCanonicalize (H12AffineFastState.compose env48104 (packedSelected [0,1,5,7,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48104 : packedSelected [0,1,5,7,12,14] rootPS < 2^1333 := by decide +kernel

def env48105 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1280,513,268,1793,1588,262,292,1060,1025,1589,529,33,17,3,269,16,1281,293,512,1061,816,32,257,1556,1792,1076]

theorem envBound48105 : H12AffineFastState.Bounded env48105 := by
  intro p hp
  have h : env48105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48104_48105 : H12AffineEnvironment.transform 12 268 env48104 = env48105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48104 == env48105) = true)

theorem identity48105 : scanCanonicalize (H12AffineFastState.compose env48105 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound48105 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env48106 : List Nat := [2,4,8,16,32,16,9,256,512,785,529,513,268,16,293,262,292,821,784,292,529,33,17,3,269,16,528,293,512,820,816,32,257,261,17,805]

theorem envBound48106 : H12AffineFastState.Bounded env48106 := by
  intro p hp
  have h : env48106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48105_48106 : H12AffineEnvironment.transform 9 785 env48105 = env48106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env48105 == env48106) = true)

theorem identity48106 : scanCanonicalize (H12AffineFastState.compose env48106 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48106 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env48107 : List Nat := [2,4,8,16,32,16,9,37,512,564,529,513,41,16,0,35,1,528,565,1,529,33,17,3,40,16,528,0,512,529,533,32,36,32,17,512]

theorem envBound48107 : H12AffineFastState.Bounded env48107 := by
  intro p hp
  have h : env48107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48106_48107 : H12AffineEnvironment.transform 7 37 env48106 = env48107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48106 == env48107) = true)

theorem identity48107 : scanCanonicalize (H12AffineFastState.compose env48107 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48108 : List Nat := [2,4,8,16,1,16,9,4,512,533,529,513,8,16,0,2,1,528,532,1,529,0,17,3,9,16,528,0,512,529,533,1,5,1,17,512]

theorem envBound48108 : H12AffineFastState.Bounded env48108 := by
  intro p hp
  have h : env48108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48107_48108 : H12AffineEnvironment.transform 4 1 env48107 = env48108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48107 == env48108) = true)

theorem identity48108 : scanCanonicalize (H12AffineFastState.compose env48108 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48108 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48109 : List Nat := [2,4,8,0,1,0,9,4,512,517,513,513,8,0,0,2,1,512,516,1,513,0,1,3,9,0,512,0,512,513,517,1,5,1,1,512]

theorem envBound48109 : H12AffineFastState.Bounded env48109 := by
  intro p hp
  have h : env48109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48108_48109 : H12AffineEnvironment.transform 3 0 env48108 = env48109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48108 == env48109) = true)

theorem identity48109 : scanCanonicalize (H12AffineFastState.compose env48109 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48110 : List Nat := [2,4,8,0,1,0,9,4,0,5,1,1,8,0,0,2,1,0,4,1,1,0,1,3,9,0,0,0,0,1,5,1,5,1,1,0]

theorem envBound48110 : H12AffineFastState.Bounded env48110 := by
  intro p hp
  have h : env48110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48109_48110 : H12AffineEnvironment.transform 8 0 env48109 = env48110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48109 == env48110) = true)

theorem identity48110 : scanCanonicalize (H12AffineFastState.compose env48110 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48111 : List Nat := [2,1,8,0,1,0,9,1,0,0,1,1,8,0,0,2,1,0,1,1,1,0,1,3,9,0,0,0,0,1,0,1,0,1,1,0]

theorem envBound48111 : H12AffineFastState.Bounded env48111 := by
  intro p hp
  have h : env48111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48110_48111 : H12AffineEnvironment.transform 1 1 env48110 = env48111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48110 == env48111) = true)

def env48112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,169371,8328,64,245138,115151,17665,262280,119042,329731,257,213351,237763,63189]

theorem envBound48112 : H12AffineFastState.Bounded env48112 := by
  intro p hp
  have h : env48112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48050_48112 : H12AffineEnvironment.transform 21 272513 env48050 = env48112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48050 == env48112) = true)

theorem identity48112 : scanCanonicalize (H12AffineFastState.compose env48112 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound48112 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4160,272513,17,21763,8328,64,97546,115151,17665,262280,119042,329731,257,98815,90203,63189]

theorem envBound48113 : H12AffineFastState.Bounded env48113 := by
  intro p hp
  have h : env48113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48112_48113 : H12AffineEnvironment.transform 16 49304 env48112 = env48113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env48112 == env48113) = true)

def env48114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21763,8192,64,97546,115015,17665,262144,119042,329731,257,98679,90203,63069]

theorem envBound48114 : H12AffineFastState.Bounded env48114 := by
  intro p hp
  have h : env48114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48113_48114 : H12AffineEnvironment.transform 6 8 env48113 = env48114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48113 == env48114) = true)

theorem identity48114 : scanCanonicalize (H12AffineFastState.compose env48114 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48114 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,4160,41340,17,21763,8192,64,97546,115015,17665,35189,119042,98678,257,98679,90203,63069]

theorem envBound48115 : H12AffineFastState.Bounded env48115 := by
  intro p hp
  have h : env48115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48114_48115 : H12AffineEnvironment.transform 17 35189 env48114 = env48115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48114 == env48115) = true)

theorem identity48115 : scanCanonicalize (H12AffineFastState.compose env48115 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound48115 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env48116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,372,65536,16740,2049,1025,373,4160,8200,17,21763,8192,64,97546,81971,17665,2049,86134,65538,257,65539,90203,30505]

theorem envBound48116 : H12AffineFastState.Bounded env48116 := by
  intro p hp
  have h : env48116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48115_48116 : H12AffineEnvironment.transform 14 372 env48115 = env48116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env48115 == env48116) = true)

theorem identity48116 : scanCanonicalize (H12AffineFastState.compose env48116 (packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48116 : packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env48117 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,80,65536,16448,2049,1025,81,4160,8200,17,21543,8192,64,97326,81971,17445,2049,86134,65538,37,65539,90203,30221]

theorem envBound48117 : H12AffineFastState.Bounded env48117 := by
  intro p hp
  have h : env48117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48116_48117 : H12AffineEnvironment.transform 7 36 env48116 = env48117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48116 == env48117) = true)

theorem identity48117 : scanCanonicalize (H12AffineFastState.compose env48117 (packedSelected [2,3,5,6,9,10,11,12,14,15,16,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound48117 : packedSelected [2,3,5,6,9,10,11,12,14,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env48118 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,80,29743,16448,2049,1025,81,4160,8200,17,21543,8192,64,2049,13340,17445,2049,9305,29741,37,29740,5236,30221]

theorem envBound48118 : H12AffineFastState.Bounded env48118 := by
  intro p hp
  have h : env48118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48117_48118 : H12AffineEnvironment.transform 15 29743 env48117 = env48118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env48117 == env48118) = true)

def env48119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21763,8193,64,97546,115014,17665,262145,119042,329731,257,98678,90203,63068]

theorem envBound48119 : H12AffineFastState.Bounded env48119 := by
  intro p hp
  have h : env48119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48113_48119 : H12AffineEnvironment.transform 6 9 env48113 = env48119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48113 == env48119) = true)

theorem identity48119 : scanCanonicalize (H12AffineFastState.compose env48119 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48119 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,32,17,21763,8193,64,97546,115014,17665,10281,119042,73771,257,98678,90203,63068]

theorem envBound48120 : H12AffineFastState.Bounded env48120 := by
  intro p hp
  have h : env48120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48119_48120 : H12AffineEnvironment.transform 17 10280 env48119 = env48120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48119 == env48120) = true)

theorem identity48120 : scanCanonicalize (H12AffineFastState.compose env48120 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48120 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env48121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,65536,49169,2341,1025,32769,4160,32,17,21763,268,64,89095,115014,17665,2340,119042,65830,257,98678,82262,55121]

theorem envBound48121 : H12AffineFastState.Bounded env48121 := by
  intro p hp
  have h : env48121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48120_48121 : H12AffineEnvironment.transform 12 269 env48120 = env48121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48120 == env48121) = true)

theorem identity48121 : scanCanonicalize (H12AffineFastState.compose env48121 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48121 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,65536,38161,2341,1025,32769,4160,32,17,3,268,64,67847,103494,4097,2340,99330,65830,257,98678,70742,33361]

theorem envBound48122 : H12AffineFastState.Bounded env48122 := by
  intro p hp
  have h : env48122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48121_48122 : H12AffineEnvironment.transform 13 5376 env48121 = env48122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48121 == env48122) = true)

theorem identity48122 : scanCanonicalize (H12AffineFastState.compose env48122 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound48122 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,1,65536,5392,2341,1025,0,4160,32,17,3,268,64,67847,70727,4097,2340,66563,65830,257,65911,70742,592]

theorem envBound48123 : H12AffineFastState.Bounded env48123 := by
  intro p hp
  have h : env48123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48122_48123 : H12AffineEnvironment.transform 14 1 env48122 = env48123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env48122 == env48123) = true)

theorem identity48123 : scanCanonicalize (H12AffineFastState.compose env48123 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 6423) := by decide +kernel

theorem selectedBound48123 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,1,6423,5392,2341,1025,0,4160,32,17,3,268,64,4112,3408,4097,2340,7444,6193,257,6240,3393,592]

theorem envBound48124 : H12AffineFastState.Bounded env48124 := by
  intro p hp
  have h : env48124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48123_48124 : H12AffineEnvironment.transform 15 6423 env48123 = env48124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6423 env48123 == env48124) = true)

theorem identity48124 : scanCanonicalize (H12AffineFastState.compose env48124 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48124 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48125 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,6423,5392,2341,1025,0,4113,32,17,3,268,17,4112,3329,4097,2340,7444,6193,257,6193,3344,513]

theorem envBound48125 : H12AffineFastState.Bounded env48125 := by
  intro p hp
  have h : env48125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48124_48125 : H12AffineEnvironment.transform 5 17 env48124 = env48125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48124 == env48125) = true)

theorem identity48125 : scanCanonicalize (H12AffineFastState.compose env48125 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound48125 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48126 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2064,269,3344,1,263,3328,2341,1025,0,2049,32,17,3,268,17,2048,3329,2065,2340,1284,33,257,33,3344,513]

theorem envBound48126 : H12AffineFastState.Bounded env48126 := by
  intro p hp
  have h : env48126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48125_48126 : H12AffineEnvironment.transform 11 2064 env48125 = env48126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env48125 == env48126) = true)

theorem identity48126 : scanCanonicalize (H12AffineFastState.compose env48126 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound48126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48127 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1313,1329,269,49,1,263,33,1028,1025,0,1312,32,17,3,268,17,1313,32,1328,1029,1284,33,257,33,49,513]

theorem envBound48127 : H12AffineFastState.Bounded env48127 := by
  intro p hp
  have h : env48127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48126_48127 : H12AffineEnvironment.transform 10 1313 env48126 = env48127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env48126 == env48127) = true)

theorem identity48127 : scanCanonicalize (H12AffineFastState.compose env48127 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48127 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48128 : List Nat := [2,4,8,16,32,17,9,256,49,1024,1313,1329,269,49,1,263,33,1028,1025,0,1312,32,17,3,268,17,1313,32,1328,1029,1284,33,257,33,49,48]

theorem envBound48128 : H12AffineFastState.Bounded env48128 := by
  intro p hp
  have h : env48128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48127_48128 : H12AffineEnvironment.transform 8 49 env48127 = env48128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48127 == env48128) = true)

theorem identity48128 : scanCanonicalize (H12AffineFastState.compose env48128 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

end H12CloudChart1