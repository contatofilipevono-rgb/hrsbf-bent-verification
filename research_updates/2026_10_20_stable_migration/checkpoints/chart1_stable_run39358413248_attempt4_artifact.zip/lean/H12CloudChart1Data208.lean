import H12CloudChart1Data207

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity52673 : scanCanonicalize (H12AffineFastState.compose env52673 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound52673 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52674 : List Nat := [2,3,0,1,2,0,0,3,3,0,1,1,0,3,0,3,3,2,1,1,1,2,0,2,0,0,0,3,0,2,0,2,2,2,3,2]

theorem envBound52674 : H12AffineFastState.Bounded env52674 := by
  intro p hp
  have h : env52674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52673_52674 : H12AffineEnvironment.transform 2 0 env52673 = env52674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env52673 == env52674) = true)

def env52675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,21763,8193,64,75786,115014,17664,303453,119042,392287,257,98679,90202,63068]

theorem envBound52675 : H12AffineFastState.Bounded env52675 := by
  intro p hp
  have h : env52675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52658_52675 : H12AffineEnvironment.transform 6 9 env52658 = env52675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52658 == env52675) = true)

theorem identity52675 : scanCanonicalize (H12AffineFastState.compose env52675 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound52675 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1025,32769,4160,21793,17,21763,8193,64,75786,115014,17664,10281,119042,95531,257,98679,90202,63068]

theorem envBound52676 : H12AffineFastState.Bounded env52676 := by
  intro p hp
  have h : env52676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52675_52676 : H12AffineEnvironment.transform 17 35188 env52675 = env52676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env52675 == env52676) = true)

theorem identity52676 : scanCanonicalize (H12AffineFastState.compose env52676 (packedSelected [1,3,18,19,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound52676 : packedSelected [1,3,18,19,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33031,24908,35188,1025,32769,4160,21793,17,21763,8193,64,43277,16449,17664,10281,20485,62508,257,112,57693,63068]

theorem envBound52677 : H12AffineFastState.Bounded env52677 := by
  intro p hp
  have h : env52677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52676_52677 : H12AffineEnvironment.transform 15 33031 env52676 = env52677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env52676 == env52677) = true)

theorem identity52677 : scanCanonicalize (H12AffineFastState.compose env52677 (packedSelected [0,3,5,7,9,10,12,14,15,19,20,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52677 : packedSelected [0,3,5,7,9,10,12,14,15,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env52678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,33031,13625,35188,1025,32769,4160,340,17,374,8193,64,43277,5172,4469,10281,1136,41049,257,112,46376,41513]

theorem envBound52678 : H12AffineFastState.Bounded env52678 := by
  intro p hp
  have h : env52678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52677_52678 : H12AffineEnvironment.transform 13 5237 env52677 = env52678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52677 == env52678) = true)

theorem identity52678 : scanCanonicalize (H12AffineFastState.compose env52678 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound52678 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env52679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,32768,33031,5441,35188,1025,32769,4160,340,17,374,121,64,35189,5172,4469,2129,1136,32801,257,112,38224,33361]

theorem envBound52679 : H12AffineFastState.Bounded env52679 := by
  intro p hp
  have h : env52679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52678_52679 : H12AffineEnvironment.transform 12 120 env52678 = env52679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env52678 == env52679) = true)

theorem identity52679 : scanCanonicalize (H12AffineFastState.compose env52679 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound52679 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,80,343,5441,2340,1025,81,4160,340,17,374,121,64,2341,5172,4469,2129,1136,113,257,112,5376,513]

theorem envBound52680 : H12AffineFastState.Bounded env52680 := by
  intro p hp
  have h : env52680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52679_52680 : H12AffineEnvironment.transform 14 80 env52679 = env52680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env52679 == env52680) = true)

theorem identity52680 : scanCanonicalize (H12AffineFastState.compose env52680 (packedSelected [1,2,5,6,7,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound52680 : packedSelected [1,2,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env52681 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,120,3393,80,343,3189,2340,1025,81,2420,340,17,374,121,64,2341,3328,2113,2129,1136,113,257,112,3124,513]

theorem envBound52681 : H12AffineFastState.Bounded env52681 := by
  intro p hp
  have h : env52681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52680_52681 : H12AffineEnvironment.transform 11 2356 env52680 = env52681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env52680 == env52681) = true)

theorem identity52681 : scanCanonicalize (H12AffineFastState.compose env52681 (packedSelected [3,4,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52681 : packedSelected [3,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env52682 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2356,120,2129,80,343,2405,2340,273,81,2420,340,17,374,121,64,2341,2064,2113,2129,352,113,257,112,2340,513]

theorem envBound52682 : H12AffineFastState.Bounded env52682 := by
  intro p hp
  have h : env52682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52681_52682 : H12AffineEnvironment.transform 9 272 env52681 = env52682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52681 == env52682) = true)

theorem identity52682 : scanCanonicalize (H12AffineFastState.compose env52682 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52682 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52683 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2113,120,2129,80,34,2064,2129,100,81,2049,33,17,3,121,64,2128,2064,2113,2129,21,113,116,112,2129,513]

theorem envBound52683 : H12AffineFastState.Bounded env52683 := by
  intro p hp
  have h : env52683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52682_52683 : H12AffineEnvironment.transform 7 117 env52682 = env52683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52682 == env52683) = true)

theorem identity52683 : scanCanonicalize (H12AffineFastState.compose env52683 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52683 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52684 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,41,2048,1,34,2064,2048,53,0,2049,33,17,3,40,17,2049,2064,2064,2048,21,32,37,33,2048,513]

theorem envBound52684 : H12AffineFastState.Bounded env52684 := by
  intro p hp
  have h : env52684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52683_52684 : H12AffineEnvironment.transform 5 17 env52683 = env52684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52683 == env52684) = true)

theorem identity52684 : scanCanonicalize (H12AffineFastState.compose env52684 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound52684 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52685 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,41,49,1,34,33,49,53,0,48,33,17,3,40,17,48,33,33,49,21,32,37,33,49,513]

theorem envBound52685 : H12AffineFastState.Bounded env52685 := by
  intro p hp
  have h : env52685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52684_52685 : H12AffineEnvironment.transform 10 49 env52684 = env52685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env52684 == env52685) = true)

theorem identity52685 : scanCanonicalize (H12AffineFastState.compose env52685 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52686 : List Nat := [2,4,8,0,32,1,9,36,512,36,33,33,41,33,1,34,33,33,37,0,32,33,1,3,40,1,32,33,33,33,5,32,37,33,33,513]

theorem envBound52686 : H12AffineFastState.Bounded env52686 := by
  intro p hp
  have h : env52686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52685_52686 : H12AffineEnvironment.transform 3 0 env52685 = env52686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52685 == env52686) = true)

theorem identity52686 : scanCanonicalize (H12AffineFastState.compose env52686 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound52686 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52687 : List Nat := [2,4,8,0,32,1,9,36,32,36,33,33,41,33,1,34,33,33,37,0,32,33,1,3,40,1,32,33,33,33,5,32,37,33,33,33]

theorem envBound52687 : H12AffineFastState.Bounded env52687 := by
  intro p hp
  have h : env52687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52686_52687 : H12AffineEnvironment.transform 8 32 env52686 = env52687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env52686 == env52687) = true)

theorem identity52687 : scanCanonicalize (H12AffineFastState.compose env52687 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52687 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52688 : List Nat := [2,4,8,0,0,1,9,4,0,4,1,1,9,1,1,2,1,1,5,0,0,1,1,3,8,1,0,1,1,1,5,0,5,1,1,1]

theorem envBound52688 : H12AffineFastState.Bounded env52688 := by
  intro p hp
  have h : env52688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52687_52688 : H12AffineEnvironment.transform 4 0 env52687 = env52688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52687 == env52688) = true)

def env52689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,21762,8328,64,215366,115151,140365,303453,241743,499099,257,254130,196886,169880]

theorem envBound52689 : H12AffineFastState.Bounded env52689 := by
  intro p hp
  have h : env52689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52656_52689 : H12AffineEnvironment.transform 20 4161 env52656 = env52689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52656 == env52689) = true)

theorem identity52689 : scanCanonicalize (H12AffineFastState.compose env52689 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound52689 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,412109,155997,21762,8328,64,215366,79130,140365,284040,214170,485710,257,201831,196886,156493]

theorem envBound52690 : H12AffineFastState.Bounded env52690 := by
  intro p hp
  have h : env52690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52689_52690 : H12AffineEnvironment.transform 14 29909 env52689 = env52690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env52689 == env52690) = true)

def env52691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,411973,155997,21762,8192,64,215366,79130,140365,283904,214034,485710,257,201831,196886,156493]

theorem envBound52691 : H12AffineFastState.Bounded env52691 := by
  intro p hp
  have h : env52691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52690_52691 : H12AffineEnvironment.transform 6 8 env52690 = env52691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52690 == env52691) = true)

theorem identity52691 : scanCanonicalize (H12AffineFastState.compose env52691 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52691 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env52692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1025,8540,4161,400453,144477,2,8192,64,203846,79130,140365,262144,200978,474190,257,201831,196886,144973]

theorem envBound52692 : H12AffineFastState.Bounded env52692 := by
  intro p hp
  have h : env52692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52691_52692 : H12AffineEnvironment.transform 13 5376 env52691 = env52692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52691 == env52692) = true)

theorem identity52692 : scanCanonicalize (H12AffineFastState.compose env52692 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound52692 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env52693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,76159,1025,8540,4161,210234,144477,2,8192,64,203846,79130,140365,76159,200978,136497,257,201831,196886,144973]

theorem envBound52693 : H12AffineFastState.Bounded env52693 := by
  intro p hp
  have h : env52693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52692_52693 : H12AffineEnvironment.transform 17 76159 env52692 = env52693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env52692 == env52693) = true)

theorem identity52693 : scanCanonicalize (H12AffineFastState.compose env52693 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound52693 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env52694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13389,76159,1025,8540,4161,65911,16,2,8192,64,75787,79130,4096,76159,75103,8572,257,73770,79195,512]

theorem envBound52694 : H12AffineFastState.Bounded env52694 := by
  intro p hp
  have h : env52694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52693_52694 : H12AffineEnvironment.transform 16 13389 env52693 = env52694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env52693 == env52694) = true)

theorem identity52694 : scanCanonicalize (H12AffineFastState.compose env52694 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 1298) := by decide +kernel

theorem selectedBound52694 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,1298,13389,11373,1025,8540,4161,1125,16,2,8192,64,11545,12296,4096,11373,8269,8572,257,9528,12361,512]

theorem envBound52695 : H12AffineFastState.Bounded env52695 := by
  intro p hp
  have h : env52695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52694_52695 : H12AffineEnvironment.transform 15 1298 env52694 = env52695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1298 env52694 == env52695) = true)

theorem identity52695 : scanCanonicalize (H12AffineFastState.compose env52695 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound52695 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env52696 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,8192,4144,8541,34,12669,10589,305,8540,4161,341,16,2,8192,64,10281,12296,4096,10589,8269,8572,257,8200,12361,512]

theorem envBound52696 : H12AffineFastState.Bounded env52696 := by
  intro p hp
  have h : env52696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52695_52696 : H12AffineEnvironment.transform 9 304 env52695 = env52696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env52695 == env52696) = true)

theorem identity52696 : scanCanonicalize (H12AffineFastState.compose env52696 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound52696 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env52697 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,300,4144,113,34,4177,2161,305,112,4161,341,16,2,300,64,2309,4388,4096,2161,353,80,257,292,4453,512]

theorem envBound52697 : H12AffineFastState.Bounded env52697 := by
  intro p hp
  have h : env52697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52696_52697 : H12AffineEnvironment.transform 12 300 env52696 = env52697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env52696 == env52697) = true)

theorem identity52697 : scanCanonicalize (H12AffineFastState.compose env52697 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52697 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52698 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,300,4144,32,34,4096,2080,305,33,4112,260,16,2,300,17,2309,4388,4096,2080,304,1,257,292,4404,512]

theorem envBound52698 : H12AffineFastState.Bounded env52698 := by
  intro p hp
  have h : env52698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52697_52698 : H12AffineEnvironment.transform 5 17 env52697 = env52698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52697 == env52698) = true)

theorem identity52698 : scanCanonicalize (H12AffineFastState.compose env52698 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52698 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52699 : List Nat := [2,4,8,16,32,17,8,37,512,21,2048,4096,9,4144,32,34,4096,2080,20,33,4112,33,16,2,9,17,2080,4097,4096,2080,21,1,36,1,4113,512]

theorem envBound52699 : H12AffineFastState.Bounded env52699 := by
  intro p hp
  have h : env52699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52698_52699 : H12AffineEnvironment.transform 7 37 env52698 = env52699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52698 == env52699) = true)

theorem identity52699 : scanCanonicalize (H12AffineFastState.compose env52699 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52699 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env52700 : List Nat := [2,4,8,16,11,17,8,14,512,21,2048,4096,9,4123,11,9,4096,2059,20,10,4112,10,16,2,9,17,2059,4097,4096,2059,21,1,15,1,4113,512]

theorem envBound52700 : H12AffineFastState.Bounded env52700 := by
  intro p hp
  have h : env52700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52699_52700 : H12AffineEnvironment.transform 4 11 env52699 = env52700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52699 == env52700) = true)

theorem identity52700 : scanCanonicalize (H12AffineFastState.compose env52700 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52700 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52701 : List Nat := [2,4,8,10,11,11,8,14,512,15,2048,4096,9,4097,11,9,4096,2059,14,10,4106,10,10,2,9,11,2059,4097,4096,2059,15,1,15,1,4107,512]

theorem envBound52701 : H12AffineFastState.Bounded env52701 := by
  intro p hp
  have h : env52701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52700_52701 : H12AffineEnvironment.transform 3 10 env52700 = env52701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52700 == env52701) = true)

theorem identity52701 : scanCanonicalize (H12AffineFastState.compose env52701 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound52701 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52702 : List Nat := [2,4,8,10,11,11,8,14,512,15,2048,11,9,10,11,9,11,2059,14,10,1,10,10,2,9,11,2059,10,11,2059,15,1,15,1,0,512]

theorem envBound52702 : H12AffineFastState.Bounded env52702 := by
  intro p hp
  have h : env52702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52701_52702 : H12AffineEnvironment.transform 11 11 env52701 = env52702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env52701 == env52702) = true)

theorem identity52702 : scanCanonicalize (H12AffineFastState.compose env52702 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52702 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52703 : List Nat := [2,4,1,3,2,2,1,7,512,6,2048,2,0,3,2,0,2,2050,7,3,1,3,3,2,0,2,2050,3,2,2050,6,1,6,1,0,512]

theorem envBound52703 : H12AffineFastState.Bounded env52703 := by
  intro p hp
  have h : env52703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52702_52703 : H12AffineEnvironment.transform 2 1 env52702 = env52703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52702 == env52703) = true)

theorem identity52703 : scanCanonicalize (H12AffineFastState.compose env52703 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound52703 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52704 : List Nat := [2,4,1,3,2,2,1,7,512,6,7,2,0,3,2,0,2,5,7,3,1,3,3,2,0,2,5,3,2,5,6,1,6,1,0,512]

theorem envBound52704 : H12AffineFastState.Bounded env52704 := by
  intro p hp
  have h : env52704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52703_52704 : H12AffineEnvironment.transform 10 7 env52703 = env52704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env52703 == env52704) = true)

theorem identity52704 : scanCanonicalize (H12AffineFastState.compose env52704 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52704 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env52705 : List Nat := [1,4,1,0,1,1,1,4,512,5,4,1,0,0,1,0,1,5,4,0,1,0,0,1,0,1,5,0,1,5,5,1,5,1,0,512]

theorem envBound52705 : H12AffineFastState.Bounded env52705 := by
  intro p hp
  have h : env52705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52704_52705 : H12AffineEnvironment.transform 0 1 env52704 = env52705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52704 == env52705) = true)

theorem identity52705 : scanCanonicalize (H12AffineFastState.compose env52705 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound52705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52706 : List Nat := [1,0,1,0,1,1,1,0,512,1,0,1,0,0,1,0,1,1,0,0,1,0,0,1,0,1,1,0,1,1,1,1,1,1,0,512]

theorem envBound52706 : H12AffineFastState.Bounded env52706 := by
  intro p hp
  have h : env52706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52705_52706 : H12AffineEnvironment.transform 1 0 env52705 = env52706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env52705 == env52706) = true)

theorem identity52706 : scanCanonicalize (H12AffineFastState.compose env52706 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52706 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52707 : List Nat := [1,0,1,0,1,1,1,0,0,1,0,1,0,0,1,0,1,1,0,0,1,0,0,1,0,1,1,0,1,1,1,1,1,1,0,0]

theorem envBound52707 : H12AffineFastState.Bounded env52707 := by
  intro p hp
  have h : env52707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52706_52707 : H12AffineEnvironment.transform 8 0 env52706 = env52707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52706 == env52707) = true)

def env52708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,411972,155997,21762,8193,64,215366,79130,140365,283905,214035,485710,257,201831,196886,156493]

theorem envBound52708 : H12AffineFastState.Bounded env52708 := by
  intro p hp
  have h : env52708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52690_52708 : H12AffineEnvironment.transform 6 9 env52690 = env52708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52690 == env52708) = true)

theorem identity52708 : scanCanonicalize (H12AffineFastState.compose env52708 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52708 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env52709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,262144,1025,29789,4161,411972,155997,21762,8193,64,158029,5393,140365,283905,156696,411973,257,144492,139549,156493]

theorem envBound52709 : H12AffineFastState.Bounded env52709 := by
  intro p hp
  have h : env52709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52708_52709 : H12AffineEnvironment.transform 15 8203 env52708 = env52709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52708 == env52709) = true)

theorem identity52709 : scanCanonicalize (H12AffineFastState.compose env52709 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound52709 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,2340,1025,29789,4161,147552,155997,21762,8193,64,158029,5393,140365,23589,156696,147553,257,144492,139549,156493]

theorem envBound52710 : H12AffineFastState.Bounded env52710 := by
  intro p hp
  have h : env52710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52709_52710 : H12AffineEnvironment.transform 17 2340 env52709 = env52710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env52709 == env52710) = true)

theorem identity52710 : scanCanonicalize (H12AffineFastState.compose env52710 (packedSelected [1,7,8,12,14,15,16,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound52710 : packedSelected [1,7,8,12,14,15,16,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env52711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,293,8203,131072,2340,1025,292,4161,144665,136228,8315,8193,64,138292,5393,140365,10588,135521,144664,257,144492,139549,136756]

theorem envBound52711 : H12AffineFastState.Bounded env52711 := by
  intro p hp
  have h : env52711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52710_52711 : H12AffineEnvironment.transform 13 13689 env52710 = env52711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env52710 == env52711) = true)

theorem identity52711 : scanCanonicalize (H12AffineFastState.compose env52711 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(16+1) ^^^ 13641) := by decide +kernel

theorem selectedBound52711 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env52712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,293,8203,13641,2340,1025,292,4161,80,8557,8315,8193,64,10621,5393,4356,10588,9256,81,257,293,5204,9085]

theorem envBound52712 : H12AffineFastState.Bounded env52712 := by
  intro p hp
  have h : env52712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52711_52712 : H12AffineEnvironment.transform 16 13641 env52711 = env52712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13641 env52711 == env52712) = true)

theorem identity52712 : scanCanonicalize (H12AffineFastState.compose env52712 (packedSelected [0,1,3,4,5,6,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52712 : packedSelected [0,1,3,4,5,6,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env52713 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8192,13437,33,8203,13389,2080,1025,32,4161,80,8297,8315,8193,64,10361,5141,4096,10328,9256,81,5,33,5204,8825]

theorem envBound52713 : H12AffineFastState.Bounded env52713 := by
  intro p hp
  have h : env52713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52712_52713 : H12AffineEnvironment.transform 7 4 env52712 = env52713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52712 == env52713) = true)

theorem identity52713 : scanCanonicalize (H12AffineFastState.compose env52713 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52713 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52714 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8192,13357,33,8203,13341,2080,1025,32,4113,0,8249,8235,8193,16,10281,5141,4096,10248,9256,1,5,33,5124,8745]

theorem envBound52714 : H12AffineFastState.Bounded env52714 := by
  intro p hp
  have h : env52714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52713_52714 : H12AffineEnvironment.transform 5 16 env52713 = env52714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52713 == env52714) = true)

theorem identity52714 : scanCanonicalize (H12AffineFastState.compose env52714 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound52714 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52715 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,2088,7173,33,2083,7221,2080,1025,32,4113,0,2065,2051,2089,16,1,5141,4096,32,3072,1,5,33,5124,2561]

theorem envBound52715 : H12AffineFastState.Bounded env52715 := by
  intro p hp
  have h : env52715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52714_52715 : H12AffineEnvironment.transform 12 2088 env52714 = env52715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env52714 == env52715) = true)

theorem identity52715 : scanCanonicalize (H12AffineFastState.compose env52715 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound52715 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env52716 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,3109,2088,32,33,2083,16,2080,1025,32,3124,0,2065,2051,2089,16,1,2096,3109,32,3072,1,5,33,2081,2561]

theorem envBound52716 : H12AffineFastState.Bounded env52716 := by
  intro p hp
  have h : env52716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52715_52716 : H12AffineEnvironment.transform 11 3109 env52715 = env52716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env52715 == env52716) = true)

theorem identity52716 : scanCanonicalize (H12AffineFastState.compose env52716 (packedSelected [4,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52716 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52717 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,3076,2057,1,0,2050,16,2049,1025,1,3093,0,2065,2051,2056,16,1,2065,3076,1,3072,1,5,0,2048,2561]

theorem envBound52717 : H12AffineFastState.Bounded env52717 := by
  intro p hp
  have h : env52717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52716_52717 : H12AffineEnvironment.transform 4 1 env52716 = env52717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52716 == env52717) = true)

theorem identity52717 : scanCanonicalize (H12AffineFastState.compose env52717 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound52717 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env52718 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1044,16,1053,1,0,1046,16,1045,1025,1,1,0,1029,1047,1052,16,1,1029,16,1,20,1,5,0,1044,1557]

theorem envBound52718 : H12AffineFastState.Bounded env52718 := by
  intro p hp
  have h : env52718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52717_52718 : H12AffineEnvironment.transform 10 1044 env52717 = env52718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env52717 == env52718) = true)

def env52719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound52719 : H12AffineFastState.Bounded env52719 := by
  intro p hp
  have h : env52719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52229_52719 : H12AffineEnvironment.transform 26 30393345 env52229 = env52719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env52229 == env52719) = true)

def env52720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound52720 : H12AffineFastState.Bounded env52720 := by
  intro p hp
  have h : env52720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52719_52720 : H12AffineEnvironment.transform 18 1024 env52719 = env52720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env52719 == env52720) = true)

theorem identity52720 : scanCanonicalize (H12AffineFastState.compose env52720 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound52720 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41311,8328,64,13066590,2172370,10507601,8830976,8463695,6407326,256,10577395,10585175,8389273]

theorem envBound52721 : H12AffineFastState.Bounded env52721 := by
  intro p hp
  have h : env52721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52720_52721 : H12AffineEnvironment.transform 23 41311 env52720 = env52721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env52720 == env52721) = true)

def env52722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41311,8192,64,13066590,2172250,10507601,8830976,8463695,6407190,256,10577275,10585175,8389137]

theorem envBound52722 : H12AffineFastState.Bounded env52722 := by
  intro p hp
  have h : env52722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52721_52722 : H12AffineEnvironment.transform 6 8 env52721 = env52722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52721 == env52722) = true)

def env52723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8192,64,4677966,2172250,2118977,442384,75103,6407190,256,2188651,2196551,513]

theorem envBound52723 : H12AffineFastState.Bounded env52723 := by
  intro p hp
  have h : env52723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52722_52723 : H12AffineEnvironment.transform 22 16 env52722 = env52723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52722 == env52723) = true)

def env52724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8192,64,4677966,115014,45405,442384,75103,4268042,256,98679,90203,513]

theorem envBound52724 : H12AffineFastState.Bounded env52724 := by
  intro p hp
  have h : env52724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52723_52724 : H12AffineEnvironment.transform 20 58396 env52723 = env52724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env52723 == env52724) = true)

def env52725 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8192,16,4677918,114966,45325,442384,75023,4268042,256,98599,90123,513]

theorem envBound52725 : H12AffineFastState.Bounded env52725 := by
  intro p hp
  have h : env52725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52724_52725 : H12AffineEnvironment.transform 5 16 env52724 = env52725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52724 == env52725) = true)

def env52726 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8192,16,4409654,114966,45325,190520,75023,4268042,256,98599,90123,513]

theorem envBound52726 : H12AffineFastState.Bounded env52726 := by
  intro p hp
  have h : env52726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52725_52726 : H12AffineEnvironment.transform 17 10280 env52725 = env52726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52725 == env52726) = true)

theorem identity52726 : scanCanonicalize (H12AffineFastState.compose env52726 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118034) := by decide +kernel

theorem selectedBound52726 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env52727 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,118034,16,41231,8192,16,164900,114966,45325,190520,75023,60696,256,98599,90123,513]

theorem envBound52727 : H12AffineFastState.Bounded env52727 := by
  intro p hp
  have h : env52727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52726_52727 : H12AffineEnvironment.transform 21 118034 env52726 = env52727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118034 env52726 == env52727) = true)

theorem identity52727 : scanCanonicalize (H12AffineFastState.compose env52727 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52727 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env52728 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,118034,16,41231,8192,16,123967,114966,45325,100387,75023,60696,256,98599,90123,513]

theorem envBound52728 : H12AffineFastState.Bounded env52728 := by
  intro p hp
  have h : env52728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52727_52728 : H12AffineEnvironment.transform 16 90139 env52727 = env52728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52727 == env52728) = true)

theorem identity52728 : scanCanonicalize (H12AffineFastState.compose env52728 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound52728 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env52729 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,292,32768,65536,74047,10280,1024,32769,42296,101430,16,41231,8192,16,107803,98354,45325,100387,75023,44092,256,98599,74031,513]

theorem envBound52729 : H12AffineFastState.Bounded env52729 := by
  intro p hp
  have h : env52729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52728_52729 : H12AffineEnvironment.transform 13 292 env52728 = env52729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env52728 == env52729) = true)

theorem identity52729 : scanCanonicalize (H12AffineFastState.compose env52729 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52729 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52730 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,292,32768,8202,309,10280,1024,32769,42296,44092,16,41231,8192,16,34065,41016,45325,43049,1285,44092,256,41261,293,513]

theorem envBound52730 : H12AffineFastState.Bounded env52730 := by
  intro p hp
  have h : env52730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52729_52730 : H12AffineEnvironment.transform 15 8202 env52729 = env52730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52729 == env52730) = true)

theorem identity52730 : scanCanonicalize (H12AffineFastState.compose env52730 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound52730 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52731 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,8192,292,32768,8202,309,10280,1024,32769,42296,44092,16,41231,8192,16,34065,41016,41016,43049,1285,44092,256,41261,293,513]

theorem envBound52731 : H12AffineFastState.Bounded env52731 := by
  intro p hp
  have h : env52731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52730_52731 : H12AffineEnvironment.transform 11 309 env52730 = env52731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env52730 == env52731) = true)

theorem identity52731 : scanCanonicalize (H12AffineFastState.compose env52731 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound52731 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env52732 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,1052,292,32768,1046,309,3124,1024,32769,33060,34848,16,34067,1052,16,34065,33828,33828,35893,1285,34848,256,34097,293,513]

theorem envBound52732 : H12AffineFastState.Bounded env52732 := by
  intro p hp
  have h : env52732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52731_52732 : H12AffineEnvironment.transform 12 1052 env52731 = env52732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env52731 == env52732) = true)

theorem identity52732 : scanCanonicalize (H12AffineFastState.compose env52732 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound52732 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env52733 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,1052,292,1077,1046,309,3124,1024,1076,1297,3093,16,294,1052,16,292,17,17,2048,1285,3093,256,260,293,513]

theorem envBound52733 : H12AffineFastState.Bounded env52733 := by
  intro p hp
  have h : env52733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52732_52733 : H12AffineEnvironment.transform 14 1077 env52732 = env52733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env52732 == env52733) = true)

theorem identity52733 : scanCanonicalize (H12AffineFastState.compose env52733 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound52733 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env52734 : List Nat := [2,4,8,16,32,16,8,256,512,1024,17,309,1052,292,1077,1046,309,1061,1024,1076,1297,1028,16,294,1052,16,292,17,17,17,1285,1028,256,260,293,513]

theorem envBound52734 : H12AffineFastState.Bounded env52734 := by
  intro p hp
  have h : env52734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52733_52734 : H12AffineEnvironment.transform 10 17 env52733 = env52734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env52733 == env52734) = true)

theorem identity52734 : scanCanonicalize (H12AffineFastState.compose env52734 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound52734 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52735 : List Nat := [2,4,8,16,32,16,8,256,309,1024,17,309,1052,292,1077,1046,309,1061,1024,1076,1297,1028,16,294,1052,16,292,17,17,17,1285,1028,256,260,293,308]

theorem envBound52735 : H12AffineFastState.Bounded env52735 := by
  intro p hp
  have h : env52735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52734_52735 : H12AffineEnvironment.transform 8 309 env52734 = env52735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env52734 == env52735) = true)

theorem identity52735 : scanCanonicalize (H12AffineFastState.compose env52735 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound52735 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52736 : List Nat := [2,4,8,16,32,16,8,53,0,1024,17,0,1052,17,1077,1046,0,1061,1024,1076,1060,1028,16,19,1052,16,17,17,17,17,1072,1028,53,49,16,1]

theorem envBound52736 : H12AffineFastState.Bounded env52736 := by
  intro p hp
  have h : env52736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52735_52736 : H12AffineEnvironment.transform 7 53 env52735 = env52736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env52735 == env52736) = true)

theorem identity52736 : scanCanonicalize (H12AffineFastState.compose env52736 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52737 : List Nat := [2,4,8,16,32,16,8,53,0,20,17,0,8,17,33,2,0,49,20,32,48,16,16,19,8,16,17,17,17,17,36,16,53,49,16,1]

theorem envBound52737 : H12AffineFastState.Bounded env52737 := by
  intro p hp
  have h : env52737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52736_52737 : H12AffineEnvironment.transform 9 20 env52736 = env52737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52736 == env52737) = true)

theorem identity52737 : scanCanonicalize (H12AffineFastState.compose env52737 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52738 : List Nat := [2,4,8,16,0,16,8,21,0,20,17,0,8,17,1,2,0,17,20,0,16,16,16,19,8,16,17,17,17,17,4,16,21,17,16,1]

theorem envBound52738 : H12AffineFastState.Bounded env52738 := by
  intro p hp
  have h : env52738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52737_52738 : H12AffineEnvironment.transform 4 0 env52737 = env52738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52737 == env52738) = true)

theorem identity52738 : scanCanonicalize (H12AffineFastState.compose env52738 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52739 : List Nat := [2,4,8,0,0,0,8,5,0,4,1,0,8,1,1,2,0,1,4,0,0,0,0,3,8,0,1,1,1,1,4,0,5,1,0,1]

theorem envBound52739 : H12AffineFastState.Bounded env52739 := by
  intro p hp
  have h : env52739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52738_52739 : H12AffineEnvironment.transform 3 0 env52738 = env52739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52738 == env52739) = true)

def env52740 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8192,16,4409655,114966,45325,190521,75023,4268042,256,98599,90123,513]

theorem envBound52740 : H12AffineFastState.Bounded env52740 := by
  intro p hp
  have h : env52740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52725_52740 : H12AffineEnvironment.transform 17 10281 env52725 = env52740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52725 == env52740) = true)

theorem identity52740 : scanCanonicalize (H12AffineFastState.compose env52740 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound52740 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env52741 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,246071,16,41231,8192,16,34816,114966,45325,190521,75023,188733,256,98599,90123,513]

theorem envBound52741 : H12AffineFastState.Bounded env52741 := by
  intro p hp
  have h : env52741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52740_52741 : H12AffineEnvironment.transform 21 246071 env52740 = env52741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env52740 == env52741) = true)

theorem identity52741 : scanCanonicalize (H12AffineFastState.compose env52741 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52741 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env52742 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,65536,131072,10281,1024,0,25629,213302,16,8462,8192,16,2049,82199,12556,157752,75023,155964,256,65830,90123,513]

theorem envBound52742 : H12AffineFastState.Bounded env52742 := by
  intro p hp
  have h : env52742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52741_52742 : H12AffineEnvironment.transform 14 1 env52741 = env52742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52741 == env52742) = true)

theorem identity52742 : scanCanonicalize (H12AffineFastState.compose env52742 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound52742 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52743 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,263,131072,10281,1024,0,25629,147505,16,8462,8192,16,2049,16400,12556,157752,9224,155964,256,33,24844,513]

theorem envBound52743 : H12AffineFastState.Bounded env52743 := by
  intro p hp
  have h : env52743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52742_52743 : H12AffineEnvironment.transform 15 263 env52742 = env52743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env52742 == env52743) = true)

theorem identity52743 : scanCanonicalize (H12AffineFastState.compose env52743 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound52743 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env52744 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,263,16401,10281,1024,0,25629,32,16,8462,8192,16,2049,16400,12556,10281,9224,8493,256,33,24844,513]

theorem envBound52744 : H12AffineFastState.Bounded env52744 := by
  intro p hp
  have h : env52744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52743_52744 : H12AffineEnvironment.transform 16 16401 env52743 = env52744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52743 == env52744) = true)

theorem identity52744 : scanCanonicalize (H12AffineFastState.compose env52744 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52744 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env52745 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,263,16401,2340,1024,0,17680,32,16,3,269,16,2049,16400,4097,2340,1285,32,256,33,16385,513]

theorem envBound52745 : H12AffineFastState.Bounded env52745 := by
  intro p hp
  have h : env52745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52744_52745 : H12AffineEnvironment.transform 12 269 env52744 = env52745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52744 == env52745) = true)

theorem identity52745 : scanCanonicalize (H12AffineFastState.compose env52745 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound52745 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52746 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,4388,1,263,4405,2340,1024,0,5172,32,16,3,269,16,2049,4404,4097,2340,1285,32,256,33,4389,513]

theorem envBound52746 : H12AffineFastState.Bounded env52746 := by
  intro p hp
  have h : env52746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52745_52746 : H12AffineEnvironment.transform 13 4388 env52745 = env52746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env52745 == env52746) = true)

theorem identity52746 : scanCanonicalize (H12AffineFastState.compose env52746 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound52746 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52747 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,512,269,804,1,263,821,2340,1024,0,1588,32,16,3,269,16,2049,820,513,2340,1285,32,256,33,805,513]

theorem envBound52747 : H12AffineFastState.Bounded env52747 := by
  intro p hp
  have h : env52747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52746_52747 : H12AffineEnvironment.transform 11 512 env52746 = env52747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env52746 == env52747) = true)

theorem identity52747 : scanCanonicalize (H12AffineFastState.compose env52747 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound52747 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52748 : List Nat := [2,4,8,16,32,16,8,256,512,769,2048,512,269,804,1,263,821,2340,769,0,309,32,16,3,269,16,2049,820,513,2340,516,32,256,33,805,513]

theorem envBound52748 : H12AffineFastState.Bounded env52748 := by
  intro p hp
  have h : env52748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52747_52748 : H12AffineEnvironment.transform 9 769 env52747 = env52748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env52747 == env52748) = true)

theorem identity52748 : scanCanonicalize (H12AffineFastState.compose env52748 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound52748 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52749 : List Nat := [2,4,8,16,32,16,8,53,512,564,2048,512,56,529,1,50,512,2065,564,0,0,32,16,3,56,16,2049,513,513,2065,516,32,53,33,528,513]

theorem envBound52749 : H12AffineFastState.Bounded env52749 := by
  intro p hp
  have h : env52749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52748_52749 : H12AffineEnvironment.transform 7 53 env52748 = env52749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env52748 == env52749) = true)

theorem identity52749 : scanCanonicalize (H12AffineFastState.compose env52749 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound52749 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52750 : List Nat := [2,4,8,16,32,16,8,53,512,564,17,512,56,529,1,50,512,0,564,0,0,32,16,3,56,16,16,513,513,0,516,32,53,33,528,513]

theorem envBound52750 : H12AffineFastState.Bounded env52750 := by
  intro p hp
  have h : env52750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52749_52750 : H12AffineEnvironment.transform 10 17 env52749 = env52750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env52749 == env52750) = true)

theorem identity52750 : scanCanonicalize (H12AffineFastState.compose env52750 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52751 : List Nat := [2,4,8,16,0,16,8,21,512,532,17,512,24,529,1,18,512,0,532,0,0,0,16,3,24,16,16,513,513,0,516,0,21,1,528,513]

theorem envBound52751 : H12AffineFastState.Bounded env52751 := by
  intro p hp
  have h : env52751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52750_52751 : H12AffineEnvironment.transform 4 0 env52750 = env52751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52750 == env52751) = true)

theorem identity52751 : scanCanonicalize (H12AffineFastState.compose env52751 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52752 : List Nat := [2,4,8,16,0,16,8,21,1,21,17,1,24,16,1,18,1,0,21,0,0,0,16,3,24,16,16,0,0,0,5,0,21,1,17,0]

theorem envBound52752 : H12AffineFastState.Bounded env52752 := by
  intro p hp
  have h : env52752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52751_52752 : H12AffineEnvironment.transform 8 1 env52751 = env52752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52751 == env52752) = true)

def env52753 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8192,17,4677919,114967,45324,442384,75022,4268042,256,98598,90122,513]

theorem envBound52753 : H12AffineFastState.Bounded env52753 := by
  intro p hp
  have h : env52753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52724_52753 : H12AffineEnvironment.transform 5 17 env52724 = env52753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52724 == env52753) = true)

theorem identity52753 : scanCanonicalize (H12AffineFastState.compose env52753 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52753 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env52754 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8192,17,4409654,114967,45324,190521,75022,4268042,256,98598,90122,513]

theorem envBound52754 : H12AffineFastState.Bounded env52754 := by
  intro p hp
  have h : env52754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52753_52754 : H12AffineEnvironment.transform 17 10281 env52753 = env52754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52753 == env52754) = true)

theorem identity52754 : scanCanonicalize (H12AffineFastState.compose env52754 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound52754 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env52755 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58396,4194304,16,41230,8192,17,4385084,24861,45324,190521,34052,4227072,256,8492,49152,513]

theorem envBound52755 : H12AffineFastState.Bounded env52755 := by
  intro p hp
  have h : env52755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52754_52755 : H12AffineEnvironment.transform 15 40970 env52754 = env52755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env52754 == env52755) = true)

theorem identity52755 : scanCanonicalize (H12AffineFastState.compose env52755 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155964) := by decide +kernel

theorem selectedBound52755 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env52756 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58396,155964,16,41230,8192,17,34816,24861,45324,190521,34052,188732,256,8492,49152,513]

theorem envBound52756 : H12AffineFastState.Bounded env52756 := by
  intro p hp
  have h : env52756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52755_52756 : H12AffineEnvironment.transform 21 155964 env52755 = env52756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155964 env52755 == env52756) = true)

theorem identity52756 : scanCanonicalize (H12AffineFastState.compose env52756 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound52756 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52757 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1024,32769,58396,8493,16,41230,8192,17,34816,24861,45324,43048,34052,41261,256,8492,49152,513]

theorem envBound52757 : H12AffineFastState.Bounded env52757 := by
  intro p hp
  have h : env52757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52756_52757 : H12AffineEnvironment.transform 16 16401 env52756 = env52757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52756 == env52757) = true)

def env52758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677966,115015,45404,442384,75103,4268043,256,98678,90202,513]

theorem envBound52758 : H12AffineFastState.Bounded env52758 := by
  intro p hp
  have h : env52758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52723_52758 : H12AffineEnvironment.transform 20 58397 env52723 = env52758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env52723 == env52758) = true)

theorem identity52758 : scanCanonicalize (H12AffineFastState.compose env52758 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52758 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4604229,57676,45404,442384,1364,4194304,256,41341,16465,513]

theorem envBound52759 : H12AffineFastState.Bounded env52759 := by
  intro p hp
  have h : env52759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52758_52759 : H12AffineEnvironment.transform 15 8203 env52758 = env52759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52758 == env52759) = true)

theorem identity52759 : scanCanonicalize (H12AffineFastState.compose env52759 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound52759 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env52760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,419913,16,41311,8192,64,10508,57676,45404,442384,1364,419913,256,41341,16465,513]

theorem envBound52760 : H12AffineFastState.Bounded env52760 := by
  intro p hp
  have h : env52760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52759_52760 : H12AffineEnvironment.transform 21 419913 env52759 = env52760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env52759 == env52760) = true)

def env52761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58397,272393,16,41311,8192,64,10508,57676,45404,294992,1364,272393,256,41341,16465,513]

theorem envBound52761 : H12AffineFastState.Bounded env52761 := by
  intro p hp
  have h : env52761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52760_52761 : H12AffineEnvironment.transform 16 16448 env52760 = env52761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env52760 == env52761) = true)

theorem identity52761 : scanCanonicalize (H12AffineFastState.compose env52761 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52761 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16448,262144,1024,8541,17729,272393,16,3,8192,64,10508,16400,4096,270604,1364,272393,256,33,16465,513]

theorem envBound52762 : H12AffineFastState.Bounded env52762 := by
  intro p hp
  have h : env52762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52761_52762 : H12AffineEnvironment.transform 14 8540 env52761 = env52762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52761 == env52762) = true)

theorem identity52762 : scanCanonicalize (H12AffineFastState.compose env52762 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound52762 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16448,2420,1024,8541,17729,8573,16,3,8192,64,10508,16400,4096,10360,1364,8573,256,33,16465,513]

theorem envBound52763 : H12AffineFastState.Bounded env52763 := by
  intro p hp
  have h : env52763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52762_52763 : H12AffineEnvironment.transform 17 2420 env52762 = env52763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env52762 == env52763) = true)

theorem identity52763 : scanCanonicalize (H12AffineFastState.compose env52763 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound52763 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env52764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,8203,4176,2420,1024,8541,5457,8573,16,3,8192,64,10508,4096,4096,10360,1364,8573,256,33,4161,513]

theorem envBound52764 : H12AffineFastState.Bounded env52764 := by
  intro p hp
  have h : env52764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52763_52764 : H12AffineEnvironment.transform 13 4112 env52763 = env52764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env52763 == env52764) = true)

theorem identity52764 : scanCanonicalize (H12AffineFastState.compose env52764 (packedSelected [1,4,8,9,10,11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52764 : packedSelected [1,4,8,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env52765 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,8460,8203,4096,2340,1024,8461,5377,8493,16,3,8192,16,10508,4096,4096,10280,1284,8493,256,33,4113,513]

theorem envBound52765 : H12AffineFastState.Bounded env52765 := by
  intro p hp
  have h : env52765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52764_52765 : H12AffineEnvironment.transform 5 16 env52764 = env52765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52764 == env52765) = true)

theorem identity52765 : scanCanonicalize (H12AffineFastState.compose env52765 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52766 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8192,4112,8201,8203,4096,2081,1024,8200,5124,8232,16,3,8192,16,10249,4096,4096,10280,1025,8232,5,33,4113,513]

theorem envBound52766 : H12AffineFastState.Bounded env52766 := by
  intro p hp
  have h : env52766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52765_52766 : H12AffineEnvironment.transform 7 5 env52765 = env52766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52765 == env52766) = true)

theorem identity52766 : scanCanonicalize (H12AffineFastState.compose env52766 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound52766 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52767 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,1084,4112,1077,1079,4096,2081,1024,1076,5124,1044,16,3,1084,16,3125,4096,4096,3092,1025,1044,5,33,4113,513]

theorem envBound52767 : H12AffineFastState.Bounded env52767 := by
  intro p hp
  have h : env52767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52766_52767 : H12AffineEnvironment.transform 12 1084 env52766 = env52767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env52766 == env52767) = true)

theorem identity52767 : scanCanonicalize (H12AffineFastState.compose env52767 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52767 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env52768 : List Nat := [2,4,8,16,32,16,8,5,16,1024,2048,4096,1084,4112,1077,1079,4096,2081,1024,1076,5124,1044,16,3,1084,16,3125,4096,4096,3092,1025,1044,5,33,4113,17]

theorem envBound52768 : H12AffineFastState.Bounded env52768 := by
  intro p hp
  have h : env52768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52767_52768 : H12AffineEnvironment.transform 8 16 env52767 = env52768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52767 == env52768) = true)

def env52769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58397,272392,16,41311,8192,64,10508,57676,45404,294993,1364,272392,256,41341,16465,513]

theorem envBound52769 : H12AffineFastState.Bounded env52769 := by
  intro p hp
  have h : env52769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52760_52769 : H12AffineEnvironment.transform 16 16449 env52760 = env52769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env52760 == env52769) = true)

theorem identity52769 : scanCanonicalize (H12AffineFastState.compose env52769 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound52769 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8203,16449,262144,1024,80,25676,272392,16,8462,8192,64,10508,24861,12557,262144,1364,272392,256,8492,16465,513]

theorem envBound52770 : H12AffineFastState.Bounded env52770 := by
  intro p hp
  have h : env52770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52769_52770 : H12AffineEnvironment.transform 14 81 env52769 = env52770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env52769 == env52770) = true)

theorem identity52770 : scanCanonicalize (H12AffineFastState.compose env52770 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound52770 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env52771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8203,16449,2420,1024,80,25676,8572,16,8462,8192,64,10508,24861,12557,2420,1364,8572,256,8492,16465,513]

theorem envBound52771 : H12AffineFastState.Bounded env52771 := by
  intro p hp
  have h : env52771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52770_52771 : H12AffineEnvironment.transform 17 2420 env52770 = env52771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env52770 == env52771) = true)

theorem identity52771 : scanCanonicalize (H12AffineFastState.compose env52771 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52771 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,342,16449,2420,1024,80,17681,33,16,83,349,64,2129,16448,4176,2420,1364,33,256,113,16465,513]

theorem envBound52772 : H12AffineFastState.Bounded env52772 := by
  intro p hp
  have h : env52772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52771_52772 : H12AffineEnvironment.transform 12 349 env52771 = env52772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52771 == env52772) = true)

theorem identity52772 : scanCanonicalize (H12AffineFastState.compose env52772 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52772 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52773 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16400,2341,1024,1,17681,33,16,2,268,17,2048,16401,4097,2341,1285,33,256,32,16384,513]

theorem envBound52773 : H12AffineFastState.Bounded env52773 := by
  intro p hp
  have h : env52773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52772_52773 : H12AffineEnvironment.transform 5 17 env52772 = env52773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52772 == env52773) = true)

theorem identity52773 : scanCanonicalize (H12AffineFastState.compose env52773 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound52773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52774 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5156,0,263,5172,2341,1024,1,4405,33,16,2,268,17,2048,5173,4097,2341,1285,33,256,32,5156,513]

theorem envBound52774 : H12AffineFastState.Bounded env52774 := by
  intro p hp
  have h : env52774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52773_52774 : H12AffineEnvironment.transform 13 5156 env52773 = env52774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env52773 == env52774) = true)

def env52775 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2836,0,263,2820,2341,1024,1,3589,33,16,2,268,17,2048,2821,3889,2341,1285,33,256,32,2836,513]

theorem envBound52775 : H12AffineFastState.Bounded env52775 := by
  intro p hp
  have h : env52775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52774_52775 : H12AffineEnvironment.transform 11 3888 env52774 = env52775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env52774 == env52775) = true)

def env52776 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1044,0,263,1028,1573,1024,1,261,33,16,2,268,17,1792,1029,49,1573,1285,33,256,32,1044,513]

theorem envBound52776 : H12AffineFastState.Bounded env52776 := by
  intro p hp
  have h : env52776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52775_52776 : H12AffineEnvironment.transform 10 1792 env52775 = env52776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env52775 == env52776) = true)

theorem identity52776 : scanCanonicalize (H12AffineFastState.compose env52776 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound52776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52777 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1077,48,268,1044,0,263,1028,1296,1024,1,261,33,16,2,268,17,1077,1029,49,1296,1285,33,256,32,1044,308]

theorem envBound52777 : H12AffineFastState.Bounded env52777 := by
  intro p hp
  have h : env52777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52776_52777 : H12AffineEnvironment.transform 8 309 env52776 = env52777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env52776 == env52777) = true)

def env52778 : List Nat := [2,4,8,16,32,17,8,256,309,52,1,48,268,32,0,263,48,292,52,1,261,33,16,2,268,17,1,49,49,292,305,33,256,32,32,308]

theorem envBound52778 : H12AffineFastState.Bounded env52778 := by
  intro p hp
  have h : env52778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52777_52778 : H12AffineEnvironment.transform 9 52 env52777 = env52778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52777 == env52778) = true)

theorem identity52778 : scanCanonicalize (H12AffineFastState.compose env52778 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52779 : List Nat := [2,4,8,16,1,17,8,256,276,21,1,17,268,1,0,263,17,261,21,1,261,0,16,2,268,17,1,16,16,261,272,0,256,1,1,277]

theorem envBound52779 : H12AffineFastState.Bounded env52779 := by
  intro p hp
  have h : env52779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52778_52779 : H12AffineEnvironment.transform 4 1 env52778 = env52779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52778 == env52779) = true)

def leafEnv52779 : List Nat := [2,4,8,16,1,17,8,256,276,21,1,17,268,1,0,263,17,261,21,1,261,0,16,2,272,268,1,17,1,16,16,261,272,0,256,1,4,263,1,277,1,261,0]

def active52779 : List Nat := [0,1,2,3,7]

def tree52779 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52779 : H12WitnessSearch.Good tree52779 := H12GlobalWitnessIndex.good

theorem leafIdentity52779 : H12AffineFastState.composeSystem env52779 rootObs = leafEnv52779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52779 rootObs == leafEnv52779) = true)

theorem terminalChecked52779 : H12PackedTerminal.terminalCheckFast leafEnv52779 active52779 tree52779 = true := by decide +kernel

def env52780 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,268,33,0,263,49,293,53,1,261,33,16,2,268,17,0,48,49,293,304,33,256,32,33,308]

theorem envBound52780 : H12AffineFastState.Bounded env52780 := by
  intro p hp
  have h : env52780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52777_52780 : H12AffineEnvironment.transform 9 53 env52777 = env52780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52777 == env52780) = true)

theorem identity52780 : scanCanonicalize (H12AffineFastState.compose env52780 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52780 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52781 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,268,33,0,263,42,293,46,1,261,33,11,2,268,10,0,43,42,293,299,33,256,32,33,303]

theorem envBound52781 : H12AffineFastState.Bounded env52781 := by
  intro p hp
  have h : env52781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52780_52781 : H12AffineEnvironment.transform 3 11 env52780 = env52781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52780 == env52781) = true)

def leafEnv52781 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,268,33,0,263,42,293,46,1,261,33,11,2,299,268,1,10,0,43,42,293,299,33,256,32,4,263,33,303,1,261,0]

def active52781 : List Nat := [0,1,2,4,7]

def tree52781 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52781 : H12WitnessSearch.Good tree52781 := H12GlobalWitnessIndex.good

theorem leafIdentity52781 : H12AffineFastState.composeSystem env52781 rootObs = leafEnv52781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52781 rootObs == leafEnv52781) = true)

theorem terminalChecked52781 : H12PackedTerminal.terminalCheckFast leafEnv52781 active52781 tree52781 = true := by decide +kernel

def env52782 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1045,0,263,1029,1572,1024,1,260,33,16,2,268,17,1793,1028,48,1572,1285,33,256,32,1045,513]

theorem envBound52782 : H12AffineFastState.Bounded env52782 := by
  intro p hp
  have h : env52782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52775_52782 : H12AffineEnvironment.transform 10 1793 env52775 = env52782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env52775 == env52782) = true)

theorem identity52782 : scanCanonicalize (H12AffineFastState.compose env52782 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound52782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52783 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,49,268,561,0,263,545,0,548,1,260,33,16,2,268,17,293,544,48,0,801,33,256,32,561,513]

theorem envBound52783 : H12AffineFastState.Bounded env52783 := by
  intro p hp
  have h : env52783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52782_52783 : H12AffineEnvironment.transform 9 548 env52782 = env52783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env52782 == env52783) = true)

def env52784 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,268,33,0,263,49,0,52,1,260,33,16,2,268,17,293,48,48,0,305,33,256,32,33,17]

theorem envBound52784 : H12AffineFastState.Bounded env52784 := by
  intro p hp
  have h : env52784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52783_52784 : H12AffineEnvironment.transform 8 16 env52783 = env52784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52783 == env52784) = true)

theorem identity52784 : scanCanonicalize (H12AffineFastState.compose env52784 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52785 : List Nat := [2,4,8,16,32,17,8,4,16,52,33,49,8,33,0,3,49,0,52,1,0,33,16,2,8,17,33,48,48,0,53,33,4,32,33,17]

theorem envBound52785 : H12AffineFastState.Bounded env52785 := by
  intro p hp
  have h : env52785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52784_52785 : H12AffineEnvironment.transform 7 4 env52784 = env52785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52784 == env52785) = true)

def leafEnv52785 : List Nat := [2,4,8,16,32,17,8,4,16,52,33,49,8,33,0,3,49,0,52,1,0,33,16,2,53,8,1,17,33,48,48,0,53,33,4,32,4,3,33,17,1,0,0]

def active52785 : List Nat := [0,1,2,3,4]

def tree52785 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52785 : H12WitnessSearch.Good tree52785 := H12GlobalWitnessIndex.good

theorem leafIdentity52785 : H12AffineFastState.composeSystem env52785 rootObs = leafEnv52785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52785 rootObs == leafEnv52785) = true)

theorem terminalChecked52785 : H12PackedTerminal.terminalCheckFast leafEnv52785 active52785 tree52785 = true := by decide +kernel

def env52786 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,49,268,32,0,263,48,0,53,1,260,33,16,2,268,17,293,49,48,0,304,33,256,32,32,16]

theorem envBound52786 : H12AffineFastState.Bounded env52786 := by
  intro p hp
  have h : env52786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52783_52786 : H12AffineEnvironment.transform 8 17 env52783 = env52786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52783 == env52786) = true)

theorem identity52786 : scanCanonicalize (H12AffineFastState.compose env52786 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52786 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52787 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,268,32,0,263,42,0,47,1,260,33,10,2,268,11,293,43,42,0,298,33,256,32,32,10]

theorem envBound52787 : H12AffineFastState.Bounded env52787 := by
  intro p hp
  have h : env52787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52786_52787 : H12AffineEnvironment.transform 3 10 env52786 = env52787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52786 == env52787) = true)

def leafEnv52787 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,268,32,0,263,42,0,47,1,260,33,10,2,298,268,1,11,293,43,42,0,298,33,256,32,4,263,32,10,1,260,0]

def active52787 : List Nat := [0,1,2,4,7]

def tree52787 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52787 : H12WitnessSearch.Good tree52787 := H12GlobalWitnessIndex.good

theorem leafIdentity52787 : H12AffineFastState.composeSystem env52787 rootObs = leafEnv52787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52787 rootObs == leafEnv52787) = true)

theorem terminalChecked52787 : H12PackedTerminal.terminalCheckFast leafEnv52787 active52787 tree52787 = true := by decide +kernel

def env52788 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2837,0,263,2821,2341,1024,1,3588,33,16,2,268,17,2048,2820,3888,2341,1285,33,256,32,2837,513]

theorem envBound52788 : H12AffineFastState.Bounded env52788 := by
  intro p hp
  have h : env52788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52774_52788 : H12AffineEnvironment.transform 11 3889 env52774 = env52788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env52774 == env52788) = true)

def env52789 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1045,0,263,1029,1573,1024,1,260,33,16,2,268,17,1792,1028,48,1573,1285,33,256,32,1045,513]

theorem envBound52789 : H12AffineFastState.Bounded env52789 := by
  intro p hp
  have h : env52789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52788_52789 : H12AffineEnvironment.transform 10 1792 env52788 = env52789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env52788 == env52789) = true)

theorem identity52789 : scanCanonicalize (H12AffineFastState.compose env52789 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound52789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52790 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,49,268,789,0,263,773,293,768,1,260,33,16,2,268,17,0,772,48,293,517,33,256,32,789,513]

theorem envBound52790 : H12AffineFastState.Bounded env52790 := by
  intro p hp
  have h : env52790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52789_52790 : H12AffineEnvironment.transform 9 768 env52789 = env52790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env52789 == env52790) = true)

def env52791 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,268,33,0,263,49,293,52,1,260,33,16,2,268,17,0,48,48,293,305,33,256,32,33,309]

theorem envBound52791 : H12AffineFastState.Bounded env52791 := by
  intro p hp
  have h : env52791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52790_52791 : H12AffineEnvironment.transform 8 308 env52790 = env52791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env52790 == env52791) = true)

theorem identity52791 : scanCanonicalize (H12AffineFastState.compose env52791 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52792 : List Nat := [2,4,8,16,1,17,8,256,277,21,0,16,268,0,0,263,16,260,21,1,260,0,16,2,268,17,0,17,17,260,272,0,256,1,0,276]

theorem envBound52792 : H12AffineFastState.Bounded env52792 := by
  intro p hp
  have h : env52792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52791_52792 : H12AffineEnvironment.transform 4 1 env52791 = env52792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52791 == env52792) = true)

def leafEnv52792 : List Nat := [2,4,8,16,1,17,8,256,277,21,0,16,268,0,0,263,16,260,21,1,260,0,16,2,272,268,1,17,0,17,17,260,272,0,256,1,4,263,0,276,1,260,0]

def active52792 : List Nat := [0,1,2,3,7]

def tree52792 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52792 : H12WitnessSearch.Good tree52792 := H12GlobalWitnessIndex.good

theorem leafIdentity52792 : H12AffineFastState.composeSystem env52792 rootObs = leafEnv52792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52792 rootObs == leafEnv52792) = true)

theorem terminalChecked52792 : H12PackedTerminal.terminalCheckFast leafEnv52792 active52792 tree52792 = true := by decide +kernel

def env52793 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,49,268,32,0,263,48,293,53,1,260,33,16,2,268,17,0,49,48,293,304,33,256,32,32,308]

theorem envBound52793 : H12AffineFastState.Bounded env52793 := by
  intro p hp
  have h : env52793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52790_52793 : H12AffineEnvironment.transform 8 309 env52790 = env52793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env52790 == env52793) = true)

theorem identity52793 : scanCanonicalize (H12AffineFastState.compose env52793 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52794 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,268,32,0,263,43,293,46,1,260,33,11,2,268,10,0,42,43,293,299,33,256,32,32,303]

theorem envBound52794 : H12AffineFastState.Bounded env52794 := by
  intro p hp
  have h : env52794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52793_52794 : H12AffineEnvironment.transform 3 11 env52793 = env52794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52793 == env52794) = true)

def leafEnv52794 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,268,32,0,263,43,293,46,1,260,33,11,2,299,268,1,10,0,42,43,293,299,33,256,32,4,263,32,303,1,260,0]

def active52794 : List Nat := [0,1,2,4,7]

def tree52794 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52794 : H12WitnessSearch.Good tree52794 := H12GlobalWitnessIndex.good

theorem leafIdentity52794 : H12AffineFastState.composeSystem env52794 rootObs = leafEnv52794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52794 rootObs == leafEnv52794) = true)

theorem terminalChecked52794 : H12PackedTerminal.terminalCheckFast leafEnv52794 active52794 tree52794 = true := by decide +kernel

def env52795 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1044,0,263,1028,1572,1024,1,261,33,16,2,268,17,1793,1029,49,1572,1285,33,256,32,1044,513]

theorem envBound52795 : H12AffineFastState.Bounded env52795 := by
  intro p hp
  have h : env52795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52788_52795 : H12AffineEnvironment.transform 10 1793 env52788 = env52795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env52788 == env52795) = true)

theorem identity52795 : scanCanonicalize (H12AffineFastState.compose env52795 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound52795 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52796 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1296,48,268,1044,0,263,1028,1077,1024,1,261,33,16,2,268,17,1296,1029,49,1077,1285,33,256,32,1044,16]

theorem envBound52796 : H12AffineFastState.Bounded env52796 := by
  intro p hp
  have h : env52796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52795_52796 : H12AffineEnvironment.transform 8 17 env52795 = env52796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52795 == env52796) = true)

def env52797 : List Nat := [2,4,8,16,32,17,8,256,17,52,292,48,268,32,0,263,48,1,52,1,261,33,16,2,268,17,292,49,49,1,305,33,256,32,32,16]

theorem envBound52797 : H12AffineFastState.Bounded env52797 := by
  intro p hp
  have h : env52797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52796_52797 : H12AffineEnvironment.transform 9 52 env52796 = env52797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52796 == env52797) = true)

theorem identity52797 : scanCanonicalize (H12AffineFastState.compose env52797 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52798 : List Nat := [2,4,8,16,32,17,8,4,17,52,32,48,8,32,0,3,48,1,52,1,1,33,16,2,8,17,32,49,49,1,53,33,4,32,32,16]

theorem envBound52798 : H12AffineFastState.Bounded env52798 := by
  intro p hp
  have h : env52798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52797_52798 : H12AffineEnvironment.transform 7 4 env52797 = env52798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52797 == env52798) = true)

def leafEnv52798 : List Nat := [2,4,8,16,32,17,8,4,17,52,32,48,8,32,0,3,48,1,52,1,1,33,16,2,53,8,1,17,32,49,49,1,53,33,4,32,4,3,32,16,1,1,0]

def active52798 : List Nat := [0,1,2,3,4]

def tree52798 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52798 : H12WitnessSearch.Good tree52798 := H12GlobalWitnessIndex.good

theorem leafIdentity52798 : H12AffineFastState.composeSystem env52798 rootObs = leafEnv52798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52798 rootObs == leafEnv52798) = true)

theorem terminalChecked52798 : H12PackedTerminal.terminalCheckFast leafEnv52798 active52798 tree52798 = true := by decide +kernel

def env52799 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,268,33,0,263,49,0,53,1,261,33,16,2,268,17,293,48,49,0,304,33,256,32,33,16]

theorem envBound52799 : H12AffineFastState.Bounded env52799 := by
  intro p hp
  have h : env52799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52796_52799 : H12AffineEnvironment.transform 9 53 env52796 = env52799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52796 == env52799) = true)

theorem identity52799 : scanCanonicalize (H12AffineFastState.compose env52799 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52799 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52800 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,268,33,0,263,43,0,47,1,261,33,10,2,268,11,293,42,43,0,298,33,256,32,33,10]

theorem envBound52800 : H12AffineFastState.Bounded env52800 := by
  intro p hp
  have h : env52800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52799_52800 : H12AffineEnvironment.transform 3 10 env52799 = env52800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52799 == env52800) = true)

def leafEnv52800 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,268,33,0,263,43,0,47,1,261,33,10,2,298,268,1,11,293,42,43,0,298,33,256,32,4,263,33,10,1,261,0]

def active52800 : List Nat := [0,1,2,4,7]

def tree52800 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52800 : H12WitnessSearch.Good tree52800 := H12GlobalWitnessIndex.good

theorem leafIdentity52800 : H12AffineFastState.composeSystem env52800 rootObs = leafEnv52800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52800 rootObs == leafEnv52800) = true)

theorem terminalChecked52800 : H12PackedTerminal.terminalCheckFast leafEnv52800 active52800 tree52800 = true := by decide +kernel

def env52801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8192,64,4677967,2172250,2118976,442385,75102,6407190,256,2188650,2196550,512]

theorem envBound52801 : H12AffineFastState.Bounded env52801 := by
  intro p hp
  have h : env52801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52722_52801 : H12AffineEnvironment.transform 22 17 env52722 = env52801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52722 == env52801) = true)

theorem identity52801 : scanCanonicalize (H12AffineFastState.compose env52801 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 314689) := by decide +kernel

theorem selectedBound52801 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,314689,4194304,17,41311,8192,64,4677967,387099,301057,442385,75102,4524375,256,370731,346375,512]

theorem envBound52802 : H12AffineFastState.Bounded env52802 := by
  intro p hp
  have h : env52802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52801_52802 : H12AffineEnvironment.transform 20 314689 env52801 = env52802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314689 env52801 == env52802) = true)

theorem identity52802 : scanCanonicalize (H12AffineFastState.compose env52802 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52802 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env52803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58728,4194304,17,41311,8192,64,4409702,114738,45096,190520,75102,4268414,256,98306,90414,512]

theorem envBound52803 : H12AffineFastState.Bounded env52803 := by
  intro p hp
  have h : env52803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52802_52803 : H12AffineEnvironment.transform 17 10281 env52802 = env52803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52802 == env52803) = true)

theorem identity52803 : scanCanonicalize (H12AffineFastState.compose env52803 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 246119) := by decide +kernel

theorem selectedBound52803 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env52804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58728,246119,17,41311,8192,64,34817,114738,45096,190520,75102,188441,256,98306,90414,512]

theorem envBound52804 : H12AffineFastState.Bounded env52804 := by
  intro p hp
  have h : env52804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52803_52804 : H12AffineEnvironment.transform 21 246119 env52803 = env52804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246119 env52803 == env52804) = true)

theorem identity52804 : scanCanonicalize (H12AffineFastState.compose env52804 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound52804 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,58728,73770,17,41311,8192,64,34817,114738,45096,2421,75102,340,256,98306,90414,512]

theorem envBound52805 : H12AffineFastState.Bounded env52805 := by
  intro p hp
  have h : env52805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52804_52805 : H12AffineEnvironment.transform 16 57677 env52804 = env52805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env52804 == env52805) = true)

theorem identity52805 : scanCanonicalize (H12AffineFastState.compose env52805 (packedSelected [0,3,5,6,7,10,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 9276) := by decide +kernel

theorem selectedBound52805 : packedSelected [0,3,5,6,7,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env52806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9276,32768,65536,34161,10281,1024,32769,33108,73770,17,41311,8192,64,34817,107534,45096,2421,75102,340,256,98306,66834,512]

theorem envBound52806 : H12AffineFastState.Bounded env52806 := by
  intro p hp
  have h : env52806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52805_52806 : H12AffineEnvironment.transform 13 9276 env52805 = env52806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9276 env52805 == env52806) = true)

theorem identity52806 : scanCanonicalize (H12AffineFastState.compose env52806 (packedSelected [0,1,2,6,7,8,11,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound52806 : packedSelected [0,1,2,6,7,8,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env52807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9276,32768,8574,34161,10281,1024,32769,33108,340,17,41311,8192,64,34817,34160,45096,2421,1056,340,256,41340,9324,512]

theorem envBound52807 : H12AffineFastState.Bounded env52807 := by
  intro p hp
  have h : env52807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52806_52807 : H12AffineEnvironment.transform 15 8574 env52806 = env52807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env52806 == env52807) = true)

theorem identity52807 : scanCanonicalize (H12AffineFastState.compose env52807 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 14360) := by decide +kernel

theorem selectedBound52807 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env52808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9276,14360,8574,15721,10281,1024,14361,14668,340,17,6471,8192,64,12313,15720,2096,2421,1056,340,256,6500,9324,512]

theorem envBound52808 : H12AffineFastState.Bounded env52808 := by
  intro p hp
  have h : env52808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52807_52808 : H12AffineEnvironment.transform 14 14360 env52807 = env52808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14360 env52807 == env52808) = true)

theorem identity52808 : scanCanonicalize (H12AffineFastState.compose env52808 (packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound52808 : packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env52809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2168,3140,4192,2310,5393,81,1024,4193,4404,340,17,6471,2168,64,6241,5392,2096,2421,1056,340,256,6500,3092,512]

theorem envBound52809 : H12AffineFastState.Bounded env52809 := by
  intro p hp
  have h : env52809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52808_52809 : H12AffineEnvironment.transform 12 2168 env52808 = env52809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env52808 == env52809) = true)

theorem identity52809 : scanCanonicalize (H12AffineFastState.compose env52809 (packedSelected [2,4,9,20] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52809 : packedSelected [2,4,9,20] rootPS < 2^1333 := by decide +kernel

def env52810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,1385,341,4192,1047,5393,81,1024,4193,4404,340,17,5206,1385,64,5488,5392,1313,1124,1056,340,256,5237,261,512]

theorem envBound52810 : H12AffineFastState.Bounded env52810 := by
  intro p hp
  have h : env52810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52809_52810 : H12AffineEnvironment.transform 10 1297 env52809 = env52810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env52809 == env52810) = true)

theorem identity52810 : scanCanonicalize (H12AffineFastState.compose env52810 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52810 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env52811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,1029,1385,341,1125,1047,276,81,1024,1124,1329,340,17,83,1385,64,373,277,1313,1124,1056,340,256,112,261,512]

theorem envBound52811 : H12AffineFastState.Bounded env52811 := by
  intro p hp
  have h : env52811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52810_52811 : H12AffineEnvironment.transform 11 1029 env52810 = env52811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52810 == env52811) = true)

theorem identity52811 : scanCanonicalize (H12AffineFastState.compose env52811 (packedSelected [1,3,5,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound52811 : packedSelected [1,3,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52812 : List Nat := [2,4,8,16,32,64,8,256,512,101,372,96,268,341,0,114,276,81,101,1,340,340,17,83,268,64,373,277,324,1,69,340,256,112,261,512]

theorem envBound52812 : H12AffineFastState.Bounded env52812 := by
  intro p hp
  have h : env52812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52811_52812 : H12AffineEnvironment.transform 9 101 env52811 = env52812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env52811 == env52812) = true)

theorem identity52812 : scanCanonicalize (H12AffineFastState.compose env52812 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52812 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52813 : List Nat := [2,4,8,16,0,64,8,256,512,69,340,64,268,341,0,82,276,81,69,1,340,340,17,83,268,64,341,277,324,1,69,340,256,80,261,512]

theorem envBound52813 : H12AffineFastState.Bounded env52813 := by
  intro p hp
  have h : env52813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52812_52813 : H12AffineEnvironment.transform 4 0 env52812 = env52813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52812 == env52813) = true)

theorem identity52813 : scanCanonicalize (H12AffineFastState.compose env52813 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound52813 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52814 : List Nat := [2,4,8,16,0,64,8,84,512,69,0,64,88,1,0,82,64,81,69,1,0,0,17,83,88,64,1,65,16,1,69,0,84,80,81,512]

theorem envBound52814 : H12AffineFastState.Bounded env52814 := by
  intro p hp
  have h : env52814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52813_52814 : H12AffineEnvironment.transform 7 84 env52813 = env52814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env52813 == env52814) = true)

theorem identity52814 : scanCanonicalize (H12AffineFastState.compose env52814 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52814 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52815 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,0,3,17,0,20,1,0,0,17,2,9,17,1,16,16,1,20,0,5,1,0,512]

theorem envBound52815 : H12AffineFastState.Bounded env52815 := by
  intro p hp
  have h : env52815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52814_52815 : H12AffineEnvironment.transform 5 17 env52814 = env52815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52814 == env52815) = true)

theorem identity52815 : scanCanonicalize (H12AffineFastState.compose env52815 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52816 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,17,9,1,0,3,17,0,20,1,0,0,17,2,9,17,1,16,16,1,20,0,5,1,0,0]

theorem envBound52816 : H12AffineFastState.Bounded env52816 := by
  intro p hp
  have h : env52816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52815_52816 : H12AffineEnvironment.transform 8 0 env52815 = env52816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52815 == env52816) = true)

theorem identity52816 : scanCanonicalize (H12AffineFastState.compose env52816 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound52816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52817 : List Nat := [2,4,6,16,0,17,6,5,0,20,0,17,7,1,0,3,17,0,20,1,0,0,17,2,7,17,1,16,16,1,20,0,5,1,0,0]

theorem envBound52817 : H12AffineFastState.Bounded env52817 := by
  intro p hp
  have h : env52817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52816_52817 : H12AffineEnvironment.transform 2 6 env52816 = env52817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env52816 == env52817) = true)

def env52818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41311,8193,64,13066590,2172251,10507601,8830976,8463695,6407191,256,10577274,10585175,8389136]

theorem envBound52818 : H12AffineFastState.Bounded env52818 := by
  intro p hp
  have h : env52818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52721_52818 : H12AffineEnvironment.transform 6 9 env52721 = env52818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52721 == env52818) = true)

def env52819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8193,64,4677966,2172251,2118977,442384,75103,6407191,256,2188650,2196551,512]

theorem envBound52819 : H12AffineFastState.Bounded env52819 := by
  intro p hp
  have h : env52819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52818_52819 : H12AffineEnvironment.transform 22 16 env52818 = env52819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52818 == env52819) = true)

theorem identity52819 : scanCanonicalize (H12AffineFastState.compose env52819 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 503130) := by decide +kernel

theorem selectedBound52819 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,503130,4194304,16,41311,8193,64,4677966,428033,522267,442384,75103,4614477,256,444464,403741,512]

theorem envBound52820 : H12AffineFastState.Bounded env52820 := by
  intro p hp
  have h : env52820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52819_52820 : H12AffineEnvironment.transform 20 503130 env52819 = env52820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 503130 env52819 == env52820) = true)

theorem identity52820 : scanCanonicalize (H12AffineFastState.compose env52820 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52820 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env52821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,461831,4194304,16,2,8193,64,4677966,403804,481606,418125,75103,4614477,256,420205,403741,512]

theorem envBound52821 : H12AffineFastState.Bounded env52821 := by
  intro p hp
  have h : env52821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52820_52821 : H12AffineEnvironment.transform 14 8541 env52820 = env52821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52820 == env52821) = true)

theorem identity52821 : scanCanonicalize (H12AffineFastState.compose env52821 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 330070) := by decide +kernel

theorem selectedBound52821 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,461831,330070,16,2,8193,64,157720,403804,481606,418125,75103,221211,256,420205,403741,512]

theorem envBound52822 : H12AffineFastState.Bounded env52822 := by
  intro p hp
  have h : env52822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52821_52822 : H12AffineEnvironment.transform 21 330070 env52821 = env52822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 330070 env52821 == env52822) = true)

theorem identity52822 : scanCanonicalize (H12AffineFastState.compose env52822 (packedSelected [9,14,22] rootPS)) = affineNative (2^(17+1) ^^^ 67959) := by decide +kernel

theorem selectedBound52822 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env52823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,67959,1024,8540,132464,33,16,2,8193,64,157720,204843,151601,223290,75103,221211,256,221210,204906,512]

theorem envBound52823 : H12AffineFastState.Bounded env52823 := by
  intro p hp
  have h : env52823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52822_52823 : H12AffineEnvironment.transform 17 67959 env52822 = env52823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67959 env52822 == env52823) = true)

theorem identity52823 : scanCanonicalize (H12AffineFastState.compose env52823 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound52823 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env52824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,67959,1024,8540,17761,33,16,2,8193,64,10249,90170,4128,75819,75103,73738,256,73739,90235,512]

theorem envBound52824 : H12AffineFastState.Bounded env52824 := by
  intro p hp
  have h : env52824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52823_52824 : H12AffineEnvironment.transform 16 16401 env52823 = env52824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52823 == env52824) = true)

theorem identity52824 : scanCanonicalize (H12AffineFastState.compose env52824 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound52824 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env52825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,16401,23841,1024,8540,17761,33,16,2,8193,64,10249,13420,4128,31869,28937,29788,256,29789,13357,512]

theorem envBound52825 : H12AffineFastState.Bounded env52825 := by
  intro p hp
  have h : env52825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52824_52825 : H12AffineEnvironment.transform 15 21590 env52824 = env52825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env52824 == env52825) = true)

theorem identity52825 : scanCanonicalize (H12AffineFastState.compose env52825 (packedSelected [3,5,6,10,12,14,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52825 : packedSelected [3,5,6,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env52826 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8313,21590,16401,23557,1024,8312,17477,33,16,2,8193,64,10249,13420,4128,31869,28717,29788,36,29789,13357,512]

theorem envBound52826 : H12AffineFastState.Bounded env52826 := by
  intro p hp
  have h : env52826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52825_52826 : H12AffineEnvironment.transform 7 36 env52825 = env52826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52825 == env52826) = true)

theorem identity52826 : scanCanonicalize (H12AffineFastState.compose env52826 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound52826 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52827 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,9,16384,112,21590,16401,23557,1024,113,17477,33,16,2,8,64,2048,5221,4128,23668,20516,21589,36,21588,5156,512]

theorem envBound52827 : H12AffineFastState.Bounded env52827 := by
  intro p hp
  have h : env52827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52826_52827 : H12AffineEnvironment.transform 12 9 env52826 = env52827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env52826 == env52827) = true)

theorem identity52827 : scanCanonicalize (H12AffineFastState.compose env52827 (packedSelected [11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound52827 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env52828 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,9,16384,112,20530,16401,22625,100,113,16417,33,16,2,8,64,2048,4097,4128,22544,20516,20529,36,20528,4160,512]

theorem envBound52828 : H12AffineFastState.Bounded env52828 := by
  intro p hp
  have h : env52828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52827_52828 : H12AffineEnvironment.transform 9 100 env52827 = env52828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env52827 == env52828) = true)

theorem identity52828 : scanCanonicalize (H12AffineFastState.compose env52828 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound52828 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52829 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,9,4160,112,114,4177,2081,100,113,4193,33,16,2,8,64,2048,4097,4128,2128,100,113,36,112,4160,512]

theorem envBound52829 : H12AffineFastState.Bounded env52829 := by
  intro p hp
  have h : env52829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52828_52829 : H12AffineEnvironment.transform 13 4160 env52828 = env52829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env52828 == env52829) = true)

theorem identity52829 : scanCanonicalize (H12AffineFastState.compose env52829 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52829 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52830 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,2065,9,2129,112,114,2112,2081,100,113,2160,33,16,2,8,64,2048,2064,2097,2128,100,113,36,112,2129,512]

theorem envBound52830 : H12AffineFastState.Bounded env52830 := by
  intro p hp
  have h : env52830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52829_52830 : H12AffineEnvironment.transform 11 2065 env52829 = env52830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52829 == env52830) = true)

theorem identity52830 : scanCanonicalize (H12AffineFastState.compose env52830 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound52830 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52831 : List Nat := [2,4,8,16,32,64,9,36,512,100,33,48,9,112,112,114,97,0,100,113,81,33,16,2,8,64,33,49,16,113,100,113,36,112,112,512]

theorem envBound52831 : H12AffineFastState.Bounded env52831 := by
  intro p hp
  have h : env52831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52830_52831 : H12AffineEnvironment.transform 10 33 env52830 = env52831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env52830 == env52831) = true)

theorem identity52831 : scanCanonicalize (H12AffineFastState.compose env52831 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52831 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52832 : List Nat := [2,4,8,16,0,64,9,4,512,68,1,16,9,80,80,82,65,0,68,81,81,1,16,2,8,64,1,17,16,81,68,81,4,80,80,512]

theorem envBound52832 : H12AffineFastState.Bounded env52832 := by
  intro p hp
  have h : env52832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52831_52832 : H12AffineEnvironment.transform 4 0 env52831 = env52832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52831 == env52832) = true)

theorem identity52832 : scanCanonicalize (H12AffineFastState.compose env52832 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52833 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,0,0,2,17,0,20,1,1,1,16,2,8,16,1,17,16,1,20,1,4,0,0,512]

theorem envBound52833 : H12AffineFastState.Bounded env52833 := by
  intro p hp
  have h : env52833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52832_52833 : H12AffineEnvironment.transform 5 16 env52832 = env52833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52832 == env52833) = true)

def env52834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8193,64,4677967,2172251,2118976,442385,75102,6407191,256,2188651,2196550,513]

theorem envBound52834 : H12AffineFastState.Bounded env52834 := by
  intro p hp
  have h : env52834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52818_52834 : H12AffineEnvironment.transform 22 17 env52818 = env52834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52818 == env52834) = true)

theorem identity52834 : scanCanonicalize (H12AffineFastState.compose env52834 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52834 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41311,8193,64,4456788,2172251,2118976,368650,75102,6407191,256,2188651,2196550,513]

theorem envBound52835 : H12AffineFastState.Bounded env52835 := by
  intro p hp
  have h : env52835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52834_52835 : H12AffineEnvironment.transform 16 90139 env52834 = env52835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52834 == env52835) = true)

theorem identity52835 : scanCanonicalize (H12AffineFastState.compose env52835 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound52835 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,262144,1024,29005,2097152,4194304,17,20499,8193,64,4456788,2172251,2118976,348486,75102,6370651,256,2188651,2192650,513]

theorem envBound52836 : H12AffineFastState.Bounded env52836 := by
  intro p hp
  have h : env52836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52835_52836 : H12AffineEnvironment.transform 14 29004 env52835 = env52836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env52835 == env52836) = true)

theorem identity52836 : scanCanonicalize (H12AffineFastState.compose env52836 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound52836 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env52837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,2097152,4194304,17,20499,8193,64,4225389,2172251,2118976,76159,75102,6370651,256,2188651,2192650,513]

theorem envBound52837 : H12AffineFastState.Bounded env52837 := by
  intro p hp
  have h : env52837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52836_52837 : H12AffineEnvironment.transform 17 30777 env52836 = env52837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env52836 == env52837) = true)

def env52838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5456,4194304,17,20499,8193,64,4225389,77835,16400,76159,75102,4268043,256,94267,90202,513]

theorem envBound52838 : H12AffineFastState.Bounded env52838 := by
  intro p hp
  have h : env52838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52837_52838 : H12AffineEnvironment.transform 20 5456 env52837 = env52838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env52837 == env52838) = true)

theorem identity52838 : scanCanonicalize (H12AffineFastState.compose env52838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound52838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5456,32,17,20499,8193,64,31053,77835,16400,76159,75102,73771,256,94267,90202,513]

theorem envBound52839 : H12AffineFastState.Bounded env52839 := by
  intro p hp
  have h : env52839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52838_52839 : H12AffineEnvironment.transform 21 32 env52838 = env52839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52838 == env52839) = true)

theorem identity52839 : scanCanonicalize (H12AffineFastState.compose env52839 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound52839 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,65536,77834,10280,1024,8540,5456,32,17,2,8193,64,10588,77835,4097,76159,75102,73771,256,73770,77899,513]

theorem envBound52840 : H12AffineFastState.Bounded env52840 := by
  intro p hp
  have h : env52840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52839_52840 : H12AffineEnvironment.transform 13 4113 env52839 = env52840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env52839 == env52840) = true)

theorem identity52840 : scanCanonicalize (H12AffineFastState.compose env52840 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound52840 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env52841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7465,4113,7284,65536,68899,5377,1024,7285,5456,32,17,2,7464,64,5237,68898,4097,70742,71799,72962,256,72963,68962,513]

theorem envBound52841 : H12AffineFastState.Bounded env52841 := by
  intro p hp
  have h : env52841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52840_52841 : H12AffineEnvironment.transform 12 7465 env52840 = env52841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env52840 == env52841) = true)

theorem identity52841 : scanCanonicalize (H12AffineFastState.compose env52841 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound52841 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,269,3125,80,65536,68899,2341,1024,81,2420,32,17,2,268,64,2129,68898,3109,67698,66643,65830,256,65831,68962,513]

theorem envBound52842 : H12AffineFastState.Bounded env52842 := by
  intro p hp
  have h : env52842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52841_52842 : H12AffineEnvironment.transform 11 3108 env52841 = env52842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env52841 == env52842) = true)

theorem identity52842 : scanCanonicalize (H12AffineFastState.compose env52842 (packedSelected [4,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound52842 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52843 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,269,2129,80,65536,67911,2341,100,81,2420,32,17,2,268,64,2129,67910,2113,67698,65591,65830,256,65831,67846,513]

theorem envBound52843 : H12AffineFastState.Bounded env52843 := by
  intro p hp
  have h : env52843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52842_52843 : H12AffineEnvironment.transform 9 100 env52842 = env52843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env52842 == env52843) = true)

theorem identity52843 : scanCanonicalize (H12AffineFastState.compose env52843 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound52843 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env52844 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,269,2129,80,343,2064,2341,100,81,2420,32,17,2,268,64,2129,2065,2113,2341,352,113,256,112,2129,513]

theorem envBound52844 : H12AffineFastState.Bounded env52844 := by
  intro p hp
  have h : env52844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52843_52844 : H12AffineEnvironment.transform 15 343 env52843 = env52844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env52843 == env52844) = true)

def env52845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5457,4194304,17,20499,8193,64,4225389,77834,16401,76159,75102,4268042,256,94266,90203,513]

theorem envBound52845 : H12AffineFastState.Bounded env52845 := by
  intro p hp
  have h : env52845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52837_52845 : H12AffineEnvironment.transform 20 5457 env52837 = env52845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env52837 == env52845) = true)

theorem identity52845 : scanCanonicalize (H12AffineFastState.compose env52845 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20529) := by decide +kernel

theorem selectedBound52845 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5457,20529,17,20499,8193,64,10588,77834,16401,76159,75102,94267,256,94266,90203,513]

theorem envBound52846 : H12AffineFastState.Bounded env52846 := by
  intro p hp
  have h : env52846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52845_52846 : H12AffineEnvironment.transform 21 20529 env52845 = env52846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20529 env52845 == env52846) = true)

theorem identity52846 : scanCanonicalize (H12AffineFastState.compose env52846 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52846 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8202,16401,30777,1024,29005,5457,20529,17,20499,8193,64,10588,4096,16401,2421,1364,20529,256,20528,16465,513]

theorem envBound52847 : H12AffineFastState.Bounded env52847 := by
  intro p hp
  have h : env52847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52846_52847 : H12AffineEnvironment.transform 15 8202 env52846 = env52847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52846 == env52847) = true)

theorem identity52847 : scanCanonicalize (H12AffineFastState.compose env52847 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound52847 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12572,80,8202,12557,2341,1024,81,5457,8493,17,8463,8193,64,10588,4096,12557,2421,1364,8493,256,8492,12621,513]

theorem envBound52848 : H12AffineFastState.Bounded env52848 := by
  intro p hp
  have h : env52848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52847_52848 : H12AffineEnvironment.transform 13 12572 env52847 = env52848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env52847 == env52848) = true)

theorem identity52848 : scanCanonicalize (H12AffineFastState.compose env52848 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52848 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52849 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,12572,1,8202,12557,2341,1024,0,5376,8493,17,8463,8193,17,10509,4096,12557,2340,1285,8493,256,8492,12572,513]

theorem envBound52849 : H12AffineFastState.Bounded env52849 := by
  intro p hp
  have h : env52849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52848_52849 : H12AffineEnvironment.transform 5 17 env52848 = env52849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52848 == env52849) = true)

theorem identity52849 : scanCanonicalize (H12AffineFastState.compose env52849 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52849 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52850 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,8192,10509,1,8202,10524,2341,1024,0,3345,8493,17,8463,8193,17,10509,2065,10524,2340,1285,8493,256,8492,10509,513]

theorem envBound52850 : H12AffineFastState.Bounded env52850 := by
  intro p hp
  have h : env52850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52849_52850 : H12AffineEnvironment.transform 11 2065 env52849 = env52850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52849 == env52850) = true)

theorem identity52850 : scanCanonicalize (H12AffineFastState.compose env52850 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52850 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52851 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,268,2049,1,262,2064,2341,1024,0,3345,33,17,3,269,17,2049,2065,2064,2340,1285,33,256,32,2049,513]

theorem envBound52851 : H12AffineFastState.Bounded env52851 := by
  intro p hp
  have h : env52851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52850_52851 : H12AffineEnvironment.transform 12 268 env52850 = env52851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52850 == env52851) = true)

theorem identity52851 : scanCanonicalize (H12AffineFastState.compose env52851 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound52851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52852 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,309,268,293,1,262,308,1,1024,0,1077,33,17,3,269,17,293,309,308,0,1285,33,256,32,293,513]

theorem envBound52852 : H12AffineFastState.Bounded env52852 := by
  intro p hp
  have h : env52852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52851_52852 : H12AffineEnvironment.transform 10 292 env52851 = env52852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env52851 == env52852) = true)

def env52853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound52853 : H12AffineFastState.Bounded env52853 := by
  intro p hp
  have h : env52853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52719_52853 : H12AffineEnvironment.transform 18 1025 env52719 = env52853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env52719 == env52853) = true)

theorem identity52853 : scanCanonicalize (H12AffineFastState.compose env52853 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213471) := by decide +kernel

theorem selectedBound52853 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213471,16777216,8328,64,21266911,18973836,2299022,360926,16958927,23160257,257,19039602,19031255,17031704]

theorem envBound52854 : H12AffineFastState.Bounded env52854 := by
  intro p hp
  have h : env52854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52853_52854 : H12AffineEnvironment.transform 22 213471 env52853 = env52854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213471 env52853 == env52854) = true)

def env52855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411972,213471,16777216,8328,64,16959643,18973836,2299022,360926,16958927,19344517,257,19039602,19031255,17031704]

theorem envBound52855 : H12AffineFastState.Bounded env52855 := by
  intro p hp
  have h : env52855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52854_52855 : H12AffineEnvironment.transform 21 411972 env52854 = env52855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411972 env52854 == env52855) = true)

def env52856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213471,16777216,8328,64,16959643,16974300,102878,360926,16958927,17148373,257,16777250,16834951,17031704]

theorem envBound52856 : H12AffineFastState.Bounded env52856 := by
  intro p hp
  have h : env52856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52855_52856 : H12AffineEnvironment.transform 20 165200 env52855 = env52856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env52855 == env52856) = true)

def env52857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318548,120015,16777216,8328,64,16801163,16880844,102878,360926,16797919,17148373,257,16777250,16834951,16873224]

theorem envBound52857 : H12AffineFastState.Bounded env52857 := by
  intro p hp
  have h : env52857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52856_52857 : H12AffineEnvironment.transform 16 38160 env52856 = env52857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52856 == env52857) = true)

def env52858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318548,120015,338048,8328,64,357643,310348,102878,360926,358495,33109,257,338082,379143,286600]

theorem envBound52858 : H12AffineFastState.Bounded env52858 := by
  intro p hp
  have h : env52858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52857_52858 : H12AffineEnvironment.transform 23 338048 env52857 = env52858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338048 env52857 == env52858) = true)

theorem identity52858 : scanCanonicalize (H12AffineFastState.compose env52858 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound52858 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env52859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35324,1025,32769,4160,21928,120015,106876,8328,64,130295,13744,102878,67618,127395,33109,257,106846,82171,54900]

theorem envBound52859 : H12AffineFastState.Bounded env52859 := by
  intro p hp
  have h : env52859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52858_52859 : H12AffineEnvironment.transform 17 35324 env52858 = env52859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env52858 == env52859) = true)

def env52860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,13388,10400,1025,8541,4160,21928,95635,65568,8328,64,89515,13744,77954,67618,86271,8201,257,65538,82171,30504]

theorem envBound52860 : H12AffineFastState.Bounded env52860 := by
  intro p hp
  have h : env52860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52859_52860 : H12AffineEnvironment.transform 14 8540 env52859 = env52860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52859 == env52860) = true)

theorem identity52860 : scanCanonicalize (H12AffineFastState.compose env52860 (packedSelected [0,2,4,6,7,9,16,20,23,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 29943) := by decide +kernel

theorem selectedBound52860 : packedSelected [0,2,4,6,7,9,16,20,23,32,35] rootPS < 2^1333 := by decide +kernel

def env52861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29943,13388,10400,1025,8541,4160,21928,356,29911,8328,64,10588,13744,17525,31957,9224,8201,257,29941,13324,30504]

theorem envBound52861 : H12AffineFastState.Bounded env52861 := by
  intro p hp
  have h : env52861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52860_52861 : H12AffineEnvironment.transform 15 29943 env52860 = env52861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29943 env52860 == env52861) = true)

theorem identity52861 : scanCanonicalize (H12AffineFastState.compose env52861 (packedSelected [0,3,7,9,10,14,16,18,19,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound52861 : packedSelected [0,3,7,9,10,14,16,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env52862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5373,8540,8202,13388,10400,1025,8541,4160,341,356,8234,8328,64,10588,13744,4232,10280,9224,8201,257,8200,13324,9173]

theorem envBound52862 : H12AffineFastState.Bounded env52862 := by
  intro p hp
  have h : env52862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52861_52862 : H12AffineEnvironment.transform 13 5373 env52861 = env52862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env52861 == env52862) = true)

theorem identity52862 : scanCanonicalize (H12AffineFastState.compose env52862 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52862 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env52863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5373,80,262,5440,2476,1025,81,4160,341,356,294,388,64,2128,5308,4232,2340,1284,261,257,260,5376,729]

theorem envBound52863 : H12AffineFastState.Bounded env52863 := by
  intro p hp
  have h : env52863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52862_52863 : H12AffineEnvironment.transform 12 268 env52862 = env52863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52862 == env52863) = true)

theorem identity52863 : scanCanonicalize (H12AffineFastState.compose env52863 (packedSelected [1,3,5,8,10,11,14,15,19] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound52863 : packedSelected [1,3,5,8,10,11,14,15,19] rootPS < 2^1333 := by decide +kernel

def env52864 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,268,4161,80,262,4604,2476,189,81,4160,341,356,294,388,64,2128,4096,4232,2340,440,261,257,260,4540,729]

theorem envBound52864 : H12AffineFastState.Bounded env52864 := by
  intro p hp
  have h : env52864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52863_52864 : H12AffineEnvironment.transform 9 188 env52863 = env52864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env52863 == env52864) = true)

theorem identity52864 : scanCanonicalize (H12AffineFastState.compose env52864 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52864 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52865 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,268,4112,1,262,4525,2476,189,0,4113,260,309,294,388,17,2049,4096,4232,2340,440,261,257,260,4540,648]

theorem envBound52865 : H12AffineFastState.Bounded env52865 := by
  intro p hp
  have h : env52865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52864_52865 : H12AffineEnvironment.transform 5 17 env52864 = env52865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52864 == env52865) = true)

theorem identity52865 : scanCanonicalize (H12AffineFastState.compose env52865 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52865 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52866 : List Nat := [2,4,8,16,32,17,128,173,512,188,2048,4096,161,4112,1,171,4096,2049,189,0,4113,169,152,139,41,17,2049,4096,4232,2185,21,168,172,169,4113,648]

theorem envBound52866 : H12AffineFastState.Bounded env52866 := by
  intro p hp
  have h : env52866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52865_52866 : H12AffineEnvironment.transform 7 173 env52865 = env52866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52865 == env52866) = true)

theorem identity52866 : scanCanonicalize (H12AffineFastState.compose env52866 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound52866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52867 : List Nat := [2,4,8,16,32,17,41,4,512,21,2048,4096,8,4112,1,2,4096,2049,20,0,4113,0,49,34,41,17,2049,4096,4129,2080,21,1,5,0,4113,545]

theorem envBound52867 : H12AffineFastState.Bounded env52867 := by
  intro p hp
  have h : env52867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52866_52867 : H12AffineEnvironment.transform 6 41 env52866 = env52867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env52866 == env52867) = true)

def env52868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,13389,10401,1025,8540,4160,21928,95634,65569,8328,64,89514,13744,77955,67618,86270,8200,257,65539,82171,30505]

theorem envBound52868 : H12AffineFastState.Bounded env52868 := by
  intro p hp
  have h : env52868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52859_52868 : H12AffineEnvironment.transform 14 8541 env52859 = env52868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52859 == env52868) = true)

theorem identity52868 : scanCanonicalize (H12AffineFastState.compose env52868 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound52868 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29963,13389,10401,1025,8540,4160,21928,153,29994,8328,64,10401,13744,17800,32041,9717,8200,257,29960,13808,30505]

theorem envBound52869 : H12AffineFastState.Bounded env52869 := by
  intro p hp
  have h : env52869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52868_52869 : H12AffineEnvironment.transform 15 29963 env52868 = env52869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env52868 == env52869) = true)

theorem identity52869 : scanCanonicalize (H12AffineFastState.compose env52869 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound52869 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env52870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13608,8541,35,13389,10401,1025,8540,4160,8320,153,2,8328,64,10401,13744,12448,2049,9717,8200,257,32,13808,513]

theorem envBound52870 : H12AffineFastState.Bounded env52870 := by
  intro p hp
  have h : env52870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52869_52870 : H12AffineEnvironment.transform 13 13608 env52869 = env52870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env52869 == env52870) = true)

theorem identity52870 : scanCanonicalize (H12AffineFastState.compose env52870 (packedSelected [1,4,8,9,10,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound52870 : packedSelected [1,4,8,9,10,15,18] rootPS < 2^1333 := by decide +kernel

def env52871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6476,3172,6161,35,3329,4589,1025,6160,4160,6604,153,2,6596,64,4589,3324,2540,2049,7353,6468,257,32,3260,513]

theorem envBound52871 : H12AffineFastState.Bounded env52871 := by
  intro p hp
  have h : env52871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52870_52871 : H12AffineEnvironment.transform 12 6476 env52870 = env52871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env52870 == env52871) = true)

theorem identity52871 : scanCanonicalize (H12AffineFastState.compose env52871 (packedSelected [0,1,2,6,7,8,10,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound52871 : packedSelected [0,1,2,6,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env52872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1196,3552,3172,3261,35,3329,1345,1025,3260,1260,3424,153,2,3432,64,1345,3324,2540,2049,2069,3560,257,32,3260,513]

theorem envBound52872 : H12AffineFastState.Bounded env52872 := by
  intro p hp
  have h : env52872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52871_52872 : H12AffineEnvironment.transform 11 1196 env52871 = env52872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env52871 == env52872) = true)

theorem identity52872 : scanCanonicalize (H12AffineFastState.compose env52872 (packedSelected [0,1,2,6,7,8,10,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound52872 : packedSelected [0,1,2,6,7,8,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,293,1196,1221,1345,1432,35,1060,1345,1025,1433,1260,1093,153,2,1101,64,1345,1497,201,292,304,1229,257,32,1433,513]

theorem envBound52873 : H12AffineFastState.Bounded env52873 := by
  intro p hp
  have h : env52873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52872_52873 : H12AffineEnvironment.transform 10 293 env52872 = env52873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env52872 == env52873) = true)

theorem identity52873 : scanCanonicalize (H12AffineFastState.compose env52873 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52873 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,1060,1101,1345,1296,35,1060,1345,1025,1297,1124,1093,17,2,1101,64,1345,1361,65,292,304,1093,257,32,1297,513]

theorem envBound52874 : H12AffineFastState.Bounded env52874 := by
  intro p hp
  have h : env52874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52873_52874 : H12AffineEnvironment.transform 6 8 env52873 = env52874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52873 == env52874) = true)

theorem identity52874 : scanCanonicalize (H12AffineFastState.compose env52874 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52874 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52875 : List Nat := [2,4,8,16,32,64,8,256,512,273,293,309,348,80,1,35,309,80,272,0,373,340,17,2,348,64,80,64,65,292,304,340,257,32,0,513]

theorem envBound52875 : H12AffineFastState.Bounded env52875 := by
  intro p hp
  have h : env52875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52874_52875 : H12AffineEnvironment.transform 9 273 env52874 = env52875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52874 == env52875) = true)

theorem identity52875 : scanCanonicalize (H12AffineFastState.compose env52875 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 53) := by decide +kernel

theorem selectedBound52875 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52876 : List Nat := [2,4,8,16,32,53,8,256,512,273,293,309,297,37,1,35,309,37,272,0,256,289,17,2,297,53,37,53,52,292,304,289,257,32,0,513]

theorem envBound52876 : H12AffineFastState.Bounded env52876 := by
  intro p hp
  have h : env52876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52875_52876 : H12AffineEnvironment.transform 5 53 env52875 = env52876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 53 env52875 == env52876) = true)

theorem identity52876 : scanCanonicalize (H12AffineFastState.compose env52876 (packedSelected [1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52876 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env52877 : List Nat := [2,4,1,16,32,53,1,256,512,273,293,309,288,37,1,35,309,37,272,0,256,289,17,2,288,53,37,53,52,292,304,289,257,32,0,513]

theorem envBound52877 : H12AffineFastState.Bounded env52877 := by
  intro p hp
  have h : env52877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52876_52877 : H12AffineEnvironment.transform 2 1 env52876 = env52877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52876 == env52877) = true)

theorem identity52877 : scanCanonicalize (H12AffineFastState.compose env52877 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52877 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52878 : List Nat := [2,4,1,16,16,5,1,256,512,273,277,261,272,21,1,19,261,21,272,0,256,273,17,2,272,5,21,5,4,276,256,273,257,16,0,513]

theorem envBound52878 : H12AffineFastState.Bounded env52878 := by
  intro p hp
  have h : env52878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52877_52878 : H12AffineEnvironment.transform 4 16 env52877 = env52878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52877 == env52878) = true)

theorem identity52878 : scanCanonicalize (H12AffineFastState.compose env52878 (packedSelected [1,6] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52878 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env52879 : List Nat := [2,4,1,16,16,5,1,256,16,273,277,261,272,21,1,19,261,21,272,0,256,273,17,2,272,5,21,5,4,276,256,273,257,16,0,17]

theorem envBound52879 : H12AffineFastState.Bounded env52879 := by
  intro p hp
  have h : env52879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52878_52879 : H12AffineEnvironment.transform 8 16 env52878 = env52879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52878 == env52879) = true)

theorem identity52879 : scanCanonicalize (H12AffineFastState.compose env52879 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 22) := by decide +kernel

theorem selectedBound52879 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52880 : List Nat := [2,4,1,16,16,5,1,22,16,7,3,19,6,21,1,19,19,21,6,0,22,7,17,2,6,5,21,5,4,2,22,7,23,16,0,17]

theorem envBound52880 : H12AffineFastState.Bounded env52880 := by
  intro p hp
  have h : env52880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52879_52880 : H12AffineEnvironment.transform 7 22 env52879 = env52880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 22 env52879 == env52880) = true)

theorem identity52880 : scanCanonicalize (H12AffineFastState.compose env52880 (packedSelected [2,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52880 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env52881 : List Nat := [2,4,1,0,0,5,1,6,0,7,3,3,6,5,1,3,3,5,6,0,6,7,1,2,6,5,5,5,4,2,6,7,7,0,0,1]

theorem envBound52881 : H12AffineFastState.Bounded env52881 := by
  intro p hp
  have h : env52881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52880_52881 : H12AffineEnvironment.transform 3 0 env52880 = env52881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52880 == env52881) = true)

def env52882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318548,120015,338049,8328,64,357642,310349,102878,360926,358494,33108,257,338083,379142,286601]

theorem envBound52882 : H12AffineFastState.Bounded env52882 := by
  intro p hp
  have h : env52882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52857_52882 : H12AffineEnvironment.transform 23 338049 env52857 = env52882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338049 env52857 == env52882) = true)

theorem identity52882 : scanCanonicalize (H12AffineFastState.compose env52882 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound52882 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env52883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35189,1025,32769,4160,21793,120015,106996,8328,64,130175,13624,102878,67755,127275,33108,257,106966,82035,55036]

theorem envBound52883 : H12AffineFastState.Bounded env52883 := by
  intro p hp
  have h : env52883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52882_52883 : H12AffineEnvironment.transform 17 35189 env52882 = env52883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env52882 == env52883) = true)

def env52884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13508,10401,1025,8661,4160,21793,95515,65568,8328,64,89515,13624,77834,67755,86271,8320,257,65538,82035,30504]

theorem envBound52884 : H12AffineFastState.Bounded env52884 := by
  intro p hp
  have h : env52884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52883_52884 : H12AffineEnvironment.transform 14 8660 env52883 = env52884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env52883 == env52884) = true)

theorem identity52884 : scanCanonicalize (H12AffineFastState.compose env52884 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound52884 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29963,13508,10401,1025,8661,4160,21793,16,29995,8328,64,10400,13624,17665,32160,9716,8320,257,29961,13688,30504]

theorem envBound52885 : H12AffineFastState.Bounded env52885 := by
  intro p hp
  have h : env52885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52884_52885 : H12AffineEnvironment.transform 15 29963 env52884 = env52885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env52884 == env52885) = true)

theorem identity52885 : scanCanonicalize (H12AffineFastState.compose env52885 (packedSelected [2,4,5,7,9,11,12,14,15,18,19,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound52885 : packedSelected [2,4,5,7,9,11,12,14,15,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env52886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,16384,428,21875,5308,2265,1025,429,4160,21793,16,21843,240,64,2264,5440,17665,24024,1420,248,257,21873,5376,22352]

theorem envBound52886 : H12AffineFastState.Bounded env52886 := by
  intro p hp
  have h : env52886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52885_52886 : H12AffineEnvironment.transform 12 120 env52885 = env52886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env52885 == env52886) = true)

theorem identity52886 : scanCanonicalize (H12AffineFastState.compose env52886 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound52886 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env52887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5512,428,251,5308,2265,1025,429,4160,169,16,219,240,64,2264,5440,4233,2128,1420,248,257,249,5376,728]

theorem envBound52887 : H12AffineFastState.Bounded env52887 := by
  intro p hp
  have h : env52887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52886_52887 : H12AffineEnvironment.transform 13 5512 env52886 = env52887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env52886 == env52887) = true)

theorem identity52887 : scanCanonicalize (H12AffineFastState.compose env52887 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52887 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52888 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5512,428,170,5308,2184,1025,429,4113,169,16,138,161,17,2185,5393,4233,2049,1420,169,257,168,5376,649]

theorem envBound52888 : H12AffineFastState.Bounded env52888 := by
  intro p hp
  have h : env52888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52887_52888 : H12AffineEnvironment.transform 5 17 env52887 = env52888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52887 == env52888) = true)

theorem identity52888 : scanCanonicalize (H12AffineFastState.compose env52888 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52888 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env52889 : List Nat := [2,4,8,16,32,17,128,256,512,53,2048,4096,41,4541,428,170,4233,2184,52,429,4113,169,16,138,161,17,2185,4388,4233,2049,441,169,257,168,4405,649]

theorem envBound52889 : H12AffineFastState.Bounded env52889 := by
  intro p hp
  have h : env52889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52888_52889 : H12AffineEnvironment.transform 9 53 env52888 = env52889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52888 == env52889) = true)

theorem identity52889 : scanCanonicalize (H12AffineFastState.compose env52889 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52889 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52890 : List Nat := [2,4,8,16,32,17,128,173,512,53,2048,4096,41,4112,1,170,4233,2184,52,0,4113,169,16,138,161,17,2185,4233,4233,2049,20,169,172,168,4248,649]

theorem envBound52890 : H12AffineFastState.Bounded env52890 := by
  intro p hp
  have h : env52890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52889_52890 : H12AffineEnvironment.transform 7 173 env52889 = env52890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52889 == env52890) = true)

theorem identity52890 : scanCanonicalize (H12AffineFastState.compose env52890 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound52890 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52891 : List Nat := [2,4,8,16,32,17,128,173,512,53,2048,2232,41,2216,1,170,2097,2184,52,0,2217,169,16,138,161,17,2185,2097,2097,2049,20,169,172,168,2080,649]

theorem envBound52891 : H12AffineFastState.Bounded env52891 := by
  intro p hp
  have h : env52891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52890_52891 : H12AffineEnvironment.transform 11 2232 env52890 = env52891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env52890 == env52891) = true)

theorem identity52891 : scanCanonicalize (H12AffineFastState.compose env52891 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound52891 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env52892 : List Nat := [2,4,8,16,32,17,40,5,512,53,2048,2064,41,2048,1,2,2097,2080,52,0,2049,1,16,34,9,17,2081,2097,2097,2049,20,1,4,0,2080,545]

theorem envBound52892 : H12AffineFastState.Bounded env52892 := by
  intro p hp
  have h : env52892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52891_52892 : H12AffineEnvironment.transform 6 40 env52891 = env52892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env52891 == env52892) = true)

theorem identity52892 : scanCanonicalize (H12AffineFastState.compose env52892 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52892 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52893 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,1,2,2064,2049,21,0,2049,1,16,3,9,17,2048,2064,2064,2049,20,1,4,0,2049,512]

theorem envBound52893 : H12AffineFastState.Bounded env52893 := by
  intro p hp
  have h : env52893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52892_52893 : H12AffineEnvironment.transform 4 1 env52892 = env52893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52892 == env52893) = true)

def env52894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13509,10400,1025,8660,4160,21793,95514,65569,8328,64,89514,13624,77835,67755,86270,8321,257,65539,82035,30505]

theorem envBound52894 : H12AffineFastState.Bounded env52894 := by
  intro p hp
  have h : env52894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52883_52894 : H12AffineEnvironment.transform 14 8661 env52883 = env52894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env52883 == env52894) = true)

theorem identity52894 : scanCanonicalize (H12AffineFastState.compose env52894 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52894 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,13388,10281,1025,8541,4160,21793,95514,65569,8193,64,89379,13624,77835,67618,86135,8200,257,65539,82035,30505]

theorem envBound52895 : H12AffineFastState.Bounded env52895 := by
  intro p hp
  have h : env52895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52894_52895 : H12AffineEnvironment.transform 6 9 env52894 = env52895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52894 == env52895) = true)

theorem identity52895 : scanCanonicalize (H12AffineFastState.compose env52895 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound52895 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env52896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21795,13388,10281,1025,8541,4160,21793,8249,21762,8193,64,2048,13624,25896,23809,1364,8200,257,21792,5456,30505]

theorem envBound52896 : H12AffineFastState.Bounded env52896 := by
  intro p hp
  have h : env52896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52895_52896 : H12AffineEnvironment.transform 15 21795 env52895 = env52896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env52895 == env52896) = true)

theorem identity52896 : scanCanonicalize (H12AffineFastState.compose env52896 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52896 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env52897 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,21590,13388,10281,1025,8232,4160,21588,8249,21623,8193,64,2048,13389,25693,23668,1057,8200,116,21589,5157,30300]

theorem envBound52897 : H12AffineFastState.Bounded env52897 := by
  intro p hp
  have h : env52897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52896_52897 : H12AffineEnvironment.transform 7 117 env52896 = env52897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52896 == env52897) = true)

theorem identity52897 : scanCanonicalize (H12AffineFastState.compose env52897 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52897 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env52898 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8233,35,13388,10281,1025,8232,4160,33,8249,2,8193,64,2048,13389,12328,2049,1057,8200,116,32,5157,8745]

theorem envBound52898 : H12AffineFastState.Bounded env52898 := by
  intro p hp
  have h : env52898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52897_52898 : H12AffineEnvironment.transform 13 5237 env52897 = env52898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52897 == env52898) = true)

theorem identity52898 : scanCanonicalize (H12AffineFastState.compose env52898 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52898 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52899 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,1,35,5220,2049,1025,0,4160,33,17,2,41,64,2048,5221,4096,2049,1057,32,116,32,5157,513]

theorem envBound52899 : H12AffineFastState.Bounded env52899 := by
  intro p hp
  have h : env52899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52898_52899 : H12AffineEnvironment.transform 12 40 env52898 = env52899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52898 == env52899) = true)

theorem identity52899 : scanCanonicalize (H12AffineFastState.compose env52899 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound52899 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52900 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,4096,40,5237,1,35,5220,1135,1025,0,4160,33,17,2,41,64,1134,5221,4096,1135,1057,32,116,32,5157,513]

theorem envBound52900 : H12AffineFastState.Bounded env52900 := by
  intro p hp
  have h : env52900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52899_52900 : H12AffineEnvironment.transform 10 1134 env52899 = env52900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env52899 == env52900) = true)

theorem identity52900 : scanCanonicalize (H12AffineFastState.compose env52900 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound52900 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52901 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,1125,40,16,1,35,1,1135,1025,0,1061,33,17,2,41,64,1134,0,1125,1135,1057,32,116,32,64,513]

theorem envBound52901 : H12AffineFastState.Bounded env52901 := by
  intro p hp
  have h : env52901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52900_52901 : H12AffineEnvironment.transform 11 1125 env52900 = env52901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env52900 == env52901) = true)

theorem identity52901 : scanCanonicalize (H12AffineFastState.compose env52901 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound52901 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52902 : List Nat := [2,4,8,16,32,26,9,47,512,1024,1076,1087,40,16,1,35,1,1077,1025,0,1061,33,17,2,41,26,1076,0,1087,1077,1057,32,46,32,26,513]

theorem envBound52902 : H12AffineFastState.Bounded env52902 := by
  intro p hp
  have h : env52902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52901_52902 : H12AffineEnvironment.transform 5 26 env52901 = env52902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env52901 == env52902) = true)

theorem identity52902 : scanCanonicalize (H12AffineFastState.compose env52902 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52902 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52903 : List Nat := [2,4,8,1,32,11,9,47,512,1024,1061,1070,40,1,1,35,1,1060,1025,0,1061,33,0,2,41,11,1061,0,1070,1060,1057,32,46,32,11,513]

theorem envBound52903 : H12AffineFastState.Bounded env52903 := by
  intro p hp
  have h : env52903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52902_52903 : H12AffineEnvironment.transform 3 1 env52902 = env52903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52902 == env52903) = true)

theorem identity52903 : scanCanonicalize (H12AffineFastState.compose env52903 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound52903 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52904 : List Nat := [2,4,8,1,32,11,9,47,33,1024,1061,1070,40,1,1,35,1,1060,1025,0,1061,33,0,2,41,11,1061,0,1070,1060,1057,32,46,32,11,32]

theorem envBound52904 : H12AffineFastState.Bounded env52904 := by
  intro p hp
  have h : env52904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52903_52904 : H12AffineEnvironment.transform 8 33 env52903 = env52904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env52903 == env52904) = true)

theorem identity52904 : scanCanonicalize (H12AffineFastState.compose env52904 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 44) := by decide +kernel

theorem selectedBound52904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52905 : List Nat := [2,4,8,1,32,11,9,47,33,44,9,2,40,1,1,35,1,8,45,0,9,33,0,2,41,11,9,0,2,8,13,32,46,32,11,32]

theorem envBound52905 : H12AffineFastState.Bounded env52905 := by
  intro p hp
  have h : env52905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52904_52905 : H12AffineEnvironment.transform 9 44 env52904 = env52905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 44 env52904 == env52905) = true)

theorem identity52905 : scanCanonicalize (H12AffineFastState.compose env52905 (packedSelected [0,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52905 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env52906 : List Nat := [2,4,8,1,1,11,9,14,0,13,9,2,9,1,1,2,1,8,12,0,9,0,0,2,8,11,9,0,2,8,13,1,15,1,11,1]

theorem envBound52906 : H12AffineFastState.Bounded env52906 := by
  intro p hp
  have h : env52906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52905_52906 : H12AffineEnvironment.transform 4 1 env52905 = env52906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52905 == env52906) = true)

theorem identity52906 : scanCanonicalize (H12AffineFastState.compose env52906 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound52906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52907 : List Nat := [2,4,6,1,1,5,7,0,0,3,7,2,7,1,1,2,1,6,2,0,7,0,0,2,6,5,7,0,2,6,3,1,1,1,5,1]

theorem envBound52907 : H12AffineFastState.Bounded env52907 := by
  intro p hp
  have h : env52907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52906_52907 : H12AffineEnvironment.transform 2 6 env52906 = env52907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env52906 == env52907) = true)

def env52908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318549,120014,16777216,8328,64,16801162,16880845,102878,360926,16797918,17148373,257,16777250,16834951,16873225]

theorem envBound52908 : H12AffineFastState.Bounded env52908 := by
  intro p hp
  have h : env52908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52856_52908 : H12AffineEnvironment.transform 16 38161 env52856 = env52908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env52856 == env52908) = true)

theorem identity52908 : scanCanonicalize (H12AffineFastState.compose env52908 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound52908 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318549,120014,95496,8328,64,75906,57797,102878,360926,75222,318685,257,95530,103567,513]

theorem envBound52909 : H12AffineFastState.Bounded env52909 := by
  intro p hp
  have h : env52909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52908_52909 : H12AffineEnvironment.transform 23 95496 env52908 = env52909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env52908 == env52909) = true)

def env52910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318549,119878,95496,8192,64,75786,57677,102742,360790,75102,318549,257,95530,103431,513]

theorem envBound52910 : H12AffineFastState.Bounded env52910 := by
  intro p hp
  have h : env52910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52909_52910 : H12AffineEnvironment.transform 6 8 env52909 = env52910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52909 == env52910) = true)

theorem identity52910 : scanCanonicalize (H12AffineFastState.compose env52910 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound52910 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4161,318549,8524,32770,8192,64,56576,57677,25692,291932,53332,318549,257,32800,24845,513]

theorem envBound52911 : H12AffineFastState.Bounded env52911 := by
  intro p hp
  have h : env52911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52910_52911 : H12AffineEnvironment.transform 15 62730 env52910 = env52911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env52910 == env52911) = true)

theorem identity52911 : scanCanonicalize (H12AffineFastState.compose env52911 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound52911 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env52912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,22884,1025,32769,4161,34097,8524,32770,8192,64,56576,57677,25692,11576,53332,34097,257,32800,24845,513]

theorem envBound52912 : H12AffineFastState.Bounded env52912 := by
  intro p hp
  have h : env52912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52911_52912 : H12AffineEnvironment.transform 17 22884 env52911 = env52912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env52911 == env52912) = true)

theorem identity52912 : scanCanonicalize (H12AffineFastState.compose env52912 (packedSelected [0,4,8,9,10,17,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound52912 : packedSelected [0,4,8,9,10,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env52913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,32768,33814,38161,10360,1025,32769,4161,34097,8524,32770,8192,64,44060,36945,5440,11576,41288,34097,257,32800,4113,513]

theorem envBound52913 : H12AffineFastState.Bounded env52913 := by
  intro p hp
  have h : env52913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52912_52913 : H12AffineEnvironment.transform 13 12572 env52912 = env52913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env52912 == env52913) = true)

theorem identity52913 : scanCanonicalize (H12AffineFastState.compose env52913 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52913 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env52914 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,12572,32768,33111,36944,10360,320,32769,4161,32880,8524,32770,8192,64,43357,36945,4097,10361,41288,32880,257,32800,4113,513]

theorem envBound52914 : H12AffineFastState.Bounded env52914 := by
  intro p hp
  have h : env52914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52913_52914 : H12AffineEnvironment.transform 9 321 env52913 = env52914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52913 == env52914) = true)

theorem identity52914 : scanCanonicalize (H12AffineFastState.compose env52914 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52914 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52915 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,8192,12393,32768,32802,36944,10360,53,32769,4161,32880,8249,32770,8192,64,43048,36945,4097,10361,41021,32880,116,32800,4113,513]

theorem envBound52915 : H12AffineFastState.Bounded env52915 := by
  intro p hp
  have h : env52915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52914_52915 : H12AffineEnvironment.transform 7 117 env52914 = env52915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52914 == env52915) = true)

theorem identity52915 : scanCanonicalize (H12AffineFastState.compose env52915 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(14+1) ^^^ 6160) := by decide +kernel

theorem selectedBound52915 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env52916 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,8192,12393,6160,6194,2112,10360,53,6161,4161,6240,8249,6162,8192,64,12344,2113,4097,10361,14381,6240,116,6192,4113,513]

theorem envBound52916 : H12AffineFastState.Bounded env52916 := by
  intro p hp
  have h : env52916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52915_52916 : H12AffineEnvironment.transform 14 6160 env52915 = env52916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6160 env52915 == env52916) = true)

theorem identity52916 : scanCanonicalize (H12AffineFastState.compose env52916 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4200) := by decide +kernel

theorem selectedBound52916 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env52917 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,4200,1,6160,6194,2112,6160,53,6161,4161,6240,4177,6162,4200,64,80,2113,4097,6161,2117,6240,116,6192,4113,513]

theorem envBound52917 : H12AffineFastState.Bounded env52917 := by
  intro p hp
  have h : env52917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52916_52917 : H12AffineEnvironment.transform 12 4200 env52916 = env52917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4200 env52916 == env52917) = true)

theorem identity52917 : scanCanonicalize (H12AffineFastState.compose env52917 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound52917 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52918 : List Nat := [2,4,8,16,32,64,8,117,512,52,80,4096,4200,1,4160,4194,16,4160,53,4161,4161,4144,4177,4162,4200,64,80,17,4097,4161,21,4144,116,4192,4113,513]

theorem envBound52918 : H12AffineFastState.Bounded env52918 := by
  intro p hp
  have h : env52918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52917_52918 : H12AffineEnvironment.transform 10 80 env52917 = env52918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env52917 == env52918) = true)

theorem identity52918 : scanCanonicalize (H12AffineFastState.compose env52918 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound52918 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env52919 : List Nat := [2,4,8,16,32,64,8,117,512,52,80,16,120,1,80,114,16,80,53,81,81,32,65,82,120,64,80,17,17,81,21,32,116,112,1,513]

theorem envBound52919 : H12AffineFastState.Bounded env52919 := by
  intro p hp
  have h : env52919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52918_52919 : H12AffineEnvironment.transform 11 16 env52918 = env52919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env52918 == env52919) = true)

theorem identity52919 : scanCanonicalize (H12AffineFastState.compose env52919 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52919 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52920 : List Nat := [2,4,8,0,32,64,8,101,512,36,64,0,104,1,64,98,0,64,37,65,65,32,65,66,104,64,64,1,1,65,5,32,100,96,1,513]

theorem envBound52920 : H12AffineFastState.Bounded env52920 := by
  intro p hp
  have h : env52920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52919_52920 : H12AffineEnvironment.transform 3 0 env52919 = env52920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52919 == env52920) = true)

def env52921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318549,119879,95496,8193,64,75787,57676,102743,360791,75103,318548,257,95530,103430,513]

theorem envBound52921 : H12AffineFastState.Bounded env52921 := by
  intro p hp
  have h : env52921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52909_52921 : H12AffineEnvironment.transform 6 9 env52909 = env52921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52909 == env52921) = true)

theorem identity52921 : scanCanonicalize (H12AffineFastState.compose env52921 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound52921 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env52922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35189,1025,32769,4161,21792,119879,95496,8193,64,75787,57676,102743,67618,75103,21793,257,95530,103430,513]

theorem envBound52922 : H12AffineFastState.Bounded env52922 := by
  intro p hp
  have h : env52922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52921_52922 : H12AffineEnvironment.transform 17 35189 env52921 = env52922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env52921 == env52922) = true)

theorem identity52922 : scanCanonicalize (H12AffineFastState.compose env52922 (packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound52922 : packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env52923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,35189,1025,32769,4161,21792,8525,32770,8193,64,56577,57676,25693,64808,53333,21793,257,32800,24844,513]

theorem envBound52923 : H12AffineFastState.Bounded env52923 := by
  intro p hp
  have h : env52923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52922_52923 : H12AffineEnvironment.transform 15 62730 env52922 = env52923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env52922 == env52923) = true)

end H12CloudChart1