import H12CloudChart1Data052

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound13295 : H12AffineFastState.Bounded env13295 := by
  intro p hp
  have h : env13295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13294_13295 : H12AffineEnvironment.transform 5 16 env13294 = env13295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13294 == env13295) = true)

theorem identity13295 : scanCanonicalize (H12AffineFastState.compose env13295 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound13295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13296 : List Nat := [2,1,8,16,32,16,9,32,512,48,523,570,41,555,0,34,570,523,48,1,554,33,17,3,40,16,522,571,570,522,16,33,32,32,555,513]

theorem envBound13296 : H12AffineFastState.Bounded env13296 := by
  intro p hp
  have h : env13296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13295_13296 : H12AffineEnvironment.transform 1 1 env13295 = env13296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env13295 == env13296) = true)

theorem identity13296 : scanCanonicalize (H12AffineFastState.compose env13296 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 50) := by decide +kernel

theorem selectedBound13296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13297 : List Nat := [2,1,8,16,32,16,9,32,50,48,57,8,41,25,0,34,8,57,48,1,24,33,17,3,40,16,56,9,8,56,16,33,32,32,25,51]

theorem envBound13297 : H12AffineFastState.Bounded env13297 := by
  intro p hp
  have h : env13297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13296_13297 : H12AffineEnvironment.transform 8 50 env13296 = env13297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 50 env13296 == env13297) = true)

def env13298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62541,2188736,8328,64,6705548,57676,2138397,406604,2102685,4194304,256,21792,46213,2175563]

theorem envBound13298 : H12AffineFastState.Bounded env13298 := by
  intro p hp
  have h : env13298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13238_13298 : H12AffineEnvironment.transform 22 62541 env13238 = env13298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62541 env13238 == env13298) = true)

def env13299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62541,2188736,8328,64,410092,57676,2138397,406604,2102685,2101344,256,21792,46213,2175563]

theorem envBound13299 : H12AffineFastState.Bounded env13299 := by
  intro p hp
  have h : env13299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13298_13299 : H12AffineEnvironment.transform 21 2101344 env13298 = env13299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env13298 == env13299) = true)

def env13300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62541,73856,8328,64,410092,57676,58461,406604,20701,21792,256,21792,46213,96011]

theorem envBound13300 : H12AffineFastState.Bounded env13300 := by
  intro p hp
  have h : env13300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13299_13300 : H12AffineEnvironment.transform 20 17728 env13299 = env13300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env13299 == env13300) = true)

theorem identity13300 : scanCanonicalize (H12AffineFastState.compose env13300 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13300 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62541,73736,8192,64,409956,57676,58461,406604,20565,21792,256,21792,46093,96011]

theorem envBound13301 : H12AffineFastState.Bounded env13301 := by
  intro p hp
  have h : env13301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13300_13301 : H12AffineEnvironment.transform 6 8 env13300 = env13301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13300 == env13301) = true)

def env13302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,17728,21792,62541,73736,8192,64,158028,57676,58461,138340,20565,21792,256,21792,46093,96011]

theorem envBound13302 : H12AffineFastState.Bounded env13302 := by
  intro p hp
  have h : env13302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13301_13302 : H12AffineEnvironment.transform 17 10280 env13301 = env13302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13301 == env13302) = true)

theorem identity13302 : scanCanonicalize (H12AffineFastState.compose env13302 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound13302 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10280,1024,32769,17728,21792,62541,21762,8192,64,158028,57676,58461,138340,20565,21792,256,21792,46093,513]

theorem envBound13303 : H12AffineFastState.Bounded env13303 := by
  intro p hp
  have h : env13303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13302_13303 : H12AffineEnvironment.transform 15 29962 env13302 = env13303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env13302 == env13303) = true)

theorem identity13303 : scanCanonicalize (H12AffineFastState.compose env13303 (packedSelected [1,8,10,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound13303 : packedSelected [1,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49216,10280,1024,32769,17728,21792,62541,21762,8192,64,43276,57676,58461,56356,20565,21792,256,21792,46093,513]

theorem envBound13304 : H12AffineFastState.Bounded env13304 := by
  intro p hp
  have h : env13304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13303_13304 : H12AffineEnvironment.transform 16 49216 env13303 = env13304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env13303 == env13304) = true)

theorem identity13304 : scanCanonicalize (H12AffineFastState.compose env13304 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13304 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13305 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,29962,49168,10280,1024,32769,17680,21792,62493,21762,8192,16,43276,57628,58381,56356,20485,21792,256,21792,46093,513]

theorem envBound13305 : H12AffineFastState.Bounded env13305 := by
  intro p hp
  have h : env13305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13304_13305 : H12AffineEnvironment.transform 5 16 env13304 = env13305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13304 == env13305) = true)

theorem identity13305 : scanCanonicalize (H12AffineFastState.compose env13305 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13305 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13306 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,21510,49168,2340,1024,32769,17680,21792,54545,21762,268,16,34816,49168,50433,56356,20485,21792,256,21792,38145,513]

theorem envBound13306 : H12AffineFastState.Bounded env13306 := by
  intro p hp
  have h : env13306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13305_13306 : H12AffineEnvironment.transform 12 268 env13305 = env13306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13305 == env13306) = true)

theorem identity13306 : scanCanonicalize (H12AffineFastState.compose env13306 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13306 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13307 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,21510,5393,2340,1024,21760,17680,21792,16,21762,268,16,23809,5393,4096,2341,20485,21792,256,21792,16384,513]

theorem envBound13307 : H12AffineFastState.Bounded env13307 := by
  intro p hp
  have h : env13307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13306_13307 : H12AffineEnvironment.transform 14 21761 env13306 = env13307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13306 == env13307) = true)

theorem identity13307 : scanCanonicalize (H12AffineFastState.compose env13307 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound13307 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env13308 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,1077,4404,4147,5393,2340,1024,4405,293,4373,16,4407,268,16,6452,5393,4096,2341,5168,4373,256,4373,1077,513]

theorem envBound13308 : H12AffineFastState.Bounded env13308 := by
  intro p hp
  have h : env13308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13307_13308 : H12AffineEnvironment.transform 13 1077 env13307 = env13308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env13307 == env13308) = true)

theorem identity13308 : scanCanonicalize (H12AffineFastState.compose env13308 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13308 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13309 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,1077,4112,4147,5173,2048,1024,4113,1,4145,16,4115,40,16,6160,5173,4096,2049,5168,4145,36,4145,1077,513]

theorem envBound13309 : H12AffineFastState.Bounded env13309 := by
  intro p hp
  have h : env13309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13308_13309 : H12AffineEnvironment.transform 7 36 env13308 = env13309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13308 == env13309) = true)

theorem identity13309 : scanCanonicalize (H12AffineFastState.compose env13309 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13309 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13310 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,4096,40,1077,4112,4147,5173,1,1024,4113,1,4145,16,4115,40,16,4113,5173,4096,0,5168,4145,36,4145,1077,513]

theorem envBound13310 : H12AffineFastState.Bounded env13310 := by
  intro p hp
  have h : env13310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13309_13310 : H12AffineEnvironment.transform 10 1 env13309 = env13310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13309 == env13310) = true)

theorem identity13310 : scanCanonicalize (H12AffineFastState.compose env13310 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13310 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13311 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,16,40,1077,0,35,1061,1,1024,1,1,33,16,3,40,16,1,1061,16,0,1056,33,36,33,1077,513]

theorem envBound13311 : H12AffineFastState.Bounded env13311 := by
  intro p hp
  have h : env13311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13310_13311 : H12AffineEnvironment.transform 11 16 env13310 = env13311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13310 == env13311) = true)

def env13312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,17728,21792,62541,73736,8192,64,158029,57676,58461,138341,20565,21792,256,21792,46093,96011]

theorem envBound13312 : H12AffineFastState.Bounded env13312 := by
  intro p hp
  have h : env13312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13301_13312 : H12AffineEnvironment.transform 17 10281 env13301 = env13312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13301 == env13312) = true)

theorem identity13312 : scanCanonicalize (H12AffineFastState.compose env13312 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound13312 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10281,1024,32769,17728,21792,62541,41311,8192,64,158029,57676,58461,138341,20565,21792,256,21792,46093,63068]

theorem envBound13313 : H12AffineFastState.Bounded env13313 := by
  intro p hp
  have h : env13313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13312_13313 : H12AffineEnvironment.transform 15 33111 env13312 = env13313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env13312 == env13313) = true)

theorem identity13313 : scanCanonicalize (H12AffineFastState.compose env13313 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound13313 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env13314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,5393,10281,1024,32769,17728,21792,62541,41311,8192,64,31836,57676,58461,2420,20565,21792,256,21792,46093,63068]

theorem envBound13314 : H12AffineFastState.Bounded env13314 := by
  intro p hp
  have h : env13314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13313_13314 : H12AffineEnvironment.transform 16 5393 env13313 = env13314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env13313 == env13314) = true)

theorem identity13314 : scanCanonicalize (H12AffineFastState.compose env13314 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound13314 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13315 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,32768,33111,4096,10281,273,32769,16465,20529,61788,41311,8192,64,31053,57676,57676,2420,20565,20529,256,20529,45340,62285]

theorem envBound13315 : H12AffineFastState.Bounded env13315 := by
  intro p hp
  have h : env13315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13314_13315 : H12AffineEnvironment.transform 9 273 env13314 = env13315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13314 == env13315) = true)

theorem identity13315 : scanCanonicalize (H12AffineFastState.compose env13315 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound13315 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13316 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,29004,28699,4096,10281,273,29005,16465,20529,16,20499,8192,64,31053,4096,4096,2420,20565,20529,256,20529,16464,513]

theorem envBound13316 : H12AffineFastState.Bounded env13316 := by
  intro p hp
  have h : env13316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13315_13316 : H12AffineEnvironment.transform 14 29004 env13315 = env13316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env13315 == env13316) = true)

theorem identity13316 : scanCanonicalize (H12AffineFastState.compose env13316 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound13316 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13317 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,381,16384,20529,20838,4096,2388,273,20528,16465,20529,16,20499,381,64,22576,4096,4096,2420,20565,20529,256,20529,16464,513]

theorem envBound13317 : H12AffineFastState.Bounded env13317 := by
  intro p hp
  have h : env13317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13316_13317 : H12AffineEnvironment.transform 12 381 env13316 = env13317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env13316 == env13317) = true)

theorem identity13317 : scanCanonicalize (H12AffineFastState.compose env13317 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound13317 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env13318 : List Nat := [2,4,8,16,32,64,8,256,512,273,81,4096,381,16384,20529,20838,4096,261,273,20528,16465,20529,16,20499,381,64,20577,4096,4096,293,20565,20529,256,20529,16464,513]

theorem envBound13318 : H12AffineFastState.Bounded env13318 := by
  intro p hp
  have h : env13318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13317_13318 : H12AffineEnvironment.transform 10 81 env13317 = env13318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env13317 == env13318) = true)

theorem identity13318 : scanCanonicalize (H12AffineFastState.compose env13318 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound13318 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13319 : List Nat := [2,4,8,16,32,64,8,256,512,273,81,48,381,16384,16385,16726,48,261,273,16384,16465,16385,16,16419,381,64,16465,48,48,293,16485,16385,256,16385,16464,513]

theorem envBound13319 : H12AffineFastState.Bounded env13319 := by
  intro p hp
  have h : env13319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13318_13319 : H12AffineEnvironment.transform 11 48 env13318 = env13319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env13318 == env13319) = true)

theorem identity13319 : scanCanonicalize (H12AffineFastState.compose env13319 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound13319 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env13320 : List Nat := [2,4,8,16,32,64,8,84,512,69,81,48,41,16384,16385,16386,48,81,69,16384,16465,16385,16,16419,41,64,16465,48,48,113,16485,16385,84,16385,16464,513]

theorem envBound13320 : H12AffineFastState.Bounded env13320 := by
  intro p hp
  have h : env13320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13319_13320 : H12AffineEnvironment.transform 7 84 env13319 = env13320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env13319 == env13320) = true)

theorem identity13320 : scanCanonicalize (H12AffineFastState.compose env13320 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound13320 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13321 : List Nat := [2,4,8,16,32,64,8,84,81,69,81,48,41,16384,16385,16386,48,81,69,16384,16465,16385,16,16419,41,64,16465,48,48,113,16485,16385,84,16385,16464,80]

theorem envBound13321 : H12AffineFastState.Bounded env13321 := by
  intro p hp
  have h : env13321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13320_13321 : H12AffineEnvironment.transform 8 81 env13320 = env13321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env13320 == env13321) = true)

theorem identity13321 : scanCanonicalize (H12AffineFastState.compose env13321 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 97) := by decide +kernel

theorem selectedBound13321 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13322 : List Nat := [2,4,8,16,32,64,8,84,81,69,81,48,41,97,96,99,48,81,69,97,48,96,16,66,41,64,48,48,48,113,4,96,84,96,49,80]

theorem envBound13322 : H12AffineFastState.Bounded env13322 := by
  intro p hp
  have h : env13322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13321_13322 : H12AffineEnvironment.transform 13 97 env13321 = env13322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 97 env13321 == env13322) = true)

theorem identity13322 : scanCanonicalize (H12AffineFastState.compose env13322 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound13322 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13323 : List Nat := [2,4,8,16,32,0,8,20,17,5,17,48,41,33,32,35,48,17,5,33,48,32,16,2,41,0,48,48,48,49,4,32,20,32,49,16]

theorem envBound13323 : H12AffineFastState.Bounded env13323 := by
  intro p hp
  have h : env13323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13322_13323 : H12AffineEnvironment.transform 5 0 env13322 = env13323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env13322 == env13323) = true)

theorem identity13323 : scanCanonicalize (H12AffineFastState.compose env13323 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13323 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13324 : List Nat := [2,4,8,16,17,0,8,20,17,5,17,1,24,16,17,18,1,17,5,16,1,17,16,2,24,0,1,1,1,0,4,17,20,17,0,16]

theorem envBound13324 : H12AffineFastState.Bounded env13324 := by
  intro p hp
  have h : env13324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13323_13324 : H12AffineEnvironment.transform 4 17 env13323 = env13324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13323 == env13324) = true)

theorem identity13324 : scanCanonicalize (H12AffineFastState.compose env13324 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13324 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13325 : List Nat := [2,4,8,0,1,0,8,4,1,5,1,1,8,0,1,2,1,1,5,0,1,1,0,2,8,0,1,1,1,0,4,1,4,1,0,0]

theorem envBound13325 : H12AffineFastState.Bounded env13325 := by
  intro p hp
  have h : env13325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13324_13325 : H12AffineEnvironment.transform 3 0 env13324 = env13325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13324 == env13325) = true)

def env13326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62541,73857,8328,64,410092,57676,58460,406604,20700,21793,256,21792,46213,96010]

theorem envBound13326 : H12AffineFastState.Bounded env13326 := by
  intro p hp
  have h : env13326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13299_13326 : H12AffineEnvironment.transform 20 17729 env13299 = env13326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env13299 == env13326) = true)

theorem identity13326 : scanCanonicalize (H12AffineFastState.compose env13326 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound13326 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env13327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1024,32769,17729,21793,62541,73857,8328,64,203847,57676,58460,223719,20700,21793,256,21792,46213,96010]

theorem envBound13327 : H12AffineFastState.Bounded env13327 := by
  intro p hp
  have h : env13327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13326_13327 : H12AffineEnvironment.transform 17 89515 env13326 = env13327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env13326 == env13327) = true)

def env13328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89515,1024,29789,17729,21793,17,73857,8328,64,203847,5392,4096,223719,20700,21793,256,21792,16601,96010]

theorem envBound13328 : H12AffineFastState.Bounded env13328 := by
  intro p hp
  have h : env13328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13327_13328 : H12AffineEnvironment.transform 14 29788 env13327 = env13328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env13327 == env13328) = true)

theorem identity13328 : scanCanonicalize (H12AffineFastState.compose env13328 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound13328 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env13329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,5392,89515,1024,29789,17729,21793,17,73857,8328,64,67927,5392,4096,97527,20700,21793,256,21792,16601,96010]

theorem envBound13329 : H12AffineFastState.Bounded env13329 := by
  intro p hp
  have h : env13329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13328_13329 : H12AffineEnvironment.transform 16 5392 env13328 = env13329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env13328 == env13329) = true)

theorem identity13329 : scanCanonicalize (H12AffineFastState.compose env13329 (packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound13329 : packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21976,65536,5392,89515,1024,21977,17729,21793,17,65797,268,64,67927,5392,4096,89459,20700,21793,256,21792,16601,87694]

theorem envBound13330 : H12AffineFastState.Bounded env13330 := by
  intro p hp
  have h : env13330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13329_13330 : H12AffineEnvironment.transform 12 388 env13329 = env13330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env13329 == env13330) = true)

theorem identity13330 : scanCanonicalize (H12AffineFastState.compose env13330 (packedSelected [0,1,2,7,8,10,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13330 : packedSelected [0,1,2,7,8,10,15,18] rootPS < 2^1333 := by decide +kernel

def env13331 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21896,65536,5392,89515,1024,21897,17681,21793,17,65797,268,16,67847,5392,4096,89379,20620,21793,256,21792,16521,87694]

theorem envBound13331 : H12AffineFastState.Bounded env13331 := by
  intro p hp
  have h : env13331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13330_13331 : H12AffineEnvironment.transform 5 16 env13330 = env13331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13330 == env13331) = true)

theorem identity13331 : scanCanonicalize (H12AffineFastState.compose env13331 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound13331 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13332 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21896,21646,5392,2341,1024,21897,17681,21793,17,21899,268,16,23945,5392,4096,2477,20620,21793,256,21792,16521,512]

theorem envBound13332 : H12AffineFastState.Bounded env13332 := by
  intro p hp
  have h : env13332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13331_13332 : H12AffineEnvironment.transform 15 21646 env13331 = env13332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env13331 == env13332) = true)

theorem identity13332 : scanCanonicalize (H12AffineFastState.compose env13332 (packedSelected [1,2,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound13332 : packedSelected [1,2,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13333 : List Nat := [2,4,8,16,32,16,128,256,512,156,2048,4096,388,16384,20756,20498,4492,2341,156,20757,16781,20925,17,20759,268,16,22805,4492,4096,2477,20620,20925,256,20924,16521,512]

theorem envBound13333 : H12AffineFastState.Bounded env13333 := by
  intro p hp
  have h : env13333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13332_13333 : H12AffineEnvironment.transform 9 156 env13332 = env13333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env13332 == env13333) = true)

theorem identity13333 : scanCanonicalize (H12AffineFastState.compose env13333 (packedSelected [0,2,6,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound13333 : packedSelected [0,2,6,9,12] rootPS < 2^1333 := by decide +kernel

def env13334 : List Nat := [2,4,8,16,32,16,40,256,512,52,2048,4096,300,16384,20756,20498,4388,2341,52,20757,16677,20757,17,20759,268,16,22805,4388,4096,2309,20516,20757,256,20756,16417,512]

theorem envBound13334 : H12AffineFastState.Bounded env13334 := by
  intro p hp
  have h : env13334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13333_13334 : H12AffineEnvironment.transform 6 40 env13333 = env13334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13333 == env13334) = true)

theorem identity13334 : scanCanonicalize (H12AffineFastState.compose env13334 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound13334 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env13335 : List Nat := [2,4,8,16,32,16,40,256,512,52,2048,4096,300,4112,260,2,4388,2341,52,261,4405,261,17,263,268,16,2309,4388,4096,2309,52,261,256,260,4145,512]

theorem envBound13335 : H12AffineFastState.Bounded env13335 := by
  intro p hp
  have h : env13335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13334_13335 : H12AffineEnvironment.transform 13 4112 env13334 = env13335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env13334 == env13335) = true)

theorem identity13335 : scanCanonicalize (H12AffineFastState.compose env13335 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13335 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env13336 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,268,4112,260,2,4356,2309,20,261,4373,261,17,263,268,16,2309,4356,4096,2309,20,261,256,260,4113,512]

theorem envBound13336 : H12AffineFastState.Bounded env13336 := by
  intro p hp
  have h : env13336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13335_13336 : H12AffineEnvironment.transform 4 0 env13335 = env13336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13335 == env13336) = true)

theorem identity13336 : scanCanonicalize (H12AffineFastState.compose env13336 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound13336 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13337 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,2065,268,2049,260,2,2325,2309,20,261,2308,261,17,263,268,16,2309,2325,2065,2309,20,261,256,260,2048,512]

theorem envBound13337 : H12AffineFastState.Bounded env13337 := by
  intro p hp
  have h : env13337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13336_13337 : H12AffineEnvironment.transform 11 2065 env13336 = env13337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env13336 == env13337) = true)

def env13338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89515,1024,29788,17729,21793,16,73857,8328,64,203847,5393,4097,223719,20700,21793,256,21792,16600,96010]

theorem envBound13338 : H12AffineFastState.Bounded env13338 := by
  intro p hp
  have h : env13338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13327_13338 : H12AffineEnvironment.transform 14 29789 env13327 = env13338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13327 == env13338) = true)

theorem identity13338 : scanCanonicalize (H12AffineFastState.compose env13338 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound13338 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env13339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,217,65536,131072,76079,1024,216,12741,8613,16,73857,8328,64,203847,5393,4097,204131,9304,8613,256,8612,13404,66446]

theorem envBound13339 : H12AffineFastState.Bounded env13339 := by
  intro p hp
  have h : env13339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13338_13339 : H12AffineEnvironment.transform 13 13444 env13338 = env13339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env13338 == env13339) = true)

def env13340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,65536,131072,76079,1024,80,12621,8493,16,73737,8192,64,203847,5393,4097,204131,9304,8493,256,8492,13404,66310]

theorem envBound13340 : H12AffineFastState.Bounded env13340 := by
  intro p hp
  have h : env13340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13339_13340 : H12AffineEnvironment.transform 6 8 env13339 = env13340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13339 == env13340) = true)

theorem identity13340 : scanCanonicalize (H12AffineFastState.compose env13340 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13340 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env13341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,8202,131072,2341,1024,80,12621,8493,16,3,8192,64,146509,5393,4097,146793,9304,8493,256,8492,13404,8972]

theorem envBound13341 : H12AffineFastState.Bounded env13341 := by
  intro p hp
  have h : env13341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13340_13341 : H12AffineEnvironment.transform 15 8202 env13340 = env13341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13340 == env13341) = true)

theorem identity13341 : scanCanonicalize (H12AffineFastState.compose env13341 (packedSelected [0,1,8,9,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound13341 : packedSelected [0,1,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env13342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,8202,5393,2341,1024,80,12621,8493,16,3,8192,64,10588,5393,4097,10360,9304,8493,256,8492,13404,8972]

theorem envBound13342 : H12AffineFastState.Bounded env13342 := by
  intro p hp
  have h : env13342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13341_13342 : H12AffineEnvironment.transform 16 5393 env13341 = env13342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env13341 == env13342) = true)

theorem identity13342 : scanCanonicalize (H12AffineFastState.compose env13342 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound13342 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env13343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,815,4096,8192,13324,81,8202,5393,522,1024,80,12621,8493,16,3,8192,64,8819,5393,4097,9047,9304,8493,256,8492,13404,8972]

theorem envBound13343 : H12AffineFastState.Bounded env13343 := by
  intro p hp
  have h : env13343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13342_13343 : H12AffineEnvironment.transform 10 815 env13342 = env13343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env13342 == env13343) = true)

theorem identity13343 : scanCanonicalize (H12AffineFastState.compose env13343 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound13343 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13344 : List Nat := [2,4,8,16,32,64,8,116,512,1024,603,4096,8192,13324,81,8202,5221,522,1024,80,12345,8281,16,3,8192,64,8819,5221,4097,8739,9304,8281,116,8280,13404,8824]

theorem envBound13344 : H12AffineFastState.Bounded env13344 := by
  intro p hp
  have h : env13344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13343_13344 : H12AffineEnvironment.transform 7 116 env13343 = env13344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env13343 == env13344) = true)

theorem identity13344 : scanCanonicalize (H12AffineFastState.compose env13344 (packedSelected [4,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound13344 : packedSelected [4,7,10,20] rootPS < 2^1333 := by decide +kernel

def env13345 : List Nat := [2,4,8,16,32,64,8,116,512,1024,603,4096,120,5236,81,114,5221,522,1024,80,4161,33,16,3,120,64,523,5221,4097,603,1056,33,116,32,5156,512]

theorem envBound13345 : H12AffineFastState.Bounded env13345 := by
  intro p hp
  have h : env13345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13344_13345 : H12AffineEnvironment.transform 12 120 env13344 = env13345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env13344 == env13345) = true)

theorem identity13345 : scanCanonicalize (H12AffineFastState.compose env13345 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound13345 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env13346 : List Nat := [2,4,8,16,32,48,8,4,512,1024,555,4096,8,5124,33,2,5141,522,1024,32,4145,33,16,3,8,48,523,5141,4097,555,1056,33,4,32,5156,512]

theorem envBound13346 : H12AffineFastState.Bounded env13346 := by
  intro p hp
  have h : env13346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13345_13346 : H12AffineEnvironment.transform 5 48 env13345 = env13346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env13345 == env13346) = true)

theorem identity13346 : scanCanonicalize (H12AffineFastState.compose env13346 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound13346 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13347 : List Nat := [2,4,8,16,32,48,8,4,512,575,555,4096,8,4667,33,2,4650,522,575,32,4145,33,16,3,8,48,523,4650,4097,555,543,33,4,32,4635,512]

theorem envBound13347 : H12AffineFastState.Bounded env13347 := by
  intro p hp
  have h : env13347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13346_13347 : H12AffineEnvironment.transform 9 575 env13346 = env13347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env13346 == env13347) = true)

theorem identity13347 : scanCanonicalize (H12AffineFastState.compose env13347 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 39) := by decide +kernel

theorem selectedBound13347 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env13348 : List Nat := [2,4,8,16,32,48,8,4,512,575,555,39,8,540,33,2,525,522,575,32,22,33,16,3,8,48,523,525,38,555,543,33,4,32,572,512]

theorem envBound13348 : H12AffineFastState.Bounded env13348 := by
  intro p hp
  have h : env13348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13347_13348 : H12AffineEnvironment.transform 11 39 env13347 = env13348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 39 env13347 == env13348) = true)

theorem identity13348 : scanCanonicalize (H12AffineFastState.compose env13348 (packedSelected [1,10] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound13348 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env13349 : List Nat := [2,4,8,16,32,48,8,4,11,52,32,39,8,23,33,2,6,1,52,32,22,33,16,3,8,48,0,6,38,32,20,33,4,32,55,11]

theorem envBound13349 : H12AffineFastState.Bounded env13349 := by
  intro p hp
  have h : env13349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13348_13349 : H12AffineEnvironment.transform 8 11 env13348 = env13349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env13348 == env13349) = true)

theorem identity13349 : scanCanonicalize (H12AffineFastState.compose env13349 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound13349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13350 : List Nat := [2,4,8,16,9,25,8,4,11,29,9,14,8,23,8,2,6,1,29,9,22,8,16,3,8,25,0,6,15,9,20,8,4,9,30,11]

theorem envBound13350 : H12AffineFastState.Bounded env13350 := by
  intro p hp
  have h : env13350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13349_13350 : H12AffineEnvironment.transform 4 9 env13349 = env13350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env13349 == env13350) = true)

theorem identity13350 : scanCanonicalize (H12AffineFastState.compose env13350 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound13350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13351 : List Nat := [2,4,8,6,9,15,8,4,11,11,9,14,8,1,8,2,6,1,11,9,0,8,6,3,8,15,0,6,15,9,2,8,4,9,8,11]

theorem envBound13351 : H12AffineFastState.Bounded env13351 := by
  intro p hp
  have h : env13351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13350_13351 : H12AffineEnvironment.transform 3 6 env13350 = env13351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env13350 == env13351) = true)

theorem identity13351 : scanCanonicalize (H12AffineFastState.compose env13351 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound13351 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13352 : List Nat := [2,4,1,6,0,6,1,4,2,2,0,7,1,1,1,2,6,1,2,0,0,1,6,3,1,6,0,6,6,0,2,1,4,0,1,2]

theorem envBound13352 : H12AffineFastState.Bounded env13352 := by
  intro p hp
  have h : env13352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13351_13352 : H12AffineEnvironment.transform 2 1 env13351 = env13352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env13351 == env13352) = true)

def env13353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,65536,131072,76079,1024,81,12620,8492,16,73736,8193,64,203847,5393,4097,204131,9304,8492,256,8493,13404,66311]

theorem envBound13353 : H12AffineFastState.Bounded env13353 := by
  intro p hp
  have h : env13353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13339_13353 : H12AffineEnvironment.transform 6 9 env13339 = env13353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13339 == env13353) = true)

theorem identity13353 : scanCanonicalize (H12AffineFastState.compose env13353 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound13353 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env13354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,65536,5221,76079,1024,81,12620,8492,16,73736,8193,64,67618,5393,4097,67846,9304,8492,256,8493,13404,66311]

theorem envBound13354 : H12AffineFastState.Bounded env13354 := by
  intro p hp
  have h : env13354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13353_13354 : H12AffineEnvironment.transform 16 5221 env13353 = env13354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env13353 == env13354) = true)

theorem identity13354 : scanCanonicalize (H12AffineFastState.compose env13354 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13354 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,8203,5221,2340,1024,81,12620,8492,16,3,8193,64,10281,5393,4097,10509,9304,8492,256,8493,13404,8972]

theorem envBound13355 : H12AffineFastState.Bounded env13355 := by
  intro p hp
  have h : env13355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13354_13355 : H12AffineEnvironment.transform 15 8203 env13354 = env13355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13354 == env13355) = true)

theorem identity13355 : scanCanonicalize (H12AffineFastState.compose env13355 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13355 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13356 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13325,80,8203,5221,2129,1024,81,12345,8281,16,3,8193,64,10281,5220,4097,10360,9304,8281,117,8280,13404,8825]

theorem envBound13356 : H12AffineFastState.Bounded env13356 := by
  intro p hp
  have h : env13356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13355_13356 : H12AffineEnvironment.transform 7 117 env13355 = env13356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13355 == env13356) = true)

theorem identity13356 : scanCanonicalize (H12AffineFastState.compose env13356 (packedSelected [4,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13356 : packedSelected [4,7,10,20] rootPS < 2^1333 := by decide +kernel

def env13357 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,80,35,5221,2129,1024,81,4113,113,16,3,41,64,2049,5220,4097,2128,1136,113,117,112,5236,593]

theorem envBound13357 : H12AffineFastState.Bounded env13357 := by
  intro p hp
  have h : env13357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13356_13357 : H12AffineEnvironment.transform 12 40 env13356 = env13357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13356 == env13357) = true)

theorem identity13357 : scanCanonicalize (H12AffineFastState.compose env13357 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13357 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env13358 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,35,5172,2048,1024,0,4113,32,16,3,41,17,2049,5173,4097,2049,1057,32,36,33,5157,512]

theorem envBound13358 : H12AffineFastState.Bounded env13358 := by
  intro p hp
  have h : env13358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13357_13358 : H12AffineEnvironment.transform 5 17 env13357 = env13358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13357 == env13358) = true)

theorem identity13358 : scanCanonicalize (H12AffineFastState.compose env13358 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13359 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,1,2,5141,2048,1024,0,4113,1,16,3,8,17,2049,5140,4097,2049,1024,1,5,0,5124,512]

theorem envBound13359 : H12AffineFastState.Bounded env13359 := by
  intro p hp
  have h : env13359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13358_13359 : H12AffineEnvironment.transform 4 1 env13358 = env13359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13358 == env13359) = true)

def env13360 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1044,1,2,1029,2048,1024,0,1,1,16,3,8,17,2049,1028,17,2049,1024,1,5,0,1044,512]

theorem envBound13360 : H12AffineFastState.Bounded env13360 := by
  intro p hp
  have h : env13360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13359_13360 : H12AffineEnvironment.transform 11 16 env13359 = env13360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13359 == env13360) = true)

def env13361 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1045,1,2,1028,2048,1024,0,0,1,16,3,8,17,2049,1029,16,2049,1024,1,5,0,1045,512]

theorem envBound13361 : H12AffineFastState.Bounded env13361 := by
  intro p hp
  have h : env13361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13359_13361 : H12AffineEnvironment.transform 11 17 env13359 = env13361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13359 == env13361) = true)

theorem identity13361 : scanCanonicalize (H12AffineFastState.compose env13361 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13362 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,0,1,2,17,2048,21,0,0,1,16,3,8,17,2049,16,16,2049,21,1,5,0,0,512]

theorem envBound13362 : H12AffineFastState.Bounded env13362 := by
  intro p hp
  have h : env13362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13361_13362 : H12AffineEnvironment.transform 9 21 env13361 = env13362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13361 == env13362) = true)

theorem identity13362 : scanCanonicalize (H12AffineFastState.compose env13362 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound13362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13363 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,5,9,0,1,2,5,2048,1,0,0,1,4,3,8,5,2049,4,4,2049,1,1,5,0,0,512]

theorem envBound13363 : H12AffineFastState.Bounded env13363 := by
  intro p hp
  have h : env13363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13362_13363 : H12AffineEnvironment.transform 3 4 env13362 = env13363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env13362 == env13363) = true)

def leafEnv13363 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,5,9,0,1,2,5,2048,1,0,0,1,4,3,1,8,1,5,2049,4,4,2049,1,1,5,0,4,3,0,512,1,0,0]

def active13363 : List Nat := [0,1,2,8,10]

def tree13363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13363 : H12WitnessSearch.Good tree13363 := H12GlobalWitnessIndex.good

theorem leafIdentity13363 : H12AffineFastState.composeSystem env13363 rootObs = leafEnv13363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13363 rootObs == leafEnv13363) = true)

theorem terminalChecked13363 : H12PackedTerminal.terminalCheckFast leafEnv13363 active13363 tree13363 = true := by decide +kernel

def env13364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62541,2188736,8328,64,410093,57676,2138397,406604,2102685,2101345,256,21792,46213,2175563]

theorem envBound13364 : H12AffineFastState.Bounded env13364 := by
  intro p hp
  have h : env13364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13298_13364 : H12AffineEnvironment.transform 21 2101345 env13298 = env13364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env13298 == env13364) = true)

def env13365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62541,73856,8328,64,410093,57676,58461,406604,20701,21793,256,21792,46213,96011]

theorem envBound13365 : H12AffineFastState.Bounded env13365 := by
  intro p hp
  have h : env13365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13364_13365 : H12AffineEnvironment.transform 20 17728 env13364 = env13365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env13364 == env13365) = true)

theorem identity13365 : scanCanonicalize (H12AffineFastState.compose env13365 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound13365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,17728,21793,152,73856,8328,64,410093,5529,4232,406604,20701,21793,256,21792,16464,96011]

theorem envBound13366 : H12AffineFastState.Bounded env13366 := by
  intro p hp
  have h : env13366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13365_13366 : H12AffineEnvironment.transform 14 29909 env13365 = env13366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env13365 == env13366) = true)

theorem identity13366 : scanCanonicalize (H12AffineFastState.compose env13366 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound13366 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env13367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,89514,1024,29908,17728,21793,152,73856,8328,64,203847,5529,4232,223718,20701,21793,256,21792,16464,96011]

theorem envBound13367 : H12AffineFastState.Bounded env13367 := by
  intro p hp
  have h : env13367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13366_13367 : H12AffineEnvironment.transform 17 89514 env13366 = env13367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env13366 == env13367) = true)

theorem identity13367 : scanCanonicalize (H12AffineFastState.compose env13367 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound13367 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29962,131072,10400,1024,29908,17728,21793,152,21898,8328,64,158029,5529,4232,138476,20701,21793,256,21792,16464,513]

theorem envBound13368 : H12AffineFastState.Bounded env13368 := by
  intro p hp
  have h : env13368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13367_13368 : H12AffineEnvironment.transform 15 29962 env13367 = env13368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env13367 == env13368) = true)

theorem identity13368 : scanCanonicalize (H12AffineFastState.compose env13368 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound13368 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env13369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,216,263,131072,10400,1024,217,12621,8492,152,8583,8328,64,138560,5529,4232,138476,9424,8492,256,8493,13405,513]

theorem envBound13369 : H12AffineFastState.Bounded env13369 := by
  intro p hp
  have h : env13369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13368_13369 : H12AffineEnvironment.transform 13 13325 env13368 = env13369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env13368 == env13369) = true)

theorem identity13369 : scanCanonicalize (H12AffineFastState.compose env13369 (packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5561) := by decide +kernel

theorem selectedBound13369 : packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env13370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,216,263,5561,10400,1024,217,12621,8492,152,8583,8328,64,2297,5529,4232,2389,9424,8492,256,8493,13405,513]

theorem envBound13370 : H12AffineFastState.Bounded env13370 := by
  intro p hp
  have h : env13370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13369_13370 : H12AffineEnvironment.transform 16 5561 env13369 = env13370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5561 env13369 == env13370) = true)

theorem identity13370 : scanCanonicalize (H12AffineFastState.compose env13370 (packedSelected [11,12,15,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound13370 : packedSelected [11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env13371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5545,216,263,5561,2308,1024,217,4329,136,152,35,300,64,2297,5529,4232,2389,1396,136,256,137,5625,513]

theorem envBound13371 : H12AffineFastState.Bounded env13371 := by
  intro p hp
  have h : env13371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13370_13371 : H12AffineEnvironment.transform 12 420 env13370 = env13371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env13370 == env13371) = true)

theorem identity13371 : scanCanonicalize (H12AffineFastState.compose env13371 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound13371 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env13372 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,5457,32,263,5441,2308,1024,33,4113,112,96,35,300,64,2049,5473,4208,2389,1396,112,256,113,5377,513]

theorem envBound13372 : H12AffineFastState.Bounded env13372 := by
  intro p hp
  have h : env13372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13371_13372 : H12AffineEnvironment.transform 6 120 env13371 = env13372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env13371 == env13372) = true)

def env13373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62541,73857,8328,64,410093,57676,58460,406604,20700,21792,256,21792,46213,96010]

theorem envBound13373 : H12AffineFastState.Bounded env13373 := by
  intro p hp
  have h : env13373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13364_13373 : H12AffineEnvironment.transform 20 17729 env13364 = env13373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env13364 == env13373) = true)

theorem identity13373 : scanCanonicalize (H12AffineFastState.compose env13373 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound13373 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,21792,16,73857,8328,64,410093,5393,4097,406604,20700,21792,256,21792,16600,96010]

theorem envBound13374 : H12AffineFastState.Bounded env13374 := by
  intro p hp
  have h : env13374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13373_13374 : H12AffineEnvironment.transform 14 29789 env13373 = env13374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13373 == env13374) = true)

def env13375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4161,32,16,73857,8328,64,398573,5393,4097,406604,1500,32,256,32,5592,74250]

theorem envBound13375 : H12AffineFastState.Bounded env13375 := by
  intro p hp
  have h : env13375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13374_13375 : H12AffineEnvironment.transform 13 5376 env13374 = env13375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13374 == env13375) = true)

theorem identity13375 : scanCanonicalize (H12AffineFastState.compose env13375 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13375 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4161,32,16,138,8328,64,398573,5393,4097,406604,1500,32,256,32,5592,513]

theorem envBound13376 : H12AffineFastState.Bounded env13376 := by
  intro p hp
  have h : env13376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13375_13376 : H12AffineEnvironment.transform 15 8203 env13375 = env13376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13375 == env13376) = true)

theorem identity13376 : scanCanonicalize (H12AffineFastState.compose env13376 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146913) := by decide +kernel

theorem selectedBound13376 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146913,1024,8540,4161,32,16,138,8328,64,10508,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound13377 : H12AffineFastState.Bounded env13377 := by
  intro p hp
  have h : env13377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13376_13377 : H12AffineEnvironment.transform 17 146913 env13376 = env13377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env13376 == env13377) = true)

theorem identity13377 : scanCanonicalize (H12AffineFastState.compose env13377 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound13377 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env13378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10481,1024,8540,4161,32,16,138,8328,64,10508,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound13378 : H12AffineFastState.Bounded env13378 := by
  intro p hp
  have h : env13378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13377_13378 : H12AffineEnvironment.transform 16 5392 env13377 = env13378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env13377 == env13378) = true)

theorem identity13378 : scanCanonicalize (H12AffineFastState.compose env13378 (packedSelected [0,3,4,7,8,9,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound13378 : packedSelected [0,3,4,7,8,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env13379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5376,372,34,5392,2264,1024,373,4161,32,16,138,161,64,2341,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound13379 : H12AffineFastState.Bounded env13379 := by
  intro p hp
  have h : env13379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13378_13379 : H12AffineEnvironment.transform 12 41 env13378 = env13379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env13378 == env13379) = true)

theorem identity13379 : scanCanonicalize (H12AffineFastState.compose env13379 (packedSelected [0,7,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound13379 : packedSelected [0,7,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env13380 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,5373,137,34,5357,2264,1024,136,4161,32,16,138,161,64,2264,5356,4097,2128,1057,32,253,32,5157,513]

theorem envBound13380 : H12AffineFastState.Bounded env13380 := by
  intro p hp
  have h : env13380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13379_13380 : H12AffineEnvironment.transform 7 253 env13379 = env13380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env13379 == env13380) = true)

theorem identity13380 : scanCanonicalize (H12AffineFastState.compose env13380 (packedSelected [0,4,5,7,8,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13380 : packedSelected [0,4,5,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env13381 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5236,0,34,5220,2129,1024,1,4161,32,16,3,40,64,2129,5221,4097,2128,1057,32,116,32,5157,513]

theorem envBound13381 : H12AffineFastState.Bounded env13381 := by
  intro p hp
  have h : env13381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13380_13381 : H12AffineEnvironment.transform 6 9 env13380 = env13381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13380 == env13381) = true)

theorem identity13381 : scanCanonicalize (H12AffineFastState.compose env13381 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13381 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13382 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,41,4112,0,34,4096,2129,100,1,4161,32,16,3,40,64,2129,4097,4097,2128,69,32,116,32,4161,513]

theorem envBound13382 : H12AffineFastState.Bounded env13382 := by
  intro p hp
  have h : env13382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13381_13382 : H12AffineEnvironment.transform 9 100 env13381 = env13382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13381 == env13382) = true)

theorem identity13382 : scanCanonicalize (H12AffineFastState.compose env13382 (packedSelected [1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound13382 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env13383 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2609,41,2593,0,34,2609,2129,100,1,2672,32,16,3,40,64,2129,2608,2608,2128,69,32,116,32,2672,513]

theorem envBound13383 : H12AffineFastState.Bounded env13383 := by
  intro p hp
  have h : env13383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13382_13383 : H12AffineEnvironment.transform 11 2609 env13382 = env13383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env13382 == env13383) = true)

theorem identity13383 : scanCanonicalize (H12AffineFastState.compose env13383 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13383 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env13384 : List Nat := [2,4,8,16,32,64,9,116,32,100,2048,2065,41,2049,0,34,2065,2129,100,1,2128,32,16,3,40,64,2129,2064,2064,2128,69,32,116,32,2128,33]

theorem envBound13384 : H12AffineFastState.Bounded env13384 := by
  intro p hp
  have h : env13384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13383_13384 : H12AffineEnvironment.transform 8 32 env13383 = env13384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13383 == env13384) = true)

theorem identity13384 : scanCanonicalize (H12AffineFastState.compose env13384 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13385 : List Nat := [2,4,8,16,32,17,9,37,32,53,2048,2065,41,2049,0,34,2065,2048,53,1,2049,32,16,3,40,17,2048,2064,2064,2049,20,32,37,32,2049,33]

theorem envBound13385 : H12AffineFastState.Bounded env13385 := by
  intro p hp
  have h : env13385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13384_13385 : H12AffineEnvironment.transform 5 17 env13384 = env13385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13384 == env13385) = true)

theorem identity13385 : scanCanonicalize (H12AffineFastState.compose env13385 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound13385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13386 : List Nat := [2,4,8,16,32,17,9,37,32,53,16,1,41,17,0,34,1,16,53,1,17,32,16,3,40,17,16,0,0,17,20,32,37,32,17,33]

theorem envBound13386 : H12AffineFastState.Bounded env13386 := by
  intro p hp
  have h : env13386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13385_13386 : H12AffineEnvironment.transform 10 16 env13385 = env13386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env13385 == env13386) = true)

theorem identity13386 : scanCanonicalize (H12AffineFastState.compose env13386 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13386 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13387 : List Nat := [2,4,8,16,1,17,9,4,1,20,16,1,8,17,0,3,1,16,20,1,17,1,16,3,9,17,16,0,0,17,20,1,4,1,17,0]

theorem envBound13387 : H12AffineFastState.Bounded env13387 := by
  intro p hp
  have h : env13387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13386_13387 : H12AffineEnvironment.transform 4 1 env13386 = env13387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13386 == env13387) = true)

theorem identity13387 : scanCanonicalize (H12AffineFastState.compose env13387 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13387 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13388 : List Nat := [2,4,8,0,1,1,9,4,1,4,0,1,8,1,0,3,1,0,4,1,1,1,0,3,9,1,0,0,0,1,4,1,4,1,1,0]

theorem envBound13388 : H12AffineFastState.Bounded env13388 := by
  intro p hp
  have h : env13388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13387_13388 : H12AffineEnvironment.transform 3 0 env13387 = env13388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13387 == env13388) = true)

def env13389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,33,16,73857,8328,64,398572,5393,4097,406604,1501,33,256,33,5593,74251]

theorem envBound13389 : H12AffineFastState.Bounded env13389 := by
  intro p hp
  have h : env13389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13374_13389 : H12AffineEnvironment.transform 13 5377 env13374 = env13389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13374 == env13389) = true)

theorem identity13389 : scanCanonicalize (H12AffineFastState.compose env13389 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound13389 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,262144,1024,8541,4160,33,16,3,8328,64,398572,5393,4097,406604,1501,33,256,33,5593,649]

theorem envBound13390 : H12AffineFastState.Bounded env13390 := by
  intro p hp
  have h : env13390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13389_13390 : H12AffineEnvironment.transform 15 8322 env13389 = env13390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env13389 == env13390) = true)

theorem identity13390 : scanCanonicalize (H12AffineFastState.compose env13390 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13390 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4160,33,16,3,8192,64,398436,5393,4097,406604,1365,33,256,33,5457,513]

theorem envBound13391 : H12AffineFastState.Bounded env13391 := by
  intro p hp
  have h : env13391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13390_13391 : H12AffineEnvironment.transform 6 8 env13390 = env13391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13390 == env13391) = true)

theorem identity13391 : scanCanonicalize (H12AffineFastState.compose env13391 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound13391 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,2421,1024,8541,4160,33,16,3,8192,64,138513,5393,4097,146745,1365,33,256,33,5457,513]

theorem envBound13392 : H12AffineFastState.Bounded env13392 := by
  intro p hp
  have h : env13392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13391_13392 : H12AffineEnvironment.transform 17 2421 env13391 = env13392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env13391 == env13392) = true)

def env13393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound13393 : H12AffineFastState.Bounded env13393 := by
  intro p hp
  have h : env13393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13236_13393 : H12AffineEnvironment.transform 18 1025 env13236 = env13393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13236 == env13393) = true)

theorem identity13393 : scanCanonicalize (H12AffineFastState.compose env13393 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262336) := by decide +kernel

theorem selectedBound13393 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262336,16777216,8328,64,23414080,18973837,184336,2377024,19071312,23160256,257,16990700,17014856,19015303]

theorem envBound13394 : H12AffineFastState.Bounded env13394 := by
  intro p hp
  have h : env13394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13393_13394 : H12AffineEnvironment.transform 22 2262336 env13393 = env13394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262336 env13393 == env13394) = true)

def env13395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262336,201932,8328,64,6705548,2265153,184336,2377024,2102684,6451468,257,21792,46212,2175563]

theorem envBound13395 : H12AffineFastState.Bounded env13395 := by
  intro p hp
  have h : env13395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13394_13395 : H12AffineEnvironment.transform 23 201932 env13394 = env13395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201932 env13394 == env13395) = true)

def env13396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603932,2098513,17664,2377024,2102684,6349852,257,21792,46212,2175563]

theorem envBound13396 : H12AffineFastState.Bounded env13396 := by
  intro p hp
  have h : env13396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13395_13396 : H12AffineEnvironment.transform 16 38160 env13395 = env13396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env13395 == env13396) = true)

def env13397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157596,2098513,17664,2377024,2102684,2411676,257,21792,46212,2175563]

theorem envBound13397 : H12AffineFastState.Bounded env13397 := by
  intro p hp
  have h : env13397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13396_13397 : H12AffineEnvironment.transform 21 272512 env13396 = env13397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13396 == env13397) = true)

def env13398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272392,2101328,98644,8192,64,2157596,2098513,17664,2377024,2102548,2411540,257,21792,46092,2175563]

theorem envBound13398 : H12AffineFastState.Bounded env13398 := by
  intro p hp
  have h : env13398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13397_13398 : H12AffineEnvironment.transform 6 8 env13397 = env13398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13397 == env13398) = true)

theorem identity13398 : scanCanonicalize (H12AffineFastState.compose env13398 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13398 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env13399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,2097152,272392,2101328,87125,8192,64,2111773,2098513,17664,2377024,2102548,2365717,257,21792,24845,2175563]

theorem envBound13399 : H12AffineFastState.Bounded env13399 := by
  intro p hp
  have h : env13399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13398_13399 : H12AffineEnvironment.transform 14 21761 env13398 = env13399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13398 == env13399) = true)

def env13400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,4160,272392,16,87125,8192,64,10589,5393,17664,283904,1364,264533,257,21792,24845,74251]

theorem envBound13400 : H12AffineFastState.Bounded env13400 := by
  intro p hp
  have h : env13400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13399_13400 : H12AffineEnvironment.transform 20 4160 env13399 = env13400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13399 == env13400) = true)

theorem identity13400 : scanCanonicalize (H12AffineFastState.compose env13400 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound13400 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21591,16401,262144,1025,21760,4160,272392,16,2,8192,64,10589,5393,17664,283904,1364,264533,257,21792,24845,30300]

theorem envBound13401 : H12AffineFastState.Bounded env13401 := by
  intro p hp
  have h : env13401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13400_13401 : H12AffineEnvironment.transform 15 21591 env13400 = env13401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env13400 == env13401) = true)

theorem identity13401 : scanCanonicalize (H12AffineFastState.compose env13401 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound13401 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env13402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21591,16401,2421,1025,21760,4160,8573,16,2,8192,64,10589,5393,17664,23669,1364,32,257,21792,24845,30300]

theorem envBound13402 : H12AffineFastState.Bounded env13402 := by
  intro p hp
  have h : env13402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13401_13402 : H12AffineEnvironment.transform 17 2421 env13401 = env13402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env13401 == env13402) = true)

theorem identity13402 : scanCanonicalize (H12AffineFastState.compose env13402 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound13402 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env13403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8312,8494,13672,2421,1025,8313,4160,8573,16,2,8192,64,10589,5393,12409,10508,1364,32,257,8281,5236,805]

theorem envBound13403 : H12AffineFastState.Bounded env13403 := by
  intro p hp
  have h : env13403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13402_13403 : H12AffineEnvironment.transform 13 13689 env13402 = env13403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env13402 == env13403) = true)

def env13404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,4161,272392,17,87125,8192,64,10588,5392,17664,283905,1365,264532,257,21792,24845,74250]

theorem envBound13404 : H12AffineFastState.Bounded env13404 := by
  intro p hp
  have h : env13404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13399_13404 : H12AffineEnvironment.transform 20 4161 env13399 = env13404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13399 == env13404) = true)

theorem identity13404 : scanCanonicalize (H12AffineFastState.compose env13404 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound13404 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,97407,1025,21760,4161,87159,17,87125,8192,64,10588,5392,17664,76158,1365,95531,257,21792,24845,74250]

theorem envBound13405 : H12AffineFastState.Bounded env13405 := by
  intro p hp
  have h : env13405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13404_13405 : H12AffineEnvironment.transform 17 97407 env13404 = env13405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env13404 == env13405) = true)

theorem identity13405 : scanCanonicalize (H12AffineFastState.compose env13405 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13405 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,16401,23669,1025,21760,4161,29821,17,29791,8192,64,10588,5392,17664,2420,1365,21793,257,21792,24845,512]

theorem envBound13406 : H12AffineFastState.Bounded env13406 := by
  intro p hp
  have h : env13406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13405_13406 : H12AffineEnvironment.transform 15 8202 env13405 = env13406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13405 == env13406) = true)

theorem identity13406 : scanCanonicalize (H12AffineFastState.compose env13406 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound13406 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,292,8202,5172,2128,1025,293,4161,8280,17,8314,8192,64,10588,5392,4389,2420,1365,260,257,261,13608,512]

theorem envBound13407 : H12AffineFastState.Bounded env13407 := by
  intro p hp
  have h : env13407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13406_13407 : H12AffineEnvironment.transform 13 5157 env13406 = env13407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env13406 == env13407) = true)

theorem identity13407 : scanCanonicalize (H12AffineFastState.compose env13407 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound13407 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env13408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2562,5157,292,2568,5172,2128,1025,293,4161,2650,17,2680,2562,64,862,5392,4389,2420,1365,260,257,261,7978,512]

theorem envBound13408 : H12AffineFastState.Bounded env13408 := by
  intro p hp
  have h : env13408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13407_13408 : H12AffineEnvironment.transform 12 2562 env13407 = env13408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env13407 == env13408) = true)

theorem identity13408 : scanCanonicalize (H12AffineFastState.compose env13408 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13408 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env13409 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,2562,5157,292,2568,5172,2049,1025,293,4112,2571,17,2601,2562,17,783,5392,4389,2341,1284,260,257,261,7978,512]

theorem envBound13409 : H12AffineFastState.Bounded env13409 := by
  intro p hp
  have h : env13409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13408_13409 : H12AffineEnvironment.transform 5 17 env13408 = env13409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13408 == env13409) = true)

theorem identity13409 : scanCanonicalize (H12AffineFastState.compose env13409 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound13409 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env13410 : List Nat := [2,4,8,16,32,17,8,256,512,1024,555,4096,41,5157,292,35,5172,554,1025,293,4112,32,17,2,41,17,783,5392,4389,782,1284,260,257,261,5377,512]

theorem envBound13410 : H12AffineFastState.Bounded env13410 := by
  intro p hp
  have h : env13410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13409_13410 : H12AffineEnvironment.transform 10 555 env13409 = env13410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env13409 == env13410) = true)

theorem identity13410 : scanCanonicalize (H12AffineFastState.compose env13410 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13410 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13411 : List Nat := [2,4,8,16,0,17,8,256,512,1024,523,4096,9,5125,260,3,5140,522,1025,261,4112,0,17,2,9,17,783,5392,4357,782,1284,260,257,261,5377,512]

theorem envBound13411 : H12AffineFastState.Bounded env13411 := by
  intro p hp
  have h : env13411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13410_13411 : H12AffineEnvironment.transform 4 0 env13410 = env13411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13410 == env13411) = true)

def env13412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272393,2101328,98645,8193,64,2157596,2098513,17664,2377024,2102549,2411541,257,21792,46093,2175563]

theorem envBound13412 : H12AffineFastState.Bounded env13412 := by
  intro p hp
  have h : env13412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13397_13412 : H12AffineEnvironment.transform 6 9 env13397 = env13412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13397 == env13412) = true)

theorem identity13412 : scanCanonicalize (H12AffineFastState.compose env13412 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound13412 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env13413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77898,272393,73754,98645,8193,64,121942,79131,17664,357642,75103,392287,257,21792,46093,513]

theorem envBound13413 : H12AffineFastState.Bounded env13413 := by
  intro p hp
  have h : env13413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13412_13413 : H12AffineEnvironment.transform 20 77898 env13412 = env13413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env13412 == env13413) = true)

def env13414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,77898,33,73754,98645,8193,64,121942,79131,17664,89378,75103,119927,257,21792,46093,513]

theorem envBound13414 : H12AffineFastState.Bounded env13414 := by
  intro p hp
  have h : env13414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13413_13414 : H12AffineEnvironment.transform 17 10280 env13413 = env13414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13413 == env13414) = true)

theorem identity13414 : scanCanonicalize (H12AffineFastState.compose env13414 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13414 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env13415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,38160,2420,1025,32769,69910,33,65862,98645,349,64,121942,70727,17664,89378,66563,119927,257,21792,38225,513]

theorem envBound13415 : H12AffineFastState.Bounded env13415 := by
  intro p hp
  have h : env13415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13414_13415 : H12AffineEnvironment.transform 12 348 env13414 = env13415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13414 == env13415) = true)

theorem identity13415 : scanCanonicalize (H12AffineFastState.compose env13415 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13415 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,16401,2420,1025,21760,69910,33,65862,87124,349,64,67927,70727,17664,89378,66563,65910,257,21792,16464,513]

theorem envBound13416 : H12AffineFastState.Bounded env13416 := by
  intro p hp
  have h : env13416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13415_13416 : H12AffineEnvironment.transform 14 21761 env13415 = env13416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13415 == env13416) = true)

theorem identity13416 : scanCanonicalize (H12AffineFastState.compose env13416 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13416 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,5393,2420,1025,0,69910,33,65862,65876,349,64,67927,70727,4096,67618,66563,65910,257,32,5456,513]

theorem envBound13417 : H12AffineFastState.Bounded env13417 := by
  intro p hp
  have h : env13417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13416_13417 : H12AffineEnvironment.transform 13 5376 env13416 = env13417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13416 == env13417) = true)

theorem identity13417 : scanCanonicalize (H12AffineFastState.compose env13417 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound13417 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5393,2420,1025,0,4161,33,17,3,349,64,2048,5392,4096,2421,1364,33,257,32,5456,513]

theorem envBound13418 : H12AffineFastState.Bounded env13418 := by
  intro p hp
  have h : env13418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13417_13418 : H12AffineEnvironment.transform 15 343 env13417 = env13418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env13417 == env13418) = true)

theorem identity13418 : scanCanonicalize (H12AffineFastState.compose env13418 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound13418 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2415,348,3183,1,343,3198,2420,1025,0,2350,33,17,3,349,64,2048,3199,2415,2421,1364,33,257,32,3135,513]

theorem envBound13419 : H12AffineFastState.Bounded env13419 := by
  intro p hp
  have h : env13419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13418_13419 : H12AffineEnvironment.transform 11 2415 env13418 = env13419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env13418 == env13419) = true)

theorem identity13419 : scanCanonicalize (H12AffineFastState.compose env13419 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound13419 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13420 : List Nat := [2,4,8,16,32,64,9,256,512,266,2048,2415,348,2405,1,343,2420,2420,267,0,2350,33,17,3,349,64,2048,2421,2415,2421,94,33,257,32,2357,513]

theorem envBound13420 : H12AffineFastState.Bounded env13420 := by
  intro p hp
  have h : env13420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13419_13420 : H12AffineEnvironment.transform 9 266 env13419 = env13420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env13419 == env13420) = true)

theorem identity13420 : scanCanonicalize (H12AffineFastState.compose env13420 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13420 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13421 : List Nat := [2,4,8,16,1,64,9,256,512,266,2048,2382,348,2372,1,343,2389,2389,267,0,2319,0,17,3,349,64,2048,2388,2382,2388,94,0,257,1,2324,513]

theorem envBound13421 : H12AffineFastState.Bounded env13421 := by
  intro p hp
  have h : env13421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13420_13421 : H12AffineEnvironment.transform 4 1 env13420 = env13421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13420 == env13421) = true)

theorem identity13421 : scanCanonicalize (H12AffineFastState.compose env13421 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13421 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13422 : List Nat := [2,4,8,16,1,16,9,256,512,266,2048,2334,268,2324,1,263,2309,2309,267,0,2319,0,17,3,269,16,2048,2308,2334,2308,14,0,257,1,2324,513]

theorem envBound13422 : H12AffineFastState.Bounded env13422 := by
  intro p hp
  have h : env13422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13421_13422 : H12AffineEnvironment.transform 5 16 env13421 = env13422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13421 == env13422) = true)

theorem identity13422 : scanCanonicalize (H12AffineFastState.compose env13422 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound13422 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13423 : List Nat := [2,4,8,16,1,16,9,14,512,4,2048,2064,2,2074,1,9,2059,2059,5,0,2049,0,17,3,3,16,2048,2058,2064,2058,14,0,15,1,2074,513]

theorem envBound13423 : H12AffineFastState.Bounded env13423 := by
  intro p hp
  have h : env13423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13422_13423 : H12AffineEnvironment.transform 7 14 env13422 = env13423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env13422 == env13423) = true)

theorem identity13423 : scanCanonicalize (H12AffineFastState.compose env13423 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound13423 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13424 : List Nat := [2,4,8,16,1,16,9,14,16,4,2048,2064,2,2074,1,9,2059,2059,5,0,2049,0,17,3,3,16,2048,2058,2064,2058,14,0,15,1,2074,17]

theorem envBound13424 : H12AffineFastState.Bounded env13424 := by
  intro p hp
  have h : env13424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13423_13424 : H12AffineEnvironment.transform 8 16 env13423 = env13424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env13423 == env13424) = true)

theorem identity13424 : scanCanonicalize (H12AffineFastState.compose env13424 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound13424 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13425 : List Nat := [2,4,8,16,1,16,9,14,16,4,26,10,2,0,1,9,17,17,5,0,27,0,17,3,3,16,26,16,10,16,14,0,15,1,0,17]

theorem envBound13425 : H12AffineFastState.Bounded env13425 := by
  intro p hp
  have h : env13425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13424_13425 : H12AffineEnvironment.transform 10 26 env13424 = env13425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env13424 == env13425) = true)

theorem identity13425 : scanCanonicalize (H12AffineFastState.compose env13425 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13425 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13426 : List Nat := [2,2,8,16,1,16,9,8,16,2,26,10,2,0,1,9,17,17,3,0,27,0,17,3,3,16,26,16,10,16,8,0,9,1,0,17]

theorem envBound13426 : H12AffineFastState.Bounded env13426 := by
  intro p hp
  have h : env13426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13425_13426 : H12AffineEnvironment.transform 1 2 env13425 = env13426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13425 == env13426) = true)

theorem identity13426 : scanCanonicalize (H12AffineFastState.compose env13426 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound13426 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env13427 : List Nat := [2,2,8,11,1,11,9,8,11,2,1,10,2,0,1,9,10,10,3,0,0,0,10,3,3,11,1,11,10,11,8,0,9,1,0,10]

theorem envBound13427 : H12AffineFastState.Bounded env13427 := by
  intro p hp
  have h : env13427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13426_13427 : H12AffineEnvironment.transform 3 11 env13426 = env13427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env13426 == env13427) = true)

theorem identity13427 : scanCanonicalize (H12AffineFastState.compose env13427 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound13427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13428 : List Nat := [0,0,8,9,1,9,9,8,9,0,1,8,0,0,1,9,8,8,1,0,0,0,8,1,1,9,1,9,8,9,8,0,9,1,0,8]

theorem envBound13428 : H12AffineFastState.Bounded env13428 := by
  intro p hp
  have h : env13428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13427_13428 : H12AffineEnvironment.transform 0 0 env13427 = env13428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env13427 == env13428) = true)

def env13429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,77898,32,73754,98645,8193,64,121942,79131,17664,89379,75103,119926,257,21792,46093,513]

theorem envBound13429 : H12AffineFastState.Bounded env13429 := by
  intro p hp
  have h : env13429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13413_13429 : H12AffineEnvironment.transform 17 10281 env13413 = env13429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13413 == env13429) = true)

theorem identity13429 : scanCanonicalize (H12AffineFastState.compose env13429 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13429 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1025,32769,4160,32,16,41311,8193,64,64604,5393,17664,32041,1365,62588,257,21792,46093,513]

theorem envBound13430 : H12AffineFastState.Bounded env13430 := by
  intro p hp
  have h : env13430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13429_13430 : H12AffineEnvironment.transform 15 8202 env13429 = env13430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13429 == env13430) = true)

theorem identity13430 : scanCanonicalize (H12AffineFastState.compose env13430 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound13430 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,32768,3142,38160,1125,1025,32769,4160,32,16,36115,3149,64,53264,5393,17664,20837,1365,55344,257,21792,38977,513]

theorem envBound13431 : H12AffineFastState.Bounded env13431 := by
  intro p hp
  have h : env13431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13430_13431 : H12AffineEnvironment.transform 12 3148 env13430 = env13431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env13430 == env13431) = true)

theorem identity13431 : scanCanonicalize (H12AffineFastState.compose env13431 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13431 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,21761,3142,16401,1125,1025,21760,4160,32,16,22546,3149,64,1297,5393,17664,20837,1365,3377,257,21792,19776,513]

theorem envBound13432 : H12AffineFastState.Bounded env13432 := by
  intro p hp
  have h : env13432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13431_13432 : H12AffineEnvironment.transform 14 21761 env13431 = env13432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13431 == env13432) = true)

theorem identity13432 : scanCanonicalize (H12AffineFastState.compose env13432 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound13432 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,16384,21761,343,16401,1125,1025,21760,4160,32,16,21763,348,64,1297,5393,17664,20837,1365,32,257,21792,16465,513]

theorem envBound13433 : H12AffineFastState.Bounded env13433 := by
  intro p hp
  have h : env13433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13432_13433 : H12AffineEnvironment.transform 10 1297 env13432 = env13433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env13432 == env13433) = true)

theorem identity13433 : scanCanonicalize (H12AffineFastState.compose env13433 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound13433 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,4405,1076,343,4388,1125,1025,1077,4160,32,16,1078,348,64,1297,5393,5173,80,1365,32,257,1045,4452,513]

theorem envBound13434 : H12AffineFastState.Bounded env13434 := by
  intro p hp
  have h : env13434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13433_13434 : H12AffineEnvironment.transform 13 4405 env13433 = env13434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env13433 == env13434) = true)

theorem identity13434 : scanCanonicalize (H12AffineFastState.compose env13434 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13434 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env13435 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1124,4096,40,4160,1076,34,4177,1125,1025,1077,4160,32,16,1078,41,64,1124,5220,5173,80,1056,32,116,1045,4113,513]

theorem envBound13435 : H12AffineFastState.Bounded env13435 := by
  intro p hp
  have h : env13435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13434_13435 : H12AffineEnvironment.transform 7 117 env13434 = env13435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13434 == env13435) = true)

theorem identity13435 : scanCanonicalize (H12AffineFastState.compose env13435 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13435 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env13436 : List Nat := [2,4,8,16,32,64,9,117,512,101,1,4096,40,4160,81,34,4177,0,100,80,4160,32,16,83,41,64,1,4097,4176,80,69,32,116,112,4113,513]

theorem envBound13436 : H12AffineFastState.Bounded env13436 := by
  intro p hp
  have h : env13436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13435_13436 : H12AffineEnvironment.transform 9 101 env13435 = env13436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13435 == env13436) = true)

theorem identity13436 : scanCanonicalize (H12AffineFastState.compose env13436 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13436 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13437 : List Nat := [2,4,8,16,32,64,9,117,512,101,1,17,40,81,81,34,64,0,100,80,81,32,16,83,41,64,1,16,65,80,69,32,116,112,0,513]

theorem envBound13437 : H12AffineFastState.Bounded env13437 := by
  intro p hp
  have h : env13437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13436_13437 : H12AffineEnvironment.transform 11 17 env13436 = env13437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13436 == env13437) = true)

def env13438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157597,2098513,17664,2377024,2102684,2411677,257,21792,46212,2175563]

theorem envBound13438 : H12AffineFastState.Bounded env13438 := by
  intro p hp
  have h : env13438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13396_13438 : H12AffineEnvironment.transform 21 272513 env13396 = env13438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13396 == env13438) = true)

theorem identity13438 : scanCanonicalize (H12AffineFastState.compose env13438 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound13438 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272513,17,98780,8328,64,64604,5392,17664,283905,1501,318684,257,21792,46212,74250]

theorem envBound13439 : H12AffineFastState.Bounded env13439 := by
  intro p hp
  have h : env13439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13438_13439 : H12AffineEnvironment.transform 20 4161 env13438 = env13439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13438 == env13439) = true)

theorem identity13439 : scanCanonicalize (H12AffineFastState.compose env13439 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13439 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4161,272513,17,41431,8328,64,64604,5392,17664,283905,1501,318684,257,21792,46212,513]

theorem envBound13440 : H12AffineFastState.Bounded env13440 := by
  intro p hp
  have h : env13440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13439_13440 : H12AffineEnvironment.transform 15 8203 env13439 = env13440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13439 == env13440) = true)

def env13441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603933,2098512,17665,2377024,2102684,6349853,257,21792,46212,2175563]

theorem envBound13441 : H12AffineFastState.Bounded env13441 := by
  intro p hp
  have h : env13441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13395_13441 : H12AffineEnvironment.transform 16 38161 env13395 = env13441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13395 == env13441) = true)

def env13442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157597,2098512,17665,2377024,2102684,2411677,257,21792,46212,2175563]

theorem envBound13442 : H12AffineFastState.Bounded env13442 := by
  intro p hp
  have h : env13442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13441_13442 : H12AffineEnvironment.transform 21 272512 env13441 = env13442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13441 == env13442) = true)

theorem identity13442 : scanCanonicalize (H12AffineFastState.compose env13442 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound13442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25028,262144,1025,29908,2097152,272512,2101329,95496,8328,64,2103496,2098512,17665,2377024,2102684,2373704,257,21792,16465,2175563]

theorem envBound13443 : H12AffineFastState.Bounded env13443 := by
  intro p hp
  have h : env13443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13442_13443 : H12AffineEnvironment.transform 14 29909 env13442 = env13443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env13442 == env13443) = true)

def env13444 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,2097152,272512,2101249,95496,8328,16,2103448,2098432,17665,2376976,2102684,2373656,257,21792,16385,2175515]

theorem envBound13444 : H12AffineFastState.Bounded env13444 := by
  intro p hp
  have h : env13444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13443_13444 : H12AffineEnvironment.transform 5 16 env13443 = env13444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13443 == env13444) = true)

theorem identity13444 : scanCanonicalize (H12AffineFastState.compose env13444 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound13444 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env13445 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,17681,272512,21776,95496,8328,16,23945,16401,17665,262145,20621,294153,257,21792,16385,96010]

theorem envBound13445 : H12AffineFastState.Bounded env13445 := by
  intro p hp
  have h : env13445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13444_13445 : H12AffineEnvironment.transform 20 17681 env13444 = env13445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env13444 == env13445) = true)

theorem identity13445 : scanCanonicalize (H12AffineFastState.compose env13445 (packedSelected [0,9,10,14,16,19,20,22,26,27,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13445 : packedSelected [0,9,10,14,16,19,20,22,26,27,31,35] rootPS < 2^1333 := by decide +kernel

def env13446 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,10280,1025,29828,17681,168,21776,95496,8328,16,23945,16401,17665,10281,20621,21793,257,21792,16385,96010]

theorem envBound13446 : H12AffineFastState.Bounded env13446 := by
  intro p hp
  have h : env13446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13445_13446 : H12AffineEnvironment.transform 17 10280 env13445 = env13446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13445 == env13446) = true)

theorem identity13446 : scanCanonicalize (H12AffineFastState.compose env13446 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound13446 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13447 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,30082,24980,10280,1025,29828,17681,168,21776,138,8328,16,23945,16401,17665,10281,20621,21793,257,21792,16385,648]

theorem envBound13447 : H12AffineFastState.Bounded env13447 := by
  intro p hp
  have h : env13447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13446_13447 : H12AffineEnvironment.transform 15 30082 env13446 = env13447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env13446 == env13447) = true)

theorem identity13447 : scanCanonicalize (H12AffineFastState.compose env13447 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13447 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env13448 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21897,21646,16536,2340,1025,21896,17681,168,21776,138,388,16,23945,16401,17665,2341,20621,21793,257,21792,16385,648]

theorem envBound13448 : H12AffineFastState.Bounded env13448 := by
  intro p hp
  have h : env13448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13447_13448 : H12AffineEnvironment.transform 12 268 env13447 = env13448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13447 == env13448) = true)

theorem identity13448 : scanCanonicalize (H12AffineFastState.compose env13448 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound13448 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13449 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,1,262,5392,2340,1025,0,4249,168,152,138,388,16,2049,5529,4233,2341,1285,169,257,168,5513,648]

theorem envBound13449 : H12AffineFastState.Bounded env13449 := by
  intro p hp
  have h : env13449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13448_13449 : H12AffineEnvironment.transform 13 5512 env13448 = env13449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env13448 == env13449) = true)

theorem identity13449 : scanCanonicalize (H12AffineFastState.compose env13449 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13449 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13450 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1025,0,4113,32,16,2,268,16,2049,5393,4097,2341,1285,33,257,32,5377,512]

theorem envBound13450 : H12AffineFastState.Bounded env13450 := by
  intro p hp
  have h : env13450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13449_13450 : H12AffineEnvironment.transform 6 8 env13449 = env13450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13449 == env13450) = true)

theorem identity13450 : scanCanonicalize (H12AffineFastState.compose env13450 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound13450 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13451 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,4145,1,262,4129,2340,304,0,4113,32,16,2,268,16,2049,4128,4097,2341,52,33,257,32,4144,512]

theorem envBound13451 : H12AffineFastState.Bounded env13451 := by
  intro p hp
  have h : env13451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13450_13451 : H12AffineEnvironment.transform 9 305 env13450 = env13451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env13450 == env13451) = true)

theorem identity13451 : scanCanonicalize (H12AffineFastState.compose env13451 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13452 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,4113,1,262,4097,2308,272,0,4113,0,16,2,268,16,2049,4096,4097,2309,20,1,257,0,4112,512]

theorem envBound13452 : H12AffineFastState.Bounded env13452 := by
  intro p hp
  have h : env13452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13451_13452 : H12AffineEnvironment.transform 4 0 env13451 = env13452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13451 == env13452) = true)

theorem identity13452 : scanCanonicalize (H12AffineFastState.compose env13452 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound13452 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13453 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,277,268,260,1,262,276,2308,272,0,260,0,16,2,268,16,2049,277,276,2309,20,1,257,0,261,512]

theorem envBound13453 : H12AffineFastState.Bounded env13453 := by
  intro p hp
  have h : env13453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13452_13453 : H12AffineEnvironment.transform 11 277 env13452 = env13453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env13452 == env13453) = true)

theorem identity13453 : scanCanonicalize (H12AffineFastState.compose env13453 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound13453 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13454 : List Nat := [2,4,8,16,0,16,8,256,512,273,261,277,268,260,1,262,276,1,272,0,260,0,16,2,268,16,260,277,276,0,20,1,257,0,261,512]

theorem envBound13454 : H12AffineFastState.Bounded env13454 := by
  intro p hp
  have h : env13454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13453_13454 : H12AffineEnvironment.transform 10 261 env13453 = env13454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env13453 == env13454) = true)

def env13455 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,262144,1025,29829,2097152,272512,2101248,95496,8328,17,2103449,2098433,17665,2376977,2102684,2373657,257,21792,16384,2175514]

theorem envBound13455 : H12AffineFastState.Bounded env13455 := by
  intro p hp
  have h : env13455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13443_13455 : H12AffineEnvironment.transform 5 17 env13443 = env13455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13443 == env13455) = true)

theorem identity13455 : scanCanonicalize (H12AffineFastState.compose env13455 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13455 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env13456 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,24861,262144,1025,29709,2097152,272392,2101248,95496,8192,17,2103313,2098433,17665,2376977,2102548,2373657,257,21792,16384,2175514]

theorem envBound13456 : H12AffineFastState.Bounded env13456 := by
  intro p hp
  have h : env13456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13455_13456 : H12AffineEnvironment.transform 6 8 env13455 = env13456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13455 == env13456) = true)

theorem identity13456 : scanCanonicalize (H12AffineFastState.compose env13456 (packedSelected [0,1,3,5,7,9,12,14,15,16,17,22,26,28] rootPS)) = affineNative (2^(20+1) ^^^ 347158) := by decide +kernel

theorem selectedBound13456 : packedSelected [0,1,3,5,7,9,12,14,15,16,17,22,26,28] rootPS < 2^1333 := by decide +kernel

def env13457 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,24861,262144,1025,29709,347158,272392,351254,95496,8192,17,349191,346391,17665,67847,350466,95247,257,21792,16384,294412]

theorem envBound13457 : H12AffineFastState.Bounded env13457 := by
  intro p hp
  have h : env13457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13456_13457 : H12AffineEnvironment.transform 20 347158 env13456 = env13457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347158 env13456 == env13457) = true)

theorem identity13457 : scanCanonicalize (H12AffineFastState.compose env13457 (packedSelected [2,3,6,7,9,10,11,16,17,18,19,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound13457 : packedSelected [2,3,6,7,9,10,11,16,17,18,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env13458 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,263,24861,262144,1025,29709,281873,272392,285969,29711,8192,17,283904,280592,17665,2048,284677,29960,257,21792,16384,294412]

theorem envBound13458 : H12AffineFastState.Bounded env13458 := by
  intro p hp
  have h : env13458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13457_13458 : H12AffineEnvironment.transform 15 263 env13457 = env13458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env13457 == env13458) = true)

theorem identity13458 : scanCanonicalize (H12AffineFastState.compose env13458 (packedSelected [1,8,12,15,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound13458 : packedSelected [1,8,12,15,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env13459 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,16384,21541,263,16692,262144,1025,21540,281873,264225,285969,21542,41,17,283904,280592,17665,2048,284677,21793,257,21792,16384,286245]

theorem envBound13459 : H12AffineFastState.Bounded env13459 := by
  intro p hp
  have h : env13459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13458_13459 : H12AffineEnvironment.transform 12 41 env13458 = env13459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env13458 == env13459) = true)

theorem identity13459 : scanCanonicalize (H12AffineFastState.compose env13459 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13459 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13460 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21541,35,16400,262144,1025,21540,281653,264225,285749,21542,41,17,283684,280592,17445,2048,284677,21509,37,21508,16384,286245]

theorem envBound13460 : H12AffineFastState.Bounded env13460 := by
  intro p hp
  have h : env13460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13459_13460 : H12AffineEnvironment.transform 7 36 env13459 = env13460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13459 == env13460) = true)

theorem identity13460 : scanCanonicalize (H12AffineFastState.compose env13460 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound13460 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env13461 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21541,35,16400,23589,1025,21540,4112,21508,16,21542,41,17,2049,5173,17445,2048,1056,21509,37,21508,16384,512]

theorem envBound13461 : H12AffineFastState.Bounded env13461 := by
  intro p hp
  have h : env13461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13460_13461 : H12AffineEnvironment.transform 17 23589 env13460 = env13461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env13460 == env13461) = true)

theorem identity13461 : scanCanonicalize (H12AffineFastState.compose env13461 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13461 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env13462 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,8,16384,21508,2,16400,23556,1025,21509,4112,21508,16,21511,8,17,2049,5140,17412,2048,1025,21509,4,21508,16384,512]

theorem envBound13462 : H12AffineFastState.Bounded env13462 := by
  intro p hp
  have h : env13462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13461_13462 : H12AffineEnvironment.transform 4 1 env13461 = env13462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13461 == env13462) = true)

theorem identity13462 : scanCanonicalize (H12AffineFastState.compose env13462 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound13462 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13463 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,8,5125,1,2,5141,2049,1025,0,4112,1,16,2,8,17,2049,5140,4097,2048,1025,0,4,1,5125,512]

theorem envBound13463 : H12AffineFastState.Bounded env13463 := by
  intro p hp
  have h : env13463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13462_13463 : H12AffineEnvironment.transform 13 5125 env13462 = env13463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env13462 == env13463) = true)

def env13464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157596,2098512,17665,2377024,2102684,2411676,257,21792,46212,2175563]

theorem envBound13464 : H12AffineFastState.Bounded env13464 := by
  intro p hp
  have h : env13464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13441_13464 : H12AffineEnvironment.transform 21 272513 env13441 = env13464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13441 == env13464) = true)

theorem identity13464 : scanCanonicalize (H12AffineFastState.compose env13464 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound13464 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58517,272513,62660,98781,8328,64,2185,57797,17665,303573,61705,272393,257,21792,46212,120542]

theorem envBound13465 : H12AffineFastState.Bounded env13465 := by
  intro p hp
  have h : env13465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13464_13465 : H12AffineEnvironment.transform 20 58517 env13464 = env13465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env13464 == env13465) = true)

def env13466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,58517,169,62660,98781,8328,64,2185,57797,17665,35325,61705,33,257,21792,46212,120542]

theorem envBound13466 : H12AffineFastState.Bounded env13466 := by
  intro p hp
  have h : env13466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13465_13466 : H12AffineEnvironment.transform 17 10280 env13465 = env13466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13465 == env13466) = true)

theorem identity13466 : scanCanonicalize (H12AffineFastState.compose env13466 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound13466 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env13467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13508,10280,1025,8660,17728,169,21777,73736,8328,64,2185,16400,17665,10280,20700,33,257,21792,5457,96011]

theorem envBound13467 : H12AffineFastState.Bounded env13467 := by
  intro p hp
  have h : env13467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13466_13467 : H12AffineEnvironment.transform 14 8661 env13466 = env13467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env13466 == env13467) = true)

theorem identity13467 : scanCanonicalize (H12AffineFastState.compose env13467 (packedSelected [0,1,2,4,6,8,9,11,18,19,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13467 : packedSelected [0,1,2,4,6,8,9,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env13468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,13508,10280,1025,8660,17728,169,21777,2,8328,64,2185,16400,17665,10280,20700,33,257,21792,5457,22273]

theorem envBound13468 : H12AffineFastState.Bounded env13468 := by
  intro p hp
  have h : env13468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13467_13468 : H12AffineEnvironment.transform 15 8202 env13467 = env13468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13467 == env13468) = true)

theorem identity13468 : scanCanonicalize (H12AffineFastState.compose env13468 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound13468 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env13469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,300,16384,249,294,5608,2308,1025,248,17728,169,21777,2,420,64,2185,16400,17665,2308,20700,33,257,21792,5457,22273]

theorem envBound13469 : H12AffineFastState.Bounded env13469 := by
  intro p hp
  have h : env13469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13468_13469 : H12AffineEnvironment.transform 12 300 env13468 = env13469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env13468 == env13469) = true)

theorem identity13469 : scanCanonicalize (H12AffineFastState.compose env13469 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5544) := by decide +kernel

theorem selectedBound13469 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,300,5544,249,294,5608,2308,1025,248,4328,169,185,2,420,64,2185,5560,4265,2308,1396,33,257,136,5457,681]

theorem envBound13470 : H12AffineFastState.Bounded env13470 := by
  intro p hp
  have h : env13470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13469_13470 : H12AffineEnvironment.transform 13 5544 env13469 = env13470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5544 env13469 == env13470) = true)

theorem identity13470 : scanCanonicalize (H12AffineFastState.compose env13470 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound13470 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env13471 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,300,5376,81,294,5440,2308,1025,80,4160,1,17,2,268,64,2081,5392,4097,2308,1396,33,257,32,5457,513]

theorem envBound13471 : H12AffineFastState.Bounded env13471 := by
  intro p hp
  have h : env13471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13470_13471 : H12AffineEnvironment.transform 6 40 env13470 = env13471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13470 == env13471) = true)

theorem identity13471 : scanCanonicalize (H12AffineFastState.compose env13471 (packedSelected [1,2,3,4,5,7,8,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound13471 : packedSelected [1,2,3,4,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env13472 : List Nat := [2,4,8,16,32,64,40,256,512,612,2048,4096,300,4964,81,294,4900,2308,613,80,4160,1,17,2,268,64,2081,4980,4097,2308,784,33,257,32,4917,513]

theorem envBound13472 : H12AffineFastState.Bounded env13472 := by
  intro p hp
  have h : env13472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13471_13472 : H12AffineEnvironment.transform 9 612 env13471 = env13472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env13471 == env13472) = true)

def env13473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,58517,168,62660,98781,8328,64,2185,57797,17665,35324,61705,32,257,21792,46212,120542]

theorem envBound13473 : H12AffineFastState.Bounded env13473 := by
  intro p hp
  have h : env13473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13465_13473 : H12AffineEnvironment.transform 17 10281 env13465 = env13473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13465 == env13473) = true)

theorem identity13473 : scanCanonicalize (H12AffineFastState.compose env13473 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound13473 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env13474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,65536,38161,10281,1025,32769,45161,168,41016,98781,8328,64,2185,46393,4605,35324,42485,32,257,476,46212,98850]

theorem envBound13474 : H12AffineFastState.Bounded env13474 := by
  intro p hp
  have h : env13474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13473_13474 : H12AffineEnvironment.transform 13 5372 env13473 = env13474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env13473 == env13474) = true)

theorem identity13474 : scanCanonicalize (H12AffineFastState.compose env13474 (packedSelected [2,4,6,7,8,10,11,12,14,15,16,17,18,19,20,22,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound13474 : packedSelected [2,4,6,7,8,10,11,12,14,15,16,17,18,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env13475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8312,65536,13673,10281,1025,8313,4113,168,64,74149,8328,64,2185,5441,4605,10628,1421,32,257,476,5372,74330]

theorem envBound13475 : H12AffineFastState.Bounded env13475 := by
  intro p hp
  have h : env13475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13474_13475 : H12AffineEnvironment.transform 14 8312 env13474 = env13475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env13474 == env13475) = true)

theorem identity13475 : scanCanonicalize (H12AffineFastState.compose env13475 (packedSelected [1,3,4,5,8,9,10,14,16,17,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound13475 : packedSelected [1,3,4,5,8,9,10,14,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env13476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8312,8403,13673,10281,1025,8313,4113,168,64,374,8328,64,2185,5441,4605,10628,1421,32,257,476,5372,649]

theorem envBound13476 : H12AffineFastState.Bounded env13476 := by
  intro p hp
  have h : env13476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13475_13476 : H12AffineEnvironment.transform 15 8403 env13475 = env13476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env13475 == env13476) = true)

theorem identity13476 : scanCanonicalize (H12AffineFastState.compose env13476 (packedSelected [1,2,3,5,6,8,11,12,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound13476 : packedSelected [1,2,3,5,6,8,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env13477 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4452,8312,8403,12529,10281,409,8313,4113,168,64,374,8328,64,2185,4313,4605,10628,21,32,257,476,4452,649]

theorem envBound13477 : H12AffineFastState.Bounded env13477 := by
  intro p hp
  have h : env13477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13476_13477 : H12AffineEnvironment.transform 9 408 env13476 = env13477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env13476 == env13477) = true)

theorem identity13477 : scanCanonicalize (H12AffineFastState.compose env13477 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13477 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env13478 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,4096,8192,4160,8312,8403,12529,10281,189,8313,4113,168,64,82,8328,64,2185,4313,4313,10400,21,32,37,248,4160,649]

theorem envBound13478 : H12AffineFastState.Bounded env13478 := by
  intro p hp
  have h : env13478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13477_13478 : H12AffineEnvironment.transform 7 36 env13477 = env13478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13477 == env13478) = true)

theorem identity13478 : scanCanonicalize (H12AffineFastState.compose env13478 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13478 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13479 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,8192,4160,8312,8283,12409,10281,53,8313,4113,32,64,82,8192,64,2049,4177,4177,10280,21,32,37,112,4160,513]

theorem envBound13479 : H12AffineFastState.Bounded env13479 := by
  intro p hp
  have h : env13479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13478_13479 : H12AffineEnvironment.transform 6 8 env13478 = env13479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13478 == env13479) = true)

theorem identity13479 : scanCanonicalize (H12AffineFastState.compose env13479 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound13479 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13480 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,6200,4160,6208,6243,2113,4113,53,6209,4113,32,64,82,6200,64,2049,4177,4177,4112,21,32,37,112,4160,513]

theorem envBound13480 : H12AffineFastState.Bounded env13480 := by
  intro p hp
  have h : env13480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13479_13480 : H12AffineEnvironment.transform 12 6200 env13479 = env13480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env13479 == env13480) = true)

theorem identity13480 : scanCanonicalize (H12AffineFastState.compose env13480 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13480 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env13481 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,6200,4113,6161,6194,2064,4113,53,6160,4113,32,17,3,6200,17,2049,4096,4096,4112,21,32,37,33,4113,513]

theorem envBound13481 : H12AffineFastState.Bounded env13481 := by
  intro p hp
  have h : env13481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13480_13481 : H12AffineEnvironment.transform 5 17 env13480 = env13481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13480 == env13481) = true)

theorem identity13481 : scanCanonicalize (H12AffineFastState.compose env13481 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound13481 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13482 : List Nat := [2,4,8,16,32,17,8,36,512,52,528,4096,4648,4113,4609,4642,512,4113,53,4608,4113,32,17,3,4648,17,529,4096,4096,4112,21,32,37,33,4113,513]

theorem envBound13482 : H12AffineFastState.Bounded env13482 := by
  intro p hp
  have h : env13482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13481_13482 : H12AffineEnvironment.transform 10 528 env13481 = env13482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env13481 == env13482) = true)

def env13483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262336,201933,8328,64,6705549,2265152,184336,2377024,2102685,6451469,257,21793,46213,2175562]

theorem envBound13483 : H12AffineFastState.Bounded env13483 := by
  intro p hp
  have h : env13483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13394_13483 : H12AffineEnvironment.transform 23 201933 env13394 = env13483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201933 env13394 == env13483) = true)

def env13484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603933,2098512,17664,2377024,2102685,6349853,257,21793,46213,2175562]

theorem envBound13484 : H12AffineFastState.Bounded env13484 := by
  intro p hp
  have h : env13484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13483_13484 : H12AffineEnvironment.transform 16 38160 env13483 = env13484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env13483 == env13484) = true)

def env13485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157597,2098512,17664,2377024,2102685,2411677,257,21793,46213,2175562]

theorem envBound13485 : H12AffineFastState.Bounded env13485 := by
  intro p hp
  have h : env13485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13484_13485 : H12AffineEnvironment.transform 21 272512 env13484 = env13485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13484 == env13485) = true)

theorem identity13485 : scanCanonicalize (H12AffineFastState.compose env13485 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound13485 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115871,272512,120015,98781,8328,64,75906,115151,17664,360927,119042,329730,257,21793,46213,63189]

theorem envBound13486 : H12AffineFastState.Bounded env13486 := by
  intro p hp
  have h : env13486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13485_13486 : H12AffineEnvironment.transform 20 115871 env13485 = env13486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env13485 == env13486) = true)

def env13487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115871,272512,119967,98701,8328,16,75906,115103,17664,360847,119042,329730,257,21793,46213,63109]

theorem envBound13487 : H12AffineFastState.Bounded env13487 := by
  intro p hp
  have h : env13487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13486_13487 : H12AffineEnvironment.transform 5 16 env13486 = env13487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13486 == env13487) = true)

def env13488 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115735,272392,119831,98565,8192,16,75786,114967,17664,360711,119042,329730,257,21793,46093,62989]

theorem envBound13488 : H12AffineFastState.Bounded env13488 := by
  intro p hp
  have h : env13488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13487_13488 : H12AffineEnvironment.transform 6 8 env13487 = env13488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13487 == env13488) = true)

theorem identity13488 : scanCanonicalize (H12AffineFastState.compose env13488 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 34816) := by decide +kernel

theorem selectedBound13488 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env13489 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,34816,1025,32769,115735,40968,119831,98565,8192,16,75786,114967,17664,67847,119042,98306,257,21793,46093,62989]

theorem envBound13489 : H12AffineFastState.Bounded env13489 := by
  intro p hp
  have h : env13489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13488_13489 : H12AffineEnvironment.transform 17 34816 env13488 = env13489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34816 env13488 == env13489) = true)

theorem identity13489 : scanCanonicalize (H12AffineFastState.compose env13489 (packedSelected [0,4,14,16,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound13489 : packedSelected [0,4,14,16,22,27] rootPS < 2^1333 := by decide +kernel

def env13490 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,38160,34816,1025,32769,17681,40968,21777,3,8192,16,43276,16401,17664,34817,20484,260,257,21793,46093,62989]

theorem envBound13490 : H12AffineFastState.Bounded env13490 := by
  intro p hp
  have h : env13490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13489_13490 : H12AffineEnvironment.transform 15 33030 env13489 = env13490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env13489 == env13490) = true)

theorem identity13490 : scanCanonicalize (H12AffineFastState.compose env13490 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(14+1) ^^^ 15372) := by decide +kernel

theorem selectedBound13490 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env13491 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,15372,15626,10524,13324,1025,15373,17681,7172,21777,3,8192,16,5376,16401,17664,13325,20484,260,257,21793,2049,18945]

theorem envBound13491 : H12AffineFastState.Bounded env13491 := by
  intro p hp
  have h : env13491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13490_13491 : H12AffineEnvironment.transform 14 15372 env13490 = env13491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15372 env13490 == env13491) = true)

theorem identity13491 : scanCanonicalize (H12AffineFastState.compose env13491 (packedSelected [1,2,3,5,6,8,10,15,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13491 : packedSelected [1,2,3,5,6,8,10,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env13492 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,15372,15407,10297,13324,1025,15373,17460,7172,21556,3,8192,16,5157,16401,17445,13325,20484,33,36,21508,2049,18945]

theorem envBound13492 : H12AffineFastState.Bounded env13492 := by
  intro p hp
  have h : env13492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13491_13492 : H12AffineEnvironment.transform 7 37 env13491 = env13492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13491 == env13492) = true)

theorem identity13492 : scanCanonicalize (H12AffineFastState.compose env13492 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound13492 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13493 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,16384,7205,7174,2064,5157,1025,7204,17460,7172,21556,3,41,16,5157,16401,17445,5156,20484,33,36,21508,2049,18945]

theorem envBound13493 : H12AffineFastState.Bounded env13493 := by
  intro p hp
  have h : env13493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13492_13493 : H12AffineEnvironment.transform 12 41 env13492 = env13493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env13492 == env13493) = true)

theorem identity13493 : scanCanonicalize (H12AffineFastState.compose env13493 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13493 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env13494 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,17,41,16384,3124,3095,2064,1076,1025,3125,17460,3093,17445,3,41,16,1076,16401,17445,1077,16405,33,36,17429,2049,18945]

theorem envBound13494 : H12AffineFastState.Bounded env13494 := by
  intro p hp
  have h : env13494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13493_13494 : H12AffineEnvironment.transform 11 17 env13493 = env13494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13493 == env13494) = true)

def env13495 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115734,272393,119830,98564,8193,16,75787,114966,17664,360710,119042,329730,257,21793,46092,62988]

theorem envBound13495 : H12AffineFastState.Bounded env13495 := by
  intro p hp
  have h : env13495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13487_13495 : H12AffineEnvironment.transform 6 9 env13487 = env13495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13487 == env13495) = true)

theorem identity13495 : scanCanonicalize (H12AffineFastState.compose env13495 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound13495 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env13496 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130095,1025,32769,115734,119846,119830,98564,8193,16,75787,114966,17664,32041,119042,62509,257,21793,46092,62988]

theorem envBound13496 : H12AffineFastState.Bounded env13496 := by
  intro p hp
  have h : env13496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13495_13496 : H12AffineEnvironment.transform 17 130095 env13495 = env13496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env13495 == env13496) = true)

theorem identity13496 : scanCanonicalize (H12AffineFastState.compose env13496 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound13496 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13497 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24861,67618,1025,29708,77851,73771,73755,95497,8193,16,75787,79131,17664,32041,75023,32,257,21793,16385,513]

theorem envBound13497 : H12AffineFastState.Bounded env13497 := by
  intro p hp
  have h : env13497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13496_13497 : H12AffineEnvironment.transform 14 29709 env13496 = env13497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env13496 == env13497) = true)

theorem identity13497 : scanCanonicalize (H12AffineFastState.compose env13497 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13497 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13498 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,65536,16400,67618,1025,21761,69910,65830,65814,87044,268,16,67846,70678,17664,23588,66562,32,257,21793,16385,513]

theorem envBound13498 : H12AffineFastState.Bounded env13498 := by
  intro p hp
  have h : env13498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13497_13498 : H12AffineEnvironment.transform 12 269 env13497 = env13498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13497 == env13498) = true)

theorem identity13498 : scanCanonicalize (H12AffineFastState.compose env13498 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13498 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13499 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,65536,5393,67618,1025,0,69910,65830,65814,65797,268,16,67846,70678,4097,2341,66562,32,257,32,5376,513]

theorem envBound13499 : H12AffineFastState.Bounded env13499 := by
  intro p hp
  have h : env13499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13498_13499 : H12AffineEnvironment.transform 13 5377 env13498 = env13499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13498 == env13499) = true)

theorem identity13499 : scanCanonicalize (H12AffineFastState.compose env13499 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound13499 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13500 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4112,32,16,3,268,16,2048,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound13500 : H12AffineFastState.Bounded env13500 := by
  intro p hp
  have h : env13500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13499_13500 : H12AffineEnvironment.transform 15 262 env13499 = env13500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env13499 == env13500) = true)

theorem identity13500 : scanCanonicalize (H12AffineFastState.compose env13500 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound13500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13501 : List Nat := [2,4,8,16,32,16,9,256,512,4,2048,4096,269,4357,1,262,4373,2340,5,0,4112,32,16,3,268,16,2048,4372,4097,2341,256,32,257,32,4356,513]

theorem envBound13501 : H12AffineFastState.Bounded env13501 := by
  intro p hp
  have h : env13501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13500_13501 : H12AffineEnvironment.transform 9 4 env13500 = env13501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env13500 == env13501) = true)

theorem identity13501 : scanCanonicalize (H12AffineFastState.compose env13501 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound13501 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13502 : List Nat := [2,4,8,16,32,16,9,256,512,4,2048,820,269,561,1,262,545,2340,5,0,804,32,16,3,268,16,2048,544,821,2341,256,32,257,32,560,513]

theorem envBound13502 : H12AffineFastState.Bounded env13502 := by
  intro p hp
  have h : env13502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13501_13502 : H12AffineEnvironment.transform 11 820 env13501 = env13502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env13501 == env13502) = true)

theorem identity13502 : scanCanonicalize (H12AffineFastState.compose env13502 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound13502 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13503 : List Nat := [2,4,8,16,32,16,9,256,512,4,277,820,269,561,1,262,545,49,5,0,804,32,16,3,268,16,277,544,821,48,256,32,257,32,560,513]

theorem envBound13503 : H12AffineFastState.Bounded env13503 := by
  intro p hp
  have h : env13503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13502_13503 : H12AffineEnvironment.transform 10 277 env13502 = env13503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env13502 == env13503) = true)

theorem identity13503 : scanCanonicalize (H12AffineFastState.compose env13503 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13503 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13504 : List Nat := [2,4,8,16,32,16,9,256,32,4,277,276,269,17,1,262,1,49,5,0,260,32,16,3,268,16,277,0,277,48,256,32,257,32,16,33]

theorem envBound13504 : H12AffineFastState.Bounded env13504 := by
  intro p hp
  have h : env13504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13503_13504 : H12AffineEnvironment.transform 8 32 env13503 = env13504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13503 == env13504) = true)

theorem identity13504 : scanCanonicalize (H12AffineFastState.compose env13504 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13504 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13505 : List Nat := [2,4,8,16,16,16,9,256,16,4,277,276,269,17,1,262,1,1,5,0,260,16,16,3,268,16,277,0,277,0,256,16,257,16,16,17]

theorem envBound13505 : H12AffineFastState.Bounded env13505 := by
  intro p hp
  have h : env13505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13504_13505 : H12AffineEnvironment.transform 4 16 env13504 = env13505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13504 == env13505) = true)

theorem identity13505 : scanCanonicalize (H12AffineFastState.compose env13505 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13505 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13506 : List Nat := [2,4,8,0,0,0,9,256,0,4,261,260,269,1,1,262,1,1,5,0,260,0,0,3,268,0,261,0,261,0,256,0,257,0,0,1]

theorem envBound13506 : H12AffineFastState.Bounded env13506 := by
  intro p hp
  have h : env13506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13505_13506 : H12AffineEnvironment.transform 3 0 env13505 = env13506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13505 == env13506) = true)

def env13507 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115871,272512,119966,98700,8328,17,75906,115102,17664,360846,119042,329730,257,21793,46213,63108]

theorem envBound13507 : H12AffineFastState.Bounded env13507 := by
  intro p hp
  have h : env13507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13486_13507 : H12AffineEnvironment.transform 5 17 env13486 = env13507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13486 == env13507) = true)

theorem identity13507 : scanCanonicalize (H12AffineFastState.compose env13507 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13507 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env13508 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,115871,168,119966,98700,8328,17,75906,115102,17664,108966,119042,73770,257,21793,46213,63108]

theorem envBound13508 : H12AffineFastState.Bounded env13508 := by
  intro p hp
  have h : env13508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13507_13508 : H12AffineEnvironment.transform 17 10280 env13507 = env13508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13507 == env13508) = true)

theorem identity13508 : scanCanonicalize (H12AffineFastState.compose env13508 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound13508 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env13509 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,65536,5529,10280,1025,136,82966,168,87063,65797,8328,17,75906,82199,17664,76079,86411,73770,257,21793,13324,30221]

theorem envBound13509 : H12AffineFastState.Bounded env13509 := by
  intro p hp
  have h : env13509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13508_13509 : H12AffineEnvironment.transform 14 137 env13508 = env13509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env13508 == env13509) = true)

theorem identity13509 : scanCanonicalize (H12AffineFastState.compose env13509 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound13509 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env13510 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,137,65536,5529,10280,1025,136,77971,168,73874,65797,8328,17,75906,79250,12677,76079,75022,73770,257,8612,13324,648]

theorem envBound13510 : H12AffineFastState.Bounded env13510 := by
  intro p hp
  have h : env13510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13509_13510 : H12AffineEnvironment.transform 13 13445 env13509 = env13510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env13509 == env13510) = true)

theorem identity13510 : scanCanonicalize (H12AffineFastState.compose env13510 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13510 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env13511 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,137,8202,5529,10280,1025,136,4249,168,152,8463,8328,17,2184,5528,12677,2341,1284,32,257,8612,13324,648]

theorem envBound13511 : H12AffineFastState.Bounded env13511 := by
  intro p hp
  have h : env13511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13510_13511 : H12AffineEnvironment.transform 15 8202 env13510 = env13511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13510 == env13511) = true)

theorem identity13511 : scanCanonicalize (H12AffineFastState.compose env13511 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13511 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13512 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8202,5392,10280,1025,1,4112,33,17,8463,8193,17,2049,5393,12556,2341,1284,32,257,8493,13324,513]

theorem envBound13512 : H12AffineFastState.Bounded env13512 := by
  intro p hp
  have h : env13512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13511_13512 : H12AffineEnvironment.transform 6 9 env13511 = env13512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13511 == env13512) = true)

theorem identity13512 : scanCanonicalize (H12AffineFastState.compose env13512 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13512 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13513 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1025,1,4112,33,17,3,269,17,2049,5393,4096,2341,1284,32,257,33,5376,513]

theorem envBound13513 : H12AffineFastState.Bounded env13513 := by
  intro p hp
  have h : env13513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13512_13513 : H12AffineEnvironment.transform 12 268 env13512 = env13513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13512 == env13513) = true)

theorem identity13513 : scanCanonicalize (H12AffineFastState.compose env13513 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13513 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13514 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4112,33,17,3,40,17,2049,5172,4096,2048,1057,32,36,33,5157,513]

theorem envBound13514 : H12AffineFastState.Bounded env13514 := by
  intro p hp
  have h : env13514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13513_13514 : H12AffineEnvironment.transform 7 37 env13513 = env13514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13513 == env13514) = true)

theorem identity13514 : scanCanonicalize (H12AffineFastState.compose env13514 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1598) := by decide +kernel

theorem selectedBound13514 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13515 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1598,4096,41,5157,0,35,5173,1599,1025,1,4112,33,17,3,40,17,1599,5172,4096,1598,1057,32,36,33,5157,513]

theorem envBound13515 : H12AffineFastState.Bounded env13515 := by
  intro p hp
  have h : env13515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13514_13515 : H12AffineEnvironment.transform 10 1598 env13514 = env13515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1598 env13514 == env13515) = true)

theorem identity13515 : scanCanonicalize (H12AffineFastState.compose env13515 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound13515 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13516 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1598,1550,41,555,0,35,571,1599,1025,1,1566,33,17,3,40,17,1599,570,1550,1598,1057,32,36,33,555,513]

theorem envBound13516 : H12AffineFastState.Bounded env13516 := by
  intro p hp
  have h : env13516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13515_13516 : H12AffineEnvironment.transform 11 1550 env13515 = env13516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env13515 == env13516) = true)

theorem identity13516 : scanCanonicalize (H12AffineFastState.compose env13516 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13516 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13517 : List Nat := [2,4,8,16,32,17,9,37,512,53,523,571,41,555,0,35,571,522,52,1,555,33,17,3,40,17,522,570,571,523,20,32,36,33,555,513]

theorem envBound13517 : H12AffineFastState.Bounded env13517 := by
  intro p hp
  have h : env13517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13516_13517 : H12AffineEnvironment.transform 9 53 env13516 = env13517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13516 == env13517) = true)

theorem identity13517 : scanCanonicalize (H12AffineFastState.compose env13517 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound13517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13518 : List Nat := [2,4,8,16,32,17,9,37,5,53,14,62,41,46,0,35,62,15,52,1,46,33,17,3,40,17,15,63,62,14,20,32,36,33,46,4]

theorem envBound13518 : H12AffineFastState.Bounded env13518 := by
  intro p hp
  have h : env13518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13517_13518 : H12AffineEnvironment.transform 8 5 env13517 = env13518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env13517 == env13518) = true)

theorem identity13518 : scanCanonicalize (H12AffineFastState.compose env13518 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound13518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13519 : List Nat := [2,4,8,13,32,12,9,37,5,40,14,35,41,46,0,35,35,15,41,1,46,33,12,3,40,12,15,34,35,14,9,32,36,33,46,4]

theorem envBound13519 : H12AffineFastState.Bounded env13519 := by
  intro p hp
  have h : env13519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13518_13519 : H12AffineEnvironment.transform 3 13 env13518 = env13519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env13518 == env13519) = true)

def env13520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157596,2098512,17664,2377024,2102685,2411676,257,21793,46213,2175562]

theorem envBound13520 : H12AffineFastState.Bounded env13520 := by
  intro p hp
  have h : env13520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13484_13520 : H12AffineEnvironment.transform 21 272513 env13484 = env13520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13484 == env13520) = true)

theorem identity13520 : scanCanonicalize (H12AffineFastState.compose env13520 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound13520 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38160,262144,1025,32769,2097152,272513,2101328,21763,8328,64,2157596,2098512,17664,2377024,2102685,2411676,257,21793,46213,2156180]

theorem envBound13521 : H12AffineFastState.Bounded env13521 := by
  intro p hp
  have h : env13521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13520_13521 : H12AffineEnvironment.transform 15 54494 env13520 = env13521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env13520 == env13521) = true)

def env13522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,2097152,272393,2101328,21763,8192,64,2157596,2098512,17664,2377024,2102549,2411540,257,21793,46093,2156060]

theorem envBound13522 : H12AffineFastState.Bounded env13522 := by
  intro p hp
  have h : env13522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13521_13522 : H12AffineEnvironment.transform 6 8 env13521 = env13522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13521 == env13522) = true)

theorem identity13522 : scanCanonicalize (H12AffineFastState.compose env13522 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 322588) := by decide +kernel

theorem selectedBound13522 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env13523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,322588,272393,326732,21763,8192,64,262144,321868,17664,43356,325897,8200,257,21793,46093,264704]

theorem envBound13523 : H12AffineFastState.Bounded env13523 := by
  intro p hp
  have h : env13523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13522_13523 : H12AffineEnvironment.transform 20 322588 env13522 = env13523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 322588 env13522 == env13523) = true)

theorem identity13523 : scanCanonicalize (H12AffineFastState.compose env13523 (packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound13523 : packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env13524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,56577,1025,32769,12573,62728,8525,21763,8192,64,56577,13389,17664,43356,9224,8200,257,21793,46093,55041]

theorem envBound13524 : H12AffineFastState.Bounded env13524 := by
  intro p hp
  have h : env13524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13523_13524 : H12AffineEnvironment.transform 17 56577 env13523 = env13524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env13523 == env13524) = true)

theorem identity13524 : scanCanonicalize (H12AffineFastState.compose env13524 (packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound13524 : packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env13525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40970,38160,43357,1025,32769,12573,33108,8525,8543,8192,64,43357,13389,12636,43356,9224,8200,257,8573,46093,41821]

theorem envBound13525 : H12AffineFastState.Bounded env13525 := by
  intro p hp
  have h : env13525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13524_13525 : H12AffineEnvironment.transform 13 13404 env13524 = env13525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env13524 == env13525) = true)

theorem identity13525 : scanCanonicalize (H12AffineFastState.compose env13525 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound13525 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env13526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8232,34,13624,2421,1025,8233,12573,8572,8525,8543,8192,64,2421,13389,12636,2420,9224,8200,257,8573,5157,885]

theorem envBound13526 : H12AffineFastState.Bounded env13526 := by
  intro p hp
  have h : env13526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13525_13526 : H12AffineEnvironment.transform 14 8232 env13525 = env13526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env13525 == env13526) = true)

theorem identity13526 : scanCanonicalize (H12AffineFastState.compose env13526 (packedSelected [1,3,8,10,12,15,18,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13526 : packedSelected [1,3,8,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env13527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,373,34,5221,2421,1025,372,4160,33,16,2,349,64,2421,5392,4097,2420,1365,341,257,32,5157,885]

theorem envBound13527 : H12AffineFastState.Bounded env13527 := by
  intro p hp
  have h : env13527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13526_13527 : H12AffineEnvironment.transform 12 349 env13526 = env13527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13526 == env13527) = true)

theorem identity13527 : scanCanonicalize (H12AffineFastState.compose env13527 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13527 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13528 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,5156,80,34,5221,2128,1025,81,4160,33,16,2,120,64,2128,5173,4097,2129,1136,112,36,32,5157,592]

theorem envBound13528 : H12AffineFastState.Bounded env13528 := by
  intro p hp
  have h : env13528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13527_13528 : H12AffineEnvironment.transform 7 37 env13527 = env13528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13527 == env13528) = true)

theorem identity13528 : scanCanonicalize (H12AffineFastState.compose env13528 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound13528 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env13529 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,120,2048,80,34,2113,2128,1025,81,3172,33,16,2,120,64,2128,2065,3109,2129,1136,112,36,32,2049,592]

theorem envBound13529 : H12AffineFastState.Bounded env13529 := by
  intro p hp
  have h : env13529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13528_13529 : H12AffineEnvironment.transform 11 3108 env13528 = env13529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env13528 == env13529) = true)

theorem identity13529 : scanCanonicalize (H12AffineFastState.compose env13529 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound13529 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env13530 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1077,17,120,1077,80,34,1140,1125,1025,81,81,33,16,2,120,64,1125,1060,16,1124,1136,112,36,32,1076,592]

theorem envBound13530 : H12AffineFastState.Bounded env13530 := by
  intro p hp
  have h : env13530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13529_13530 : H12AffineEnvironment.transform 10 1077 env13529 = env13530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env13529 == env13530) = true)

theorem identity13530 : scanCanonicalize (H12AffineFastState.compose env13530 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound13530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13531 : List Nat := [2,4,8,16,32,64,8,37,512,36,17,17,120,17,80,34,80,65,37,81,81,33,16,2,120,64,65,0,16,64,84,112,36,32,16,592]

theorem envBound13531 : H12AffineFastState.Bounded env13531 := by
  intro p hp
  have h : env13531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13530_13531 : H12AffineEnvironment.transform 9 36 env13530 = env13531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env13530 == env13531) = true)

theorem identity13531 : scanCanonicalize (H12AffineFastState.compose env13531 (packedSelected [3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13531 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env13532 : List Nat := [2,4,8,1,32,64,8,37,512,36,0,0,105,0,65,34,65,65,37,64,64,33,1,2,105,64,65,0,1,64,69,97,36,32,1,577]

theorem envBound13532 : H12AffineFastState.Bounded env13532 := by
  intro p hp
  have h : env13532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13531_13532 : H12AffineEnvironment.transform 3 1 env13531 = env13532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13531 == env13532) = true)

def env13533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,2097152,272392,2101328,21763,8193,64,2157596,2098512,17664,2377024,2102548,2411541,257,21793,46092,2156061]

theorem envBound13533 : H12AffineFastState.Bounded env13533 := by
  intro p hp
  have h : env13533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13521_13533 : H12AffineEnvironment.transform 6 9 env13521 = env13533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13521 == env13533) = true)

theorem identity13533 : scanCanonicalize (H12AffineFastState.compose env13533 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound13533 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env13534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,17729,272392,21777,21763,8193,64,43357,16401,17664,262145,20565,297300,257,21793,46092,41820]

theorem envBound13534 : H12AffineFastState.Bounded env13534 := by
  intro p hp
  have h : env13534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13533_13534 : H12AffineEnvironment.transform 20 17729 env13533 = env13534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env13533 == env13534) = true)

theorem identity13534 : scanCanonicalize (H12AffineFastState.compose env13534 (packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13534 : packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env13535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,54359,38160,262144,1025,32769,17729,264452,21777,21763,269,64,34897,16401,17664,262145,20565,297300,257,21793,38144,33360]

theorem envBound13535 : H12AffineFastState.Bounded env13535 := by
  intro p hp
  have h : env13535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13534_13535 : H12AffineEnvironment.transform 12 268 env13534 = env13535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13534 == env13535) = true)

theorem identity13535 : scanCanonicalize (H12AffineFastState.compose env13535 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound13535 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env13536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,54359,38160,35109,1025,32769,17729,32801,21777,21763,269,64,34897,16401,17664,35108,20565,113,257,21793,38144,33360]

theorem envBound13536 : H12AffineFastState.Bounded env13536 := by
  intro p hp
  have h : env13536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13535_13536 : H12AffineEnvironment.transform 17 35109 env13535 = env13536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env13535 == env13536) = true)

theorem identity13536 : scanCanonicalize (H12AffineFastState.compose env13536 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13536 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13537 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,54279,38160,35109,1025,32769,17681,32801,21777,21763,269,16,34817,16401,17664,35108,20485,33,257,21793,38144,33280]

theorem envBound13537 : H12AffineFastState.Bounded env13537 := by
  intro p hp
  have h : env13537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13536_13537 : H12AffineEnvironment.transform 5 16 env13536 = env13537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13536 == env13537) = true)

theorem identity13537 : scanCanonicalize (H12AffineFastState.compose env13537 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13537 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env13538 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,32768,33030,38160,35109,1025,32769,4112,32801,16,2,269,16,34817,5392,4097,35108,1284,33,257,32,38144,33280]

theorem envBound13538 : H12AffineFastState.Bounded env13538 := by
  intro p hp
  have h : env13538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13537_13538 : H12AffineEnvironment.transform 13 5377 env13537 = env13538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13537 == env13538) = true)

theorem identity13538 : scanCanonicalize (H12AffineFastState.compose env13538 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13538 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env13539 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1296,1046,4096,3125,1025,1297,4112,1329,16,2,269,16,3345,5392,4097,3124,1284,33,257,32,4112,1808]

theorem envBound13539 : H12AffineFastState.Bounded env13539 := by
  intro p hp
  have h : env13539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13538_13539 : H12AffineEnvironment.transform 14 1296 env13538 = env13539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env13538 == env13539) = true)

def env13540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603932,2098513,17665,2377024,2102685,6349852,257,21793,46213,2175562]

theorem envBound13540 : H12AffineFastState.Bounded env13540 := by
  intro p hp
  have h : env13540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13483_13540 : H12AffineEnvironment.transform 16 38161 env13483 = env13540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13483 == env13540) = true)

def env13541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157596,2098513,17665,2377024,2102685,2411676,257,21793,46213,2175562]

theorem envBound13541 : H12AffineFastState.Bounded env13541 := by
  intro p hp
  have h : env13541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13540_13541 : H12AffineEnvironment.transform 21 272512 env13540 = env13541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13540 == env13541) = true)

theorem identity13541 : scanCanonicalize (H12AffineFastState.compose env13541 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound13541 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77899,272512,73754,98780,8328,64,121943,79130,17665,357643,75222,392407,257,21793,46213,513]

theorem envBound13542 : H12AffineFastState.Bounded env13542 := by
  intro p hp
  have h : env13542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13541_13542 : H12AffineEnvironment.transform 20 77899 env13541 = env13542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env13541 == env13542) = true)

def env13543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77899,272392,73754,98644,8192,64,121943,79130,17665,357643,75102,392287,257,21793,46093,513]

theorem envBound13543 : H12AffineFastState.Bounded env13543 := by
  intro p hp
  have h : env13543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13542_13543 : H12AffineEnvironment.transform 6 8 env13542 = env13543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13542 == env13543) = true)

theorem identity13543 : scanCanonicalize (H12AffineFastState.compose env13543 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound13543 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,50497,272392,54544,29790,8192,64,10589,49168,17665,294913,53332,264533,257,21793,46093,513]

theorem envBound13544 : H12AffineFastState.Bounded env13544 := by
  intro p hp
  have h : env13544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13543_13544 : H12AffineEnvironment.transform 15 62730 env13543 = env13544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env13543 == env13544) = true)

theorem identity13544 : scanCanonicalize (H12AffineFastState.compose env13544 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound13544 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env13545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,35,24632,262144,1025,29992,12392,272392,8249,29790,8192,64,10589,13625,17665,292136,9597,264533,257,21793,16676,513]

theorem envBound13545 : H12AffineFastState.Bounded env13545 := by
  intro p hp
  have h : env13545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13544_13545 : H12AffineEnvironment.transform 14 29993 env13544 = env13545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env13544 == env13545) = true)

theorem identity13545 : scanCanonicalize (H12AffineFastState.compose env13545 (packedSelected [0,2,4,6,9,17,20,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound13545 : packedSelected [0,2,4,6,9,17,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env13546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,0,35,5393,262144,1025,1,12392,272392,8249,375,8192,64,10589,13625,12328,262145,9597,264533,257,8200,13325,513]

theorem envBound13546 : H12AffineFastState.Bounded env13546 := by
  intro p hp
  have h : env13546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13545_13546 : H12AffineEnvironment.transform 13 13609 env13545 = env13546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env13545 == env13546) = true)

theorem identity13546 : scanCanonicalize (H12AffineFastState.compose env13546 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11341) := by decide +kernel

theorem selectedBound13546 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,0,35,5393,11341,1025,1,12392,1093,8249,375,8192,64,10589,13625,12328,11340,9597,9496,257,8200,13325,513]

theorem envBound13547 : H12AffineFastState.Bounded env13547 := by
  intro p hp
  have h : env13547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13546_13547 : H12AffineEnvironment.transform 17 11341 env13546 = env13547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11341 env13546 == env13547) = true)

theorem identity13547 : scanCanonicalize (H12AffineFastState.compose env13547 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13547 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13548 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,12621,0,35,4469,10281,101,1,12392,33,8249,375,8192,64,10589,12637,12328,10280,8473,8572,257,8200,12393,513]

theorem envBound13548 : H12AffineFastState.Bounded env13548 := by
  intro p hp
  have h : env13548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13547_13548 : H12AffineEnvironment.transform 9 100 env13547 = env13548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13547 == env13548) = true)

theorem identity13548 : scanCanonicalize (H12AffineFastState.compose env13548 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13548 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13549 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8192,12344,0,35,4096,10281,101,1,12392,33,8249,2,8192,64,10280,12328,12328,10280,8300,8201,116,8200,12393,513]

theorem envBound13549 : H12AffineFastState.Bounded env13549 := by
  intro p hp
  have h : env13549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13548_13549 : H12AffineEnvironment.transform 7 117 env13548 = env13549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13548 == env13549) = true)

def env13550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77899,272393,73754,98645,8193,64,121943,79130,17665,357643,75103,392286,257,21793,46092,513]

theorem envBound13550 : H12AffineFastState.Bounded env13550 := by
  intro p hp
  have h : env13550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13542_13550 : H12AffineEnvironment.transform 6 9 env13542 = env13550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13542 == env13550) = true)

def env13551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,77899,33,73754,98645,8193,64,121943,79130,17665,89379,75103,119926,257,21793,46092,513]

theorem envBound13551 : H12AffineFastState.Bounded env13551 := by
  intro p hp
  have h : env13551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13550_13551 : H12AffineEnvironment.transform 17 10280 env13550 = env13551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13550 == env13551) = true)

theorem identity13551 : scanCanonicalize (H12AffineFastState.compose env13551 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13551 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env13552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,38161,2420,1025,32769,69911,33,65862,98645,349,64,121943,70726,17665,89379,66563,119926,257,21793,38224,513]

theorem envBound13552 : H12AffineFastState.Bounded env13552 := by
  intro p hp
  have h : env13552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13551_13552 : H12AffineEnvironment.transform 12 348 env13551 = env13552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13551 == env13552) = true)

theorem identity13552 : scanCanonicalize (H12AffineFastState.compose env13552 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound13552 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,16401,2420,1025,21761,69911,33,65862,87125,349,64,67927,70726,17665,89379,66563,65910,257,21793,16464,513]

theorem envBound13553 : H12AffineFastState.Bounded env13553 := by
  intro p hp
  have h : env13553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13552_13553 : H12AffineEnvironment.transform 14 21760 env13552 = env13553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env13552 == env13553) = true)

theorem identity13553 : scanCanonicalize (H12AffineFastState.compose env13553 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13553 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1