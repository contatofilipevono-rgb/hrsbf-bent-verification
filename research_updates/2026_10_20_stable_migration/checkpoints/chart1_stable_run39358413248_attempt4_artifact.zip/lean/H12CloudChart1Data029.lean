import H12CloudChart1Data028

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env7180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103731,262144,62640,32768,2097152,41089,20480,98645,8328,118898,360619,2216051,2118976,2421,99702,40968,61872,340,34359738368,98850]

theorem envBound7180 : H12AffineFastState.Bounded env7180 := by
  intro p hp
  have h : env7180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7179_7180 : H12AffineEnvironment.transform 22 20480 env7179 = env7180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env7179 == env7180) = true)

theorem identity7180 : scanCanonicalize (H12AffineFastState.compose env7180 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7180 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env7181 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103631,262144,62640,32768,2097152,41089,20480,98473,8328,118898,360619,2216051,2118844,2185,99466,40968,61516,168,34359738368,98850]

theorem envBound7181 : H12AffineFastState.Bounded env7181 := by
  intro p hp
  have h : env7181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7180_7181 : H12AffineEnvironment.transform 7 252 env7180 = env7181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7180 == env7181) = true)

theorem identity7181 : scanCanonicalize (H12AffineFastState.compose env7181 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 310485) := by decide +kernel

theorem selectedBound7181 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7182 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103631,262144,62640,32768,310485,41089,20480,98473,8328,118898,360619,355494,321641,2185,99466,40968,61516,168,34359738368,98850]

theorem envBound7182 : H12AffineFastState.Bounded env7182 := by
  intro p hp
  have h : env7182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7181_7182 : H12AffineEnvironment.transform 20 310485 env7181 = env7182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 310485 env7181 == env7182) = true)

theorem identity7182 : scanCanonicalize (H12AffineFastState.compose env7182 (packedSelected [11,13,18] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound7182 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env7183 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,78959,262144,21520,8352,269429,33,20480,73737,8328,94418,335883,355494,280777,2185,74794,168,20716,168,34359738368,74370]

theorem envBound7183 : H12AffineFastState.Bounded env7183 := by
  intro p hp
  have h : env7183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7182_7183 : H12AffineEnvironment.transform 14 8352 env7182 = env7183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env7182 == env7183) = true)

theorem identity7183 : scanCanonicalize (H12AffineFastState.compose env7183 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7183 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env7184 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,78959,262144,21520,8352,269429,33,20480,73737,8328,94418,335883,355494,280777,2185,74794,168,20716,168,280712,74370]

theorem envBound7184 : H12AffineFastState.Bounded env7184 := by
  intro p hp
  have h : env7184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7183_7184 : H12AffineEnvironment.transform 34 280712 env7183 = env7184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7183 == env7184) = true)

theorem identity7184 : scanCanonicalize (H12AffineFastState.compose env7184 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound7184 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7185 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,65536,78959,262144,2742,8352,269429,33,3750,73737,8328,77428,335883,340480,267887,2185,74794,168,3658,168,267822,74370]

theorem envBound7185 : H12AffineFastState.Bounded env7185 := by
  intro p hp
  have h : env7185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7184_7185 : H12AffineEnvironment.transform 13 7846 env7184 = env7185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env7184 == env7185) = true)

def env7186 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,16031,262144,2742,8352,269429,33,3750,11001,8328,9348,273147,276720,267887,2185,11994,168,3658,168,267822,10354]

theorem envBound7186 : H12AffineFastState.Bounded env7186 := by
  intro p hp
  have h : env7186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7185_7186 : H12AffineEnvironment.transform 15 2800 env7185 = env7186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7185 == env7186) = true)

theorem identity7186 : scanCanonicalize (H12AffineFastState.compose env7186 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 8954) := by decide +kernel

theorem selectedBound7186 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7187 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,16031,8954,2742,8352,16015,33,3750,11001,8328,9348,2049,6666,13461,2185,11994,168,3658,168,13524,10354]

theorem envBound7187 : H12AffineFastState.Bounded env7187 := by
  intro p hp
  have h : env7187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7186_7187 : H12AffineEnvironment.transform 17 8954 env7186 = env7187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8954 env7186 == env7187) = true)

theorem identity7187 : scanCanonicalize (H12AffineFastState.compose env7187 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 2674) := by decide +kernel

theorem selectedBound7187 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7188 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2674,7846,2770,2800,5357,2184,2742,2770,5373,33,3750,139,2810,3830,2049,6666,7911,2185,1192,168,3658,168,7846,512]

theorem envBound7188 : H12AffineFastState.Bounded env7188 := by
  intro p hp
  have h : env7188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7187_7188 : H12AffineEnvironment.transform 12 2674 env7187 = env7188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2674 env7187 == env7188) = true)

theorem identity7188 : scanCanonicalize (H12AffineFastState.compose env7188 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7189 : List Nat := [2,4,8,16,32,64,128,252,512,68,2048,4096,2674,6882,2770,2800,4265,2184,2742,2770,4281,33,2786,139,2810,2738,2049,6666,6819,2185,236,168,2574,168,6882,512]

theorem envBound7189 : H12AffineFastState.Bounded env7189 := by
  intro p hp
  have h : env7189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7188_7189 : H12AffineEnvironment.transform 9 68 env7188 = env7189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7188 == env7189) = true)

theorem identity7189 : scanCanonicalize (H12AffineFastState.compose env7189 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 723) := by decide +kernel

theorem selectedBound7189 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7190 : List Nat := [2,4,8,16,32,64,128,252,512,68,723,4096,161,4145,1,35,4265,603,101,1,4281,33,49,139,41,97,722,4313,4208,602,236,168,221,168,4145,512]

theorem envBound7190 : H12AffineFastState.Bounded env7190 := by
  intro p hp
  have h : env7190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7189_7190 : H12AffineEnvironment.transform 10 723 env7189 = env7190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 723 env7189 == env7190) = true)

theorem identity7190 : scanCanonicalize (H12AffineFastState.compose env7190 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 671) := by decide +kernel

theorem selectedBound7190 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7191 : List Nat := [2,4,8,16,32,64,128,252,512,68,723,671,161,686,1,35,566,603,101,1,550,33,49,139,41,97,722,582,751,602,236,168,221,168,686,512]

theorem envBound7191 : H12AffineFastState.Bounded env7191 := by
  intro p hp
  have h : env7191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7190_7191 : H12AffineEnvironment.transform 11 671 env7190 = env7191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 671 env7190 == env7191) = true)

def env7192 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,16030,262144,2742,8352,269429,33,3750,11000,8328,9349,273146,276721,267887,2185,11995,168,3658,168,267822,10355]

theorem envBound7192 : H12AffineFastState.Bounded env7192 := by
  intro p hp
  have h : env7192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7185_7192 : H12AffineEnvironment.transform 15 2801 env7185 = env7192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7185 == env7192) = true)

def env7193 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,16030,3276,2742,8352,4281,33,3750,11000,8328,9349,9782,13373,6819,2185,11995,168,3658,168,6882,10355]

theorem envBound7193 : H12AffineFastState.Bounded env7193 := by
  intro p hp
  have h : env7193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7192_7193 : H12AffineEnvironment.transform 17 3276 env7192 = env7193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3276 env7192 == env7193) = true)

theorem identity7193 : scanCanonicalize (H12AffineFastState.compose env7193 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1687) := by decide +kernel

theorem selectedBound7193 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7194 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,4096,8192,4145,8352,1126,12297,603,1057,8352,4281,33,49,9327,8328,9349,9782,13373,5172,1566,8268,168,221,168,5237,9956]

theorem envBound7194 : H12AffineFastState.Bounded env7194 := by
  intro p hp
  have h : env7194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7193_7194 : H12AffineEnvironment.transform 10 1687 env7193 = env7194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1687 env7193 == env7194) = true)

def env7195 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,4096,4152,4145,4248,1126,49,603,1057,4248,4281,33,49,5207,4272,5309,5646,1029,5172,1566,4212,168,221,168,5237,5852]

theorem envBound7195 : H12AffineFastState.Bounded env7195 := by
  intro p hp
  have h : env7195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7194_7195 : H12AffineEnvironment.transform 12 4152 env7194 = env7195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4152 env7194 == env7195) = true)

def env7196 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,16,40,33,136,1126,49,603,1057,136,169,33,49,1095,160,1197,1566,1029,1060,1566,100,168,221,168,1125,1740]

theorem envBound7196 : H12AffineFastState.Bounded env7196 := by
  intro p hp
  have h : env7196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7195_7196 : H12AffineEnvironment.transform 11 16 env7195 = env7196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env7195 == env7196) = true)

def env7197 : List Nat := [2,4,8,16,32,64,128,252,512,216,591,16,40,33,136,190,49,603,249,136,169,33,49,159,160,117,710,221,252,710,100,168,221,168,189,532]

theorem envBound7197 : H12AffineFastState.Bounded env7197 := by
  intro p hp
  have h : env7197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7196_7197 : H12AffineEnvironment.transform 9 216 env7196 = env7197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 216 env7196 == env7197) = true)

theorem identity7197 : scanCanonicalize (H12AffineFastState.compose env7197 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 76) := by decide +kernel

theorem selectedBound7197 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env7198 : List Nat := [2,4,8,16,32,64,76,48,512,20,591,16,40,33,68,114,49,603,53,68,101,33,49,83,108,117,522,17,48,522,100,100,17,100,113,532]

theorem envBound7198 : H12AffineFastState.Bounded env7198 := by
  intro p hp
  have h : env7198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7197_7198 : H12AffineEnvironment.transform 6 76 env7197 = env7198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 76 env7197 == env7198) = true)

def env7199 : List Nat := [2,4,8,16,32,4,8,48,512,20,523,16,40,33,0,54,49,543,53,0,33,33,49,23,40,49,522,17,48,522,32,32,17,32,53,532]

theorem envBound7199 : H12AffineFastState.Bounded env7199 := by
  intro p hp
  have h : env7199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7198_7199 : H12AffineEnvironment.transform 5 4 env7198 = env7199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env7198 == env7199) = true)

theorem identity7199 : scanCanonicalize (H12AffineFastState.compose env7199 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound7199 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7200 : List Nat := [2,4,8,5,32,4,8,37,512,1,523,5,40,33,0,35,36,522,32,0,33,33,36,2,40,36,522,4,37,522,32,32,4,32,32,513]

theorem envBound7200 : H12AffineFastState.Bounded env7200 := by
  intro p hp
  have h : env7200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7199_7200 : H12AffineEnvironment.transform 3 5 env7199 = env7200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env7199 == env7200) = true)

theorem identity7200 : scanCanonicalize (H12AffineFastState.compose env7200 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7200 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7201 : List Nat := [2,2,8,3,32,2,8,35,512,1,523,3,40,33,0,35,34,522,32,0,33,33,34,2,40,34,522,2,35,522,32,32,2,32,32,513]

theorem envBound7201 : H12AffineFastState.Bounded env7201 := by
  intro p hp
  have h : env7201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7200_7201 : H12AffineEnvironment.transform 1 2 env7200 = env7201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7200 == env7201) = true)

theorem identity7201 : scanCanonicalize (H12AffineFastState.compose env7201 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7201 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7202 : List Nat := [2,2,8,3,32,2,8,35,11,1,0,3,40,33,0,35,34,1,32,0,33,33,34,2,40,34,1,2,35,1,32,32,2,32,32,10]

theorem envBound7202 : H12AffineFastState.Bounded env7202 := by
  intro p hp
  have h : env7202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7201_7202 : H12AffineEnvironment.transform 8 11 env7201 = env7202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7201 == env7202) = true)

def env7203 : List Nat := [2,4,8,16,32,5,9,48,512,20,522,16,40,33,1,55,49,542,53,1,32,33,49,22,41,48,522,17,48,522,33,33,17,33,52,532]

theorem envBound7203 : H12AffineFastState.Bounded env7203 := by
  intro p hp
  have h : env7203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7198_7203 : H12AffineEnvironment.transform 5 5 env7198 = env7203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env7198 == env7203) = true)

theorem identity7203 : scanCanonicalize (H12AffineFastState.compose env7203 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7204 : List Nat := [2,4,8,16,32,5,9,48,11,20,1,16,40,33,1,55,49,21,53,1,32,33,49,22,41,48,1,17,48,1,33,33,17,33,52,31]

theorem envBound7204 : H12AffineFastState.Bounded env7204 := by
  intro p hp
  have h : env7204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7203_7204 : H12AffineEnvironment.transform 8 11 env7203 = env7204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7203 == env7204) = true)

theorem identity7204 : scanCanonicalize (H12AffineFastState.compose env7204 (packedSelected [20] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7204 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7205 : List Nat := [2,4,8,4,32,5,9,36,11,0,1,4,40,33,1,35,37,1,33,1,32,33,37,2,41,36,1,5,36,1,33,33,5,33,32,11]

theorem envBound7205 : H12AffineFastState.Bounded env7205 := by
  intro p hp
  have h : env7205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7204_7205 : H12AffineEnvironment.transform 3 4 env7204 = env7205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7204 == env7205) = true)

theorem identity7205 : scanCanonicalize (H12AffineFastState.compose env7205 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7206 : List Nat := [2,4,8,4,12,5,9,8,11,0,1,4,4,13,1,15,9,1,13,1,12,13,9,2,5,8,1,5,8,1,13,13,5,13,12,11]

theorem envBound7206 : H12AffineFastState.Bounded env7206 := by
  intro p hp
  have h : env7206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7205_7206 : H12AffineEnvironment.transform 4 12 env7205 = env7206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7205 == env7206) = true)

def leafEnv7206 : List Nat := [2,4,8,4,12,5,9,8,11,0,1,4,4,13,1,15,9,1,13,1,12,13,9,2,0,5,1,8,1,5,8,1,13,13,5,13,9,15,12,11,1,13,0]

def active7206 : List Nat := [0,1,2]

def tree7206 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7206 : H12WitnessSearch.Good tree7206 := H12GlobalWitnessIndex.good

theorem leafIdentity7206 : H12AffineFastState.composeSystem env7206 rootObs = leafEnv7206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7206 rootObs == leafEnv7206) = true)

theorem terminalChecked7206 : H12PackedTerminal.terminalCheckFast leafEnv7206 active7206 tree7206 = true := by decide +kernel

def env7207 : List Nat := [2,4,8,16,32,64,128,252,512,217,590,16,40,33,136,191,49,603,248,136,169,33,49,158,160,116,711,220,253,711,100,168,221,168,188,533]

theorem envBound7207 : H12AffineFastState.Bounded env7207 := by
  intro p hp
  have h : env7207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7196_7207 : H12AffineEnvironment.transform 9 217 env7196 = env7207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 217 env7196 == env7207) = true)

theorem identity7207 : scanCanonicalize (H12AffineFastState.compose env7207 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound7207 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env7208 : List Nat := [2,4,8,16,32,64,89,37,512,0,590,16,40,33,81,102,49,603,33,81,112,33,49,71,121,116,542,5,36,542,100,113,4,113,101,533]

theorem envBound7208 : H12AffineFastState.Bounded env7208 := by
  intro p hp
  have h : env7208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7207_7208 : H12AffineEnvironment.transform 6 89 env7207 = env7208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env7207 == env7208) = true)

def env7209 : List Nat := [2,4,8,16,32,16,9,37,512,0,542,16,40,33,1,54,49,523,33,1,32,33,49,23,41,36,542,5,36,542,52,33,4,33,53,533]

theorem envBound7209 : H12AffineFastState.Bounded env7209 := by
  intro p hp
  have h : env7209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7208_7209 : H12AffineEnvironment.transform 5 16 env7208 = env7209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env7208 == env7209) = true)

theorem identity7209 : scanCanonicalize (H12AffineFastState.compose env7209 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound7209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7210 : List Nat := [2,4,8,16,32,16,9,37,31,0,1,16,40,33,1,54,49,20,33,1,32,33,49,23,41,36,1,5,36,1,52,33,4,33,53,10]

theorem envBound7210 : H12AffineFastState.Bounded env7210 := by
  intro p hp
  have h : env7210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7209_7210 : H12AffineEnvironment.transform 8 31 env7209 = env7210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env7209 == env7210) = true)

theorem identity7210 : scanCanonicalize (H12AffineFastState.compose env7210 (packedSelected [20] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound7210 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7211 : List Nat := [2,4,8,5,32,5,9,37,10,0,1,5,40,33,1,35,36,1,33,1,32,33,36,2,41,36,1,5,36,1,33,33,4,33,32,10]

theorem envBound7211 : H12AffineFastState.Bounded env7211 := by
  intro p hp
  have h : env7211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7210_7211 : H12AffineEnvironment.transform 3 5 env7210 = env7211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env7210 == env7211) = true)

theorem identity7211 : scanCanonicalize (H12AffineFastState.compose env7211 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7212 : List Nat := [2,4,8,5,12,5,9,9,10,0,1,5,4,13,1,15,8,1,13,1,12,13,8,2,5,8,1,5,8,1,13,13,4,13,12,10]

theorem envBound7212 : H12AffineFastState.Bounded env7212 := by
  intro p hp
  have h : env7212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7211_7212 : H12AffineEnvironment.transform 4 12 env7211 = env7212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7211 == env7212) = true)

def leafEnv7212 : List Nat := [2,4,8,5,12,5,9,9,10,0,1,5,4,13,1,15,8,1,13,1,12,13,8,2,0,5,1,8,1,5,8,1,13,13,4,13,9,15,12,10,1,13,0]

def active7212 : List Nat := [0,1,2]

def tree7212 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7212 : H12WitnessSearch.Good tree7212 := H12GlobalWitnessIndex.good

theorem leafIdentity7212 : H12AffineFastState.composeSystem env7212 rootObs = leafEnv7212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7212 rootObs == leafEnv7212) = true)

theorem terminalChecked7212 : H12PackedTerminal.terminalCheckFast leafEnv7212 active7212 tree7212 = true := by decide +kernel

def env7213 : List Nat := [2,4,8,16,32,17,8,37,512,0,543,16,40,33,0,55,49,522,33,0,33,33,49,22,40,37,542,5,36,542,53,32,4,32,52,533]

theorem envBound7213 : H12AffineFastState.Bounded env7213 := by
  intro p hp
  have h : env7213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7208_7213 : H12AffineEnvironment.transform 5 17 env7208 = env7213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env7208 == env7213) = true)

theorem identity7213 : scanCanonicalize (H12AffineFastState.compose env7213 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7213 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7214 : List Nat := [2,4,8,4,32,5,8,37,512,0,523,4,40,33,0,35,37,522,33,0,33,33,37,2,40,37,522,5,36,522,33,32,4,32,32,513]

theorem envBound7214 : H12AffineFastState.Bounded env7214 := by
  intro p hp
  have h : env7214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7213_7214 : H12AffineEnvironment.transform 3 4 env7213 = env7214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7213 == env7214) = true)

theorem identity7214 : scanCanonicalize (H12AffineFastState.compose env7214 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound7214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7215 : List Nat := [2,3,8,3,32,2,8,34,512,0,523,3,40,33,0,35,34,522,33,0,33,33,34,2,40,34,522,2,35,522,33,32,3,32,32,513]

theorem envBound7215 : H12AffineFastState.Bounded env7215 := by
  intro p hp
  have h : env7215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7214_7215 : H12AffineEnvironment.transform 1 3 env7214 = env7215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env7214 == env7215) = true)

theorem identity7215 : scanCanonicalize (H12AffineFastState.compose env7215 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7215 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7216 : List Nat := [2,3,8,3,32,2,8,34,11,0,0,3,40,33,0,35,34,1,33,0,33,33,34,2,40,34,1,2,35,1,33,32,3,32,32,10]

theorem envBound7216 : H12AffineFastState.Bounded env7216 := by
  intro p hp
  have h : env7216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7215_7216 : H12AffineEnvironment.transform 8 11 env7215 = env7216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7215 == env7216) = true)

def env7217 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,17,41,32,137,1126,49,603,1057,137,168,33,49,1094,161,1196,1567,1029,1061,1566,101,168,221,168,1124,1741]

theorem envBound7217 : H12AffineFastState.Bounded env7217 := by
  intro p hp
  have h : env7217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7195_7217 : H12AffineEnvironment.transform 11 17 env7195 = env7217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env7195 == env7217) = true)

theorem identity7217 : scanCanonicalize (H12AffineFastState.compose env7217 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound7217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7218 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1566,17,41,32,0,1126,49,603,1057,0,33,33,49,1094,40,1061,1567,1029,1061,1566,101,33,84,33,1124,1604]

theorem envBound7218 : H12AffineFastState.Bounded env7218 := by
  intro p hp
  have h : env7218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7217_7218 : H12AffineEnvironment.transform 6 9 env7217 = env7218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7217 == env7218) = true)

theorem identity7218 : scanCanonicalize (H12AffineFastState.compose env7218 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7218 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7219 : List Nat := [2,4,8,16,32,64,9,117,512,69,603,17,41,32,0,35,49,603,100,0,33,33,49,3,40,96,602,64,96,603,101,33,84,33,33,513]

theorem envBound7219 : H12AffineFastState.Bounded env7219 := by
  intro p hp
  have h : env7219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7218_7219 : H12AffineEnvironment.transform 9 69 env7218 = env7219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7218 == env7219) = true)

theorem identity7219 : scanCanonicalize (H12AffineFastState.compose env7219 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 73) := by decide +kernel

theorem selectedBound7219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7220 : List Nat := [2,4,8,16,32,64,9,117,73,69,18,17,41,32,0,35,49,18,100,0,33,33,49,3,40,96,19,64,96,18,101,33,84,33,33,72]

theorem envBound7220 : H12AffineFastState.Bounded env7220 := by
  intro p hp
  have h : env7220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7219_7220 : H12AffineEnvironment.transform 8 73 env7219 = env7220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 73 env7219 == env7220) = true)

theorem identity7220 : scanCanonicalize (H12AffineFastState.compose env7220 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound7220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7221 : List Nat := [2,4,8,16,32,3,9,54,10,6,18,17,41,32,0,35,49,18,39,0,33,33,49,3,40,35,19,3,35,18,38,33,23,33,33,11]

theorem envBound7221 : H12AffineFastState.Bounded env7221 := by
  intro p hp
  have h : env7221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7220_7221 : H12AffineEnvironment.transform 5 3 env7220 = env7221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env7220 == env7221) = true)

theorem identity7221 : scanCanonicalize (H12AffineFastState.compose env7221 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound7221 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7222 : List Nat := [2,4,8,2,32,3,9,36,10,6,0,3,41,32,0,35,35,0,39,0,33,33,35,3,40,35,1,3,35,0,38,33,5,33,33,11]

theorem envBound7222 : H12AffineFastState.Bounded env7222 := by
  intro p hp
  have h : env7222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7221_7222 : H12AffineEnvironment.transform 3 2 env7221 = env7222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env7221 == env7222) = true)

def env7223 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,4096,4153,4145,4249,1126,48,603,1057,4249,4281,33,49,5206,4273,5308,5647,1028,5172,1566,4213,168,221,168,5237,5853]

theorem envBound7223 : H12AffineFastState.Bounded env7223 := by
  intro p hp
  have h : env7223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7194_7223 : H12AffineEnvironment.transform 12 4153 env7194 = env7223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env7194 == env7223) = true)

def env7224 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,16,41,33,137,1126,48,603,1057,137,169,33,49,1094,161,1196,1567,1028,1060,1566,101,168,221,168,1125,1741]

theorem envBound7224 : H12AffineFastState.Bounded env7224 := by
  intro p hp
  have h : env7224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7223_7224 : H12AffineEnvironment.transform 11 16 env7223 = env7224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env7223 == env7224) = true)

theorem identity7224 : scanCanonicalize (H12AffineFastState.compose env7224 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7224 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7225 : List Nat := [2,4,8,16,32,64,128,252,512,68,723,16,41,33,137,34,48,603,101,137,169,33,49,2,161,232,603,64,96,602,101,168,221,168,33,649]

theorem envBound7225 : H12AffineFastState.Bounded env7225 := by
  intro p hp
  have h : env7225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7224_7225 : H12AffineEnvironment.transform 9 68 env7224 = env7225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7224 == env7225) = true)

def env7226 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,17,40,32,136,1126,48,603,1057,136,168,33,49,1095,160,1197,1566,1028,1061,1566,100,168,221,168,1124,1740]

theorem envBound7226 : H12AffineFastState.Bounded env7226 := by
  intro p hp
  have h : env7226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7223_7226 : H12AffineEnvironment.transform 11 17 env7223 = env7226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env7223 == env7226) = true)

theorem identity7226 : scanCanonicalize (H12AffineFastState.compose env7226 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound7226 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7227 : List Nat := [2,4,8,16,32,64,128,252,512,204,603,17,40,32,136,170,48,603,237,136,168,33,49,139,160,97,722,200,233,722,100,168,221,168,168,512]

theorem envBound7227 : H12AffineFastState.Bounded env7227 := by
  intro p hp
  have h : env7227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7226_7227 : H12AffineEnvironment.transform 9 204 env7226 = env7227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env7226 == env7227) = true)

theorem identity7227 : scanCanonicalize (H12AffineFastState.compose env7227 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound7227 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env7228 : List Nat := [2,4,8,16,32,5,128,185,512,137,542,17,40,32,136,170,48,542,168,136,168,33,49,139,160,36,663,141,172,663,33,168,152,168,168,512]

theorem envBound7228 : H12AffineFastState.Bounded env7228 := by
  intro p hp
  have h : env7228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7227_7228 : H12AffineEnvironment.transform 5 5 env7227 = env7228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env7227 == env7228) = true)

theorem identity7228 : scanCanonicalize (H12AffineFastState.compose env7228 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound7228 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7229 : List Nat := [2,4,8,16,32,5,9,48,512,0,542,17,40,32,1,35,48,542,33,1,33,33,49,2,41,36,542,4,37,542,33,33,17,33,33,512]

theorem envBound7229 : H12AffineFastState.Bounded env7229 := by
  intro p hp
  have h : env7229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7228_7229 : H12AffineEnvironment.transform 6 9 env7228 = env7229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7228 == env7229) = true)

theorem identity7229 : scanCanonicalize (H12AffineFastState.compose env7229 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7230 : List Nat := [2,4,8,16,13,5,9,29,512,0,542,17,5,13,1,14,29,542,12,1,12,12,28,2,4,9,542,4,8,542,12,12,17,12,12,512]

theorem envBound7230 : H12AffineFastState.Bounded env7230 := by
  intro p hp
  have h : env7230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7229_7230 : H12AffineEnvironment.transform 4 13 env7229 = env7230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7229 == env7230) = true)

theorem identity7230 : scanCanonicalize (H12AffineFastState.compose env7230 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound7230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7231 : List Nat := [2,4,8,16,13,5,9,29,30,0,0,17,5,13,1,14,29,0,12,1,12,12,28,2,4,9,0,4,8,0,12,12,17,12,12,30]

theorem envBound7231 : H12AffineFastState.Bounded env7231 := by
  intro p hp
  have h : env7231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7230_7231 : H12AffineEnvironment.transform 8 30 env7230 = env7231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env7230 == env7231) = true)

def leafEnv7231 : List Nat := [2,4,8,16,13,5,9,29,30,0,0,17,5,13,1,14,29,0,12,1,12,12,28,2,0,4,1,9,0,4,8,0,12,12,17,12,8,14,12,30,1,13,0]

def active7231 : List Nat := [0,1,2,3]

def tree7231 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7231 : H12WitnessSearch.Good tree7231 := H12GlobalWitnessIndex.good

theorem leafIdentity7231 : H12AffineFastState.composeSystem env7231 rootObs = leafEnv7231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7231 rootObs == leafEnv7231) = true)

theorem terminalChecked7231 : H12PackedTerminal.terminalCheckFast leafEnv7231 active7231 tree7231 = true := by decide +kernel

def env7232 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,16030,3277,2742,8352,4280,33,3750,11000,8328,9349,9783,13372,6818,2185,11995,168,3658,168,6883,10355]

theorem envBound7232 : H12AffineFastState.Bounded env7232 := by
  intro p hp
  have h : env7232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7192_7232 : H12AffineEnvironment.transform 17 3277 env7192 = env7232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3277 env7192 == env7232) = true)

theorem identity7232 : scanCanonicalize (H12AffineFastState.compose env7232 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1253) := by decide +kernel

theorem selectedBound7232 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7233 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1253,7846,1093,2801,6779,3277,2742,1093,4280,33,3750,3613,1133,96,722,4313,6818,2185,2622,168,3658,168,6883,3222]

theorem envBound7233 : H12AffineFastState.Bounded env7233 := by
  intro p hp
  have h : env7233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7232_7233 : H12AffineEnvironment.transform 12 1253 env7232 = env7233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1253 env7232 == env7233) = true)

def env7234 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,16,1253,3766,1093,2801,2667,3277,2742,1093,168,33,3750,3613,1133,96,722,201,2738,2185,2622,168,3658,168,2803,3222]

theorem envBound7234 : H12AffineFastState.Bounded env7234 := by
  intro p hp
  have h : env7234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7233_7234 : H12AffineEnvironment.transform 11 16 env7233 = env7234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env7233 == env7234) = true)

def env7235 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,16,1133,3646,1093,2681,2667,3141,2622,1093,32,33,3630,3613,1133,96,602,65,2618,2049,2622,32,3658,32,2683,3102]

theorem envBound7235 : H12AffineFastState.Bounded env7235 := by
  intro p hp
  have h : env7235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7234_7235 : H12AffineEnvironment.transform 6 8 env7234 = env7235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7234 == env7235) = true)

theorem identity7235 : scanCanonicalize (H12AffineFastState.compose env7235 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound7235 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7236 : List Nat := [2,4,8,16,32,64,8,116,512,1024,602,16,1133,1124,1093,35,49,1567,100,1093,32,33,1140,1095,1133,96,602,65,96,603,100,32,1040,32,33,1604]

theorem envBound7236 : H12AffineFastState.Bounded env7236 := by
  intro p hp
  have h : env7236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7235_7236 : H12AffineEnvironment.transform 10 602 env7235 = env7236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env7235 == env7236) = true)

theorem identity7236 : scanCanonicalize (H12AffineFastState.compose env7236 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound7236 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7237 : List Nat := [2,4,8,16,32,64,8,116,512,543,602,16,626,635,602,35,49,0,100,602,32,33,619,600,626,96,602,65,96,603,100,32,527,32,33,91]

theorem envBound7237 : H12AffineFastState.Bounded env7237 := by
  intro p hp
  have h : env7237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7236_7237 : H12AffineEnvironment.transform 9 543 env7236 = env7237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env7236 == env7237) = true)

theorem identity7237 : scanCanonicalize (H12AffineFastState.compose env7237 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound7237 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7238 : List Nat := [2,4,8,16,32,64,8,116,91,68,1,16,41,32,1,35,49,0,100,1,32,33,48,3,41,96,1,65,96,0,100,32,84,32,33,91]

theorem envBound7238 : H12AffineFastState.Bounded env7238 := by
  intro p hp
  have h : env7238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7237_7238 : H12AffineEnvironment.transform 8 91 env7237 = env7238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env7237 == env7238) = true)

theorem identity7238 : scanCanonicalize (H12AffineFastState.compose env7238 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound7238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7239 : List Nat := [2,4,8,16,32,8,8,60,19,12,1,16,41,32,1,35,49,0,44,1,32,33,48,3,41,40,1,9,40,0,44,32,28,32,33,19]

theorem envBound7239 : H12AffineFastState.Bounded env7239 := by
  intro p hp
  have h : env7239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7238_7239 : H12AffineEnvironment.transform 5 8 env7238 = env7239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env7238 == env7239) = true)

theorem identity7239 : scanCanonicalize (H12AffineFastState.compose env7239 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7239 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7240 : List Nat := [2,4,8,4,32,8,8,40,7,12,1,4,41,32,1,35,37,0,44,1,32,33,36,3,41,40,1,9,40,0,44,32,8,32,33,7]

theorem envBound7240 : H12AffineFastState.Bounded env7240 := by
  intro p hp
  have h : env7240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7239_7240 : H12AffineEnvironment.transform 3 4 env7239 = env7240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7239 == env7240) = true)

def leafEnv7240 : List Nat := [2,4,8,4,32,8,8,40,7,12,1,4,41,32,1,35,37,0,44,1,32,33,36,3,12,41,1,40,1,9,40,0,44,32,8,32,36,34,33,7,1,33,0]

def active7240 : List Nat := [0,1,2,4]

def tree7240 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7240 : H12WitnessSearch.Good tree7240 := H12GlobalWitnessIndex.good

theorem leafIdentity7240 : H12AffineFastState.composeSystem env7240 rootObs = leafEnv7240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7240 rootObs == leafEnv7240) = true)

theorem terminalChecked7240 : H12PackedTerminal.terminalCheckFast leafEnv7240 active7240 tree7240 = true := by decide +kernel

def env7241 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,16,1132,3647,1093,2680,2667,3140,2623,1093,33,33,3631,3613,1133,96,603,64,2619,2048,2622,33,3658,33,2682,3103]

theorem envBound7241 : H12AffineFastState.Bounded env7241 := by
  intro p hp
  have h : env7241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7234_7241 : H12AffineEnvironment.transform 6 9 env7234 = env7241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7234 == env7241) = true)

theorem identity7241 : scanCanonicalize (H12AffineFastState.compose env7241 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound7241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7242 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1566,16,1132,33,1093,1126,1141,602,1057,1093,33,33,49,3,1133,96,603,64,1061,1566,1056,33,84,33,1124,513]

theorem envBound7242 : H12AffineFastState.Bounded env7242 := by
  intro p hp
  have h : env7242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7241_7242 : H12AffineEnvironment.transform 10 1566 env7241 = env7242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env7241 == env7242) = true)

theorem identity7242 : scanCanonicalize (H12AffineFastState.compose env7242 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound7242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7243 : List Nat := [2,4,8,16,32,64,9,117,512,20,522,16,120,33,81,114,97,602,53,81,33,33,49,3,121,96,603,64,49,522,52,33,84,33,112,513]

theorem envBound7243 : H12AffineFastState.Bounded env7243 := by
  intro p hp
  have h : env7243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7242_7243 : H12AffineEnvironment.transform 9 20 env7242 = env7243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env7242 == env7243) = true)

theorem identity7243 : scanCanonicalize (H12AffineFastState.compose env7243 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound7243 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7244 : List Nat := [2,4,8,16,32,64,9,117,91,20,81,16,120,33,81,114,97,1,53,81,33,33,49,3,121,96,0,64,49,81,52,33,84,33,112,90]

theorem envBound7244 : H12AffineFastState.Bounded env7244 := by
  intro p hp
  have h : env7244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7243_7244 : H12AffineEnvironment.transform 8 91 env7243 = env7244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env7243 == env7244) = true)

def env7245 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,17,1253,3767,1093,2801,2666,3277,2742,1093,169,33,3750,3613,1133,96,722,200,2739,2185,2622,168,3658,168,2802,3222]

theorem envBound7245 : H12AffineFastState.Bounded env7245 := by
  intro p hp
  have h : env7245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7233_7245 : H12AffineEnvironment.transform 11 17 env7233 = env7245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env7233 == env7245) = true)

def env7246 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,17,1133,3647,1093,2681,2666,3141,2622,1093,33,33,3630,3613,1133,96,602,64,2619,2049,2622,32,3658,32,2682,3102]

theorem envBound7246 : H12AffineFastState.Bounded env7246 := by
  intro p hp
  have h : env7246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7245_7246 : H12AffineEnvironment.transform 6 8 env7245 = env7246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7245 == env7246) = true)

theorem identity7246 : scanCanonicalize (H12AffineFastState.compose env7246 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7247 : List Nat := [2,4,8,16,32,64,8,116,512,68,2048,17,41,2683,1,2681,2666,2049,2622,1,33,33,2666,2649,41,96,602,64,2619,2049,2622,32,2574,32,2682,2138]

theorem envBound7247 : H12AffineFastState.Bounded env7247 := by
  intro p hp
  have h : env7247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7246_7247 : H12AffineEnvironment.transform 9 68 env7246 = env7247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7246 == env7247) = true)

theorem identity7247 : scanCanonicalize (H12AffineFastState.compose env7247 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound7247 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env7248 : List Nat := [2,4,8,16,32,64,8,116,512,68,0,17,41,635,1,633,618,1,574,1,33,33,618,601,41,96,602,64,571,1,574,32,526,32,634,90]

theorem envBound7248 : H12AffineFastState.Bounded env7248 := by
  intro p hp
  have h : env7248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7247_7248 : H12AffineEnvironment.transform 10 0 env7247 = env7248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env7247 == env7248) = true)

theorem identity7248 : scanCanonicalize (H12AffineFastState.compose env7248 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound7248 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7249 : List Nat := [2,4,8,16,32,64,8,116,90,68,0,17,41,33,1,35,48,1,100,1,33,33,48,3,41,96,0,64,97,1,100,32,84,32,32,90]

theorem envBound7249 : H12AffineFastState.Bounded env7249 := by
  intro p hp
  have h : env7249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7248_7249 : H12AffineEnvironment.transform 8 90 env7248 = env7249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env7248 == env7249) = true)

theorem identity7249 : scanCanonicalize (H12AffineFastState.compose env7249 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound7249 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7250 : List Nat := [2,4,8,16,32,9,8,61,19,13,0,17,41,33,1,35,48,1,45,1,33,33,48,3,41,41,0,9,40,1,45,32,29,32,32,19]

theorem envBound7250 : H12AffineFastState.Bounded env7250 := by
  intro p hp
  have h : env7250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7249_7250 : H12AffineEnvironment.transform 5 9 env7249 = env7250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env7249 == env7250) = true)

theorem identity7250 : scanCanonicalize (H12AffineFastState.compose env7250 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7251 : List Nat := [2,4,8,4,32,9,8,41,7,13,0,5,41,33,1,35,36,1,45,1,33,33,36,3,41,41,0,9,40,1,45,32,9,32,32,7]

theorem envBound7251 : H12AffineFastState.Bounded env7251 := by
  intro p hp
  have h : env7251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7250_7251 : H12AffineEnvironment.transform 3 4 env7250 = env7251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7250 == env7251) = true)

def leafEnv7251 : List Nat := [2,4,8,4,32,9,8,41,7,13,0,5,41,33,1,35,36,1,45,1,33,33,36,3,13,41,1,41,0,9,40,1,45,32,9,32,36,34,32,7,1,32,0]

def active7251 : List Nat := [0,1,2,4]

def tree7251 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7251 : H12WitnessSearch.Good tree7251 := H12GlobalWitnessIndex.good

theorem leafIdentity7251 : H12AffineFastState.composeSystem env7251 rootObs = leafEnv7251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7251 rootObs == leafEnv7251) = true)

theorem terminalChecked7251 : H12PackedTerminal.terminalCheckFast leafEnv7251 active7251 tree7251 = true := by decide +kernel

def env7252 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,17,1132,3646,1093,2680,2666,3140,2623,1093,32,33,3631,3613,1133,96,603,65,2618,2048,2622,33,3658,33,2683,3103]

theorem envBound7252 : H12AffineFastState.Bounded env7252 := by
  intro p hp
  have h : env7252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7245_7252 : H12AffineEnvironment.transform 6 9 env7245 = env7252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7245 == env7252) = true)

def env7253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103731,262144,62640,32768,2097152,41089,20481,98644,8328,118898,360619,2216050,2118977,2420,99702,40968,61872,341,34359738368,98850]

theorem envBound7253 : H12AffineFastState.Bounded env7253 := by
  intro p hp
  have h : env7253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7179_7253 : H12AffineEnvironment.transform 22 20481 env7179 = env7253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env7179 == env7253) = true)

def env7254 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103631,262144,62640,32768,2097152,41089,20481,98472,8328,118898,360619,2216050,2118845,2184,99466,40968,61516,169,34359738368,98850]

theorem envBound7254 : H12AffineFastState.Bounded env7254 := by
  intro p hp
  have h : env7254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7253_7254 : H12AffineEnvironment.transform 7 252 env7253 = env7254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7253 == env7254) = true)

theorem identity7254 : scanCanonicalize (H12AffineFastState.compose env7254 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 269429) := by decide +kernel

theorem selectedBound7254 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7255 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,103631,262144,62640,32768,269429,41089,20481,98472,8328,118898,360619,379911,280776,2184,99466,40968,61516,169,34359738368,98850]

theorem envBound7255 : H12AffineFastState.Bounded env7255 := by
  intro p hp
  have h : env7255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7254_7255 : H12AffineEnvironment.transform 20 269429 env7254 = env7255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 269429 env7254 == env7255) = true)

theorem identity7255 : scanCanonicalize (H12AffineFastState.compose env7255 (packedSelected [11,13,18] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound7255 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env7256 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,78958,262144,21521,8353,269429,32,20481,73737,8328,94419,335882,355494,280776,2184,74795,169,20717,169,34359738368,74371]

theorem envBound7256 : H12AffineFastState.Bounded env7256 := by
  intro p hp
  have h : env7256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7255_7256 : H12AffineEnvironment.transform 14 8353 env7255 = env7256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env7255 == env7256) = true)

theorem identity7256 : scanCanonicalize (H12AffineFastState.compose env7256 (packedSelected [2,13,14] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7256 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7257 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,78958,262144,21521,8353,269429,32,20481,73737,8328,94419,335882,355494,280776,2184,74795,169,20717,169,280712,74371]

theorem envBound7257 : H12AffineFastState.Bounded env7257 := by
  intro p hp
  have h : env7257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7256_7257 : H12AffineEnvironment.transform 34 280712 env7256 = env7257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7256 == env7257) = true)

theorem identity7257 : scanCanonicalize (H12AffineFastState.compose env7257 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound7257 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7258 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,65536,78958,262144,2742,8353,269429,32,3750,73737,8328,77428,335882,340481,267887,2184,74795,169,3658,169,267823,74371]

theorem envBound7258 : H12AffineFastState.Bounded env7258 := by
  intro p hp
  have h : env7258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7257_7258 : H12AffineEnvironment.transform 13 7847 env7257 = env7258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env7257 == env7258) = true)

def env7259 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,16030,262144,2742,8353,269429,32,3750,11001,8328,9348,273146,276721,267887,2184,11995,169,3658,169,267823,10355]

theorem envBound7259 : H12AffineFastState.Bounded env7259 := by
  intro p hp
  have h : env7259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7258_7259 : H12AffineEnvironment.transform 15 2800 env7258 = env7259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7258 == env7259) = true)

theorem identity7259 : scanCanonicalize (H12AffineFastState.compose env7259 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 4843) := by decide +kernel

theorem selectedBound7259 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7260 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,4843,7847,4682,2800,3189,262144,2742,4682,269429,32,3750,6162,4707,5743,268305,264730,267887,2184,7216,169,3658,169,267823,6808]

theorem envBound7260 : H12AffineFastState.Bounded env7260 := by
  intro p hp
  have h : env7260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7259_7260 : H12AffineEnvironment.transform 12 4843 env7259 = env7260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4843 env7259 == env7260) = true)

theorem identity7260 : scanCanonicalize (H12AffineFastState.compose env7260 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound7260 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7261 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,587,160,3308,1,2800,3189,262144,2742,1,265790,32,3750,2649,40,1060,264794,264730,263204,2184,3707,169,3658,169,263268,2259]

theorem envBound7261 : H12AffineFastState.Bounded env7261 := by
  intro p hp
  have h : env7261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7260_7261 : H12AffineEnvironment.transform 11 587 env7260 = env7261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env7260 == env7261) = true)

theorem identity7261 : scanCanonicalize (H12AffineFastState.compose env7261 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1687) := by decide +kernel

theorem selectedBound7261 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env7262 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,587,160,635,1,1127,738,262144,1057,1,262313,32,49,1230,40,1060,263373,263309,263204,1567,236,169,221,169,263268,1604]

theorem envBound7262 : H12AffineFastState.Bounded env7262 := by
  intro p hp
  have h : env7262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7261_7262 : H12AffineEnvironment.transform 10 1687 env7261 = env7262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1687 env7261 == env7262) = true)

theorem identity7262 : scanCanonicalize (H12AffineFastState.compose env7262 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7262 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7263 : List Nat := [2,4,8,16,32,64,128,252,512,68,723,587,160,635,1,35,738,262144,101,1,262313,32,49,138,40,96,262281,262345,262240,603,236,169,221,169,262176,512]

theorem envBound7263 : H12AffineFastState.Bounded env7263 := by
  intro p hp
  have h : env7263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7262_7263 : H12AffineEnvironment.transform 9 68 env7262 = env7263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7262 == env7263) = true)

theorem identity7263 : scanCanonicalize (H12AffineFastState.compose env7263 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 76) := by decide +kernel

theorem selectedBound7263 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7264 : List Nat := [2,4,8,16,32,64,76,48,512,68,543,587,108,635,1,35,558,262144,101,1,262245,32,49,70,40,96,262213,262149,262240,603,32,101,17,101,262176,512]

theorem envBound7264 : H12AffineFastState.Bounded env7264 := by
  intro p hp
  have h : env7264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7263_7264 : H12AffineEnvironment.transform 6 76 env7263 = env7264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 76 env7263 == env7264) = true)

def env7265 : List Nat := [2,4,8,16,32,64,76,48,512,68,543,587,108,635,1,35,558,0,101,1,101,32,49,70,40,96,69,5,96,603,32,101,17,101,32,512]

theorem envBound7265 : H12AffineFastState.Bounded env7265 := by
  intro p hp
  have h : env7265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7264_7265 : H12AffineEnvironment.transform 17 0 env7264 = env7265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env7264 == env7265) = true)

theorem identity7265 : scanCanonicalize (H12AffineFastState.compose env7265 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 118) := by decide +kernel

theorem selectedBound7265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7266 : List Nat := [2,4,8,16,32,64,76,48,118,68,105,61,108,13,1,35,88,0,101,1,101,32,49,70,40,96,69,5,96,45,32,101,17,101,32,118]

theorem envBound7266 : H12AffineFastState.Bounded env7266 := by
  intro p hp
  have h : env7266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7265_7266 : H12AffineEnvironment.transform 8 118 env7265 = env7266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 118 env7265 == env7266) = true)

def env7267 : List Nat := [2,4,8,16,32,40,36,48,30,44,1,61,4,13,1,35,48,0,13,1,13,32,49,46,40,8,45,5,8,45,32,13,17,13,32,30]

theorem envBound7267 : H12AffineFastState.Bounded env7267 := by
  intro p hp
  have h : env7267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7266_7267 : H12AffineEnvironment.transform 5 40 env7266 = env7267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 40 env7266 == env7267) = true)

def env7268 : List Nat := [2,4,8,16,32,41,37,48,31,45,0,61,5,13,1,35,49,0,12,1,12,32,49,47,40,9,44,5,9,45,32,12,17,12,32,31]

theorem envBound7268 : H12AffineFastState.Bounded env7268 := by
  intro p hp
  have h : env7268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7266_7268 : H12AffineEnvironment.transform 5 41 env7266 = env7268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 41 env7266 == env7268) = true)

theorem identity7268 : scanCanonicalize (H12AffineFastState.compose env7268 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7269 : List Nat := [2,4,8,16,13,4,8,29,31,0,0,16,5,13,1,14,28,0,12,1,12,13,28,2,5,9,1,5,9,0,13,12,17,12,13,31]

theorem envBound7269 : H12AffineFastState.Bounded env7269 := by
  intro p hp
  have h : env7269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7268_7269 : H12AffineEnvironment.transform 4 13 env7268 = env7269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7268 == env7269) = true)

def leafEnv7269 : List Nat := [2,4,8,16,13,4,8,29,31,0,0,16,5,13,1,14,28,0,12,1,12,13,28,2,0,5,1,9,1,5,9,0,13,12,17,12,9,14,13,31,1,13,0]

def active7269 : List Nat := [0,1,2,3]

def tree7269 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7269 : H12WitnessSearch.Good tree7269 := H12GlobalWitnessIndex.good

theorem leafIdentity7269 : H12AffineFastState.composeSystem env7269 rootObs = leafEnv7269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7269 rootObs == leafEnv7269) = true)

theorem terminalChecked7269 : H12PackedTerminal.terminalCheckFast leafEnv7269 active7269 tree7269 = true := by decide +kernel

def env7270 : List Nat := [2,4,8,16,32,64,76,48,512,68,543,587,108,635,1,35,558,1,101,1,100,32,49,70,40,96,68,4,97,603,32,101,17,101,33,512]

theorem envBound7270 : H12AffineFastState.Bounded env7270 := by
  intro p hp
  have h : env7270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7264_7270 : H12AffineEnvironment.transform 17 1 env7264 = env7270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env7264 == env7270) = true)

theorem identity7270 : scanCanonicalize (H12AffineFastState.compose env7270 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7271 : List Nat := [2,4,8,16,13,64,76,29,512,68,543,587,65,598,1,14,515,1,72,1,73,13,28,70,5,77,68,4,76,603,13,72,17,72,12,512]

theorem envBound7271 : H12AffineFastState.Bounded env7271 := by
  intro p hp
  have h : env7271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7270_7271 : H12AffineEnvironment.transform 4 13 env7270 = env7271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7270 == env7271) = true)

def env7272 : List Nat := [2,4,8,16,13,4,8,29,512,0,543,527,5,530,1,14,515,1,12,1,13,13,28,2,5,9,0,4,8,543,13,12,17,12,12,512]

theorem envBound7272 : H12AffineFastState.Bounded env7272 := by
  intro p hp
  have h : env7272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7271_7272 : H12AffineEnvironment.transform 5 4 env7271 = env7272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env7271 == env7272) = true)

theorem identity7272 : scanCanonicalize (H12AffineFastState.compose env7272 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound7272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7273 : List Nat := [2,4,8,16,13,4,8,29,31,0,0,16,5,13,1,14,28,1,12,1,13,13,28,2,5,9,0,4,8,0,13,12,17,12,12,31]

theorem envBound7273 : H12AffineFastState.Bounded env7273 := by
  intro p hp
  have h : env7273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7272_7273 : H12AffineEnvironment.transform 8 31 env7272 = env7273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env7272 == env7273) = true)

def leafEnv7273 : List Nat := [2,4,8,16,13,4,8,29,31,0,0,16,5,13,1,14,28,1,12,1,13,13,28,2,0,5,1,9,0,4,8,0,13,12,17,12,9,14,12,31,1,13,0]

def active7273 : List Nat := [0,1,2,3]

def tree7273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7273 : H12WitnessSearch.Good tree7273 := H12GlobalWitnessIndex.good

theorem leafIdentity7273 : H12AffineFastState.composeSystem env7273 rootObs = leafEnv7273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7273 rootObs == leafEnv7273) = true)

theorem terminalChecked7273 : H12PackedTerminal.terminalCheckFast leafEnv7273 active7273 tree7273 = true := by decide +kernel

def env7274 : List Nat := [2,4,8,16,13,5,9,29,512,1,543,526,4,531,1,14,515,1,13,1,12,13,28,3,5,8,1,4,9,542,13,13,17,13,12,512]

theorem envBound7274 : H12AffineFastState.Bounded env7274 := by
  intro p hp
  have h : env7274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7271_7274 : H12AffineEnvironment.transform 5 5 env7271 = env7274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env7271 == env7274) = true)

def leafEnv7274 : List Nat := [2,4,8,16,13,5,9,29,512,1,543,526,4,531,1,14,515,1,13,1,12,13,28,3,0,5,1,8,1,4,9,542,13,13,17,13,9,15,12,512,1,530,0]

def active7274 : List Nat := [0,1,2,3,8]

def tree7274 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7274 : H12WitnessSearch.Good tree7274 := H12GlobalWitnessIndex.good

theorem leafIdentity7274 : H12AffineFastState.composeSystem env7274 rootObs = leafEnv7274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7274 rootObs == leafEnv7274) = true)

theorem terminalChecked7274 : H12PackedTerminal.terminalCheckFast leafEnv7274 active7274 tree7274 = true := by decide +kernel

def env7275 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,16031,262144,2742,8353,269429,32,3750,11000,8328,9349,273147,276720,267887,2184,11994,169,3658,169,267823,10354]

theorem envBound7275 : H12AffineFastState.Bounded env7275 := by
  intro p hp
  have h : env7275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7258_7275 : H12AffineEnvironment.transform 15 2801 env7258 = env7275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7258 == env7275) = true)

theorem identity7275 : scanCanonicalize (H12AffineFastState.compose env7275 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 4113) := by decide +kernel

theorem selectedBound7275 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7276 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,16031,4113,2742,8353,3172,32,3750,11000,8328,9349,15082,10465,1662,2184,11994,169,3658,169,1598,10354]

theorem envBound7276 : H12AffineFastState.Bounded env7276 := by
  intro p hp
  have h : env7276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7275_7276 : H12AffineEnvironment.transform 17 4113 env7275 = env7276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4113 env7275 == env7276) = true)

theorem identity7276 : scanCanonicalize (H12AffineFastState.compose env7276 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 722) := by decide +kernel

theorem selectedBound7276 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7277 : List Nat := [2,4,8,16,32,64,128,252,512,1024,722,4096,8192,5237,8353,35,13389,4113,100,8353,1718,32,1140,8234,8328,9349,12344,8755,1662,602,9224,169,1176,169,1598,8864]

theorem envBound7277 : H12AffineFastState.Bounded env7277 := by
  intro p hp
  have h : env7277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7276_7277 : H12AffineEnvironment.transform 10 722 env7276 = env7277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 722 env7276 == env7277) = true)

theorem identity7277 : scanCanonicalize (H12AffineFastState.compose env7277 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 1253) := by decide +kernel

theorem selectedBound7277 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env7278 : List Nat := [2,4,8,16,32,64,128,252,512,1024,722,4096,1253,5237,1092,35,4264,4113,100,1092,1718,32,1140,1231,1133,96,5341,1750,1662,602,237,169,1176,169,1598,1605]

theorem envBound7278 : H12AffineFastState.Bounded env7278 := by
  intro p hp
  have h : env7278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7277_7278 : H12AffineEnvironment.transform 12 1253 env7277 = env7278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1253 env7277 == env7278) = true)

theorem identity7278 : scanCanonicalize (H12AffineFastState.compose env7278 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7278 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env7279 : List Nat := [2,4,8,16,32,64,128,252,512,69,722,4096,160,4144,1,35,4264,4113,100,1,755,32,49,138,40,96,4248,659,571,602,237,169,221,169,635,512]

theorem envBound7279 : H12AffineFastState.Bounded env7279 := by
  intro p hp
  have h : env7279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7278_7279 : H12AffineEnvironment.transform 9 69 env7278 = env7279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7278 == env7279) = true)

theorem identity7279 : scanCanonicalize (H12AffineFastState.compose env7279 (packedSelected [1,2] rootPS)) = affineNative (2^(11+1) ^^^ 606) := by decide +kernel

theorem selectedBound7279 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env7280 : List Nat := [2,4,8,16,32,64,128,252,512,69,722,606,160,622,1,35,758,591,100,1,755,32,49,138,40,96,710,659,571,602,237,169,221,169,635,512]

theorem envBound7280 : H12AffineFastState.Bounded env7280 := by
  intro p hp
  have h : env7280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7279_7280 : H12AffineEnvironment.transform 11 606 env7279 = env7280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 606 env7279 == env7280) = true)

def env7281 : List Nat := [2,4,8,4,32,64,128,232,512,69,710,586,160,622,1,35,738,591,100,1,743,32,37,138,40,96,710,647,559,590,237,169,201,169,623,512]

theorem envBound7281 : H12AffineFastState.Bounded env7281 := by
  intro p hp
  have h : env7281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7280_7281 : H12AffineEnvironment.transform 3 4 env7280 = env7281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7280 == env7281) = true)

theorem identity7281 : scanCanonicalize (H12AffineFastState.compose env7281 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound7281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7282 : List Nat := [2,4,8,4,32,8,128,160,512,13,654,514,160,550,1,35,682,519,44,1,687,32,37,138,40,40,654,647,559,518,165,169,129,169,551,512]

theorem envBound7282 : H12AffineFastState.Bounded env7282 := by
  intro p hp
  have h : env7282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7281_7282 : H12AffineEnvironment.transform 5 8 env7281 = env7282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env7281 == env7282) = true)

theorem identity7282 : scanCanonicalize (H12AffineFastState.compose env7282 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound7282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7283 : List Nat := [2,4,8,4,32,8,128,160,7,13,137,5,160,33,1,35,173,0,44,1,168,32,37,138,40,40,137,128,40,1,165,169,129,169,32,7]

theorem envBound7283 : H12AffineFastState.Bounded env7283 := by
  intro p hp
  have h : env7283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7282_7283 : H12AffineEnvironment.transform 8 7 env7282 = env7283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env7282 == env7283) = true)

def leafEnv7283 : List Nat := [2,4,8,4,32,8,128,160,7,13,137,5,160,33,1,35,173,0,44,1,168,32,37,138,133,40,1,40,137,128,40,1,165,169,129,169,36,171,32,7,1,168,0]

def active7283 : List Nat := [0,1,2,4,6]

def tree7283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7283 : H12WitnessSearch.Good tree7283 := H12GlobalWitnessIndex.good

theorem leafIdentity7283 : H12AffineFastState.composeSystem env7283 rootObs = leafEnv7283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7283 rootObs == leafEnv7283) = true)

theorem terminalChecked7283 : H12PackedTerminal.terminalCheckFast leafEnv7283 active7283 tree7283 = true := by decide +kernel

def env7284 : List Nat := [2,4,8,5,32,64,128,233,512,69,711,587,160,622,1,35,739,591,100,1,742,32,36,138,40,96,710,646,558,591,237,169,200,169,622,512]

theorem envBound7284 : H12AffineFastState.Bounded env7284 := by
  intro p hp
  have h : env7284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7280_7284 : H12AffineEnvironment.transform 3 5 env7280 = env7284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env7280 == env7284) = true)

theorem identity7284 : scanCanonicalize (H12AffineFastState.compose env7284 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound7284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7285 : List Nat := [2,4,8,5,32,64,128,233,142,69,73,197,160,224,1,35,109,193,100,1,104,32,36,138,40,96,72,8,160,193,237,169,200,169,224,142]

theorem envBound7285 : H12AffineFastState.Bounded env7285 := by
  intro p hp
  have h : env7285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7284_7285 : H12AffineEnvironment.transform 8 142 env7284 = env7285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env7284 == env7285) = true)

theorem identity7285 : scanCanonicalize (H12AffineFastState.compose env7285 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound7285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7286 : List Nat := [2,4,8,5,32,8,128,161,142,13,1,141,160,168,1,35,37,137,44,1,32,32,36,138,40,40,0,8,160,137,165,169,128,169,168,142]

theorem envBound7286 : H12AffineFastState.Bounded env7286 := by
  intro p hp
  have h : env7286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7285_7286 : H12AffineEnvironment.transform 5 8 env7285 = env7286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env7285 == env7286) = true)

def leafEnv7286 : List Nat := [2,4,8,5,32,8,128,161,142,13,1,141,160,168,1,35,37,137,44,1,32,32,36,138,133,40,1,40,0,8,160,137,165,169,128,169,36,171,168,142,1,33,0]

def active7286 : List Nat := [0,1,2,4,6]

def tree7286 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7286 : H12WitnessSearch.Good tree7286 := H12GlobalWitnessIndex.good

theorem leafIdentity7286 : H12AffineFastState.composeSystem env7286 rootObs = leafEnv7286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7286 rootObs == leafEnv7286) = true)

theorem terminalChecked7286 : H12PackedTerminal.terminalCheckFast leafEnv7286 active7286 tree7286 = true := by decide +kernel

def env7287 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,103630,262144,62640,32768,2097152,41089,20481,98473,8328,118898,360619,2216050,2118844,2185,99467,40968,61517,168,34359738368,98850]

theorem envBound7287 : H12AffineFastState.Bounded env7287 := by
  intro p hp
  have h : env7287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7253_7287 : H12AffineEnvironment.transform 7 253 env7253 = env7287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7253 == env7287) = true)

theorem identity7287 : scanCanonicalize (H12AffineFastState.compose env7287 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 387202) := by decide +kernel

theorem selectedBound7287 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7288 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,103630,262144,62640,32768,387202,41089,20481,98473,8328,118898,360619,276720,375870,2185,99467,40968,61517,168,34359738368,98850]

theorem envBound7288 : H12AffineFastState.Bounded env7288 := by
  intro p hp
  have h : env7288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7287_7288 : H12AffineEnvironment.transform 20 387202 env7287 = env7288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 387202 env7287 == env7288) = true)

theorem identity7288 : scanCanonicalize (H12AffineFastState.compose env7288 (packedSelected [0,2,4,6,7,9,13,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound7288 : packedSelected [0,2,4,6,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env7289 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,170,37988,262144,62640,32768,321576,41089,20481,32771,8328,53464,294913,276720,310420,2185,33825,40968,61517,168,34359738368,33416]

theorem envBound7289 : H12AffineFastState.Bounded env7289 := by
  intro p hp
  have h : env7289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7288_7289 : H12AffineEnvironment.transform 15 170 env7288 = env7289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env7288 == env7289) = true)

theorem identity7289 : scanCanonicalize (H12AffineFastState.compose env7289 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound7289 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7290 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,170,13509,262144,21521,8353,280713,32,20481,8354,8328,28793,270496,276720,269365,2185,9344,169,20716,168,34359738368,8745]

theorem envBound7290 : H12AffineFastState.Bounded env7290 := by
  intro p hp
  have h : env7290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7289_7290 : H12AffineEnvironment.transform 14 8353 env7289 = env7290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env7289 == env7290) = true)

theorem identity7290 : scanCanonicalize (H12AffineFastState.compose env7290 (packedSelected [0,4,6,7,9,13] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound7290 : packedSelected [0,4,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env7291 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,170,13509,23588,21521,8353,5293,32,20481,8354,8328,28793,31876,25812,16401,2185,9344,169,20716,168,34359738368,8745]

theorem envBound7291 : H12AffineFastState.Bounded env7291 := by
  intro p hp
  have h : env7291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7290_7291 : H12AffineEnvironment.transform 17 23588 env7290 = env7291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env7290 == env7291) = true)

theorem identity7291 : scanCanonicalize (H12AffineFastState.compose env7291 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound7291 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7292 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,16384,136,170,5356,23588,21521,136,5293,32,20481,139,161,20560,23725,17661,16401,2185,1193,169,20716,168,34359738368,512]

theorem envBound7292 : H12AffineFastState.Bounded env7292 := by
  intro p hp
  have h : env7292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7291_7292 : H12AffineEnvironment.transform 12 41 env7291 = env7292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env7291 == env7292) = true)

theorem identity7292 : scanCanonicalize (H12AffineFastState.compose env7292 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4793) := by decide +kernel

theorem selectedBound7292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7293 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,4793,136,170,5356,3741,1704,136,5293,32,696,139,161,745,3604,5700,4776,2185,1193,169,597,168,34359738368,512]

theorem envBound7293 : H12AffineFastState.Bounded env7293 := by
  intro p hp
  have h : env7293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7292_7293 : H12AffineEnvironment.transform 13 4793 env7292 = env7293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4793 env7292 == env7293) = true)

theorem identity7293 : scanCanonicalize (H12AffineFastState.compose env7293 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound7293 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7294 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,4704,81,115,5173,3652,1649,81,5236,32,609,82,120,560,3604,5700,4721,2128,1136,112,597,113,34359738368,512]

theorem envBound7294 : H12AffineFastState.Bounded env7294 := by
  intro p hp
  have h : env7294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7293_7294 : H12AffineEnvironment.transform 6 89 env7293 = env7294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env7293 == env7294) = true)

theorem identity7294 : scanCanonicalize (H12AffineFastState.compose env7294 (packedSelected [0,7,11] rootPS)) = affineNative (2^(34+1) ^^^ 4128) := by decide +kernel

theorem selectedBound7294 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env7295 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,4704,81,115,5173,3652,1649,81,5236,32,609,82,120,560,3604,5700,4721,2128,1136,112,597,113,4128,512]

theorem envBound7295 : H12AffineFastState.Bounded env7295 := by
  intro p hp
  have h : env7295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7294_7295 : H12AffineEnvironment.transform 34 4128 env7294 = env7295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4128 env7294 == env7295) = true)

theorem identity7295 : scanCanonicalize (H12AffineFastState.compose env7295 (packedSelected [2,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3684) := by decide +kernel

theorem selectedBound7295 : packedSelected [2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7296 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,3684,41,3076,81,115,2641,3652,1649,81,2576,32,609,82,120,560,3604,2080,3093,2128,1136,112,597,113,3652,512]

theorem envBound7296 : H12AffineFastState.Bounded env7296 := by
  intro p hp
  have h : env7296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7295_7296 : H12AffineEnvironment.transform 11 3684 env7295 = env7296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3684 env7295 == env7296) = true)

theorem identity7296 : scanCanonicalize (H12AffineFastState.compose env7296 (packedSelected [2,5,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 580) := by decide +kernel

theorem selectedBound7296 : packedSelected [2,5,8,15] rootPS < 2^1333 := by decide +kernel

def env7297 : List Nat := [2,4,8,16,32,64,89,36,512,580,2048,2080,41,2624,81,115,2641,2048,53,81,2576,32,609,82,120,560,2128,2080,2641,2128,564,112,597,113,2048,512]

theorem envBound7297 : H12AffineFastState.Bounded env7297 := by
  intro p hp
  have h : env7297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7296_7297 : H12AffineEnvironment.transform 9 580 env7296 = env7297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env7296 == env7297) = true)

theorem identity7297 : scanCanonicalize (H12AffineFastState.compose env7297 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound7297 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env7298 : List Nat := [2,4,8,16,32,64,89,36,512,580,43,11,41,619,81,115,634,43,53,81,571,32,609,82,120,560,123,11,634,123,564,112,597,113,43,512]

theorem envBound7298 : H12AffineFastState.Bounded env7298 := by
  intro p hp
  have h : env7298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7297_7298 : H12AffineEnvironment.transform 10 43 env7297 = env7298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env7297 == env7298) = true)

theorem identity7298 : scanCanonicalize (H12AffineFastState.compose env7298 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7298 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7299 : List Nat := [2,4,8,16,32,64,89,36,10,78,43,11,41,97,81,115,112,43,53,81,49,32,107,82,120,58,123,11,112,123,62,112,95,113,43,10]

theorem envBound7299 : H12AffineFastState.Bounded env7299 := by
  intro p hp
  have h : env7299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7298_7299 : H12AffineEnvironment.transform 8 10 env7298 = env7299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7298 == env7299) = true)

theorem identity7299 : scanCanonicalize (H12AffineFastState.compose env7299 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7299 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env7300 : List Nat := [2,4,8,16,32,59,34,36,10,53,43,11,41,26,42,8,11,43,53,42,49,32,16,41,3,58,0,11,11,0,62,11,36,10,43,10]

theorem envBound7300 : H12AffineFastState.Bounded env7300 := by
  intro p hp
  have h : env7300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7299_7300 : H12AffineEnvironment.transform 5 59 env7299 = env7300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7299 == env7300) = true)

theorem identity7300 : scanCanonicalize (H12AffineFastState.compose env7300 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound7300 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env7301 : List Nat := [1,4,8,16,32,56,33,36,9,53,40,8,41,25,41,8,8,40,53,41,49,32,16,41,0,57,0,8,8,0,61,8,36,9,40,9]

theorem envBound7301 : H12AffineFastState.Bounded env7301 := by
  intro p hp
  have h : env7301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7300_7301 : H12AffineEnvironment.transform 0 1 env7300 = env7301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env7300 == env7301) = true)

theorem identity7301 : scanCanonicalize (H12AffineFastState.compose env7301 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound7301 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7302 : List Nat := [1,4,8,16,16,8,17,20,9,5,24,8,25,25,25,8,8,24,5,25,1,16,16,25,0,9,0,8,8,0,13,8,20,9,24,9]

theorem envBound7302 : H12AffineFastState.Bounded env7302 := by
  intro p hp
  have h : env7302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7301_7302 : H12AffineEnvironment.transform 4 16 env7301 = env7302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env7301 == env7302) = true)

theorem identity7302 : scanCanonicalize (H12AffineFastState.compose env7302 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound7302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7303 : List Nat := [1,4,8,8,8,8,9,12,9,5,0,8,1,1,1,8,8,0,5,1,1,8,8,1,0,9,0,8,8,0,13,8,12,9,0,9]

theorem envBound7303 : H12AffineFastState.Bounded env7303 := by
  intro p hp
  have h : env7303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7302_7303 : H12AffineEnvironment.transform 3 8 env7302 = env7303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env7302 == env7303) = true)

theorem identity7303 : scanCanonicalize (H12AffineFastState.compose env7303 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound7303 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7304 : List Nat := [1,4,5,5,5,5,4,1,4,5,0,5,1,1,1,5,5,0,5,1,1,5,5,1,0,4,0,5,5,0,0,5,1,4,0,4]

theorem envBound7304 : H12AffineFastState.Bounded env7304 := by
  intro p hp
  have h : env7304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7303_7304 : H12AffineEnvironment.transform 2 5 env7303 = env7304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env7303 == env7304) = true)

def env7305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62641,32768,2097152,41089,8388608,8507732,8328,118899,360619,10584178,10719346,8411508,99702,40968,61873,8409429,34359738368,98850]

theorem envBound7305 : H12AffineFastState.Bounded env7305 := by
  intro p hp
  have h : env7305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7177_7305 : H12AffineEnvironment.transform 18 62641 env7177 = env7305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62641 env7177 == env7305) = true)

theorem identity7305 : scanCanonicalize (H12AffineFastState.compose env7305 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound7305 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5393,262144,62641,32768,2097152,41089,8388608,8507732,8328,118899,360619,10584178,10585443,8411508,99702,40968,61873,8409429,34359738368,98850]

theorem envBound7306 : H12AffineFastState.Bounded env7306 := by
  intro p hp
  have h : env7306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7305_7306 : H12AffineEnvironment.transform 16 5393 env7305 = env7306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env7305 == env7306) = true)

def env7307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5393,262144,62641,32768,2097152,41089,20480,98644,8328,118899,360619,2216050,2217315,2420,99702,40968,61873,341,34359738368,98850]

theorem envBound7307 : H12AffineFastState.Bounded env7307 := by
  intro p hp
  have h : env7307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7306_7307 : H12AffineEnvironment.transform 22 20480 env7306 = env7307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env7306 == env7307) = true)

def env7308 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62641,32768,2097152,41089,20480,98472,8328,118899,360619,2216050,2217119,2184,99466,40968,61517,169,34359738368,98850]

theorem envBound7308 : H12AffineFastState.Bounded env7308 := by
  intro p hp
  have h : env7308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7307_7308 : H12AffineEnvironment.transform 7 252 env7307 = env7308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7307 == env7308) = true)

theorem identity7308 : scanCanonicalize (H12AffineFastState.compose env7308 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 367702) := by decide +kernel

theorem selectedBound7308 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7309 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62641,32768,367702,41089,20480,98472,8328,118899,360619,281636,280777,2184,99466,40968,61517,169,34359738368,98850]

theorem envBound7309 : H12AffineFastState.Bounded env7309 := by
  intro p hp
  have h : env7309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7308_7309 : H12AffineEnvironment.transform 20 367702 env7308 = env7309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 367702 env7308 == env7309) = true)

theorem identity7309 : scanCanonicalize (H12AffineFastState.compose env7309 (packedSelected [11,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound7309 : packedSelected [11,17,18] rootPS < 2^1333 := by decide +kernel

def env7310 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,5357,262144,21520,8353,343287,32,20480,73737,8328,94418,335882,281636,280777,2184,74795,169,20716,169,34359738368,74371]

theorem envBound7310 : H12AffineFastState.Bounded env7310 := by
  intro p hp
  have h : env7310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7309_7310 : H12AffineEnvironment.transform 14 8353 env7309 = env7310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env7309 == env7310) = true)

theorem identity7310 : scanCanonicalize (H12AffineFastState.compose env7310 (packedSelected [2,13,14] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7310 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7311 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,5357,262144,21520,8353,343287,32,20480,73737,8328,94418,335882,281636,280777,2184,74795,169,20716,169,280712,74371]

theorem envBound7311 : H12AffineFastState.Bounded env7311 := by
  intro p hp
  have h : env7311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7310_7311 : H12AffineEnvironment.transform 34 280712 env7310 = env7311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7310 == env7311) = true)

theorem identity7311 : scanCanonicalize (H12AffineFastState.compose env7311 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound7311 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7312 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,65536,5357,262144,2743,8353,343287,32,3751,73737,8328,77429,335882,266883,267886,2184,74795,169,3659,169,267823,74371]

theorem envBound7312 : H12AffineFastState.Bounded env7312 := by
  intro p hp
  have h : env7312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7311_7312 : H12AffineEnvironment.transform 13 7847 env7311 = env7312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env7311 == env7312) = true)

def env7313 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,5357,262144,2743,8353,275975,32,3751,11001,8328,9349,273146,266883,267886,2184,11995,169,3659,169,267823,10355]

theorem envBound7313 : H12AffineFastState.Bounded env7313 := by
  intro p hp
  have h : env7313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7312_7313 : H12AffineEnvironment.transform 15 2800 env7312 = env7313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7312 == env7313) = true)

theorem identity7313 : scanCanonicalize (H12AffineFastState.compose env7313 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound7313 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7314 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,5357,4112,2743,8353,9751,32,3751,11001,8328,9349,15082,659,1662,2184,11995,169,3659,169,1599,10355]

theorem envBound7314 : H12AffineFastState.Bounded env7314 := by
  intro p hp
  have h : env7314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7313_7314 : H12AffineEnvironment.transform 17 4112 env7313 = env7314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env7313 == env7314) = true)

theorem identity7314 : scanCanonicalize (H12AffineFastState.compose env7314 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound7314 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7315 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,7847,1,2800,5357,4112,2743,1,1719,32,3751,2649,40,1061,6730,659,1662,2184,3707,169,3659,169,1599,2259]

theorem envBound7315 : H12AffineFastState.Bounded env7315 := by
  intro p hp
  have h : env7315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7314_7315 : H12AffineEnvironment.transform 12 160 env7314 = env7315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7314 == env7315) = true)

theorem identity7315 : scanCanonicalize (H12AffineFastState.compose env7315 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7315 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env7316 : List Nat := [2,4,8,16,32,64,128,252,512,68,2048,4096,160,6883,1,2800,4265,4112,2743,1,755,32,2787,2649,40,97,6730,659,570,2184,2623,169,2575,169,635,2259]

theorem envBound7316 : H12AffineFastState.Bounded env7316 := by
  intro p hp
  have h : env7316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7315_7316 : H12AffineEnvironment.transform 9 68 env7315 = env7316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7315 == env7316) = true)

theorem identity7316 : scanCanonicalize (H12AffineFastState.compose env7316 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 723) := by decide +kernel

theorem selectedBound7316 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env7317 : List Nat := [2,4,8,16,32,64,128,252,512,68,723,4096,160,4144,1,35,4265,4112,100,1,755,32,48,138,40,97,4249,659,570,603,236,169,220,169,635,512]

theorem envBound7317 : H12AffineFastState.Bounded env7317 := by
  intro p hp
  have h : env7317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7316_7317 : H12AffineEnvironment.transform 10 723 env7316 = env7317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 723 env7316 == env7317) = true)

theorem identity7317 : scanCanonicalize (H12AffineFastState.compose env7317 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound7317 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env7318 : List Nat := [2,4,8,16,32,36,128,152,512,32,695,4096,160,4144,1,35,4265,4112,0,1,663,32,48,138,40,5,4249,659,570,575,136,169,184,169,543,512]

theorem envBound7318 : H12AffineFastState.Bounded env7318 := by
  intro p hp
  have h : env7318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7317_7318 : H12AffineEnvironment.transform 5 36 env7317 = env7318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env7317 == env7318) = true)

def env7319 : List Nat := [2,4,8,16,32,36,128,152,512,32,695,152,160,168,1,35,49,136,0,1,663,32,48,138,40,5,1,659,570,575,136,169,184,169,543,512]

theorem envBound7319 : H12AffineFastState.Bounded env7319 := by
  intro p hp
  have h : env7319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7318_7319 : H12AffineEnvironment.transform 11 152 env7318 = env7319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env7318 == env7319) = true)

theorem identity7319 : scanCanonicalize (H12AffineFastState.compose env7319 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound7319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7320 : List Nat := [2,4,8,16,25,29,128,152,512,25,654,152,153,145,1,26,8,136,0,1,663,25,9,138,17,5,1,659,515,518,136,144,129,144,543,512]

theorem envBound7320 : H12AffineFastState.Bounded env7320 := by
  intro p hp
  have h : env7320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7319_7320 : H12AffineEnvironment.transform 4 25 env7319 = env7320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env7319 == env7320) = true)

def env7321 : List Nat := [2,4,8,16,25,29,8,16,512,25,518,16,17,25,1,26,8,0,0,1,543,25,9,2,17,5,1,539,515,518,0,24,9,24,543,512]

theorem envBound7321 : H12AffineFastState.Bounded env7321 := by
  intro p hp
  have h : env7321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7320_7321 : H12AffineEnvironment.transform 6 8 env7320 = env7321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7320 == env7321) = true)

theorem identity7321 : scanCanonicalize (H12AffineFastState.compose env7321 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound7321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7322 : List Nat := [2,4,8,16,25,29,8,16,6,25,0,16,17,25,1,26,8,0,0,1,25,25,9,2,17,5,1,29,5,0,0,24,9,24,25,6]

theorem envBound7322 : H12AffineFastState.Bounded env7322 := by
  intro p hp
  have h : env7322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7321_7322 : H12AffineEnvironment.transform 8 6 env7321 = env7322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env7321 == env7322) = true)

def leafEnv7322 : List Nat := [2,4,8,16,25,29,8,16,6,25,0,16,17,25,1,26,8,0,0,1,25,25,9,2,24,17,1,5,1,29,5,0,0,24,9,24,28,26,25,6,1,24,0]

def active7322 : List Nat := [0,1,2,3]

def tree7322 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7322 : H12WitnessSearch.Good tree7322 := H12GlobalWitnessIndex.good

theorem leafIdentity7322 : H12AffineFastState.composeSystem env7322 rootObs = leafEnv7322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7322 rootObs == leafEnv7322) = true)

theorem terminalChecked7322 : H12PackedTerminal.terminalCheckFast leafEnv7322 active7322 tree7322 = true := by decide +kernel

def env7323 : List Nat := [2,4,8,16,25,29,9,17,512,25,519,17,16,24,1,26,8,1,0,1,542,25,9,3,17,5,1,538,515,518,1,25,8,25,543,512]

theorem envBound7323 : H12AffineFastState.Bounded env7323 := by
  intro p hp
  have h : env7323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7320_7323 : H12AffineEnvironment.transform 6 9 env7320 = env7323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7320 == env7323) = true)

def leafEnv7323 : List Nat := [2,4,8,16,25,29,9,17,512,25,519,17,16,24,1,26,8,1,0,1,542,25,9,3,25,17,1,5,1,538,515,518,1,25,8,25,28,27,543,512,1,24,0]

def active7323 : List Nat := [0,1,2,3,8]

def tree7323 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7323 : H12WitnessSearch.Good tree7323 := H12GlobalWitnessIndex.good

theorem leafIdentity7323 : H12AffineFastState.composeSystem env7323 rootObs = leafEnv7323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7323 rootObs == leafEnv7323) = true)

theorem terminalChecked7323 : H12PackedTerminal.terminalCheckFast leafEnv7323 active7323 tree7323 = true := by decide +kernel

def env7324 : List Nat := [2,4,8,16,32,36,128,152,512,32,695,153,160,169,1,35,48,137,0,1,663,32,48,138,40,5,0,659,570,575,136,169,184,169,543,512]

theorem envBound7324 : H12AffineFastState.Bounded env7324 := by
  intro p hp
  have h : env7324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7318_7324 : H12AffineEnvironment.transform 11 153 env7318 = env7324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env7318 == env7324) = true)

theorem identity7324 : scanCanonicalize (H12AffineFastState.compose env7324 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound7324 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7325 : List Nat := [2,4,8,16,32,36,128,152,142,32,57,153,160,169,1,35,48,137,0,1,25,32,48,138,40,5,0,29,180,177,136,169,184,169,145,142]

theorem envBound7325 : H12AffineFastState.Bounded env7325 := by
  intro p hp
  have h : env7325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7324_7325 : H12AffineEnvironment.transform 8 142 env7324 = env7325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env7324 == env7325) = true)

def env7326 : List Nat := [2,4,8,16,32,36,48,40,62,32,57,41,16,25,1,35,48,57,0,1,25,32,48,58,40,5,0,29,4,1,56,25,8,25,33,62]

theorem envBound7326 : H12AffineFastState.Bounded env7326 := by
  intro p hp
  have h : env7326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7325_7326 : H12AffineEnvironment.transform 6 48 env7325 = env7326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 48 env7325 == env7326) = true)

def env7327 : List Nat := [2,4,8,16,32,36,49,41,63,32,57,40,17,24,1,35,48,56,0,1,25,32,48,59,40,5,0,29,5,0,57,24,9,24,32,63]

theorem envBound7327 : H12AffineFastState.Bounded env7327 := by
  intro p hp
  have h : env7327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7325_7327 : H12AffineEnvironment.transform 6 49 env7325 = env7327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 49 env7325 == env7327) = true)

theorem identity7327 : scanCanonicalize (H12AffineFastState.compose env7327 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound7327 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7328 : List Nat := [2,4,8,16,25,29,8,16,6,25,0,17,17,24,1,26,9,1,0,1,25,25,9,2,17,5,0,29,5,0,0,24,9,24,25,6]

theorem envBound7328 : H12AffineFastState.Bounded env7328 := by
  intro p hp
  have h : env7328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7327_7328 : H12AffineEnvironment.transform 4 25 env7327 = env7328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env7327 == env7328) = true)

def leafEnv7328 : List Nat := [2,4,8,16,25,29,8,16,6,25,0,17,17,24,1,26,9,1,0,1,25,25,9,2,24,17,1,5,0,29,5,0,0,24,9,24,28,26,25,6,1,25,0]

def active7328 : List Nat := [0,1,2,3]

def tree7328 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7328 : H12WitnessSearch.Good tree7328 := H12GlobalWitnessIndex.good

theorem leafIdentity7328 : H12AffineFastState.composeSystem env7328 rootObs = leafEnv7328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7328 rootObs == leafEnv7328) = true)

theorem terminalChecked7328 : H12PackedTerminal.terminalCheckFast leafEnv7328 active7328 tree7328 = true := by decide +kernel

def env7329 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,5357,262144,2743,8353,275974,32,3751,11000,8328,9348,273147,266883,267886,2184,11994,169,3659,169,267823,10354]

theorem envBound7329 : H12AffineFastState.Bounded env7329 := by
  intro p hp
  have h : env7329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7312_7329 : H12AffineEnvironment.transform 15 2801 env7312 = env7329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7312 == env7329) = true)

theorem identity7329 : scanCanonicalize (H12AffineFastState.compose env7329 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 4843) := by decide +kernel

theorem selectedBound7329 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7330 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,4843,7847,4682,2801,5357,262144,2743,4682,263405,32,3751,6163,4707,5743,268304,266883,267886,2184,7217,169,3659,169,267823,6809]

theorem envBound7330 : H12AffineFastState.Bounded env7330 := by
  intro p hp
  have h : env7330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7329_7330 : H12AffineEnvironment.transform 12 4843 env7329 = env7330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4843 env7329 == env7330) = true)

theorem identity7330 : scanCanonicalize (H12AffineFastState.compose env7330 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 722) := by decide +kernel

theorem selectedBound7330 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7331 : List Nat := [2,4,8,16,32,64,128,252,512,1024,722,4096,4843,5237,4682,35,5357,262144,101,4682,263405,32,1141,4801,4707,5743,266946,266883,267886,602,5859,169,1177,169,267823,4171]

theorem envBound7331 : H12AffineFastState.Bounded env7331 := by
  intro p hp
  have h : env7331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7330_7331 : H12AffineEnvironment.transform 10 722 env7330 = env7331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 722 env7330 == env7331) = true)

theorem identity7331 : scanCanonicalize (H12AffineFastState.compose env7331 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7331 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env7332 : List Nat := [2,4,8,16,32,64,128,252,512,69,722,4096,4843,4144,4682,35,4264,262144,101,4682,262312,32,48,4801,4707,4650,266946,266883,266795,602,4774,169,220,169,266858,4171]

theorem envBound7332 : H12AffineFastState.Bounded env7332 := by
  intro p hp
  have h : env7332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7331_7332 : H12AffineEnvironment.transform 9 69 env7331 = env7332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7331 == env7332) = true)

theorem identity7332 : scanCanonicalize (H12AffineFastState.compose env7332 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound7332 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7333 : List Nat := [2,4,8,16,32,64,128,252,512,69,722,587,160,635,1,35,739,262144,101,1,262312,32,48,138,40,97,262281,262344,262240,602,237,169,220,169,262177,512]

theorem envBound7333 : H12AffineFastState.Bounded env7333 := by
  intro p hp
  have h : env7333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7332_7333 : H12AffineEnvironment.transform 11 587 env7332 = env7333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env7332 == env7333) = true)

theorem identity7333 : scanCanonicalize (H12AffineFastState.compose env7333 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 742) := by decide +kernel

theorem selectedBound7333 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7334 : List Nat := [2,4,8,16,32,64,128,252,512,69,722,587,160,635,1,35,739,742,101,1,590,32,48,138,40,97,623,558,646,602,237,169,220,169,711,512]

theorem envBound7334 : H12AffineFastState.Bounded env7334 := by
  intro p hp
  have h : env7334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7333_7334 : H12AffineEnvironment.transform 17 742 env7333 = env7334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 742 env7333 == env7334) = true)

def env7335 : List Nat := [2,4,8,16,32,64,60,64,512,69,622,587,28,635,1,35,607,602,101,1,590,32,48,54,40,97,623,558,570,602,81,21,96,21,635,512]

theorem envBound7335 : H12AffineFastState.Bounded env7335 := by
  intro p hp
  have h : env7335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7334_7335 : H12AffineEnvironment.transform 6 60 env7334 = env7335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 60 env7334 == env7335) = true)

theorem identity7335 : scanCanonicalize (H12AffineFastState.compose env7335 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7336 : List Nat := [2,4,8,16,12,64,16,64,512,69,578,587,28,599,1,15,607,602,73,1,590,12,28,26,4,77,579,514,534,602,81,21,76,21,599,512]

theorem envBound7336 : H12AffineFastState.Bounded env7336 := by
  intro p hp
  have h : env7336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7335_7336 : H12AffineEnvironment.transform 4 12 env7335 = env7336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7335 == env7336) = true)

theorem identity7336 : scanCanonicalize (H12AffineFastState.compose env7336 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 67) := by decide +kernel

theorem selectedBound7336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7337 : List Nat := [2,4,8,16,12,64,16,64,67,69,1,8,28,20,1,15,28,25,73,1,13,12,28,26,4,77,0,65,85,25,81,21,76,21,20,67]

theorem envBound7337 : H12AffineFastState.Bounded env7337 := by
  intro p hp
  have h : env7337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7336_7337 : H12AffineEnvironment.transform 8 67 env7336 = env7337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 67 env7336 == env7337) = true)

def leafEnv7337 : List Nat := [2,4,8,16,12,64,16,64,67,69,1,8,28,20,1,15,28,25,73,1,13,12,28,26,92,4,1,77,0,65,85,25,81,21,76,21,9,23,20,67,1,12,0]

def active7337 : List Nat := [0,1,2,3,5]

def tree7337 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7337 : H12WitnessSearch.Good tree7337 := H12GlobalWitnessIndex.good

theorem leafIdentity7337 : H12AffineFastState.composeSystem env7337 rootObs = leafEnv7337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7337 rootObs == leafEnv7337) = true)

theorem terminalChecked7337 : H12PackedTerminal.terminalCheckFast leafEnv7337 active7337 tree7337 = true := by decide +kernel

def env7338 : List Nat := [2,4,8,16,32,64,61,65,512,69,623,587,29,635,1,35,606,603,101,1,590,32,48,55,40,97,623,558,571,602,80,20,97,20,634,512]

theorem envBound7338 : H12AffineFastState.Bounded env7338 := by
  intro p hp
  have h : env7338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7334_7338 : H12AffineEnvironment.transform 6 61 env7334 = env7338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 61 env7334 == env7338) = true)

theorem identity7338 : scanCanonicalize (H12AffineFastState.compose env7338 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 118) := by decide +kernel

theorem selectedBound7338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7339 : List Nat := [2,4,8,16,32,64,61,65,118,69,25,61,29,13,1,35,40,45,101,1,56,32,48,55,40,97,25,88,77,44,80,20,97,20,12,118]

theorem envBound7339 : H12AffineFastState.Bounded env7339 := by
  intro p hp
  have h : env7339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7338_7339 : H12AffineEnvironment.transform 8 118 env7338 = env7339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 118 env7338 == env7339) = true)

theorem identity7339 : scanCanonicalize (H12AffineFastState.compose env7339 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7340 : List Nat := [2,4,8,16,13,64,16,65,91,69,25,16,29,13,1,14,5,0,72,1,21,13,29,26,5,76,25,88,77,1,80,20,76,20,12,91]

theorem envBound7340 : H12AffineFastState.Bounded env7340 := by
  intro p hp
  have h : env7340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7339_7340 : H12AffineEnvironment.transform 4 13 env7339 = env7340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7339 == env7340) = true)

def leafEnv7340 : List Nat := [2,4,8,16,13,64,16,65,91,69,25,16,29,13,1,14,5,0,72,1,21,13,29,26,92,5,1,76,25,88,77,1,80,20,76,20,8,22,12,91,1,21,0]

def active7340 : List Nat := [0,1,2,3,5]

def tree7340 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7340 : H12WitnessSearch.Good tree7340 := H12GlobalWitnessIndex.good

theorem leafIdentity7340 : H12AffineFastState.composeSystem env7340 rootObs = leafEnv7340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7340 rootObs == leafEnv7340) = true)

theorem terminalChecked7340 : H12PackedTerminal.terminalCheckFast leafEnv7340 active7340 tree7340 = true := by decide +kernel

def env7341 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,5356,262144,62641,32768,2097152,41089,20480,98473,8328,118899,360619,2216050,2217118,2185,99467,40968,61516,168,34359738368,98850]

theorem envBound7341 : H12AffineFastState.Bounded env7341 := by
  intro p hp
  have h : env7341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7307_7341 : H12AffineEnvironment.transform 7 253 env7307 = env7341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7307 == env7341) = true)

theorem identity7341 : scanCanonicalize (H12AffineFastState.compose env7341 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 288928) := by decide +kernel

theorem selectedBound7341 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7342 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,5356,262144,62641,32768,288928,41089,20480,98473,8328,118899,360619,374994,375870,2185,99467,40968,61516,168,34359738368,98850]

theorem envBound7342 : H12AffineFastState.Bounded env7342 := by
  intro p hp
  have h : env7342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7341_7342 : H12AffineEnvironment.transform 20 288928 env7341 = env7342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 288928 env7341 == env7342) = true)

theorem identity7342 : scanCanonicalize (H12AffineFastState.compose env7342 (packedSelected [0,2,4,6,7,9,13,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound7342 : packedSelected [0,2,4,6,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env7343 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,170,5356,262144,62641,32768,288928,41089,20480,32771,8328,53465,294913,309368,310420,2185,33825,40968,61516,168,34359738368,33416]

theorem envBound7343 : H12AffineFastState.Bounded env7343 := by
  intro p hp
  have h : env7343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7342_7343 : H12AffineEnvironment.transform 15 170 env7342 = env7343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env7342 == env7343) = true)

theorem identity7343 : scanCanonicalize (H12AffineFastState.compose env7343 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound7343 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7344 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,170,5356,262144,21520,8353,288928,32,20480,8354,8328,28792,270496,268505,269365,2185,9344,169,20717,168,34359738368,8745]

theorem envBound7344 : H12AffineFastState.Bounded env7344 := by
  intro p hp
  have h : env7344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7343_7344 : H12AffineEnvironment.transform 14 8353 env7343 = env7344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env7343 == env7344) = true)

theorem identity7344 : scanCanonicalize (H12AffineFastState.compose env7344 (packedSelected [0,4,6,7,9,13] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound7344 : packedSelected [0,4,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env7345 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,170,5356,23588,21520,8353,13444,32,20480,8354,8328,28792,31876,17661,16401,2185,9344,169,20717,168,34359738368,8745]

theorem envBound7345 : H12AffineFastState.Bounded env7345 := by
  intro p hp
  have h : env7345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7344_7345 : H12AffineEnvironment.transform 17 23588 env7344 = env7345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env7344 == env7345) = true)

theorem identity7345 : scanCanonicalize (H12AffineFastState.compose env7345 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound7345 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7346 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,16384,136,170,5356,23588,21520,136,5293,32,20480,139,161,20561,23725,17661,16401,2185,1193,169,20717,168,34359738368,512]

theorem envBound7346 : H12AffineFastState.Bounded env7346 := by
  intro p hp
  have h : env7346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7345_7346 : H12AffineEnvironment.transform 12 41 env7345 = env7346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env7345 == env7346) = true)

theorem identity7346 : scanCanonicalize (H12AffineFastState.compose env7346 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4793) := by decide +kernel

theorem selectedBound7346 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7347 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,4793,136,170,5356,3741,1705,136,5293,32,697,139,161,744,3604,5700,4776,2185,1193,169,596,168,34359738368,512]

theorem envBound7347 : H12AffineFastState.Bounded env7347 := by
  intro p hp
  have h : env7347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7346_7347 : H12AffineEnvironment.transform 13 4793 env7346 = env7347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4793 env7346 == env7347) = true)

theorem identity7347 : scanCanonicalize (H12AffineFastState.compose env7347 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound7347 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7348 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,4704,81,115,5173,3652,1648,81,5236,32,608,82,120,561,3604,5700,4721,2128,1136,112,596,113,34359738368,512]

theorem envBound7348 : H12AffineFastState.Bounded env7348 := by
  intro p hp
  have h : env7348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7347_7348 : H12AffineEnvironment.transform 6 89 env7347 = env7348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env7347 == env7348) = true)

theorem identity7348 : scanCanonicalize (H12AffineFastState.compose env7348 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7348 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env7349 : List Nat := [2,4,8,16,32,64,89,36,512,4,2048,4096,41,4704,81,115,4145,2624,628,81,4208,32,608,82,120,561,2576,4672,4721,2128,116,112,596,113,34359738368,512]

theorem envBound7349 : H12AffineFastState.Bounded env7349 := by
  intro p hp
  have h : env7349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7348_7349 : H12AffineEnvironment.transform 9 4 env7348 = env7349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7348 == env7349) = true)

theorem identity7349 : scanCanonicalize (H12AffineFastState.compose env7349 (packedSelected [2,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound7349 : packedSelected [2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7350 : List Nat := [2,4,8,16,32,64,89,36,512,4,2048,2608,41,2128,81,115,2561,2624,628,81,2624,32,608,82,120,561,2576,2160,2113,2128,116,112,596,113,34359738368,512]

theorem envBound7350 : H12AffineFastState.Bounded env7350 := by
  intro p hp
  have h : env7350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7349_7350 : H12AffineEnvironment.transform 11 2608 env7349 = env7350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env7349 == env7350) = true)

theorem identity7350 : scanCanonicalize (H12AffineFastState.compose env7350 (packedSelected [2,5,8,15] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound7350 : packedSelected [2,5,8,15] rootPS < 2^1333 := by decide +kernel

def env7351 : List Nat := [2,4,8,16,32,64,89,36,64,4,2048,2160,41,2128,81,115,2113,2048,52,81,2048,32,32,82,120,113,2128,2160,2113,2128,116,112,20,113,34359738368,64]

theorem envBound7351 : H12AffineFastState.Bounded env7351 := by
  intro p hp
  have h : env7351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7350_7351 : H12AffineEnvironment.transform 8 64 env7350 = env7351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env7350 == env7351) = true)

theorem identity7351 : scanCanonicalize (H12AffineFastState.compose env7351 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound7351 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env7352 : List Nat := [2,4,8,16,32,64,89,36,64,4,27,107,41,75,81,115,90,27,52,81,27,32,32,82,120,113,75,107,90,75,116,112,20,113,34359738368,64]

theorem envBound7352 : H12AffineFastState.Bounded env7352 := by
  intro p hp
  have h : env7352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7351_7352 : H12AffineEnvironment.transform 10 27 env7351 = env7352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env7351 == env7352) = true)

theorem identity7352 : scanCanonicalize (H12AffineFastState.compose env7352 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound7352 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7353 : List Nat := [2,4,8,16,10,64,89,14,64,4,27,65,3,75,81,89,90,27,30,81,27,10,10,82,82,91,75,65,90,75,94,90,20,91,34359738368,64]

theorem envBound7353 : H12AffineFastState.Bounded env7353 := by
  intro p hp
  have h : env7353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7352_7353 : H12AffineEnvironment.transform 4 10 env7352 = env7353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env7352 == env7353) = true)

theorem identity7353 : scanCanonicalize (H12AffineFastState.compose env7353 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound7353 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env7354 : List Nat := [2,4,8,11,10,64,66,14,64,4,0,65,3,75,74,66,65,0,5,74,0,10,10,73,73,64,75,65,65,75,69,65,15,64,34359738368,64]

theorem envBound7354 : H12AffineFastState.Bounded env7354 := by
  intro p hp
  have h : env7354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7353_7354 : H12AffineEnvironment.transform 3 11 env7353 = env7354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env7353 == env7354) = true)

theorem identity7354 : scanCanonicalize (H12AffineFastState.compose env7354 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound7354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7355 : List Nat := [2,4,8,11,10,8,10,14,8,4,0,9,3,3,2,10,9,0,5,2,0,10,10,1,1,8,3,9,9,3,13,9,15,8,34359738368,8]

theorem envBound7355 : H12AffineFastState.Bounded env7355 := by
  intro p hp
  have h : env7355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7354_7355 : H12AffineEnvironment.transform 5 8 env7354 = env7355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env7354 == env7355) = true)

def env7356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5393,262144,62641,32768,2097152,41089,20481,98645,8328,118899,360619,2216051,2217314,2421,99702,40968,61873,340,34359738368,98850]

theorem envBound7356 : H12AffineFastState.Bounded env7356 := by
  intro p hp
  have h : env7356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7306_7356 : H12AffineEnvironment.transform 22 20481 env7306 = env7356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env7306 == env7356) = true)

theorem identity7356 : scanCanonicalize (H12AffineFastState.compose env7356 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7356 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env7357 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62641,32768,2097152,41089,20481,98473,8328,118899,360619,2216051,2217118,2185,99466,40968,61517,168,34359738368,98850]

theorem envBound7357 : H12AffineFastState.Bounded env7357 := by
  intro p hp
  have h : env7357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7356_7357 : H12AffineEnvironment.transform 7 252 env7356 = env7357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7356 == env7357) = true)

theorem identity7357 : scanCanonicalize (H12AffineFastState.compose env7357 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 343286) := by decide +kernel

theorem selectedBound7357 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7358 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62641,32768,343286,41089,20481,98473,8328,118899,360619,322693,321640,2185,99466,40968,61517,168,34359738368,98850]

theorem envBound7358 : H12AffineFastState.Bounded env7358 := by
  intro p hp
  have h : env7358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7357_7358 : H12AffineEnvironment.transform 20 343286 env7357 = env7358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 343286 env7357 == env7358) = true)

theorem identity7358 : scanCanonicalize (H12AffineFastState.compose env7358 (packedSelected [11,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound7358 : packedSelected [11,17,18] rootPS < 2^1333 := by decide +kernel

def env7359 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,5357,262144,21521,8352,343286,33,20481,73737,8328,94419,335883,281637,280776,2185,74794,168,20717,168,34359738368,74370]

theorem envBound7359 : H12AffineFastState.Bounded env7359 := by
  intro p hp
  have h : env7359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7358_7359 : H12AffineEnvironment.transform 14 8352 env7358 = env7359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env7358 == env7359) = true)

theorem identity7359 : scanCanonicalize (H12AffineFastState.compose env7359 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7359 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env7360 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,5357,262144,21521,8352,343286,33,20481,73737,8328,94419,335883,281637,280776,2185,74794,168,20717,168,280712,74370]

theorem envBound7360 : H12AffineFastState.Bounded env7360 := by
  intro p hp
  have h : env7360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7359_7360 : H12AffineEnvironment.transform 34 280712 env7359 = env7360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7359 == env7360) = true)

theorem identity7360 : scanCanonicalize (H12AffineFastState.compose env7360 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound7360 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7361 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,65536,5357,262144,2743,8352,343286,33,3751,73737,8328,77429,335883,266883,267886,2185,74794,168,3659,168,267822,74370]

theorem envBound7361 : H12AffineFastState.Bounded env7361 := by
  intro p hp
  have h : env7361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7360_7361 : H12AffineEnvironment.transform 13 7846 env7360 = env7361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env7360 == env7361) = true)

def env7362 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,5357,262144,2743,8352,275974,33,3751,11001,8328,9349,273147,266883,267886,2185,11994,168,3659,168,267822,10354]

theorem envBound7362 : H12AffineFastState.Bounded env7362 := by
  intro p hp
  have h : env7362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7361_7362 : H12AffineEnvironment.transform 15 2800 env7361 = env7362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7361 == env7362) = true)

def env7363 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,5357,3276,2743,8352,15050,33,3751,11001,8328,9349,9783,7759,6818,2185,11994,168,3659,168,6882,10354]

theorem envBound7363 : H12AffineFastState.Bounded env7363 := by
  intro p hp
  have h : env7363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7362_7363 : H12AffineEnvironment.transform 17 3276 env7362 = env7363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3276 env7362 == env7363) = true)

theorem identity7363 : scanCanonicalize (H12AffineFastState.compose env7363 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1252) := by decide +kernel

theorem selectedBound7363 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7364 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1252,7846,1092,2800,5357,3276,2743,1092,7726,33,3751,3613,1132,97,723,7759,6818,2185,2622,168,3659,168,6882,3222]

theorem envBound7364 : H12AffineFastState.Bounded env7364 := by
  intro p hp
  have h : env7364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7363_7364 : H12AffineEnvironment.transform 12 1252 env7363 = env7364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1252 env7363 == env7364) = true)

def env7365 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1108,1252,2802,1092,2800,185,3276,2743,1092,2682,33,3751,3613,1132,97,723,2587,3830,2185,2622,168,3659,168,3766,3222]

theorem envBound7365 : H12AffineFastState.Bounded env7365 := by
  intro p hp
  have h : env7365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7364_7365 : H12AffineEnvironment.transform 11 1108 env7364 = env7365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env7364 == env7365) = true)

def env7366 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1108,1132,2682,1092,2680,49,3140,2623,1092,2682,33,3631,3613,1132,97,603,2587,3710,2049,2622,32,3659,32,3646,3102]

theorem envBound7366 : H12AffineFastState.Bounded env7366 := by
  intro p hp
  have h : env7366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7365_7366 : H12AffineEnvironment.transform 6 8 env7365 = env7366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7365 == env7366) = true)

theorem identity7366 : scanCanonicalize (H12AffineFastState.compose env7366 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7366 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7367 : List Nat := [2,4,8,16,32,64,8,116,512,68,2048,16,40,2682,0,2680,49,2048,2623,0,2682,33,2667,2649,40,97,603,2587,2618,2049,2622,32,2575,32,2682,2138]

theorem envBound7367 : H12AffineFastState.Bounded env7367 := by
  intro p hp
  have h : env7367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7366_7367 : H12AffineEnvironment.transform 9 68 env7366 = env7367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7366 == env7367) = true)

theorem identity7367 : scanCanonicalize (H12AffineFastState.compose env7367 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound7367 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env7368 : List Nat := [2,4,8,16,32,64,8,116,512,68,603,16,40,33,0,35,49,603,100,0,33,33,48,2,40,97,603,64,97,602,101,32,84,32,33,513]

theorem envBound7368 : H12AffineFastState.Bounded env7368 := by
  intro p hp
  have h : env7368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7367_7368 : H12AffineEnvironment.transform 10 603 env7367 = env7368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env7367 == env7368) = true)

theorem identity7368 : scanCanonicalize (H12AffineFastState.compose env7368 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound7368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7369 : List Nat := [2,4,8,16,32,3,8,55,512,7,536,16,40,33,0,35,49,536,39,0,33,33,48,2,40,34,536,3,34,537,38,32,23,32,33,513]

theorem envBound7369 : H12AffineFastState.Bounded env7369 := by
  intro p hp
  have h : env7369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7368_7369 : H12AffineEnvironment.transform 5 3 env7368 = env7369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env7368 == env7369) = true)

theorem identity7369 : scanCanonicalize (H12AffineFastState.compose env7369 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound7369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7370 : List Nat := [2,4,8,2,32,3,8,37,512,7,522,2,40,33,0,35,35,522,39,0,33,33,34,2,40,34,522,3,34,523,38,32,5,32,33,513]

theorem envBound7370 : H12AffineFastState.Bounded env7370 := by
  intro p hp
  have h : env7370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7369_7370 : H12AffineEnvironment.transform 3 2 env7369 = env7370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env7369 == env7370) = true)

theorem identity7370 : scanCanonicalize (H12AffineFastState.compose env7370 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7370 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7371 : List Nat := [2,4,8,2,32,3,8,37,11,7,1,2,40,33,0,35,35,1,39,0,33,33,34,2,40,34,1,3,34,0,38,32,5,32,33,10]

theorem envBound7371 : H12AffineFastState.Bounded env7371 := by
  intro p hp
  have h : env7371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7370_7371 : H12AffineEnvironment.transform 8 11 env7370 = env7371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7370 == env7371) = true)

def env7372 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1108,1133,2683,1092,2681,48,3141,2622,1092,2682,33,3630,3613,1132,97,602,2587,3711,2048,2622,33,3659,33,3647,3103]

theorem envBound7372 : H12AffineFastState.Bounded env7372 := by
  intro p hp
  have h : env7372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7365_7372 : H12AffineEnvironment.transform 6 9 env7365 = env7372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7365 == env7372) = true)

def env7373 : List Nat := [2,4,8,16,32,64,9,117,512,112,2048,36,29,2683,52,2681,48,2101,2622,52,2682,33,2654,2669,28,97,602,2587,2575,2048,2622,33,2619,33,2639,2159]

theorem envBound7373 : H12AffineFastState.Bounded env7373 := by
  intro p hp
  have h : env7373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7372_7373 : H12AffineEnvironment.transform 9 112 env7372 = env7373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 112 env7372 == env7373) = true)

theorem identity7373 : scanCanonicalize (H12AffineFastState.compose env7373 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound7373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7374 : List Nat := [2,4,8,16,32,64,9,117,512,112,81,36,29,554,52,552,48,100,623,52,555,33,527,572,28,97,602,586,606,81,623,33,618,33,542,62]

theorem envBound7374 : H12AffineFastState.Bounded env7374 := by
  intro p hp
  have h : env7374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7373_7374 : H12AffineEnvironment.transform 10 81 env7373 = env7374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env7373 == env7374) = true)

def env7375 : List Nat := [2,4,8,16,32,16,9,37,512,32,1,36,29,554,52,552,48,52,575,52,555,33,527,572,28,49,522,538,526,1,575,33,570,33,542,62]

theorem envBound7375 : H12AffineFastState.Bounded env7375 := by
  intro p hp
  have h : env7375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7374_7375 : H12AffineEnvironment.transform 5 16 env7374 = env7375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env7374 == env7375) = true)

theorem identity7375 : scanCanonicalize (H12AffineFastState.compose env7375 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7375 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7376 : List Nat := [2,4,8,16,32,16,9,37,10,32,1,36,29,32,52,34,48,52,53,52,33,33,5,54,28,49,0,16,4,1,53,33,48,33,20,62]

theorem envBound7376 : H12AffineFastState.Bounded env7376 := by
  intro p hp
  have h : env7376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7375_7376 : H12AffineEnvironment.transform 8 10 env7375 = env7376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7375 == env7376) = true)

theorem identity7376 : scanCanonicalize (H12AffineFastState.compose env7376 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound7376 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7377 : List Nat := [2,4,8,16,21,16,9,16,10,21,1,17,29,21,1,23,5,1,0,1,20,20,5,3,28,4,0,16,4,1,0,20,5,20,20,11]

theorem envBound7377 : H12AffineFastState.Bounded env7377 := by
  intro p hp
  have h : env7377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7376_7377 : H12AffineEnvironment.transform 4 21 env7376 = env7377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env7376 == env7377) = true)

theorem identity7377 : scanCanonicalize (H12AffineFastState.compose env7377 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound7377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7378 : List Nat := [2,3,8,16,18,16,9,16,10,18,1,17,26,18,1,16,2,1,0,1,19,19,2,3,27,3,0,16,3,1,0,19,2,19,19,11]

theorem envBound7378 : H12AffineFastState.Bounded env7378 := by
  intro p hp
  have h : env7378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7377_7378 : H12AffineEnvironment.transform 1 3 env7377 = env7378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env7377 == env7378) = true)

def env7379 : List Nat := [2,4,8,16,32,17,9,36,512,33,0,36,29,554,52,552,48,53,574,52,555,33,527,572,28,48,523,539,527,0,574,33,571,33,542,62]

theorem envBound7379 : H12AffineFastState.Bounded env7379 := by
  intro p hp
  have h : env7379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7374_7379 : H12AffineEnvironment.transform 5 17 env7374 = env7379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env7374 == env7379) = true)

theorem identity7379 : scanCanonicalize (H12AffineFastState.compose env7379 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7379 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7380 : List Nat := [2,4,8,16,32,17,9,36,11,33,0,36,29,33,52,35,48,53,53,52,32,33,4,55,28,48,0,16,4,0,53,33,48,33,21,62]

theorem envBound7380 : H12AffineFastState.Bounded env7380 := by
  intro p hp
  have h : env7380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7379_7380 : H12AffineEnvironment.transform 8 11 env7379 = env7380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7379 == env7380) = true)

theorem identity7380 : scanCanonicalize (H12AffineFastState.compose env7380 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound7380 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7381 : List Nat := [2,4,8,16,21,17,9,17,11,20,0,17,29,20,1,22,5,0,0,1,21,20,4,2,28,5,0,16,4,0,0,20,5,20,21,11]

theorem envBound7381 : H12AffineFastState.Bounded env7381 := by
  intro p hp
  have h : env7381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7380_7381 : H12AffineEnvironment.transform 4 21 env7380 = env7381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env7380 == env7381) = true)

theorem identity7381 : scanCanonicalize (H12AffineFastState.compose env7381 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound7381 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7382 : List Nat := [2,4,4,16,21,17,5,17,7,20,0,17,17,20,1,22,5,0,0,1,21,20,4,2,16,5,0,16,4,0,0,20,5,20,21,7]

theorem envBound7382 : H12AffineFastState.Bounded env7382 := by
  intro p hp
  have h : env7382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7381_7382 : H12AffineEnvironment.transform 2 4 env7381 = env7382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env7381 == env7382) = true)

def leafEnv7382 : List Nat := [2,4,4,16,21,17,5,17,7,20,0,17,17,20,1,22,5,0,0,1,21,20,4,2,20,16,1,5,0,16,4,0,0,20,5,20,16,22,21,7,1,20,0]

def active7382 : List Nat := [0,1,3]

def tree7382 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7382 : H12WitnessSearch.Good tree7382 := H12GlobalWitnessIndex.good

theorem leafIdentity7382 : H12AffineFastState.composeSystem env7382 rootObs = leafEnv7382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7382 rootObs == leafEnv7382) = true)

theorem terminalChecked7382 : H12PackedTerminal.terminalCheckFast leafEnv7382 active7382 tree7382 = true := by decide +kernel

def env7383 : List Nat := [2,4,8,16,32,64,9,117,512,113,2048,37,28,2683,53,2681,48,2100,2622,53,2682,33,2655,2668,29,97,602,2587,2574,2048,2622,33,2618,33,2638,2158]

theorem envBound7383 : H12AffineFastState.Bounded env7383 := by
  intro p hp
  have h : env7383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7372_7383 : H12AffineEnvironment.transform 9 113 env7372 = env7383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 113 env7372 == env7383) = true)

theorem identity7383 : scanCanonicalize (H12AffineFastState.compose env7383 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 62) := by decide +kernel

theorem selectedBound7383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7384 : List Nat := [2,4,8,16,32,64,9,117,62,113,2048,37,28,2117,53,2119,48,2100,2048,53,2116,33,2145,2130,29,97,100,2085,2096,2048,2048,33,2052,33,2160,2158]

theorem envBound7384 : H12AffineFastState.Bounded env7384 := by
  intro p hp
  have h : env7384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7383_7384 : H12AffineEnvironment.transform 8 62 env7383 = env7384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 62 env7383 == env7384) = true)

def env7385 : List Nat := [2,4,8,16,32,64,9,117,62,113,0,37,28,69,53,71,48,52,0,53,68,33,97,82,29,97,100,37,48,0,0,33,4,33,112,110]

theorem envBound7385 : H12AffineFastState.Bounded env7385 := by
  intro p hp
  have h : env7385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7384_7385 : H12AffineEnvironment.transform 10 0 env7384 = env7385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env7384 == env7385) = true)

theorem identity7385 : scanCanonicalize (H12AffineFastState.compose env7385 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound7385 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7386 : List Nat := [2,4,8,16,32,36,9,17,62,21,0,37,28,33,53,35,48,52,0,53,32,33,5,54,29,5,0,37,48,0,0,33,4,33,20,10]

theorem envBound7386 : H12AffineFastState.Bounded env7386 := by
  intro p hp
  have h : env7386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7385_7386 : H12AffineEnvironment.transform 5 36 env7385 = env7386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env7385 == env7386) = true)

theorem identity7386 : scanCanonicalize (H12AffineFastState.compose env7386 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound7386 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env7387 : List Nat := [2,4,8,16,20,16,9,17,10,21,0,17,28,21,1,23,4,0,0,1,20,21,5,2,29,5,0,17,4,0,0,21,4,21,20,10]

theorem envBound7387 : H12AffineFastState.Bounded env7387 := by
  intro p hp
  have h : env7387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7386_7387 : H12AffineEnvironment.transform 4 20 env7386 = env7387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env7386 == env7387) = true)

theorem identity7387 : scanCanonicalize (H12AffineFastState.compose env7387 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound7387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7388 : List Nat := [2,4,5,16,20,16,4,17,7,21,0,17,17,21,1,23,4,0,0,1,20,21,5,2,16,5,0,17,4,0,0,21,4,21,20,7]

theorem envBound7388 : H12AffineFastState.Bounded env7388 := by
  intro p hp
  have h : env7388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7387_7388 : H12AffineEnvironment.transform 2 5 env7387 = env7388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env7387 == env7388) = true)

def leafEnv7388 : List Nat := [2,4,5,16,20,16,4,17,7,21,0,17,17,21,1,23,4,0,0,1,20,21,5,2,21,16,1,5,0,17,4,0,0,21,4,21,17,23,20,7,1,21,0]

def active7388 : List Nat := [0,1,3]

def tree7388 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7388 : H12WitnessSearch.Good tree7388 := H12GlobalWitnessIndex.good

theorem leafIdentity7388 : H12AffineFastState.composeSystem env7388 rootObs = leafEnv7388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7388 rootObs == leafEnv7388) = true)

theorem terminalChecked7388 : H12PackedTerminal.terminalCheckFast leafEnv7388 active7388 tree7388 = true := by decide +kernel

def env7389 : List Nat := [2,4,8,16,32,64,9,117,62,113,1,37,28,68,53,70,48,53,1,53,69,33,96,83,29,97,100,36,49,1,1,33,5,33,113,111]

theorem envBound7389 : H12AffineFastState.Bounded env7389 := by
  intro p hp
  have h : env7389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7384_7389 : H12AffineEnvironment.transform 10 1 env7384 = env7389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env7384 == env7389) = true)

theorem identity7389 : scanCanonicalize (H12AffineFastState.compose env7389 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound7389 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7390 : List Nat := [2,4,8,16,32,36,9,17,62,21,1,37,28,32,53,34,48,53,1,53,33,33,4,55,29,5,0,36,49,1,1,33,5,33,21,11]

theorem envBound7390 : H12AffineFastState.Bounded env7390 := by
  intro p hp
  have h : env7390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7389_7390 : H12AffineEnvironment.transform 5 36 env7389 = env7390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env7389 == env7390) = true)

theorem identity7390 : scanCanonicalize (H12AffineFastState.compose env7390 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound7390 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7391 : List Nat := [2,4,8,16,20,16,9,17,10,21,1,17,28,20,1,22,4,1,1,1,21,21,4,3,29,5,0,16,5,1,1,21,5,21,21,11]

theorem envBound7391 : H12AffineFastState.Bounded env7391 := by
  intro p hp
  have h : env7391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7390_7391 : H12AffineEnvironment.transform 4 20 env7390 = env7391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env7390 == env7391) = true)

theorem identity7391 : scanCanonicalize (H12AffineFastState.compose env7391 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7391 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7392 : List Nat := [2,2,8,16,18,16,9,17,10,19,1,17,26,18,1,16,2,1,1,1,19,19,2,3,27,3,0,16,3,1,1,19,3,19,19,11]

theorem envBound7392 : H12AffineFastState.Bounded env7392 := by
  intro p hp
  have h : env7392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7391_7392 : H12AffineEnvironment.transform 1 2 env7391 = env7392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7391 == env7392) = true)

def env7393 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1109,1252,2803,1092,2800,184,3276,2743,1092,2683,33,3751,3613,1132,97,723,2586,3831,2185,2622,168,3659,168,3767,3222]

theorem envBound7393 : H12AffineFastState.Bounded env7393 := by
  intro p hp
  have h : env7393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7364_7393 : H12AffineEnvironment.transform 11 1109 env7364 = env7393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env7364 == env7393) = true)

def env7394 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1109,1132,2683,1092,2680,48,3140,2623,1092,2683,33,3631,3613,1132,97,603,2586,3711,2049,2622,32,3659,32,3647,3102]

theorem envBound7394 : H12AffineFastState.Bounded env7394 := by
  intro p hp
  have h : env7394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7393_7394 : H12AffineEnvironment.transform 6 8 env7393 = env7394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7393 == env7394) = true)

theorem identity7394 : scanCanonicalize (H12AffineFastState.compose env7394 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound7394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7395 : List Nat := [2,4,8,16,32,64,8,116,512,1024,602,1109,1132,33,1092,34,48,1566,101,1092,33,33,1141,1095,1132,97,603,64,1061,603,100,32,1041,32,1125,1604]

theorem envBound7395 : H12AffineFastState.Bounded env7395 := by
  intro p hp
  have h : env7395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7394_7395 : H12AffineEnvironment.transform 10 602 env7394 = env7395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env7394 == env7395) = true)

def env7396 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1109,1133,2682,1092,2681,49,3141,2622,1092,2683,33,3630,3613,1132,97,602,2586,3710,2048,2622,33,3659,33,3646,3103]

theorem envBound7396 : H12AffineFastState.Bounded env7396 := by
  intro p hp
  have h : env7396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7393_7396 : H12AffineEnvironment.transform 6 9 env7393 = env7396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7393 == env7396) = true)

theorem identity7396 : scanCanonicalize (H12AffineFastState.compose env7396 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound7396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7397 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1567,1109,1133,1125,1092,1126,49,602,1057,1092,1124,33,49,2,1132,97,602,1029,97,1567,1057,33,84,33,33,512]

theorem envBound7397 : H12AffineFastState.Bounded env7397 := by
  intro p hp
  have h : env7397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7396_7397 : H12AffineEnvironment.transform 10 1567 env7396 = env7397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env7396 == env7397) = true)

theorem identity7397 : scanCanonicalize (H12AffineFastState.compose env7397 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 634) := by decide +kernel

theorem selectedBound7397 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7398 : List Nat := [2,4,8,16,32,64,9,117,512,634,101,559,535,543,574,540,49,602,603,574,542,33,49,2,534,97,602,639,97,101,603,33,84,33,33,512]

theorem envBound7398 : H12AffineFastState.Bounded env7398 := by
  intro p hp
  have h : env7398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7397_7398 : H12AffineEnvironment.transform 9 634 env7397 = env7398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 634 env7397 == env7398) = true)

theorem identity7398 : scanCanonicalize (H12AffineFastState.compose env7398 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound7398 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7399 : List Nat := [2,4,8,16,32,64,9,117,63,69,101,16,40,32,1,35,49,101,100,1,33,33,49,2,41,97,101,64,97,101,100,33,84,33,33,63]

theorem envBound7399 : H12AffineFastState.Bounded env7399 := by
  intro p hp
  have h : env7399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7398_7399 : H12AffineEnvironment.transform 8 63 env7398 = env7399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env7398 == env7399) = true)

theorem identity7399 : scanCanonicalize (H12AffineFastState.compose env7399 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound7399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7400 : List Nat := [2,4,8,16,24,64,9,77,7,69,93,16,16,24,1,27,9,93,92,1,25,25,9,2,17,89,93,64,89,93,92,25,84,25,25,7]

theorem envBound7400 : H12AffineFastState.Bounded env7400 := by
  intro p hp
  have h : env7400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7399_7400 : H12AffineEnvironment.transform 4 24 env7399 = env7400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env7399 == env7400) = true)

theorem identity7400 : scanCanonicalize (H12AffineFastState.compose env7400 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound7400 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7401 : List Nat := [2,4,8,16,24,28,9,17,7,25,1,16,16,24,1,27,9,1,0,1,25,25,9,2,17,5,1,28,5,1,0,25,8,25,25,7]

theorem envBound7401 : H12AffineFastState.Bounded env7401 := by
  intro p hp
  have h : env7401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7400_7401 : H12AffineEnvironment.transform 5 28 env7400 = env7401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env7400 == env7401) = true)

def leafEnv7401 : List Nat := [2,4,8,16,24,28,9,17,7,25,1,16,16,24,1,27,9,1,0,1,25,25,9,2,25,17,1,5,1,28,5,1,0,25,8,25,29,27,25,7,1,24,0]

def active7401 : List Nat := [0,1,2,3]

def tree7401 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7401 : H12WitnessSearch.Good tree7401 := H12GlobalWitnessIndex.good

theorem leafIdentity7401 : H12AffineFastState.composeSystem env7401 rootObs = leafEnv7401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7401 rootObs == leafEnv7401) = true)

theorem terminalChecked7401 : H12PackedTerminal.terminalCheckFast leafEnv7401 active7401 tree7401 = true := by decide +kernel

def env7402 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,5357,3277,2743,8352,15051,33,3751,11001,8328,9349,9782,7758,6819,2185,11994,168,3659,168,6883,10354]

theorem envBound7402 : H12AffineFastState.Bounded env7402 := by
  intro p hp
  have h : env7402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7362_7402 : H12AffineEnvironment.transform 17 3277 env7362 = env7402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3277 env7362 == env7402) = true)

theorem identity7402 : scanCanonicalize (H12AffineFastState.compose env7402 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1687) := by decide +kernel

theorem selectedBound7402 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7403 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,4096,8192,4145,8352,1127,5357,602,1056,8352,13404,33,48,9326,8328,9349,9782,4313,5172,1566,8269,168,220,168,5236,9957]

theorem envBound7403 : H12AffineFastState.Bounded env7403 := by
  intro p hp
  have h : env7403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7402_7403 : H12AffineEnvironment.transform 10 1687 env7402 = env7403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1687 env7402 == env7403) = true)

def env7404 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,152,8192,169,8352,1127,1141,602,1056,8352,9412,33,48,9326,8328,9349,9782,65,1196,1566,8269,168,220,168,1260,9957]

theorem envBound7404 : H12AffineFastState.Bounded env7404 := by
  intro p hp
  have h : env7404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7403_7404 : H12AffineEnvironment.transform 11 152 env7403 = env7404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env7403 == env7404) = true)

def env7405 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,152,160,169,0,1127,1141,602,1056,0,1124,33,48,1230,40,1061,1686,65,1196,1566,237,168,220,168,1260,1605]

theorem envBound7405 : H12AffineFastState.Bounded env7405 := by
  intro p hp
  have h : env7405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7404_7405 : H12AffineEnvironment.transform 12 160 env7404 = env7405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7404 == env7405) = true)

def env7406 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,152,161,169,1,1127,1141,602,1056,1,1125,33,48,1231,41,1060,1687,65,1196,1566,236,168,220,168,1260,1604]

theorem envBound7406 : H12AffineFastState.Bounded env7406 := by
  intro p hp
  have h : env7406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7404_7406 : H12AffineEnvironment.transform 12 161 env7404 = env7406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7404 == env7406) = true)

theorem identity7406 : scanCanonicalize (H12AffineFastState.compose env7406 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound7406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7407 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1567,16,41,33,1,1127,1141,602,1056,1,1125,33,48,1095,41,1060,1567,65,1060,1566,100,32,84,32,1124,1604]

theorem envBound7407 : H12AffineFastState.Bounded env7407 := by
  intro p hp
  have h : env7407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7406_7407 : H12AffineEnvironment.transform 6 8 env7406 = env7407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7406 == env7407) = true)

theorem identity7407 : scanCanonicalize (H12AffineFastState.compose env7407 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound7407 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7408 : List Nat := [2,4,8,16,32,64,8,116,512,542,1,16,41,33,1,633,619,602,574,1,635,33,48,601,41,570,1,65,570,0,100,32,84,32,634,90]

theorem envBound7408 : H12AffineFastState.Bounded env7408 := by
  intro p hp
  have h : env7408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7407_7408 : H12AffineEnvironment.transform 9 542 env7407 = env7408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env7407 == env7408) = true)

theorem identity7408 : scanCanonicalize (H12AffineFastState.compose env7408 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound7408 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7409 : List Nat := [2,4,8,16,32,64,8,116,90,68,1,16,41,33,1,35,49,0,100,1,33,33,48,3,41,96,1,65,96,0,100,32,84,32,32,90]

theorem envBound7409 : H12AffineFastState.Bounded env7409 := by
  intro p hp
  have h : env7409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7408_7409 : H12AffineEnvironment.transform 8 90 env7408 = env7409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env7408 == env7409) = true)

theorem identity7409 : scanCanonicalize (H12AffineFastState.compose env7409 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound7409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7410 : List Nat := [2,4,8,9,32,64,8,109,67,68,1,9,41,33,1,35,40,0,100,1,33,33,41,3,41,96,1,65,96,0,100,32,77,32,32,67]

theorem envBound7410 : H12AffineFastState.Bounded env7410 := by
  intro p hp
  have h : env7410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7409_7410 : H12AffineEnvironment.transform 3 9 env7409 = env7410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env7409 == env7410) = true)

theorem identity7410 : scanCanonicalize (H12AffineFastState.compose env7410 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7411 : List Nat := [2,4,8,9,13,64,8,64,67,68,1,9,4,12,1,14,5,0,73,1,12,12,4,3,4,77,1,65,77,0,73,13,77,13,13,67]

theorem envBound7411 : H12AffineFastState.Bounded env7411 := by
  intro p hp
  have h : env7411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7410_7411 : H12AffineEnvironment.transform 4 13 env7410 = env7411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7410 == env7411) = true)

def leafEnv7411 : List Nat := [2,4,8,9,13,64,8,64,67,68,1,9,4,12,1,14,5,0,73,1,12,12,4,3,68,4,1,77,1,65,77,0,73,13,77,13,9,15,13,67,1,13,0]

def active7411 : List Nat := [0,1,2,5]

def tree7411 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7411 : H12WitnessSearch.Good tree7411 := H12GlobalWitnessIndex.good

theorem leafIdentity7411 : H12AffineFastState.composeSystem env7411 rootObs = leafEnv7411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7411 rootObs == leafEnv7411) = true)

theorem terminalChecked7411 : H12PackedTerminal.terminalCheckFast leafEnv7411 active7411 tree7411 = true := by decide +kernel

def env7412 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,153,8192,168,8352,1127,1140,602,1056,8352,9413,33,48,9326,8328,9349,9782,64,1197,1566,8269,168,220,168,1261,9957]

theorem envBound7412 : H12AffineFastState.Bounded env7412 := by
  intro p hp
  have h : env7412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7403_7412 : H12AffineEnvironment.transform 11 153 env7403 = env7412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env7403 == env7412) = true)

def env7413 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,153,160,168,0,1127,1140,602,1056,0,1125,33,48,1230,40,1061,1686,64,1197,1566,237,168,220,168,1261,1605]

theorem envBound7413 : H12AffineFastState.Bounded env7413 := by
  intro p hp
  have h : env7413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7412_7413 : H12AffineEnvironment.transform 12 160 env7412 = env7413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7412 == env7413) = true)

theorem identity7413 : scanCanonicalize (H12AffineFastState.compose env7413 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7414 : List Nat := [2,4,8,16,32,64,128,252,512,68,723,153,160,168,0,35,48,602,100,0,33,33,48,138,40,97,722,64,233,602,237,168,220,168,169,513]

theorem envBound7414 : H12AffineFastState.Bounded env7414 := by
  intro p hp
  have h : env7414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7413_7414 : H12AffineEnvironment.transform 9 68 env7413 = env7414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7413 == env7414) = true)

theorem identity7414 : scanCanonicalize (H12AffineFastState.compose env7414 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 193) := by decide +kernel

theorem selectedBound7414 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7415 : List Nat := [2,4,8,16,32,64,128,252,193,68,18,153,160,168,0,35,48,155,100,0,33,33,48,138,40,97,19,64,233,155,237,168,220,168,169,192]

theorem envBound7415 : H12AffineFastState.Bounded env7415 := by
  intro p hp
  have h : env7415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7414_7415 : H12AffineEnvironment.transform 8 193 env7414 = env7415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 193 env7414 == env7415) = true)

def env7416 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1687,153,161,168,1,1127,1140,602,1056,1,1124,33,48,1231,41,1060,1687,64,1197,1566,236,168,220,168,1261,1604]

theorem envBound7416 : H12AffineFastState.Bounded env7416 := by
  intro p hp
  have h : env7416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7412_7416 : H12AffineEnvironment.transform 12 161 env7412 = env7416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7412 == env7416) = true)

theorem identity7416 : scanCanonicalize (H12AffineFastState.compose env7416 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound7416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7417 : List Nat := [2,4,8,16,32,64,128,252,512,204,603,153,161,168,1,171,184,602,236,1,168,33,48,3,41,232,603,64,97,722,236,168,220,168,33,648]

theorem envBound7417 : H12AffineFastState.Bounded env7417 := by
  intro p hp
  have h : env7417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7416_7417 : H12AffineEnvironment.transform 9 204 env7416 = env7417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env7416 == env7417) = true)

theorem identity7417 : scanCanonicalize (H12AffineFastState.compose env7417 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound7417 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7418 : List Nat := [2,4,8,16,32,64,128,252,91,204,0,153,161,168,1,171,184,1,236,1,168,33,48,3,41,232,0,64,97,137,236,168,220,168,33,211]

theorem envBound7418 : H12AffineFastState.Bounded env7418 := by
  intro p hp
  have h : env7418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7417_7418 : H12AffineEnvironment.transform 8 91 env7417 = env7418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env7417 == env7418) = true)

theorem identity7418 : scanCanonicalize (H12AffineFastState.compose env7418 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound7418 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7419 : List Nat := [2,4,8,16,32,64,8,116,91,68,0,17,41,32,1,35,48,1,100,1,32,33,48,3,41,96,0,64,97,1,100,32,84,32,33,91]

theorem envBound7419 : H12AffineFastState.Bounded env7419 := by
  intro p hp
  have h : env7419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7418_7419 : H12AffineEnvironment.transform 6 8 env7418 = env7419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7418 == env7419) = true)

theorem identity7419 : scanCanonicalize (H12AffineFastState.compose env7419 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound7419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7420 : List Nat := [2,4,8,8,32,64,8,108,67,68,0,9,41,32,1,35,40,1,100,1,32,33,40,3,41,96,0,64,97,1,100,32,76,32,33,67]

theorem envBound7420 : H12AffineFastState.Bounded env7420 := by
  intro p hp
  have h : env7420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7419_7420 : H12AffineEnvironment.transform 3 8 env7419 = env7420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env7419 == env7420) = true)

theorem identity7420 : scanCanonicalize (H12AffineFastState.compose env7420 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7421 : List Nat := [2,4,8,8,12,64,8,64,67,68,0,9,5,12,1,15,4,1,72,1,12,13,4,3,5,76,0,64,77,1,72,12,76,12,13,67]

theorem envBound7421 : H12AffineFastState.Bounded env7421 := by
  intro p hp
  have h : env7421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7420_7421 : H12AffineEnvironment.transform 4 12 env7420 = env7421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7420 == env7421) = true)

def leafEnv7421 : List Nat := [2,4,8,8,12,64,8,64,67,68,0,9,5,12,1,15,4,1,72,1,12,13,4,3,68,5,1,76,0,64,77,1,72,12,76,12,8,14,13,67,1,13,0]

def active7421 : List Nat := [0,1,2,5]

def tree7421 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7421 : H12WitnessSearch.Good tree7421 := H12GlobalWitnessIndex.good

theorem leafIdentity7421 : H12AffineFastState.composeSystem env7421 rootObs = leafEnv7421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7421 rootObs == leafEnv7421) = true)

theorem terminalChecked7421 : H12PackedTerminal.terminalCheckFast leafEnv7421 active7421 tree7421 = true := by decide +kernel

def env7422 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,5357,262144,2743,8352,275975,33,3751,11000,8328,9348,273146,266883,267886,2185,11995,168,3659,168,267822,10355]

theorem envBound7422 : H12AffineFastState.Bounded env7422 := by
  intro p hp
  have h : env7422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7361_7422 : H12AffineEnvironment.transform 15 2801 env7361 = env7422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7361 == env7422) = true)

theorem identity7422 : scanCanonicalize (H12AffineFastState.compose env7422 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 8955) := by decide +kernel

theorem selectedBound7422 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7423 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,5357,8955,2743,8352,5372,33,3751,11000,8328,9348,2049,12408,13461,2185,11995,168,3659,168,13525,10355]

theorem envBound7423 : H12AffineFastState.Bounded env7423 := by
  intro p hp
  have h : env7423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7422_7423 : H12AffineEnvironment.transform 17 8955 env7422 = env7423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8955 env7422 == env7423) = true)

theorem identity7423 : scanCanonicalize (H12AffineFastState.compose env7423 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 2675) := by decide +kernel

theorem selectedBound7423 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7424 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2675,7846,2771,2801,5357,2184,2743,2771,5372,33,3751,139,2811,3831,2049,6667,7910,2185,1192,168,3659,168,7846,512]

theorem envBound7424 : H12AffineFastState.Bounded env7424 := by
  intro p hp
  have h : env7424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7423_7424 : H12AffineEnvironment.transform 12 2675 env7423 = env7424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2675 env7423 == env7424) = true)

theorem identity7424 : scanCanonicalize (H12AffineFastState.compose env7424 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

end H12CloudChart1