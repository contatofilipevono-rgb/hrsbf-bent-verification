import H12CloudChart1Data038

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env9704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,67108864,134217728,138678441,138678613,151259274,84484168,155451870,525568,151257258,203759843,16778206]

theorem envBound9704 : H12AffineFastState.Bounded env9704 := by
  intro p hp
  have h : env9704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9491_9704 : H12AffineEnvironment.transform 27 138678441 env9491 = env9704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env9491 == env9704) = true)

theorem identity9704 : scanCanonicalize (H12AffineFastState.compose env9704 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 79859) := by decide +kernel

theorem selectedBound9704 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env9705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,79859,134217728,138678441,138678613,151259274,17307579,155451870,525568,151257258,136582928,16778206]

theorem envBound9705 : H12AffineFastState.Bounded env9705 := by
  intro p hp
  have h : env9705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9704_9705 : H12AffineEnvironment.transform 25 79859 env9704 = env9705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 79859 env9704 == env9705) = true)

def env9706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,16777216,8329,79859,134217728,134500813,134500401,151259274,17307579,151273658,525568,151257258,136582928,16778206]

theorem envBound9706 : H12AffineFastState.Bounded env9706 := by
  intro p hp
  have h : env9706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9705_9706 : H12AffineEnvironment.transform 21 16740 env9705 = env9706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16740 env9705 == env9706) = true)

def env9707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,16777216,8329,79859,278624,4525,4177,16795882,17307579,16777434,525568,16793802,2119536,16778206]

theorem envBound9707 : H12AffineFastState.Bounded env9707 := by
  intro p hp
  have h : env9707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9706_9707 : H12AffineEnvironment.transform 26 278624 env9706 = env9707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278624 env9706 == env9707) = true)

def env9708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,90336,8329,79859,278624,4525,4177,75786,620379,90170,525568,73770,2119536,90942]

theorem envBound9708 : H12AffineFastState.Bounded env9708 := by
  intro p hp
  have h : env9708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9707_9708 : H12AffineEnvironment.transform 23 90336 env9707 = env9708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9707 == env9708) = true)

theorem identity9708 : scanCanonicalize (H12AffineFastState.compose env9708 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9708 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9709 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16536,525329,90336,8329,79375,278624,4177,4177,75786,620199,90170,525564,73770,2119308,90818]

theorem envBound9709 : H12AffineFastState.Bounded env9709 := by
  intro p hp
  have h : env9709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9708_9709 : H12AffineEnvironment.transform 7 252 env9708 = env9709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9708 == env9709) = true)

def env9710 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16480,525329,90136,8305,79375,278624,4177,4177,75786,620127,90170,525316,73770,2119284,90682]

theorem envBound9710 : H12AffineFastState.Bounded env9710 := by
  intro p hp
  have h : env9710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9709_9710 : H12AffineEnvironment.transform 6 120 env9709 = env9710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9709 == env9710) = true)

theorem identity9710 : scanCanonicalize (H12AffineFastState.compose env9710 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619087) := by decide +kernel

theorem selectedBound9710 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9711 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619087,16480,525329,90136,8305,79375,278624,4177,4177,75786,620127,90170,525316,73770,599099,90682]

theorem envBound9711 : H12AffineFastState.Bounded env9711 := by
  intro p hp
  have h : env9711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9710_9711 : H12AffineEnvironment.transform 20 619087 env9710 = env9711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619087 env9710 == env9711) = true)

def env9712 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619039,16432,525329,90136,8225,79375,278576,4097,4097,75786,620047,90170,525316,73770,599099,90682]

theorem envBound9712 : H12AffineFastState.Bounded env9712 := by
  intro p hp
  have h : env9712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9711_9712 : H12AffineEnvironment.transform 5 16 env9711 = env9712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9711 == env9712) = true)

theorem identity9712 : scanCanonicalize (H12AffineFastState.compose env9712 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281648) := by decide +kernel

theorem selectedBound9712 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9713 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,281648,8201,343599,16432,280609,90136,8225,79375,278576,4097,4097,75786,342591,90170,280628,73770,354315,90682]

theorem envBound9713 : H12AffineFastState.Bounded env9713 := by
  intro p hp
  have h : env9713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9712_9713 : H12AffineEnvironment.transform 18 281648 env9712 = env9713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281648 env9712 == env9713) = true)

theorem identity9713 : scanCanonicalize (H12AffineFastState.compose env9713 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound9713 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9714 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,97838,78366,8201,16385,16432,79375,90136,8225,79375,81438,4097,4097,75786,17425,90170,79386,73770,5669,90682]

theorem envBound9714 : H12AffineFastState.Bounded env9714 := by
  intro p hp
  have h : env9714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9713_9714 : H12AffineEnvironment.transform 17 97838 env9713 = env9714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env9713 == env9714) = true)

def env9715 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619038,16433,525329,90136,8224,79375,278577,4096,4096,75786,620046,90170,525316,73770,599099,90682]

theorem envBound9715 : H12AffineFastState.Bounded env9715 := by
  intro p hp
  have h : env9715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9711_9715 : H12AffineEnvironment.transform 5 17 env9711 = env9715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9711 == env9715) = true)

theorem identity9715 : scanCanonicalize (H12AffineFastState.compose env9715 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound9715 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9716 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,97839,524288,8201,619038,16433,525329,90136,8224,79375,81438,4096,4096,75786,620046,90170,525316,73770,599099,90682]

theorem envBound9716 : H12AffineFastState.Bounded env9716 := by
  intro p hp
  have h : env9716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9715_9716 : H12AffineEnvironment.transform 17 97839 env9715 = env9716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env9715 == env9716) = true)

theorem identity9716 : scanCanonicalize (H12AffineFastState.compose env9716 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94734) := by decide +kernel

theorem selectedBound9716 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9717 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,97839,94734,8201,16,16433,95775,90136,8224,79375,81438,4096,4096,75786,1024,90170,95754,73770,22069,90682]

theorem envBound9717 : H12AffineFastState.Bounded env9717 := by
  intro p hp
  have h : env9717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9716_9717 : H12AffineEnvironment.transform 18 94734 env9716 = env9717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94734 env9716 == env9717) = true)

theorem identity9717 : scanCanonicalize (H12AffineFastState.compose env9717 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound9717 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9718 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,24634,4097,7701,4660,8201,16,16433,5669,34,8224,22069,24100,4096,4096,18480,1024,0,5680,16400,22069,512]

theorem envBound9718 : H12AffineFastState.Bounded env9718 := by
  intro p hp
  have h : env9718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9717_9718 : H12AffineEnvironment.transform 15 24634 env9717 = env9718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env9717 == env9718) = true)

theorem identity9718 : scanCanonicalize (H12AffineFastState.compose env9718 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound9718 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9719 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,4096,8192,16384,8201,24634,4097,5150,4660,8201,16,16433,5669,34,8224,22069,21551,4096,4096,16955,1024,0,5680,16400,22069,512]

theorem envBound9719 : H12AffineFastState.Bounded env9719 := by
  intro p hp
  have h : env9719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9718_9719 : H12AffineEnvironment.transform 10 523 env9718 = env9719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env9718 == env9719) = true)

theorem identity9719 : scanCanonicalize (H12AffineFastState.compose env9719 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9719 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9720 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,4096,8192,17,8201,8235,4097,5150,4660,8201,16,32,5669,34,8224,5668,5182,4096,4096,554,1024,0,5680,1,5668,512]

theorem envBound9720 : H12AffineFastState.Bounded env9720 := by
  intro p hp
  have h : env9720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9719_9720 : H12AffineEnvironment.transform 13 17 env9719 = env9720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9719 == env9720) = true)

theorem identity9720 : scanCanonicalize (H12AffineFastState.compose env9720 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound9720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9721 : List Nat := [2,4,8,16,32,17,41,4,512,1024,523,4096,1063,17,1070,1036,4097,5150,4660,1070,16,32,5669,34,1031,5668,5182,4096,4096,554,1024,0,5680,1,5668,512]

theorem envBound9721 : H12AffineFastState.Bounded env9721 := by
  intro p hp
  have h : env9721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9720_9721 : H12AffineEnvironment.transform 12 1063 env9720 = env9721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env9720 == env9721) = true)

theorem identity9721 : scanCanonicalize (H12AffineFastState.compose env9721 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9721 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9722 : List Nat := [2,4,8,16,1,17,8,4,512,1024,523,4096,1030,17,1039,1036,4097,5150,4629,1039,16,1,5636,3,1031,5637,5151,4096,4096,523,1024,0,5649,1,5637,512]

theorem envBound9722 : H12AffineFastState.Bounded env9722 := by
  intro p hp
  have h : env9722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9721_9722 : H12AffineEnvironment.transform 4 1 env9721 = env9722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9721 == env9722) = true)

theorem identity9722 : scanCanonicalize (H12AffineFastState.compose env9722 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound9722 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9723 : List Nat := [2,4,8,16,1,17,8,4,512,1024,523,26,1030,17,1039,1036,27,1028,527,1039,16,1,1566,3,1031,1567,1029,26,26,523,1024,0,1547,1,1567,512]

theorem envBound9723 : H12AffineFastState.Bounded env9723 := by
  intro p hp
  have h : env9723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9722_9723 : H12AffineEnvironment.transform 11 26 env9722 = env9723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env9722 == env9723) = true)

theorem identity9723 : scanCanonicalize (H12AffineFastState.compose env9723 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound9723 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env9724 : List Nat := [2,4,8,16,1,17,8,4,1,1024,10,26,1030,17,1039,1036,27,1028,14,1039,16,1,1055,3,1031,1054,1029,26,26,10,1024,0,1034,1,1054,1]

theorem envBound9724 : H12AffineFastState.Bounded env9724 := by
  intro p hp
  have h : env9724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9723_9724 : H12AffineEnvironment.transform 8 1 env9723 = env9724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env9723 == env9724) = true)

theorem identity9724 : scanCanonicalize (H12AffineFastState.compose env9724 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound9724 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9725 : List Nat := [2,4,8,16,1,17,8,4,1,14,10,26,8,17,1,2,27,10,14,1,16,1,17,3,9,16,11,26,26,10,14,0,4,1,16,1]

theorem envBound9725 : H12AffineFastState.Bounded env9725 := by
  intro p hp
  have h : env9725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9724_9725 : H12AffineEnvironment.transform 9 14 env9724 = env9725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env9724 == env9725) = true)

theorem identity9725 : scanCanonicalize (H12AffineFastState.compose env9725 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9726 : List Nat := [2,4,8,11,1,10,8,4,1,14,10,1,8,10,1,2,0,10,14,1,11,1,10,3,9,11,11,1,1,10,14,0,4,1,11,1]

theorem envBound9726 : H12AffineFastState.Bounded env9726 := by
  intro p hp
  have h : env9726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9725_9726 : H12AffineEnvironment.transform 3 11 env9725 = env9726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9725 == env9726) = true)

def env9727 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16481,525329,90137,8304,79375,278624,4177,4177,75786,620126,90170,525317,73770,2119285,90683]

theorem envBound9727 : H12AffineFastState.Bounded env9727 := by
  intro p hp
  have h : env9727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9709_9727 : H12AffineEnvironment.transform 6 121 env9709 = env9727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9709 == env9727) = true)

theorem identity9727 : scanCanonicalize (H12AffineFastState.compose env9727 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545381) := by decide +kernel

theorem selectedBound9727 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9728 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545381,16481,525329,90137,8304,79375,278624,4177,4177,75786,620126,90170,525317,73770,525328,90683]

theorem envBound9728 : H12AffineFastState.Bounded env9728 := by
  intro p hp
  have h : env9728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9727_9728 : H12AffineEnvironment.transform 20 545381 env9727 = env9728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545381 env9727 == env9728) = true)

def env9729 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545333,16433,525329,90137,8224,79375,278576,4097,4097,75786,620046,90170,525317,73770,525328,90683]

theorem envBound9729 : H12AffineFastState.Bounded env9729 := by
  intro p hp
  have h : env9729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9728_9729 : H12AffineEnvironment.transform 5 16 env9728 = env9729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9728 == env9729) = true)

theorem identity9729 : scanCanonicalize (H12AffineFastState.compose env9729 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338954) := by decide +kernel

theorem selectedBound9729 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9730 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,338954,8201,359999,16433,337947,90137,8224,79375,278576,4097,4097,75786,285188,90170,337935,73770,337946,90683]

theorem envBound9730 : H12AffineFastState.Bounded env9730 := by
  intro p hp
  have h : env9730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9729_9730 : H12AffineEnvironment.transform 18 338954 env9729 = env9730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338954 env9729 == env9730) = true)

theorem identity9730 : scanCanonicalize (H12AffineFastState.compose env9730 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24069) := by decide +kernel

theorem selectedBound9730 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9731 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,24069,94735,8201,73786,16433,95774,90137,8224,79375,7733,4097,4097,75786,1025,90170,95754,73770,95775,90683]

theorem envBound9731 : H12AffineFastState.Bounded env9731 := by
  intro p hp
  have h : env9731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9730_9731 : H12AffineEnvironment.transform 17 24069 env9730 = env9731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24069 env9730 == env9731) = true)

def env9732 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545332,16432,525329,90137,8225,79375,278577,4096,4096,75786,620047,90170,525317,73770,525328,90683]

theorem envBound9732 : H12AffineFastState.Bounded env9732 := by
  intro p hp
  have h : env9732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9728_9732 : H12AffineEnvironment.transform 5 17 env9728 = env9732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9728 == env9732) = true)

theorem identity9732 : scanCanonicalize (H12AffineFastState.compose env9732 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound9732 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9733 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,524288,8201,545332,16432,525329,90137,8225,79375,24101,4096,4096,75786,620047,90170,525317,73770,525328,90683]

theorem envBound9733 : H12AffineFastState.Bounded env9733 := by
  intro p hp
  have h : env9733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9732_9733 : H12AffineEnvironment.transform 17 7700 env9732 = env9733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env9732 == env9733) = true)

theorem identity9733 : scanCanonicalize (H12AffineFastState.compose env9733 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78367) := by decide +kernel

theorem selectedBound9733 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9734 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,78367,8201,90155,16432,79374,90137,8225,79375,24101,4096,4096,75786,17424,90170,79386,73770,79375,90683]

theorem envBound9734 : H12AffineFastState.Bounded env9734 := by
  intro p hp
  have h : env9734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9733_9734 : H12AffineEnvironment.transform 18 78367 env9733 = env9734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78367 env9733 == env9734) = true)

theorem identity9734 : scanCanonicalize (H12AffineFastState.compose env9734 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9734 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env9735 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,17,8201,65536,4097,7700,78367,8201,73786,33,79374,73736,8225,79375,7732,4096,4096,75786,1025,73771,79386,73770,79375,74282]

theorem envBound9735 : H12AffineFastState.Bounded env9735 := by
  intro p hp
  have h : env9735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9734_9735 : H12AffineEnvironment.transform 13 17 env9734 = env9735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9734 == env9735) = true)

theorem identity9735 : scanCanonicalize (H12AffineFastState.compose env9735 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound9735 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9736 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,4096,8192,17,8201,65536,4097,5668,78367,8201,73786,33,79374,73736,8225,79375,5636,4096,4096,73786,1025,73771,79386,73770,79375,74282]

theorem envBound9736 : H12AffineFastState.Bounded env9736 := by
  intro p hp
  have h : env9736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9735_9736 : H12AffineEnvironment.transform 10 48 env9735 = env9736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env9735 == env9736) = true)

theorem identity9736 : scanCanonicalize (H12AffineFastState.compose env9736 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound9736 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9737 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,4096,24,17,17,65536,4097,5668,70151,17,65570,33,71190,65552,57,71191,5636,4096,4096,65570,1025,65587,71170,65586,71191,66098]

theorem envBound9737 : H12AffineFastState.Bounded env9737 := by
  intro p hp
  have h : env9737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9736_9737 : H12AffineEnvironment.transform 12 24 env9736 = env9737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env9736 == env9737) = true)

theorem identity9737 : scanCanonicalize (H12AffineFastState.compose env9737 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 5175) := by decide +kernel

theorem selectedBound9737 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9738 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,4096,24,17,17,5175,4097,5668,1584,17,5141,33,545,5159,57,544,5636,4096,4096,5141,1025,5124,565,5125,544,5637]

theorem envBound9738 : H12AffineFastState.Bounded env9738 := by
  intro p hp
  have h : env9738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9737_9738 : H12AffineEnvironment.transform 15 5175 env9737 = env9738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5175 env9737 == env9738) = true)

theorem identity9738 : scanCanonicalize (H12AffineFastState.compose env9738 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 1599) := by decide +kernel

theorem selectedBound9738 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env9739 : List Nat := [2,4,8,16,32,17,40,5,512,1024,48,1599,24,17,17,520,1598,27,1584,17,554,33,545,536,57,544,59,1599,1599,554,1025,571,565,570,544,58]

theorem envBound9739 : H12AffineFastState.Bounded env9739 := by
  intro p hp
  have h : env9739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9738_9739 : H12AffineEnvironment.transform 11 1599 env9738 = env9739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1599 env9738 == env9739) = true)

theorem identity9739 : scanCanonicalize (H12AffineFastState.compose env9739 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound9739 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9740 : List Nat := [2,4,8,16,32,17,40,5,512,516,48,59,24,17,17,520,58,27,52,17,554,33,545,536,57,544,59,59,59,554,517,571,565,570,544,58]

theorem envBound9740 : H12AffineFastState.Bounded env9740 := by
  intro p hp
  have h : env9740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9739_9740 : H12AffineEnvironment.transform 9 516 env9739 = env9740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env9739 == env9740) = true)

theorem identity9740 : scanCanonicalize (H12AffineFastState.compose env9740 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound9740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9741 : List Nat := [2,4,8,16,32,17,40,5,10,14,48,59,24,17,17,2,58,27,52,17,32,33,43,18,57,42,59,59,59,32,15,49,63,48,42,58]

theorem envBound9741 : H12AffineFastState.Bounded env9741 := by
  intro p hp
  have h : env9741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9740_9741 : H12AffineEnvironment.transform 8 10 env9740 = env9741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env9740 == env9741) = true)

theorem identity9741 : scanCanonicalize (H12AffineFastState.compose env9741 (packedSelected [0,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9741 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env9742 : List Nat := [2,4,8,0,32,1,40,5,10,14,32,43,8,1,1,2,42,11,36,1,32,33,43,2,41,42,43,43,43,32,15,33,47,32,42,42]

theorem envBound9742 : H12AffineFastState.Bounded env9742 := by
  intro p hp
  have h : env9742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9741_9742 : H12AffineEnvironment.transform 3 0 env9741 = env9742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9741 == env9742) = true)

def env9743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,90337,8329,79859,278624,4525,4177,75787,620378,90171,525568,73771,2119536,90943]

theorem envBound9743 : H12AffineFastState.Bounded env9743 := by
  intro p hp
  have h : env9743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9707_9743 : H12AffineEnvironment.transform 23 90337 env9707 = env9743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9707 == env9743) = true)

theorem identity9743 : scanCanonicalize (H12AffineFastState.compose env9743 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9743 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,4605,262144,524288,8693,2097152,16740,525805,34,8329,22320,278624,4525,4177,18632,530329,248,525568,16616,2119536,1020]

theorem envBound9744 : H12AffineFastState.Bounded env9744 := by
  intro p hp
  have h : env9744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9743_9744 : H12AffineEnvironment.transform 15 24771 env9743 = env9744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9743 == env9744) = true)

def env9745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,8403,4605,262144,524288,8693,2097152,372,525805,34,8329,5920,262256,4525,4177,2264,530329,248,525568,248,2103136,1020]

theorem envBound9745 : H12AffineFastState.Bounded env9745 := by
  intro p hp
  have h : env9745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9744_9745 : H12AffineEnvironment.transform 13 16 env9744 = env9745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9744 == env9745) = true)

theorem identity9745 : scanCanonicalize (H12AffineFastState.compose env9745 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9745 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9746 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8403,4097,262144,524288,8201,2097152,136,525329,34,8329,5852,262256,4177,4177,2264,530021,248,525564,248,2102940,512]

theorem envBound9746 : H12AffineFastState.Bounded env9746 := by
  intro p hp
  have h : env9746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9745_9746 : H12AffineEnvironment.transform 7 252 env9745 = env9746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9745 == env9746) = true)

theorem identity9746 : scanCanonicalize (H12AffineFastState.compose env9746 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529036) := by decide +kernel

theorem selectedBound9746 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9747 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8403,4097,262144,524288,8201,529036,136,525329,34,8329,5852,262256,4177,4177,2264,530021,248,525564,248,525328,512]

theorem envBound9747 : H12AffineFastState.Bounded env9747 := by
  intro p hp
  have h : env9747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9746_9747 : H12AffineEnvironment.transform 20 529036 env9746 = env9747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529036 env9746 == env9747) = true)

theorem identity9747 : scanCanonicalize (H12AffineFastState.compose env9747 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4661) := by decide +kernel

theorem selectedBound9747 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9748 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8403,4097,262144,4661,8201,185,136,5668,34,8329,5852,262256,4177,4177,2264,1104,248,5833,248,5669,512]

theorem envBound9748 : H12AffineFastState.Bounded env9748 := by
  intro p hp
  have h : env9748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9747_9748 : H12AffineEnvironment.transform 18 4661 env9747 = env9748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4661 env9747 == env9748) = true)

theorem identity9748 : scanCanonicalize (H12AffineFastState.compose env9748 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 13998) := by decide +kernel

theorem selectedBound9748 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9749 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8403,4097,13998,4661,8201,185,136,5668,34,8329,5852,14046,4177,4177,2264,1104,248,5833,248,5669,512]

theorem envBound9749 : H12AffineFastState.Bounded env9749 := by
  intro p hp
  have h : env9749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9748_9749 : H12AffineEnvironment.transform 17 13998 env9748 = env9749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13998 env9748 == env9749) = true)

theorem identity9749 : scanCanonicalize (H12AffineFastState.compose env9749 (packedSelected [2,13,14] rootPS)) = affineNative (2^(11+1) ^^^ 2786) := by decide +kernel

theorem selectedBound9749 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9750 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2786,8192,16,8201,8403,2787,11340,2263,8201,185,136,3270,34,8329,3134,11324,2739,2739,2264,1104,248,3115,248,3271,512]

theorem envBound9750 : H12AffineFastState.Bounded env9750 := by
  intro p hp
  have h : env9750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9749_9750 : H12AffineEnvironment.transform 11 2786 env9749 = env9750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2786 env9749 == env9750) = true)

theorem identity9750 : scanCanonicalize (H12AffineFastState.compose env9750 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3310) := by decide +kernel

theorem selectedBound9750 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env9751 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2786,3310,16,3303,3133,2787,162,2263,3303,185,136,3270,34,3175,3134,210,2739,2739,2264,1104,248,3115,248,3271,512]

theorem envBound9751 : H12AffineFastState.Bounded env9751 := by
  intro p hp
  have h : env9751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9750_9751 : H12AffineEnvironment.transform 12 3310 env9750 = env9751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3310 env9750 == env9751) = true)

theorem identity9751 : scanCanonicalize (H12AffineFastState.compose env9751 (packedSelected [13,17] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound9751 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9752 : List Nat := [2,4,8,16,32,64,128,252,512,85,2048,2786,2235,16,2226,2152,2787,162,2263,2226,185,136,2195,34,2098,2155,210,2739,2739,2264,5,248,2174,248,2194,512]

theorem envBound9752 : H12AffineFastState.Bounded env9752 := by
  intro p hp
  have h : env9752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9751_9752 : H12AffineEnvironment.transform 9 85 env9751 = env9752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env9751 == env9752) = true)

theorem identity9752 : scanCanonicalize (H12AffineFastState.compose env9752 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 153) := by decide +kernel

theorem selectedBound9752 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9753 : List Nat := [2,4,8,16,32,64,128,252,153,85,2048,2171,2235,16,2226,2152,2170,162,2263,2226,185,136,2195,34,2098,2155,210,2090,2090,2264,5,248,2174,248,2194,153]

theorem envBound9753 : H12AffineFastState.Bounded env9753 := by
  intro p hp
  have h : env9753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9752_9753 : H12AffineEnvironment.transform 8 153 env9752 = env9753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 153 env9752 == env9753) = true)

def env9754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,8402,4605,262144,524288,8693,2097152,373,525805,34,8329,5921,262257,4525,4177,2265,530329,248,525568,249,2103137,1020]

theorem envBound9754 : H12AffineFastState.Bounded env9754 := by
  intro p hp
  have h : env9754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9744_9754 : H12AffineEnvironment.transform 13 17 env9744 = env9754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9744 == env9754) = true)

theorem identity9754 : scanCanonicalize (H12AffineFastState.compose env9754 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5201) := by decide +kernel

theorem selectedBound9754 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env9755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,8402,4605,262144,5201,8693,2097152,373,4540,34,8329,5921,262257,4525,4177,2265,968,248,4433,249,2103137,1020]

theorem envBound9755 : H12AffineFastState.Bounded env9755 := by
  intro p hp
  have h : env9755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9754_9755 : H12AffineEnvironment.transform 18 5201 env9754 = env9755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5201 env9754 == env9755) = true)

def env9756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,16777216,8329,79859,278625,4524,4176,16795883,17307579,16777435,525568,16793803,2119537,16778206]

theorem envBound9756 : H12AffineFastState.Bounded env9756 := by
  intro p hp
  have h : env9756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9706_9756 : H12AffineEnvironment.transform 26 278625 env9706 = env9756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278625 env9706 == env9756) = true)

def env9757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,90336,8329,79859,278625,4524,4176,75787,620379,90171,525568,73771,2119537,90942]

theorem envBound9757 : H12AffineFastState.Bounded env9757 := by
  intro p hp
  have h : env9757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9756_9757 : H12AffineEnvironment.transform 23 90336 env9756 = env9757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9756 == env9757) = true)

theorem identity9757 : scanCanonicalize (H12AffineFastState.compose env9757 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9757 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24770,4605,262144,524288,8693,2097152,16740,525805,34,8329,22321,278625,4524,4176,18633,530329,249,525568,16617,2119537,1020]

theorem envBound9758 : H12AffineFastState.Bounded env9758 := by
  intro p hp
  have h : env9758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9757_9758 : H12AffineEnvironment.transform 15 24770 env9757 = env9758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9757 == env9758) = true)

def env9759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,8402,4605,262144,524288,8693,2097152,372,525805,34,8329,5921,262257,4524,4176,2265,530329,249,525568,249,2103137,1020]

theorem envBound9759 : H12AffineFastState.Bounded env9759 := by
  intro p hp
  have h : env9759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9758_9759 : H12AffineEnvironment.transform 13 16 env9758 = env9759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9758 == env9759) = true)

theorem identity9759 : scanCanonicalize (H12AffineFastState.compose env9759 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9759 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9760 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8402,4097,262144,524288,8201,2097152,136,525329,34,8329,5853,262257,4176,4176,2265,530021,249,525564,249,2102941,512]

theorem envBound9760 : H12AffineFastState.Bounded env9760 := by
  intro p hp
  have h : env9760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9759_9760 : H12AffineEnvironment.transform 7 252 env9759 = env9760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9759 == env9760) = true)

theorem identity9760 : scanCanonicalize (H12AffineFastState.compose env9760 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529036) := by decide +kernel

theorem selectedBound9760 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9761 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8402,4097,262144,524288,8201,529036,136,525329,34,8329,5853,262257,4176,4176,2265,530021,249,525564,249,525329,512]

theorem envBound9761 : H12AffineFastState.Bounded env9761 := by
  intro p hp
  have h : env9761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9760_9761 : H12AffineEnvironment.transform 20 529036 env9760 = env9761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529036 env9760 == env9761) = true)

theorem identity9761 : scanCanonicalize (H12AffineFastState.compose env9761 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4660) := by decide +kernel

theorem selectedBound9761 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9762 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16,8201,8402,4097,262144,4660,8201,184,136,5669,34,8329,5853,262257,4176,4176,2265,1105,249,5832,249,5669,512]

theorem envBound9762 : H12AffineFastState.Bounded env9762 := by
  intro p hp
  have h : env9762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9761_9762 : H12AffineEnvironment.transform 18 4660 env9761 = env9762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4660 env9761 == env9762) = true)

theorem identity9762 : scanCanonicalize (H12AffineFastState.compose env9762 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound9762 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9763 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,16,2274,2105,4097,262144,4660,2274,184,136,5669,34,2146,5853,262257,4176,4176,2265,1105,249,5832,249,5669,512]

theorem envBound9763 : H12AffineFastState.Bounded env9763 := by
  intro p hp
  have h : env9763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9762_9763 : H12AffineEnvironment.transform 12 2283 env9762 = env9763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env9762 == env9763) = true)

theorem identity9763 : scanCanonicalize (H12AffineFastState.compose env9763 (packedSelected [2,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 1190) := by decide +kernel

theorem selectedBound9763 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9764 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,16,2274,2105,4097,1190,4660,2274,184,136,5669,34,2146,5853,1239,4176,4176,2265,1105,249,5832,249,5669,512]

theorem envBound9764 : H12AffineFastState.Bounded env9764 := by
  intro p hp
  have h : env9764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9763_9764 : H12AffineEnvironment.transform 17 1190 env9763 = env9764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1190 env9763 == env9764) = true)

theorem identity9764 : scanCanonicalize (H12AffineFastState.compose env9764 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound9764 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env9765 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2283,16,2274,2105,4097,162,4660,2274,184,136,4641,34,2146,4825,211,4176,4176,2265,85,249,4812,249,4641,512]

theorem envBound9765 : H12AffineFastState.Bounded env9765 := by
  intro p hp
  have h : env9765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9764_9765 : H12AffineEnvironment.transform 9 4 env9764 = env9765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env9764 == env9765) = true)

theorem identity9765 : scanCanonicalize (H12AffineFastState.compose env9765 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2739) := by decide +kernel

theorem selectedBound9765 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9766 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2739,2283,16,2274,2105,2738,162,2183,2274,184,136,2194,34,2146,2154,211,2787,2787,2265,85,249,2175,249,2194,512]

theorem envBound9766 : H12AffineFastState.Bounded env9766 := by
  intro p hp
  have h : env9766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9765_9766 : H12AffineEnvironment.transform 11 2739 env9765 = env9766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2739 env9765 == env9766) = true)

theorem identity9766 : scanCanonicalize (H12AffineFastState.compose env9766 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound9766 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9767 : List Nat := [2,4,8,16,32,64,128,252,201,4,2048,2170,2283,16,2274,2105,2171,162,2183,2274,184,136,2194,34,2146,2154,211,2090,2090,2265,85,249,2175,249,2194,201]

theorem envBound9767 : H12AffineFastState.Bounded env9767 := by
  intro p hp
  have h : env9767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9766_9767 : H12AffineEnvironment.transform 8 201 env9766 = env9767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env9766 == env9767) = true)

theorem identity9767 : scanCanonicalize (H12AffineFastState.compose env9767 (packedSelected [4,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound9767 : packedSelected [4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env9768 : List Nat := [2,4,8,16,32,64,128,252,201,4,10,112,225,16,232,51,113,162,141,232,184,136,152,34,104,96,211,32,32,211,85,249,117,249,152,201]

theorem envBound9768 : H12AffineFastState.Bounded env9768 := by
  intro p hp
  have h : env9768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9767_9768 : H12AffineEnvironment.transform 10 10 env9767 = env9768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env9767 == env9768) = true)

def env9769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,8403,4605,262144,524288,8693,2097152,373,525805,34,8329,5920,262256,4524,4176,2264,530329,249,525568,248,2103136,1020]

theorem envBound9769 : H12AffineFastState.Bounded env9769 := by
  intro p hp
  have h : env9769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9758_9769 : H12AffineEnvironment.transform 13 17 env9758 = env9769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9758 == env9769) = true)

theorem identity9769 : scanCanonicalize (H12AffineFastState.compose env9769 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5200) := by decide +kernel

theorem selectedBound9769 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env9770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,8403,4605,262144,5200,8693,2097152,373,4541,34,8329,5920,262256,4524,4176,2264,969,249,4432,248,2103136,1020]

theorem envBound9770 : H12AffineFastState.Bounded env9770 := by
  intro p hp
  have h : env9770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9769_9770 : H12AffineEnvironment.transform 18 5200 env9769 = env9770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5200 env9769 == env9770) = true)

def env9771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,90337,8329,79859,278625,4524,4176,75786,620378,90170,525568,73770,2119537,90943]

theorem envBound9771 : H12AffineFastState.Bounded env9771 := by
  intro p hp
  have h : env9771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9756_9771 : H12AffineEnvironment.transform 23 90337 env9756 = env9771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9756 == env9771) = true)

theorem identity9771 : scanCanonicalize (H12AffineFastState.compose env9771 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9771 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9772 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16536,525329,90337,8329,79375,278625,4176,4176,75786,620198,90170,525564,73770,2119309,90819]

theorem envBound9772 : H12AffineFastState.Bounded env9772 := by
  intro p hp
  have h : env9772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9771_9772 : H12AffineEnvironment.transform 7 252 env9771 = env9772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9771 == env9772) = true)

def env9773 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16480,525329,90137,8305,79375,278625,4176,4176,75786,620126,90170,525316,73770,2119285,90683]

theorem envBound9773 : H12AffineFastState.Bounded env9773 := by
  intro p hp
  have h : env9773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9772_9773 : H12AffineEnvironment.transform 6 120 env9772 = env9773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9772 == env9773) = true)

theorem identity9773 : scanCanonicalize (H12AffineFastState.compose env9773 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545380) := by decide +kernel

theorem selectedBound9773 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9774 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545380,16480,525329,90137,8305,79375,278625,4176,4176,75786,620126,90170,525316,73770,525329,90683]

theorem envBound9774 : H12AffineFastState.Bounded env9774 := by
  intro p hp
  have h : env9774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9773_9774 : H12AffineEnvironment.transform 20 545380 env9773 = env9774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545380 env9773 == env9774) = true)

def env9775 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545332,16432,525329,90137,8225,79375,278577,4096,4096,75786,620046,90170,525316,73770,525329,90683]

theorem envBound9775 : H12AffineFastState.Bounded env9775 := by
  intro p hp
  have h : env9775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9774_9775 : H12AffineEnvironment.transform 5 16 env9774 = env9775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9774 == env9775) = true)

theorem identity9775 : scanCanonicalize (H12AffineFastState.compose env9775 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound9775 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9776 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,524288,8201,545332,16432,525329,90137,8225,79375,24101,4096,4096,75786,620046,90170,525316,73770,525329,90683]

theorem envBound9776 : H12AffineFastState.Bounded env9776 := by
  intro p hp
  have h : env9776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9775_9776 : H12AffineEnvironment.transform 17 7700 env9775 = env9776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env9775 == env9776) = true)

theorem identity9776 : scanCanonicalize (H12AffineFastState.compose env9776 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78366) := by decide +kernel

theorem selectedBound9776 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9777 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,78366,8201,90154,16432,79375,90137,8225,79375,24101,4096,4096,75786,17424,90170,79386,73770,79375,90683]

theorem envBound9777 : H12AffineFastState.Bounded env9777 := by
  intro p hp
  have h : env9777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9776_9777 : H12AffineEnvironment.transform 18 78366 env9776 = env9777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78366 env9776 == env9777) = true)

theorem identity9777 : scanCanonicalize (H12AffineFastState.compose env9777 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9777 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env9778 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,17,8201,65536,4097,7700,78366,8201,73787,33,79375,73736,8225,79375,7732,4096,4096,75786,1025,73771,79386,73770,79375,74282]

theorem envBound9778 : H12AffineFastState.Bounded env9778 := by
  intro p hp
  have h : env9778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9777_9778 : H12AffineEnvironment.transform 13 17 env9777 = env9778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9777 == env9778) = true)

theorem identity9778 : scanCanonicalize (H12AffineFastState.compose env9778 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound9778 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9779 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,4096,8192,17,8201,65536,4097,5669,78366,8201,73787,33,79375,73736,8225,79375,5637,4096,4096,73787,1025,73771,79386,73770,79375,74282]

theorem envBound9779 : H12AffineFastState.Bounded env9779 := by
  intro p hp
  have h : env9779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9778_9779 : H12AffineEnvironment.transform 10 49 env9778 = env9779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env9778 == env9779) = true)

theorem identity9779 : scanCanonicalize (H12AffineFastState.compose env9779 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound9779 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9780 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,4096,25,17,16,65536,4097,5669,70151,16,65570,33,71190,65553,56,71190,5637,4096,4096,65570,1025,65586,71171,65587,71190,66099]

theorem envBound9780 : H12AffineFastState.Bounded env9780 := by
  intro p hp
  have h : env9780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9779_9780 : H12AffineEnvironment.transform 12 25 env9779 = env9780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env9779 == env9780) = true)

theorem identity9780 : scanCanonicalize (H12AffineFastState.compose env9780 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 1542) := by decide +kernel

theorem selectedBound9780 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9781 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,4096,25,17,16,1542,4097,5669,5121,16,1572,33,4112,1559,56,4112,5637,4096,4096,1572,1025,1588,4101,1589,4112,1077]

theorem envBound9781 : H12AffineFastState.Bounded env9781 := by
  intro p hp
  have h : env9781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9780_9781 : H12AffineEnvironment.transform 15 1542 env9780 = env9781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1542 env9780 == env9781) = true)

theorem identity9781 : scanCanonicalize (H12AffineFastState.compose env9781 (packedSelected [1,2,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound9781 : packedSelected [1,2,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9782 : List Nat := [2,4,8,16,32,16,40,4,512,1024,49,1541,25,17,16,1542,1540,32,516,16,1572,33,1557,1559,56,1557,0,1541,1541,1572,1025,1588,1536,1589,1557,1077]

theorem envBound9782 : H12AffineFastState.Bounded env9782 := by
  intro p hp
  have h : env9782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9781_9782 : H12AffineEnvironment.transform 11 1541 env9781 = env9782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env9781 == env9782) = true)

theorem identity9782 : scanCanonicalize (H12AffineFastState.compose env9782 (packedSelected [0,2,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound9782 : packedSelected [0,2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9783 : List Nat := [2,4,8,16,32,16,40,4,512,543,49,26,25,17,16,25,27,32,516,16,59,33,10,8,56,10,0,26,26,59,542,43,31,42,10,554]

theorem envBound9783 : H12AffineFastState.Bounded env9783 := by
  intro p hp
  have h : env9783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9782_9783 : H12AffineEnvironment.transform 9 543 env9782 = env9783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env9782 == env9783) = true)

theorem identity9783 : scanCanonicalize (H12AffineFastState.compose env9783 (packedSelected [0,2,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound9783 : packedSelected [0,2,11,12] rootPS < 2^1333 := by decide +kernel

def env9784 : List Nat := [2,4,8,16,32,16,40,4,17,14,49,26,25,17,16,25,27,32,21,16,59,33,10,8,56,10,0,26,26,59,15,43,31,42,10,59]

theorem envBound9784 : H12AffineFastState.Bounded env9784 := by
  intro p hp
  have h : env9784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9783_9784 : H12AffineEnvironment.transform 8 17 env9783 = env9784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env9783 == env9784) = true)

theorem identity9784 : scanCanonicalize (H12AffineFastState.compose env9784 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9784 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env9785 : List Nat := [2,4,8,16,16,16,24,4,17,14,1,26,25,17,16,25,27,16,21,16,11,17,10,8,8,10,0,26,26,11,15,27,31,26,10,11]

theorem envBound9785 : H12AffineFastState.Bounded env9785 := by
  intro p hp
  have h : env9785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9784_9785 : H12AffineEnvironment.transform 4 16 env9784 = env9785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9784 == env9785) = true)

theorem identity9785 : scanCanonicalize (H12AffineFastState.compose env9785 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9785 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9786 : List Nat := [2,4,8,11,11,11,3,4,10,14,1,1,2,10,11,2,0,11,14,11,11,10,10,8,8,10,0,1,1,11,15,0,4,1,10,11]

theorem envBound9786 : H12AffineFastState.Bounded env9786 := by
  intro p hp
  have h : env9786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9785_9786 : H12AffineEnvironment.transform 3 11 env9785 = env9786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9785 == env9786) = true)

theorem identity9786 : scanCanonicalize (H12AffineFastState.compose env9786 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9787 : List Nat := [2,4,3,0,0,0,3,4,1,5,1,1,2,1,0,2,0,0,5,0,0,1,1,3,3,1,0,1,1,0,4,0,4,1,1,0]

theorem envBound9787 : H12AffineFastState.Bounded env9787 := by
  intro p hp
  have h : env9787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9786_9787 : H12AffineEnvironment.transform 2 3 env9786 = env9787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9786 == env9787) = true)

theorem identity9787 : scanCanonicalize (H12AffineFastState.compose env9787 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9787 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9788 : List Nat := [2,1,3,0,0,0,3,1,1,0,1,1,2,1,0,2,0,0,0,0,0,1,1,3,3,1,0,1,1,0,1,0,1,1,1,0]

theorem envBound9788 : H12AffineFastState.Bounded env9788 := by
  intro p hp
  have h : env9788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9787_9788 : H12AffineEnvironment.transform 1 1 env9787 = env9788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9787 == env9788) = true)

def env9789 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545333,16433,525329,90137,8224,79375,278576,4097,4097,75786,620047,90170,525316,73770,525329,90683]

theorem envBound9789 : H12AffineFastState.Bounded env9789 := by
  intro p hp
  have h : env9789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9774_9789 : H12AffineEnvironment.transform 5 17 env9774 = env9789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9774 == env9789) = true)

theorem identity9789 : scanCanonicalize (H12AffineFastState.compose env9789 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338955) := by decide +kernel

theorem selectedBound9789 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9790 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,338955,8201,359998,16433,337946,90137,8224,79375,278576,4097,4097,75786,285188,90170,337935,73770,337946,90683]

theorem envBound9790 : H12AffineFastState.Bounded env9790 := by
  intro p hp
  have h : env9790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9789_9790 : H12AffineEnvironment.transform 18 338955 env9789 = env9790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338955 env9789 == env9790) = true)

theorem identity9790 : scanCanonicalize (H12AffineFastState.compose env9790 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24069) := by decide +kernel

theorem selectedBound9790 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9791 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,24069,94734,8201,73787,16433,95775,90137,8224,79375,7733,4097,4097,75786,1025,90170,95754,73770,95775,90683]

theorem envBound9791 : H12AffineFastState.Bounded env9791 := by
  intro p hp
  have h : env9791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9790_9791 : H12AffineEnvironment.transform 17 24069 env9790 = env9791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24069 env9790 == env9791) = true)

def env9792 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16481,525329,90136,8304,79375,278625,4176,4176,75786,620127,90170,525317,73770,2119284,90682]

theorem envBound9792 : H12AffineFastState.Bounded env9792 := by
  intro p hp
  have h : env9792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9772_9792 : H12AffineEnvironment.transform 6 121 env9772 = env9792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9772 == env9792) = true)

theorem identity9792 : scanCanonicalize (H12AffineFastState.compose env9792 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619086) := by decide +kernel

theorem selectedBound9792 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9793 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619086,16481,525329,90136,8304,79375,278625,4176,4176,75786,620127,90170,525317,73770,599098,90682]

theorem envBound9793 : H12AffineFastState.Bounded env9793 := by
  intro p hp
  have h : env9793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9792_9793 : H12AffineEnvironment.transform 20 619086 env9792 = env9793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619086 env9792 == env9793) = true)

def env9794 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619038,16433,525329,90136,8224,79375,278577,4096,4096,75786,620047,90170,525317,73770,599098,90682]

theorem envBound9794 : H12AffineFastState.Bounded env9794 := by
  intro p hp
  have h : env9794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9793_9794 : H12AffineEnvironment.transform 5 16 env9793 = env9794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9793 == env9794) = true)

theorem identity9794 : scanCanonicalize (H12AffineFastState.compose env9794 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound9794 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9795 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,97839,524288,8201,619038,16433,525329,90136,8224,79375,81438,4096,4096,75786,620047,90170,525317,73770,599098,90682]

theorem envBound9795 : H12AffineFastState.Bounded env9795 := by
  intro p hp
  have h : env9795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9794_9795 : H12AffineEnvironment.transform 17 97839 env9794 = env9795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env9794 == env9795) = true)

theorem identity9795 : scanCanonicalize (H12AffineFastState.compose env9795 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94735) := by decide +kernel

theorem selectedBound9795 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9796 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,97839,94735,8201,17,16433,95774,90136,8224,79375,81438,4096,4096,75786,1024,90170,95754,73770,22069,90682]

theorem envBound9796 : H12AffineFastState.Bounded env9796 := by
  intro p hp
  have h : env9796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9795_9796 : H12AffineEnvironment.transform 18 94735 env9795 = env9796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94735 env9795 == env9796) = true)

theorem identity9796 : scanCanonicalize (H12AffineFastState.compose env9796 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound9796 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9797 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,24634,4097,7701,4661,8201,17,16433,5668,34,8224,22069,24100,4096,4096,18480,1024,0,5680,16400,22069,512]

theorem envBound9797 : H12AffineFastState.Bounded env9797 := by
  intro p hp
  have h : env9797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9796_9797 : H12AffineEnvironment.transform 15 24634 env9796 = env9797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env9796 == env9797) = true)

theorem identity9797 : scanCanonicalize (H12AffineFastState.compose env9797 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 7214) := by decide +kernel

theorem selectedBound9797 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9798 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,7214,8201,15380,4097,7701,4661,8201,17,7199,5668,34,8224,2587,522,4096,4096,5150,1024,0,5680,7230,2587,512]

theorem envBound9798 : H12AffineFastState.Bounded env9798 := by
  intro p hp
  have h : env9798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9797_9798 : H12AffineEnvironment.transform 13 7214 env9797 = env9798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7214 env9797 == env9798) = true)

theorem identity9798 : scanCanonicalize (H12AffineFastState.compose env9798 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3135) := by decide +kernel

theorem selectedBound9798 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9799 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3135,8192,17,8201,8235,3134,554,3594,8201,17,32,2587,34,8224,2587,522,3135,3135,2081,1024,0,2575,1,2587,512]

theorem envBound9799 : H12AffineFastState.Bounded env9799 := by
  intro p hp
  have h : env9799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9798_9799 : H12AffineEnvironment.transform 11 3135 env9798 = env9799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3135 env9798 == env9799) = true)

theorem identity9799 : scanCanonicalize (H12AffineFastState.compose env9799 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound9799 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9800 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3135,1062,17,1071,1037,3134,554,3594,1071,17,32,2587,34,1030,2587,522,3135,3135,2081,1024,0,2575,1,2587,512]

theorem envBound9800 : H12AffineFastState.Bounded env9800 := by
  intro p hp
  have h : env9800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9799_9800 : H12AffineEnvironment.transform 12 1062 env9799 = env9800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env9799 == env9800) = true)

theorem identity9800 : scanCanonicalize (H12AffineFastState.compose env9800 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9800 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9801 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3103,1030,17,1039,1037,3102,522,3594,1039,17,0,2587,2,1030,2587,522,3103,3103,2049,1024,0,2575,1,2587,512]

theorem envBound9801 : H12AffineFastState.Bounded env9801 := by
  intro p hp
  have h : env9801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9800_9801 : H12AffineEnvironment.transform 4 0 env9800 = env9801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9800 == env9801) = true)

theorem identity9801 : scanCanonicalize (H12AffineFastState.compose env9801 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound9801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9802 : List Nat := [2,4,8,16,0,16,9,5,512,15,2048,2064,9,17,0,2,2065,522,2565,0,17,0,2587,2,9,2587,522,2064,2064,2049,15,0,2575,1,2587,512]

theorem envBound9802 : H12AffineFastState.Bounded env9802 := by
  intro p hp
  have h : env9802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9801_9802 : H12AffineEnvironment.transform 9 15 env9801 = env9802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env9801 == env9802) = true)

theorem identity9802 : scanCanonicalize (H12AffineFastState.compose env9802 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound9802 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env9803 : List Nat := [2,4,8,16,0,16,9,5,512,15,11,27,9,17,0,2,26,522,526,0,17,0,528,2,9,528,522,27,27,10,15,0,516,1,528,512]

theorem envBound9803 : H12AffineFastState.Bounded env9803 := by
  intro p hp
  have h : env9803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9802_9803 : H12AffineEnvironment.transform 10 11 env9802 = env9803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env9802 == env9803) = true)

theorem identity9803 : scanCanonicalize (H12AffineFastState.compose env9803 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound9803 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9804 : List Nat := [2,4,8,16,0,16,9,5,0,15,11,27,9,17,0,2,26,10,14,0,17,0,16,2,9,16,10,27,27,10,15,0,4,1,16,0]

theorem envBound9804 : H12AffineFastState.Bounded env9804 := by
  intro p hp
  have h : env9804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9803_9804 : H12AffineEnvironment.transform 8 0 env9803 = env9804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env9803 == env9804) = true)

theorem identity9804 : scanCanonicalize (H12AffineFastState.compose env9804 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9804 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9805 : List Nat := [2,4,8,10,0,10,9,5,0,15,11,1,9,11,0,2,0,10,14,0,11,0,10,2,9,10,10,1,1,10,15,0,4,1,10,0]

theorem envBound9805 : H12AffineFastState.Bounded env9805 := by
  intro p hp
  have h : env9805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9804_9805 : H12AffineEnvironment.transform 3 10 env9804 = env9805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9804 == env9805) = true)

def env9806 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619039,16432,525329,90136,8225,79375,278576,4097,4097,75786,620046,90170,525317,73770,599098,90682]

theorem envBound9806 : H12AffineFastState.Bounded env9806 := by
  intro p hp
  have h : env9806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9793_9806 : H12AffineEnvironment.transform 5 17 env9793 = env9806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9793 == env9806) = true)

theorem identity9806 : scanCanonicalize (H12AffineFastState.compose env9806 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281649) := by decide +kernel

theorem selectedBound9806 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9807 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,281649,8201,343598,16432,280608,90136,8225,79375,278576,4097,4097,75786,342591,90170,280628,73770,354315,90682]

theorem envBound9807 : H12AffineFastState.Bounded env9807 := by
  intro p hp
  have h : env9807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9806_9807 : H12AffineEnvironment.transform 18 281649 env9806 = env9807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281649 env9806 == env9807) = true)

theorem identity9807 : scanCanonicalize (H12AffineFastState.compose env9807 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound9807 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9808 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,97838,78367,8201,16384,16432,79374,90136,8225,79375,81438,4097,4097,75786,17425,90170,79386,73770,5669,90682]

theorem envBound9808 : H12AffineFastState.Bounded env9808 := by
  intro p hp
  have h : env9808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9807_9808 : H12AffineEnvironment.transform 17 97838 env9807 = env9808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env9807 == env9808) = true)

def env9809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,16777216,8329,79859,134217728,134500812,134500400,151259274,17307579,151273659,525568,151257258,136582928,16778206]

theorem envBound9809 : H12AffineFastState.Bounded env9809 := by
  intro p hp
  have h : env9809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9705_9809 : H12AffineEnvironment.transform 21 16741 env9705 = env9809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16741 env9705 == env9809) = true)

def env9810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,16777216,8329,79859,278624,4524,4176,16795882,17307579,16777435,525568,16793802,2119536,16778206]

theorem envBound9810 : H12AffineFastState.Bounded env9810 := by
  intro p hp
  have h : env9810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9809_9810 : H12AffineEnvironment.transform 26 278624 env9809 = env9810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278624 env9809 == env9810) = true)

def env9811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,90336,8329,79859,278624,4524,4176,75786,620379,90171,525568,73770,2119536,90942]

theorem envBound9811 : H12AffineFastState.Bounded env9811 := by
  intro p hp
  have h : env9811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9810_9811 : H12AffineEnvironment.transform 23 90336 env9810 = env9811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9810 == env9811) = true)

theorem identity9811 : scanCanonicalize (H12AffineFastState.compose env9811 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9811 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9812 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16537,525329,90336,8329,79375,278624,4176,4176,75786,620199,90171,525564,73770,2119308,90818]

theorem envBound9812 : H12AffineFastState.Bounded env9812 := by
  intro p hp
  have h : env9812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9811_9812 : H12AffineEnvironment.transform 7 252 env9811 = env9812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9811 == env9812) = true)

def env9813 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16481,525329,90136,8305,79375,278624,4176,4176,75786,620127,90171,525316,73770,2119284,90682]

theorem envBound9813 : H12AffineFastState.Bounded env9813 := by
  intro p hp
  have h : env9813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9812_9813 : H12AffineEnvironment.transform 6 120 env9812 = env9813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9812 == env9813) = true)

theorem identity9813 : scanCanonicalize (H12AffineFastState.compose env9813 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545380) := by decide +kernel

theorem selectedBound9813 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9814 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545380,16481,525329,90136,8305,79375,278624,4176,4176,75786,620127,90171,525316,73770,525328,90682]

theorem envBound9814 : H12AffineFastState.Bounded env9814 := by
  intro p hp
  have h : env9814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9813_9814 : H12AffineEnvironment.transform 20 545380 env9813 = env9814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545380 env9813 == env9814) = true)

def env9815 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545332,16433,525329,90136,8225,79375,278576,4096,4096,75786,620047,90171,525316,73770,525328,90682]

theorem envBound9815 : H12AffineFastState.Bounded env9815 := by
  intro p hp
  have h : env9815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9814_9815 : H12AffineEnvironment.transform 5 16 env9814 = env9815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9814 == env9815) = true)

theorem identity9815 : scanCanonicalize (H12AffineFastState.compose env9815 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound9815 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9816 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,524288,8201,545332,16433,525329,90136,8225,79375,24100,4096,4096,75786,620047,90171,525316,73770,525328,90682]

theorem envBound9816 : H12AffineFastState.Bounded env9816 := by
  intro p hp
  have h : env9816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9815_9816 : H12AffineEnvironment.transform 17 7700 env9815 = env9816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env9815 == env9816) = true)

theorem identity9816 : scanCanonicalize (H12AffineFastState.compose env9816 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78366) := by decide +kernel

theorem selectedBound9816 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9817 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,78366,8201,90154,16433,79375,90136,8225,79375,24100,4096,4096,75786,17425,90171,79386,73770,79374,90682]

theorem envBound9817 : H12AffineFastState.Bounded env9817 := by
  intro p hp
  have h : env9817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9816_9817 : H12AffineEnvironment.transform 18 78366 env9816 = env9817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78366 env9816 == env9817) = true)

theorem identity9817 : scanCanonicalize (H12AffineFastState.compose env9817 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9817 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env9818 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16,8201,65536,4097,7700,78366,8201,73786,33,79375,73736,8225,79375,7732,4096,4096,75786,1025,73771,79386,73770,79374,74282]

theorem envBound9818 : H12AffineFastState.Bounded env9818 := by
  intro p hp
  have h : env9818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9817_9818 : H12AffineEnvironment.transform 13 16 env9817 = env9818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9817 == env9818) = true)

theorem identity9818 : scanCanonicalize (H12AffineFastState.compose env9818 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound9818 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9819 : List Nat := [2,4,8,16,32,16,40,4,512,1024,48,4096,8192,16,8201,65536,4097,5668,78366,8201,73786,33,79375,73736,8225,79375,5636,4096,4096,73786,1025,73771,79386,73770,79374,74282]

theorem envBound9819 : H12AffineFastState.Bounded env9819 := by
  intro p hp
  have h : env9819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9818_9819 : H12AffineEnvironment.transform 10 48 env9818 = env9819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env9818 == env9819) = true)

theorem identity9819 : scanCanonicalize (H12AffineFastState.compose env9819 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound9819 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9820 : List Nat := [2,4,8,16,32,16,40,4,512,1024,48,4096,24,16,17,65536,4097,5668,70150,17,65570,33,71191,65552,57,71191,5636,4096,4096,65570,1025,65587,71170,65586,71190,66098]

theorem envBound9820 : H12AffineFastState.Bounded env9820 := by
  intro p hp
  have h : env9820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9819_9820 : H12AffineEnvironment.transform 12 24 env9819 = env9820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env9819 == env9820) = true)

theorem identity9820 : scanCanonicalize (H12AffineFastState.compose env9820 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound9820 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9821 : List Nat := [2,4,8,16,32,16,40,4,512,565,48,4096,24,16,17,65536,4097,4113,70150,17,65570,33,69666,65552,57,69666,4145,4096,4096,65570,564,65587,69687,65586,69667,66098]

theorem envBound9821 : H12AffineFastState.Bounded env9821 := by
  intro p hp
  have h : env9821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9820_9821 : H12AffineEnvironment.transform 9 565 env9820 = env9821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env9820 == env9821) = true)

theorem identity9821 : scanCanonicalize (H12AffineFastState.compose env9821 (packedSelected [1,2,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound9821 : packedSelected [1,2,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9822 : List Nat := [2,4,8,16,32,16,40,4,512,565,48,49,24,16,17,65536,48,32,66103,17,65570,33,65555,65552,57,65555,0,49,49,65570,564,65587,65542,65586,65554,66098]

theorem envBound9822 : H12AffineFastState.Bounded env9822 := by
  intro p hp
  have h : env9822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9821_9822 : H12AffineEnvironment.transform 11 49 env9821 = env9822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env9821 == env9822) = true)

theorem identity9822 : scanCanonicalize (H12AffineFastState.compose env9822 (packedSelected [0,2,4,6,7] rootPS)) = affineNative (2^(15+1) ^^^ 25) := by decide +kernel

theorem selectedBound9822 : packedSelected [0,2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9823 : List Nat := [2,4,8,16,32,16,40,4,512,565,48,49,24,16,17,25,48,32,558,17,59,33,10,9,57,10,0,49,49,59,564,42,31,43,11,555]

theorem envBound9823 : H12AffineFastState.Bounded env9823 := by
  intro p hp
  have h : env9823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9822_9823 : H12AffineEnvironment.transform 15 25 env9822 = env9823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env9822 == env9823) = true)

theorem identity9823 : scanCanonicalize (H12AffineFastState.compose env9823 (packedSelected [0,2,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound9823 : packedSelected [0,2,11,12] rootPS < 2^1333 := by decide +kernel

def env9824 : List Nat := [2,4,8,16,32,16,40,4,59,14,48,49,24,16,17,25,48,32,21,17,59,33,10,9,57,10,0,49,49,59,15,42,31,43,11,16]

theorem envBound9824 : H12AffineFastState.Bounded env9824 := by
  intro p hp
  have h : env9824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9823_9824 : H12AffineEnvironment.transform 8 59 env9823 = env9824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env9823 == env9824) = true)

theorem identity9824 : scanCanonicalize (H12AffineFastState.compose env9824 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9824 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env9825 : List Nat := [2,4,8,16,17,16,25,4,10,14,1,0,24,16,17,25,1,17,21,17,10,16,10,9,8,10,0,0,0,10,15,27,31,26,11,16]

theorem envBound9825 : H12AffineFastState.Bounded env9825 := by
  intro p hp
  have h : env9825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9824_9825 : H12AffineEnvironment.transform 4 17 env9824 = env9825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9824 == env9825) = true)

theorem identity9825 : scanCanonicalize (H12AffineFastState.compose env9825 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9825 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9826 : List Nat := [2,4,8,11,10,11,2,4,10,14,1,0,3,11,10,2,1,10,14,10,10,11,10,9,8,10,0,0,0,10,15,0,4,1,11,11]

theorem envBound9826 : H12AffineFastState.Bounded env9826 := by
  intro p hp
  have h : env9826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9825_9826 : H12AffineEnvironment.transform 3 11 env9825 = env9826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9825 == env9826) = true)

theorem identity9826 : scanCanonicalize (H12AffineFastState.compose env9826 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9827 : List Nat := [2,4,2,1,0,1,2,4,0,4,1,0,3,1,0,2,1,0,4,0,0,1,0,3,2,0,0,0,0,0,5,0,4,1,1,1]

theorem envBound9827 : H12AffineFastState.Bounded env9827 := by
  intro p hp
  have h : env9827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9826_9827 : H12AffineEnvironment.transform 2 2 env9826 = env9827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9826 == env9827) = true)

theorem identity9827 : scanCanonicalize (H12AffineFastState.compose env9827 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9828 : List Nat := [2,1,2,1,0,1,2,1,0,1,1,0,3,1,0,2,1,0,1,0,0,1,0,3,2,0,0,0,0,0,0,0,1,1,1,1]

theorem envBound9828 : H12AffineFastState.Bounded env9828 := by
  intro p hp
  have h : env9828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9827_9828 : H12AffineEnvironment.transform 1 1 env9827 = env9828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9827 == env9828) = true)

def env9829 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545333,16432,525329,90136,8224,79375,278577,4097,4097,75786,620046,90171,525316,73770,525328,90682]

theorem envBound9829 : H12AffineFastState.Bounded env9829 := by
  intro p hp
  have h : env9829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9814_9829 : H12AffineEnvironment.transform 5 17 env9814 = env9829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9814 == env9829) = true)

theorem identity9829 : scanCanonicalize (H12AffineFastState.compose env9829 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338955) := by decide +kernel

theorem selectedBound9829 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9830 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,338955,8201,359998,16432,337946,90136,8224,79375,278577,4097,4097,75786,285189,90171,337935,73770,337947,90682]

theorem envBound9830 : H12AffineFastState.Bounded env9830 := by
  intro p hp
  have h : env9830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9829_9830 : H12AffineEnvironment.transform 18 338955 env9829 = env9830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338955 env9829 == env9830) = true)

theorem identity9830 : scanCanonicalize (H12AffineFastState.compose env9830 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24068) := by decide +kernel

theorem selectedBound9830 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9831 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,24068,94735,8201,73786,16432,95774,90136,8224,79375,7733,4097,4097,75786,1025,90171,95755,73770,95775,90682]

theorem envBound9831 : H12AffineFastState.Bounded env9831 := by
  intro p hp
  have h : env9831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9830_9831 : H12AffineEnvironment.transform 17 24068 env9830 = env9831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24068 env9830 == env9831) = true)

def env9832 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16480,525329,90137,8304,79375,278624,4176,4176,75786,620126,90171,525317,73770,2119285,90683]

theorem envBound9832 : H12AffineFastState.Bounded env9832 := by
  intro p hp
  have h : env9832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9812_9832 : H12AffineEnvironment.transform 6 121 env9812 = env9832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9812 == env9832) = true)

theorem identity9832 : scanCanonicalize (H12AffineFastState.compose env9832 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619086) := by decide +kernel

theorem selectedBound9832 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9833 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619086,16480,525329,90137,8304,79375,278624,4176,4176,75786,620126,90171,525317,73770,599099,90683]

theorem envBound9833 : H12AffineFastState.Bounded env9833 := by
  intro p hp
  have h : env9833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9832_9833 : H12AffineEnvironment.transform 20 619086 env9832 = env9833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619086 env9832 == env9833) = true)

def env9834 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619038,16432,525329,90137,8224,79375,278576,4096,4096,75786,620046,90171,525317,73770,599099,90683]

theorem envBound9834 : H12AffineFastState.Bounded env9834 := by
  intro p hp
  have h : env9834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9833_9834 : H12AffineEnvironment.transform 5 16 env9833 = env9834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9833 == env9834) = true)

theorem identity9834 : scanCanonicalize (H12AffineFastState.compose env9834 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound9834 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9835 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,97838,524288,8201,619038,16432,525329,90137,8224,79375,81438,4096,4096,75786,620046,90171,525317,73770,599099,90683]

theorem envBound9835 : H12AffineFastState.Bounded env9835 := by
  intro p hp
  have h : env9835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9834_9835 : H12AffineEnvironment.transform 17 97838 env9834 = env9835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env9834 == env9835) = true)

theorem identity9835 : scanCanonicalize (H12AffineFastState.compose env9835 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94734) := by decide +kernel

theorem selectedBound9835 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9836 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,97838,94734,8201,16,16432,95775,90137,8224,79375,81438,4096,4096,75786,1024,90171,95755,73770,22069,90683]

theorem envBound9836 : H12AffineFastState.Bounded env9836 := by
  intro p hp
  have h : env9836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9835_9836 : H12AffineEnvironment.transform 18 94734 env9835 = env9836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94734 env9835 == env9836) = true)

theorem identity9836 : scanCanonicalize (H12AffineFastState.compose env9836 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound9836 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9837 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,24635,4097,7701,4661,8201,16,16432,5668,34,8224,22068,24101,4096,4096,18481,1024,0,5680,16401,22069,512]

theorem envBound9837 : H12AffineFastState.Bounded env9837 := by
  intro p hp
  have h : env9837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9836_9837 : H12AffineEnvironment.transform 15 24635 env9836 = env9837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env9836 == env9837) = true)

theorem identity9837 : scanCanonicalize (H12AffineFastState.compose env9837 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound9837 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9838 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3134,8192,16384,8201,24635,3135,555,3595,8201,16,16432,2586,34,8224,18954,16923,3134,3134,18481,1024,0,2574,16401,18955,512]

theorem envBound9838 : H12AffineFastState.Bounded env9838 := by
  intro p hp
  have h : env9838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9837_9838 : H12AffineEnvironment.transform 11 3134 env9837 = env9838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env9837 == env9838) = true)

theorem identity9838 : scanCanonicalize (H12AffineFastState.compose env9838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9839 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3134,8192,16,8201,8235,3135,555,3595,8201,16,32,2586,34,8224,2586,523,3134,3134,2081,1024,0,2574,1,2587,512]

theorem envBound9839 : H12AffineFastState.Bounded env9839 := by
  intro p hp
  have h : env9839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9838_9839 : H12AffineEnvironment.transform 13 16 env9838 = env9839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9838 == env9839) = true)

theorem identity9839 : scanCanonicalize (H12AffineFastState.compose env9839 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound9839 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9840 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,3134,1062,16,1071,1037,3135,555,3595,1071,16,32,2586,34,1030,2586,523,3134,3134,2081,1024,0,2574,1,2587,512]

theorem envBound9840 : H12AffineFastState.Bounded env9840 := by
  intro p hp
  have h : env9840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9839_9840 : H12AffineEnvironment.transform 12 1062 env9839 = env9840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env9839 == env9840) = true)

theorem identity9840 : scanCanonicalize (H12AffineFastState.compose env9840 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9840 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9841 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3102,1030,16,1039,1037,3103,523,3595,1039,16,0,2586,2,1030,2586,523,3102,3102,2049,1024,0,2574,1,2587,512]

theorem envBound9841 : H12AffineFastState.Bounded env9841 := by
  intro p hp
  have h : env9841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9840_9841 : H12AffineEnvironment.transform 4 0 env9840 = env9841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9840 == env9841) = true)

theorem identity9841 : scanCanonicalize (H12AffineFastState.compose env9841 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound9841 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9842 : List Nat := [2,4,8,16,0,16,9,5,512,15,2048,2065,9,16,0,2,2064,523,2564,0,16,0,2586,2,9,2586,523,2065,2065,2049,15,0,2574,1,2587,512]

theorem envBound9842 : H12AffineFastState.Bounded env9842 := by
  intro p hp
  have h : env9842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9841_9842 : H12AffineEnvironment.transform 9 15 env9841 = env9842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env9841 == env9842) = true)

theorem identity9842 : scanCanonicalize (H12AffineFastState.compose env9842 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound9842 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env9843 : List Nat := [2,4,8,16,0,16,9,5,512,15,10,27,9,16,0,2,26,523,526,0,16,0,528,2,9,528,523,27,27,11,15,0,516,1,529,512]

theorem envBound9843 : H12AffineFastState.Bounded env9843 := by
  intro p hp
  have h : env9843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9842_9843 : H12AffineEnvironment.transform 10 10 env9842 = env9843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env9842 == env9843) = true)

theorem identity9843 : scanCanonicalize (H12AffineFastState.compose env9843 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound9843 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9844 : List Nat := [2,4,8,16,0,16,9,5,0,15,10,27,9,16,0,2,26,11,14,0,16,0,16,2,9,16,11,27,27,11,15,0,4,1,17,0]

theorem envBound9844 : H12AffineFastState.Bounded env9844 := by
  intro p hp
  have h : env9844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9843_9844 : H12AffineEnvironment.transform 8 0 env9843 = env9844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env9843 == env9844) = true)

theorem identity9844 : scanCanonicalize (H12AffineFastState.compose env9844 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9845 : List Nat := [2,4,8,10,0,10,9,5,0,15,10,1,9,10,0,2,0,11,14,0,10,0,10,2,9,10,11,1,1,11,15,0,4,1,11,0]

theorem envBound9845 : H12AffineFastState.Bounded env9845 := by
  intro p hp
  have h : env9845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9844_9845 : H12AffineEnvironment.transform 3 10 env9844 = env9845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9844 == env9845) = true)

def env9846 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619039,16433,525329,90137,8225,79375,278577,4097,4097,75786,620047,90171,525317,73770,599099,90683]

theorem envBound9846 : H12AffineFastState.Bounded env9846 := by
  intro p hp
  have h : env9846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9833_9846 : H12AffineEnvironment.transform 5 17 env9833 = env9846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9833 == env9846) = true)

theorem identity9846 : scanCanonicalize (H12AffineFastState.compose env9846 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281648) := by decide +kernel

theorem selectedBound9846 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9847 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,281648,8201,343599,16433,280609,90137,8225,79375,278577,4097,4097,75786,342591,90171,280629,73770,354315,90683]

theorem envBound9847 : H12AffineFastState.Bounded env9847 := by
  intro p hp
  have h : env9847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9846_9847 : H12AffineEnvironment.transform 18 281648 env9846 = env9847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281648 env9846 == env9847) = true)

theorem identity9847 : scanCanonicalize (H12AffineFastState.compose env9847 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound9847 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9848 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,97839,78367,8201,16384,16433,79374,90137,8225,79375,81438,4097,4097,75786,17424,90171,79386,73770,5668,90683]

theorem envBound9848 : H12AffineFastState.Bounded env9848 := by
  intro p hp
  have h : env9848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9847_9848 : H12AffineEnvironment.transform 17 97839 env9847 = env9848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env9847 == env9848) = true)

def env9849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,90337,8329,79859,278624,4524,4176,75787,620378,90170,525568,73771,2119536,90943]

theorem envBound9849 : H12AffineFastState.Bounded env9849 := by
  intro p hp
  have h : env9849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9810_9849 : H12AffineEnvironment.transform 23 90337 env9810 = env9849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9810 == env9849) = true)

theorem identity9849 : scanCanonicalize (H12AffineFastState.compose env9849 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9849 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,4605,262144,524288,8693,2097152,16741,525805,34,8329,22320,278624,4524,4176,18632,530329,249,525568,16616,2119536,1020]

theorem envBound9850 : H12AffineFastState.Bounded env9850 := by
  intro p hp
  have h : env9850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9849_9850 : H12AffineEnvironment.transform 15 24771 env9849 = env9850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9849 == env9850) = true)

def env9851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,8403,4605,262144,524288,8693,2097152,373,525805,34,8329,5920,262256,4524,4176,2264,530329,249,525568,248,2103136,1020]

theorem envBound9851 : H12AffineFastState.Bounded env9851 := by
  intro p hp
  have h : env9851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9850_9851 : H12AffineEnvironment.transform 13 16 env9850 = env9851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9850 == env9851) = true)

theorem identity9851 : scanCanonicalize (H12AffineFastState.compose env9851 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5201) := by decide +kernel

theorem selectedBound9851 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env9852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,8403,4605,262144,5201,8693,2097152,373,4540,34,8329,5920,262256,4524,4176,2264,968,249,4433,248,2103136,1020]

theorem envBound9852 : H12AffineFastState.Bounded env9852 := by
  intro p hp
  have h : env9852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9851_9852 : H12AffineEnvironment.transform 18 5201 env9851 = env9852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5201 env9851 == env9852) = true)

def env9853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,8402,4605,262144,524288,8693,2097152,372,525805,34,8329,5921,262257,4524,4176,2265,530329,249,525568,249,2103137,1020]

theorem envBound9853 : H12AffineFastState.Bounded env9853 := by
  intro p hp
  have h : env9853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9850_9853 : H12AffineEnvironment.transform 13 17 env9850 = env9853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9850 == env9853) = true)

theorem identity9853 : scanCanonicalize (H12AffineFastState.compose env9853 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9853 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9854 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8402,4097,262144,524288,8201,2097152,136,525329,34,8329,5853,262257,4176,4176,2265,530021,249,525564,249,2102941,512]

theorem envBound9854 : H12AffineFastState.Bounded env9854 := by
  intro p hp
  have h : env9854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9853_9854 : H12AffineEnvironment.transform 7 252 env9853 = env9854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9853 == env9854) = true)

theorem identity9854 : scanCanonicalize (H12AffineFastState.compose env9854 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529037) := by decide +kernel

theorem selectedBound9854 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9855 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8402,4097,262144,524288,8201,529037,136,525329,34,8329,5853,262257,4176,4176,2265,530021,249,525564,249,525328,512]

theorem envBound9855 : H12AffineFastState.Bounded env9855 := by
  intro p hp
  have h : env9855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9854_9855 : H12AffineEnvironment.transform 20 529037 env9854 = env9855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529037 env9854 == env9855) = true)

theorem identity9855 : scanCanonicalize (H12AffineFastState.compose env9855 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4660) := by decide +kernel

theorem selectedBound9855 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9856 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8402,4097,262144,4660,8201,185,136,5669,34,8329,5853,262257,4176,4176,2265,1105,249,5832,249,5668,512]

theorem envBound9856 : H12AffineFastState.Bounded env9856 := by
  intro p hp
  have h : env9856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9855_9856 : H12AffineEnvironment.transform 18 4660 env9855 = env9856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4660 env9855 == env9856) = true)

theorem identity9856 : scanCanonicalize (H12AffineFastState.compose env9856 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound9856 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9857 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,17,2274,2105,4097,262144,4660,2274,185,136,5669,34,2146,5853,262257,4176,4176,2265,1105,249,5832,249,5668,512]

theorem envBound9857 : H12AffineFastState.Bounded env9857 := by
  intro p hp
  have h : env9857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9856_9857 : H12AffineEnvironment.transform 12 2283 env9856 = env9857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env9856 == env9857) = true)

theorem identity9857 : scanCanonicalize (H12AffineFastState.compose env9857 (packedSelected [2,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 1190) := by decide +kernel

theorem selectedBound9857 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9858 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2283,17,2274,2105,4097,1190,4660,2274,185,136,5669,34,2146,5853,1239,4176,4176,2265,1105,249,5832,249,5668,512]

theorem envBound9858 : H12AffineFastState.Bounded env9858 := by
  intro p hp
  have h : env9858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9857_9858 : H12AffineEnvironment.transform 17 1190 env9857 = env9858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1190 env9857 == env9858) = true)

theorem identity9858 : scanCanonicalize (H12AffineFastState.compose env9858 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9858 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env9859 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,4096,2283,17,2274,2105,4097,163,4660,2274,185,136,4640,34,2146,4824,210,4176,4176,2265,84,249,4813,249,4641,512]

theorem envBound9859 : H12AffineFastState.Bounded env9859 := by
  intro p hp
  have h : env9859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9858_9859 : H12AffineEnvironment.transform 9 5 env9858 = env9859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9858 == env9859) = true)

theorem identity9859 : scanCanonicalize (H12AffineFastState.compose env9859 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2739) := by decide +kernel

theorem selectedBound9859 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9860 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,2739,2283,17,2274,2105,2738,163,2183,2274,185,136,2195,34,2146,2155,210,2787,2787,2265,84,249,2174,249,2194,512]

theorem envBound9860 : H12AffineFastState.Bounded env9860 := by
  intro p hp
  have h : env9860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9859_9860 : H12AffineEnvironment.transform 11 2739 env9859 = env9860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2739 env9859 == env9860) = true)

theorem identity9860 : scanCanonicalize (H12AffineFastState.compose env9860 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 200) := by decide +kernel

theorem selectedBound9860 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9861 : List Nat := [2,4,8,16,32,64,128,252,200,5,2048,2171,2283,17,2274,2105,2170,163,2183,2274,185,136,2195,34,2146,2155,210,2091,2091,2265,84,249,2174,249,2194,200]

theorem envBound9861 : H12AffineFastState.Bounded env9861 := by
  intro p hp
  have h : env9861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9860_9861 : H12AffineEnvironment.transform 8 200 env9860 = env9861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 200 env9860 == env9861) = true)

theorem identity9861 : scanCanonicalize (H12AffineFastState.compose env9861 (packedSelected [4,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound9861 : packedSelected [4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env9862 : List Nat := [2,4,8,16,32,64,128,252,200,5,11,112,224,17,233,50,113,163,140,233,185,136,152,34,105,96,210,32,32,210,84,249,117,249,153,200]

theorem envBound9862 : H12AffineFastState.Bounded env9862 := by
  intro p hp
  have h : env9862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9861_9862 : H12AffineEnvironment.transform 10 11 env9861 = env9862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env9861 == env9862) = true)

def env9863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,16777216,8329,79859,278625,4525,4177,16795883,17307579,16777434,525568,16793803,2119537,16778206]

theorem envBound9863 : H12AffineFastState.Bounded env9863 := by
  intro p hp
  have h : env9863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9809_9863 : H12AffineEnvironment.transform 26 278625 env9809 = env9863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 278625 env9809 == env9863) = true)

def env9864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,90336,8329,79859,278625,4525,4177,75787,620379,90170,525568,73771,2119537,90942]

theorem envBound9864 : H12AffineFastState.Bounded env9864 := by
  intro p hp
  have h : env9864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9863_9864 : H12AffineEnvironment.transform 23 90336 env9863 = env9864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9863 == env9864) = true)

theorem identity9864 : scanCanonicalize (H12AffineFastState.compose env9864 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9864 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24770,4605,262144,524288,8693,2097152,16741,525805,34,8329,22321,278625,4525,4177,18633,530329,248,525568,16617,2119537,1020]

theorem envBound9865 : H12AffineFastState.Bounded env9865 := by
  intro p hp
  have h : env9865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9864_9865 : H12AffineEnvironment.transform 15 24770 env9864 = env9865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9864 == env9865) = true)

def env9866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,8402,4605,262144,524288,8693,2097152,373,525805,34,8329,5921,262257,4525,4177,2265,530329,248,525568,249,2103137,1020]

theorem envBound9866 : H12AffineFastState.Bounded env9866 := by
  intro p hp
  have h : env9866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9865_9866 : H12AffineEnvironment.transform 13 16 env9865 = env9866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9865 == env9866) = true)

theorem identity9866 : scanCanonicalize (H12AffineFastState.compose env9866 (packedSelected [1,2,8,11,14,17,18,19,21] rootPS)) = affineNative (2^(18+1) ^^^ 5200) := by decide +kernel

theorem selectedBound9866 : packedSelected [1,2,8,11,14,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env9867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,8402,4605,262144,5200,8693,2097152,373,4541,34,8329,5921,262257,4525,4177,2265,969,248,4432,249,2103137,1020]

theorem envBound9867 : H12AffineFastState.Bounded env9867 := by
  intro p hp
  have h : env9867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9866_9867 : H12AffineEnvironment.transform 18 5200 env9866 = env9867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5200 env9866 == env9867) = true)

def env9868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,8403,4605,262144,524288,8693,2097152,372,525805,34,8329,5920,262256,4525,4177,2264,530329,248,525568,248,2103136,1020]

theorem envBound9868 : H12AffineFastState.Bounded env9868 := by
  intro p hp
  have h : env9868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9865_9868 : H12AffineEnvironment.transform 13 17 env9865 = env9868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9865 == env9868) = true)

theorem identity9868 : scanCanonicalize (H12AffineFastState.compose env9868 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9868 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9869 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8403,4097,262144,524288,8201,2097152,136,525329,34,8329,5852,262256,4177,4177,2264,530021,248,525564,248,2102940,512]

theorem envBound9869 : H12AffineFastState.Bounded env9869 := by
  intro p hp
  have h : env9869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9868_9869 : H12AffineEnvironment.transform 7 252 env9868 = env9869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9868 == env9869) = true)

theorem identity9869 : scanCanonicalize (H12AffineFastState.compose env9869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529037) := by decide +kernel

theorem selectedBound9869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9870 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8403,4097,262144,524288,8201,529037,136,525329,34,8329,5852,262256,4177,4177,2264,530021,248,525564,248,525329,512]

theorem envBound9870 : H12AffineFastState.Bounded env9870 := by
  intro p hp
  have h : env9870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9869_9870 : H12AffineEnvironment.transform 20 529037 env9869 = env9870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529037 env9869 == env9870) = true)

theorem identity9870 : scanCanonicalize (H12AffineFastState.compose env9870 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4661) := by decide +kernel

theorem selectedBound9870 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9871 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8403,4097,262144,4661,8201,184,136,5668,34,8329,5852,262256,4177,4177,2264,1104,248,5833,248,5668,512]

theorem envBound9871 : H12AffineFastState.Bounded env9871 := by
  intro p hp
  have h : env9871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9870_9871 : H12AffineEnvironment.transform 18 4661 env9870 = env9871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4661 env9870 == env9871) = true)

theorem identity9871 : scanCanonicalize (H12AffineFastState.compose env9871 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 13998) := by decide +kernel

theorem selectedBound9871 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9872 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,17,8201,8403,4097,13998,4661,8201,184,136,5668,34,8329,5852,14046,4177,4177,2264,1104,248,5833,248,5668,512]

theorem envBound9872 : H12AffineFastState.Bounded env9872 := by
  intro p hp
  have h : env9872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9871_9872 : H12AffineEnvironment.transform 17 13998 env9871 = env9872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13998 env9871 == env9872) = true)

theorem identity9872 : scanCanonicalize (H12AffineFastState.compose env9872 (packedSelected [2,13,14] rootPS)) = affineNative (2^(11+1) ^^^ 2786) := by decide +kernel

theorem selectedBound9872 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9873 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2786,8192,17,8201,8403,2787,11340,2263,8201,184,136,3270,34,8329,3134,11324,2739,2739,2264,1104,248,3115,248,3270,512]

theorem envBound9873 : H12AffineFastState.Bounded env9873 := by
  intro p hp
  have h : env9873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9872_9873 : H12AffineEnvironment.transform 11 2786 env9872 = env9873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2786 env9872 == env9873) = true)

theorem identity9873 : scanCanonicalize (H12AffineFastState.compose env9873 (packedSelected [2,6,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3311) := by decide +kernel

theorem selectedBound9873 : packedSelected [2,6,11,13,15] rootPS < 2^1333 := by decide +kernel

def env9874 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,2786,3311,17,3302,3132,2787,163,2263,3302,184,136,3270,34,3174,3134,211,2739,2739,2264,1104,248,3115,248,3270,512]

theorem envBound9874 : H12AffineFastState.Bounded env9874 := by
  intro p hp
  have h : env9874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9873_9874 : H12AffineEnvironment.transform 12 3311 env9873 = env9874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3311 env9873 == env9874) = true)

theorem identity9874 : scanCanonicalize (H12AffineFastState.compose env9874 (packedSelected [13,17] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound9874 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9875 : List Nat := [2,4,8,16,32,64,128,252,512,84,2048,2786,2235,17,2226,2152,2787,163,2263,2226,184,136,2194,34,2098,2154,211,2739,2739,2264,4,248,2175,248,2194,512]

theorem envBound9875 : H12AffineFastState.Bounded env9875 := by
  intro p hp
  have h : env9875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9874_9875 : H12AffineEnvironment.transform 9 84 env9874 = env9875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env9874 == env9875) = true)

theorem identity9875 : scanCanonicalize (H12AffineFastState.compose env9875 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound9875 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9876 : List Nat := [2,4,8,16,32,64,128,252,152,84,2048,2170,2235,17,2226,2152,2171,163,2263,2226,184,136,2194,34,2098,2154,211,2091,2091,2264,4,248,2175,248,2194,152]

theorem envBound9876 : H12AffineFastState.Bounded env9876 := by
  intro p hp
  have h : env9876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9875_9876 : H12AffineEnvironment.transform 8 152 env9875 = env9876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env9875 == env9876) = true)

def env9877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,90337,8329,79859,278625,4525,4177,75786,620378,90171,525568,73770,2119537,90943]

theorem envBound9877 : H12AffineFastState.Bounded env9877 := by
  intro p hp
  have h : env9877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9863_9877 : H12AffineEnvironment.transform 23 90337 env9863 = env9877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9863 == env9877) = true)

theorem identity9877 : scanCanonicalize (H12AffineFastState.compose env9877 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound9877 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9878 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16537,525329,90337,8329,79375,278625,4177,4177,75786,620198,90171,525564,73770,2119309,90819]

theorem envBound9878 : H12AffineFastState.Bounded env9878 := by
  intro p hp
  have h : env9878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9877_9878 : H12AffineEnvironment.transform 7 252 env9877 = env9878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env9877 == env9878) = true)

def env9879 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16481,525329,90137,8305,79375,278625,4177,4177,75786,620126,90171,525316,73770,2119285,90683]

theorem envBound9879 : H12AffineFastState.Bounded env9879 := by
  intro p hp
  have h : env9879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9878_9879 : H12AffineEnvironment.transform 6 120 env9878 = env9879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9878 == env9879) = true)

theorem identity9879 : scanCanonicalize (H12AffineFastState.compose env9879 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 619087) := by decide +kernel

theorem selectedBound9879 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9880 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619087,16481,525329,90137,8305,79375,278625,4177,4177,75786,620126,90171,525316,73770,599098,90683]

theorem envBound9880 : H12AffineFastState.Bounded env9880 := by
  intro p hp
  have h : env9880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9879_9880 : H12AffineEnvironment.transform 20 619087 env9879 = env9880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619087 env9879 == env9880) = true)

def env9881 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619039,16433,525329,90137,8225,79375,278577,4097,4097,75786,620046,90171,525316,73770,599098,90683]

theorem envBound9881 : H12AffineFastState.Bounded env9881 := by
  intro p hp
  have h : env9881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9880_9881 : H12AffineEnvironment.transform 5 16 env9880 = env9881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9880 == env9881) = true)

theorem identity9881 : scanCanonicalize (H12AffineFastState.compose env9881 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 281649) := by decide +kernel

theorem selectedBound9881 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9882 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,281649,8201,343598,16433,280608,90137,8225,79375,278577,4097,4097,75786,342591,90171,280629,73770,354315,90683]

theorem envBound9882 : H12AffineFastState.Bounded env9882 := by
  intro p hp
  have h : env9882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9881_9882 : H12AffineEnvironment.transform 18 281649 env9881 = env9882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 281649 env9881 == env9882) = true)

theorem identity9882 : scanCanonicalize (H12AffineFastState.compose env9882 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97839) := by decide +kernel

theorem selectedBound9882 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9883 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,8201,65536,4097,97839,78366,8201,16385,16433,79375,90137,8225,79375,81438,4097,4097,75786,17424,90171,79386,73770,5668,90683]

theorem envBound9883 : H12AffineFastState.Bounded env9883 := by
  intro p hp
  have h : env9883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9882_9883 : H12AffineEnvironment.transform 17 97839 env9882 = env9883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97839 env9882 == env9883) = true)

def env9884 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,619038,16432,525329,90137,8224,79375,278576,4096,4096,75786,620047,90171,525316,73770,599098,90683]

theorem envBound9884 : H12AffineFastState.Bounded env9884 := by
  intro p hp
  have h : env9884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9880_9884 : H12AffineEnvironment.transform 5 17 env9880 = env9884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9880 == env9884) = true)

theorem identity9884 : scanCanonicalize (H12AffineFastState.compose env9884 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 97838) := by decide +kernel

theorem selectedBound9884 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env9885 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,97838,524288,8201,619038,16432,525329,90137,8224,79375,81438,4096,4096,75786,620047,90171,525316,73770,599098,90683]

theorem envBound9885 : H12AffineFastState.Bounded env9885 := by
  intro p hp
  have h : env9885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9884_9885 : H12AffineEnvironment.transform 17 97838 env9884 = env9885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97838 env9884 == env9885) = true)

theorem identity9885 : scanCanonicalize (H12AffineFastState.compose env9885 (packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS)) = affineNative (2^(18+1) ^^^ 94735) := by decide +kernel

theorem selectedBound9885 : packedSelected [1,3,4,7,9,11,13,17,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9886 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,65536,4097,97838,94735,8201,17,16432,95774,90137,8224,79375,81438,4096,4096,75786,1024,90171,95755,73770,22069,90683]

theorem envBound9886 : H12AffineFastState.Bounded env9886 := by
  intro p hp
  have h : env9886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9885_9886 : H12AffineEnvironment.transform 18 94735 env9885 = env9886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 94735 env9885 == env9886) = true)

theorem identity9886 : scanCanonicalize (H12AffineFastState.compose env9886 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound9886 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9887 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,8201,24635,4097,7701,4660,8201,17,16432,5669,34,8224,22068,24101,4096,4096,18481,1024,0,5680,16401,22069,512]

theorem envBound9887 : H12AffineFastState.Bounded env9887 := by
  intro p hp
  have h : env9887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9886_9887 : H12AffineEnvironment.transform 15 24635 env9886 = env9887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env9886 == env9887) = true)

theorem identity9887 : scanCanonicalize (H12AffineFastState.compose env9887 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2586) := by decide +kernel

theorem selectedBound9887 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9888 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,2586,8201,10785,4097,7701,4660,8201,17,2602,5669,34,8224,7214,5183,4096,4096,555,1024,0,5680,2571,7215,512]

theorem envBound9888 : H12AffineFastState.Bounded env9888 := by
  intro p hp
  have h : env9888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9887_9888 : H12AffineEnvironment.transform 13 2586 env9887 = env9888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2586 env9887 == env9888) = true)

theorem identity9888 : scanCanonicalize (H12AffineFastState.compose env9888 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound9888 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9889 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,4096,8192,16,8201,8235,4097,5151,4660,8201,17,32,5669,34,8224,5668,5183,4096,4096,555,1024,0,5680,1,5669,512]

theorem envBound9889 : H12AffineFastState.Bounded env9889 := by
  intro p hp
  have h : env9889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9888_9889 : H12AffineEnvironment.transform 10 522 env9888 = env9889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env9888 == env9889) = true)

theorem identity9889 : scanCanonicalize (H12AffineFastState.compose env9889 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound9889 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9890 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,4096,1063,16,1070,1036,4097,5151,4660,1070,17,32,5669,34,1031,5668,5183,4096,4096,555,1024,0,5680,1,5669,512]

theorem envBound9890 : H12AffineFastState.Bounded env9890 := by
  intro p hp
  have h : env9890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9889_9890 : H12AffineEnvironment.transform 12 1063 env9889 = env9890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env9889 == env9890) = true)

theorem identity9890 : scanCanonicalize (H12AffineFastState.compose env9890 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9890 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9891 : List Nat := [2,4,8,16,1,17,8,4,512,1024,522,4096,1030,16,1039,1036,4097,5151,4629,1039,17,1,5636,3,1031,5637,5150,4096,4096,522,1024,0,5649,1,5636,512]

theorem envBound9891 : H12AffineFastState.Bounded env9891 := by
  intro p hp
  have h : env9891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9890_9891 : H12AffineEnvironment.transform 4 1 env9890 = env9891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9890 == env9891) = true)

theorem identity9891 : scanCanonicalize (H12AffineFastState.compose env9891 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound9891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9892 : List Nat := [2,4,8,16,1,17,8,4,512,1024,522,26,1030,16,1039,1036,27,1029,527,1039,17,1,1566,3,1031,1567,1028,26,26,522,1024,0,1547,1,1566,512]

theorem envBound9892 : H12AffineFastState.Bounded env9892 := by
  intro p hp
  have h : env9892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9891_9892 : H12AffineEnvironment.transform 11 26 env9891 = env9892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env9891 == env9892) = true)

theorem identity9892 : scanCanonicalize (H12AffineFastState.compose env9892 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound9892 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env9893 : List Nat := [2,4,8,16,1,17,8,4,1,1024,11,26,1030,16,1039,1036,27,1029,14,1039,17,1,1055,3,1031,1054,1028,26,26,11,1024,0,1034,1,1055,1]

theorem envBound9893 : H12AffineFastState.Bounded env9893 := by
  intro p hp
  have h : env9893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9892_9893 : H12AffineEnvironment.transform 8 1 env9892 = env9893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env9892 == env9893) = true)

theorem identity9893 : scanCanonicalize (H12AffineFastState.compose env9893 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound9893 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9894 : List Nat := [2,4,8,16,1,17,8,4,1,14,11,26,8,16,1,2,27,11,14,1,17,1,17,3,9,16,10,26,26,11,14,0,4,1,17,1]

theorem envBound9894 : H12AffineFastState.Bounded env9894 := by
  intro p hp
  have h : env9894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9893_9894 : H12AffineEnvironment.transform 9 14 env9893 = env9894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env9893 == env9894) = true)

theorem identity9894 : scanCanonicalize (H12AffineFastState.compose env9894 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9895 : List Nat := [2,4,8,11,1,10,8,4,1,14,11,1,8,11,1,2,0,11,14,1,10,1,10,3,9,11,10,1,1,11,14,0,4,1,10,1]

theorem envBound9895 : H12AffineFastState.Bounded env9895 := by
  intro p hp
  have h : env9895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9894_9895 : H12AffineEnvironment.transform 3 11 env9894 = env9895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9894 == env9895) = true)

def env9896 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,2097152,16480,525329,90136,8304,79375,278625,4177,4177,75786,620127,90171,525317,73770,2119284,90682]

theorem envBound9896 : H12AffineFastState.Bounded env9896 := by
  intro p hp
  have h : env9896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9878_9896 : H12AffineEnvironment.transform 6 121 env9878 = env9896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9878 == env9896) = true)

theorem identity9896 : scanCanonicalize (H12AffineFastState.compose env9896 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545381) := by decide +kernel

theorem selectedBound9896 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9897 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545381,16480,525329,90136,8304,79375,278625,4177,4177,75786,620127,90171,525317,73770,525329,90682]

theorem envBound9897 : H12AffineFastState.Bounded env9897 := by
  intro p hp
  have h : env9897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9896_9897 : H12AffineEnvironment.transform 20 545381 env9896 = env9897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545381 env9896 == env9897) = true)

def env9898 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545333,16432,525329,90136,8224,79375,278577,4097,4097,75786,620047,90171,525317,73770,525329,90682]

theorem envBound9898 : H12AffineFastState.Bounded env9898 := by
  intro p hp
  have h : env9898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9897_9898 : H12AffineEnvironment.transform 5 16 env9897 = env9898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9897 == env9898) = true)

theorem identity9898 : scanCanonicalize (H12AffineFastState.compose env9898 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 338954) := by decide +kernel

theorem selectedBound9898 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9899 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,338954,8201,359999,16432,337947,90136,8224,79375,278577,4097,4097,75786,285189,90171,337935,73770,337947,90682]

theorem envBound9899 : H12AffineFastState.Bounded env9899 := by
  intro p hp
  have h : env9899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9898_9899 : H12AffineEnvironment.transform 18 338954 env9898 = env9899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 338954 env9898 == env9899) = true)

theorem identity9899 : scanCanonicalize (H12AffineFastState.compose env9899 (packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 24068) := by decide +kernel

theorem selectedBound9899 : packedSelected [4,5,7,8,9,10,11,18,19,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env9900 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,8201,65536,4097,24068,94734,8201,73787,16432,95775,90136,8224,79375,7733,4097,4097,75786,1025,90171,95755,73770,95775,90682]

theorem envBound9900 : H12AffineFastState.Bounded env9900 := by
  intro p hp
  have h : env9900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9899_9900 : H12AffineEnvironment.transform 17 24068 env9899 = env9900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24068 env9899 == env9900) = true)

def env9901 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,545332,16433,525329,90136,8225,79375,278576,4096,4096,75786,620046,90171,525317,73770,525329,90682]

theorem envBound9901 : H12AffineFastState.Bounded env9901 := by
  intro p hp
  have h : env9901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9897_9901 : H12AffineEnvironment.transform 5 17 env9897 = env9901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9897 == env9901) = true)

theorem identity9901 : scanCanonicalize (H12AffineFastState.compose env9901 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound9901 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9902 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,524288,8201,545332,16433,525329,90136,8225,79375,24100,4096,4096,75786,620046,90171,525317,73770,525329,90682]

theorem envBound9902 : H12AffineFastState.Bounded env9902 := by
  intro p hp
  have h : env9902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9901_9902 : H12AffineEnvironment.transform 17 7700 env9901 = env9902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env9901 == env9902) = true)

theorem identity9902 : scanCanonicalize (H12AffineFastState.compose env9902 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78367) := by decide +kernel

theorem selectedBound9902 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9903 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,78367,8201,90155,16433,79374,90136,8225,79375,24100,4096,4096,75786,17425,90171,79386,73770,79374,90682]

theorem envBound9903 : H12AffineFastState.Bounded env9903 := by
  intro p hp
  have h : env9903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9902_9903 : H12AffineEnvironment.transform 18 78367 env9902 = env9903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78367 env9902 == env9903) = true)

theorem identity9903 : scanCanonicalize (H12AffineFastState.compose env9903 (packedSelected [3,4,5,9,12,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9903 : packedSelected [3,4,5,9,12,18,19] rootPS < 2^1333 := by decide +kernel

def env9904 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,16,8201,65536,4097,7700,78367,8201,73787,33,79374,73736,8225,79375,7732,4096,4096,75786,1025,73771,79386,73770,79374,74282]

theorem envBound9904 : H12AffineFastState.Bounded env9904 := by
  intro p hp
  have h : env9904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9903_9904 : H12AffineEnvironment.transform 13 16 env9903 = env9904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9903 == env9904) = true)

theorem identity9904 : scanCanonicalize (H12AffineFastState.compose env9904 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound9904 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9905 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,4096,8192,16,8201,65536,4097,5669,78367,8201,73787,33,79374,73736,8225,79375,5637,4096,4096,73787,1025,73771,79386,73770,79374,74282]

theorem envBound9905 : H12AffineFastState.Bounded env9905 := by
  intro p hp
  have h : env9905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9904_9905 : H12AffineEnvironment.transform 10 49 env9904 = env9905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env9904 == env9905) = true)

theorem identity9905 : scanCanonicalize (H12AffineFastState.compose env9905 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound9905 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9906 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,4096,25,16,16,65536,4097,5669,70150,16,65570,33,71191,65553,56,71190,5637,4096,4096,65570,1025,65586,71171,65587,71191,66099]

theorem envBound9906 : H12AffineFastState.Bounded env9906 := by
  intro p hp
  have h : env9906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9905_9906 : H12AffineEnvironment.transform 12 25 env9905 = env9906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env9905 == env9906) = true)

theorem identity9906 : scanCanonicalize (H12AffineFastState.compose env9906 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound9906 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9907 : List Nat := [2,4,8,16,32,17,40,5,512,1024,49,1028,25,16,16,65536,1029,545,67074,16,65570,33,66067,65553,56,66066,513,1028,1028,65570,1025,65586,66055,65587,66067,66099]

theorem envBound9907 : H12AffineFastState.Bounded env9907 := by
  intro p hp
  have h : env9907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9906_9907 : H12AffineEnvironment.transform 11 1028 env9906 = env9907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env9906 == env9907) = true)

theorem identity9907 : scanCanonicalize (H12AffineFastState.compose env9907 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound9907 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env9908 : List Nat := [2,4,8,16,32,17,40,5,58,1024,49,1028,25,16,16,65536,1029,27,66616,16,65570,33,65577,65553,56,65576,59,1028,1028,65570,1025,65586,65597,65587,65577,65545]

theorem envBound9908 : H12AffineFastState.Bounded env9908 := by
  intro p hp
  have h : env9908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9907_9908 : H12AffineEnvironment.transform 8 58 env9907 = env9908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env9907 == env9908) = true)

theorem identity9908 : scanCanonicalize (H12AffineFastState.compose env9908 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 1036) := by decide +kernel

theorem selectedBound9908 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9909 : List Nat := [2,4,8,16,32,17,40,5,58,1024,49,1028,25,16,16,1036,1029,27,52,16,1070,33,1061,1053,56,1060,59,1028,1028,1070,1025,1086,1073,1087,1061,1029]

theorem envBound9909 : H12AffineFastState.Bounded env9909 := by
  intro p hp
  have h : env9909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9908_9909 : H12AffineEnvironment.transform 15 1036 env9908 = env9909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1036 env9908 == env9909) = true)

theorem identity9909 : scanCanonicalize (H12AffineFastState.compose env9909 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound9909 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9910 : List Nat := [2,4,8,16,32,17,40,5,58,14,49,10,25,16,16,2,11,27,52,16,32,33,43,19,56,42,59,10,10,32,15,48,63,49,43,11]

theorem envBound9910 : H12AffineFastState.Bounded env9910 := by
  intro p hp
  have h : env9910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9909_9910 : H12AffineEnvironment.transform 9 14 env9909 = env9910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env9909 == env9910) = true)

theorem identity9910 : scanCanonicalize (H12AffineFastState.compose env9910 (packedSelected [0,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9910 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env9911 : List Nat := [2,4,8,1,32,0,40,5,43,14,32,10,8,1,1,2,11,10,37,1,32,33,43,2,41,42,42,10,10,32,15,33,46,32,43,11]

theorem envBound9911 : H12AffineFastState.Bounded env9911 := by
  intro p hp
  have h : env9911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9910_9911 : H12AffineEnvironment.transform 3 1 env9910 = env9911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9910 == env9911) = true)

def env9912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525568,6531129661,34359738368,59279182]

theorem envBound9912 : H12AffineFastState.Bounded env9912 := by
  intro p hp
  have h : env9912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3_9912 : H12AffineEnvironment.transform 19 32769 env3 = env9912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32769 env3 == env9912) = true)

theorem identity9912 : scanCanonicalize (H12AffineFastState.compose env9912 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9912 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env9913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525568,6531129661,34359738368,25733062]

theorem envBound9913 : H12AffineFastState.Bounded env9913 := by
  intro p hp
  have h : env9913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9912_9913 : H12AffineEnvironment.transform 24 8328 env9912 = env9913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9912 == env9913) = true)

theorem identity9913 : scanCanonicalize (H12AffineFastState.compose env9913 (packedSelected [6,25] rootPS)) = affineNative (2^(30+1) ^^^ 92374096) := by decide +kernel

theorem selectedBound9913 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374096,4294967296,525568,4308116845,34359738368,25733062]

theorem envBound9914 : H12AffineFastState.Bounded env9914 := by
  intro p hp
  have h : env9914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9913_9914 : H12AffineEnvironment.transform 30 92374096 env9913 = env9914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 92374096 env9913 == env9914) = true)

def env9915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374096,4294967296,525568,4308116845,620851224,25733062]

theorem envBound9915 : H12AffineFastState.Bounded env9915 := by
  intro p hp
  have h : env9915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9914_9915 : H12AffineEnvironment.transform 34 620851224 env9914 = env9915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 620851224 env9914 == env9915) = true)

def env9916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,536870912,1073741824,92374096,4294967296,525568,4308116845,620851224,25733062]

theorem envBound9916 : H12AffineFastState.Bounded env9916 := by
  intro p hp
  have h : env9916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9915_9916 : H12AffineEnvironment.transform 27 19497100 env9915 = env9916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497100 env9915 == env9916) = true)

def env9917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374096,4294967296,525568,4308116845,27337992,25733062]

theorem envBound9917 : H12AffineFastState.Bounded env9917 := by
  intro p hp
  have h : env9917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9916_9917 : H12AffineEnvironment.transform 28 77616400 env9916 = env9917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env9916 == env9917) = true)

def env9918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound9918 : H12AffineFastState.Bounded env9918 := by
  intro p hp
  have h : env9918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9917_9918 : H12AffineEnvironment.transform 31 145662400 env9917 = env9918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env9917 == env9918) = true)

def env9919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound9919 : H12AffineFastState.Bounded env9919 := by
  intro p hp
  have h : env9919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9918_9919 : H12AffineEnvironment.transform 29 155254784 env9918 = env9919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env9918 == env9919) = true)

def env9920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound9920 : H12AffineFastState.Bounded env9920 := by
  intro p hp
  have h : env9920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9919_9920 : H12AffineEnvironment.transform 25 64 env9919 = env9920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env9919 == env9920) = true)

def env9921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound9921 : H12AffineFastState.Bounded env9921 := by
  intro p hp
  have h : env9921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9920_9921 : H12AffineEnvironment.transform 26 30393344 env9920 = env9921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env9920 == env9921) = true)

def env9922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound9922 : H12AffineFastState.Bounded env9922 := by
  intro p hp
  have h : env9922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9921_9922 : H12AffineEnvironment.transform 18 1024 env9921 = env9922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9921 == env9922) = true)

theorem identity9922 : scanCanonicalize (H12AffineFastState.compose env9922 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound9922 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env9923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188616,8328,64,15115592,57796,10507600,8830976,10543448,4194440,256,8430053,8405056,10602126]

theorem envBound9923 : H12AffineFastState.Bounded env9923 := by
  intro p hp
  have h : env9923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9922_9923 : H12AffineEnvironment.transform 23 2188616 env9922 = env9923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env9922 == env9923) = true)

def env9924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62660,2188616,8328,64,6705548,57796,2138516,406724,2102684,4194440,256,21793,46212,2175562]

theorem envBound9924 : H12AffineFastState.Bounded env9924 := by
  intro p hp
  have h : env9924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9923_9924 : H12AffineEnvironment.transform 22 62660 env9923 = env9924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env9923 == env9924) = true)

def env9925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62660,2188616,8328,64,158028,57796,2138516,406724,2102684,2373704,256,21793,46212,2175562]

theorem envBound9925 : H12AffineFastState.Bounded env9925 := by
  intro p hp
  have h : env9925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9924_9925 : H12AffineEnvironment.transform 21 2373824 env9924 = env9925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env9924 == env9925) = true)

theorem identity9925 : scanCanonicalize (H12AffineFastState.compose env9925 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound9925 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env9926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,2373824,16,2188616,8328,64,158028,5392,2118976,406724,2102684,2373704,256,21793,16464,2175562]

theorem envBound9926 : H12AffineFastState.Bounded env9926 := by
  intro p hp
  have h : env9926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9925_9926 : H12AffineEnvironment.transform 14 29908 env9925 = env9926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env9925 == env9926) = true)

def env9927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,2373824,16,2175048,8328,64,146508,5392,2097216,406724,2102684,2373704,256,33,5456,2175562]

theorem envBound9927 : H12AffineFastState.Bounded env9927 := by
  intro p hp
  have h : env9927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9926_9927 : H12AffineEnvironment.transform 13 5376 env9926 = env9927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env9926 == env9927) = true)

theorem identity9927 : scanCanonicalize (H12AffineFastState.compose env9927 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound9927 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,78018,329730,16,138,8328,64,146508,5392,77954,406724,75102,329866,256,33,5456,648]

theorem envBound9928 : H12AffineFastState.Bounded env9928 := by
  intro p hp
  have h : env9928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9927_9928 : H12AffineEnvironment.transform 20 78018 env9927 = env9928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env9927 == env9928) = true)

theorem identity9928 : scanCanonicalize (H12AffineFastState.compose env9928 (packedSelected [2,6,7,9,11,18,20,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound9928 : packedSelected [2,6,7,9,11,18,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env9929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,67618,1024,8661,78018,32,16,138,8328,64,146508,5392,77954,212198,75102,168,256,33,5456,648]

theorem envBound9929 : H12AffineFastState.Bounded env9929 := by
  intro p hp
  have h : env9929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9928_9929 : H12AffineEnvironment.transform 17 67618 env9928 = env9929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env9928 == env9929) = true)

theorem identity9929 : scanCanonicalize (H12AffineFastState.compose env9929 (packedSelected [3,4,5,6,7,8,9,10,11,14,16,18,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5325) := by decide +kernel

theorem selectedBound9929 : packedSelected [3,4,5,6,7,8,9,10,11,14,16,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env9930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5325,67618,1024,8661,78018,32,16,138,8328,64,10369,5392,77954,75819,75102,168,256,33,5456,648]

theorem envBound9930 : H12AffineFastState.Bounded env9930 := by
  intro p hp
  have h : env9930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9929_9930 : H12AffineEnvironment.transform 16 5325 env9929 = env9930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5325 env9929 == env9930) = true)

theorem identity9930 : scanCanonicalize (H12AffineFastState.compose env9930 (packedSelected [0,1,3,5,6,8,10,11,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound9930 : packedSelected [0,1,3,5,6,8,10,11,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8662,5325,10740,1024,8661,4372,32,16,138,8328,64,10369,5392,4436,2557,1160,168,256,33,5456,648]

theorem envBound9931 : H12AffineFastState.Bounded env9931 := by
  intro p hp
  have h : env9931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9930_9931 : H12AffineEnvironment.transform 15 8662 env9930 = env9931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env9930 == env9931) = true)

theorem identity9931 : scanCanonicalize (H12AffineFastState.compose env9931 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound9931 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8543,5188,10621,1024,8540,4372,32,16,3,8193,64,10248,5392,4436,2420,1025,33,256,33,5456,513]

theorem envBound9932 : H12AffineFastState.Bounded env9932 := by
  intro p hp
  have h : env9932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9931_9932 : H12AffineEnvironment.transform 6 9 env9931 = env9932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9931 == env9932) = true)

theorem identity9932 : scanCanonicalize (H12AffineFastState.compose env9932 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9932 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9933 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,5205,8200,8202,5188,10280,1024,8201,4161,32,16,3,8193,64,10248,5189,4097,2081,1025,33,85,33,5125,513]

theorem envBound9933 : H12AffineFastState.Bounded env9933 := by
  intro p hp
  have h : env9933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9932_9933 : H12AffineEnvironment.transform 7 85 env9932 = env9933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9932 == env9933) = true)

theorem identity9933 : scanCanonicalize (H12AffineFastState.compose env9933 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9933 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env9934 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,8200,8202,5141,10280,1024,8201,4112,32,16,3,8193,17,10248,5140,4097,2081,1025,33,4,33,5125,513]

theorem envBound9934 : H12AffineFastState.Bounded env9934 := by
  intro p hp
  have h : env9934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9933_9934 : H12AffineEnvironment.transform 5 17 env9933 = env9934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9933 == env9934) = true)

theorem identity9934 : scanCanonicalize (H12AffineFastState.compose env9934 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound9934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9935 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,41,5124,33,35,5141,2049,1024,32,4112,32,16,3,40,17,2081,5140,4097,2081,1025,33,4,33,5125,513]

theorem envBound9935 : H12AffineFastState.Bounded env9935 := by
  intro p hp
  have h : env9935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9934_9935 : H12AffineEnvironment.transform 12 41 env9934 = env9935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env9934 == env9935) = true)

theorem identity9935 : scanCanonicalize (H12AffineFastState.compose env9935 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound9935 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9936 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1045,4096,41,5124,33,35,5141,1044,1024,32,4112,32,16,3,40,17,1076,5140,4097,1076,1025,33,4,33,5125,513]

theorem envBound9936 : H12AffineFastState.Bounded env9936 := by
  intro p hp
  have h : env9936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9935_9936 : H12AffineEnvironment.transform 10 1045 env9935 = env9936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env9935 == env9936) = true)

theorem identity9936 : scanCanonicalize (H12AffineFastState.compose env9936 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9936 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env9937 : List Nat := [2,4,8,16,32,17,9,4,33,1024,1045,4096,41,5124,33,35,5141,1044,1024,32,4112,32,16,3,40,17,1076,5140,4097,1076,1025,33,4,33,5125,32]

theorem envBound9937 : H12AffineFastState.Bounded env9937 := by
  intro p hp
  have h : env9937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9936_9937 : H12AffineEnvironment.transform 8 33 env9936 = env9937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9936 == env9937) = true)

def env9938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,2373824,16,2175049,8328,64,146509,5392,2097217,406724,2102684,2373704,256,32,5457,2175562]

theorem envBound9938 : H12AffineFastState.Bounded env9938 := by
  intro p hp
  have h : env9938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9926_9938 : H12AffineEnvironment.transform 13 5377 env9926 = env9938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env9926 == env9938) = true)

theorem identity9938 : scanCanonicalize (H12AffineFastState.compose env9938 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound9938 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,77899,329867,16,2,8328,64,146509,5392,77834,406724,75223,329731,256,32,5457,513]

theorem envBound9939 : H12AffineFastState.Bounded env9939 := by
  intro p hp
  have h : env9939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9938_9939 : H12AffineEnvironment.transform 20 77899 env9938 = env9939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env9938 == env9939) = true)

def env9940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,329731,16,2,8192,64,146509,5392,77834,406604,75103,329731,256,32,5457,513]

theorem envBound9940 : H12AffineFastState.Bounded env9940 := by
  intro p hp
  have h : env9940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9939_9940 : H12AffineEnvironment.transform 6 8 env9939 = env9940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9939 == env9940) = true)

theorem identity9940 : scanCanonicalize (H12AffineFastState.compose env9940 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound9940 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,131072,262144,1024,8540,5457,273689,16,2,8192,64,146509,5392,5392,406604,69,273689,256,32,5457,513]

theorem envBound9941 : H12AffineFastState.Bounded env9941 := by
  intro p hp
  have h : env9941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9940_9941 : H12AffineEnvironment.transform 15 9498 env9940 = env9941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env9940 == env9941) = true)

theorem identity9941 : scanCanonicalize (H12AffineFastState.compose env9941 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound9941 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env9942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,4096,262144,1024,8540,5457,273689,16,2,8192,64,11341,5392,5392,271436,69,273689,256,32,5457,513]

theorem envBound9942 : H12AffineFastState.Bounded env9942 := by
  intro p hp
  have h : env9942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9941_9942 : H12AffineEnvironment.transform 16 4096 env9941 = env9942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env9941 == env9942) = true)

theorem identity9942 : scanCanonicalize (H12AffineFastState.compose env9942 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound9942 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,4096,11576,1024,8540,5457,33,16,2,8192,64,11341,5392,5392,2420,69,33,256,32,5457,513]

theorem envBound9943 : H12AffineFastState.Bounded env9943 := by
  intro p hp
  have h : env9943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9942_9943 : H12AffineEnvironment.transform 17 11576 env9942 = env9943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env9942 == env9943) = true)

theorem identity9943 : scanCanonicalize (H12AffineFastState.compose env9943 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound9943 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env9944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5377,1124,35,4096,2049,1024,1125,5457,33,16,2,1337,64,2420,5392,5392,2420,69,33,256,32,5457,513]

theorem envBound9944 : H12AffineFastState.Bounded env9944 := by
  intro p hp
  have h : env9944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9943_9944 : H12AffineEnvironment.transform 12 1337 env9943 = env9944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env9943 == env9944) = true)

theorem identity9944 : scanCanonicalize (H12AffineFastState.compose env9944 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9944 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env9945 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,1132,5204,1124,35,4096,2049,1024,1125,5124,33,16,2,1132,64,2081,5189,5189,2081,69,33,85,32,5124,513]

theorem envBound9945 : H12AffineFastState.Bounded env9945 := by
  intro p hp
  have h : env9945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9944_9945 : H12AffineEnvironment.transform 7 85 env9944 = env9945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9944 == env9945) = true)

theorem identity9945 : scanCanonicalize (H12AffineFastState.compose env9945 (packedSelected [1,2,3,4,5,6,8,9,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9945 : packedSelected [1,2,3,4,5,6,8,9,18] rootPS < 2^1333 := by decide +kernel

def env9946 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,1101,5204,1093,2,4096,2049,1024,1092,5124,0,16,2,1101,64,2048,5189,5189,2048,69,0,85,1,5124,513]

theorem envBound9946 : H12AffineFastState.Bounded env9946 := by
  intro p hp
  have h : env9946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9945_9946 : H12AffineEnvironment.transform 4 1 env9945 = env9946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9945 == env9946) = true)

theorem identity9946 : scanCanonicalize (H12AffineFastState.compose env9946 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound9946 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env9947 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,3156,1101,2048,1093,2,3156,2049,1024,1092,2128,0,16,2,1101,64,2048,2065,2065,2048,69,0,85,1,2128,513]

theorem envBound9947 : H12AffineFastState.Bounded env9947 := by
  intro p hp
  have h : env9947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9946_9947 : H12AffineEnvironment.transform 11 3156 env9946 = env9947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env9946 == env9947) = true)

theorem identity9947 : scanCanonicalize (H12AffineFastState.compose env9947 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound9947 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env9948 : List Nat := [2,4,8,16,1,64,8,85,512,21,2048,2113,88,2048,80,2,2113,2049,21,81,2128,0,16,2,88,64,2048,2065,2065,2048,69,0,85,1,2128,513]

theorem envBound9948 : H12AffineFastState.Bounded env9948 := by
  intro p hp
  have h : env9948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9947_9948 : H12AffineEnvironment.transform 9 21 env9947 = env9948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env9947 == env9948) = true)

theorem identity9948 : scanCanonicalize (H12AffineFastState.compose env9948 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound9948 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9949 : List Nat := [2,4,8,16,1,64,8,85,512,21,17,80,88,17,80,2,80,16,21,81,65,0,16,2,88,64,17,0,0,17,69,0,85,1,65,513]

theorem envBound9949 : H12AffineFastState.Bounded env9949 := by
  intro p hp
  have h : env9949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9948_9949 : H12AffineEnvironment.transform 10 17 env9948 = env9949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env9948 == env9949) = true)

theorem identity9949 : scanCanonicalize (H12AffineFastState.compose env9949 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound9949 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9950 : List Nat := [2,4,8,16,1,64,8,85,64,21,17,80,88,17,80,2,80,16,21,81,65,0,16,2,88,64,17,0,0,17,69,0,85,1,65,65]

theorem envBound9950 : H12AffineFastState.Bounded env9950 := by
  intro p hp
  have h : env9950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9949_9950 : H12AffineEnvironment.transform 8 64 env9949 = env9950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env9949 == env9950) = true)

theorem identity9950 : scanCanonicalize (H12AffineFastState.compose env9950 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9950 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9951 : List Nat := [2,4,8,1,1,64,8,68,64,4,0,65,73,0,65,2,65,1,4,64,65,0,1,2,73,64,0,0,0,0,69,0,68,1,65,65]

theorem envBound9951 : H12AffineFastState.Bounded env9951 := by
  intro p hp
  have h : env9951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9950_9951 : H12AffineEnvironment.transform 3 1 env9950 = env9951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9950 == env9951) = true)

def env9952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,329730,16,2,8193,64,146509,5392,77834,406605,75102,329731,256,32,5457,513]

theorem envBound9952 : H12AffineFastState.Bounded env9952 := by
  intro p hp
  have h : env9952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9939_9952 : H12AffineEnvironment.transform 6 9 env9939 = env9952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9939 == env9952) = true)

theorem identity9952 : scanCanonicalize (H12AffineFastState.compose env9952 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound9952 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env9953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70726,262144,1024,8541,77899,329730,16,2,8193,64,75787,5392,77834,335883,75102,329731,256,32,5457,513]

theorem envBound9953 : H12AffineFastState.Bounded env9953 := by
  intro p hp
  have h : env9953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9952_9953 : H12AffineEnvironment.transform 16 70726 env9952 = env9953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env9952 == env9953) = true)

theorem identity9953 : scanCanonicalize (H12AffineFastState.compose env9953 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound9953 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env9954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70726,10281,1024,8541,77899,73771,16,2,8193,64,75787,5392,77834,67618,75102,73770,256,32,5457,513]

theorem envBound9954 : H12AffineFastState.Bounded env9954 := by
  intro p hp
  have h : env9954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9953_9954 : H12AffineEnvironment.transform 17 10281 env9953 = env9954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env9953 == env9954) = true)

theorem identity9954 : scanCanonicalize (H12AffineFastState.compose env9954 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound9954 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,1094,4096,10281,1024,8541,13325,9325,16,2,8193,64,11341,5392,13388,3172,8472,9324,256,32,5457,513]

theorem envBound9955 : H12AffineFastState.Bounded env9955 := by
  intro p hp
  have h : env9955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9954_9955 : H12AffineEnvironment.transform 15 1094 env9954 = env9955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env9954 == env9955) = true)

theorem identity9955 : scanCanonicalize (H12AffineFastState.compose env9955 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound9955 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env9956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6476,5377,6160,1094,4096,4453,1024,6161,3393,7457,16,2,6477,64,5377,5392,3328,3172,6228,7456,256,32,5457,513]

theorem envBound9956 : H12AffineFastState.Bounded env9956 := by
  intro p hp
  have h : env9956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9955_9956 : H12AffineEnvironment.transform 12 6476 env9955 = env9956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env9955 == env9956) = true)

theorem identity9956 : scanCanonicalize (H12AffineFastState.compose env9956 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound9956 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env9957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,3149,0,3345,1094,1281,1124,1024,3344,3393,2080,16,2,3148,64,0,17,3328,3172,3413,2081,256,32,80,513]

theorem envBound9957 : H12AffineFastState.Bounded env9957 := by
  intro p hp
  have h : env9957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9956_9957 : H12AffineEnvironment.transform 11 1281 env9956 = env9957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env9956 == env9957) = true)

theorem identity9957 : scanCanonicalize (H12AffineFastState.compose env9957 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound9957 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9958 : List Nat := [2,4,8,16,32,64,9,256,512,768,2048,513,2893,0,2577,838,513,868,768,2576,2625,2080,16,2,2892,64,0,17,2560,2916,2645,2081,256,32,80,513]

theorem envBound9958 : H12AffineFastState.Bounded env9958 := by
  intro p hp
  have h : env9958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9957_9958 : H12AffineEnvironment.transform 9 768 env9957 = env9958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env9957 == env9958) = true)

theorem identity9958 : scanCanonicalize (H12AffineFastState.compose env9958 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound9958 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env9959 : List Nat := [2,4,8,16,32,64,9,256,512,768,81,513,796,0,576,838,513,868,768,577,528,113,16,2,797,64,0,17,593,821,516,112,256,32,80,513]

theorem envBound9959 : H12AffineFastState.Bounded env9959 := by
  intro p hp
  have h : env9959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9958_9959 : H12AffineEnvironment.transform 10 81 env9958 = env9959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env9958 == env9959) = true)

theorem identity9959 : scanCanonicalize (H12AffineFastState.compose env9959 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9959 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9960 : List Nat := [2,4,8,16,32,64,9,4,512,516,81,513,536,0,576,578,513,608,516,577,528,113,16,2,537,64,0,17,593,561,516,112,4,32,80,513]

theorem envBound9960 : H12AffineFastState.Bounded env9960 := by
  intro p hp
  have h : env9960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9959_9960 : H12AffineEnvironment.transform 7 4 env9959 = env9960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9959 == env9960) = true)

theorem identity9960 : scanCanonicalize (H12AffineFastState.compose env9960 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9960 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env9961 : List Nat := [2,4,8,1,32,64,9,4,512,516,64,513,521,0,576,578,513,608,516,577,513,96,1,2,520,64,0,0,576,544,516,97,4,32,65,513]

theorem envBound9961 : H12AffineFastState.Bounded env9961 := by
  intro p hp
  have h : env9961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9960_9961 : H12AffineEnvironment.transform 3 1 env9960 = env9961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9960 == env9961) = true)

theorem identity9961 : scanCanonicalize (H12AffineFastState.compose env9961 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound9961 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env9962 : List Nat := [2,4,8,1,32,64,9,4,64,68,64,65,73,0,0,2,65,32,68,1,65,96,1,2,72,64,0,0,0,96,68,97,4,32,65,65]

theorem envBound9962 : H12AffineFastState.Bounded env9962 := by
  intro p hp
  have h : env9962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9961_9962 : H12AffineEnvironment.transform 8 64 env9961 = env9962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env9961 == env9962) = true)

theorem identity9962 : scanCanonicalize (H12AffineFastState.compose env9962 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9962 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9963 : List Nat := [2,4,8,1,32,1,9,4,1,5,1,0,8,0,0,2,0,32,5,1,0,33,1,2,9,1,0,0,0,33,5,32,4,32,0,0]

theorem envBound9963 : H12AffineFastState.Bounded env9963 := by
  intro p hp
  have h : env9963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9962_9963 : H12AffineEnvironment.transform 5 1 env9962 = env9963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9962 == env9963) = true)

def env9964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62660,2188616,8328,64,158029,57796,2138516,406724,2102684,2373705,256,21793,46212,2175562]

theorem envBound9964 : H12AffineFastState.Bounded env9964 := by
  intro p hp
  have h : env9964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9924_9964 : H12AffineEnvironment.transform 21 2373825 env9924 = env9964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env9924 == env9964) = true)

theorem identity9964 : scanCanonicalize (H12AffineFastState.compose env9964 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound9964 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env9965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329866,62660,21763,8328,64,158029,57796,102879,406724,75223,329730,256,21793,46212,513]

theorem envBound9965 : H12AffineFastState.Bounded env9965 := by
  intro p hp
  have h : env9965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9964_9965 : H12AffineEnvironment.transform 20 77899 env9964 = env9965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env9964 == env9965) = true)

def env9966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329730,62540,21763,8192,64,158029,57676,102743,406604,75103,329730,256,21793,46092,513]

theorem envBound9966 : H12AffineFastState.Bounded env9966 := by
  intro p hp
  have h : env9966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9965_9966 : H12AffineEnvironment.transform 6 8 env9965 = env9966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9965 == env9966) = true)

theorem identity9966 : scanCanonicalize (H12AffineFastState.compose env9966 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound9966 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env9967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,77899,329730,62540,21763,8192,64,67926,57676,102743,349271,75103,329730,256,21793,46092,513]

theorem envBound9967 : H12AffineFastState.Bounded env9967 := by
  intro p hp
  have h : env9967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9966_9967 : H12AffineEnvironment.transform 16 90139 env9966 = env9967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env9966 == env9967) = true)

def env9968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77899,73770,62540,21763,8192,64,67926,57676,102743,97407,75103,73770,256,21793,46092,513]

theorem envBound9968 : H12AffineFastState.Bounded env9968 := by
  intro p hp
  have h : env9968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9967_9968 : H12AffineEnvironment.transform 17 10280 env9967 = env9968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env9967 == env9968) = true)

theorem identity9968 : scanCanonicalize (H12AffineFastState.compose env9968 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound9968 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1024,29789,77899,73770,16,21763,8192,64,67926,5392,91403,97407,75103,73770,256,21793,16464,513]

theorem envBound9969 : H12AffineFastState.Bounded env9969 := by
  intro p hp
  have h : env9969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9968_9969 : H12AffineEnvironment.transform 14 29788 env9968 = env9969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env9968 == env9969) = true)

end H12CloudChart1