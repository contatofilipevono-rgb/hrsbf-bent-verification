import H12CloudChart1Data211

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env53682 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,13388,10400,1024,8352,4160,21589,95343,16777216,8328,65,16800886,16856172,77955,67618,16797919,16850984,252,16777250,16793819,16873204]

theorem envBound53682 : H12AffineFastState.Bounded env53682 := by
  intro p hp
  have h : env53682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53668_53682 : H12AffineEnvironment.transform 14 8353 env53668 = env53682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env53668 == env53682) = true)

theorem identity53682 : scanCanonicalize (H12AffineFastState.compose env53682 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29942) := by decide +kernel

theorem selectedBound53682 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53683 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,29942,13388,10400,1024,8352,4160,21589,153,16777216,8328,65,16800886,16793754,17525,31956,16797919,16798942,252,16777250,16793819,16777730]

theorem envBound53683 : H12AffineFastState.Bounded env53683 := by
  intro p hp
  have h : env53683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53682_53683 : H12AffineEnvironment.transform 15 29942 env53682 = env53683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29942 env53682 == env53683) = true)

theorem identity53683 : scanCanonicalize (H12AffineFastState.compose env53683 (packedSelected [2,4,5,6,11,12,15,18,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound53683 : packedSelected [2,4,5,6,11,12,15,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env53684 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8353,8322,13388,10400,1024,8352,4160,33,153,16777216,8328,65,16779266,16782574,4097,10400,16778411,16777386,252,16777250,16782511,16777730]

theorem envBound53684 : H12AffineFastState.Bounded env53684 := by
  intro p hp
  have h : env53684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53683_53684 : H12AffineEnvironment.transform 13 5236 env53683 = env53684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env53683 == env53684) = true)

def env53685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13745,34816,1024,32769,4160,21588,120014,16777216,8328,65,16842026,16880845,102878,108927,16797919,16851413,256,16777250,16834950,16873224]

theorem envBound53685 : H12AffineFastState.Bounded env53685 := by
  intro p hp
  have h : env53685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53666_53685 : H12AffineEnvironment.transform 16 13745 env53666 = env53685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env53666 == env53685) = true)

theorem identity53685 : scanCanonicalize (H12AffineFastState.compose env53685 (packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53685 : packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS < 2^1333 := by decide +kernel

def env53686 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,13508,34816,1024,32769,4160,21588,120014,16777216,8328,65,16841823,16880845,102571,108554,16797919,16851104,117,16777250,16834803,16873085]

theorem envBound53686 : H12AffineFastState.Bounded env53686 := by
  intro p hp
  have h : env53686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53685_53686 : H12AffineEnvironment.transform 7 117 env53685 = env53686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53685 == env53686) = true)

def env53687 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8352,65536,13508,10400,1024,8353,4160,21588,95342,16777216,8328,65,16801023,16856173,77835,67754,16797919,16851104,117,16777250,16793683,16873085]

theorem envBound53687 : H12AffineFastState.Bounded env53687 := by
  intro p hp
  have h : env53687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53686_53687 : H12AffineEnvironment.transform 14 8352 env53686 = env53687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env53686 == env53687) = true)

theorem identity53687 : scanCanonicalize (H12AffineFastState.compose env53687 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound53687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53688 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8352,29823,13508,10400,1024,8353,4160,21588,17,16777216,8328,65,16801023,16793618,17524,31957,16797919,16798943,117,16777250,16793683,16777730]

theorem envBound53688 : H12AffineFastState.Bounded env53688 := by
  intro p hp
  have h : env53688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53687_53688 : H12AffineEnvironment.transform 15 29823 env53687 = env53688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env53687 == env53688) = true)

theorem identity53688 : scanCanonicalize (H12AffineFastState.compose env53688 (packedSelected [4,5,6,12,14,15,16,19,22,24] rootPS)) = affineNative (2^(23+1) ^^^ 29911) := by decide +kernel

theorem selectedBound53688 : packedSelected [4,5,6,12,14,15,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env53689 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8352,29823,13508,10400,1024,8353,4160,21588,17,29911,8328,65,10280,13509,17524,31957,9224,8200,117,29941,13444,30421]

theorem envBound53689 : H12AffineFastState.Bounded env53689 := by
  intro p hp
  have h : env53689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53688_53689 : H12AffineEnvironment.transform 23 29911 env53688 = env53689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 29911 env53688 == env53689) = true)

theorem identity53689 : scanCanonicalize (H12AffineFastState.compose env53689 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound53689 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53690 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5237,8352,8202,13508,10400,1024,8353,4160,33,17,8354,8328,65,10280,13509,4097,10400,9224,8200,117,8320,13444,8864]

theorem envBound53690 : H12AffineFastState.Bounded env53690 := by
  intro p hp
  have h : env53690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53689_53690 : H12AffineEnvironment.transform 13 5237 env53689 = env53690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env53689 == env53690) = true)

theorem identity53690 : scanCanonicalize (H12AffineFastState.compose env53690 (packedSelected [2,3,6,8,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound53690 : packedSelected [2,3,6,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53691 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,2600,5237,2696,2594,7916,648,1024,2697,4160,33,17,2698,2720,65,512,7917,4097,648,3616,2592,117,2728,7852,2184]

theorem envBound53691 : H12AffineFastState.Bounded env53691 := by
  intro p hp
  have h : env53691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53690_53691 : H12AffineEnvironment.transform 12 2600 env53690 = env53691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env53690 == env53691) = true)

theorem identity53691 : scanCanonicalize (H12AffineFastState.compose env53691 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound53691 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env53692 : List Nat := [2,4,8,16,32,64,128,117,512,1024,648,4096,160,5237,0,170,5220,648,1024,1,4160,33,17,2,40,65,512,5221,4097,648,1192,168,117,32,5156,512]

theorem envBound53692 : H12AffineFastState.Bounded env53692 := by
  intro p hp
  have h : env53692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53691_53692 : H12AffineEnvironment.transform 10 648 env53691 = env53692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env53691 == env53692) = true)

theorem identity53692 : scanCanonicalize (H12AffineFastState.compose env53692 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound53692 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53693 : List Nat := [2,4,8,16,32,64,121,117,512,1024,625,4096,89,5237,0,83,5220,625,1024,1,4160,33,17,2,40,65,512,5221,4097,625,1105,81,117,32,5156,512]

theorem envBound53693 : H12AffineFastState.Bounded env53693 := by
  intro p hp
  have h : env53693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53692_53693 : H12AffineEnvironment.transform 6 121 env53692 = env53693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env53692 == env53693) = true)

theorem identity53693 : scanCanonicalize (H12AffineFastState.compose env53693 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53693 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53694 : List Nat := [2,4,8,16,32,17,40,36,512,1024,544,4096,8,5156,0,2,5173,544,1024,1,4113,33,17,2,40,16,512,5172,4097,544,1024,0,36,32,5156,512]

theorem envBound53694 : H12AffineFastState.Bounded env53694 := by
  intro p hp
  have h : env53694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53693_53694 : H12AffineEnvironment.transform 5 17 env53693 = env53694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53693 == env53694) = true)

theorem identity53694 : scanCanonicalize (H12AffineFastState.compose env53694 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound53694 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53695 : List Nat := [2,4,8,16,32,17,40,36,512,565,544,4096,8,4625,0,2,4608,544,565,1,4113,33,17,2,40,16,512,4609,4097,544,565,0,36,32,4625,512]

theorem envBound53695 : H12AffineFastState.Bounded env53695 := by
  intro p hp
  have h : env53695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53694_53695 : H12AffineEnvironment.transform 9 565 env53694 = env53695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env53694 == env53695) = true)

theorem identity53695 : scanCanonicalize (H12AffineFastState.compose env53695 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound53695 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53696 : List Nat := [2,4,8,16,32,17,40,36,512,565,544,528,8,1,0,2,16,544,565,1,513,33,17,2,40,16,512,17,529,544,565,0,36,32,1,512]

theorem envBound53696 : H12AffineFastState.Bounded env53696 := by
  intro p hp
  have h : env53696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53695_53696 : H12AffineEnvironment.transform 11 528 env53695 = env53696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env53695 == env53696) = true)

theorem identity53696 : scanCanonicalize (H12AffineFastState.compose env53696 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound53696 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env53697 : List Nat := [2,4,8,16,32,17,40,36,49,4,17,33,8,1,0,2,16,17,4,1,48,33,17,2,40,16,49,17,32,17,4,0,36,32,1,49]

theorem envBound53697 : H12AffineFastState.Bounded env53697 := by
  intro p hp
  have h : env53697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53696_53697 : H12AffineEnvironment.transform 8 49 env53696 = env53697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env53696 == env53697) = true)

theorem identity53697 : scanCanonicalize (H12AffineFastState.compose env53697 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53697 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53698 : List Nat := [2,4,8,16,1,17,9,5,16,4,17,0,8,1,0,2,16,17,4,1,17,0,17,2,9,16,16,17,1,17,4,0,5,1,1,16]

theorem envBound53698 : H12AffineFastState.Bounded env53698 := by
  intro p hp
  have h : env53698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53697_53698 : H12AffineEnvironment.transform 4 1 env53697 = env53698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53697 == env53698) = true)

def env53699 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8353,65536,13508,10401,1024,8352,4160,21588,95343,16777216,8328,65,16801022,16856172,77834,67755,16797919,16851104,117,16777250,16793682,16873085]

theorem envBound53699 : H12AffineFastState.Bounded env53699 := by
  intro p hp
  have h : env53699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53686_53699 : H12AffineEnvironment.transform 14 8353 env53686 = env53699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env53686 == env53699) = true)

theorem identity53699 : scanCanonicalize (H12AffineFastState.compose env53699 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53699 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53700 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,65536,13388,10281,1024,8232,4160,21588,95343,16777216,8192,65,16800886,16856172,77834,67619,16797783,16850984,117,16777250,16793682,16873085]

theorem envBound53700 : H12AffineFastState.Bounded env53700 := by
  intro p hp
  have h : env53700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53699_53700 : H12AffineEnvironment.transform 6 8 env53699 = env53700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53699 == env53700) = true)

theorem identity53700 : scanCanonicalize (H12AffineFastState.compose env53700 (packedSelected [2,4,6,11,12,15,20,22,23] rootPS)) = affineNative (2^(23+1) ^^^ 21622) := by decide +kernel

theorem selectedBound53700 : packedSelected [2,4,6,11,12,15,20,22,23] rootPS < 2^1333 := by decide +kernel

def env53701 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,65536,13388,10281,1024,8232,4160,21588,95343,21622,8192,65,2048,90138,77834,67619,1057,95326,117,21588,5156,74251]

theorem envBound53701 : H12AffineFastState.Bounded env53701 := by
  intro p hp
  have h : env53701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53700_53701 : H12AffineEnvironment.transform 23 21622 env53700 = env53701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 21622 env53700 == env53701) = true)

theorem identity53701 : scanCanonicalize (H12AffineFastState.compose env53701 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound53701 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env53702 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8233,65536,13388,10281,1024,8232,4160,33,73754,3,8192,65,2048,78959,77834,67619,1057,73771,117,33,5156,74251]

theorem envBound53702 : H12AffineFastState.Bounded env53702 := by
  intro p hp
  have h : env53702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53701_53702 : H12AffineEnvironment.transform 13 5237 env53701 = env53702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env53701 == env53702) = true)

theorem identity53702 : scanCanonicalize (H12AffineFastState.compose env53702 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound53702 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env53703 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,9,5237,32,65536,5189,2080,1024,33,4160,33,65555,3,9,65,2048,70758,69635,67619,1057,65570,117,33,5156,66050]

theorem envBound53703 : H12AffineFastState.Bounded env53703 := by
  intro p hp
  have h : env53703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53702_53703 : H12AffineEnvironment.transform 12 9 env53702 = env53703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env53702 == env53703) = true)

theorem identity53703 : scanCanonicalize (H12AffineFastState.compose env53703 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53703 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env53704 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5204,1,65536,5189,2049,1024,0,4160,0,65555,3,9,65,2048,70727,69635,67586,1024,65539,84,0,5125,66050]

theorem envBound53704 : H12AffineFastState.Bounded env53704 := by
  intro p hp
  have h : env53704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53703_53704 : H12AffineEnvironment.transform 4 1 env53703 = env53704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53703 == env53704) = true)

theorem identity53704 : scanCanonicalize (H12AffineFastState.compose env53704 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 6226) := by decide +kernel

theorem selectedBound53704 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env53705 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5204,1,6226,5189,2049,1024,0,4160,0,6209,3,9,65,2048,3093,2129,4176,1024,6225,84,0,5125,6736]

theorem envBound53705 : H12AffineFastState.Bounded env53705 := by
  intro p hp
  have h : env53705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53704_53705 : H12AffineEnvironment.transform 15 6226 env53704 = env53705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6226 env53704 == env53705) = true)

theorem identity53705 : scanCanonicalize (H12AffineFastState.compose env53705 (packedSelected [1,3,12] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound53705 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env53706 : List Nat := [2,4,8,16,1,26,8,14,512,1024,2048,4096,9,5134,1,6152,5151,2049,1024,0,4122,0,6171,3,9,27,2048,3093,2059,4106,1024,6155,14,0,5125,6666]

theorem envBound53706 : H12AffineFastState.Bounded env53706 := by
  intro p hp
  have h : env53706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53705_53706 : H12AffineEnvironment.transform 5 26 env53705 = env53706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env53705 == env53706) = true)

theorem identity53706 : scanCanonicalize (H12AffineFastState.compose env53706 (packedSelected [4,5,8,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound53706 : packedSelected [4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env53707 : List Nat := [2,4,8,16,1,26,8,14,512,1024,2048,1054,9,16,1,3094,1,2049,1024,0,1028,0,3077,3,9,27,2048,3093,2059,1044,1024,3093,14,0,27,3604]

theorem envBound53707 : H12AffineFastState.Bounded env53707 := by
  intro p hp
  have h : env53707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53706_53707 : H12AffineEnvironment.transform 11 1054 env53706 = env53707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env53706 == env53707) = true)

def env53708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound53708 : H12AffineFastState.Bounded env53708 := by
  intro p hp
  have h : env53708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53532_53708 : H12AffineEnvironment.transform 18 1025 env53532 = env53708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env53532 == env53708) = true)

theorem identity53708 : scanCanonicalize (H12AffineFastState.compose env53708 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297470) := by decide +kernel

theorem selectedBound53708 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297470,8328,65,12798462,2428274,10507600,8830977,8719855,6679615,257,10833235,10857718,8661561]

theorem envBound53709 : H12AffineFastState.Bounded env53709 := by
  intro p hp
  have h : env53709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53708_53709 : H12AffineEnvironment.transform 23 297470 env53708 = env53709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297470 env53708 == env53709) = true)

def env53710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12798326,2428274,10507600,8830977,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound53710 : H12AffineFastState.Bounded env53710 := by
  intro p hp
  have h : env53710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53709_53710 : H12AffineEnvironment.transform 6 8 env53709 = env53710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53709 == env53710) = true)

def env53711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650854,2428274,10507600,8683537,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound53711 : H12AffineFastState.Bounded env53711 := by
  intro p hp
  have h : env53711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53710_53711 : H12AffineEnvironment.transform 16 16400 env53710 = env53711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env53710 == env53711) = true)

theorem identity53711 : scanCanonicalize (H12AffineFastState.compose env53711 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297317) := by decide +kernel

theorem selectedBound53711 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,297317,297334,8192,65,4554755,2428274,2415669,2420,99330,6679615,257,2212918,2172187,41820]

theorem envBound53712 : H12AffineFastState.Bounded env53712 := by
  intro p hp
  have h : env53712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53711_53712 : H12AffineEnvironment.transform 22 297317 env53711 = env53712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297317 env53711 == env53712) = true)

theorem identity53712 : scanCanonicalize (H12AffineFastState.compose env53712 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound53712 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env53713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16400,262144,1025,32769,2097152,4194304,297317,297334,8192,65,4456788,2395173,2415669,2420,1365,6581608,257,2114913,2139212,41820]

theorem envBound53713 : H12AffineFastState.Bounded env53713 := by
  intro p hp
  have h : env53713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53712_53713 : H12AffineEnvironment.transform 15 33111 env53712 = env53713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env53712 == env53713) = true)

theorem identity53713 : scanCanonicalize (H12AffineFastState.compose env53713 (packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound53713 : packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS < 2^1333 := by decide +kernel

def env53714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16400,262144,1025,32769,2097152,41341,297317,297334,8192,65,303145,2395173,2415669,2420,1365,2411541,257,2114913,2139212,41820]

theorem envBound53714 : H12AffineFastState.Bounded env53714 := by
  intro p hp
  have h : env53714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53713_53714 : H12AffineEnvironment.transform 21 41341 env53713 = env53714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env53713 == env53714) = true)

theorem identity53714 : scanCanonicalize (H12AffineFastState.compose env53714 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound53714 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env53715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16400,262144,1025,32769,25677,41341,297317,297334,8192,65,303145,321640,309368,2420,1365,305240,257,8492,49153,41820]

theorem envBound53715 : H12AffineFastState.Bounded env53715 := by
  intro p hp
  have h : env53715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53714_53715 : H12AffineEnvironment.transform 20 25677 env53714 = env53715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env53714 == env53715) = true)

def env53716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8575,16400,262144,1025,8233,25677,341,272717,272734,8192,65,262145,280640,268368,2420,1365,264304,257,8492,24617,884]

theorem envBound53716 : H12AffineFastState.Bounded env53716 := by
  intro p hp
  have h : env53716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53715_53716 : H12AffineEnvironment.transform 14 8232 env53715 = env53716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env53715 == env53716) = true)

theorem identity53716 : scanCanonicalize (H12AffineFastState.compose env53716 (packedSelected [0,1,3,4,10,11,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound53716 : packedSelected [0,1,3,4,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env53717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8575,16400,10281,1025,8233,25677,341,356,375,8192,65,10280,24681,12409,2420,1365,8281,257,8492,24617,884]

theorem envBound53717 : H12AffineFastState.Bounded env53717 := by
  intro p hp
  have h : env53717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53716_53717 : H12AffineEnvironment.transform 17 10281 env53716 = env53717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53716 == env53717) = true)

theorem identity53717 : scanCanonicalize (H12AffineFastState.compose env53717 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53717 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,292,115,16400,2341,1025,293,17729,341,356,375,268,65,2340,16741,4469,2420,1365,341,257,32,16677,884]

theorem envBound53718 : H12AffineFastState.Bounded env53718 := by
  intro p hp
  have h : env53718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53717_53718 : H12AffineEnvironment.transform 12 268 env53717 = env53718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53717 == env53718) = true)

theorem identity53718 : scanCanonicalize (H12AffineFastState.compose env53718 (packedSelected [0,1,2,4,5,6,11] rootPS)) = affineNative (2^(13+1) ^^^ 7505) := by decide +kernel

theorem selectedBound53718 : packedSelected [0,1,2,4,5,6,11] rootPS < 2^1333 := by decide +kernel

def env53719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,7505,292,115,7489,2341,1025,293,6160,341,356,375,268,65,2340,7220,4469,2420,1365,341,257,32,7284,884]

theorem envBound53719 : H12AffineFastState.Bounded env53719 := by
  intro p hp
  have h : env53719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53718_53719 : H12AffineEnvironment.transform 13 7505 env53718 = env53719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7505 env53718 == env53719) = true)

theorem identity53719 : scanCanonicalize (H12AffineFastState.compose env53719 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound53719 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env53720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,268,5377,292,115,5393,373,1025,293,4160,341,356,375,268,65,372,5220,4469,292,1365,341,257,32,5156,884]

theorem envBound53720 : H12AffineFastState.Bounded env53720 := by
  intro p hp
  have h : env53720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53719_53720 : H12AffineEnvironment.transform 10 80 env53719 = env53720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env53719 == env53720) = true)

def env53721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8574,16400,262144,1025,8232,25677,340,272716,272735,8192,65,262144,280641,268369,2420,1365,264305,257,8492,24616,885]

theorem envBound53721 : H12AffineFastState.Bounded env53721 := by
  intro p hp
  have h : env53721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53715_53721 : H12AffineEnvironment.transform 14 8233 env53715 = env53721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env53715 == env53721) = true)

theorem identity53721 : scanCanonicalize (H12AffineFastState.compose env53721 (packedSelected [0,1,3,4,10,11,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound53721 : packedSelected [0,1,3,4,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env53722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8574,16400,10589,1025,8232,25677,340,17,2,8192,65,10589,24860,12556,2420,1365,8492,257,8492,24616,885]

theorem envBound53722 : H12AffineFastState.Bounded env53722 := by
  intro p hp
  have h : env53722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53721_53722 : H12AffineEnvironment.transform 17 10589 env53721 = env53722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env53721 == env53722) = true)

theorem identity53722 : scanCanonicalize (H12AffineFastState.compose env53722 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53722 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53723 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8233,8494,16400,10509,1025,8232,25629,260,17,2,8192,17,10509,24860,12556,2340,1285,8492,257,8492,24616,805]

theorem envBound53723 : H12AffineFastState.Bounded env53723 := by
  intro p hp
  have h : env53723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53722_53723 : H12AffineEnvironment.transform 5 16 env53722 = env53723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53722 == env53723) = true)

theorem identity53723 : scanCanonicalize (H12AffineFastState.compose env53723 (packedSelected [2,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound53723 : packedSelected [2,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53724 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13609,8233,8494,13625,10509,1025,8232,4404,260,17,2,8192,17,10509,5173,12556,2340,1285,8492,257,8492,5377,805]

theorem envBound53724 : H12AffineFastState.Bounded env53724 := by
  intro p hp
  have h : env53724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53723_53724 : H12AffineEnvironment.transform 13 13609 env53723 = env53724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env53723 == env53724) = true)

theorem identity53724 : scanCanonicalize (H12AffineFastState.compose env53724 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound53724 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env53725 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6201,3344,6160,6423,3328,4404,1025,6161,4404,260,17,2,6201,17,4404,5173,2357,2340,1285,6421,257,6421,5377,805]

theorem envBound53725 : H12AffineFastState.Bounded env53725 := by
  intro p hp
  have h : env53725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53724_53725 : H12AffineEnvironment.transform 12 6201 env53724 = env53725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env53724 == env53725) = true)

theorem identity53725 : scanCanonicalize (H12AffineFastState.compose env53725 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound53725 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53726 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,4096,5416,1,5377,5126,17,4404,1025,5376,4404,260,17,2,5416,17,4404,5173,1060,1077,1285,5124,257,5124,5377,805]

theorem envBound53726 : H12AffineFastState.Bounded env53726 := by
  intro p hp
  have h : env53726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53725_53726 : H12AffineEnvironment.transform 10 1297 env53725 = env53726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env53725 == env53726) = true)

theorem identity53726 : scanCanonicalize (H12AffineFastState.compose env53726 (packedSelected [2,6,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound53726 : packedSelected [2,6,10,14] rootPS < 2^1333 := by decide +kernel

def env53727 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,1281,41,1,0,263,17,1077,1025,1,1077,260,17,2,41,17,1077,308,1060,1077,1285,261,257,261,0,805]

theorem envBound53727 : H12AffineFastState.Bounded env53727 := by
  intro p hp
  have h : env53727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53726_53727 : H12AffineEnvironment.transform 11 1281 env53726 = env53727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env53726 == env53727) = true)

theorem identity53727 : scanCanonicalize (H12AffineFastState.compose env53727 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53727 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53728 : List Nat := [2,4,8,16,32,16,8,256,512,53,292,308,41,1,0,263,17,0,52,1,0,260,17,2,41,17,0,308,17,0,304,261,257,261,0,805]

theorem envBound53728 : H12AffineFastState.Bounded env53728 := by
  intro p hp
  have h : env53728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53727_53728 : H12AffineEnvironment.transform 9 53 env53727 = env53728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53727 == env53728) = true)

theorem identity53728 : scanCanonicalize (H12AffineFastState.compose env53728 (packedSelected [0,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53728 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env53729 : List Nat := [2,4,8,0,32,0,8,256,512,37,292,292,41,1,0,263,1,0,36,1,0,260,1,2,41,1,0,292,1,0,288,261,257,261,0,805]

theorem envBound53729 : H12AffineFastState.Bounded env53729 := by
  intro p hp
  have h : env53729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53728_53729 : H12AffineEnvironment.transform 3 0 env53728 = env53729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53728 == env53729) = true)

def env53730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650855,2428274,10507600,8683536,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound53730 : H12AffineFastState.Bounded env53730 := by
  intro p hp
  have h : env53730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53710_53730 : H12AffineEnvironment.transform 16 16401 env53710 = env53730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env53710 == env53730) = true)

theorem identity53730 : scanCanonicalize (H12AffineFastState.compose env53730 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53730 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1025,8540,2097152,4194304,8388608,272427,8192,65,12650855,2428274,10507600,8659277,8719719,6638946,257,10833235,10816803,8661561]

theorem envBound53731 : H12AffineFastState.Bounded env53731 := by
  intro p hp
  have h : env53731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53730_53731 : H12AffineEnvironment.transform 14 8541 env53730 = env53731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53730 == env53731) = true)

theorem identity53731 : scanCanonicalize (H12AffineFastState.compose env53731 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 329779) := by decide +kernel

theorem selectedBound53731 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env53732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1025,8540,2097152,4194304,329779,272427,8192,65,4456788,2428274,2448739,76158,1364,6638946,257,2114912,2098448,74250]

theorem envBound53732 : H12AffineFastState.Bounded env53732 := by
  intro p hp
  have h : env53732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53731_53732 : H12AffineEnvironment.transform 22 329779 env53731 = env53732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 329779 env53731 == env53732) = true)

theorem identity53732 : scanCanonicalize (H12AffineFastState.compose env53732 (packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 329731) := by decide +kernel

theorem selectedBound53732 : packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS < 2^1333 := by decide +kernel

def env53733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1025,8540,2097152,329731,329779,272427,8192,65,67927,2428274,2448739,76158,1364,2114913,257,2114912,2098448,74250]

theorem envBound53733 : H12AffineFastState.Bounded env53733 := by
  intro p hp
  have h : env53733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53732_53733 : H12AffineEnvironment.transform 21 329731 env53732 = env53733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329731 env53732 == env53733) = true)

theorem identity53733 : scanCanonicalize (H12AffineFastState.compose env53733 (packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound53733 : packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env53734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1025,8540,91466,329731,329779,272427,8192,65,67927,288824,276521,76158,1364,73771,257,73770,90202,74250]

theorem envBound53734 : H12AffineFastState.Bounded env53734 := by
  intro p hp
  have h : env53734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53733_53734 : H12AffineEnvironment.transform 20 91466 env53733 = env53734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env53733 == env53734) = true)

theorem identity53734 : scanCanonicalize (H12AffineFastState.compose env53734 (packedSelected [2,4,9,11,16,17,18,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53734 : packedSelected [2,4,9,11,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env53735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91466,73771,73755,3,8192,65,67927,16400,4097,76158,1364,73771,257,73770,90202,74250]

theorem envBound53735 : H12AffineFastState.Bounded env53735 := by
  intro p hp
  have h : env53735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53734_53735 : H12AffineEnvironment.transform 17 10280 env53734 = env53735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53734 == env53735) = true)

theorem identity53735 : scanCanonicalize (H12AffineFastState.compose env53735 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound53735 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env53736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8541,65536,5221,10280,1025,8540,78142,73771,73755,3,8192,65,67927,5220,4097,76158,1364,73771,257,73770,78894,74250]

theorem envBound53736 : H12AffineFastState.Bounded env53736 := by
  intro p hp
  have h : env53736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53735_53736 : H12AffineEnvironment.transform 13 5236 env53735 = env53736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env53735 == env53736) = true)

theorem identity53736 : scanCanonicalize (H12AffineFastState.compose env53736 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound53736 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env53737 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4113,8541,65536,4096,10280,100,8540,78142,73771,73755,3,8192,65,67927,4097,4097,76158,305,73771,257,73770,77899,74250]

theorem envBound53737 : H12AffineFastState.Bounded env53737 := by
  intro p hp
  have h : env53737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53736_53737 : H12AffineEnvironment.transform 9 101 env53736 = env53737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env53736 == env53737) = true)

theorem identity53737 : scanCanonicalize (H12AffineFastState.compose env53737 (packedSelected [1,3,4,6,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 14411) := by decide +kernel

theorem selectedBound53737 : packedSelected [1,3,4,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env53738 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4113,8541,14411,4096,10280,100,8540,2421,6240,6224,3,8192,65,12572,4097,4097,4405,305,6240,257,6241,2048,6721]

theorem envBound53738 : H12AffineFastState.Bounded env53738 := by
  intro p hp
  have h : env53738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53737_53738 : H12AffineEnvironment.transform 15 14411 env53737 = env53738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14411 env53737 == env53738) = true)

theorem identity53738 : scanCanonicalize (H12AffineFastState.compose env53738 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53738 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env53739 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,269,4113,80,6470,4096,2341,100,81,2421,6240,6224,3,269,65,4113,4097,4097,4405,305,6240,257,6241,2048,6721]

theorem envBound53739 : H12AffineFastState.Bounded env53739 := by
  intro p hp
  have h : env53739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53738_53739 : H12AffineEnvironment.transform 12 269 env53738 = env53739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53738 == env53739) = true)

theorem identity53739 : scanCanonicalize (H12AffineFastState.compose env53739 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound53739 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env53740 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2065,269,2048,80,343,2065,2341,100,81,2421,113,65,3,269,65,2048,2064,2064,2340,305,113,257,112,2048,592]

theorem envBound53740 : H12AffineFastState.Bounded env53740 := by
  intro p hp
  have h : env53740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53739_53740 : H12AffineEnvironment.transform 11 2065 env53739 = env53740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env53739 == env53740) = true)

theorem identity53740 : scanCanonicalize (H12AffineFastState.compose env53740 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53740 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53741 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2065,269,2048,1,262,2065,2341,53,0,2340,32,16,3,269,16,2048,2064,2064,2340,305,32,257,33,2048,513]

theorem envBound53741 : H12AffineFastState.Bounded env53741 := by
  intro p hp
  have h : env53741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53740_53741 : H12AffineEnvironment.transform 5 17 env53740 = env53741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53740 == env53741) = true)

theorem identity53741 : scanCanonicalize (H12AffineFastState.compose env53741 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 830) := by decide +kernel

theorem selectedBound53741 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53742 : List Nat := [2,4,8,16,32,17,8,256,512,52,830,815,269,830,1,262,815,539,53,0,538,32,16,3,269,16,830,814,814,538,305,32,257,33,830,513]

theorem envBound53742 : H12AffineFastState.Bounded env53742 := by
  intro p hp
  have h : env53742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53741_53742 : H12AffineEnvironment.transform 10 830 env53741 = env53742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 830 env53741 == env53742) = true)

theorem identity53742 : scanCanonicalize (H12AffineFastState.compose env53742 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound53742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53743 : List Nat := [2,4,8,16,32,17,8,256,26,52,292,309,269,292,1,262,309,1,53,0,0,32,16,3,269,16,292,308,308,0,305,32,257,33,292,27]

theorem envBound53743 : H12AffineFastState.Bounded env53743 := by
  intro p hp
  have h : env53743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53742_53743 : H12AffineEnvironment.transform 8 26 env53742 = env53743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env53742 == env53743) = true)

def env53744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12798327,2428274,10507600,8830977,8719718,6679615,257,10833235,10857599,8661561]

theorem envBound53744 : H12AffineFastState.Bounded env53744 := by
  intro p hp
  have h : env53744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53709_53744 : H12AffineEnvironment.transform 6 9 env53709 = env53744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53709 == env53744) = true)

def env53745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650855,2428274,10507600,8683537,8719718,6679615,257,10833235,10857599,8661561]

theorem envBound53745 : H12AffineFastState.Bounded env53745 := by
  intro p hp
  have h : env53745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53744_53745 : H12AffineEnvironment.transform 16 16400 env53744 = env53745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env53744 == env53745) = true)

theorem identity53745 : scanCanonicalize (H12AffineFastState.compose env53745 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound53745 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,8388608,41310,8193,65,12650855,2172251,10507600,8431672,8463695,6407190,257,10577274,10585174,8389136]

theorem envBound53746 : H12AffineFastState.Bounded env53746 := by
  intro p hp
  have h : env53746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53745_53746 : H12AffineEnvironment.transform 17 10281 env53745 = env53746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53745 == env53746) = true)

def env53747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,16,41310,8193,65,4262263,2172251,2118976,43048,75103,6407190,257,2188650,2196550,512]

theorem envBound53747 : H12AffineFastState.Bounded env53747 := by
  intro p hp
  have h : env53747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53746_53747 : H12AffineEnvironment.transform 22 16 env53746 = env53747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env53746 == env53747) = true)

theorem identity53747 : scanCanonicalize (H12AffineFastState.compose env53747 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 58729) := by decide +kernel

theorem selectedBound53747 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58729,4194304,16,41310,8193,65,4262263,114738,45097,43048,75103,4268415,257,98307,90415,512]

theorem envBound53748 : H12AffineFastState.Bounded env53748 := by
  intro p hp
  have h : env53748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53747_53748 : H12AffineEnvironment.transform 20 58729 env53747 = env53748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58729 env53747 == env53748) = true)

theorem identity53748 : scanCanonicalize (H12AffineFastState.compose env53748 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound53748 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env53749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58729,98678,16,41310,8193,65,34817,114738,45097,43048,75103,40969,257,98307,90415,512]

theorem envBound53749 : H12AffineFastState.Bounded env53749 := by
  intro p hp
  have h : env53749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53748_53749 : H12AffineEnvironment.transform 21 98678 env53748 = env53749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env53748 == env53749) = true)

theorem identity53749 : scanCanonicalize (H12AffineFastState.compose env53749 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 61498) := by decide +kernel

theorem selectedBound53749 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,61498,16400,10281,1025,32769,58729,29004,16,41310,8193,65,34817,12296,45097,43048,54629,40969,257,28729,37141,512]

theorem envBound53750 : H12AffineFastState.Bounded env53750 := by
  intro p hp
  have h : env53750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53749_53750 : H12AffineEnvironment.transform 15 61498 env53749 = env53750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61498 env53749 == env53750) = true)

theorem identity53750 : scanCanonicalize (H12AffineFastState.compose env53750 (packedSelected [12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53750 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env53751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,42298,5392,10281,1025,32769,45161,9292,16,41310,8193,65,34817,12296,45097,43048,32869,40969,257,9529,37141,512]

theorem envBound53751 : H12AffineFastState.Bounded env53751 := by
  intro p hp
  have h : env53751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53750_53751 : H12AffineEnvironment.transform 13 5376 env53750 = env53751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53750 == env53751) = true)

theorem identity53751 : scanCanonicalize (H12AffineFastState.compose env53751 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound53751 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env53752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1077,8463,5392,10281,1025,1076,13404,9292,16,9579,8193,65,3124,12296,13340,11293,1104,9276,257,9529,5408,512]

theorem envBound53752 : H12AffineFastState.Bounded env53752 := by
  intro p hp
  have h : env53752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53751_53752 : H12AffineEnvironment.transform 14 1077 env53751 = env53752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env53751 == env53752) = true)

theorem identity53752 : scanCanonicalize (H12AffineFastState.compose env53752 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound53752 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env53753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,5376,1077,1127,5392,3393,1025,1076,4404,292,16,3,1385,65,3124,5472,4468,2421,1104,340,257,81,5408,512]

theorem envBound53753 : H12AffineFastState.Bounded env53753 := by
  intro p hp
  have h : env53753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53752_53753 : H12AffineEnvironment.transform 12 1384 env53752 = env53753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env53752 == env53753) = true)

theorem identity53753 : scanCanonicalize (H12AffineFastState.compose env53753 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound53753 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53754 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,41,4161,372,294,4177,2048,320,373,4404,292,16,3,40,65,2421,4129,4468,2421,273,340,257,81,4193,512]

theorem envBound53754 : H12AffineFastState.Bounded env53754 := by
  intro p hp
  have h : env53754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53753_53754 : H12AffineEnvironment.transform 9 321 env53753 = env53754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53753 == env53754) = true)

theorem identity53754 : scanCanonicalize (H12AffineFastState.compose env53754 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53754 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53755 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,41,4161,1,83,4177,2048,53,0,4161,81,16,3,40,65,2048,4129,4097,2048,100,33,116,81,4193,512]

theorem envBound53755 : H12AffineFastState.Bounded env53755 := by
  intro p hp
  have h : env53755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53754_53755 : H12AffineEnvironment.transform 7 117 env53754 = env53755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53754 == env53755) = true)

theorem identity53755 : scanCanonicalize (H12AffineFastState.compose env53755 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound53755 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53756 : List Nat := [2,4,8,16,32,49,9,4,512,52,2048,4096,41,4144,1,34,4128,2048,53,0,4144,32,16,3,40,48,2048,4129,4097,2048,21,33,5,32,4112,512]

theorem envBound53756 : H12AffineFastState.Bounded env53756 := by
  intro p hp
  have h : env53756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53755_53756 : H12AffineEnvironment.transform 5 49 env53755 = env53756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env53755 == env53756) = true)

theorem identity53756 : scanCanonicalize (H12AffineFastState.compose env53756 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound53756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53757 : List Nat := [2,4,8,16,32,49,9,4,512,52,2048,2560,41,2608,1,34,2592,2048,53,0,2608,32,16,3,40,48,2048,2593,2561,2048,21,33,5,32,2576,512]

theorem envBound53757 : H12AffineFastState.Bounded env53757 := by
  intro p hp
  have h : env53757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53756_53757 : H12AffineEnvironment.transform 11 2560 env53756 = env53757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env53756 == env53757) = true)

theorem identity53757 : scanCanonicalize (H12AffineFastState.compose env53757 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound53757 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53758 : List Nat := [2,4,8,16,32,49,9,4,512,52,529,17,41,33,1,34,49,529,53,0,33,32,16,3,40,48,529,48,16,529,21,33,5,32,1,512]

theorem envBound53758 : H12AffineFastState.Bounded env53758 := by
  intro p hp
  have h : env53758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53757_53758 : H12AffineEnvironment.transform 10 529 env53757 = env53758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env53757 == env53758) = true)

theorem identity53758 : scanCanonicalize (H12AffineFastState.compose env53758 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53758 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53759 : List Nat := [2,4,8,16,1,16,9,4,512,21,529,17,8,0,1,3,16,529,20,0,0,1,16,3,9,17,529,17,16,529,21,0,5,1,1,512]

theorem envBound53759 : H12AffineFastState.Bounded env53759 := by
  intro p hp
  have h : env53759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53758_53759 : H12AffineEnvironment.transform 4 1 env53758 = env53759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53758 == env53759) = true)

theorem identity53759 : scanCanonicalize (H12AffineFastState.compose env53759 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound53759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53760 : List Nat := [2,4,8,5,1,5,9,4,512,0,516,4,8,0,1,3,5,516,1,0,0,1,5,3,9,4,516,4,5,516,0,0,5,1,1,512]

theorem envBound53760 : H12AffineFastState.Bounded env53760 := by
  intro p hp
  have h : env53760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53759_53760 : H12AffineEnvironment.transform 3 5 env53759 = env53760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env53759 == env53760) = true)

theorem identity53760 : scanCanonicalize (H12AffineFastState.compose env53760 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound53760 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53761 : List Nat := [2,4,8,5,1,5,9,4,5,0,1,4,8,0,1,3,5,1,1,0,0,1,5,3,9,4,1,4,5,1,0,0,5,1,1,5]

theorem envBound53761 : H12AffineFastState.Bounded env53761 := by
  intro p hp
  have h : env53761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53760_53761 : H12AffineEnvironment.transform 8 5 env53760 = env53761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env53760 == env53761) = true)

def env53762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41310,8193,65,4262262,2172251,2118977,43049,75102,6407190,257,2188651,2196551,513]

theorem envBound53762 : H12AffineFastState.Bounded env53762 := by
  intro p hp
  have h : env53762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53746_53762 : H12AffineEnvironment.transform 22 17 env53746 = env53762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env53746 == env53762) = true)

def env53763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,4194304,17,41310,8193,65,4262262,115015,45405,43049,75102,4268042,257,98679,90203,513]

theorem envBound53763 : H12AffineFastState.Bounded env53763 := by
  intro p hp
  have h : env53763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53762_53763 : H12AffineEnvironment.transform 20 58396 env53762 = env53763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env53762 == env53763) = true)

theorem identity53763 : scanCanonicalize (H12AffineFastState.compose env53763 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound53763 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env53764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,41341,17,41310,8193,65,108555,115015,45405,43049,75102,98679,257,98679,90203,513]

theorem envBound53764 : H12AffineFastState.Bounded env53764 := by
  intro p hp
  have h : env53764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53763_53764 : H12AffineEnvironment.transform 21 41341 env53763 = env53764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env53763 == env53764) = true)

theorem identity53764 : scanCanonicalize (H12AffineFastState.compose env53764 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53764 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,58396,41341,17,41310,8193,65,34816,57676,45405,43049,1365,41340,257,41340,16464,513]

theorem envBound53765 : H12AffineFastState.Bounded env53765 := by
  intro p hp
  have h : env53765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53764_53765 : H12AffineEnvironment.transform 15 8203 env53764 = env53765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53764 == env53765) = true)

theorem identity53765 : scanCanonicalize (H12AffineFastState.compose env53765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,16400,2421,1025,32769,50496,32801,17,32770,349,65,34816,49168,36865,35189,1365,32800,257,32800,16464,513]

theorem envBound53766 : H12AffineFastState.Bounded env53766 := by
  intro p hp
  have h : env53766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53765_53766 : H12AffineEnvironment.transform 12 348 env53765 = env53766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53765 == env53766) = true)

theorem identity53766 : scanCanonicalize (H12AffineFastState.compose env53766 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53766 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,343,16400,2421,1025,0,17729,32,17,3,349,65,2049,16401,4096,2420,1365,33,257,33,16464,513]

theorem envBound53767 : H12AffineFastState.Bounded env53767 := by
  intro p hp
  have h : env53767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53766_53767 : H12AffineEnvironment.transform 14 1 env53766 = env53767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53766 == env53767) = true)

theorem identity53767 : scanCanonicalize (H12AffineFastState.compose env53767 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound53767 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,602,4096,348,16384,1,343,16400,815,1025,0,17729,32,17,3,349,65,603,16401,4096,814,1365,33,257,33,16464,513]

theorem envBound53768 : H12AffineFastState.Bounded env53768 := by
  intro p hp
  have h : env53768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53767_53768 : H12AffineEnvironment.transform 10 602 env53767 = env53768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env53767 == env53768) = true)

theorem identity53768 : scanCanonicalize (H12AffineFastState.compose env53768 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53768 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,602,4096,348,5377,1,343,5393,815,1025,0,4160,32,17,3,349,65,603,5392,4096,814,1365,33,257,33,5457,513]

theorem envBound53769 : H12AffineFastState.Bounded env53769 := by
  intro p hp
  have h : env53769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53768_53769 : H12AffineEnvironment.transform 13 5377 env53768 = env53769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53768 == env53769) = true)

theorem identity53769 : scanCanonicalize (H12AffineFastState.compose env53769 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53769 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env53770 : List Nat := [2,4,8,16,32,64,9,116,512,1024,602,4096,40,5237,1,35,5221,603,1025,0,4160,32,17,3,41,65,603,5220,4096,602,1057,33,117,33,5157,513]

theorem envBound53770 : H12AffineFastState.Bounded env53770 := by
  intro p hp
  have h : env53770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53769_53770 : H12AffineEnvironment.transform 7 116 env53769 = env53770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53769 == env53770) = true)

theorem identity53770 : scanCanonicalize (H12AffineFastState.compose env53770 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound53770 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53771 : List Nat := [2,4,8,16,32,64,9,116,512,623,602,4096,40,4634,1,35,4618,603,622,0,4160,32,17,3,41,65,603,4619,4096,602,590,33,117,33,4682,513]

theorem envBound53771 : H12AffineFastState.Bounded env53771 := by
  intro p hp
  have h : env53771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53770_53771 : H12AffineEnvironment.transform 9 623 env53770 = env53771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env53770 == env53771) = true)

theorem identity53771 : scanCanonicalize (H12AffineFastState.compose env53771 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound53771 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53772 : List Nat := [2,4,8,16,32,64,9,116,43,68,113,4096,40,4145,1,35,4129,112,69,0,4160,32,17,3,41,65,112,4128,4096,113,101,33,117,33,4193,42]

theorem envBound53772 : H12AffineFastState.Bounded env53772 := by
  intro p hp
  have h : env53772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53771_53772 : H12AffineEnvironment.transform 8 43 env53771 = env53772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env53771 == env53772) = true)

theorem identity53772 : scanCanonicalize (H12AffineFastState.compose env53772 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 57) := by decide +kernel

theorem selectedBound53772 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53773 : List Nat := [2,4,8,16,32,57,9,13,43,61,8,4096,40,4145,1,35,4129,9,60,0,4153,32,17,3,41,56,9,4128,4096,8,28,33,12,33,4120,42]

theorem envBound53773 : H12AffineFastState.Bounded env53773 := by
  intro p hp
  have h : env53773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53772_53773 : H12AffineEnvironment.transform 5 57 env53772 = env53773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 57 env53772 == env53773) = true)

theorem identity53773 : scanCanonicalize (H12AffineFastState.compose env53773 (packedSelected [1,11] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound53773 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env53774 : List Nat := [2,4,8,16,9,16,9,13,2,20,8,4096,1,4120,1,10,4104,9,21,0,4112,9,17,3,0,17,9,4105,4096,8,28,8,12,8,4120,3]

theorem envBound53774 : H12AffineFastState.Bounded env53774 := by
  intro p hp
  have h : env53774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53773_53774 : H12AffineEnvironment.transform 4 9 env53773 = env53774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env53773 == env53774) = true)

theorem identity53774 : scanCanonicalize (H12AffineFastState.compose env53774 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 24) := by decide +kernel

theorem selectedBound53774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53775 : List Nat := [2,4,8,16,9,16,9,13,2,20,8,24,1,0,1,10,16,9,21,0,8,9,17,3,0,17,9,17,24,8,28,8,12,8,0,3]

theorem envBound53775 : H12AffineFastState.Bounded env53775 := by
  intro p hp
  have h : env53775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53774_53775 : H12AffineEnvironment.transform 11 24 env53774 = env53775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 24 env53774 == env53775) = true)

theorem identity53775 : scanCanonicalize (H12AffineFastState.compose env53775 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53776 : List Nat := [2,3,8,16,9,16,9,10,2,19,8,24,1,0,1,10,16,9,18,0,8,9,17,3,0,17,9,17,24,8,27,8,11,8,0,3]

theorem envBound53776 : H12AffineFastState.Bounded env53776 := by
  intro p hp
  have h : env53776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53775_53776 : H12AffineEnvironment.transform 1 3 env53775 = env53776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53775 == env53776) = true)

theorem identity53776 : scanCanonicalize (H12AffineFastState.compose env53776 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound53776 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53777 : List Nat := [2,3,1,16,0,16,0,3,2,19,1,17,1,0,1,3,16,0,18,0,1,0,17,3,0,17,0,17,17,1,18,1,2,1,0,3]

theorem envBound53777 : H12AffineFastState.Bounded env53777 := by
  intro p hp
  have h : env53777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53776_53777 : H12AffineEnvironment.transform 2 1 env53776 = env53777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env53776 == env53777) = true)

def env53778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,4194304,17,41310,8193,65,4262262,115014,45404,43049,75102,4268043,257,98678,90202,513]

theorem envBound53778 : H12AffineFastState.Bounded env53778 := by
  intro p hp
  have h : env53778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53762_53778 : H12AffineEnvironment.transform 20 58397 env53762 = env53778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env53762 == env53778) = true)

theorem identity53778 : scanCanonicalize (H12AffineFastState.compose env53778 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58397,4194304,17,41310,8193,65,4204924,57676,45404,43049,1364,4194305,257,41340,16464,513]

theorem envBound53779 : H12AffineFastState.Bounded env53779 := by
  intro p hp
  have h : env53779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53778_53779 : H12AffineEnvironment.transform 15 8202 env53778 = env53779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53778 == env53779) = true)

theorem identity53779 : scanCanonicalize (H12AffineFastState.compose env53779 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound53779 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58397,33,17,41310,8193,65,10589,57676,45404,43049,1364,32,257,41340,16464,513]

theorem envBound53780 : H12AffineFastState.Bounded env53780 := by
  intro p hp
  have h : env53780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53779_53780 : H12AffineEnvironment.transform 21 33 env53779 = env53780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env53779 == env53780) = true)

theorem identity53780 : scanCanonicalize (H12AffineFastState.compose env53780 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53780 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env53781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16400,2340,1025,32769,50448,33,17,32851,268,65,2128,49217,36945,35108,1364,32,257,32881,16464,513]

theorem envBound53781 : H12AffineFastState.Bounded env53781 := by
  intro p hp
  have h : env53781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53780_53781 : H12AffineEnvironment.transform 12 269 env53780 = env53781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53780 == env53781) = true)

theorem identity53781 : scanCanonicalize (H12AffineFastState.compose env53781 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound53781 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,263,16400,2340,1025,81,17728,33,17,3,268,65,2128,16401,4097,2420,1364,32,257,33,16464,513]

theorem envBound53782 : H12AffineFastState.Bounded env53782 := by
  intro p hp
  have h : env53782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53781_53782 : H12AffineEnvironment.transform 14 80 env53781 = env53782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env53781 == env53782) = true)

theorem identity53782 : scanCanonicalize (H12AffineFastState.compose env53782 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53782 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53783 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,263,16400,2340,1025,1,17680,33,17,3,268,17,2048,16401,4097,2340,1284,32,257,33,16384,513]

theorem envBound53783 : H12AffineFastState.Bounded env53783 := by
  intro p hp
  have h : env53783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53782_53783 : H12AffineEnvironment.transform 5 16 env53782 = env53783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53782 == env53783) = true)

theorem identity53783 : scanCanonicalize (H12AffineFastState.compose env53783 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound53783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53784 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,0,263,5172,2340,1025,1,4404,33,17,3,268,17,2048,5173,4097,2340,1284,32,257,33,5156,513]

theorem envBound53784 : H12AffineFastState.Bounded env53784 := by
  intro p hp
  have h : env53784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53783_53784 : H12AffineEnvironment.transform 13 5156 env53783 = env53784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env53783 == env53784) = true)

def env53785 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,269,2836,0,263,2820,2340,1025,1,3588,33,17,3,268,17,2048,2821,3889,2340,1284,32,257,33,2836,513]

theorem envBound53785 : H12AffineFastState.Bounded env53785 := by
  intro p hp
  have h : env53785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53784_53785 : H12AffineEnvironment.transform 11 3888 env53784 = env53785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env53784 == env53785) = true)

def env53786 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,269,1044,0,263,1028,1572,1025,1,260,33,17,3,268,17,1792,1029,49,1572,1284,32,257,33,1044,513]

theorem envBound53786 : H12AffineFastState.Bounded env53786 := by
  intro p hp
  have h : env53786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53785_53786 : H12AffineEnvironment.transform 10 1792 env53785 = env53786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env53785 == env53786) = true)

theorem identity53786 : scanCanonicalize (H12AffineFastState.compose env53786 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53787 : List Nat := [2,4,8,16,32,16,9,256,512,21,789,48,269,1,0,263,17,561,20,1,260,33,17,3,268,17,789,16,49,561,273,32,257,33,1,513]

theorem envBound53787 : H12AffineFastState.Bounded env53787 := by
  intro p hp
  have h : env53787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53786_53787 : H12AffineEnvironment.transform 9 21 env53786 = env53787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53786 == env53787) = true)

def env53788 : List Nat := [2,4,8,16,0,16,9,256,512,21,789,16,269,1,0,263,17,529,20,1,260,1,17,3,268,17,789,16,17,529,273,0,257,1,1,513]

theorem envBound53788 : H12AffineFastState.Bounded env53788 := by
  intro p hp
  have h : env53788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53787_53788 : H12AffineEnvironment.transform 4 0 env53787 = env53788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53787 == env53788) = true)

theorem identity53788 : scanCanonicalize (H12AffineFastState.compose env53788 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53789 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,10,269,1,0,263,11,523,14,1,260,1,11,3,268,11,783,10,11,523,267,0,257,1,1,513]

theorem envBound53789 : H12AffineFastState.Bounded env53789 := by
  intro p hp
  have h : env53789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53788_53789 : H12AffineEnvironment.transform 3 10 env53788 = env53789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53788 == env53789) = true)

def leafEnv53789 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,10,269,1,0,263,11,523,14,1,260,1,11,3,266,268,1,11,783,10,11,523,267,0,257,1,5,262,1,513,1,260,0]

def active53789 : List Nat := [0,1,2,7,8]

def tree53789 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53789 : H12WitnessSearch.Good tree53789 := H12GlobalWitnessIndex.good

theorem leafIdentity53789 : H12AffineFastState.composeSystem env53789 rootObs = leafEnv53789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53789 rootObs == leafEnv53789) = true)

theorem terminalChecked53789 : H12PackedTerminal.terminalCheckFast leafEnv53789 active53789 tree53789 = true := by decide +kernel

def env53790 : List Nat := [2,4,8,16,1,16,9,256,512,21,789,17,269,1,0,263,17,528,20,1,260,0,17,3,268,17,789,16,16,528,273,1,257,0,1,513]

theorem envBound53790 : H12AffineFastState.Bounded env53790 := by
  intro p hp
  have h : env53790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53787_53790 : H12AffineEnvironment.transform 4 1 env53787 = env53790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53787 == env53790) = true)

theorem identity53790 : scanCanonicalize (H12AffineFastState.compose env53790 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound53790 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53791 : List Nat := [2,4,8,16,1,16,9,256,276,21,1,17,269,1,0,263,17,260,20,1,260,0,17,3,268,17,1,16,16,260,273,1,257,0,1,277]

theorem envBound53791 : H12AffineFastState.Bounded env53791 := by
  intro p hp
  have h : env53791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53790_53791 : H12AffineEnvironment.transform 8 276 env53790 = env53791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env53790 == env53791) = true)

def leafEnv53791 : List Nat := [2,4,8,16,1,16,9,256,276,21,1,17,269,1,0,263,17,260,20,1,260,0,17,3,272,268,1,17,1,16,16,260,273,1,257,0,5,262,1,277,1,260,0]

def active53791 : List Nat := [0,1,2,3,7]

def tree53791 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53791 : H12WitnessSearch.Good tree53791 := H12GlobalWitnessIndex.good

theorem leafIdentity53791 : H12AffineFastState.composeSystem env53791 rootObs = leafEnv53791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53791 rootObs == leafEnv53791) = true)

theorem terminalChecked53791 : H12PackedTerminal.terminalCheckFast leafEnv53791 active53791 tree53791 = true := by decide +kernel

def env53792 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,269,1045,0,263,1029,1573,1025,1,261,33,17,3,268,17,1793,1028,48,1573,1284,32,257,33,1045,513]

theorem envBound53792 : H12AffineFastState.Bounded env53792 := by
  intro p hp
  have h : env53792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53785_53792 : H12AffineEnvironment.transform 10 1793 env53785 = env53792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53785 == env53792) = true)

theorem identity53792 : scanCanonicalize (H12AffineFastState.compose env53792 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53793 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1541,49,9,1045,0,3,1029,1573,1025,1,1,33,17,3,8,17,1541,1028,48,1573,1024,32,5,33,1045,513]

theorem envBound53793 : H12AffineFastState.Bounded env53793 := by
  intro p hp
  have h : env53793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53792_53793 : H12AffineEnvironment.transform 7 4 env53792 = env53793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53792 == env53793) = true)

def env53794 : List Nat := [2,4,8,16,32,16,9,4,512,52,561,49,9,33,0,3,49,529,53,1,1,33,17,3,8,17,561,48,48,529,52,32,5,33,33,513]

theorem envBound53794 : H12AffineFastState.Bounded env53794 := by
  intro p hp
  have h : env53794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53793_53794 : H12AffineEnvironment.transform 9 52 env53793 = env53794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53793 == env53794) = true)

theorem identity53794 : scanCanonicalize (H12AffineFastState.compose env53794 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53795 : List Nat := [2,4,8,16,32,16,9,4,16,52,33,49,9,33,0,3,49,1,53,1,1,33,17,3,8,17,33,48,48,1,52,32,5,33,33,17]

theorem envBound53795 : H12AffineFastState.Bounded env53795 := by
  intro p hp
  have h : env53795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53794_53795 : H12AffineEnvironment.transform 8 16 env53794 = env53795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53794 == env53795) = true)

def leafEnv53795 : List Nat := [2,4,8,16,32,16,9,4,16,52,33,49,9,33,0,3,49,1,53,1,1,33,17,3,53,8,1,17,33,48,48,1,52,32,5,33,5,2,33,17,1,1,0]

def active53795 : List Nat := [0,1,2,3,4]

def tree53795 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53795 : H12WitnessSearch.Good tree53795 := H12GlobalWitnessIndex.good

theorem leafIdentity53795 : H12AffineFastState.composeSystem env53795 rootObs = leafEnv53795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53795 rootObs == leafEnv53795) = true)

theorem terminalChecked53795 : H12PackedTerminal.terminalCheckFast leafEnv53795 active53795 tree53795 = true := by decide +kernel

def env53796 : List Nat := [2,4,8,16,32,16,9,4,512,53,560,49,9,32,0,3,48,528,52,1,1,33,17,3,8,17,560,49,48,528,53,32,5,33,32,513]

theorem envBound53796 : H12AffineFastState.Bounded env53796 := by
  intro p hp
  have h : env53796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53793_53796 : H12AffineEnvironment.transform 9 53 env53793 = env53796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53793 == env53796) = true)

theorem identity53796 : scanCanonicalize (H12AffineFastState.compose env53796 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53796 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53797 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,42,9,32,0,3,43,523,47,1,1,33,10,3,8,10,555,42,43,523,46,32,5,33,32,513]

theorem envBound53797 : H12AffineFastState.Bounded env53797 := by
  intro p hp
  have h : env53797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53796_53797 : H12AffineEnvironment.transform 3 11 env53796 = env53797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53796 == env53797) = true)

def leafEnv53797 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,42,9,32,0,3,43,523,47,1,1,33,10,3,47,8,1,10,555,42,43,523,46,32,5,33,5,2,32,513,1,1,0]

def active53797 : List Nat := [0,1,2,4,8]

def tree53797 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53797 : H12WitnessSearch.Good tree53797 := H12GlobalWitnessIndex.good

theorem leafIdentity53797 : H12AffineFastState.composeSystem env53797 rootObs = leafEnv53797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53797 rootObs == leafEnv53797) = true)

theorem terminalChecked53797 : H12PackedTerminal.terminalCheckFast leafEnv53797 active53797 tree53797 = true := by decide +kernel

def env53798 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,269,2837,0,263,2821,2340,1025,1,3589,33,17,3,268,17,2048,2820,3888,2340,1284,32,257,33,2837,513]

theorem envBound53798 : H12AffineFastState.Bounded env53798 := by
  intro p hp
  have h : env53798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53784_53798 : H12AffineEnvironment.transform 11 3889 env53784 = env53798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env53784 == env53798) = true)

def env53799 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,269,1045,0,263,1029,1572,1025,1,261,33,17,3,268,17,1792,1028,48,1572,1284,32,257,33,1045,513]

theorem envBound53799 : H12AffineFastState.Bounded env53799 := by
  intro p hp
  have h : env53799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53798_53799 : H12AffineEnvironment.transform 10 1792 env53798 = env53799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env53798 == env53799) = true)

theorem identity53799 : scanCanonicalize (H12AffineFastState.compose env53799 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53799 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53800 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1792,16,269,1045,0,263,1029,1541,1025,1,261,0,17,3,268,17,1792,1028,17,1541,1284,1,257,0,1045,513]

theorem envBound53800 : H12AffineFastState.Bounded env53800 := by
  intro p hp
  have h : env53800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53799_53800 : H12AffineEnvironment.transform 4 1 env53799 = env53800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53799 == env53800) = true)

def env53801 : List Nat := [2,4,8,16,1,16,9,256,512,20,788,16,269,1,0,263,17,529,21,1,261,0,17,3,268,17,788,16,17,529,272,1,257,0,1,513]

theorem envBound53801 : H12AffineFastState.Bounded env53801 := by
  intro p hp
  have h : env53801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53800_53801 : H12AffineEnvironment.transform 9 20 env53800 = env53801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53800 == env53801) = true)

theorem identity53801 : scanCanonicalize (H12AffineFastState.compose env53801 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53802 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,10,269,1,0,263,11,523,15,1,261,0,11,3,268,11,782,10,11,523,266,1,257,0,1,513]

theorem envBound53802 : H12AffineFastState.Bounded env53802 := by
  intro p hp
  have h : env53802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53801_53802 : H12AffineEnvironment.transform 3 10 env53801 = env53802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53801 == env53802) = true)

def leafEnv53802 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,10,269,1,0,263,11,523,15,1,261,0,11,3,267,268,1,11,782,10,11,523,266,1,257,0,5,262,1,513,1,261,0]

def active53802 : List Nat := [0,1,2,7,8]

def tree53802 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53802 : H12WitnessSearch.Good tree53802 := H12GlobalWitnessIndex.good

theorem leafIdentity53802 : H12AffineFastState.composeSystem env53802 rootObs = leafEnv53802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53802 rootObs == leafEnv53802) = true)

theorem terminalChecked53802 : H12PackedTerminal.terminalCheckFast leafEnv53802 active53802 tree53802 = true := by decide +kernel

def env53803 : List Nat := [2,4,8,16,1,16,9,256,512,21,789,16,269,0,0,263,16,528,20,1,261,0,17,3,268,17,789,17,17,528,273,1,257,0,0,513]

theorem envBound53803 : H12AffineFastState.Bounded env53803 := by
  intro p hp
  have h : env53803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53800_53803 : H12AffineEnvironment.transform 9 21 env53800 = env53803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53800 == env53803) = true)

theorem identity53803 : scanCanonicalize (H12AffineFastState.compose env53803 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound53803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53804 : List Nat := [2,4,8,16,1,16,9,256,277,21,0,16,269,0,0,263,16,261,20,1,261,0,17,3,268,17,0,17,17,261,273,1,257,0,0,276]

theorem envBound53804 : H12AffineFastState.Bounded env53804 := by
  intro p hp
  have h : env53804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53803_53804 : H12AffineEnvironment.transform 8 277 env53803 = env53804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env53803 == env53804) = true)

def leafEnv53804 : List Nat := [2,4,8,16,1,16,9,256,277,21,0,16,269,0,0,263,16,261,20,1,261,0,17,3,272,268,1,17,0,17,17,261,273,1,257,0,5,262,0,276,1,261,0]

def active53804 : List Nat := [0,1,2,3,7]

def tree53804 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53804 : H12WitnessSearch.Good tree53804 := H12GlobalWitnessIndex.good

theorem leafIdentity53804 : H12AffineFastState.composeSystem env53804 rootObs = leafEnv53804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53804 rootObs == leafEnv53804) = true)

theorem terminalChecked53804 : H12PackedTerminal.terminalCheckFast leafEnv53804 active53804 tree53804 = true := by decide +kernel

def env53805 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,269,1044,0,263,1028,1573,1025,1,260,33,17,3,268,17,1793,1029,49,1573,1284,32,257,33,1044,513]

theorem envBound53805 : H12AffineFastState.Bounded env53805 := by
  intro p hp
  have h : env53805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53798_53805 : H12AffineEnvironment.transform 10 1793 env53798 = env53805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53798 == env53805) = true)

theorem identity53805 : scanCanonicalize (H12AffineFastState.compose env53805 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound53805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53806 : List Nat := [2,4,8,16,32,16,9,256,512,304,561,48,269,292,0,263,308,789,305,1,260,33,17,3,268,17,561,309,49,789,52,32,257,33,292,513]

theorem envBound53806 : H12AffineFastState.Bounded env53806 := by
  intro p hp
  have h : env53806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53805_53806 : H12AffineEnvironment.transform 9 304 env53805 = env53806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env53805 == env53806) = true)

def env53807 : List Nat := [2,4,8,16,32,16,9,4,512,52,561,48,9,32,0,3,48,529,53,1,0,33,17,3,8,17,561,49,49,529,52,32,5,33,32,513]

theorem envBound53807 : H12AffineFastState.Bounded env53807 := by
  intro p hp
  have h : env53807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53806_53807 : H12AffineEnvironment.transform 7 4 env53806 = env53807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53806 == env53807) = true)

theorem identity53807 : scanCanonicalize (H12AffineFastState.compose env53807 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound53807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53808 : List Nat := [2,4,8,16,32,16,9,4,17,52,32,48,9,32,0,3,48,0,53,1,0,33,17,3,8,17,32,49,49,0,52,32,5,33,32,16]

theorem envBound53808 : H12AffineFastState.Bounded env53808 := by
  intro p hp
  have h : env53808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53807_53808 : H12AffineEnvironment.transform 8 17 env53807 = env53808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env53807 == env53808) = true)

def leafEnv53808 : List Nat := [2,4,8,16,32,16,9,4,17,52,32,48,9,32,0,3,48,0,53,1,0,33,17,3,53,8,1,17,32,49,49,0,52,32,5,33,5,2,32,16,1,0,0]

def active53808 : List Nat := [0,1,2,3,4]

def tree53808 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53808 : H12WitnessSearch.Good tree53808 := H12GlobalWitnessIndex.good

theorem leafIdentity53808 : H12AffineFastState.composeSystem env53808 rootObs = leafEnv53808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53808 rootObs == leafEnv53808) = true)

theorem terminalChecked53808 : H12PackedTerminal.terminalCheckFast leafEnv53808 active53808 tree53808 = true := by decide +kernel

def env53809 : List Nat := [2,4,8,16,32,16,9,5,512,53,561,48,8,33,0,2,49,528,52,1,1,33,17,3,9,17,561,48,49,528,52,32,4,33,33,513]

theorem envBound53809 : H12AffineFastState.Bounded env53809 := by
  intro p hp
  have h : env53809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53806_53809 : H12AffineEnvironment.transform 7 5 env53806 = env53809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53806 == env53809) = true)

theorem identity53809 : scanCanonicalize (H12AffineFastState.compose env53809 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53809 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53810 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,43,8,33,0,2,42,523,47,1,1,33,10,3,9,10,554,43,42,523,47,32,4,33,33,513]

theorem envBound53810 : H12AffineFastState.Bounded env53810 := by
  intro p hp
  have h : env53810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53809_53810 : H12AffineEnvironment.transform 3 11 env53809 = env53810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53809 == env53810) = true)

def leafEnv53810 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,43,8,33,0,2,42,523,47,1,1,33,10,3,46,9,1,10,554,43,42,523,47,32,4,33,5,3,33,513,1,1,0]

def active53810 : List Nat := [0,1,2,4,8]

def tree53810 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53810 : H12WitnessSearch.Good tree53810 := H12GlobalWitnessIndex.good

theorem leafIdentity53810 : H12AffineFastState.composeSystem env53810 rootObs = leafEnv53810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53810 rootObs == leafEnv53810) = true)

theorem terminalChecked53810 : H12PackedTerminal.terminalCheckFast leafEnv53810 active53810 tree53810 = true := by decide +kernel

def env53811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650854,2428274,10507600,8683536,8719718,6679615,257,10833235,10857599,8661561]

theorem envBound53811 : H12AffineFastState.Bounded env53811 := by
  intro p hp
  have h : env53811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53744_53811 : H12AffineEnvironment.transform 16 16401 env53744 = env53811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env53744 == env53811) = true)

theorem identity53811 : scanCanonicalize (H12AffineFastState.compose env53811 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound53811 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,297335,8193,65,4262263,2428274,2118977,294913,331127,6679615,257,2444610,2468974,272936]

theorem envBound53812 : H12AffineFastState.Bounded env53812 := by
  intro p hp
  have h : env53812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53811_53812 : H12AffineEnvironment.transform 22 17 env53811 = env53812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env53811 == env53812) = true)

def env53813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,17,41311,8193,65,4262263,2172250,2118977,43049,75103,6407191,257,2188650,2196550,512]

theorem envBound53813 : H12AffineFastState.Bounded env53813 := by
  intro p hp
  have h : env53813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53812_53813 : H12AffineEnvironment.transform 17 10280 env53812 = env53813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53812 == env53813) = true)

theorem identity53813 : scanCanonicalize (H12AffineFastState.compose env53813 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 116067) := by decide +kernel

theorem selectedBound53813 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,116067,4194304,17,41311,8193,65,4262263,57401,102434,43049,75103,4194676,257,40969,16677,512]

theorem envBound53814 : H12AffineFastState.Bounded env53814 := by
  intro p hp
  have h : env53814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53813_53814 : H12AffineEnvironment.transform 20 116067 env53813 = env53814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 116067 env53813 == env53814) = true)

theorem identity53814 : scanCanonicalize (H12AffineFastState.compose env53814 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound53814 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env53815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,10280,1025,32769,17461,4194304,17,41311,8193,65,4229153,57401,4468,43049,41993,4194676,257,40969,16677,512]

theorem envBound53815 : H12AffineFastState.Bounded env53815 := by
  intro p hp
  have h : env53815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53814_53815 : H12AffineEnvironment.transform 15 33110 env53814 = env53815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env53814 == env53815) = true)

theorem identity53815 : scanCanonicalize (H12AffineFastState.compose env53815 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 26665) := by decide +kernel

theorem selectedBound53815 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,10280,1025,32769,17461,26665,17,41311,8193,65,57352,57401,4468,43049,41993,26973,257,40969,16677,512]

theorem envBound53816 : H12AffineFastState.Bounded env53816 := by
  intro p hp
  have h : env53816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53815_53816 : H12AffineEnvironment.transform 21 26665 env53815 = env53816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 26665 env53815 == env53816) = true)

theorem identity53816 : scanCanonicalize (H12AffineFastState.compose env53816 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13436) := by decide +kernel

theorem selectedBound53816 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env53817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13436,32768,33110,13421,10280,1025,32769,12361,7253,17,41311,8193,65,38004,37957,4468,43049,41993,7457,257,40969,13657,512]

theorem envBound53817 : H12AffineFastState.Bounded env53817 := by
  intro p hp
  have h : env53817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53816_53817 : H12AffineEnvironment.transform 13 13436 env53816 = env53817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13436 env53816 == env53817) = true)

theorem identity53817 : scanCanonicalize (H12AffineFastState.compose env53817 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 6161) := by decide +kernel

theorem selectedBound53817 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13436,6161,6471,13421,10280,1025,6160,12361,7253,17,14670,8193,65,3173,3156,4468,12344,15384,7457,257,14360,13657,512]

theorem envBound53818 : H12AffineFastState.Bounded env53818 := by
  intro p hp
  have h : env53818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53817_53818 : H12AffineEnvironment.transform 14 6161 env53817 = env53818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6161 env53817 == env53818) = true)

theorem identity53818 : scanCanonicalize (H12AffineFastState.compose env53818 (packedSelected [9,14,22] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound53818 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env53819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,8192,10249,1124,1330,10264,10280,1025,1125,11324,32,17,9531,8193,65,3173,3156,3329,11341,8301,340,257,9325,10540,512]

theorem envBound53819 : H12AffineFastState.Bounded env53819 := by
  intro p hp
  have h : env53819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53818_53819 : H12AffineEnvironment.transform 11 3189 env53818 = env53819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env53818 == env53819) = true)

theorem identity53819 : scanCanonicalize (H12AffineFastState.compose env53819 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53819 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env53820 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,3077,8192,10249,1044,1330,10264,10280,1025,1045,11324,32,17,9531,8193,49,3093,3108,3329,11325,8221,292,257,9245,10540,512]

theorem envBound53820 : H12AffineFastState.Bounded env53820 := by
  intro p hp
  have h : env53820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53819_53820 : H12AffineEnvironment.transform 5 48 env53819 = env53820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53819 == env53820) = true)

theorem identity53820 : scanCanonicalize (H12AffineFastState.compose env53820 (packedSelected [3,5,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound53820 : packedSelected [3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env53821 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,3077,9,2048,1044,1330,2065,2081,1025,1045,3125,32,17,1330,8,49,3093,3108,3329,3124,20,292,257,1044,2341,512]

theorem envBound53821 : H12AffineFastState.Bounded env53821 := by
  intro p hp
  have h : env53821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53820_53821 : H12AffineEnvironment.transform 12 9 env53820 = env53821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env53820 == env53821) = true)

theorem identity53821 : scanCanonicalize (H12AffineFastState.compose env53821 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53821 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env53822 : List Nat := [2,4,8,16,32,48,9,256,512,272,2048,2325,9,2048,260,34,2065,2081,273,261,2341,32,17,34,8,49,2309,2356,2065,2340,20,292,257,260,2341,512]

theorem envBound53822 : H12AffineFastState.Bounded env53822 := by
  intro p hp
  have h : env53822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53821_53822 : H12AffineEnvironment.transform 9 272 env53821 = env53822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53821 == env53822) = true)

theorem identity53822 : scanCanonicalize (H12AffineFastState.compose env53822 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53822 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53823 : List Nat := [2,4,8,16,32,48,9,5,512,21,2048,2064,9,2048,1,34,2065,2081,20,0,2080,32,17,34,8,49,2048,2097,2065,2081,20,33,4,1,2080,512]

theorem envBound53823 : H12AffineFastState.Bounded env53823 := by
  intro p hp
  have h : env53823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53822_53823 : H12AffineEnvironment.transform 7 5 env53822 = env53823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53822 == env53823) = true)

theorem identity53823 : scanCanonicalize (H12AffineFastState.compose env53823 (packedSelected [2,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53823 : packedSelected [2,15] rootPS < 2^1333 := by decide +kernel

def env53824 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2064,9,2048,1,3,2065,2048,20,0,2049,1,17,3,8,16,2048,2064,2065,2048,20,0,4,1,2049,512]

theorem envBound53824 : H12AffineFastState.Bounded env53824 := by
  intro p hp
  have h : env53824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53823_53824 : H12AffineEnvironment.transform 4 1 env53823 = env53824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53823 == env53824) = true)

theorem identity53824 : scanCanonicalize (H12AffineFastState.compose env53824 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53824 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53825 : List Nat := [2,4,8,16,1,17,9,5,0,21,2048,2064,9,2048,1,3,2065,2048,20,0,2049,1,17,3,8,16,2048,2064,2065,2048,20,0,4,1,2049,0]

theorem envBound53825 : H12AffineFastState.Bounded env53825 := by
  intro p hp
  have h : env53825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53824_53825 : H12AffineEnvironment.transform 8 0 env53824 = env53825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53824 == env53825) = true)

theorem identity53825 : scanCanonicalize (H12AffineFastState.compose env53825 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound53825 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53826 : List Nat := [2,4,8,16,1,17,9,5,0,21,31,15,9,31,1,3,14,31,20,0,30,1,17,3,8,16,31,15,14,31,20,0,4,1,30,0]

theorem envBound53826 : H12AffineFastState.Bounded env53826 := by
  intro p hp
  have h : env53826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53825_53826 : H12AffineEnvironment.transform 10 31 env53825 = env53826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env53825 == env53826) = true)

def leafEnv53826 : List Nat := [2,4,8,16,1,17,9,5,0,21,31,15,9,31,1,3,14,31,20,0,30,1,17,3,21,8,1,16,31,15,14,31,20,0,4,1,5,2,30,0,1,31,0]

def active53826 : List Nat := [0,1,2,3]

def tree53826 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53826 : H12WitnessSearch.Good tree53826 := H12GlobalWitnessIndex.good

theorem leafIdentity53826 : H12AffineFastState.composeSystem env53826 rootObs = leafEnv53826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53826 rootObs == leafEnv53826) = true)

theorem terminalChecked53826 : H12PackedTerminal.terminalCheckFast leafEnv53826 active53826 tree53826 = true := by decide +kernel

def env53827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41310,8193,65,4262263,2172251,2118977,43048,75102,6407190,257,2188651,2196551,513]

theorem envBound53827 : H12AffineFastState.Bounded env53827 := by
  intro p hp
  have h : env53827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53812_53827 : H12AffineEnvironment.transform 17 10281 env53812 = env53827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53812 == env53827) = true)

theorem identity53827 : scanCanonicalize (H12AffineFastState.compose env53827 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound53827 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env53828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115735,4194304,17,41310,8193,65,4262263,57676,102742,43048,75102,4194305,257,41340,16464,513]

theorem envBound53828 : H12AffineFastState.Bounded env53828 := by
  intro p hp
  have h : env53828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53827_53828 : H12AffineEnvironment.transform 20 115735 env53827 = env53828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env53827 == env53828) = true)

theorem identity53828 : scanCanonicalize (H12AffineFastState.compose env53828 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound53828 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env53829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115735,8573,17,41310,8193,65,75786,57676,102742,43048,75102,8572,257,41340,16464,513]

theorem envBound53829 : H12AffineFastState.Bounded env53829 := by
  intro p hp
  have h : env53829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53828_53829 : H12AffineEnvironment.transform 21 8573 env53828 = env53829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env53828 == env53829) = true)

theorem identity53829 : scanCanonicalize (H12AffineFastState.compose env53829 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound53829 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env53830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1025,32769,25629,8573,17,41310,8193,65,34816,57676,12636,43048,34132,8572,257,41340,16464,513]

theorem envBound53830 : H12AffineFastState.Bounded env53830 := by
  intro p hp
  have h : env53830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53829_53830 : H12AffineEnvironment.transform 15 40970 env53829 = env53830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env53829 == env53830) = true)

theorem identity53830 : scanCanonicalize (H12AffineFastState.compose env53830 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53830 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53831 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1025,32769,25629,8492,17,41231,8193,16,34816,57629,12557,43048,34053,8493,257,41261,16385,513]

theorem envBound53831 : H12AffineFastState.Bounded env53831 := by
  intro p hp
  have h : env53831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53830_53831 : H12AffineEnvironment.transform 5 17 env53830 = env53831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53830 == env53831) = true)

theorem identity53831 : scanCanonicalize (H12AffineFastState.compose env53831 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53832 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,33030,16401,2341,1025,32769,17681,32,17,32771,269,16,34816,49169,4097,35108,34053,33,257,32801,16385,513]

theorem envBound53832 : H12AffineFastState.Bounded env53832 := by
  intro p hp
  have h : env53832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53831_53832 : H12AffineEnvironment.transform 12 268 env53831 = env53832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53831 == env53832) = true)

theorem identity53832 : scanCanonicalize (H12AffineFastState.compose env53832 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53832 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53833 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,263,16401,2341,1025,0,17681,32,17,2,269,16,2049,16400,4097,2341,1284,33,257,32,16385,513]

theorem envBound53833 : H12AffineFastState.Bounded env53833 := by
  intro p hp
  have h : env53833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53832_53833 : H12AffineEnvironment.transform 14 1 env53832 = env53833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53832 == env53833) = true)

theorem identity53833 : scanCanonicalize (H12AffineFastState.compose env53833 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4389) := by decide +kernel

theorem selectedBound53833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53834 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4389,1,263,4404,2341,1025,0,5172,32,17,2,269,16,2049,4405,4097,2341,1284,33,257,32,4388,513]

theorem envBound53834 : H12AffineFastState.Bounded env53834 := by
  intro p hp
  have h : env53834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53833_53834 : H12AffineEnvironment.transform 13 4389 env53833 = env53834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4389 env53833 == env53834) = true)

theorem identity53834 : scanCanonicalize (H12AffineFastState.compose env53834 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound53834 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53835 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,513,268,804,1,263,821,2341,1025,0,1589,32,17,2,269,16,2049,820,512,2341,1284,33,257,32,805,513]

theorem envBound53835 : H12AffineFastState.Bounded env53835 := by
  intro p hp
  have h : env53835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53834_53835 : H12AffineEnvironment.transform 11 513 env53834 = env53835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env53834 == env53835) = true)

theorem identity53835 : scanCanonicalize (H12AffineFastState.compose env53835 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound53835 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53836 : List Nat := [2,4,8,16,32,17,9,256,512,769,2048,513,268,804,1,263,821,2341,768,0,308,32,17,2,269,16,2049,820,512,2341,517,33,257,32,805,513]

theorem envBound53836 : H12AffineFastState.Bounded env53836 := by
  intro p hp
  have h : env53836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53835_53836 : H12AffineEnvironment.transform 9 769 env53835 = env53836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env53835 == env53836) = true)

theorem identity53836 : scanCanonicalize (H12AffineFastState.compose env53836 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound53836 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53837 : List Nat := [2,4,8,16,32,17,9,52,512,565,2048,513,56,528,1,51,513,2065,564,0,0,32,17,2,57,16,2049,512,512,2065,517,33,53,32,529,513]

theorem envBound53837 : H12AffineFastState.Bounded env53837 := by
  intro p hp
  have h : env53837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53836_53837 : H12AffineEnvironment.transform 7 52 env53836 = env53837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env53836 == env53837) = true)

theorem identity53837 : scanCanonicalize (H12AffineFastState.compose env53837 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound53837 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53838 : List Nat := [2,4,8,16,32,17,9,52,512,565,16,513,56,528,1,51,513,1,564,0,0,32,17,2,57,16,17,512,512,1,517,33,53,32,529,513]

theorem envBound53838 : H12AffineFastState.Bounded env53838 := by
  intro p hp
  have h : env53838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53837_53838 : H12AffineEnvironment.transform 10 16 env53837 = env53838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env53837 == env53838) = true)

theorem identity53838 : scanCanonicalize (H12AffineFastState.compose env53838 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound53838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53839 : List Nat := [2,4,8,16,32,17,9,52,33,20,16,32,56,49,1,51,32,1,21,0,0,32,17,2,57,16,17,33,33,1,36,33,53,32,48,32]

theorem envBound53839 : H12AffineFastState.Bounded env53839 := by
  intro p hp
  have h : env53839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53838_53839 : H12AffineEnvironment.transform 8 33 env53838 = env53839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env53838 == env53839) = true)

def env53840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound53840 : H12AffineFastState.Bounded env53840 := by
  intro p hp
  have h : env53840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50849_53840 : H12AffineEnvironment.transform 31 145662401 env50849 = env53840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env50849 == env53840) = true)

def env53841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound53841 : H12AffineFastState.Bounded env53841 := by
  intro p hp
  have h : env53841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53840_53841 : H12AffineEnvironment.transform 29 155254784 env53840 = env53841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env53840 == env53841) = true)

def env53842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound53842 : H12AffineFastState.Bounded env53842 := by
  intro p hp
  have h : env53842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53841_53842 : H12AffineEnvironment.transform 25 64 env53841 = env53842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env53841 == env53842) = true)

def env53843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound53843 : H12AffineFastState.Bounded env53843 := by
  intro p hp
  have h : env53843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53842_53843 : H12AffineEnvironment.transform 26 30393344 env53842 = env53843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env53842 == env53843) = true)

def env53844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound53844 : H12AffineFastState.Bounded env53844 := by
  intro p hp
  have h : env53844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53843_53844 : H12AffineEnvironment.transform 18 1024 env53843 = env53844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env53843 == env53844) = true)

theorem identity53844 : scanCanonicalize (H12AffineFastState.compose env53844 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8430023) := by decide +kernel

theorem selectedBound53844 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8430023,8328,64,4678087,10560842,10507601,8830976,75223,14795782,256,2188651,2196687,513]

theorem envBound53845 : H12AffineFastState.Bounded env53845 := by
  intro p hp
  have h : env53845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53844_53845 : H12AffineEnvironment.transform 23 8430023 env53844 = env53845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8430023 env53844 == env53845) = true)

def env53846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8192,64,4677967,10560842,10507601,8830976,75103,14795782,256,2188651,2196551,513]

theorem envBound53846 : H12AffineFastState.Bounded env53846 := by
  intro p hp
  have h : env53846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53845_53846 : H12AffineEnvironment.transform 6 8 env53845 = env53846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53845 == env53846) = true)

theorem identity53846 : scanCanonicalize (H12AffineFastState.compose env53846 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound53846 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env53847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,8388608,8429903,8192,64,4456788,10560842,10507601,8757275,75103,14795782,256,2188651,2196551,513]

theorem envBound53847 : H12AffineFastState.Bounded env53847 := by
  intro p hp
  have h : env53847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53846_53847 : H12AffineEnvironment.transform 16 90139 env53846 = env53847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env53846 == env53847) = true)

def env53848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,16,41311,8192,64,4456788,2172250,2118977,368651,75103,6407190,256,2188651,2196551,513]

theorem envBound53848 : H12AffineFastState.Bounded env53848 := by
  intro p hp
  have h : env53848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53847_53848 : H12AffineEnvironment.transform 22 16 env53847 = env53848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env53847 == env53848) = true)

theorem identity53848 : scanCanonicalize (H12AffineFastState.compose env53848 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46093) := by decide +kernel

theorem selectedBound53848 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,46093,4194304,16,41311,8192,64,4456788,102743,57676,368651,75103,4288539,256,119142,77898,513]

theorem envBound53849 : H12AffineFastState.Bounded env53849 := by
  intro p hp
  have h : env53849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53848_53849 : H12AffineEnvironment.transform 20 46093 env53848 = env53849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46093 env53848 == env53849) = true)

theorem identity53849 : scanCanonicalize (H12AffineFastState.compose env53849 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53849 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env53850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,262144,1024,8540,5456,4194304,16,2,8192,64,4456788,77834,16401,328022,75103,4288539,256,94267,77898,513]

theorem envBound53850 : H12AffineFastState.Bounded env53850 := by
  intro p hp
  have h : env53850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53849_53850 : H12AffineEnvironment.transform 14 8541 env53849 = env53850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53849 == env53850) = true)

def env53851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,262144,1024,8540,5456,4194304,16,2,8192,64,4456788,77834,4097,328022,75103,4268043,256,73771,77898,513]

theorem envBound53851 : H12AffineFastState.Bounded env53851 := by
  intro p hp
  have h : env53851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53850_53851 : H12AffineEnvironment.transform 13 4112 env53850 = env53851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env53850 == env53851) = true)

theorem identity53851 : scanCanonicalize (H12AffineFastState.compose env53851 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound53851 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env53852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,262144,1024,8540,5456,33,16,2,8192,64,262517,77834,4097,328022,75103,73770,256,73771,77898,513]

theorem envBound53852 : H12AffineFastState.Bounded env53852 := by
  intro p hp
  have h : env53852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53851_53852 : H12AffineEnvironment.transform 21 33 env53851 = env53852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env53851 == env53852) = true)

theorem identity53852 : scanCanonicalize (H12AffineFastState.compose env53852 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound53852 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env53853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,67618,1024,8540,5456,33,16,2,8192,64,67927,77834,4097,2420,75103,73770,256,73771,77898,513]

theorem envBound53853 : H12AffineFastState.Bounded env53853 := by
  intro p hp
  have h : env53853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53852_53853 : H12AffineEnvironment.transform 17 67618 env53852 = env53853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env53852 == env53853) = true)

theorem identity53853 : scanCanonicalize (H12AffineFastState.compose env53853 (packedSelected [0,4,6,7,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound53853 : packedSelected [0,4,6,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env53854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1305,4112,1092,65536,70930,67618,1024,1093,5456,33,16,2,1305,64,67927,70931,4097,2420,65606,66867,256,66866,70995,513]

theorem envBound53854 : H12AffineFastState.Bounded env53854 := by
  intro p hp
  have h : env53854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53853_53854 : H12AffineEnvironment.transform 12 1305 env53853 = env53854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env53853 == env53854) = true)

theorem identity53854 : scanCanonicalize (H12AffineFastState.compose env53854 (packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1298) := by decide +kernel

theorem selectedBound53854 : packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1305,4112,1092,1298,4096,3376,1024,1093,5456,33,16,2,1305,64,3141,4097,4097,2420,1364,33,256,32,4161,513]

theorem envBound53855 : H12AffineFastState.Bounded env53855 := by
  intro p hp
  have h : env53855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53854_53855 : H12AffineEnvironment.transform 15 1298 env53854 = env53855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1298 env53854 == env53855) = true)

def env53856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77834,262144,1024,8540,5456,4194304,16,2,8192,64,4456788,77834,4096,328022,75103,4268042,256,73770,77898,513]

theorem envBound53856 : H12AffineFastState.Bounded env53856 := by
  intro p hp
  have h : env53856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53850_53856 : H12AffineEnvironment.transform 13 4113 env53850 = env53856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env53850 == env53856) = true)

theorem identity53856 : scanCanonicalize (H12AffineFastState.compose env53856 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53856 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,4096,262144,1024,8540,5456,4194304,16,2,8192,64,4456788,4096,4096,270684,1365,4194304,256,32,4160,513]

theorem envBound53857 : H12AffineFastState.Bounded env53857 := by
  intro p hp
  have h : env53857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53856_53857 : H12AffineEnvironment.transform 15 8202 env53856 = env53857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53856 == env53857) = true)

theorem identity53857 : scanCanonicalize (H12AffineFastState.compose env53857 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound53857 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,4096,262144,1024,8540,5456,113,16,2,8192,64,262437,4096,4096,270684,1365,113,256,32,4160,513]

theorem envBound53858 : H12AffineFastState.Bounded env53858 := by
  intro p hp
  have h : env53858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53857_53858 : H12AffineEnvironment.transform 21 113 env53857 = env53858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env53857 == env53858) = true)

theorem identity53858 : scanCanonicalize (H12AffineFastState.compose env53858 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound53858 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env53859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,4096,2420,1024,8540,5456,113,16,2,8192,64,2129,4096,4096,10280,1365,113,256,32,4160,513]

theorem envBound53859 : H12AffineFastState.Bounded env53859 := by
  intro p hp
  have h : env53859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53858_53859 : H12AffineEnvironment.transform 17 2420 env53858 = env53859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env53858 == env53859) = true)

theorem identity53859 : scanCanonicalize (H12AffineFastState.compose env53859 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53859 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env53860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,4113,80,263,4096,2420,1024,81,5456,113,16,2,269,64,2129,4096,4096,2341,1365,113,256,32,4160,513]

theorem envBound53860 : H12AffineFastState.Bounded env53860 := by
  intro p hp
  have h : env53860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53859_53860 : H12AffineEnvironment.transform 12 269 env53859 = env53860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53859 == env53860) = true)

theorem identity53860 : scanCanonicalize (H12AffineFastState.compose env53860 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound53860 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53861 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,4113,80,263,4096,2420,320,81,4112,113,16,2,269,64,2129,4096,4096,2341,21,113,256,32,4160,513]

theorem envBound53861 : H12AffineFastState.Bounded env53861 := by
  intro p hp
  have h : env53861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53860_53861 : H12AffineEnvironment.transform 9 320 env53860 = env53861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53860 == env53861) = true)

theorem identity53861 : scanCanonicalize (H12AffineFastState.compose env53861 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53862 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4113,0,263,4096,2340,272,1,4112,33,16,2,269,16,2049,4096,4096,2341,21,33,256,32,4112,513]

theorem envBound53862 : H12AffineFastState.Bounded env53862 := by
  intro p hp
  have h : env53862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53861_53862 : H12AffineEnvironment.transform 5 16 env53861 = env53862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53861 == env53862) = true)

theorem identity53862 : scanCanonicalize (H12AffineFastState.compose env53862 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound53862 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53863 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2064,269,2049,0,263,2064,2340,272,1,2048,33,16,2,269,16,2049,2064,2064,2341,21,33,256,32,2048,513]

theorem envBound53863 : H12AffineFastState.Bounded env53863 := by
  intro p hp
  have h : env53863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53862_53863 : H12AffineEnvironment.transform 11 2064 env53862 = env53863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env53862 == env53863) = true)

theorem identity53863 : scanCanonicalize (H12AffineFastState.compose env53863 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53863 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53864 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,40,2049,0,34,2064,2049,53,1,2048,33,16,2,40,16,2049,2064,2064,2048,21,33,37,32,2048,513]

theorem envBound53864 : H12AffineFastState.Bounded env53864 := by
  intro p hp
  have h : env53864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53863_53864 : H12AffineEnvironment.transform 7 37 env53863 = env53864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53863 == env53864) = true)

theorem identity53864 : scanCanonicalize (H12AffineFastState.compose env53864 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound53864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53865 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,40,48,0,34,33,48,53,1,49,33,16,2,40,16,48,33,33,49,21,33,37,32,49,513]

theorem envBound53865 : H12AffineFastState.Bounded env53865 := by
  intro p hp
  have h : env53865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53864_53865 : H12AffineEnvironment.transform 10 49 env53864 = env53865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env53864 == env53865) = true)

def leafEnv53865 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,40,48,0,34,33,48,53,1,49,33,16,2,21,40,1,16,48,33,33,49,21,33,37,32,4,34,49,513,1,48,0]

def active53865 : List Nat := [0,1,2,3,4,8]

def tree53865 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53865 : H12WitnessSearch.Good tree53865 := H12GlobalWitnessIndex.good

theorem leafIdentity53865 : H12AffineFastState.composeSystem env53865 rootObs = leafEnv53865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53865 rootObs == leafEnv53865) = true)

theorem terminalChecked53865 : H12PackedTerminal.terminalCheckFast leafEnv53865 active53865 tree53865 = true := by decide +kernel

def env53866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456788,2172251,2118976,368650,75103,6407191,256,2188651,2196551,513]

theorem envBound53866 : H12AffineFastState.Bounded env53866 := by
  intro p hp
  have h : env53866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53847_53866 : H12AffineEnvironment.transform 22 17 env53847 = env53866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env53847 == env53866) = true)

theorem identity53866 : scanCanonicalize (H12AffineFastState.compose env53866 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound53866 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90139,262144,1024,29004,2097152,4194304,17,20499,8192,64,4456788,2172251,2118976,348487,75103,6370650,256,2188651,2192650,513]

theorem envBound53867 : H12AffineFastState.Bounded env53867 := by
  intro p hp
  have h : env53867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53866_53867 : H12AffineEnvironment.transform 14 29005 env53866 = env53867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env53866 == env53867) = true)

theorem identity53867 : scanCanonicalize (H12AffineFastState.compose env53867 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound53867 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env53868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,2097152,4194304,17,20499,8192,64,4225389,2172251,2118976,76158,75103,6370650,256,2188651,2192650,513]

theorem envBound53868 : H12AffineFastState.Bounded env53868 := by
  intro p hp
  have h : env53868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53867_53868 : H12AffineEnvironment.transform 17 30777 env53867 = env53868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env53867 == env53868) = true)

def env53869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5456,4194304,17,20499,8192,64,4225389,77835,16400,76158,75103,4268042,256,94267,90202,513]

theorem envBound53869 : H12AffineFastState.Bounded env53869 := by
  intro p hp
  have h : env53869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53868_53869 : H12AffineEnvironment.transform 20 5456 env53868 = env53869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env53868 == env53869) = true)

theorem identity53869 : scanCanonicalize (H12AffineFastState.compose env53869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound53869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5456,20528,17,20499,8192,64,10589,77835,16400,76158,75103,94266,256,94267,90202,513]

theorem envBound53870 : H12AffineFastState.Bounded env53870 := by
  intro p hp
  have h : env53870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53869_53870 : H12AffineEnvironment.transform 21 20528 env53869 = env53870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env53869 == env53870) = true)

theorem identity53870 : scanCanonicalize (H12AffineFastState.compose env53870 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53870 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30777,1024,29004,5456,20528,17,20499,8192,64,10589,4096,16400,2421,1364,20529,256,20528,16465,513]

theorem envBound53871 : H12AffineFastState.Bounded env53871 := by
  intro p hp
  have h : env53871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53870_53871 : H12AffineEnvironment.transform 15 8203 env53870 = env53871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53870 == env53871) = true)

theorem identity53871 : scanCanonicalize (H12AffineFastState.compose env53871 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound53871 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,81,8203,12556,2341,1024,80,5456,8492,17,8463,8192,64,10589,4096,12556,2421,1364,8493,256,8492,12621,513]

theorem envBound53872 : H12AffineFastState.Bounded env53872 := by
  intro p hp
  have h : env53872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53871_53872 : H12AffineEnvironment.transform 13 12572 env53871 = env53872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env53871 == env53872) = true)

theorem identity53872 : scanCanonicalize (H12AffineFastState.compose env53872 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53872 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4161,81,342,4177,2341,1024,80,5456,113,17,82,349,64,2048,4096,4177,2421,1364,112,256,113,4112,513]

theorem envBound53873 : H12AffineFastState.Bounded env53873 := by
  intro p hp
  have h : env53873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53872_53873 : H12AffineEnvironment.transform 12 349 env53872 = env53873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53872 == env53873) = true)

theorem identity53873 : scanCanonicalize (H12AffineFastState.compose env53873 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound53873 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,349,1076,81,342,1060,2341,1024,80,293,113,17,82,349,64,2048,1141,1060,2421,1364,112,256,113,1125,513]

theorem envBound53874 : H12AffineFastState.Bounded env53874 := by
  intro p hp
  have h : env53874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53873_53874 : H12AffineEnvironment.transform 11 1141 env53873 = env53874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env53873 == env53874) = true)

def env53875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5457,4194304,17,20499,8192,64,4225389,77834,16401,76158,75103,4268043,256,94266,90203,513]

theorem envBound53875 : H12AffineFastState.Bounded env53875 := by
  intro p hp
  have h : env53875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53868_53875 : H12AffineEnvironment.transform 20 5457 env53868 = env53875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env53868 == env53875) = true)

theorem identity53875 : scanCanonicalize (H12AffineFastState.compose env53875 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound53875 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90139,30777,1024,29004,5457,32,17,20499,8192,64,31053,77834,16401,76158,75103,73771,256,94266,90203,513]

theorem envBound53876 : H12AffineFastState.Bounded env53876 := by
  intro p hp
  have h : env53876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53875_53876 : H12AffineEnvironment.transform 21 32 env53875 = env53876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env53875 == env53876) = true)

theorem identity53876 : scanCanonicalize (H12AffineFastState.compose env53876 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound53876 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,10281,1024,8540,5457,32,17,3,8192,64,10589,77834,4097,76158,75103,73771,256,73770,77899,513]

theorem envBound53877 : H12AffineFastState.Bounded env53877 := by
  intro p hp
  have h : env53877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53876_53877 : H12AffineEnvironment.transform 13 4112 env53876 = env53877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env53876 == env53877) = true)

theorem identity53877 : scanCanonicalize (H12AffineFastState.compose env53877 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound53877 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env53878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7544,4112,7205,65536,68979,5457,1024,7204,5457,32,17,3,7544,64,5157,68978,4097,70662,71719,73043,256,73042,68915,513]

theorem envBound53878 : H12AffineFastState.Bounded env53878 := by
  intro p hp
  have h : env53878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53877_53878 : H12AffineEnvironment.transform 12 7544 env53877 = env53878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env53877 == env53878) = true)

theorem identity53878 : scanCanonicalize (H12AffineFastState.compose env53878 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound53878 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env53879 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,6429,4112,6208,65536,67862,4404,101,6209,4404,32,17,3,6429,64,4160,67863,4097,69731,71719,71990,256,71991,67926,513]

theorem envBound53879 : H12AffineFastState.Bounded env53879 := by
  intro p hp
  have h : env53879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53878_53879 : H12AffineEnvironment.transform 9 101 env53878 = env53879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env53878 == env53879) = true)

def env53880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8193,64,4677966,10560842,10507601,8830976,75102,14795782,256,2188651,2196550,513]

theorem envBound53880 : H12AffineFastState.Bounded env53880 := by
  intro p hp
  have h : env53880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53845_53880 : H12AffineEnvironment.transform 6 9 env53845 = env53880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53845 == env53880) = true)

def env53881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8193,64,4677966,2172250,2118977,442384,75102,6407190,256,2188651,2196550,513]

theorem envBound53881 : H12AffineFastState.Bounded env53881 := by
  intro p hp
  have h : env53881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53880_53881 : H12AffineEnvironment.transform 22 16 env53880 = env53881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env53880 == env53881) = true)

def env53882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8193,64,4677966,115014,45405,442384,75102,4268042,256,98679,90202,513]

theorem envBound53882 : H12AffineFastState.Bounded env53882 := by
  intro p hp
  have h : env53882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53881_53882 : H12AffineEnvironment.transform 20 58396 env53881 = env53882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env53881 == env53882) = true)

def env53883 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8193,16,4677918,114966,45325,442384,75022,4268042,256,98599,90122,513]

theorem envBound53883 : H12AffineFastState.Bounded env53883 := by
  intro p hp
  have h : env53883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53882_53883 : H12AffineEnvironment.transform 5 16 env53882 = env53883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53882 == env53883) = true)

def env53884 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8193,16,4409654,114966,45325,190520,75022,4268042,256,98599,90122,513]

theorem envBound53884 : H12AffineFastState.Bounded env53884 := by
  intro p hp
  have h : env53884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53883_53884 : H12AffineEnvironment.transform 17 10280 env53883 = env53884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53883 == env53884) = true)

theorem identity53884 : scanCanonicalize (H12AffineFastState.compose env53884 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound53884 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env53885 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,65831,16,41230,8193,16,149521,114966,45325,190520,75022,8493,256,98599,90122,513]

theorem envBound53885 : H12AffineFastState.Bounded env53885 := by
  intro p hp
  have h : env53885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53884_53885 : H12AffineEnvironment.transform 21 65831 env53884 = env53885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env53884 == env53885) = true)

theorem identity53885 : scanCanonicalize (H12AffineFastState.compose env53885 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound53885 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env53886 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1024,32769,58396,65831,16,41230,8193,16,108554,114966,45325,67619,75022,8493,256,98599,90122,513]

theorem envBound53886 : H12AffineFastState.Bounded env53886 := by
  intro p hp
  have h : env53886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53885_53886 : H12AffineEnvironment.transform 16 122907 env53885 = env53886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env53885 == env53886) = true)

theorem identity53886 : scanCanonicalize (H12AffineFastState.compose env53886 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound53886 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53887 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1024,32769,58396,41260,16,41230,8193,16,2049,24861,45325,43048,34053,8493,256,8492,49153,513]

theorem envBound53887 : H12AffineFastState.Bounded env53887 := by
  intro p hp
  have h : env53887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53886_53887 : H12AffineEnvironment.transform 15 40971 env53886 = env53887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env53886 == env53887) = true)

theorem identity53887 : scanCanonicalize (H12AffineFastState.compose env53887 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53887 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env53888 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10280,1024,1,25628,8492,16,8462,8193,16,2049,24861,12557,10280,1285,8493,256,8492,16385,513]

theorem envBound53888 : H12AffineFastState.Bounded env53888 := by
  intro p hp
  have h : env53888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53887_53888 : H12AffineEnvironment.transform 14 0 env53887 = env53888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53887 == env53888) = true)

def env53889 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8193,16,4409655,114966,45325,190521,75022,4268042,256,98599,90122,513]

theorem envBound53889 : H12AffineFastState.Bounded env53889 := by
  intro p hp
  have h : env53889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53883_53889 : H12AffineEnvironment.transform 17 10281 env53883 = env53889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53883 == env53889) = true)

theorem identity53889 : scanCanonicalize (H12AffineFastState.compose env53889 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound53889 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env53890 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,199939,16,41230,8193,16,17460,114966,45325,190521,75022,142601,256,98599,90122,513]

theorem envBound53890 : H12AffineFastState.Bounded env53890 := by
  intro p hp
  have h : env53890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53889_53890 : H12AffineEnvironment.transform 21 199939 env53889 = env53890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env53889 == env53890) = true)

theorem identity53890 : scanCanonicalize (H12AffineFastState.compose env53890 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound53890 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env53891 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,58396,27928,16,41230,8193,16,17460,114966,45325,100386,75022,85266,256,98599,90122,513]

theorem envBound53891 : H12AffineFastState.Bounded env53891 := by
  intro p hp
  have h : env53891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53890_53891 : H12AffineEnvironment.transform 16 90139 env53890 = env53891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env53890 == env53891) = true)

theorem identity53891 : scanCanonicalize (H12AffineFastState.compose env53891 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound53891 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53892 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,16384,32768,65536,84998,1076,1024,32769,51201,16645,16,36115,3100,16,17460,114966,40208,100386,67859,85266,256,98599,85015,513]

theorem envBound53892 : H12AffineFastState.Bounded env53892 := by
  intro p hp
  have h : env53892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53891_53892 : H12AffineEnvironment.transform 12 3101 env53891 = env53892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env53891 == env53892) = true)

theorem identity53892 : scanCanonicalize (H12AffineFastState.compose env53892 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 3094) := by decide +kernel

theorem selectedBound53892 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53893 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,16384,32768,3094,16400,1076,1024,32769,51201,16645,16,36115,3100,16,17460,52480,40208,33844,1285,16644,256,36145,16385,513]

theorem envBound53893 : H12AffineFastState.Bounded env53893 := by
  intro p hp
  have h : env53893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53892_53893 : H12AffineEnvironment.transform 15 3094 env53892 = env53893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3094 env53892 == env53893) = true)

theorem identity53893 : scanCanonicalize (H12AffineFastState.compose env53893 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound53893 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53894 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,4112,32768,3094,4096,1076,1024,32769,38929,4373,16,36115,3100,16,5156,40208,40208,33844,1285,4372,256,36145,4113,513]

theorem envBound53894 : H12AffineFastState.Bounded env53894 := by
  intro p hp
  have h : env53894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53893_53894 : H12AffineEnvironment.transform 13 4112 env53893 = env53894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env53893 == env53894) = true)

theorem identity53894 : scanCanonicalize (H12AffineFastState.compose env53894 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53894 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env53895 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,4096,1052,4112,32768,1047,4096,1076,1024,32769,36880,4373,16,34066,1053,16,5156,38161,38161,33844,1285,4372,256,34096,4113,513]

theorem envBound53895 : H12AffineFastState.Bounded env53895 := by
  intro p hp
  have h : env53895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53894_53895 : H12AffineEnvironment.transform 10 1 env53894 = env53895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53894 == env53895) = true)

theorem identity53895 : scanCanonicalize (H12AffineFastState.compose env53895 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound53895 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env53896 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,16,1052,0,32768,1047,16,1076,1024,32769,32768,261,16,34066,1053,16,1076,34049,34049,33844,1285,260,256,34096,1,513]

theorem envBound53896 : H12AffineFastState.Bounded env53896 := by
  intro p hp
  have h : env53896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53895_53896 : H12AffineEnvironment.transform 11 16 env53895 = env53896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53895 == env53896) = true)

theorem identity53896 : scanCanonicalize (H12AffineFastState.compose env53896 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound53896 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53897 : List Nat := [2,4,8,16,32,16,9,256,293,1024,1,16,1052,0,32768,1047,16,1076,1024,32769,32768,261,16,34066,1053,16,1076,34049,34049,33844,1285,260,256,34096,1,292]

theorem envBound53897 : H12AffineFastState.Bounded env53897 := by
  intro p hp
  have h : env53897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53896_53897 : H12AffineEnvironment.transform 8 293 env53896 = env53897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env53896 == env53897) = true)

theorem identity53897 : scanCanonicalize (H12AffineFastState.compose env53897 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 1060) := by decide +kernel

theorem selectedBound53897 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env53898 : List Nat := [2,4,8,16,32,16,9,256,293,1024,1,16,1052,0,1060,1047,16,1076,1024,1061,1060,261,16,310,1053,16,1076,293,293,16,1285,260,256,276,1,292]

theorem envBound53898 : H12AffineFastState.Bounded env53898 := by
  intro p hp
  have h : env53898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53897_53898 : H12AffineEnvironment.transform 14 1060 env53897 = env53898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1060 env53897 == env53898) = true)

theorem identity53898 : scanCanonicalize (H12AffineFastState.compose env53898 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound53898 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53899 : List Nat := [2,4,8,16,32,16,9,256,293,256,1,16,284,0,292,279,16,308,256,293,292,261,16,310,285,16,308,293,293,16,5,260,256,276,1,292]

theorem envBound53899 : H12AffineFastState.Bounded env53899 := by
  intro p hp
  have h : env53899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53898_53899 : H12AffineEnvironment.transform 9 256 env53898 = env53899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env53898 == env53899) = true)

theorem identity53899 : scanCanonicalize (H12AffineFastState.compose env53899 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound53899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53900 : List Nat := [2,4,8,16,32,16,9,20,49,20,1,16,8,0,48,3,16,32,20,49,48,17,16,34,9,16,32,49,49,16,5,16,20,0,1,48]

theorem envBound53900 : H12AffineFastState.Bounded env53900 := by
  intro p hp
  have h : env53900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53899_53900 : H12AffineEnvironment.transform 7 20 env53899 = env53900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env53899 == env53900) = true)

theorem identity53900 : scanCanonicalize (H12AffineFastState.compose env53900 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53900 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53901 : List Nat := [2,4,8,16,1,16,9,20,16,20,1,16,8,0,17,3,16,1,20,16,17,17,16,3,9,16,1,16,16,16,5,16,20,0,1,17]

theorem envBound53901 : H12AffineFastState.Bounded env53901 := by
  intro p hp
  have h : env53901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53900_53901 : H12AffineEnvironment.transform 4 1 env53900 = env53901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53900 == env53901) = true)

theorem identity53901 : scanCanonicalize (H12AffineFastState.compose env53901 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53901 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53902 : List Nat := [2,4,8,1,1,1,9,5,1,5,1,1,8,0,0,3,1,1,5,1,0,0,1,3,9,1,1,1,1,1,5,1,5,0,1,0]

theorem envBound53902 : H12AffineFastState.Bounded env53902 := by
  intro p hp
  have h : env53902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53901_53902 : H12AffineEnvironment.transform 3 1 env53901 = env53902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53901 == env53902) = true)

def env53903 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8193,17,4677919,114967,45324,442384,75023,4268042,256,98598,90123,513]

theorem envBound53903 : H12AffineFastState.Bounded env53903 := by
  intro p hp
  have h : env53903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53882_53903 : H12AffineEnvironment.transform 5 17 env53882 = env53903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53882 == env53903) = true)

theorem identity53903 : scanCanonicalize (H12AffineFastState.compose env53903 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53903 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env53904 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8193,17,4409655,114967,45324,190520,75023,4268042,256,98598,90123,513]

theorem envBound53904 : H12AffineFastState.Bounded env53904 := by
  intro p hp
  have h : env53904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53903_53904 : H12AffineEnvironment.transform 17 10280 env53903 = env53904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53903 == env53904) = true)

theorem identity53904 : scanCanonicalize (H12AffineFastState.compose env53904 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound53904 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env53905 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,4194304,16,41231,8193,17,4204844,114967,45324,100387,75023,4268042,256,98598,90123,513]

theorem envBound53905 : H12AffineFastState.Bounded env53905 := by
  intro p hp
  have h : env53905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53904_53905 : H12AffineEnvironment.transform 16 90139 env53904 = env53905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env53904 == env53905) = true)

theorem identity53905 : scanCanonicalize (H12AffineFastState.compose env53905 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound53905 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53906 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,32,16,41231,8193,17,10508,114967,45324,100387,75023,73770,256,98598,90123,513]

theorem envBound53906 : H12AffineFastState.Bounded env53906 := by
  intro p hp
  have h : env53906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53905_53906 : H12AffineEnvironment.transform 21 32 env53905 = env53906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env53905 == env53906) = true)

theorem identity53906 : scanCanonicalize (H12AffineFastState.compose env53906 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53906 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env53907 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,10280,1024,0,25629,32,16,8462,8193,17,10508,82198,12557,67618,75023,73770,256,65831,90123,513]

theorem envBound53907 : H12AffineFastState.Bounded env53907 := by
  intro p hp
  have h : env53907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53906_53907 : H12AffineEnvironment.transform 14 1 env53906 = env53907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53906 == env53907) = true)

theorem identity53907 : scanCanonicalize (H12AffineFastState.compose env53907 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53907 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53908 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10280,1024,0,25629,32,16,8462,8193,17,10508,24861,12557,10281,1284,33,256,8492,16384,513]

theorem envBound53908 : H12AffineFastState.Bounded env53908 := by
  intro p hp
  have h : env53908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53907_53908 : H12AffineEnvironment.transform 15 8203 env53907 = env53908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53907 == env53908) = true)

theorem identity53908 : scanCanonicalize (H12AffineFastState.compose env53908 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound53908 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env53909 : List Nat := [2,4,8,16,32,17,9,256,512,1024,529,4096,8192,16384,1,8203,16400,8761,1024,0,25629,32,16,8462,8193,17,8989,24861,12557,8760,1284,33,256,8492,16384,513]

theorem envBound53909 : H12AffineFastState.Bounded env53909 := by
  intro p hp
  have h : env53909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53908_53909 : H12AffineEnvironment.transform 10 529 env53908 = env53909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env53908 == env53909) = true)

theorem identity53909 : scanCanonicalize (H12AffineFastState.compose env53909 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 8460) := by decide +kernel

theorem selectedBound53909 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53910 : List Nat := [2,4,8,16,32,17,9,256,512,1024,529,4096,8192,8460,1,8203,8476,8761,1024,0,1297,32,16,8462,8193,17,8989,17,12557,8760,1284,33,256,8492,8460,513]

theorem envBound53910 : H12AffineFastState.Bounded env53910 := by
  intro p hp
  have h : env53910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53909_53910 : H12AffineEnvironment.transform 13 8460 env53909 = env53910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8460 env53909 == env53910) = true)

theorem identity53910 : scanCanonicalize (H12AffineFastState.compose env53910 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1320) := by decide +kernel

theorem selectedBound53910 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53911 : List Nat := [2,4,8,16,32,17,9,256,512,1024,529,4096,1320,1060,1,1315,1076,1809,1024,0,1297,32,16,1062,1321,17,1589,17,5157,1808,1284,33,256,1028,1060,513]

theorem envBound53911 : H12AffineFastState.Bounded env53911 := by
  intro p hp
  have h : env53911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53910_53911 : H12AffineEnvironment.transform 12 1320 env53910 = env53911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1320 env53910 == env53911) = true)

theorem identity53911 : scanCanonicalize (H12AffineFastState.compose env53911 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound53911 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env53912 : List Nat := [2,4,8,16,32,17,9,256,512,36,529,4096,268,0,1,263,16,821,36,0,309,32,16,2,269,17,529,17,4097,820,288,33,256,32,0,513]

theorem envBound53912 : H12AffineFastState.Bounded env53912 := by
  intro p hp
  have h : env53912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53911_53912 : H12AffineEnvironment.transform 9 36 env53911 = env53912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env53911 == env53912) = true)

theorem identity53912 : scanCanonicalize (H12AffineFastState.compose env53912 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound53912 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53913 : List Nat := [2,4,8,16,32,17,9,256,512,36,529,17,268,0,1,263,16,821,36,0,309,32,16,2,269,17,529,17,16,820,288,33,256,32,0,513]

theorem envBound53913 : H12AffineFastState.Bounded env53913 := by
  intro p hp
  have h : env53913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53912_53913 : H12AffineEnvironment.transform 11 17 env53912 = env53913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env53912 == env53913) = true)

theorem identity53913 : scanCanonicalize (H12AffineFastState.compose env53913 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound53913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53914 : List Nat := [2,4,8,16,32,17,9,256,293,36,308,17,268,0,1,263,16,16,36,0,309,32,16,2,269,17,308,17,16,17,288,33,256,32,0,292]

theorem envBound53914 : H12AffineFastState.Bounded env53914 := by
  intro p hp
  have h : env53914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53913_53914 : H12AffineEnvironment.transform 8 293 env53913 = env53914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env53913 == env53914) = true)

theorem identity53914 : scanCanonicalize (H12AffineFastState.compose env53914 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound53914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53915 : List Nat := [2,4,8,16,26,17,9,256,287,30,270,17,268,0,1,263,16,16,30,0,271,26,16,2,269,17,270,17,16,17,282,27,256,26,0,286]

theorem envBound53915 : H12AffineFastState.Bounded env53915 := by
  intro p hp
  have h : env53915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53914_53915 : H12AffineEnvironment.transform 4 26 env53914 = env53915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env53914 == env53915) = true)

theorem identity53915 : scanCanonicalize (H12AffineFastState.compose env53915 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound53915 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53916 : List Nat := [2,4,8,16,26,17,9,14,17,30,0,17,2,0,1,9,16,16,30,0,1,26,16,2,3,17,0,17,16,17,20,27,14,26,0,16]

theorem envBound53916 : H12AffineFastState.Bounded env53916 := by
  intro p hp
  have h : env53916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53915_53916 : H12AffineEnvironment.transform 7 14 env53915 = env53916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env53915 == env53916) = true)

def env53917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8193,64,4677966,115015,45404,442384,75102,4268043,256,98678,90203,513]

theorem envBound53917 : H12AffineFastState.Bounded env53917 := by
  intro p hp
  have h : env53917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53881_53917 : H12AffineEnvironment.transform 20 58397 env53881 = env53917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env53881 == env53917) = true)

theorem identity53917 : scanCanonicalize (H12AffineFastState.compose env53917 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53917 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,4194304,16,41310,8193,64,4604228,57677,45404,442384,1364,4194305,256,41340,16465,513]

theorem envBound53918 : H12AffineFastState.Bounded env53918 := by
  intro p hp
  have h : env53918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53917_53918 : H12AffineEnvironment.transform 15 8202 env53917 = env53918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53917 == env53918) = true)

theorem identity53918 : scanCanonicalize (H12AffineFastState.compose env53918 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound53918 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env53919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419913,16,41310,8193,64,10509,57677,45404,442384,1364,419912,256,41340,16465,513]

theorem envBound53919 : H12AffineFastState.Bounded env53919 := by
  intro p hp
  have h : env53919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53918_53919 : H12AffineEnvironment.transform 21 419913 env53918 = env53919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env53918 == env53919) = true)

def env53920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58397,272393,16,41310,8193,64,10509,57677,45404,294992,1364,272392,256,41340,16465,513]

theorem envBound53920 : H12AffineFastState.Bounded env53920 := by
  intro p hp
  have h : env53920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53919_53920 : H12AffineEnvironment.transform 16 16448 env53919 = env53920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env53919 == env53920) = true)

theorem identity53920 : scanCanonicalize (H12AffineFastState.compose env53920 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound53920 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,2341,1024,32769,58397,8492,16,41310,8193,64,10509,57677,45404,35189,1364,8493,256,41340,16465,513]

theorem envBound53921 : H12AffineFastState.Bounded env53921 := by
  intro p hp
  have h : env53921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53920_53921 : H12AffineEnvironment.transform 17 2341 env53920 = env53921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env53920 == env53921) = true)

theorem identity53921 : scanCanonicalize (H12AffineFastState.compose env53921 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound53921 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env53922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8202,16448,2341,1024,8461,17681,8492,16,82,8193,64,10509,16449,4176,10361,1364,8493,256,112,16465,513]

theorem envBound53922 : H12AffineFastState.Bounded env53922 := by
  intro p hp
  have h : env53922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53921_53922 : H12AffineEnvironment.transform 14 8460 env53921 = env53922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env53921 == env53922) = true)

theorem identity53922 : scanCanonicalize (H12AffineFastState.compose env53922 (packedSelected [0,1,3,4,5,8,10,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53922 : packedSelected [0,1,3,4,5,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env53923 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8202,16401,2341,1024,8461,17681,8492,16,3,8193,17,10509,16400,4097,10280,1285,8493,256,33,16384,513]

theorem envBound53923 : H12AffineFastState.Bounded env53923 := by
  intro p hp
  have h : env53923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53922_53923 : H12AffineEnvironment.transform 5 17 env53922 = env53923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53922 == env53923) = true)

theorem identity53923 : scanCanonicalize (H12AffineFastState.compose env53923 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound53923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53924 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,8460,8202,5173,2341,1024,8461,4405,8492,16,3,8193,17,10509,5172,4097,10280,1285,8493,256,33,5156,513]

theorem envBound53924 : H12AffineFastState.Bounded env53924 := by
  intro p hp
  have h : env53924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53923_53924 : H12AffineEnvironment.transform 13 5156 env53923 = env53924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env53923 == env53924) = true)

theorem identity53924 : scanCanonicalize (H12AffineFastState.compose env53924 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53924 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53925 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,1,263,5173,2341,1024,0,4405,33,16,3,268,17,2048,5172,4097,2341,1285,32,256,33,5156,513]

theorem envBound53925 : H12AffineFastState.Bounded env53925 := by
  intro p hp
  have h : env53925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53924_53925 : H12AffineEnvironment.transform 12 269 env53924 = env53925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53924 == env53925) = true)

def env53926 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,269,2836,1,263,2821,2341,1024,0,3589,33,16,3,268,17,2048,2820,3889,2341,1285,32,256,33,2836,513]

theorem envBound53926 : H12AffineFastState.Bounded env53926 := by
  intro p hp
  have h : env53926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53925_53926 : H12AffineEnvironment.transform 11 3888 env53925 = env53926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env53925 == env53926) = true)

def env53927 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,269,1044,1,263,1029,1573,1024,0,261,33,16,3,268,17,1792,1028,49,1573,1285,32,256,33,1044,513]

theorem envBound53927 : H12AffineFastState.Bounded env53927 := by
  intro p hp
  have h : env53927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53926_53927 : H12AffineEnvironment.transform 10 1792 env53926 = env53927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env53926 == env53927) = true)

theorem identity53927 : scanCanonicalize (H12AffineFastState.compose env53927 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53928 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,48,40,1044,1,34,1029,1573,1024,0,32,33,16,3,41,17,1573,1028,49,1573,1056,32,37,33,1044,513]

theorem envBound53928 : H12AffineFastState.Bounded env53928 := by
  intro p hp
  have h : env53928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53927_53928 : H12AffineEnvironment.transform 7 37 env53927 = env53928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53927 == env53928) = true)

def env53929 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,48,40,32,1,34,49,529,52,0,32,33,16,3,41,17,529,48,49,529,20,32,37,33,32,513]

theorem envBound53929 : H12AffineFastState.Bounded env53929 := by
  intro p hp
  have h : env53929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53928_53929 : H12AffineEnvironment.transform 9 52 env53928 = env53929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53928 == env53929) = true)

theorem identity53929 : scanCanonicalize (H12AffineFastState.compose env53929 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound53929 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53930 : List Nat := [2,4,8,16,32,17,9,37,43,52,58,48,40,32,1,34,49,58,52,0,32,33,16,3,41,17,58,48,49,58,20,32,37,33,32,42]

theorem envBound53930 : H12AffineFastState.Bounded env53930 := by
  intro p hp
  have h : env53930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53929_53930 : H12AffineEnvironment.transform 8 43 env53929 = env53930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env53929 == env53930) = true)

def leafEnv53930 : List Nat := [2,4,8,16,32,17,9,37,43,52,58,48,40,32,1,34,49,58,52,0,32,33,16,3,20,41,1,17,58,48,49,58,20,32,37,33,4,35,32,42,1,32,0]

def active53930 : List Nat := [0,1,2,3,4]

def tree53930 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53930 : H12WitnessSearch.Good tree53930 := H12GlobalWitnessIndex.good

theorem leafIdentity53930 : H12AffineFastState.composeSystem env53930 rootObs = leafEnv53930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53930 rootObs == leafEnv53930) = true)

theorem terminalChecked53930 : H12PackedTerminal.terminalCheckFast leafEnv53930 active53930 tree53930 = true := by decide +kernel

def env53931 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,48,40,33,1,34,48,528,53,0,32,33,16,3,41,17,528,49,49,528,21,32,37,33,33,513]

theorem envBound53931 : H12AffineFastState.Bounded env53931 := by
  intro p hp
  have h : env53931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53928_53931 : H12AffineEnvironment.transform 9 53 env53928 = env53931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53928 == env53931) = true)

end H12CloudChart1