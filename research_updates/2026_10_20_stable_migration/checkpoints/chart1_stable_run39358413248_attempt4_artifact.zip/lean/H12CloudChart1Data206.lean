import H12CloudChart1Data205

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound52167 : H12AffineFastState.Bounded env52167 := by
  intro p hp
  have h : env52167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52166_52167 : H12AffineEnvironment.transform 9 272 env52166 = env52167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52166 == env52167) = true)

theorem identity52167 : scanCanonicalize (H12AffineFastState.compose env52167 (packedSelected [1,3,10] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound52167 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env52168 : List Nat := [2,4,8,16,32,17,9,256,512,272,821,528,268,804,1,262,820,529,273,0,804,32,17,2,269,16,821,820,528,529,21,33,257,32,805,513]

theorem envBound52168 : H12AffineFastState.Bounded env52168 := by
  intro p hp
  have h : env52168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52167_52168 : H12AffineEnvironment.transform 11 528 env52167 = env52168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env52167 == env52168) = true)

theorem identity52168 : scanCanonicalize (H12AffineFastState.compose env52168 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52168 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52169 : List Nat := [2,4,8,16,32,17,9,5,512,21,560,528,9,545,1,3,561,529,20,0,545,32,17,2,8,16,560,561,528,529,21,33,4,32,544,513]

theorem envBound52169 : H12AffineFastState.Bounded env52169 := by
  intro p hp
  have h : env52169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52168_52169 : H12AffineEnvironment.transform 7 5 env52168 = env52169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52168 == env52169) = true)

theorem identity52169 : scanCanonicalize (H12AffineFastState.compose env52169 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52169 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52170 : List Nat := [2,4,8,16,0,17,9,5,512,21,528,528,9,513,1,3,529,529,20,0,513,0,17,2,8,16,528,529,528,529,21,1,4,0,512,513]

theorem envBound52170 : H12AffineFastState.Bounded env52170 := by
  intro p hp
  have h : env52170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52169_52170 : H12AffineEnvironment.transform 4 0 env52169 = env52170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52169 == env52170) = true)

theorem identity52170 : scanCanonicalize (H12AffineFastState.compose env52170 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52171 : List Nat := [2,4,8,16,0,17,9,5,0,21,16,16,9,1,1,3,17,17,20,0,1,0,17,2,8,16,16,17,16,17,21,1,4,0,0,1]

theorem envBound52171 : H12AffineFastState.Bounded env52171 := by
  intro p hp
  have h : env52171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52170_52171 : H12AffineEnvironment.transform 8 0 env52170 = env52171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52170 == env52171) = true)

theorem identity52171 : scanCanonicalize (H12AffineFastState.compose env52171 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52172 : List Nat := [2,4,8,11,0,10,9,5,0,14,11,11,9,1,1,3,10,10,15,0,1,0,10,2,8,11,11,10,11,10,14,1,4,0,0,1]

theorem envBound52172 : H12AffineFastState.Bounded env52172 := by
  intro p hp
  have h : env52172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52171_52172 : H12AffineEnvironment.transform 3 11 env52171 = env52172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52171 == env52172) = true)

def env52173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4262262,10816866,10507600,8683537,331126,15068207,257,2444611,2468975,272937]

theorem envBound52173 : H12AffineFastState.Bounded env52173 := by
  intro p hp
  have h : env52173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52121_52173 : H12AffineEnvironment.transform 16 16401 env52121 = env52173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52121 == env52173) = true)

def env52174 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685879,8193,17,4262182,10816818,10507520,8683537,331046,15068207,257,2444563,2468927,272937]

theorem envBound52174 : H12AffineFastState.Bounded env52174 := by
  intro p hp
  have h : env52174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52173_52174 : H12AffineEnvironment.transform 5 16 env52173 = env52174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52173 == env52174) = true)

def env52175 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685879,8193,17,4262182,10815490,10506288,8683537,329750,15067423,257,2443299,2468111,272937]

theorem envBound52175 : H12AffineFastState.Bounded env52175 := by
  intro p hp
  have h : env52175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52174_52175 : H12AffineEnvironment.transform 9 304 env52174 = env52175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env52174 == env52175) = true)

theorem identity52175 : scanCanonicalize (H12AffineFastState.compose env52175 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235581) := by decide +kernel

theorem selectedBound52175 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52176 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4235581,4466698,8193,17,4262182,6662463,6353165,4464940,329750,2443298,257,2443299,2468111,272937]

theorem envBound52176 : H12AffineFastState.Bounded env52176 := by
  intro p hp
  have h : env52176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52175_52176 : H12AffineEnvironment.transform 22 4235581 env52175 = env52176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235581 env52175 == env52176) = true)

def env52177 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,4194304,4235581,4194338,8193,17,4262182,6390039,6353165,4196612,73790,2187274,257,2187275,2195751,513]

theorem envBound52177 : H12AffineFastState.Bounded env52177 := by
  intro p hp
  have h : env52177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52176_52177 : H12AffineEnvironment.transform 17 10280 env52176 = env52177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52176 == env52177) = true)

theorem identity52177 : scanCanonicalize (H12AffineFastState.compose env52177 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound52177 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env52178 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,33031,16401,10280,305,32769,2097152,4194304,4235581,4194338,8193,17,4229153,6291472,6353165,4196612,41273,2154765,257,2154764,2097184,513]

theorem envBound52178 : H12AffineFastState.Bounded env52178 := by
  intro p hp
  have h : env52178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52177_52178 : H12AffineEnvironment.transform 15 33031 env52177 = env52178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env52177 == env52178) = true)

theorem identity52178 : scanCanonicalize (H12AffineFastState.compose env52178 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound52178 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52179 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,33031,16401,10280,305,32769,2097152,32,41245,2,8193,17,34817,2097200,2158893,2340,41273,2154765,257,2154764,2097184,513]

theorem envBound52179 : H12AffineFastState.Bounded env52179 := by
  intro p hp
  have h : env52179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52178_52179 : H12AffineEnvironment.transform 21 32 env52178 = env52179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52178 == env52179) = true)

theorem identity52179 : scanCanonicalize (H12AffineFastState.compose env52179 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52179 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52180 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,269,16384,32768,33031,16401,2341,305,32769,2097152,32,32784,2,268,17,34817,2097200,2150432,2340,32820,2146304,257,2146305,2097184,513]

theorem envBound52180 : H12AffineFastState.Bounded env52180 := by
  intro p hp
  have h : env52180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52179_52180 : H12AffineEnvironment.transform 12 269 env52179 = env52180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52179 == env52180) = true)

theorem identity52180 : scanCanonicalize (H12AffineFastState.compose env52180 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52180 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52181 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,269,16384,1,262,16401,2341,305,0,2097152,32,17,2,268,17,2048,2097200,2117665,2340,53,2113537,257,2113536,2097184,513]

theorem envBound52181 : H12AffineFastState.Bounded env52181 := by
  intro p hp
  have h : env52181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52180_52181 : H12AffineEnvironment.transform 14 1 env52180 = env52181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52180 == env52181) = true)

theorem identity52181 : scanCanonicalize (H12AffineFastState.compose env52181 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6932) := by decide +kernel

theorem selectedBound52181 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52182 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,269,6932,1,262,6917,2341,305,0,2097152,32,17,2,268,17,2048,2097200,2100021,2340,53,2104085,257,2104084,2097184,513]

theorem envBound52182 : H12AffineFastState.Bounded env52182 := by
  intro p hp
  have h : env52182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52181_52182 : H12AffineEnvironment.transform 13 6932 env52181 = env52182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6932 env52181 == env52182) = true)

def env52183 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,2097152,4194304,4235581,4194339,8193,17,4262182,6390038,6353165,4196613,73791,2187275,257,2187274,2195750,512]

theorem envBound52183 : H12AffineFastState.Bounded env52183 := by
  intro p hp
  have h : env52183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52176_52183 : H12AffineEnvironment.transform 17 10281 env52176 = env52183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52176 == env52183) = true)

theorem identity52183 : scanCanonicalize (H12AffineFastState.compose env52183 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 100387) := by decide +kernel

theorem selectedBound52183 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env52184 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,100387,4194304,4235581,4194339,8193,17,4262182,4196661,4290862,4196613,73791,59432,257,59433,2309,512]

theorem envBound52184 : H12AffineFastState.Bounded env52184 := by
  intro p hp
  have h : env52184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52183_52184 : H12AffineEnvironment.transform 20 100387 env52183 = env52184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 100387 env52183 == env52184) = true)

theorem identity52184 : scanCanonicalize (H12AffineFastState.compose env52184 (packedSelected [1,3,4,5,8,9,11,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 80191) := by decide +kernel

theorem selectedBound52184 : packedSelected [1,3,4,5,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env52185 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,100387,80191,104450,80156,8193,17,12313,77834,16401,77882,73791,59432,257,59433,2309,512]

theorem envBound52185 : H12AffineFastState.Bounded env52185 := by
  intro p hp
  have h : env52185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52184_52185 : H12AffineEnvironment.transform 21 80191 env52184 = env52185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80191 env52184 == env52185) = true)

theorem identity52185 : scanCanonicalize (H12AffineFastState.compose env52185 (packedSelected [1,3,4,5,8,9,11,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 38931) := by decide +kernel

theorem selectedBound52185 : packedSelected [1,3,4,5,8,9,11,15,21] rootPS < 2^1333 := by decide +kernel

def env52186 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,38931,16401,10281,305,32769,4144,41260,17,41231,8193,17,12313,43033,16401,43049,47148,59432,257,59433,2309,512]

theorem envBound52186 : H12AffineFastState.Bounded env52186 := by
  intro p hp
  have h : env52186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52185_52186 : H12AffineEnvironment.transform 15 38931 env52185 = env52186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38931 env52185 == env52186) = true)

theorem identity52186 : scanCanonicalize (H12AffineFastState.compose env52186 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound52186 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52187 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,2080,32768,38931,2097,10281,305,32769,4144,41260,17,41231,8193,17,12313,43033,2097,43049,47148,40968,257,40969,2309,512]

theorem envBound52187 : H12AffineFastState.Bounded env52187 := by
  intro p hp
  have h : env52187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52186_52187 : H12AffineEnvironment.transform 13 2080 env52186 = env52187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env52186 == env52187) = true)

theorem identity52187 : scanCanonicalize (H12AffineFastState.compose env52187 (packedSelected [0,2,3,5,6,7,10,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound52187 : packedSelected [0,2,3,5,6,7,10,14,18] rootPS < 2^1333 := by decide +kernel

def env52188 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,2080,292,6455,2097,10281,305,293,4144,8200,17,8235,8193,17,12313,10557,2097,10509,14600,8492,257,8493,2309,512]

theorem envBound52188 : H12AffineFastState.Bounded env52188 := by
  intro p hp
  have h : env52188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52187_52188 : H12AffineEnvironment.transform 14 292 env52187 = env52188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env52187 == env52188) = true)

theorem identity52188 : scanCanonicalize (H12AffineFastState.compose env52188 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound52188 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52189 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,6429,2080,292,6455,2097,4404,305,293,4144,6421,17,6454,6428,17,2308,4128,2097,4112,21,6193,257,6192,2309,512]

theorem envBound52189 : H12AffineFastState.Bounded env52189 := by
  intro p hp
  have h : env52189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52188_52189 : H12AffineEnvironment.transform 12 6429 env52188 = env52189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env52188 == env52189) = true)

theorem identity52189 : scanCanonicalize (H12AffineFastState.compose env52189 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52189 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env52190 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,4096,6169,2080,32,6195,2097,4144,53,33,4144,6161,17,6194,6168,17,2048,4128,2097,4112,21,6193,5,6192,2049,512]

theorem envBound52190 : H12AffineFastState.Bounded env52190 := by
  intro p hp
  have h : env52190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52189_52190 : H12AffineEnvironment.transform 7 4 env52189 = env52190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52189 == env52190) = true)

def env52191 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685879,8193,17,4262182,10815491,10506289,8683537,329751,15067422,257,2443298,2468110,272937]

theorem envBound52191 : H12AffineFastState.Bounded env52191 := by
  intro p hp
  have h : env52191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52174_52191 : H12AffineEnvironment.transform 9 305 env52174 = env52191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env52174 == env52191) = true)

theorem identity52191 : scanCanonicalize (H12AffineFastState.compose env52191 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4491541) := by decide +kernel

theorem selectedBound52191 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52192 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4491541,4194338,8193,17,4262182,6390038,6609188,4196612,329751,2187275,257,2443298,2468110,272937]

theorem envBound52192 : H12AffineFastState.Bounded env52192 := by
  intro p hp
  have h : env52192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52191_52192 : H12AffineEnvironment.transform 22 4491541 env52191 = env52192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4491541 env52191 == env52192) = true)

theorem identity52192 : scanCanonicalize (H12AffineFastState.compose env52192 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52192 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env52193 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4235581,4194338,8193,17,4262182,6390038,6353164,4196612,73791,2187275,257,2187274,2195750,513]

theorem envBound52193 : H12AffineFastState.Bounded env52193 := by
  intro p hp
  have h : env52193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52192_52193 : H12AffineEnvironment.transform 17 10280 env52192 = env52193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52192 == env52193) = true)

theorem identity52193 : scanCanonicalize (H12AffineFastState.compose env52193 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound52193 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env52194 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,33031,16401,10280,304,32769,2097152,4194304,4235581,4194338,8193,17,4229153,6291473,6353164,4196612,41272,2154764,257,2154765,2097185,513]

theorem envBound52194 : H12AffineFastState.Bounded env52194 := by
  intro p hp
  have h : env52194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52193_52194 : H12AffineEnvironment.transform 15 33031 env52193 = env52194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env52193 == env52194) = true)

theorem identity52194 : scanCanonicalize (H12AffineFastState.compose env52194 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound52194 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52195 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,33031,16401,10280,304,32769,2097152,32,41245,2,8193,17,34817,2097201,2158892,2340,41272,2154764,257,2154765,2097185,513]

theorem envBound52195 : H12AffineFastState.Bounded env52195 := by
  intro p hp
  have h : env52195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52194_52195 : H12AffineEnvironment.transform 21 32 env52194 = env52195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env52194 == env52195) = true)

theorem identity52195 : scanCanonicalize (H12AffineFastState.compose env52195 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52195 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52196 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,33031,16401,2341,304,32769,2097152,32,32784,2,268,17,34817,2097201,2150433,2340,32821,2146305,257,2146304,2097185,513]

theorem envBound52196 : H12AffineFastState.Bounded env52196 := by
  intro p hp
  have h : env52196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52195_52196 : H12AffineEnvironment.transform 12 269 env52195 = env52196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52195 == env52196) = true)

theorem identity52196 : scanCanonicalize (H12AffineFastState.compose env52196 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52196 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52197 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,1,262,16401,2341,304,0,2097152,32,17,2,268,17,2048,2097201,2117664,2340,52,2113536,257,2113537,2097185,513]

theorem envBound52197 : H12AffineFastState.Bounded env52197 := by
  intro p hp
  have h : env52197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52196_52197 : H12AffineEnvironment.transform 14 1 env52196 = env52197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52196 == env52197) = true)

theorem identity52197 : scanCanonicalize (H12AffineFastState.compose env52197 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6933) := by decide +kernel

theorem selectedBound52197 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52198 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,6933,1,262,6916,2341,304,0,2097152,32,17,2,268,17,2048,2097201,2100021,2340,52,2104085,257,2104084,2097185,513]

theorem envBound52198 : H12AffineFastState.Bounded env52198 := by
  intro p hp
  have h : env52198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52197_52198 : H12AffineEnvironment.transform 13 6933 env52197 = env52198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6933 env52197 == env52198) = true)

def env52199 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685878,8193,16,4262183,10816819,10507521,8683537,331047,15068207,257,2444562,2468926,272937]

theorem envBound52199 : H12AffineFastState.Bounded env52199 := by
  intro p hp
  have h : env52199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52173_52199 : H12AffineEnvironment.transform 5 17 env52173 = env52199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52173 == env52199) = true)

def env52200 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685878,8193,16,4262183,10815491,10506289,8683537,329751,15067423,257,2443298,2468110,272937]

theorem envBound52200 : H12AffineFastState.Bounded env52200 := by
  intro p hp
  have h : env52200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52199_52200 : H12AffineEnvironment.transform 9 304 env52199 = env52200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env52199 == env52200) = true)

theorem identity52200 : scanCanonicalize (H12AffineFastState.compose env52200 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4292919) := by decide +kernel

theorem selectedBound52200 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52201 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4292919,4524033,8193,16,4262183,6588724,6410502,4522278,329751,2385960,257,2443298,2468110,272937]

theorem envBound52201 : H12AffineFastState.Bounded env52201 := by
  intro p hp
  have h : env52201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52200_52201 : H12AffineEnvironment.transform 22 4292919 env52200 = env52201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292919 env52200 == env52201) = true)

theorem identity52201 : scanCanonicalize (H12AffineFastState.compose env52201 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52201 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52202 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,4194304,4292919,4268073,8193,16,4262183,6332700,6410502,4270350,73791,2113536,257,2187274,2195750,513]

theorem envBound52202 : H12AffineFastState.Bounded env52202 := by
  intro p hp
  have h : env52202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52201_52202 : H12AffineEnvironment.transform 17 10280 env52201 = env52202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52201 == env52202) = true)

theorem identity52202 : scanCanonicalize (H12AffineFastState.compose env52202 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound52202 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env52203 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,41261,73754,98564,8193,16,108554,2097201,2191403,100387,73791,2113536,257,2187274,2195750,513]

theorem envBound52203 : H12AffineFastState.Bounded env52203 := by
  intro p hp
  have h : env52203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52202_52203 : H12AffineEnvironment.transform 21 41261 env52202 = env52203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env52202 == env52203) = true)

theorem identity52203 : scanCanonicalize (H12AffineFastState.compose env52203 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52203 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52204 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,8203,16401,10280,305,32769,2097152,41261,17,41231,8193,16,34817,2097201,2117664,43048,52,2113536,257,2113537,2138413,513]

theorem envBound52204 : H12AffineFastState.Bounded env52204 := by
  intro p hp
  have h : env52204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52203_52204 : H12AffineEnvironment.transform 15 8203 env52203 = env52204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52203 == env52204) = true)

theorem identity52204 : scanCanonicalize (H12AffineFastState.compose env52204 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52204 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52205 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,1,8203,16401,10280,305,0,2097152,8492,17,8462,8193,16,2048,2097201,2117664,10281,52,2113536,257,2113537,2105644,513]

theorem envBound52205 : H12AffineFastState.Bounded env52205 := by
  intro p hp
  have h : env52205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52204_52205 : H12AffineEnvironment.transform 14 1 env52204 = env52205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52204 == env52205) = true)

theorem identity52205 : scanCanonicalize (H12AffineFastState.compose env52205 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52205 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52206 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,268,16384,1,263,16401,2340,305,0,2097152,32,17,2,269,16,2048,2097201,2117664,2341,52,2113536,257,2113537,2097184,513]

theorem envBound52206 : H12AffineFastState.Bounded env52206 := by
  intro p hp
  have h : env52206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52205_52206 : H12AffineEnvironment.transform 12 268 env52205 = env52206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52205 == env52206) = true)

theorem identity52206 : scanCanonicalize (H12AffineFastState.compose env52206 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6704) := by decide +kernel

theorem selectedBound52206 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52207 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,268,6704,1,263,6689,2340,305,0,2097152,32,17,2,269,16,2048,2097201,2099728,2341,52,2103856,257,2103857,2097184,513]

theorem envBound52207 : H12AffineFastState.Bounded env52207 := by
  intro p hp
  have h : env52207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52206_52207 : H12AffineEnvironment.transform 13 6704 env52206 = env52207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6704 env52206 == env52207) = true)

def env52208 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685878,8193,16,4262183,10815490,10506288,8683537,329750,15067422,257,2443299,2468111,272937]

theorem envBound52208 : H12AffineFastState.Bounded env52208 := by
  intro p hp
  have h : env52208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52199_52208 : H12AffineEnvironment.transform 9 305 env52199 = env52208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env52199 == env52208) = true)

theorem identity52208 : scanCanonicalize (H12AffineFastState.compose env52208 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4565279) := by decide +kernel

theorem selectedBound52208 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52209 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4565279,4268073,8193,16,4262183,6332701,6682927,4270350,329750,2113537,257,2443299,2468111,272937]

theorem envBound52209 : H12AffineFastState.Bounded env52209 := by
  intro p hp
  have h : env52209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52208_52209 : H12AffineEnvironment.transform 22 4565279 env52208 = env52209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4565279 env52208 == env52209) = true)

def env52210 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4292919,4268073,8193,16,4262183,6332701,6410503,4270350,73790,2113537,257,2187275,2195751,513]

theorem envBound52210 : H12AffineFastState.Bounded env52210 := by
  intro p hp
  have h : env52210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52209_52210 : H12AffineEnvironment.transform 17 10280 env52209 = env52210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52209 == env52210) = true)

theorem identity52210 : scanCanonicalize (H12AffineFastState.compose env52210 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound52210 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env52211 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,41261,73754,98564,8193,16,108554,2097200,2191402,100387,73790,2113537,257,2187275,2195751,513]

theorem envBound52211 : H12AffineFastState.Bounded env52211 := by
  intro p hp
  have h : env52211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52210_52211 : H12AffineEnvironment.transform 21 41261 env52210 = env52211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env52210 == env52211) = true)

theorem identity52211 : scanCanonicalize (H12AffineFastState.compose env52211 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52211 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52212 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,8203,16401,10280,304,32769,2097152,41261,17,41231,8193,16,34817,2097200,2117665,43048,53,2113537,257,2113536,2138412,513]

theorem envBound52212 : H12AffineFastState.Bounded env52212 := by
  intro p hp
  have h : env52212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52211_52212 : H12AffineEnvironment.transform 15 8203 env52211 = env52212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52211 == env52212) = true)

theorem identity52212 : scanCanonicalize (H12AffineFastState.compose env52212 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52212 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52213 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,1,8203,16401,10280,304,0,2097152,8492,17,8462,8193,16,2048,2097200,2117665,10281,53,2113537,257,2113536,2105645,513]

theorem envBound52213 : H12AffineFastState.Bounded env52213 := by
  intro p hp
  have h : env52213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52212_52213 : H12AffineEnvironment.transform 14 1 env52212 = env52213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52212 == env52213) = true)

theorem identity52213 : scanCanonicalize (H12AffineFastState.compose env52213 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52213 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52214 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,1,263,16401,2340,304,0,2097152,32,17,2,269,16,2048,2097200,2117665,2341,53,2113537,257,2113536,2097185,513]

theorem envBound52214 : H12AffineFastState.Bounded env52214 := by
  intro p hp
  have h : env52214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52213_52214 : H12AffineEnvironment.transform 12 268 env52213 = env52214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52213 == env52214) = true)

theorem identity52214 : scanCanonicalize (H12AffineFastState.compose env52214 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6705) := by decide +kernel

theorem selectedBound52214 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52215 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,6705,1,263,6688,2340,304,0,2097152,32,17,2,269,16,2048,2097200,2099728,2341,53,2103856,257,2103857,2097185,513]

theorem envBound52215 : H12AffineFastState.Bounded env52215 := by
  intro p hp
  have h : env52215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52214_52215 : H12AffineEnvironment.transform 13 6705 env52214 = env52215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6705 env52214 == env52215) = true)

def env52216 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10281,304,32769,2097152,4194304,4292918,4268073,8193,16,4262183,6332701,6410502,4270350,73791,2113537,257,2187274,2195750,512]

theorem envBound52216 : H12AffineFastState.Bounded env52216 := by
  intro p hp
  have h : env52216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52209_52216 : H12AffineEnvironment.transform 17 10281 env52209 = env52216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52209 == env52216) = true)

theorem identity52216 : scanCanonicalize (H12AffineFastState.compose env52216 (packedSelected [0,7,16] rootPS)) = affineNative (2^(20+1) ^^^ 110619) := by decide +kernel

theorem selectedBound52216 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env52217 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10281,304,32769,110619,4194304,4292918,4268073,8193,16,4262183,4264198,4219165,4270350,73791,127002,257,53265,12605,512]

theorem envBound52217 : H12AffineFastState.Bounded env52217 := by
  intro p hp
  have h : env52217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52216_52217 : H12AffineEnvironment.transform 20 110619 env52216 = env52217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110619 env52216 == env52217) = true)

theorem identity52217 : scanCanonicalize (H12AffineFastState.compose env52217 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(14+1) ^^^ 14620) := by decide +kernel

theorem selectedBound52217 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env52218 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,14620,65536,16401,10281,304,14621,67847,4194304,4274218,4268073,8193,16,4262183,4264198,4219165,4270350,73791,84230,257,26893,12605,512]

theorem envBound52218 : H12AffineFastState.Bounded env52218 := by
  intro p hp
  have h : env52218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52217_52218 : H12AffineEnvironment.transform 14 14620 env52217 = env52218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14620 env52217 == env52218) = true)

theorem identity52218 : scanCanonicalize (H12AffineFastState.compose env52218 (packedSelected [1,3,5,8,11,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound52218 : packedSelected [1,3,5,8,11,14,15,20] rootPS < 2^1333 := by decide +kernel

def env52219 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,2341,14620,65536,2356,10281,304,14621,67847,4194304,4274218,4268073,8193,16,4262183,4264198,4204600,4270350,73791,65571,257,8232,12605,512]

theorem envBound52219 : H12AffineFastState.Bounded env52219 := by
  intro p hp
  have h : env52219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52218_52219 : H12AffineEnvironment.transform 13 2341 env52218 = env52219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env52218 == env52219) = true)

theorem identity52219 : scanCanonicalize (H12AffineFastState.compose env52219 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 79931) := by decide +kernel

theorem selectedBound52219 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env52220 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,2341,14620,65536,2356,10281,304,14621,67847,79931,17,6162,8193,16,12572,10557,69635,4405,73791,65571,257,8232,12605,512]

theorem envBound52220 : H12AffineFastState.Bounded env52220 := by
  intro p hp
  have h : env52220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52219_52220 : H12AffineEnvironment.transform 21 79931 env52219 = env52220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 79931 env52219 == env52220) = true)

theorem identity52220 : scanCanonicalize (H12AffineFastState.compose env52220 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 6461) := by decide +kernel

theorem selectedBound52220 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52221 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,6461,2341,33,65536,2356,4372,304,32,67847,65798,17,6162,6460,16,2081,4096,69635,4405,71938,65571,257,6421,2048,512]

theorem envBound52221 : H12AffineFastState.Bounded env52221 := by
  intro p hp
  have h : env52221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52220_52221 : H12AffineEnvironment.transform 12 6461 env52220 = env52221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6461 env52220 == env52221) = true)

theorem identity52221 : scanCanonicalize (H12AffineFastState.compose env52221 (packedSelected [12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound52221 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env52222 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,6461,2341,33,35,2356,4372,304,32,2340,293,17,6162,6460,16,2081,4096,4128,4405,6433,0,257,6421,2048,512]

theorem envBound52222 : H12AffineFastState.Bounded env52222 := by
  intro p hp
  have h : env52222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52221_52222 : H12AffineEnvironment.transform 15 35 env52221 = env52222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env52221 == env52222) = true)

theorem identity52222 : scanCanonicalize (H12AffineFastState.compose env52222 (packedSelected [4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52222 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env52223 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,6200,2080,33,35,2097,4113,53,32,2081,32,17,6162,6201,16,2081,4096,4128,4144,6180,0,4,6160,2048,512]

theorem envBound52223 : H12AffineFastState.Bounded env52223 := by
  intro p hp
  have h : env52223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52222_52223 : H12AffineEnvironment.transform 7 5 env52222 = env52223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52222 == env52223) = true)

theorem identity52223 : scanCanonicalize (H12AffineFastState.compose env52223 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52223 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env52224 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2065,41,2080,33,35,2097,2048,53,32,2081,32,17,3,40,16,2081,2065,2097,2081,53,0,4,1,2048,512]

theorem envBound52224 : H12AffineFastState.Bounded env52224 := by
  intro p hp
  have h : env52224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52223_52224 : H12AffineEnvironment.transform 11 2065 env52223 = env52224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52223 == env52224) = true)

theorem identity52224 : scanCanonicalize (H12AffineFastState.compose env52224 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52224 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52225 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2065,8,2049,0,2,2064,2048,20,1,2048,1,17,3,9,16,2048,2065,2064,2048,20,0,4,1,2048,512]

theorem envBound52225 : H12AffineFastState.Bounded env52225 := by
  intro p hp
  have h : env52225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52224_52225 : H12AffineEnvironment.transform 4 1 env52224 = env52225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52224 == env52225) = true)

theorem identity52225 : scanCanonicalize (H12AffineFastState.compose env52225 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52225 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52226 : List Nat := [2,4,8,16,1,17,9,5,1,21,2048,2065,8,2049,0,2,2064,2048,20,1,2048,1,17,3,9,16,2048,2065,2064,2048,20,0,4,1,2048,1]

theorem envBound52226 : H12AffineFastState.Bounded env52226 := by
  intro p hp
  have h : env52226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52225_52226 : H12AffineEnvironment.transform 8 1 env52225 = env52226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52225 == env52226) = true)

theorem identity52226 : scanCanonicalize (H12AffineFastState.compose env52226 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound52226 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52227 : List Nat := [2,4,8,16,1,17,9,5,1,21,31,14,8,30,0,2,15,31,20,1,31,1,17,3,9,16,31,14,15,31,20,0,4,1,31,1]

theorem envBound52227 : H12AffineFastState.Bounded env52227 := by
  intro p hp
  have h : env52227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52226_52227 : H12AffineEnvironment.transform 10 31 env52226 = env52227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env52226 == env52227) = true)

def leafEnv52227 : List Nat := [2,4,8,16,1,17,9,5,1,21,31,14,8,30,0,2,15,31,20,1,31,1,17,3,21,9,1,16,31,14,15,31,20,0,4,1,5,3,31,1,1,30,0]

def active52227 : List Nat := [0,1,2,3]

def tree52227 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52227 : H12WitnessSearch.Good tree52227 := H12GlobalWitnessIndex.good

theorem leafIdentity52227 : H12AffineFastState.composeSystem env52227 rootObs = leafEnv52227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52227 rootObs == leafEnv52227) = true)

theorem terminalChecked52227 : H12PackedTerminal.terminalCheckFast leafEnv52227 active52227 tree52227 = true := by decide +kernel

def env52228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound52228 : H12AffineFastState.Bounded env52228 := by
  intro p hp
  have h : env52228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50850_52228 : H12AffineEnvironment.transform 29 155254785 env50850 = env52228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env50850 == env52228) = true)

def env52229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound52229 : H12AffineFastState.Bounded env52229 := by
  intro p hp
  have h : env52229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52228_52229 : H12AffineEnvironment.transform 25 64 env52228 = env52229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env52228 == env52229) = true)

def env52230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound52230 : H12AffineFastState.Bounded env52230 := by
  intro p hp
  have h : env52230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52229_52230 : H12AffineEnvironment.transform 26 30393344 env52229 = env52230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env52229 == env52230) = true)

def env52231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound52231 : H12AffineFastState.Bounded env52231 := by
  intro p hp
  have h : env52231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52230_52231 : H12AffineEnvironment.transform 18 1024 env52230 = env52231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env52230 == env52231) = true)

theorem identity52231 : scanCanonicalize (H12AffineFastState.compose env52231 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound52231 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,4194304,8388608,16777216,8328,64,29868032,16793618,8491470,8830977,25265168,21012831,256,25165874,25223575,25207750]

theorem envBound52232 : H12AffineFastState.Bounded env52232 := by
  intro p hp
  have h : env52232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52231_52232 : H12AffineEnvironment.transform 20 115871 env52231 = env52232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env52231 == env52232) = true)

def env52233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,4194304,8388608,95496,8328,64,13022472,79130,8491470,8830977,8450328,4314199,256,8484154,8492191,8509134]

theorem envBound52233 : H12AffineFastState.Bounded env52233 := by
  intro p hp
  have h : env52233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52232_52233 : H12AffineEnvironment.transform 23 95496 env52232 = env52233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env52232 == env52233) = true)

def env52234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272512,8388608,95496,8328,64,8560008,79130,8491470,8830977,8450328,392407,256,8484154,8492191,8509134]

theorem envBound52234 : H12AffineFastState.Bounded env52234 := by
  intro p hp
  have h : env52234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52233_52234 : H12AffineEnvironment.transform 21 272512 env52233 = env52234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52233 == env52234) = true)

def env52235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,8388608,95496,8192,64,8559872,79130,8491334,8830977,8450328,392287,256,8484154,8492055,8508998]

theorem envBound52235 : H12AffineFastState.Bounded env52235 := by
  intro p hp
  have h : env52235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52234_52235 : H12AffineEnvironment.transform 6 8 env52234 = env52235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52234 == env52235) = true)

def env52236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,16,95496,8192,64,171280,79130,102742,442385,61704,392287,256,95530,103431,120406]

theorem envBound52236 : H12AffineFastState.Bounded env52236 := by
  intro p hp
  have h : env52236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52235_52236 : H12AffineEnvironment.transform 22 16 env52235 = env52236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52235 == env52236) = true)

theorem identity52236 : scanCanonicalize (H12AffineFastState.compose env52236 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,91466,272392,16,95496,8192,64,146509,79130,77835,418124,20565,351490,256,95530,79194,96011]

theorem envBound52237 : H12AffineFastState.Bounded env52237 := by
  intro p hp
  have h : env52237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52236_52237 : H12AffineEnvironment.transform 14 8541 env52236 = env52237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52236 == env52237) = true)

theorem identity52237 : scanCanonicalize (H12AffineFastState.compose env52237 (packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound52237 : packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env52238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,146745,1024,8540,91466,136497,16,95496,8192,64,146509,79130,77835,23669,20565,221243,256,95530,79194,96011]

theorem envBound52238 : H12AffineFastState.Bounded env52238 := by
  intro p hp
  have h : env52238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52237_52238 : H12AffineEnvironment.transform 17 146745 env52237 = env52238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env52237 == env52238) = true)

theorem identity52238 : scanCanonicalize (H12AffineFastState.compose env52238 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52238 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,89378,1024,8540,91466,95530,16,95496,8192,64,89174,79130,77835,23669,20565,32,256,95530,79194,96011]

theorem envBound52239 : H12AffineFastState.Bounded env52239 := by
  intro p hp
  have h : env52239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52238_52239 : H12AffineEnvironment.transform 16 90139 env52238 = env52239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52238 == env52239) = true)

theorem identity52239 : scanCanonicalize (H12AffineFastState.compose env52239 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound52239 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env52240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,114,24681,23888,1024,8540,25912,30040,16,30074,8192,64,23588,13672,12409,23669,20565,32,256,30040,13608,30585]

theorem envBound52240 : H12AffineFastState.Bounded env52240 := by
  intro p hp
  have h : env52240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52239_52240 : H12AffineEnvironment.transform 15 114 env52239 = env52240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env52239 == env52240) = true)

theorem identity52240 : scanCanonicalize (H12AffineFastState.compose env52240 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound52240 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env52241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,114,5220,10589,1024,8540,4405,341,16,375,8192,64,10281,13672,12409,10360,9304,32,256,341,13608,884]

theorem envBound52241 : H12AffineFastState.Bounded env52241 := by
  intro p hp
  have h : env52241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52240_52241 : H12AffineEnvironment.transform 13 13325 env52240 = env52241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env52240 == env52241) = true)

theorem identity52241 : scanCanonicalize (H12AffineFastState.compose env52241 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52241 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env52242 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13325,8232,114,5220,10280,1024,8233,4160,32,16,2,8192,64,10281,13341,12409,10360,9304,32,117,32,13405,513]

theorem envBound52242 : H12AffineFastState.Bounded env52242 := by
  intro p hp
  have h : env52242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52241_52242 : H12AffineEnvironment.transform 7 117 env52241 = env52242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52241 == env52242) = true)

theorem identity52242 : scanCanonicalize (H12AffineFastState.compose env52242 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound52242 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52243 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8192,12393,8232,114,4096,10280,100,8233,4160,32,16,2,8192,64,10281,12409,12409,10360,8252,32,117,32,12345,513]

theorem envBound52243 : H12AffineFastState.Bounded env52243 := by
  intro p hp
  have h : env52243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52242_52243 : H12AffineEnvironment.transform 9 100 env52242 = env52243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env52242 == env52243) = true)

theorem identity52243 : scanCanonicalize (H12AffineFastState.compose env52243 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 6777) := by decide +kernel

theorem selectedBound52243 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52244 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,6777,2576,6737,114,4096,4689,100,6736,4160,32,16,2,6777,64,4688,2560,2560,4609,6725,32,117,32,2624,513]

theorem envBound52244 : H12AffineFastState.Bounded env52244 := by
  intro p hp
  have h : env52244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52243_52244 : H12AffineEnvironment.transform 12 6777 env52243 = env52244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6777 env52243 == env52244) = true)

theorem identity52244 : scanCanonicalize (H12AffineFastState.compose env52244 (packedSelected [1,2,3,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound52244 : packedSelected [1,2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env52245 : List Nat := [2,4,8,16,32,0,8,53,512,36,2048,4096,6713,2576,6673,50,4096,4625,36,6672,4096,32,16,2,6713,0,4624,2560,2560,4609,6661,32,53,32,2560,513]

theorem envBound52245 : H12AffineFastState.Bounded env52245 := by
  intro p hp
  have h : env52245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52244_52245 : H12AffineEnvironment.transform 5 0 env52244 = env52245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env52244 == env52245) = true)

theorem identity52245 : scanCanonicalize (H12AffineFastState.compose env52245 (packedSelected [0,1,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound52245 : packedSelected [0,1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env52246 : List Nat := [2,4,8,16,32,0,8,53,512,36,2048,2048,569,2576,529,50,2048,2577,36,528,2048,32,16,2,569,0,2576,2560,2560,2561,517,32,53,32,2560,513]

theorem envBound52246 : H12AffineFastState.Bounded env52246 := by
  intro p hp
  have h : env52246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52245_52246 : H12AffineEnvironment.transform 11 2048 env52245 = env52246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env52245 == env52246) = true)

theorem identity52246 : scanCanonicalize (H12AffineFastState.compose env52246 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound52246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52247 : List Nat := [2,4,8,16,32,0,8,53,17,36,2048,2048,40,2049,0,50,2048,2048,36,1,2048,32,16,2,40,0,2049,2065,2065,2064,20,32,53,32,2065,16]

theorem envBound52247 : H12AffineFastState.Bounded env52247 := by
  intro p hp
  have h : env52247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52246_52247 : H12AffineEnvironment.transform 8 17 env52246 = env52247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52246 == env52247) = true)

theorem identity52247 : scanCanonicalize (H12AffineFastState.compose env52247 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52248 : List Nat := [2,4,8,16,17,0,8,4,17,21,2048,2048,25,2049,0,3,2048,2048,21,1,2048,17,16,2,25,0,2049,2065,2065,2064,20,17,4,17,2065,16]

theorem envBound52248 : H12AffineFastState.Bounded env52248 := by
  intro p hp
  have h : env52248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52247_52248 : H12AffineEnvironment.transform 4 17 env52247 = env52248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52247 == env52248) = true)

theorem identity52248 : scanCanonicalize (H12AffineFastState.compose env52248 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52249 : List Nat := [2,4,8,1,0,0,8,4,0,4,2048,2048,8,2049,0,3,2048,2048,4,1,2048,0,1,2,8,0,2049,2048,2048,2049,5,0,4,0,2048,1]

theorem envBound52249 : H12AffineFastState.Bounded env52249 := by
  intro p hp
  have h : env52249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52248_52249 : H12AffineEnvironment.transform 3 1 env52248 = env52249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52248 == env52249) = true)

def env52250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,17,95496,8192,64,171281,79130,102743,442384,61705,392287,256,95531,103430,120407]

theorem envBound52250 : H12AffineFastState.Bounded env52250 := by
  intro p hp
  have h : env52250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52235_52250 : H12AffineEnvironment.transform 22 17 env52235 = env52250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52235 == env52250) = true)

theorem identity52250 : scanCanonicalize (H12AffineFastState.compose env52250 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound52250 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1024,32769,115735,41341,17,95496,8192,64,171281,79130,102743,149861,61705,95530,256,95531,103430,120407]

theorem envBound52251 : H12AffineFastState.Bounded env52251 := by
  intro p hp
  have h : env52251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52250_52251 : H12AffineEnvironment.transform 17 35189 env52250 = env52251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env52250 == env52251) = true)

theorem identity52251 : scanCanonicalize (H12AffineFastState.compose env52251 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound52251 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env52252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,46157,35189,1024,32769,115735,41341,17,95496,8192,64,10588,79130,102743,64808,61705,95530,256,95531,103430,120407]

theorem envBound52252 : H12AffineFastState.Bounded env52252 := by
  intro p hp
  have h : env52252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52251_52252 : H12AffineEnvironment.transform 16 46157 env52251 = env52252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env52251 == env52252) = true)

theorem identity52252 : scanCanonicalize (H12AffineFastState.compose env52252 (packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound52252 : packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env52253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21511,46157,35189,1024,32769,36880,41341,17,8463,8192,64,10588,24861,50512,64808,61705,8493,256,8492,49153,33360]

theorem envBound52253 : H12AffineFastState.Bounded env52253 := by
  intro p hp
  have h : env52253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52252_52253 : H12AffineEnvironment.transform 15 21511 env52252 = env52253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env52252 == env52253) = true)

theorem identity52253 : scanCanonicalize (H12AffineFastState.compose env52253 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52253 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,21511,38209,35189,1024,32769,36880,32881,17,3,268,64,2128,16401,50512,56356,53253,33,256,32,49153,33360]

theorem envBound52254 : H12AffineFastState.Bounded env52254 := by
  intro p hp
  have h : env52254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52253_52254 : H12AffineEnvironment.transform 12 268 env52253 = env52254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52253 == env52254) = true)

theorem identity52254 : scanCanonicalize (H12AffineFastState.compose env52254 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52254 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env52255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,263,38209,35189,1024,32769,36880,32881,17,3,268,64,2128,5393,36944,35108,34053,33,256,32,38145,33360]

theorem envBound52255 : H12AffineFastState.Bounded env52255 := by
  intro p hp
  have h : env52255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52254_52255 : H12AffineEnvironment.transform 13 5376 env52254 = env52255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52254 == env52255) = true)

theorem identity52255 : scanCanonicalize (H12AffineFastState.compose env52255 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound52255 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5393,2341,1024,81,4160,33,17,3,268,64,2128,5393,4096,2420,1365,33,256,32,5457,512]

theorem envBound52256 : H12AffineFastState.Bounded env52256 := by
  intro p hp
  have h : env52256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52255_52256 : H12AffineEnvironment.transform 14 80 env52255 = env52256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env52255 == env52256) = true)

theorem identity52256 : scanCanonicalize (H12AffineFastState.compose env52256 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52256 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env52257 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,268,5376,80,263,5393,2309,1024,81,4160,1,17,3,268,64,2128,5393,4096,2388,1365,1,256,0,5457,512]

theorem envBound52257 : H12AffineFastState.Bounded env52257 := by
  intro p hp
  have h : env52257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52256_52257 : H12AffineEnvironment.transform 4 0 env52256 = env52257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52256 == env52257) = true)

theorem identity52257 : scanCanonicalize (H12AffineFastState.compose env52257 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound52257 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env52258 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,88,5204,80,83,5189,2129,1024,81,4160,1,17,3,88,64,2128,5189,4096,2048,1025,1,84,0,5125,512]

theorem envBound52258 : H12AffineFastState.Bounded env52258 := by
  intro p hp
  have h : env52258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52257_52258 : H12AffineEnvironment.transform 7 84 env52257 = env52258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env52257 == env52258) = true)

theorem identity52258 : scanCanonicalize (H12AffineFastState.compose env52258 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound52258 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52259 : List Nat := [2,4,8,16,0,64,8,84,512,1024,80,4096,88,5204,80,83,5189,1,1024,81,4160,1,17,3,88,64,0,5189,4096,80,1025,1,84,0,5125,512]

theorem envBound52259 : H12AffineFastState.Bounded env52259 := by
  intro p hp
  have h : env52259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52258_52259 : H12AffineEnvironment.transform 10 80 env52258 = env52259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env52258 == env52259) = true)

def env52260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,8388608,95496,8193,64,8559873,79130,8491335,8830977,8450328,392286,256,8484154,8492054,8508999]

theorem envBound52260 : H12AffineFastState.Bounded env52260 := by
  intro p hp
  have h : env52260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52234_52260 : H12AffineEnvironment.transform 6 9 env52234 = env52260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52234 == env52260) = true)

def env52261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,16,95496,8193,64,171281,79130,102743,442385,61704,392286,256,95530,103430,120407]

theorem envBound52261 : H12AffineFastState.Bounded env52261 := by
  intro p hp
  have h : env52261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52260_52261 : H12AffineEnvironment.transform 22 16 env52260 = env52261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52260 == env52261) = true)

def env52262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,272393,16,95496,8193,64,56577,79130,102743,294913,61704,392286,256,95530,103430,120407]

theorem envBound52262 : H12AffineFastState.Bounded env52262 := by
  intro p hp
  have h : env52262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52261_52262 : H12AffineEnvironment.transform 16 16400 env52261 = env52262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52261 == env52262) = true)

def env52263 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,272393,16,95496,8193,16,56577,79130,102663,294913,61704,392206,256,95530,103430,120327]

theorem envBound52263 : H12AffineFastState.Bounded env52263 := by
  intro p hp
  have h : env52263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52262_52263 : H12AffineEnvironment.transform 5 16 env52262 = env52263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52262 == env52263) = true)

theorem identity52263 : scanCanonicalize (H12AffineFastState.compose env52263 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound52263 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env52264 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,262144,1024,32769,25629,272393,16,54531,8193,16,56577,38161,12556,294913,61704,285701,256,54561,13325,30220]

theorem envBound52264 : H12AffineFastState.Bounded env52264 := by
  intro p hp
  have h : env52264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52263_52264 : H12AffineEnvironment.transform 15 40971 env52263 = env52264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env52263 == env52264) = true)

theorem identity52264 : scanCanonicalize (H12AffineFastState.compose env52264 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52264 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52265 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1024,32769,25629,33,16,54531,8193,16,56577,38161,12556,43049,61704,29741,256,54561,13325,30220]

theorem envBound52265 : H12AffineFastState.Bounded env52265 := by
  intro p hp
  have h : env52265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52264_52265 : H12AffineEnvironment.transform 17 10280 env52264 = env52265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52264 == env52265) = true)

theorem identity52265 : scanCanonicalize (H12AffineFastState.compose env52265 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 28728) := by decide +kernel

theorem selectedBound52265 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env52266 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,28728,20531,16400,10280,1024,28729,25629,33,16,9531,8193,16,11577,25897,12556,22545,304,29741,256,9497,13325,30220]

theorem envBound52266 : H12AffineFastState.Bounded env52266 := by
  intro p hp
  have h : env52266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52265_52266 : H12AffineEnvironment.transform 14 28728 env52265 = env52266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28728 env52265 == env52266) = true)

theorem identity52266 : scanCanonicalize (H12AffineFastState.compose env52266 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound52266 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env52267 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,20497,20531,16400,2049,1024,20496,17460,33,16,1298,40,16,3344,17664,4389,22545,304,21508,256,1328,5156,22053]

theorem envBound52267 : H12AffineFastState.Bounded env52267 := by
  intro p hp
  have h : env52267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52266_52267 : H12AffineEnvironment.transform 12 41 env52266 = env52267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env52266 == env52267) = true)

def env52268 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,272393,16,95496,8193,17,56577,79130,102662,294913,61704,392207,256,95530,103430,120326]

theorem envBound52268 : H12AffineFastState.Bounded env52268 := by
  intro p hp
  have h : env52268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52262_52268 : H12AffineEnvironment.transform 5 17 env52262 = env52268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52262 == env52268) = true)

theorem identity52268 : scanCanonicalize (H12AffineFastState.compose env52268 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound52268 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env52269 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,43049,1024,32769,115734,32800,16,95496,8193,17,56577,79130,102662,10280,61704,87078,256,95530,103430,120326]

theorem envBound52269 : H12AffineFastState.Bounded env52269 := by
  intro p hp
  have h : env52269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52268_52269 : H12AffineEnvironment.transform 17 43049 env52268 = env52269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env52268 == env52269) = true)

theorem identity52269 : scanCanonicalize (H12AffineFastState.compose env52269 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52269 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52270 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,65536,16400,10281,1024,1,82966,32,16,95496,8193,17,23809,79130,69894,10280,28936,87078,256,95530,70662,87558]

theorem envBound52270 : H12AffineFastState.Bounded env52270 := by
  intro p hp
  have h : env52270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52269_52270 : H12AffineEnvironment.transform 14 0 env52269 = env52270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52269 == env52270) = true)

theorem identity52270 : scanCanonicalize (H12AffineFastState.compose env52270 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52270 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env52271 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10281,1024,1,25629,32,16,21763,8193,17,23809,5393,12557,10280,28936,29741,256,21793,13325,30221]

theorem envBound52271 : H12AffineFastState.Bounded env52271 := by
  intro p hp
  have h : env52271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52270_52271 : H12AffineEnvironment.transform 15 8203 env52270 = env52271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52270 == env52271) = true)

theorem identity52271 : scanCanonicalize (H12AffineFastState.compose env52271 (packedSelected [0,1,3,5,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound52271 : packedSelected [0,1,3,5,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52272 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7181,16384,0,7174,16400,5156,1024,1,22544,32,16,21763,7180,17,23809,5393,3328,5157,19717,18464,256,21793,2048,18944]

theorem envBound52272 : H12AffineFastState.Bounded env52272 := by
  intro p hp
  have h : env52272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52271_52272 : H12AffineEnvironment.transform 12 7181 env52271 = env52272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env52271 == env52272) = true)

theorem identity52272 : scanCanonicalize (H12AffineFastState.compose env52272 (packedSelected [10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound52272 : packedSelected [10,11] rootPS < 2^1333 := by decide +kernel

def env52273 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,40,16384,0,35,16400,2049,1024,1,17461,32,16,18726,41,17,16676,2356,3328,2048,19717,18464,256,18692,2048,18944]

theorem envBound52273 : H12AffineFastState.Bounded env52273 := by
  intro p hp
  have h : env52273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52272_52273 : H12AffineEnvironment.transform 11 3109 env52272 = env52273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env52272 == env52273) = true)

theorem identity52273 : scanCanonicalize (H12AffineFastState.compose env52273 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52273 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52274 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,40,16384,0,35,16400,2049,1024,1,17461,32,16,18435,41,17,16385,2065,3109,2048,19488,18464,37,18465,2048,18944]

theorem envBound52274 : H12AffineFastState.Bounded env52274 := by
  intro p hp
  have h : env52274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52273_52274 : H12AffineEnvironment.transform 7 37 env52273 = env52274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52273 == env52274) = true)

theorem identity52274 : scanCanonicalize (H12AffineFastState.compose env52274 (packedSelected [4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52274 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env52275 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2064,40,16384,0,35,16400,2049,53,1,16384,32,16,18435,41,17,16385,2065,2064,2048,18453,18464,37,18465,2048,18944]

theorem envBound52275 : H12AffineFastState.Bounded env52275 := by
  intro p hp
  have h : env52275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52274_52275 : H12AffineEnvironment.transform 9 53 env52274 = env52275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52274 == env52275) = true)

def env52276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115734,272393,16,95496,8193,64,56576,79130,102743,294912,61704,392286,256,95530,103430,120407]

theorem envBound52276 : H12AffineFastState.Bounded env52276 := by
  intro p hp
  have h : env52276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52261_52276 : H12AffineEnvironment.transform 16 16401 env52261 = env52276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52261 == env52276) = true)

theorem identity52276 : scanCanonicalize (H12AffineFastState.compose env52276 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound52276 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,262144,1024,32769,4160,272393,16,41310,8193,64,56576,57676,17665,294912,61704,272392,256,41340,16464,513]

theorem envBound52277 : H12AffineFastState.Bounded env52277 := by
  intro p hp
  have h : env52277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52276_52277 : H12AffineEnvironment.transform 15 54358 env52276 = env52277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env52276 == env52277) = true)

theorem identity52277 : scanCanonicalize (H12AffineFastState.compose env52277 (packedSelected [0,1,7,8,12,19,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound52277 : packedSelected [0,1,7,8,12,19,20,38] rootPS < 2^1333 := by decide +kernel

def env52278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,35189,1024,32769,4160,41340,16,41310,8193,64,56576,57676,17665,2421,61704,41341,256,41340,16464,513]

theorem envBound52278 : H12AffineFastState.Bounded env52278 := by
  intro p hp
  have h : env52278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52277_52278 : H12AffineEnvironment.transform 17 35189 env52277 = env52278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env52277 == env52278) = true)

theorem identity52278 : scanCanonicalize (H12AffineFastState.compose env52278 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52278 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env52279 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,16401,35108,1024,32769,4113,41261,16,41231,8193,17,56576,57629,17665,2340,61704,41260,256,41261,16385,513]

theorem envBound52279 : H12AffineFastState.Bounded env52279 := by
  intro p hp
  have h : env52279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52278_52279 : H12AffineEnvironment.transform 5 17 env52278 = env52279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52278 == env52279) = true)

theorem identity52279 : scanCanonicalize (H12AffineFastState.compose env52279 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52279 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env52280 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,54279,16401,35108,1024,32769,4113,32801,16,32771,269,17,56576,49169,17665,2340,53252,32800,256,32801,16385,513]

theorem envBound52280 : H12AffineFastState.Bounded env52280 := by
  intro p hp
  have h : env52280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52279_52280 : H12AffineEnvironment.transform 12 268 env52279 = env52280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52279 == env52280) = true)

theorem identity52280 : scanCanonicalize (H12AffineFastState.compose env52280 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52280 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env52281 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,21510,16401,2341,1024,0,4113,32,16,2,269,17,23809,16400,17665,2340,20485,33,256,32,16385,513]

theorem envBound52281 : H12AffineFastState.Bounded env52281 := by
  intro p hp
  have h : env52281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52280_52281 : H12AffineEnvironment.transform 14 1 env52280 = env52281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52280 == env52281) = true)

theorem identity52281 : scanCanonicalize (H12AffineFastState.compose env52281 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52281 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52282 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1024,0,4113,32,16,2,269,17,2049,5392,4097,2340,1285,33,256,32,5377,513]

theorem envBound52282 : H12AffineFastState.Bounded env52282 := by
  intro p hp
  have h : env52282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52281_52282 : H12AffineEnvironment.transform 13 5376 env52281 = env52282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52281 == env52282) = true)

theorem identity52282 : scanCanonicalize (H12AffineFastState.compose env52282 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52283 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,9,5125,1,3,5140,2080,1024,0,4113,32,16,2,8,17,2049,5141,4097,2081,1024,33,5,32,5124,513]

theorem envBound52283 : H12AffineFastState.Bounded env52283 := by
  intro p hp
  have h : env52283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52282_52283 : H12AffineEnvironment.transform 7 5 env52282 = env52283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52282 == env52283) = true)

theorem identity52283 : scanCanonicalize (H12AffineFastState.compose env52283 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52283 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52284 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,9,4145,1,3,4128,2080,52,0,4113,32,16,2,8,17,2049,4129,4097,2081,52,33,5,32,4144,513]

theorem envBound52284 : H12AffineFastState.Bounded env52284 := by
  intro p hp
  have h : env52284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52283_52284 : H12AffineEnvironment.transform 9 52 env52283 = env52284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52283 == env52284) = true)

theorem identity52284 : scanCanonicalize (H12AffineFastState.compose env52284 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound52284 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52285 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2608,9,2561,1,3,2576,2080,52,0,2593,32,16,2,8,17,2049,2577,2609,2081,52,33,5,32,2560,513]

theorem envBound52285 : H12AffineFastState.Bounded env52285 := by
  intro p hp
  have h : env52285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52284_52285 : H12AffineEnvironment.transform 11 2608 env52284 = env52285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env52284 == env52285) = true)

theorem identity52285 : scanCanonicalize (H12AffineFastState.compose env52285 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound52285 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52286 : List Nat := [2,4,8,16,32,17,9,5,512,52,512,48,9,1,1,3,16,544,52,0,33,32,16,2,8,17,513,17,49,545,52,33,5,32,0,513]

theorem envBound52286 : H12AffineFastState.Bounded env52286 := by
  intro p hp
  have h : env52286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52285_52286 : H12AffineEnvironment.transform 10 512 env52285 = env52286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env52285 == env52286) = true)

theorem identity52286 : scanCanonicalize (H12AffineFastState.compose env52286 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound52286 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52287 : List Nat := [2,4,8,16,32,17,9,5,48,52,48,48,9,1,1,3,16,16,52,0,33,32,16,2,8,17,49,17,49,17,52,33,5,32,0,49]

theorem envBound52287 : H12AffineFastState.Bounded env52287 := by
  intro p hp
  have h : env52287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52286_52287 : H12AffineEnvironment.transform 8 48 env52286 = env52287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env52286 == env52287) = true)

theorem identity52287 : scanCanonicalize (H12AffineFastState.compose env52287 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52287 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52288 : List Nat := [2,4,8,16,1,17,9,5,17,21,17,17,9,1,1,3,16,16,21,0,0,1,16,2,8,17,16,17,16,17,21,0,5,1,0,16]

theorem envBound52288 : H12AffineFastState.Bounded env52288 := by
  intro p hp
  have h : env52288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52287_52288 : H12AffineEnvironment.transform 4 1 env52287 = env52288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52287 == env52288) = true)

theorem identity52288 : scanCanonicalize (H12AffineFastState.compose env52288 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52289 : List Nat := [2,4,8,10,1,11,9,5,11,15,11,11,9,1,1,3,10,10,15,0,0,1,10,2,8,11,10,11,10,11,15,0,5,1,0,10]

theorem envBound52289 : H12AffineFastState.Bounded env52289 := by
  intro p hp
  have h : env52289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52288_52289 : H12AffineEnvironment.transform 3 10 env52288 = env52289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52288 == env52289) = true)

def env52290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,17,95496,8193,64,171280,79130,102742,442384,61705,392286,256,95531,103431,120406]

theorem envBound52290 : H12AffineFastState.Bounded env52290 := by
  intro p hp
  have h : env52290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52260_52290 : H12AffineEnvironment.transform 22 17 env52260 = env52290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52260 == env52290) = true)

theorem identity52290 : scanCanonicalize (H12AffineFastState.compose env52290 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52290 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115734,32,17,95496,8193,64,171280,79130,102742,190521,61705,119927,256,95531,103431,120406]

theorem envBound52291 : H12AffineFastState.Bounded env52291 := by
  intro p hp
  have h : env52291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52290_52291 : H12AffineEnvironment.transform 17 10281 env52290 = env52291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52290 == env52291) = true)

theorem identity52291 : scanCanonicalize (H12AffineFastState.compose env52291 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound52291 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env52292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46156,10281,1024,32769,115734,32,17,95496,8193,64,10588,79130,102742,23669,61705,119927,256,95531,103431,120406]

theorem envBound52292 : H12AffineFastState.Bounded env52292 := by
  intro p hp
  have h : env52292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52291_52292 : H12AffineEnvironment.transform 16 46156 env52291 = env52292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env52291 == env52292) = true)

theorem identity52292 : scanCanonicalize (H12AffineFastState.compose env52292 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52292 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,46156,10281,1024,32769,102679,32,17,73737,8193,64,10588,79130,102742,2420,41992,98678,256,73770,103431,99159]

theorem envBound52293 : H12AffineFastState.Bounded env52293 := by
  intro p hp
  have h : env52293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52292_52293 : H12AffineEnvironment.transform 13 5377 env52292 = env52293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52292 == env52293) = true)

theorem identity52293 : scanCanonicalize (H12AffineFastState.compose env52293 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound52293 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env52294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,46156,10281,1024,32769,4160,32,17,41310,8193,64,10588,46157,4097,2420,41992,33,256,41341,5456,512]

theorem envBound52294 : H12AffineFastState.Bounded env52294 := by
  intro p hp
  have h : env52294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52293_52294 : H12AffineEnvironment.transform 15 33111 env52293 = env52294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env52293 == env52294) = true)

theorem identity52294 : scanCanonicalize (H12AffineFastState.compose env52294 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5164) := by decide +kernel

theorem selectedBound52294 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5164,5377,32768,33111,32864,7173,1024,32769,4160,32,17,38258,5165,64,7536,32865,4097,2420,36900,33,256,38225,5456,512]

theorem envBound52295 : H12AffineFastState.Bounded env52295 := by
  intro p hp
  have h : env52295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52294_52295 : H12AffineEnvironment.transform 12 5164 env52294 = env52295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5164 env52294 == env52295) = true)

theorem identity52295 : scanCanonicalize (H12AffineFastState.compose env52295 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 4404) := by decide +kernel

theorem selectedBound52295 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5164,5377,4404,4195,4436,7173,1024,4405,4160,32,17,1094,5165,64,7536,4437,4097,2420,272,33,256,1125,5456,512]

theorem envBound52296 : H12AffineFastState.Bounded env52296 := by
  intro p hp
  have h : env52296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52295_52296 : H12AffineEnvironment.transform 14 4404 env52295 = env52296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4404 env52295 == env52296) = true)

theorem identity52296 : scanCanonicalize (H12AffineFastState.compose env52296 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52296 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env52297 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,5164,5157,4112,4195,4208,7173,1024,4113,4160,32,17,1094,5165,64,7252,4209,4097,2128,52,33,36,1125,5236,512]

theorem envBound52297 : H12AffineFastState.Bounded env52297 := by
  intro p hp
  have h : env52297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52296_52297 : H12AffineEnvironment.transform 7 36 env52296 = env52297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52296 == env52297) = true)

theorem identity52297 : scanCanonicalize (H12AffineFastState.compose env52297 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound52297 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env52298 : List Nat := [2,4,8,16,32,64,9,36,512,21,2048,4096,4153,4144,4112,4195,4208,6160,21,4113,4160,32,17,83,4152,64,6209,4209,4097,2128,52,33,36,112,4193,512]

theorem envBound52298 : H12AffineFastState.Bounded env52298 := by
  intro p hp
  have h : env52298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52297_52298 : H12AffineEnvironment.transform 9 21 env52297 = env52298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52297 == env52298) = true)

theorem identity52298 : scanCanonicalize (H12AffineFastState.compose env52298 (packedSelected [3,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound52298 : packedSelected [3,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52299 : List Nat := [2,4,8,16,32,64,9,36,512,21,561,4096,4153,4144,4112,4195,4208,4641,21,4113,4160,32,17,83,4152,64,4720,4209,4097,609,52,33,36,112,4193,512]

theorem envBound52299 : H12AffineFastState.Bounded env52299 := by
  intro p hp
  have h : env52299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52298_52299 : H12AffineEnvironment.transform 10 561 env52298 = env52299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env52298 == env52299) = true)

theorem identity52299 : scanCanonicalize (H12AffineFastState.compose env52299 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound52299 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env52300 : List Nat := [2,4,8,16,32,64,9,36,512,21,561,97,88,81,113,2,17,576,21,112,33,32,17,83,89,64,529,16,96,609,52,33,36,112,0,512]

theorem envBound52300 : H12AffineFastState.Bounded env52300 := by
  intro p hp
  have h : env52300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52299_52300 : H12AffineEnvironment.transform 11 97 env52299 = env52300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env52299 == env52300) = true)

theorem identity52300 : scanCanonicalize (H12AffineFastState.compose env52300 (packedSelected [0,2,6] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound52300 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env52301 : List Nat := [2,4,8,16,32,64,9,36,96,21,81,97,88,81,113,2,17,32,21,112,33,32,17,83,89,64,113,16,96,1,52,33,36,112,0,96]

theorem envBound52301 : H12AffineFastState.Bounded env52301 := by
  intro p hp
  have h : env52301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52300_52301 : H12AffineEnvironment.transform 8 96 env52300 = env52301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env52300 == env52301) = true)

theorem identity52301 : scanCanonicalize (H12AffineFastState.compose env52301 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52301 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52302 : List Nat := [2,4,8,16,32,17,9,36,49,21,0,48,9,0,32,2,17,32,21,33,33,32,17,2,8,17,32,16,49,1,52,33,36,33,0,49]

theorem envBound52302 : H12AffineFastState.Bounded env52302 := by
  intro p hp
  have h : env52302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52301_52302 : H12AffineEnvironment.transform 5 17 env52301 = env52302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52301 == env52302) = true)

def env52303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,8388608,95496,8328,64,8560009,79130,8491470,8830977,8450328,392406,256,8484154,8492191,8509134]

theorem envBound52303 : H12AffineFastState.Bounded env52303 := by
  intro p hp
  have h : env52303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52233_52303 : H12AffineEnvironment.transform 21 272513 env52233 = env52303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52233 == env52303) = true)

theorem identity52303 : scanCanonicalize (H12AffineFastState.compose env52303 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound52303 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,16,95496,8328,64,171417,79130,102878,442385,61704,392406,256,95530,103567,120542]

theorem envBound52304 : H12AffineFastState.Bounded env52304 := by
  intro p hp
  have h : env52304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52303_52304 : H12AffineEnvironment.transform 22 16 env52303 = env52304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52303 == env52304) = true)

def env52305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,16,95496,8192,64,171281,79130,102742,442385,61704,392286,256,95530,103431,120406]

theorem envBound52305 : H12AffineFastState.Bounded env52305 := by
  intro p hp
  have h : env52305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52304_52305 : H12AffineEnvironment.transform 6 8 env52304 = env52305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52304 == env52305) = true)

theorem identity52305 : scanCanonicalize (H12AffineFastState.compose env52305 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,91466,272393,16,95496,8192,64,146508,79130,77835,418124,20565,351491,256,95530,79194,96011]

theorem envBound52306 : H12AffineFastState.Bounded env52306 := by
  intro p hp
  have h : env52306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52305_52306 : H12AffineEnvironment.transform 14 8541 env52305 = env52306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52305 == env52306) = true)

theorem identity52306 : scanCanonicalize (H12AffineFastState.compose env52306 (packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52306 : packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env52307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,262144,1024,8540,91466,272393,16,95496,8192,64,89175,79130,77835,328023,20565,351491,256,95530,79194,96011]

theorem envBound52307 : H12AffineFastState.Bounded env52307 := by
  intro p hp
  have h : env52307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52306_52307 : H12AffineEnvironment.transform 16 90139 env52306 = env52307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52306 == env52307) = true)

theorem identity52307 : scanCanonicalize (H12AffineFastState.compose env52307 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound52307 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,5393,262144,1024,8540,4160,272393,16,2,8192,64,10589,16400,17665,291933,20565,272393,256,32,16464,513]

theorem envBound52308 : H12AffineFastState.Bounded env52308 := by
  intro p hp
  have h : env52308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52307_52308 : H12AffineEnvironment.transform 15 29962 env52307 = env52308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env52307 == env52308) = true)

theorem identity52308 : scanCanonicalize (H12AffineFastState.compose env52308 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52308 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52309 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,28699,4096,262144,273,8540,4160,272393,16,2,8192,64,10589,16400,16400,291148,20565,272393,256,32,16464,513]

theorem envBound52309 : H12AffineFastState.Bounded env52309 := by
  intro p hp
  have h : env52309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52308_52309 : H12AffineEnvironment.transform 9 273 env52308 = env52309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52308 == env52309) = true)

theorem identity52309 : scanCanonicalize (H12AffineFastState.compose env52309 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52309 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env52310 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,28699,4096,10280,273,8540,4160,33,16,2,8192,64,10589,16400,16400,22884,20565,33,256,32,16464,513]

theorem envBound52310 : H12AffineFastState.Bounded env52310 := by
  intro p hp
  have h : env52310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52309_52310 : H12AffineEnvironment.transform 17 10280 env52309 = env52310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52309 == env52310) = true)

theorem identity52310 : scanCanonicalize (H12AffineFastState.compose env52310 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound52310 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52311 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,8192,16384,8541,27006,2405,10280,273,8540,2341,33,16,2,8192,64,10589,16400,16400,16385,18736,33,256,32,16464,513]

theorem envBound52311 : H12AffineFastState.Bounded env52311 := by
  intro p hp
  have h : env52311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52310_52311 : H12AffineEnvironment.transform 11 2405 env52310 = env52311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env52310 == env52311) = true)

theorem identity52311 : scanCanonicalize (H12AffineFastState.compose env52311 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound52311 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env52312 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,8192,2048,8541,8574,2405,10280,273,8540,2341,33,16,2,8192,64,10589,2064,2064,2049,304,33,256,32,2128,513]

theorem envBound52312 : H12AffineFastState.Bounded env52312 := by
  intro p hp
  have h : env52312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52311_52312 : H12AffineEnvironment.transform 13 2048 env52311 = env52312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env52311 == env52312) = true)

theorem identity52312 : scanCanonicalize (H12AffineFastState.compose env52312 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52312 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env52313 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,269,2048,80,115,2405,2341,273,81,2341,33,16,2,269,64,2128,2064,2064,2049,304,33,256,32,2128,513]

theorem envBound52313 : H12AffineFastState.Bounded env52313 := by
  intro p hp
  have h : env52313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52312_52313 : H12AffineEnvironment.transform 12 269 env52312 = env52313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52312 == env52313) = true)

theorem identity52313 : scanCanonicalize (H12AffineFastState.compose env52313 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52313 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52314 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2112,40,2048,80,115,2112,2048,52,81,2048,33,16,2,40,64,2128,2064,2064,2049,21,33,37,32,2128,513]

theorem envBound52314 : H12AffineFastState.Bounded env52314 := by
  intro p hp
  have h : env52314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52313_52314 : H12AffineEnvironment.transform 7 37 env52313 = env52314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52313 == env52314) = true)

theorem identity52314 : scanCanonicalize (H12AffineFastState.compose env52314 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound52314 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env52315 : List Nat := [2,4,8,16,32,64,8,37,32,52,2048,2112,40,2048,80,115,2112,2048,52,81,2048,33,16,2,40,64,2128,2064,2064,2049,21,33,37,32,2128,33]

theorem envBound52315 : H12AffineFastState.Bounded env52315 := by
  intro p hp
  have h : env52315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52314_52315 : H12AffineEnvironment.transform 8 32 env52314 = env52315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env52314 == env52315) = true)

theorem identity52315 : scanCanonicalize (H12AffineFastState.compose env52315 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound52315 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52316 : List Nat := [2,4,8,16,32,49,8,37,32,52,2048,2097,40,2048,33,2,2097,2048,52,32,2048,33,16,2,40,49,2081,2064,2064,2049,21,33,37,32,2081,33]

theorem envBound52316 : H12AffineFastState.Bounded env52316 := by
  intro p hp
  have h : env52316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52315_52316 : H12AffineEnvironment.transform 5 49 env52315 = env52316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env52315 == env52316) = true)

theorem identity52316 : scanCanonicalize (H12AffineFastState.compose env52316 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52316 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52317 : List Nat := [2,4,8,16,1,16,8,4,1,21,2048,2064,9,2048,0,2,2064,2048,21,1,2048,0,16,2,9,16,2048,2064,2064,2049,21,0,4,1,2048,0]

theorem envBound52317 : H12AffineFastState.Bounded env52317 := by
  intro p hp
  have h : env52317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52316_52317 : H12AffineEnvironment.transform 4 1 env52316 = env52317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52316 == env52317) = true)

theorem identity52317 : scanCanonicalize (H12AffineFastState.compose env52317 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52317 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52318 : List Nat := [2,4,8,16,1,16,8,4,1,21,1,17,9,1,0,2,17,1,21,1,1,0,16,2,9,16,1,17,17,0,21,0,4,1,1,0]

theorem envBound52318 : H12AffineFastState.Bounded env52318 := by
  intro p hp
  have h : env52318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52317_52318 : H12AffineEnvironment.transform 10 1 env52317 = env52318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52317 == env52318) = true)

theorem identity52318 : scanCanonicalize (H12AffineFastState.compose env52318 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52318 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52319 : List Nat := [2,4,8,0,1,0,8,4,1,5,1,1,9,1,0,2,1,1,5,1,1,0,0,2,9,0,1,1,1,0,5,0,4,1,1,0]

theorem envBound52319 : H12AffineFastState.Bounded env52319 := by
  intro p hp
  have h : env52319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52318_52319 : H12AffineEnvironment.transform 3 0 env52318 = env52319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52318 == env52319) = true)

def env52320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,16,95496,8193,64,171280,79130,102743,442385,61704,392287,256,95530,103430,120407]

theorem envBound52320 : H12AffineFastState.Bounded env52320 := by
  intro p hp
  have h : env52320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52304_52320 : H12AffineEnvironment.transform 6 9 env52304 = env52320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52304 == env52320) = true)

def env52321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,272392,16,95496,8193,64,56576,79130,102743,294913,61704,392287,256,95530,103430,120407]

theorem envBound52321 : H12AffineFastState.Bounded env52321 := by
  intro p hp
  have h : env52321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52320_52321 : H12AffineEnvironment.transform 16 16400 env52320 = env52321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52320 == env52321) = true)

def env52322 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,272392,16,95496,8193,16,56576,79130,102663,294913,61704,392207,256,95530,103430,120327]

theorem envBound52322 : H12AffineFastState.Bounded env52322 := by
  intro p hp
  have h : env52322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52321_52322 : H12AffineEnvironment.transform 5 16 env52321 = env52322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52321 == env52322) = true)

theorem identity52322 : scanCanonicalize (H12AffineFastState.compose env52322 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52322 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env52323 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1024,21761,69910,272392,16,95496,8193,16,2048,79130,82951,283905,9224,338191,256,95530,82182,66311]

theorem envBound52323 : H12AffineFastState.Bounded env52323 := by
  intro p hp
  have h : env52323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52322_52323 : H12AffineEnvironment.transform 14 21760 env52322 = env52323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52322 == env52323) = true)

theorem identity52323 : scanCanonicalize (H12AffineFastState.compose env52323 (packedSelected [3,4,7,9,10,19,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound52323 : packedSelected [3,4,7,9,10,19,24,27] rootPS < 2^1333 := by decide +kernel

def env52324 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,65536,13340,262144,1024,8461,69910,272392,16,65796,8193,16,2048,79130,77835,270605,9224,338191,256,65830,79114,66311]

theorem envBound52324 : H12AffineFastState.Bounded env52324 := by
  intro p hp
  have h : env52324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52323_52324 : H12AffineEnvironment.transform 13 13324 env52323 = env52324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env52323 == env52324) = true)

theorem identity52324 : scanCanonicalize (H12AffineFastState.compose env52324 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound52324 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env52325 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,65536,13340,2341,1024,8461,69910,8493,16,65796,8193,16,2048,79130,77835,10280,9224,73770,256,65830,79114,66311]

theorem envBound52325 : H12AffineFastState.Bounded env52325 := by
  intro p hp
  have h : env52325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52324_52325 : H12AffineEnvironment.transform 17 2341 env52324 = env52325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env52324 == env52325) = true)

theorem identity52325 : scanCanonicalize (H12AffineFastState.compose env52325 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52325 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env52326 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,8202,13340,2341,1024,8461,12572,8493,16,8462,8193,16,2048,5392,4097,10280,9224,32,256,8492,5376,8973]

theorem envBound52326 : H12AffineFastState.Bounded env52326 := by
  intro p hp
  have h : env52326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52325_52326 : H12AffineEnvironment.transform 15 8202 env52325 = env52326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52325 == env52326) = true)

theorem identity52326 : scanCanonicalize (H12AffineFastState.compose env52326 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52326 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52327 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,13324,8232,8202,13340,2049,1024,8233,12344,8201,16,8234,8193,16,2048,5172,4097,10280,9224,32,36,8200,5156,8745]

theorem envBound52327 : H12AffineFastState.Bounded env52327 := by
  intro p hp
  have h : env52327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52326_52327 : H12AffineEnvironment.transform 7 36 env52326 = env52327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52326 == env52327) = true)

theorem identity52327 : scanCanonicalize (H12AffineFastState.compose env52327 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound52327 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env52328 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2096,8192,11324,8232,8202,11308,2049,1024,8233,10248,8201,16,8234,8193,16,2048,3076,2097,10280,9224,32,36,8200,3092,8745]

theorem envBound52328 : H12AffineFastState.Bounded env52328 := by
  intro p hp
  have h : env52328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52327_52328 : H12AffineEnvironment.transform 11 2096 env52327 = env52328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env52327 == env52328) = true)

theorem identity52328 : scanCanonicalize (H12AffineFastState.compose env52328 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52328 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52329 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,2065,8192,11293,8201,8202,11277,2049,1024,8200,10248,8201,16,8203,8193,16,2048,3076,2064,10249,9224,1,5,8200,3092,8712]

theorem envBound52329 : H12AffineFastState.Bounded env52329 := by
  intro p hp
  have h : env52329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52328_52329 : H12AffineEnvironment.transform 4 1 env52328 = env52329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52328 == env52329) = true)

theorem identity52329 : scanCanonicalize (H12AffineFastState.compose env52329 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound52329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52330 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,2065,8,3093,1,2,3077,2049,1024,0,2048,1,16,3,9,16,2048,3076,2064,2049,1024,1,5,0,3092,512]

theorem envBound52330 : H12AffineFastState.Bounded env52330 := by
  intro p hp
  have h : env52330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52329_52330 : H12AffineEnvironment.transform 12 8 env52329 = env52330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env52329 == env52330) = true)

def env52331 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,272392,16,95496,8193,17,56576,79130,102662,294913,61704,392206,256,95530,103430,120326]

theorem envBound52331 : H12AffineFastState.Bounded env52331 := by
  intro p hp
  have h : env52331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52321_52331 : H12AffineEnvironment.transform 5 17 env52321 = env52331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52321 == env52331) = true)

theorem identity52331 : scanCanonicalize (H12AffineFastState.compose env52331 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound52331 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env52332 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,122146,1024,32769,115734,128298,16,95496,8193,17,56576,79130,102662,89379,61704,8492,256,95530,103430,120326]

theorem envBound52332 : H12AffineFastState.Bounded env52332 := by
  intro p hp
  have h : env52332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52331_52332 : H12AffineEnvironment.transform 17 122146 env52331 = env52332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env52331 == env52332) = true)

theorem identity52332 : scanCanonicalize (H12AffineFastState.compose env52332 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound52332 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env52333 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,16400,56357,1024,32769,50449,62509,16,29711,8193,17,56576,13341,36865,23588,61704,8492,256,29741,38145,55041]

theorem envBound52333 : H12AffineFastState.Bounded env52333 := by
  intro p hp
  have h : env52333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52332_52333 : H12AffineEnvironment.transform 15 263 env52332 = env52333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env52332 == env52333) = true)

theorem identity52333 : scanCanonicalize (H12AffineFastState.compose env52333 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52333 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52334 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,263,16400,56357,1024,32769,50449,54561,16,21763,269,17,56576,5393,36865,23588,53252,32,256,21793,38145,55041]

theorem envBound52334 : H12AffineFastState.Bounded env52334 := by
  intro p hp
  have h : env52334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52333_52334 : H12AffineEnvironment.transform 12 268 env52333 = env52334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52333 == env52334) = true)

theorem identity52334 : scanCanonicalize (H12AffineFastState.compose env52334 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound52334 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env52335 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,32,268,16384,32768,263,16400,52229,1024,32769,50449,50433,16,17699,269,17,52512,1329,32801,19460,49188,32,256,17665,34081,50977]

theorem envBound52335 : H12AffineFastState.Bounded env52335 := by
  intro p hp
  have h : env52335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52334_52335 : H12AffineEnvironment.transform 11 32 env52334 = env52335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env52334 == env52335) = true)

theorem identity52335 : scanCanonicalize (H12AffineFastState.compose env52335 (packedSelected [4,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 789) := by decide +kernel

theorem selectedBound52335 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env52336 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,32,268,16384,789,263,16400,20240,1024,788,17924,17940,16,17699,269,17,20021,1329,820,19460,17201,32,256,17665,1588,17460]

theorem envBound52336 : H12AffineFastState.Bounded env52336 := by
  intro p hp
  have h : env52336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52335_52336 : H12AffineEnvironment.transform 14 789 env52335 = env52336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 789 env52335 == env52336) = true)

def env52337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115734,272392,16,95496,8193,64,56577,79130,102743,294912,61704,392287,256,95530,103430,120407]

theorem envBound52337 : H12AffineFastState.Bounded env52337 := by
  intro p hp
  have h : env52337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52320_52337 : H12AffineEnvironment.transform 16 16401 env52320 = env52337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52320 == env52337) = true)

theorem identity52337 : scanCanonicalize (H12AffineFastState.compose env52337 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound52337 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,262144,1024,32769,4160,272392,16,41310,8193,64,56577,57676,17665,294912,61704,272393,256,41340,16464,513]

theorem envBound52338 : H12AffineFastState.Bounded env52338 := by
  intro p hp
  have h : env52338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52337_52338 : H12AffineEnvironment.transform 15 54358 env52337 = env52338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env52337 == env52338) = true)

theorem identity52338 : scanCanonicalize (H12AffineFastState.compose env52338 (packedSelected [0,1,7,8,12,19,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52338 : packedSelected [0,1,7,8,12,19,20,38] rootPS < 2^1333 := by decide +kernel

def env52339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,10281,1024,32769,4160,33,16,41310,8193,64,56577,57676,17665,43049,61704,32,256,41340,16464,513]

theorem envBound52339 : H12AffineFastState.Bounded env52339 := by
  intro p hp
  have h : env52339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52338_52339 : H12AffineEnvironment.transform 17 10281 env52338 = env52339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52338 == env52339) = true)

theorem identity52339 : scanCanonicalize (H12AffineFastState.compose env52339 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52339 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env52340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,5392,10281,1024,32769,4160,33,16,41310,8193,64,34816,46157,4096,43049,41993,32,256,41340,5457,513]

theorem envBound52340 : H12AffineFastState.Bounded env52340 := by
  intro p hp
  have h : env52340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52339_52340 : H12AffineEnvironment.transform 13 5377 env52339 = env52340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52339 == env52340) = true)

theorem identity52340 : scanCanonicalize (H12AffineFastState.compose env52340 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52340 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5392,10281,1024,8540,4160,33,16,3,8193,64,10589,5392,4096,2420,1364,32,256,33,5457,513]

theorem envBound52341 : H12AffineFastState.Bounded env52341 := by
  intro p hp
  have h : env52341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52340_52341 : H12AffineEnvironment.transform 14 8541 env52340 = env52341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52340 == env52341) = true)

theorem identity52341 : scanCanonicalize (H12AffineFastState.compose env52341 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52341 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52342 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,5392,10281,1024,8460,4112,33,16,3,8193,16,10509,5392,4096,2340,1284,32,256,33,5377,513]

theorem envBound52342 : H12AffineFastState.Bounded env52342 := by
  intro p hp
  have h : env52342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52341_52342 : H12AffineEnvironment.transform 5 16 env52341 = env52342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52341 == env52342) = true)

theorem identity52342 : scanCanonicalize (H12AffineFastState.compose env52342 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52343 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8232,8202,5173,10281,1024,8233,4112,33,16,3,8193,16,10280,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound52343 : H12AffineFastState.Bounded env52343 := by
  intro p hp
  have h : env52343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52342_52343 : H12AffineEnvironment.transform 7 37 env52342 = env52343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52342 == env52343) = true)

def env52344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,4194304,8388608,95497,8328,64,13022473,79131,8491470,8830977,8450329,4314198,256,8484155,8492190,8509135]

theorem envBound52344 : H12AffineFastState.Bounded env52344 := by
  intro p hp
  have h : env52344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52232_52344 : H12AffineEnvironment.transform 23 95497 env52232 = env52344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env52232 == env52344) = true)

def env52345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272512,8388608,95497,8328,64,8560009,79131,8491470,8830977,8450329,392406,256,8484155,8492190,8509135]

theorem envBound52345 : H12AffineFastState.Bounded env52345 := by
  intro p hp
  have h : env52345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52344_52345 : H12AffineEnvironment.transform 21 272512 env52344 = env52345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env52344 == env52345) = true)

theorem identity52345 : scanCanonicalize (H12AffineFastState.compose env52345 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound52345 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272512,120014,95497,8328,64,215367,79131,17664,464079,75223,392406,256,41461,16464,513]

theorem envBound52346 : H12AffineFastState.Bounded env52346 := by
  intro p hp
  have h : env52346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52345_52346 : H12AffineEnvironment.transform 22 120014 env52345 = env52346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env52345 == env52346) = true)

def env52347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,119878,95497,8192,64,215367,79131,17664,463943,75103,392286,256,41341,16464,513]

theorem envBound52347 : H12AffineFastState.Bounded env52347 := by
  intro p hp
  have h : env52347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52346_52347 : H12AffineEnvironment.transform 6 8 env52346 = env52347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52346 == env52347) = true)

theorem identity52347 : scanCanonicalize (H12AffineFastState.compose env52347 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52347 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,115735,272392,119878,95497,8192,64,10588,79131,17664,291932,75103,392286,256,41341,16464,513]

theorem envBound52348 : H12AffineFastState.Bounded env52348 := by
  intro p hp
  have h : env52348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52347_52348 : H12AffineEnvironment.transform 16 90139 env52347 = env52348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52347 == env52348) = true)

def env52349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,115735,32,119878,95497,8192,64,10588,79131,17664,23668,75103,119926,256,41341,16464,513]

theorem envBound52349 : H12AffineFastState.Bounded env52349 := by
  intro p hp
  have h : env52349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52348_52349 : H12AffineEnvironment.transform 17 10280 env52348 = env52349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52348 == env52349) = true)

theorem identity52349 : scanCanonicalize (H12AffineFastState.compose env52349 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52349 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1024,8540,91466,32,95515,95497,8192,64,10588,79131,17664,23668,75103,95531,256,32,16464,513]

theorem envBound52350 : H12AffineFastState.Bounded env52350 := by
  intro p hp
  have h : env52350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52349_52350 : H12AffineEnvironment.transform 14 8541 env52349 = env52350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52349 == env52350) = true)

theorem identity52350 : scanCanonicalize (H12AffineFastState.compose env52350 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1379) := by decide +kernel

theorem selectedBound52350 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env52351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,1379,25976,10280,1024,8540,24617,32,28792,28778,8192,64,10588,12408,17664,23668,8252,28744,256,32,16464,513]

theorem envBound52351 : H12AffineFastState.Bounded env52351 := by
  intro p hp
  have h : env52351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52350_52351 : H12AffineEnvironment.transform 15 1379 env52350 = env52351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1379 env52350 == env52351) = true)

theorem identity52351 : scanCanonicalize (H12AffineFastState.compose env52351 (packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound52351 : packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env52352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,16384,7505,1379,22900,5156,1024,7504,23589,32,19572,19558,7180,64,5456,3188,17664,23668,7216,19524,256,32,16464,513]

theorem envBound52352 : H12AffineFastState.Bounded env52352 := by
  intro p hp
  have h : env52352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52351_52352 : H12AffineEnvironment.transform 12 7180 env52351 = env52352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env52351 == env52352) = true)

theorem identity52352 : scanCanonicalize (H12AffineFastState.compose env52352 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound52352 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env52353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,2129,7505,1379,4389,5156,1024,7504,5236,32,1061,1079,7180,64,5456,3188,3409,5157,7216,1045,256,32,2049,513]

theorem envBound52353 : H12AffineFastState.Bounded env52353 := by
  intro p hp
  have h : env52353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52352_52353 : H12AffineEnvironment.transform 13 2129 env52352 = env52353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env52352 == env52353) = true)

theorem identity52353 : scanCanonicalize (H12AffineFastState.compose env52353 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52353 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52354 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,6428,2129,6209,115,4389,4404,272,6208,4452,32,309,295,6428,64,4160,2404,2113,4405,6432,261,256,32,2049,513]

theorem envBound52354 : H12AffineFastState.Bounded env52354 := by
  intro p hp
  have h : env52354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52353_52354 : H12AffineEnvironment.transform 9 272 env52353 = env52354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52353 == env52354) = true)

theorem identity52354 : scanCanonicalize (H12AffineFastState.compose env52354 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound52354 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env52355 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,120,2129,293,115,2113,2128,272,292,2048,32,309,295,120,64,2340,2404,2113,2129,68,261,256,32,2049,513]

theorem envBound52355 : H12AffineFastState.Bounded env52355 := by
  intro p hp
  have h : env52355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52354_52355 : H12AffineEnvironment.transform 11 2404 env52354 = env52355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env52354 == env52355) = true)

def env52356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,115735,33,119878,95497,8192,64,10588,79131,17664,23669,75103,119927,256,41341,16464,513]

theorem envBound52356 : H12AffineFastState.Bounded env52356 := by
  intro p hp
  have h : env52356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52348_52356 : H12AffineEnvironment.transform 17 10281 env52348 = env52356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52348 == env52356) = true)

theorem identity52356 : scanCanonicalize (H12AffineFastState.compose env52356 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound52356 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52357 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,5392,10281,1024,32769,45340,33,41293,2,8192,64,10588,16400,17664,23669,20564,41340,256,41341,16464,513]

theorem envBound52357 : H12AffineFastState.Bounded env52357 := by
  intro p hp
  have h : env52357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52356_52357 : H12AffineEnvironment.transform 15 29963 env52356 = env52357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env52356 == env52357) = true)

theorem identity52357 : scanCanonicalize (H12AffineFastState.compose env52357 (packedSelected [0,2,3,5,6,7,10,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound52357 : packedSelected [0,2,3,5,6,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env52358 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,4113,29963,5392,10281,1024,4112,8461,33,12636,2,8192,64,10588,16400,17664,23669,20564,12653,256,12652,16464,513]

theorem envBound52358 : H12AffineFastState.Bounded env52358 := by
  intro p hp
  have h : env52358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52357_52358 : H12AffineEnvironment.transform 14 4113 env52357 = env52358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env52357 == env52358) = true)

theorem identity52358 : scanCanonicalize (H12AffineFastState.compose env52358 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound52358 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env52359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,16384,2049,27931,3328,10281,1024,2048,8461,33,10572,2,8192,64,10588,16400,17664,17509,18500,10621,256,10620,16464,513]

theorem envBound52359 : H12AffineFastState.Bounded env52359 := by
  intro p hp
  have h : env52359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52358_52359 : H12AffineEnvironment.transform 11 2064 env52358 = env52359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env52358 == env52359) = true)

theorem identity52359 : scanCanonicalize (H12AffineFastState.compose env52359 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound52359 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,3148,16384,2049,16727,3328,1125,1024,2048,3393,33,1280,2,3148,64,1296,16400,17664,17509,18500,1329,256,1328,16464,513]

theorem envBound52360 : H12AffineFastState.Bounded env52360 := by
  intro p hp
  have h : env52360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52359_52360 : H12AffineEnvironment.transform 12 3148 env52359 = env52360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env52359 == env52360) = true)

theorem identity52360 : scanCanonicalize (H12AffineFastState.compose env52360 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound52360 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env52361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,64,1052,16384,81,16727,1360,1125,1024,80,1297,33,1280,2,1052,64,1296,16400,17664,17509,16404,1329,256,1328,16464,513]

theorem envBound52361 : H12AffineFastState.Bounded env52361 := by
  intro p hp
  have h : env52361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52360_52361 : H12AffineEnvironment.transform 10 80 env52360 = env52361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env52360 == env52361) = true)

theorem identity52361 : scanCanonicalize (H12AffineFastState.compose env52361 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52361 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52362 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,64,1052,16384,81,16498,1141,1125,1024,80,1076,33,1061,2,1052,64,1077,16400,17445,17509,16404,1044,37,1045,16464,513]

theorem envBound52362 : H12AffineFastState.Bounded env52362 := by
  intro p hp
  have h : env52362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52361_52362 : H12AffineEnvironment.transform 7 37 env52361 = env52362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52361 == env52362) = true)

theorem identity52362 : scanCanonicalize (H12AffineFastState.compose env52362 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound52362 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env52363 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,64,1052,80,81,34,1141,1125,1024,80,1076,33,1061,2,1052,64,1077,64,1141,1077,68,1044,37,1045,0,513]

theorem envBound52363 : H12AffineFastState.Bounded env52363 := by
  intro p hp
  have h : env52363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52362_52363 : H12AffineEnvironment.transform 13 80 env52362 = env52363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env52362 == env52363) = true)

theorem identity52363 : scanCanonicalize (H12AffineFastState.compose env52363 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound52363 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52364 : List Nat := [2,4,8,16,32,64,8,37,80,1024,80,64,1052,80,81,34,1141,1125,1024,80,1076,33,1061,2,1052,64,1077,64,1141,1077,68,1044,37,1045,0,81]

theorem envBound52364 : H12AffineFastState.Bounded env52364 := by
  intro p hp
  have h : env52364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52363_52364 : H12AffineEnvironment.transform 8 80 env52363 = env52364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env52363 == env52364) = true)

theorem identity52364 : scanCanonicalize (H12AffineFastState.compose env52364 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound52364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52365 : List Nat := [2,4,8,16,32,33,8,37,49,1024,49,33,1052,49,48,34,1044,1028,1024,49,1076,33,1061,2,1052,33,1077,33,1044,1077,37,1044,37,1045,0,48]

theorem envBound52365 : H12AffineFastState.Bounded env52365 := by
  intro p hp
  have h : env52365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52364_52365 : H12AffineEnvironment.transform 5 33 env52364 = env52365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env52364 == env52365) = true)

theorem identity52365 : scanCanonicalize (H12AffineFastState.compose env52365 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound52365 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52366 : List Nat := [2,4,8,16,32,33,8,37,49,21,49,33,9,49,48,34,1,17,21,49,33,33,48,2,9,33,32,33,1,32,37,1,37,0,0,48]

theorem envBound52366 : H12AffineFastState.Bounded env52366 := by
  intro p hp
  have h : env52366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52365_52366 : H12AffineEnvironment.transform 9 21 env52365 = env52366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52365 == env52366) = true)

theorem identity52366 : scanCanonicalize (H12AffineFastState.compose env52366 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52366 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52367 : List Nat := [2,4,8,16,16,17,8,21,1,21,1,17,9,1,0,18,1,17,21,1,17,17,0,2,9,17,16,17,1,16,21,1,21,0,0,0]

theorem envBound52367 : H12AffineFastState.Bounded env52367 := by
  intro p hp
  have h : env52367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52366_52367 : H12AffineEnvironment.transform 4 16 env52366 = env52367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52366 == env52367) = true)

theorem identity52367 : scanCanonicalize (H12AffineFastState.compose env52367 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52368 : List Nat := [2,4,8,1,1,0,8,4,1,4,1,0,9,1,0,3,1,0,4,1,0,0,0,2,9,0,1,0,1,1,4,1,4,0,0,0]

theorem envBound52368 : H12AffineFastState.Bounded env52368 := by
  intro p hp
  have h : env52368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52367_52368 : H12AffineEnvironment.transform 3 1 env52367 = env52368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52367 == env52368) = true)

def env52369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,119879,95497,8193,64,215367,79131,17664,463942,75102,392287,256,41340,16464,513]

theorem envBound52369 : H12AffineFastState.Bounded env52369 := by
  intro p hp
  have h : env52369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52346_52369 : H12AffineEnvironment.transform 6 9 env52346 = env52369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52346 == env52369) = true)

def env52370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115734,33,119879,95497,8193,64,215367,79131,17664,212078,75102,119927,256,41340,16464,513]

theorem envBound52370 : H12AffineFastState.Bounded env52370 := by
  intro p hp
  have h : env52370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52369_52370 : H12AffineEnvironment.transform 17 10280 env52369 = env52370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52369 == env52370) = true)

theorem identity52370 : scanCanonicalize (H12AffineFastState.compose env52370 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound52370 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,4161,33,16,41310,8193,64,171280,57676,17664,190521,61705,32,256,41340,16464,513]

theorem envBound52371 : H12AffineFastState.Bounded env52371 := by
  intro p hp
  have h : env52371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52370_52371 : H12AffineEnvironment.transform 15 54359 env52370 = env52371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env52370 == env52371) = true)

theorem identity52371 : scanCanonicalize (H12AffineFastState.compose env52371 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound52371 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10280,1024,32769,4161,33,16,41310,8193,64,10588,57676,17664,23669,61705,32,256,41340,16464,513]

theorem envBound52372 : H12AffineFastState.Bounded env52372 := by
  intro p hp
  have h : env52372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52371_52372 : H12AffineEnvironment.transform 16 46156 env52371 = env52372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env52371 == env52372) = true)

theorem identity52372 : scanCanonicalize (H12AffineFastState.compose env52372 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound52372 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28699,4096,10280,1024,9293,4161,33,16,1298,8193,64,10588,17664,17664,23669,21829,32,256,1328,16464,513]

theorem envBound52373 : H12AffineFastState.Bounded env52373 := by
  intro p hp
  have h : env52373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52372_52373 : H12AffineEnvironment.transform 14 9292 env52372 = env52373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env52372 == env52373) = true)

theorem identity52373 : scanCanonicalize (H12AffineFastState.compose env52373 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52373 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,8192,16384,9292,28699,4096,9529,1024,9293,4161,33,16,1298,8193,64,9293,17664,17664,20836,21829,32,256,1328,16464,513]

theorem envBound52374 : H12AffineFastState.Bounded env52374 := by
  intro p hp
  have h : env52374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52373_52374 : H12AffineEnvironment.transform 10 1297 env52373 = env52374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env52373 == env52374) = true)

theorem identity52374 : scanCanonicalize (H12AffineFastState.compose env52374 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound52374 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env52375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,1336,16384,372,21795,4096,1,1024,373,4161,33,16,1298,1337,64,373,17664,17664,20836,21829,32,256,1328,16464,513]

theorem envBound52375 : H12AffineFastState.Bounded env52375 := by
  intro p hp
  have h : env52375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52374_52375 : H12AffineEnvironment.transform 12 1336 env52374 = env52375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env52374 == env52375) = true)

theorem identity52375 : scanCanonicalize (H12AffineFastState.compose env52375 (packedSelected [0,11,14,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound52375 : packedSelected [0,11,14,23,27] rootPS < 2^1333 := by decide +kernel

def env52376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,1336,4452,372,1095,4096,1,1024,373,4161,33,16,1298,1337,64,373,5220,5220,0,1057,32,256,1328,4404,513]

theorem envBound52376 : H12AffineFastState.Bounded env52376 := by
  intro p hp
  have h : env52376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52375_52376 : H12AffineEnvironment.transform 13 4452 env52375 = env52376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env52375 == env52376) = true)

theorem identity52376 : scanCanonicalize (H12AffineFastState.compose env52376 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound52376 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,357,1336,1,372,1095,357,1,1024,373,292,33,16,1298,1337,64,373,1281,1281,0,1057,32,256,1328,81,513]

theorem envBound52377 : H12AffineFastState.Bounded env52377 := by
  intro p hp
  have h : env52377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52376_52377 : H12AffineEnvironment.transform 11 357 env52376 = env52377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env52376 == env52377) = true)

theorem identity52377 : scanCanonicalize (H12AffineFastState.compose env52377 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound52377 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env52378 : List Nat := [2,4,8,16,32,64,9,256,512,320,81,357,120,1,372,263,357,1,320,373,292,33,16,82,121,64,373,65,65,0,353,32,256,112,81,513]

theorem envBound52378 : H12AffineFastState.Bounded env52378 := by
  intro p hp
  have h : env52378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52377_52378 : H12AffineEnvironment.transform 9 320 env52377 = env52378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52377 == env52378) = true)

theorem identity52378 : scanCanonicalize (H12AffineFastState.compose env52378 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound52378 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env52379 : List Nat := [2,4,8,16,32,64,9,256,372,320,81,357,120,1,372,263,357,1,320,373,292,33,16,82,121,64,373,65,65,0,353,32,256,112,81,373]

theorem envBound52379 : H12AffineFastState.Bounded env52379 := by
  intro p hp
  have h : env52379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52378_52379 : H12AffineEnvironment.transform 8 372 env52378 = env52379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env52378 == env52379) = true)

def env52380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115734,32,119879,95497,8193,64,215367,79131,17664,212079,75102,119926,256,41340,16464,513]

theorem envBound52380 : H12AffineFastState.Bounded env52380 := by
  intro p hp
  have h : env52380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52369_52380 : H12AffineEnvironment.transform 17 10281 env52369 = env52380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52369 == env52380) = true)

theorem identity52380 : scanCanonicalize (H12AffineFastState.compose env52380 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound52380 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env52381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,91419,32,95562,95497,8193,64,215367,79131,17664,212079,75102,95611,256,113,16464,513]

theorem envBound52381 : H12AffineFastState.Bounded env52381 := by
  intro p hp
  have h : env52381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52380_52381 : H12AffineEnvironment.transform 14 8461 env52380 = env52381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env52380 == env52381) = true)

theorem identity52381 : scanCanonicalize (H12AffineFastState.compose env52381 (packedSelected [0,3,7,12,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound52381 : packedSelected [0,3,7,12,20,24] rootPS < 2^1333 := by decide +kernel

def env52382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,21511,131072,10281,1024,8460,12572,32,8525,8462,8193,64,138560,24860,17664,157800,29017,8572,256,113,16464,513]

theorem envBound52382 : H12AffineFastState.Bounded env52382 := by
  intro p hp
  have h : env52382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52381_52382 : H12AffineEnvironment.transform 15 21511 env52381 = env52382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env52381 == env52382) = true)

theorem identity52382 : scanCanonicalize (H12AffineFastState.compose env52382 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound52382 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env52383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,21511,13340,10281,1024,8460,12572,32,8525,8462,8193,64,10588,24860,17664,23668,29017,8572,256,113,16464,513]

theorem envBound52383 : H12AffineFastState.Bounded env52383 := by
  intro p hp
  have h : env52383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52382_52383 : H12AffineEnvironment.transform 16 13340 env52382 = env52383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env52382 == env52383) = true)

theorem identity52383 : scanCanonicalize (H12AffineFastState.compose env52383 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52383 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,1,21511,5392,2341,1024,0,4112,32,65,2,269,64,2128,16400,17664,23668,20565,112,256,113,16464,513]

theorem envBound52384 : H12AffineFastState.Bounded env52384 := by
  intro p hp
  have h : env52384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52383_52384 : H12AffineEnvironment.transform 12 268 env52383 = env52384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52383 == env52384) = true)

theorem identity52384 : scanCanonicalize (H12AffineFastState.compose env52384 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound52384 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env52385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,1,343,5392,2341,1024,0,4112,32,65,2,269,64,2128,5440,4176,2340,1285,112,256,113,5376,513]

theorem envBound52385 : H12AffineFastState.Bounded env52385 := by
  intro p hp
  have h : env52385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52384_52385 : H12AffineEnvironment.transform 13 5456 env52384 = env52385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env52384 == env52385) = true)

theorem identity52385 : scanCanonicalize (H12AffineFastState.compose env52385 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52385 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52386 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4160,1,343,4096,2341,272,0,4112,32,65,2,269,64,2128,4176,4176,2340,21,112,256,113,4112,513]

theorem envBound52386 : H12AffineFastState.Bounded env52386 := by
  intro p hp
  have h : env52386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52385_52386 : H12AffineEnvironment.transform 9 272 env52385 = env52386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52385 == env52386) = true)

theorem identity52386 : scanCanonicalize (H12AffineFastState.compose env52386 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52386 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52387 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4112,1,263,4096,2341,272,0,4112,32,17,2,269,16,2048,4096,4096,2340,21,32,256,33,4112,513]

theorem envBound52387 : H12AffineFastState.Bounded env52387 := by
  intro p hp
  have h : env52387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52386_52387 : H12AffineEnvironment.transform 5 16 env52386 = env52387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52386 == env52387) = true)

theorem identity52387 : scanCanonicalize (H12AffineFastState.compose env52387 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound52387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52388 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,308,268,292,1,263,308,2341,272,0,292,32,17,2,269,16,2048,308,308,2340,21,32,256,33,292,513]

theorem envBound52388 : H12AffineFastState.Bounded env52388 := by
  intro p hp
  have h : env52388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52387_52388 : H12AffineEnvironment.transform 11 308 env52387 = env52388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env52387 == env52388) = true)

def env52389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272513,8388608,95497,8328,64,8560008,79131,8491470,8830977,8450329,392407,256,8484155,8492190,8509135]

theorem envBound52389 : H12AffineFastState.Bounded env52389 := by
  intro p hp
  have h : env52389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52344_52389 : H12AffineEnvironment.transform 21 272513 env52344 = env52389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env52344 == env52389) = true)

theorem identity52389 : scanCanonicalize (H12AffineFastState.compose env52389 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound52389 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,272513,8388608,41431,8328,64,8560008,57797,8406288,8830977,8450329,272393,256,8430053,8405056,8389137]

theorem envBound52390 : H12AffineFastState.Bounded env52390 := by
  intro p hp
  have h : env52390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52389_52390 : H12AffineEnvironment.transform 15 54494 env52389 = env52390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env52389 == env52390) = true)

def env52391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272393,8388608,41311,8192,64,8559872,57677,8406288,8830977,8450329,272393,256,8429933,8405056,8389137]

theorem envBound52391 : H12AffineFastState.Bounded env52391 := by
  intro p hp
  have h : env52391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52390_52391 : H12AffineEnvironment.transform 6 8 env52390 = env52391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52390 == env52391) = true)

def env52392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272393,16,41311,8192,64,171280,57677,17664,442385,61705,272393,256,41341,16464,513]

theorem envBound52392 : H12AffineFastState.Bounded env52392 := by
  intro p hp
  have h : env52392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52391_52392 : H12AffineEnvironment.transform 22 16 env52391 = env52392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52391 == env52392) = true)

theorem identity52392 : scanCanonicalize (H12AffineFastState.compose env52392 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,131072,262144,1024,8540,4161,272393,16,2,8192,64,146509,16400,17664,418124,20564,272393,256,32,16464,513]

theorem envBound52393 : H12AffineFastState.Bounded env52393 := by
  intro p hp
  have h : env52393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52392_52393 : H12AffineEnvironment.transform 14 8541 env52392 = env52393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52392 == env52393) = true)

theorem identity52393 : scanCanonicalize (H12AffineFastState.compose env52393 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52393 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52394 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,131072,262144,272,8540,4161,272393,16,2,8192,64,145757,16400,16400,418124,20564,272393,256,32,16464,513]

theorem envBound52394 : H12AffineFastState.Bounded env52394 := by
  intro p hp
  have h : env52394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52393_52394 : H12AffineEnvironment.transform 9 272 env52393 = env52394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52393 == env52394) = true)

theorem identity52394 : scanCanonicalize (H12AffineFastState.compose env52394 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound52394 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env52395 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,4096,262144,272,8540,4161,272393,16,2,8192,64,10589,16400,16400,291148,20564,272393,256,32,16464,513]

theorem envBound52395 : H12AffineFastState.Bounded env52395 := by
  intro p hp
  have h : env52395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52394_52395 : H12AffineEnvironment.transform 16 4096 env52394 = env52395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env52394 == env52395) = true)

theorem identity52395 : scanCanonicalize (H12AffineFastState.compose env52395 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52395 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env52396 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,4096,10280,272,8540,4161,33,16,2,8192,64,10589,16400,16400,22884,20564,33,256,32,16464,513]

theorem envBound52396 : H12AffineFastState.Bounded env52396 := by
  intro p hp
  have h : env52396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52395_52396 : H12AffineEnvironment.transform 17 10280 env52395 = env52396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52395 == env52396) = true)

theorem identity52396 : scanCanonicalize (H12AffineFastState.compose env52396 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound52396 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52397 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,8192,16384,8541,27007,2404,10280,272,8540,2341,33,16,2,8192,64,10589,16400,16400,16384,18736,33,256,32,16464,513]

theorem envBound52397 : H12AffineFastState.Bounded env52397 := by
  intro p hp
  have h : env52397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52396_52397 : H12AffineEnvironment.transform 11 2404 env52396 = env52397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env52396 == env52397) = true)

theorem identity52397 : scanCanonicalize (H12AffineFastState.compose env52397 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound52397 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env52398 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,8192,2048,8541,8575,2404,10280,272,8540,2341,33,16,2,8192,64,10589,2064,2064,2048,304,33,256,32,2128,513]

theorem envBound52398 : H12AffineFastState.Bounded env52398 := by
  intro p hp
  have h : env52398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52397_52398 : H12AffineEnvironment.transform 13 2048 env52397 = env52398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env52397 == env52398) = true)

theorem identity52398 : scanCanonicalize (H12AffineFastState.compose env52398 (packedSelected [1,4,5,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound52398 : packedSelected [1,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env52399 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2404,41,2048,372,342,2404,2049,272,373,2341,33,16,2,41,64,2420,2064,2064,2048,304,33,256,32,2128,513]

theorem envBound52399 : H12AffineFastState.Bounded env52399 := by
  intro p hp
  have h : env52399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52398_52399 : H12AffineEnvironment.transform 12 41 env52398 = env52399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env52398 == env52399) = true)

theorem identity52399 : scanCanonicalize (H12AffineFastState.compose env52399 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound52399 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52400 : List Nat := [2,4,8,16,32,64,8,256,512,272,276,112,41,276,372,342,112,277,272,373,49,33,16,2,41,64,96,260,260,276,304,33,256,32,324,513]

theorem envBound52400 : H12AffineFastState.Bounded env52400 := by
  intro p hp
  have h : env52400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52399_52400 : H12AffineEnvironment.transform 10 276 env52399 = env52400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env52399 == env52400) = true)

theorem identity52400 : scanCanonicalize (H12AffineFastState.compose env52400 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound52400 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env52401 : List Nat := [2,4,8,16,32,64,8,85,512,69,65,112,41,65,33,3,112,64,69,32,49,33,16,2,41,64,96,81,81,65,101,33,85,32,17,513]

theorem envBound52401 : H12AffineFastState.Bounded env52401 := by
  intro p hp
  have h : env52401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52400_52401 : H12AffineEnvironment.transform 7 85 env52400 = env52401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env52400 == env52401) = true)

theorem identity52401 : scanCanonicalize (H12AffineFastState.compose env52401 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52401 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52402 : List Nat := [2,4,8,16,0,64,8,85,512,69,65,80,9,65,1,3,80,64,69,0,17,1,16,2,9,64,64,81,81,65,69,1,85,0,17,513]

theorem envBound52402 : H12AffineFastState.Bounded env52402 := by
  intro p hp
  have h : env52402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52401_52402 : H12AffineEnvironment.transform 4 0 env52401 = env52402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52401 == env52402) = true)

theorem identity52402 : scanCanonicalize (H12AffineFastState.compose env52402 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52402 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52403 : List Nat := [2,4,8,16,0,16,8,5,512,21,17,0,9,17,1,3,0,16,21,0,17,1,16,2,9,16,16,1,1,17,21,1,5,0,17,513]

theorem envBound52403 : H12AffineFastState.Bounded env52403 := by
  intro p hp
  have h : env52403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52402_52403 : H12AffineEnvironment.transform 5 16 env52402 = env52403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52402 == env52403) = true)

theorem identity52403 : scanCanonicalize (H12AffineFastState.compose env52403 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52404 : List Nat := [2,4,8,1,0,1,8,5,512,4,0,0,9,0,1,3,0,1,4,0,0,1,1,2,9,1,1,1,1,0,4,1,5,0,0,513]

theorem envBound52404 : H12AffineFastState.Bounded env52404 := by
  intro p hp
  have h : env52404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52403_52404 : H12AffineEnvironment.transform 3 1 env52403 = env52404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52403 == env52404) = true)

def env52405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,272393,17,41311,8192,64,171281,57677,17665,442384,61704,272393,256,41340,16465,512]

theorem envBound52405 : H12AffineFastState.Bounded env52405 := by
  intro p hp
  have h : env52405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52391_52405 : H12AffineEnvironment.transform 22 17 env52391 = env52405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52391 == env52405) = true)

theorem identity52405 : scanCanonicalize (H12AffineFastState.compose env52405 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound52405 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56576,1024,32769,4161,62729,17,41311,8192,64,171281,57677,17665,138512,61704,62729,256,41340,16465,512]

theorem envBound52406 : H12AffineFastState.Bounded env52406 := by
  intro p hp
  have h : env52406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52405_52406 : H12AffineEnvironment.transform 17 56576 env52405 = env52406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env52405 == env52406) = true)

theorem identity52406 : scanCanonicalize (H12AffineFastState.compose env52406 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound52406 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32803,131072,35189,1024,32769,4161,41340,17,41311,8192,64,171281,46392,4468,138512,42365,41340,256,41340,5156,512]

theorem envBound52407 : H12AffineFastState.Bounded env52407 := by
  intro p hp
  have h : env52407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52406_52407 : H12AffineEnvironment.transform 13 5237 env52406 = env52407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env52406 == env52407) = true)

theorem identity52407 : scanCanonicalize (H12AffineFastState.compose env52407 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound52407 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env52408 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,5237,32768,32803,131072,34848,1024,32769,4161,41001,17,40970,8192,64,171076,46189,4129,138309,42024,41001,85,41001,5156,512]

theorem envBound52408 : H12AffineFastState.Bounded env52408 := by
  intro p hp
  have h : env52408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52407_52408 : H12AffineEnvironment.transform 7 85 env52407 = env52408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env52407 == env52408) = true)

def env52409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272392,8388608,41310,8193,64,8559873,57676,8406288,8830977,8450329,272393,256,8429932,8405056,8389137]

theorem envBound52409 : H12AffineFastState.Bounded env52409 := by
  intro p hp
  have h : env52409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52390_52409 : H12AffineEnvironment.transform 6 9 env52390 = env52409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52390 == env52409) = true)

def env52410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272392,16,41310,8193,64,171281,57676,17664,442385,61705,272393,256,41340,16464,513]

theorem envBound52410 : H12AffineFastState.Bounded env52410 := by
  intro p hp
  have h : env52410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52409_52410 : H12AffineEnvironment.transform 22 16 env52409 = env52410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env52409 == env52410) = true)

def env52411 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,272392,16,41230,8193,16,171281,57628,17664,442385,61705,272393,256,41260,16384,513]

theorem envBound52411 : H12AffineFastState.Bounded env52411 := by
  intro p hp
  have h : env52411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52410_52411 : H12AffineEnvironment.transform 5 16 env52410 = env52411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52410 == env52411) = true)

theorem identity52411 : scanCanonicalize (H12AffineFastState.compose env52411 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound52411 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env52412 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,262144,1024,29708,4113,272392,16,21763,8193,16,157980,5393,17664,406556,1284,272393,256,21793,16384,513]

theorem envBound52412 : H12AffineFastState.Bounded env52412 := by
  intro p hp
  have h : env52412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52411_52412 : H12AffineEnvironment.transform 14 29709 env52411 = env52412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env52411 == env52412) = true)

theorem identity52412 : scanCanonicalize (H12AffineFastState.compose env52412 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound52412 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52413 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,23588,1024,29708,4113,29740,16,21763,8193,16,157980,5393,17664,157752,1284,29741,256,21793,16384,513]

theorem envBound52413 : H12AffineFastState.Bounded env52413 := by
  intro p hp
  have h : env52413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52412_52413 : H12AffineEnvironment.transform 17 23588 env52412 = env52413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env52412 == env52413) = true)

theorem identity52413 : scanCanonicalize (H12AffineFastState.compose env52413 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound52413 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env52414 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,16401,23588,1024,29708,4113,29740,16,21763,8193,16,10509,5393,17664,10281,1284,29741,256,21793,16384,513]

theorem envBound52414 : H12AffineFastState.Bounded env52414 := by
  intro p hp
  have h : env52414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52413_52414 : H12AffineEnvironment.transform 16 16401 env52413 = env52414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env52413 == env52414) = true)

theorem identity52414 : scanCanonicalize (H12AffineFastState.compose env52414 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound52414 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env52415 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5157,8232,8202,5172,2049,1024,8233,4113,8201,16,294,8193,16,10509,5393,4389,10281,1284,8200,256,260,5157,513]

theorem envBound52415 : H12AffineFastState.Bounded env52415 := by
  intro p hp
  have h : env52415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52414_52415 : H12AffineEnvironment.transform 13 5157 env52414 = env52415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env52414 == env52415) = true)

theorem identity52415 : scanCanonicalize (H12AffineFastState.compose env52415 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52415 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52416 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5157,293,263,5172,2049,1024,292,4113,260,16,294,268,16,2048,5393,4389,2340,1284,261,256,260,5157,513]

theorem envBound52416 : H12AffineFastState.Bounded env52416 := by
  intro p hp
  have h : env52416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52415_52416 : H12AffineEnvironment.transform 12 269 env52415 = env52416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52415 == env52416) = true)

theorem identity52416 : scanCanonicalize (H12AffineFastState.compose env52416 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52416 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env52417 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,34,5172,2049,1024,1,4113,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound52417 : H12AffineFastState.Bounded env52417 := by
  intro p hp
  have h : env52417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52416_52417 : H12AffineEnvironment.transform 7 37 env52416 = env52417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52416 == env52417) = true)

def env52418 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,0,34,1028,2049,1024,1,33,33,16,3,41,16,2048,1028,48,2049,1057,32,37,33,1045,513]

theorem envBound52418 : H12AffineFastState.Bounded env52418 := by
  intro p hp
  have h : env52418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52417_52418 : H12AffineEnvironment.transform 11 48 env52417 = env52418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52417 == env52418) = true)

theorem identity52418 : scanCanonicalize (H12AffineFastState.compose env52418 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52418 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52419 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,40,33,0,34,48,2049,52,1,33,33,16,3,41,16,2048,48,48,2049,21,32,37,33,33,513]

theorem envBound52419 : H12AffineFastState.Bounded env52419 := by
  intro p hp
  have h : env52419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52418_52419 : H12AffineEnvironment.transform 9 52 env52418 = env52419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52418 == env52419) = true)

theorem identity52419 : scanCanonicalize (H12AffineFastState.compose env52419 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52419 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52420 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,0,0,3,17,2049,21,1,0,0,16,3,8,16,2048,17,17,2049,21,1,4,0,0,513]

theorem envBound52420 : H12AffineFastState.Bounded env52420 := by
  intro p hp
  have h : env52420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52419_52420 : H12AffineEnvironment.transform 4 1 env52419 = env52420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52419 == env52420) = true)

def leafEnv52420 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,0,0,3,17,2049,21,1,0,0,16,3,21,8,1,16,2048,17,17,2049,21,1,4,0,4,2,0,513,1,0,0]

def active52420 : List Nat := [0,1,2,3,8,10]

def tree52420 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52420 : H12WitnessSearch.Good tree52420 := H12GlobalWitnessIndex.good

theorem leafIdentity52420 : H12AffineFastState.composeSystem env52420 rootObs = leafEnv52420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52420 rootObs == leafEnv52420) = true)

theorem terminalChecked52420 : H12PackedTerminal.terminalCheckFast leafEnv52420 active52420 tree52420 = true := by decide +kernel

def env52421 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,0,34,1029,2049,1024,1,32,33,16,3,41,16,2048,1029,49,2049,1057,32,37,33,1044,513]

theorem envBound52421 : H12AffineFastState.Bounded env52421 := by
  intro p hp
  have h : env52421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52417_52421 : H12AffineEnvironment.transform 11 49 env52417 = env52421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52417 == env52421) = true)

def env52422 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,272392,16,41231,8193,17,171281,57629,17664,442385,61705,272393,256,41261,16385,513]

theorem envBound52422 : H12AffineFastState.Bounded env52422 := by
  intro p hp
  have h : env52422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52410_52422 : H12AffineEnvironment.transform 5 17 env52410 = env52422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52410 == env52422) = true)

theorem identity52422 : scanCanonicalize (H12AffineFastState.compose env52422 (packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound52422 : packedSelected [0,1,3,8,10,12,14,15,24,27] rootPS < 2^1333 := by decide +kernel

def env52423 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,179513,1024,32769,4112,169265,16,41231,8193,17,171281,57629,17664,32040,61705,169264,256,41261,16385,513]

theorem envBound52423 : H12AffineFastState.Bounded env52423 := by
  intro p hp
  have h : env52423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52422_52423 : H12AffineEnvironment.transform 17 179513 env52422 = env52423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env52422 == env52423) = true)

theorem identity52423 : scanCanonicalize (H12AffineFastState.compose env52423 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound52423 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52424 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,38160,10281,1024,32769,4112,33,16,41231,8193,17,2049,57629,17664,32040,61705,32,256,41261,16385,513]

theorem envBound52424 : H12AffineFastState.Bounded env52424 := by
  intro p hp
  have h : env52424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52423_52424 : H12AffineEnvironment.transform 16 38160 env52423 = env52424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52423 == env52424) = true)

theorem identity52424 : scanCanonicalize (H12AffineFastState.compose env52424 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52424 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52425 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,54278,38160,2340,1024,32769,4112,33,16,32770,268,17,2049,49168,17664,23589,53252,32,256,32800,16385,513]

theorem envBound52425 : H12AffineFastState.Bounded env52425 := by
  intro p hp
  have h : env52425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52424_52425 : H12AffineEnvironment.transform 12 269 env52424 = env52425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52424 == env52425) = true)

end H12CloudChart1