import H12CloudChart1Data166

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound42351 : H12AffineFastState.Bounded env42351 := by
  intro p hp
  have h : env42351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42350_42351 : H12AffineEnvironment.transform 6 8 env42350 = env42351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42350 == env42351) = true)

theorem identity42351 : scanCanonicalize (H12AffineFastState.compose env42351 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound42351 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env42352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,171108,1024,32769,50497,177260,8525,21763,8192,65,179276,13388,45404,32041,53333,156013,256,21793,46093,55040]

theorem envBound42352 : H12AffineFastState.Bounded env42352 := by
  intro p hp
  have h : env42352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42351_42352 : H12AffineEnvironment.transform 17 171108 env42351 = env42352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env42351 == env42352) = true)

theorem identity42352 : scanCanonicalize (H12AffineFastState.compose env42352 (packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound42352 : packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS < 2^1333 := by decide +kernel

def env42353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5393,35189,1024,32769,50497,41341,8525,21763,8192,65,43357,13388,45404,32041,53333,29820,256,21793,46093,55040]

theorem envBound42353 : H12AffineFastState.Bounded env42353 := by
  intro p hp
  have h : env42353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42352_42353 : H12AffineEnvironment.transform 16 5393 env42352 = env42353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env42352 == env42353) = true)

theorem identity42353 : scanCanonicalize (H12AffineFastState.compose env42353 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound42353 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env42354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,5393,23668,1024,21760,4160,29820,8525,21763,8192,65,31836,13388,25693,32041,1364,29820,256,21793,24844,513]

theorem envBound42354 : H12AffineFastState.Bounded env42354 := by
  intro p hp
  have h : env42354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42353_42354 : H12AffineEnvironment.transform 14 21761 env42353 = env42354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42353 == env42354) = true)

theorem identity42354 : scanCanonicalize (H12AffineFastState.compose env42354 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42354 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42355 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8202,5393,10281,1024,8541,4160,33,8525,8542,8192,65,2049,13388,4096,2420,1364,33,256,8572,5457,513]

theorem envBound42355 : H12AffineFastState.Bounded env42355 := by
  intro p hp
  have h : env42355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42354_42355 : H12AffineEnvironment.transform 13 13405 env42354 = env42355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42354 == env42355) = true)

theorem identity42355 : scanCanonicalize (H12AffineFastState.compose env42355 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42355 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42356 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12620,8540,8202,4096,10281,273,8541,4160,33,8525,8542,8192,65,2049,12637,4096,2420,69,33,256,8572,4160,513]

theorem envBound42356 : H12AffineFastState.Bounded env42356 := by
  intro p hp
  have h : env42356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42355_42356 : H12AffineEnvironment.transform 9 273 env42355 = env42356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42355 == env42356) = true)

theorem identity42356 : scanCanonicalize (H12AffineFastState.compose env42356 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound42356 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42357 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,8192,8313,8540,8202,309,10281,273,8541,373,33,8525,8542,8192,65,2049,8296,309,2420,69,33,256,8572,373,513]

theorem envBound42357 : H12AffineFastState.Bounded env42357 := by
  intro p hp
  have h : env42357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42356_42357 : H12AffineEnvironment.transform 11 309 env42356 = env42357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env42356 == env42357) = true)

theorem identity42357 : scanCanonicalize (H12AffineFastState.compose env42357 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42357 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env42358 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,309,8192,8313,8540,8202,309,8233,273,8541,373,33,8525,8542,8192,65,1,8296,309,372,69,33,256,8572,373,513]

theorem envBound42358 : H12AffineFastState.Bounded env42358 := by
  intro p hp
  have h : env42358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42357_42358 : H12AffineEnvironment.transform 10 0 env42357 = env42358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42357 == env42358) = true)

def env42359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272393,441640,21763,8193,65,270376,436265,45405,32040,412720,156013,256,21793,46092,412516]

theorem envBound42359 : H12AffineFastState.Bounded env42359 := by
  intro p hp
  have h : env42359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42350_42359 : H12AffineEnvironment.transform 6 9 env42350 = env42359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42350 == env42359) = true)

theorem identity42359 : scanCanonicalize (H12AffineFastState.compose env42359 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound42359 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env42360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46392,262144,1024,32769,322589,272393,264208,21763,8193,65,270376,269585,45405,32040,325896,54357,256,21793,46092,327260]

theorem envBound42360 : H12AffineFastState.Bounded env42360 := by
  intro p hp
  have h : env42360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42359_42360 : H12AffineEnvironment.transform 16 46392 env42359 = env42360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env42359 == env42360) = true)

theorem identity42360 : scanCanonicalize (H12AffineFastState.compose env42360 (packedSelected [0,3,4,10,11,14,18,20,22,23,24,26,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 43356) := by decide +kernel

theorem selectedBound42360 : packedSelected [0,3,4,10,11,14,18,20,22,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env42361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46392,43356,1024,32769,17729,33109,41292,21763,8193,65,35188,46157,45405,32040,20564,54357,256,21793,46092,22272]

theorem envBound42361 : H12AffineFastState.Bounded env42361 := by
  intro p hp
  have h : env42361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42360_42361 : H12AffineEnvironment.transform 17 43356 env42360 = env42361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43356 env42360 == env42361) = true)

theorem identity42361 : scanCanonicalize (H12AffineFastState.compose env42361 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound42361 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env42362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16741,23809,1024,29788,17729,29960,21777,21763,8193,65,32041,16400,17664,32040,20564,8200,256,21793,16465,22272]

theorem envBound42362 : H12AffineFastState.Bounded env42362 := by
  intro p hp
  have h : env42362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42361_42362 : H12AffineEnvironment.transform 14 29789 env42361 = env42362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42361 == env42362) = true)

theorem identity42362 : scanCanonicalize (H12AffineFastState.compose env42362 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42362 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env42363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8202,13624,10588,1024,1,12572,341,8524,8542,8193,65,2420,13389,12637,2421,9225,8200,256,8572,13324,9053]

theorem envBound42363 : H12AffineFastState.Bounded env42363 := by
  intro p hp
  have h : env42363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42362_42363 : H12AffineEnvironment.transform 13 13405 env42362 = env42363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42362 == env42363) = true)

theorem identity42363 : scanCanonicalize (H12AffineFastState.compose env42363 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42363 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5220,2048,1024,1,4160,341,16,2,349,65,2420,5393,4097,2421,1365,340,256,32,5456,513]

theorem envBound42364 : H12AffineFastState.Bounded env42364 := by
  intro p hp
  have h : env42364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42363_42364 : H12AffineEnvironment.transform 12 348 env42363 = env42364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42363 == env42364) = true)

theorem identity42364 : scanCanonicalize (H12AffineFastState.compose env42364 (packedSelected [1,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound42364 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env42365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,348,3392,0,342,3109,2048,1024,1,2049,341,16,2,349,65,2420,3408,2112,2421,1365,340,256,32,3345,513]

theorem envBound42365 : H12AffineFastState.Bounded env42365 := by
  intro p hp
  have h : env42365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42364_42365 : H12AffineEnvironment.transform 11 2113 env42364 = env42365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env42364 == env42365) = true)

theorem identity42365 : scanCanonicalize (H12AffineFastState.compose env42365 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42365 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env42366 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2113,348,2421,0,342,2064,2048,53,1,2049,341,16,2,349,65,2420,2405,2112,2421,352,340,256,32,2340,513]

theorem envBound42366 : H12AffineFastState.Bounded env42366 := by
  intro p hp
  have h : env42366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42365_42366 : H12AffineEnvironment.transform 9 53 env42365 = env42366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42365 == env42366) = true)

theorem identity42366 : scanCanonicalize (H12AffineFastState.compose env42366 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42366 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42367 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,2113,41,2048,0,35,2064,2048,53,1,2049,32,16,2,40,65,2049,2064,2112,2048,21,33,117,32,2129,513]

theorem envBound42367 : H12AffineFastState.Bounded env42367 := by
  intro p hp
  have h : env42367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42366_42367 : H12AffineEnvironment.transform 7 117 env42366 = env42367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42366 == env42367) = true)

theorem identity42367 : scanCanonicalize (H12AffineFastState.compose env42367 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42368 : List Nat := [2,4,8,1,32,64,9,100,512,36,2048,2113,41,2048,0,35,2049,2048,36,1,2049,32,1,2,40,65,2049,2049,2112,2048,4,33,100,32,2112,513]

theorem envBound42368 : H12AffineFastState.Bounded env42368 := by
  intro p hp
  have h : env42368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42367_42368 : H12AffineEnvironment.transform 3 1 env42367 = env42368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42367 == env42368) = true)

theorem identity42368 : scanCanonicalize (H12AffineFastState.compose env42368 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42369 : List Nat := [2,4,3,1,32,64,2,100,512,36,2048,2113,34,2048,0,35,2049,2048,36,1,2049,32,1,2,35,65,2049,2049,2112,2048,4,33,100,32,2112,513]

theorem envBound42369 : H12AffineFastState.Bounded env42369 := by
  intro p hp
  have h : env42369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42368_42369 : H12AffineEnvironment.transform 2 3 env42368 = env42369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42368 == env42369) = true)

def env42370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441761,95497,8328,65,270377,436384,45524,32161,412857,156012,256,21793,46213,486254]

theorem envBound42370 : H12AffineFastState.Bounded env42370 := by
  intro p hp
  have h : env42370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42348_42370 : H12AffineEnvironment.transform 21 272513 env42348 = env42370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42348 == env42370) = true)

theorem identity42370 : scanCanonicalize (H12AffineFastState.compose env42370 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound42370 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,115870,243002,73754,95497,8328,65,245138,79131,45524,32161,119042,156012,256,21793,46213,63189]

theorem envBound42371 : H12AffineFastState.Bounded env42371 := by
  intro p hp
  have h : env42371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42370_42371 : H12AffineEnvironment.transform 17 236987 env42370 = env42371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env42370 == env42371) = true)

def env42372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,67755,1024,32769,115870,73770,73754,95497,8328,65,75906,79131,45524,32161,119042,62588,256,21793,46213,63189]

theorem envBound42372 : H12AffineFastState.Bounded env42372 := by
  intro p hp
  have h : env42372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42371_42372 : H12AffineEnvironment.transform 16 38160 env42371 = env42372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42371 == env42372) = true)

theorem identity42372 : scanCanonicalize (H12AffineFastState.compose env42372 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42372 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env42373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10401,1024,32769,58516,32,16,21763,8328,65,2184,5393,45524,32161,61704,62588,256,21793,46213,63189]

theorem envBound42373 : H12AffineFastState.Bounded env42373 := by
  intro p hp
  have h : env42373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42372_42373 : H12AffineEnvironment.transform 15 8202 env42372 = env42373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42372 == env42373) = true)

theorem identity42373 : scanCanonicalize (H12AffineFastState.compose env42373 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound42373 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env42374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,38160,10401,1024,32769,36928,32,16,8663,8328,65,2184,5393,45524,2421,34268,32936,256,8693,46213,33281]

theorem envBound42374 : H12AffineFastState.Bounded env42374 := by
  intro p hp
  have h : env42374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42373_42374 : H12AffineEnvironment.transform 13 13524 env42373 = env42374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env42373 == env42374) = true)

def env42375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,67754,1024,32769,115870,73771,73754,95497,8328,65,75907,79131,45524,32161,119042,62589,256,21793,46213,63189]

theorem envBound42375 : H12AffineFastState.Bounded env42375 := by
  intro p hp
  have h : env42375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42371_42375 : H12AffineEnvironment.transform 16 38161 env42371 = env42375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42371 == env42375) = true)

theorem identity42375 : scanCanonicalize (H12AffineFastState.compose env42375 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound42375 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env42376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38161,56436,1024,32769,4160,62709,62660,41431,8328,65,64605,57797,45524,32161,1500,62589,256,21793,46213,63189]

theorem envBound42376 : H12AffineFastState.Bounded env42376 := by
  intro p hp
  have h : env42376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42375_42376 : H12AffineEnvironment.transform 15 54494 env42375 = env42376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env42375 == env42376) = true)

theorem identity42376 : scanCanonicalize (H12AffineFastState.compose env42376 (packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound42376 : packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env42377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,40971,38161,43169,1024,32769,4160,32800,32785,41431,8328,65,34952,38160,45524,2420,1500,32936,256,8692,46213,33280]

theorem envBound42377 : H12AffineFastState.Bounded env42377 := by
  intro p hp
  have h : env42377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42376_42377 : H12AffineEnvironment.transform 13 13525 env42376 = env42377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env42376 == env42377) = true)

theorem identity42377 : scanCanonicalize (H12AffineFastState.compose env42377 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42377 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,8202,5392,10400,1024,0,4160,33,16,8662,8328,65,2185,5393,12757,2420,1500,169,256,8692,13444,513]

theorem envBound42378 : H12AffineFastState.Bounded env42378 := by
  intro p hp
  have h : env42378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42377_42378 : H12AffineEnvironment.transform 14 1 env42377 = env42378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42377 == env42378) = true)

theorem identity42378 : scanCanonicalize (H12AffineFastState.compose env42378 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound42378 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5456,1,399,5392,2341,1024,0,4160,33,16,83,269,65,2185,5393,4176,2420,1500,169,256,113,5377,513]

theorem envBound42379 : H12AffineFastState.Bounded env42379 := by
  intro p hp
  have h : env42379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42378_42379 : H12AffineEnvironment.transform 12 389 env42378 = env42379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env42378 == env42379) = true)

theorem identity42379 : scanCanonicalize (H12AffineFastState.compose env42379 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 728) := by decide +kernel

theorem selectedBound42379 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env42380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,728,389,1928,1,399,1992,2341,1024,0,664,33,16,83,269,65,2185,1993,648,2420,1500,169,256,113,2009,513]

theorem envBound42380 : H12AffineFastState.Bounded env42380 := by
  intro p hp
  have h : env42380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42379_42380 : H12AffineEnvironment.transform 11 728 env42379 = env42380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 728 env42379 == env42380) = true)

theorem identity42380 : scanCanonicalize (H12AffineFastState.compose env42380 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42380 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env42381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,592,269,1792,1,263,1856,2341,1024,0,528,33,16,83,269,65,2049,1857,512,2420,1364,33,256,113,1873,513]

theorem envBound42381 : H12AffineFastState.Bounded env42381 := by
  intro p hp
  have h : env42381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42380_42381 : H12AffineEnvironment.transform 6 8 env42380 = env42381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42380 == env42381) = true)

theorem identity42381 : scanCanonicalize (H12AffineFastState.compose env42381 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42381 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env42382 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,513,269,1792,1,263,1809,2341,1024,0,528,33,16,2,269,16,2049,1808,512,2341,1285,33,256,32,1792,513]

theorem envBound42382 : H12AffineFastState.Bounded env42382 := by
  intro p hp
  have h : env42382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42381_42382 : H12AffineEnvironment.transform 5 17 env42381 = env42382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42381 == env42382) = true)

theorem identity42382 : scanCanonicalize (H12AffineFastState.compose env42382 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound42382 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42383 : List Nat := [2,4,8,16,32,17,8,256,276,1024,2048,277,269,1044,1,263,1029,2341,1024,0,260,33,16,2,269,16,2049,1028,276,2341,1285,33,256,32,1044,277]

theorem envBound42383 : H12AffineFastState.Bounded env42383 := by
  intro p hp
  have h : env42383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42382_42383 : H12AffineEnvironment.transform 8 276 env42382 = env42383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env42382 == env42383) = true)

theorem identity42383 : scanCanonicalize (H12AffineFastState.compose env42383 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42383 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42384 : List Nat := [2,4,8,16,32,17,8,256,276,20,2048,277,269,0,1,263,17,2341,20,0,260,33,16,2,269,16,2049,16,276,2341,273,33,256,32,0,277]

theorem envBound42384 : H12AffineFastState.Bounded env42384 := by
  intro p hp
  have h : env42384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42383_42384 : H12AffineEnvironment.transform 9 20 env42383 = env42384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42383 == env42384) = true)

theorem identity42384 : scanCanonicalize (H12AffineFastState.compose env42384 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42384 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42385 : List Nat := [2,4,8,1,32,0,8,256,261,5,2048,260,269,0,1,263,0,2341,5,0,260,33,1,2,269,1,2049,1,261,2341,256,33,256,32,0,260]

theorem envBound42385 : H12AffineFastState.Bounded env42385 := by
  intro p hp
  have h : env42385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42384_42385 : H12AffineEnvironment.transform 3 1 env42384 = env42385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42384 == env42385) = true)

theorem identity42385 : scanCanonicalize (H12AffineFastState.compose env42385 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound42385 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42386 : List Nat := [2,4,8,1,32,0,8,256,261,5,33,260,269,0,1,263,0,260,5,0,260,33,1,2,269,1,32,1,261,260,256,33,256,32,0,260]

theorem envBound42386 : H12AffineFastState.Bounded env42386 := by
  intro p hp
  have h : env42386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42385_42386 : H12AffineEnvironment.transform 10 33 env42385 = env42386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env42385 == env42386) = true)

theorem identity42386 : scanCanonicalize (H12AffineFastState.compose env42386 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42387 : List Nat := [2,4,8,1,1,0,8,256,261,5,0,260,269,0,1,263,0,260,5,0,260,0,1,2,269,1,1,1,261,260,256,0,256,1,0,260]

theorem envBound42387 : H12AffineFastState.Bounded env42387 := by
  intro p hp
  have h : env42387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42386_42387 : H12AffineEnvironment.transform 4 1 env42386 = env42387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42386 == env42387) = true)

theorem identity42387 : scanCanonicalize (H12AffineFastState.compose env42387 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42387 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42388 : List Nat := [2,4,8,1,1,0,8,4,1,5,0,0,9,0,1,3,0,0,5,0,0,0,1,2,9,1,1,1,1,0,4,0,4,1,0,0]

theorem envBound42388 : H12AffineFastState.Bounded env42388 := by
  intro p hp
  have h : env42388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42387_42388 : H12AffineEnvironment.transform 7 4 env42387 = env42388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42387 == env42388) = true)

def env42389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound42389 : H12AffineFastState.Bounded env42389 := by
  intro p hp
  have h : env42389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42188_42389 : H12AffineEnvironment.transform 18 1025 env42188 = env42389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env42188 == env42389) = true)

theorem identity42389 : scanCanonicalize (H12AffineFastState.compose env42389 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42389 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616169,18973837,10507600,8579113,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound42390 : H12AffineFastState.Bounded env42390 := by
  intro p hp
  have h : env42390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42389_42390 : H12AffineEnvironment.transform 17 10280 env42389 = env42390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42389 == env42390) = true)

def env42391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616169,18973701,10507600,8579113,25265169,23160137,257,27378725,27337992,25207631]

theorem envBound42391 : H12AffineFastState.Bounded env42391 := by
  intro p hp
  have h : env42391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42390_42391 : H12AffineEnvironment.transform 6 8 env42390 = env42391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42390 == env42391) = true)

theorem identity42391 : scanCanonicalize (H12AffineFastState.compose env42391 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound42391 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,41292,16777216,8192,65,21186917,18973701,2159644,149861,16852317,23160137,257,18965865,18973764,16777731]

theorem envBound42392 : H12AffineFastState.Bounded env42392 := by
  intro p hp
  have h : env42392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42391_42392 : H12AffineEnvironment.transform 22 41292 env42391 = env42392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env42391 == env42392) = true)

theorem identity42392 : scanCanonicalize (H12AffineFastState.compose env42392 (packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound42392 : packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,41292,16777216,8192,65,16935247,18973701,2159644,149861,16852317,18892131,257,18965865,18973764,16777731]

theorem envBound42393 : H12AffineFastState.Bounded env42393 := by
  intro p hp
  have h : env42393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42392_42393 : H12AffineEnvironment.transform 21 73770 env42392 = env42393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env42392 == env42393) = true)

def env42394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1025,32769,2097152,73770,41292,16777216,8192,65,16812035,18973701,2159644,43049,16852317,18892131,257,18965865,18973764,16777731]

theorem envBound42394 : H12AffineFastState.Bounded env42394 := by
  intro p hp
  have h : env42394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42393_42394 : H12AffineEnvironment.transform 16 57676 env42393 = env42394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env42393 == env42394) = true)

theorem identity42394 : scanCanonicalize (H12AffineFastState.compose env42394 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound42394 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1025,32769,2097152,73770,41292,2,8192,65,34817,2196487,2159644,43049,75103,2114913,257,2188651,2196550,513]

theorem envBound42395 : H12AffineFastState.Bounded env42395 := by
  intro p hp
  have h : env42395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42394_42395 : H12AffineEnvironment.transform 23 2 env42394 = env42395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env42394 == env42395) = true)

theorem identity42395 : scanCanonicalize (H12AffineFastState.compose env42395 (packedSelected [0,2,3,5,6,7,10,11,12,14,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 36914) := by decide +kernel

theorem selectedBound42395 : packedSelected [0,2,3,5,6,7,10,11,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env42396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,36914,57676,10280,1025,32769,2097152,45080,41292,2,8192,65,34817,2102325,2159644,43049,46445,2114913,257,2159961,2102388,513]

theorem envBound42396 : H12AffineFastState.Bounded env42396 := by
  intro p hp
  have h : env42396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42395_42396 : H12AffineEnvironment.transform 15 36914 env42395 = env42396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36914 env42395 == env42396) = true)

theorem identity42396 : scanCanonicalize (H12AffineFastState.compose env42396 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound42396 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,16384,32768,36914,53621,6161,1025,32769,2097152,32801,37237,2,4153,65,34817,2102325,2147365,38928,34132,2114913,257,2147680,2102388,513]

theorem envBound42397 : H12AffineFastState.Bounded env42397 := by
  intro p hp
  have h : env42397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42396_42397 : H12AffineEnvironment.transform 12 4153 env42396 = env42397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env42396 == env42397) = true)

theorem identity42397 : scanCanonicalize (H12AffineFastState.compose env42397 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42397 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env42398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,16384,32768,36914,53621,6161,1025,32769,5456,32801,37237,2,4153,65,34817,357,53621,38928,34132,20529,257,53296,292,513]

theorem envBound42398 : H12AffineFastState.Bounded env42398 := by
  intro p hp
  have h : env42398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42397_42398 : H12AffineEnvironment.transform 20 5456 env42397 = env42398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env42397 == env42398) = true)

theorem identity42398 : scanCanonicalize (H12AffineFastState.compose env42398 (packedSelected [0,7,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound42398 : packedSelected [0,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env42399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,16384,4112,34,16741,6161,1025,4113,5456,4145,357,2,4153,65,6161,357,16741,2048,5444,20529,257,16416,292,513]

theorem envBound42399 : H12AffineFastState.Bounded env42399 := by
  intro p hp
  have h : env42399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42398_42399 : H12AffineEnvironment.transform 14 4112 env42398 = env42399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env42398 == env42399) = true)

theorem identity42399 : scanCanonicalize (H12AffineFastState.compose env42399 (packedSelected [0,3,5,6,7,10,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42399 : packedSelected [0,3,5,6,7,10,18] rootPS < 2^1333 := by decide +kernel

def env42400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4153,5377,4112,34,5220,6161,1025,4113,5456,4145,357,2,4153,65,6161,357,5220,2048,5444,1328,257,5409,292,513]

theorem envBound42400 : H12AffineFastState.Bounded env42400 := by
  intro p hp
  have h : env42400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42399_42400 : H12AffineEnvironment.transform 13 5377 env42399 = env42400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42399 == env42400) = true)

theorem identity42400 : scanCanonicalize (H12AffineFastState.compose env42400 (packedSelected [1,2,3,4,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound42400 : packedSelected [1,2,3,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env42401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,4096,4153,5377,4112,34,5220,4160,1025,4113,5456,4145,357,2,4153,65,4160,357,5220,81,5444,1328,257,5409,292,513]

theorem envBound42401 : H12AffineFastState.Bounded env42401 := by
  intro p hp
  have h : env42401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42400_42401 : H12AffineEnvironment.transform 10 81 env42400 = env42401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env42400 == env42401) = true)

theorem identity42401 : scanCanonicalize (H12AffineFastState.compose env42401 (packedSelected [1,2,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound42401 : packedSelected [1,2,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env42402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1281,1336,0,1297,34,357,1345,1025,1296,81,1328,357,2,1336,65,1345,357,357,81,69,1328,257,32,292,513]

theorem envBound42402 : H12AffineFastState.Bounded env42402 := by
  intro p hp
  have h : env42402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42401_42402 : H12AffineEnvironment.transform 11 1281 env42401 = env42402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env42401 == env42402) = true)

theorem identity42402 : scanCanonicalize (H12AffineFastState.compose env42402 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42402 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42403 : List Nat := [2,4,8,16,32,64,8,256,512,100,81,357,348,0,373,34,357,293,101,372,81,340,357,2,348,65,293,357,357,81,69,340,257,32,292,513]

theorem envBound42403 : H12AffineFastState.Bounded env42403 := by
  intro p hp
  have h : env42403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42402_42403 : H12AffineEnvironment.transform 9 100 env42402 = env42403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42402 == env42403) = true)

def env42404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1025,32769,2097152,73770,41292,16777216,8192,65,16812034,18973701,2159644,43048,16852317,18892131,257,18965865,18973764,16777731]

theorem envBound42404 : H12AffineFastState.Bounded env42404 := by
  intro p hp
  have h : env42404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42393_42404 : H12AffineEnvironment.transform 16 57677 env42393 = env42404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env42393 == env42404) = true)

theorem identity42404 : scanCanonicalize (H12AffineFastState.compose env42404 (packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 2155882) := by decide +kernel

theorem selectedBound42404 : packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env42405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1025,32769,2097152,73770,41292,2155882,8192,65,2125160,90479,2159644,43048,2211895,40969,257,98307,90414,2156393]

theorem envBound42405 : H12AffineFastState.Bounded env42405 := by
  intro p hp
  have h : env42405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42404_42405 : H12AffineEnvironment.transform 23 2155882 env42404 = env42405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2155882 env42404 == env42405) = true)

theorem identity42405 : scanCanonicalize (H12AffineFastState.compose env42405 (packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42405 : packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env42406 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,57401,10280,1025,32769,2097152,73770,41016,2155550,8192,65,2124828,90139,2159644,43048,2211895,40969,117,98307,90202,2156061]

theorem envBound42406 : H12AffineFastState.Bounded env42406 := by
  intro p hp
  have h : env42406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42405_42406 : H12AffineEnvironment.transform 7 116 env42405 = env42406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42405 == env42406) = true)

theorem identity42406 : scanCanonicalize (H12AffineFastState.compose env42406 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42406 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env42407 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,57401,10280,1025,32769,2097152,33,41016,2155550,8192,65,2124828,16400,2159644,43048,2154556,40969,117,40968,16465,2156061]

theorem envBound42407 : H12AffineFastState.Bounded env42407 := by
  intro p hp
  have h : env42407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42406_42407 : H12AffineEnvironment.transform 15 8203 env42406 = env42407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42406 == env42407) = true)

theorem identity42407 : scanCanonicalize (H12AffineFastState.compose env42407 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound42407 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env42408 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,57401,10280,1025,32769,58397,33,41016,3,8192,65,34817,16400,4097,43048,1057,40969,117,40968,16465,512]

theorem envBound42408 : H12AffineFastState.Bounded env42408 := by
  intro p hp
  have h : env42408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42407_42408 : H12AffineEnvironment.transform 20 58397 env42407 = env42408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env42407 == env42408) = true)

theorem identity42408 : scanCanonicalize (H12AffineFastState.compose env42408 (packedSelected [0,2,3,5,6,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 15484) := by decide +kernel

theorem selectedBound42408 : packedSelected [0,2,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env42409 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,15484,32768,8203,40005,10280,1025,32769,39009,33,41016,3,8192,65,34817,15468,4097,43048,1057,40969,117,40968,15405,512]

theorem envBound42409 : H12AffineFastState.Bounded env42409 := by
  intro p hp
  have h : env42409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42408_42409 : H12AffineEnvironment.transform 13 15484 env42408 = env42409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15484 env42408 == env42409) = true)

theorem identity42409 : scanCanonicalize (H12AffineFastState.compose env42409 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42409 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env42410 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,15404,32768,8203,39957,10280,1025,32769,38961,33,41016,3,8192,17,34817,15420,4097,43048,1057,40969,37,40968,15405,512]

theorem envBound42410 : H12AffineFastState.Bounded env42410 := by
  intro p hp
  have h : env42410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42409_42410 : H12AffineEnvironment.transform 5 16 env42409 = env42410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42409 == env42410) = true)

theorem identity42410 : scanCanonicalize (H12AffineFastState.compose env42410 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound42410 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42411 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,9,7205,32768,2,39957,2081,1025,32769,38961,33,32817,3,9,17,34817,7221,4097,34849,1057,32768,37,32769,7204,512]

theorem envBound42411 : H12AffineFastState.Bounded env42411 := by
  intro p hp
  have h : env42411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42410_42411 : H12AffineEnvironment.transform 12 9 env42410 = env42411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env42410 == env42411) = true)

theorem identity42411 : scanCanonicalize (H12AffineFastState.compose env42411 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42411 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42412 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,4096,9,5157,32768,2,37909,33,1025,32769,36913,33,32817,3,9,17,32769,5173,4097,32801,1057,32768,37,32769,5156,512]

theorem envBound42412 : H12AffineFastState.Bounded env42412 := by
  intro p hp
  have h : env42412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42411_42412 : H12AffineEnvironment.transform 10 0 env42411 = env42412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42411 == env42412) = true)

theorem identity42412 : scanCanonicalize (H12AffineFastState.compose env42412 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42412 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42413 : List Nat := [2,4,8,16,1,16,8,5,512,1024,0,4096,9,5124,32768,2,37909,0,1025,32769,36880,0,32784,3,9,17,32769,5140,4097,32768,1024,32768,4,32769,5125,512]

theorem envBound42413 : H12AffineFastState.Bounded env42413 := by
  intro p hp
  have h : env42413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42412_42413 : H12AffineEnvironment.transform 4 1 env42412 = env42413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42412 == env42413) = true)

theorem identity42413 : scanCanonicalize (H12AffineFastState.compose env42413 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound42413 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42414 : List Nat := [2,4,8,16,1,16,8,5,512,1024,0,1029,9,1,32768,2,32784,0,1025,32769,33813,0,32784,3,9,17,32769,17,1028,32768,1024,32768,4,32769,0,512]

theorem envBound42414 : H12AffineFastState.Bounded env42414 := by
  intro p hp
  have h : env42414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42413_42414 : H12AffineEnvironment.transform 11 1029 env42413 = env42414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env42413 == env42414) = true)

theorem identity42414 : scanCanonicalize (H12AffineFastState.compose env42414 (packedSelected [0,4] rootPS)) = affineNative (2^(14+1) ^^^ 1045) := by decide +kernel

theorem selectedBound42414 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42415 : List Nat := [2,4,8,16,1,16,8,5,512,1024,0,1029,9,1,1045,2,1029,0,1025,1044,0,0,1029,3,9,17,1044,17,1028,1045,1024,1045,4,1044,0,512]

theorem envBound42415 : H12AffineFastState.Bounded env42415 := by
  intro p hp
  have h : env42415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42414_42415 : H12AffineEnvironment.transform 14 1045 env42414 = env42415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1045 env42414 == env42415) = true)

theorem identity42415 : scanCanonicalize (H12AffineFastState.compose env42415 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound42415 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42416 : List Nat := [2,4,8,16,1,16,8,5,512,21,0,16,9,1,0,2,16,0,20,1,0,0,16,3,9,17,1,17,17,0,21,0,4,1,0,512]

theorem envBound42416 : H12AffineFastState.Bounded env42416 := by
  intro p hp
  have h : env42416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42415_42416 : H12AffineEnvironment.transform 9 21 env42415 = env42416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42415 == env42416) = true)

theorem identity42416 : scanCanonicalize (H12AffineFastState.compose env42416 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42417 : List Nat := [2,4,8,16,1,16,8,5,17,21,0,16,9,1,0,2,16,0,20,1,0,0,16,3,9,17,1,17,17,0,21,0,4,1,0,17]

theorem envBound42417 : H12AffineFastState.Bounded env42417 := by
  intro p hp
  have h : env42417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42416_42417 : H12AffineEnvironment.transform 8 17 env42416 = env42417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42416 == env42417) = true)

theorem identity42417 : scanCanonicalize (H12AffineFastState.compose env42417 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound42417 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42418 : List Nat := [2,4,6,16,1,16,6,5,17,21,0,16,7,1,0,2,16,0,20,1,0,0,16,3,7,17,1,17,17,0,21,0,4,1,0,17]

theorem envBound42418 : H12AffineFastState.Bounded env42418 := by
  intro p hp
  have h : env42418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42417_42418 : H12AffineEnvironment.transform 2 6 env42417 = env42418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env42417 == env42418) = true)

def env42419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616169,18973700,10507600,8579113,25265169,23160136,257,27378724,27337992,25207630]

theorem envBound42419 : H12AffineFastState.Bounded env42419 := by
  intro p hp
  have h : env42419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42390_42419 : H12AffineEnvironment.transform 6 9 env42390 = env42419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42390 == env42419) = true)

def env42420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,16777216,8193,65,21080105,18973700,2233680,43049,17024017,23160136,257,19104804,19096840,16966478]

theorem envBound42420 : H12AffineFastState.Bounded env42420 := by
  intro p hp
  have h : env42420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42419_42420 : H12AffineEnvironment.transform 22 147456 env42419 = env42420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env42419 == env42420) = true)

theorem identity42420 : scanCanonicalize (H12AffineFastState.compose env42420 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound42420 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,188751,8193,65,4409702,2319691,2233680,43049,75102,6521863,257,2188651,2196551,513]

theorem envBound42421 : H12AffineFastState.Bounded env42421 := by
  intro p hp
  have h : env42421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42420_42421 : H12AffineEnvironment.transform 23 188751 env42420 = env42421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env42420 == env42421) = true)

def env42422 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,188703,8193,17,4409654,2319643,2233600,43049,75022,6521863,257,2188603,2196503,513]

theorem envBound42422 : H12AffineFastState.Bounded env42422 := by
  intro p hp
  have h : env42422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42421_42422 : H12AffineEnvironment.transform 5 16 env42421 = env42422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42421 == env42422) = true)

theorem identity42422 : scanCanonicalize (H12AffineFastState.compose env42422 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound42422 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env42423 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,4194304,147456,188703,8193,17,4409654,172300,250135,43049,75022,4341776,257,41260,16384,513]

theorem envBound42423 : H12AffineFastState.Bounded env42423 := by
  intro p hp
  have h : env42423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42422_42423 : H12AffineEnvironment.transform 20 115735 env42422 = env42423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env42422 == env42423) = true)

theorem identity42423 : scanCanonicalize (H12AffineFastState.compose env42423 (packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42423 : packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env42424 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115735,4194304,147456,180243,269,17,4409654,163840,250135,35109,66562,4341776,257,32800,16384,513]

theorem envBound42424 : H12AffineFastState.Bounded env42424 := by
  intro p hp
  have h : env42424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42423_42424 : H12AffineEnvironment.transform 12 268 env42423 = env42424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42423 == env42424) = true)

theorem identity42424 : scanCanonicalize (H12AffineFastState.compose env42424 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound42424 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env42425 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115735,32800,147456,180243,269,17,248086,163840,250135,35109,66562,180272,257,32800,16384,513]

theorem envBound42425 : H12AffineFastState.Bounded env42425 := by
  intro p hp
  have h : env42425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42424_42425 : H12AffineEnvironment.transform 21 32800 env42424 = env42425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env42424 == env42425) = true)

theorem identity42425 : scanCanonicalize (H12AffineFastState.compose env42425 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound42425 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42426 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,82199,2340,1025,32769,115735,32800,65815,98564,269,17,34817,114967,36864,35109,66562,98599,257,32800,16384,513]

theorem envBound42426 : H12AffineFastState.Bounded env42426 := by
  intro p hp
  have h : env42426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42425_42426 : H12AffineEnvironment.transform 16 82199 env42425 = env42426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env42425 == env42426) = true)

theorem identity42426 : scanCanonicalize (H12AffineFastState.compose env42426 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound42426 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42427 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16401,2340,1025,32769,50449,32800,17,32770,269,17,34817,49169,36864,35109,1284,32801,257,32800,16384,513]

theorem envBound42427 : H12AffineFastState.Bounded env42427 := by
  intro p hp
  have h : env42427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42426_42427 : H12AffineEnvironment.transform 15 262 env42426 = env42427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env42426 == env42427) = true)

theorem identity42427 : scanCanonicalize (H12AffineFastState.compose env42427 (packedSelected [4,9,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42427 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env42428 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16401,2340,1025,0,17680,33,17,3,269,17,2048,16400,4097,2340,1284,32,257,33,16384,513]

theorem envBound42428 : H12AffineFastState.Bounded env42428 := by
  intro p hp
  have h : env42428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42427_42428 : H12AffineEnvironment.transform 14 1 env42427 = env42428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42427 == env42428) = true)

theorem identity42428 : scanCanonicalize (H12AffineFastState.compose env42428 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound42428 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42429 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5157,1,262,5172,2340,1025,0,4405,33,17,3,269,17,2048,5173,4097,2340,1284,32,257,33,5157,513]

theorem envBound42429 : H12AffineFastState.Bounded env42429 := by
  intro p hp
  have h : env42429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42428_42429 : H12AffineEnvironment.transform 13 5157 env42428 = env42429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env42428 == env42429) = true)

def env42430 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,268,2837,1,262,2820,2340,1025,0,3589,33,17,3,269,17,2048,2821,3889,2340,1284,32,257,33,2837,513]

theorem envBound42430 : H12AffineFastState.Bounded env42430 := by
  intro p hp
  have h : env42430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42429_42430 : H12AffineEnvironment.transform 11 3888 env42429 = env42430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env42429 == env42430) = true)

def env42431 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,268,1045,1,262,1028,1572,1025,0,261,33,17,3,269,17,1792,1029,49,1572,1284,32,257,33,1045,513]

theorem envBound42431 : H12AffineFastState.Bounded env42431 := by
  intro p hp
  have h : env42431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42430_42431 : H12AffineEnvironment.transform 10 1792 env42430 = env42431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env42430 == env42431) = true)

theorem identity42431 : scanCanonicalize (H12AffineFastState.compose env42431 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound42431 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42432 : List Nat := [2,4,8,16,32,16,9,256,512,21,789,48,268,0,1,262,17,561,20,0,261,33,17,3,269,17,789,16,49,561,273,32,257,33,0,513]

theorem envBound42432 : H12AffineFastState.Bounded env42432 := by
  intro p hp
  have h : env42432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42431_42432 : H12AffineEnvironment.transform 9 21 env42431 = env42432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42431 == env42432) = true)

def env42433 : List Nat := [2,4,8,16,0,16,9,256,512,21,789,16,268,0,1,262,17,529,20,0,261,1,17,3,269,17,789,16,17,529,273,0,257,1,0,513]

theorem envBound42433 : H12AffineFastState.Bounded env42433 := by
  intro p hp
  have h : env42433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42432_42433 : H12AffineEnvironment.transform 4 0 env42432 = env42433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42432 == env42433) = true)

theorem identity42433 : scanCanonicalize (H12AffineFastState.compose env42433 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42433 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42434 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,10,268,0,1,262,11,523,14,0,261,1,11,3,269,11,783,10,11,523,267,0,257,1,0,513]

theorem envBound42434 : H12AffineFastState.Bounded env42434 := by
  intro p hp
  have h : env42434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42433_42434 : H12AffineEnvironment.transform 3 10 env42433 = env42434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42433 == env42434) = true)

def leafEnv42434 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,10,268,0,1,262,11,523,14,0,261,1,11,3,266,269,1,11,783,10,11,523,267,0,257,1,5,263,0,513,1,261,0]

def active42434 : List Nat := [0,1,2,7,8]

def tree42434 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42434 : H12WitnessSearch.Good tree42434 := H12GlobalWitnessIndex.good

theorem leafIdentity42434 : H12AffineFastState.composeSystem env42434 rootObs = leafEnv42434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42434 rootObs == leafEnv42434) = true)

theorem terminalChecked42434 : H12PackedTerminal.terminalCheckFast leafEnv42434 active42434 tree42434 = true := by decide +kernel

def env42435 : List Nat := [2,4,8,16,1,16,9,256,512,21,789,17,268,0,1,262,17,528,20,0,261,0,17,3,269,17,789,16,16,528,273,1,257,0,0,513]

theorem envBound42435 : H12AffineFastState.Bounded env42435 := by
  intro p hp
  have h : env42435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42432_42435 : H12AffineEnvironment.transform 4 1 env42432 = env42435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42432 == env42435) = true)

theorem identity42435 : scanCanonicalize (H12AffineFastState.compose env42435 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound42435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42436 : List Nat := [2,4,8,16,1,16,9,256,276,21,1,17,268,0,1,262,17,260,20,0,261,0,17,3,269,17,1,16,16,260,273,1,257,0,0,277]

theorem envBound42436 : H12AffineFastState.Bounded env42436 := by
  intro p hp
  have h : env42436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42435_42436 : H12AffineEnvironment.transform 8 276 env42435 = env42436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env42435 == env42436) = true)

def leafEnv42436 : List Nat := [2,4,8,16,1,16,9,256,276,21,1,17,268,0,1,262,17,260,20,0,261,0,17,3,272,269,1,17,1,16,16,260,273,1,257,0,5,263,0,277,1,261,0]

def active42436 : List Nat := [0,1,2,3,7]

def tree42436 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42436 : H12WitnessSearch.Good tree42436 := H12GlobalWitnessIndex.good

theorem leafIdentity42436 : H12AffineFastState.composeSystem env42436 rootObs = leafEnv42436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42436 rootObs == leafEnv42436) = true)

theorem terminalChecked42436 : H12PackedTerminal.terminalCheckFast leafEnv42436 active42436 tree42436 = true := by decide +kernel

def env42437 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,268,1044,1,262,1029,1573,1025,0,260,33,17,3,269,17,1793,1028,48,1573,1284,32,257,33,1044,513]

theorem envBound42437 : H12AffineFastState.Bounded env42437 := by
  intro p hp
  have h : env42437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42430_42437 : H12AffineEnvironment.transform 10 1793 env42430 = env42437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env42430 == env42437) = true)

theorem identity42437 : scanCanonicalize (H12AffineFastState.compose env42437 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42438 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1541,49,8,1044,1,2,1029,1573,1025,0,0,33,17,3,9,17,1541,1028,48,1573,1024,32,5,33,1044,513]

theorem envBound42438 : H12AffineFastState.Bounded env42438 := by
  intro p hp
  have h : env42438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42437_42438 : H12AffineEnvironment.transform 7 4 env42437 = env42438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42437 == env42438) = true)

def env42439 : List Nat := [2,4,8,16,32,16,9,4,512,52,561,49,8,32,1,2,49,529,53,0,0,33,17,3,9,17,561,48,48,529,52,32,5,33,32,513]

theorem envBound42439 : H12AffineFastState.Bounded env42439 := by
  intro p hp
  have h : env42439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42438_42439 : H12AffineEnvironment.transform 9 52 env42438 = env42439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42438 == env42439) = true)

theorem identity42439 : scanCanonicalize (H12AffineFastState.compose env42439 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42440 : List Nat := [2,4,8,16,32,16,9,4,16,52,33,49,8,32,1,2,49,1,53,0,0,33,17,3,9,17,33,48,48,1,52,32,5,33,32,17]

theorem envBound42440 : H12AffineFastState.Bounded env42440 := by
  intro p hp
  have h : env42440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42439_42440 : H12AffineEnvironment.transform 8 16 env42439 = env42440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42439 == env42440) = true)

def leafEnv42440 : List Nat := [2,4,8,16,32,16,9,4,16,52,33,49,8,32,1,2,49,1,53,0,0,33,17,3,53,9,1,17,33,48,48,1,52,32,5,33,5,3,32,17,1,0,0]

def active42440 : List Nat := [0,1,2,3,4]

def tree42440 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42440 : H12WitnessSearch.Good tree42440 := H12GlobalWitnessIndex.good

theorem leafIdentity42440 : H12AffineFastState.composeSystem env42440 rootObs = leafEnv42440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42440 rootObs == leafEnv42440) = true)

theorem terminalChecked42440 : H12PackedTerminal.terminalCheckFast leafEnv42440 active42440 tree42440 = true := by decide +kernel

def env42441 : List Nat := [2,4,8,16,32,16,9,4,512,53,560,49,8,33,1,2,48,528,52,0,0,33,17,3,9,17,560,49,48,528,53,32,5,33,33,513]

theorem envBound42441 : H12AffineFastState.Bounded env42441 := by
  intro p hp
  have h : env42441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42438_42441 : H12AffineEnvironment.transform 9 53 env42438 = env42441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42438 == env42441) = true)

theorem identity42441 : scanCanonicalize (H12AffineFastState.compose env42441 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42441 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42442 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,42,8,33,1,2,43,523,47,0,0,33,10,3,9,10,555,42,43,523,46,32,5,33,33,513]

theorem envBound42442 : H12AffineFastState.Bounded env42442 := by
  intro p hp
  have h : env42442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42441_42442 : H12AffineEnvironment.transform 3 11 env42441 = env42442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42441 == env42442) = true)

def leafEnv42442 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,42,8,33,1,2,43,523,47,0,0,33,10,3,47,9,1,10,555,42,43,523,46,32,5,33,5,3,33,513,1,0,0]

def active42442 : List Nat := [0,1,2,4,8]

def tree42442 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42442 : H12WitnessSearch.Good tree42442 := H12GlobalWitnessIndex.good

theorem leafIdentity42442 : H12AffineFastState.composeSystem env42442 rootObs = leafEnv42442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42442 rootObs == leafEnv42442) = true)

theorem terminalChecked42442 : H12PackedTerminal.terminalCheckFast leafEnv42442 active42442 tree42442 = true := by decide +kernel

def env42443 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,268,2836,1,262,2821,2340,1025,0,3588,33,17,3,269,17,2048,2820,3888,2340,1284,32,257,33,2836,513]

theorem envBound42443 : H12AffineFastState.Bounded env42443 := by
  intro p hp
  have h : env42443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42429_42443 : H12AffineEnvironment.transform 11 3889 env42429 = env42443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env42429 == env42443) = true)

def env42444 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,268,1044,1,262,1029,1572,1025,0,260,33,17,3,269,17,1792,1028,48,1572,1284,32,257,33,1044,513]

theorem envBound42444 : H12AffineFastState.Bounded env42444 := by
  intro p hp
  have h : env42444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42443_42444 : H12AffineEnvironment.transform 10 1792 env42443 = env42444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env42443 == env42444) = true)

theorem identity42444 : scanCanonicalize (H12AffineFastState.compose env42444 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42445 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1792,16,268,1044,1,262,1029,1541,1025,0,260,0,17,3,269,17,1792,1028,17,1541,1284,1,257,0,1044,513]

theorem envBound42445 : H12AffineFastState.Bounded env42445 := by
  intro p hp
  have h : env42445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42444_42445 : H12AffineEnvironment.transform 4 1 env42444 = env42445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42444 == env42445) = true)

def env42446 : List Nat := [2,4,8,16,1,16,9,256,512,20,788,16,268,0,1,262,17,529,21,0,260,0,17,3,269,17,788,16,17,529,272,1,257,0,0,513]

theorem envBound42446 : H12AffineFastState.Bounded env42446 := by
  intro p hp
  have h : env42446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42445_42446 : H12AffineEnvironment.transform 9 20 env42445 = env42446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42445 == env42446) = true)

theorem identity42446 : scanCanonicalize (H12AffineFastState.compose env42446 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42447 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,10,268,0,1,262,11,523,15,0,260,0,11,3,269,11,782,10,11,523,266,1,257,0,0,513]

theorem envBound42447 : H12AffineFastState.Bounded env42447 := by
  intro p hp
  have h : env42447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42446_42447 : H12AffineEnvironment.transform 3 10 env42446 = env42447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42446 == env42447) = true)

def leafEnv42447 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,10,268,0,1,262,11,523,15,0,260,0,11,3,267,269,1,11,782,10,11,523,266,1,257,0,5,263,0,513,1,260,0]

def active42447 : List Nat := [0,1,2,7,8]

def tree42447 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42447 : H12WitnessSearch.Good tree42447 := H12GlobalWitnessIndex.good

theorem leafIdentity42447 : H12AffineFastState.composeSystem env42447 rootObs = leafEnv42447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42447 rootObs == leafEnv42447) = true)

theorem terminalChecked42447 : H12PackedTerminal.terminalCheckFast leafEnv42447 active42447 tree42447 = true := by decide +kernel

def env42448 : List Nat := [2,4,8,16,1,16,9,256,512,21,789,16,268,1,1,262,16,528,20,0,260,0,17,3,269,17,789,17,17,528,273,1,257,0,1,513]

theorem envBound42448 : H12AffineFastState.Bounded env42448 := by
  intro p hp
  have h : env42448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42445_42448 : H12AffineEnvironment.transform 9 21 env42445 = env42448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42445 == env42448) = true)

theorem identity42448 : scanCanonicalize (H12AffineFastState.compose env42448 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound42448 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42449 : List Nat := [2,4,8,16,1,16,9,256,277,21,0,16,268,1,1,262,16,261,20,0,260,0,17,3,269,17,0,17,17,261,273,1,257,0,1,276]

theorem envBound42449 : H12AffineFastState.Bounded env42449 := by
  intro p hp
  have h : env42449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42448_42449 : H12AffineEnvironment.transform 8 277 env42448 = env42449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env42448 == env42449) = true)

def leafEnv42449 : List Nat := [2,4,8,16,1,16,9,256,277,21,0,16,268,1,1,262,16,261,20,0,260,0,17,3,272,269,1,17,0,17,17,261,273,1,257,0,5,263,1,276,1,260,0]

def active42449 : List Nat := [0,1,2,3,7]

def tree42449 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42449 : H12WitnessSearch.Good tree42449 := H12GlobalWitnessIndex.good

theorem leafIdentity42449 : H12AffineFastState.composeSystem env42449 rootObs = leafEnv42449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42449 rootObs == leafEnv42449) = true)

theorem terminalChecked42449 : H12PackedTerminal.terminalCheckFast leafEnv42449 active42449 tree42449 = true := by decide +kernel

def env42450 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,268,1045,1,262,1028,1573,1025,0,261,33,17,3,269,17,1793,1029,49,1573,1284,32,257,33,1045,513]

theorem envBound42450 : H12AffineFastState.Bounded env42450 := by
  intro p hp
  have h : env42450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42443_42450 : H12AffineEnvironment.transform 10 1793 env42443 = env42450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env42443 == env42450) = true)

theorem identity42450 : scanCanonicalize (H12AffineFastState.compose env42450 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound42450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42451 : List Nat := [2,4,8,16,32,16,9,256,512,304,561,48,268,293,1,262,308,789,305,0,261,33,17,3,269,17,561,309,49,789,52,32,257,33,293,513]

theorem envBound42451 : H12AffineFastState.Bounded env42451 := by
  intro p hp
  have h : env42451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42450_42451 : H12AffineEnvironment.transform 9 304 env42450 = env42451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env42450 == env42451) = true)

def env42452 : List Nat := [2,4,8,16,32,16,9,4,512,52,561,48,8,33,1,2,48,529,53,0,1,33,17,3,9,17,561,49,49,529,52,32,5,33,33,513]

theorem envBound42452 : H12AffineFastState.Bounded env42452 := by
  intro p hp
  have h : env42452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42451_42452 : H12AffineEnvironment.transform 7 4 env42451 = env42452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42451 == env42452) = true)

theorem identity42452 : scanCanonicalize (H12AffineFastState.compose env42452 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42453 : List Nat := [2,4,8,16,32,16,9,4,17,52,32,48,8,33,1,2,48,0,53,0,1,33,17,3,9,17,32,49,49,0,52,32,5,33,33,16]

theorem envBound42453 : H12AffineFastState.Bounded env42453 := by
  intro p hp
  have h : env42453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42452_42453 : H12AffineEnvironment.transform 8 17 env42452 = env42453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42452 == env42453) = true)

def leafEnv42453 : List Nat := [2,4,8,16,32,16,9,4,17,52,32,48,8,33,1,2,48,0,53,0,1,33,17,3,53,9,1,17,32,49,49,0,52,32,5,33,5,3,33,16,1,1,0]

def active42453 : List Nat := [0,1,2,3,4]

def tree42453 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42453 : H12WitnessSearch.Good tree42453 := H12GlobalWitnessIndex.good

theorem leafIdentity42453 : H12AffineFastState.composeSystem env42453 rootObs = leafEnv42453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42453 rootObs == leafEnv42453) = true)

theorem terminalChecked42453 : H12PackedTerminal.terminalCheckFast leafEnv42453 active42453 tree42453 = true := by decide +kernel

def env42454 : List Nat := [2,4,8,16,32,16,9,5,512,53,561,48,9,32,1,3,49,528,52,0,0,33,17,3,8,17,561,48,49,528,52,32,4,33,32,513]

theorem envBound42454 : H12AffineFastState.Bounded env42454 := by
  intro p hp
  have h : env42454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42451_42454 : H12AffineEnvironment.transform 7 5 env42451 = env42454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42451 == env42454) = true)

theorem identity42454 : scanCanonicalize (H12AffineFastState.compose env42454 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42455 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,43,9,32,1,3,42,523,47,0,0,33,10,3,8,10,554,43,42,523,47,32,4,33,32,513]

theorem envBound42455 : H12AffineFastState.Bounded env42455 := by
  intro p hp
  have h : env42455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42454_42455 : H12AffineEnvironment.transform 3 11 env42454 = env42455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42454 == env42455) = true)

def leafEnv42455 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,43,9,32,1,3,42,523,47,0,0,33,10,3,46,8,1,10,554,43,42,523,47,32,4,33,5,2,32,513,1,0,0]

def active42455 : List Nat := [0,1,2,4,8]

def tree42455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42455 : H12WitnessSearch.Good tree42455 := H12GlobalWitnessIndex.good

theorem leafIdentity42455 : H12AffineFastState.composeSystem env42455 rootObs = leafEnv42455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42455 rootObs == leafEnv42455) = true)

theorem terminalChecked42455 : H12PackedTerminal.terminalCheckFast leafEnv42455 active42455 tree42455 = true := by decide +kernel

def env42456 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,188702,8193,16,4409655,2319642,2233601,43049,75023,6521863,257,2188602,2196502,513]

theorem envBound42456 : H12AffineFastState.Bounded env42456 := by
  intro p hp
  have h : env42456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42421_42456 : H12AffineEnvironment.transform 5 17 env42421 = env42456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42421 == env42456) = true)

theorem identity42456 : scanCanonicalize (H12AffineFastState.compose env42456 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 2270252) := by decide +kernel

theorem selectedBound42456 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env42457 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2270252,147456,188702,8193,16,2223387,2319642,2233601,43049,75023,73771,257,2188602,2196502,513]

theorem envBound42457 : H12AffineFastState.Bounded env42457 := by
  intro p hp
  have h : env42457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42456_42457 : H12AffineEnvironment.transform 21 2270252 env42456 = env42457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2270252 env42456 == env42457) = true)

theorem identity42457 : scanCanonicalize (H12AffineFastState.compose env42457 (packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound42457 : packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env42458 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,221242,147456,188702,8193,16,10509,172300,250135,43049,75023,73771,257,41260,16384,513]

theorem envBound42458 : H12AffineFastState.Bounded env42458 := by
  intro p hp
  have h : env42458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42457_42458 : H12AffineEnvironment.transform 20 115734 env42457 = env42458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env42457 == env42458) = true)

theorem identity42458 : scanCanonicalize (H12AffineFastState.compose env42458 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound42458 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env42459 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10280,1025,8460,91419,221242,147456,147475,8193,16,10509,131073,225306,2340,75023,73771,257,33,16384,513]

theorem envBound42459 : H12AffineFastState.Bounded env42459 := by
  intro p hp
  have h : env42459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42458_42459 : H12AffineEnvironment.transform 14 8461 env42458 = env42459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env42458 == env42459) = true)

theorem identity42459 : scanCanonicalize (H12AffineFastState.compose env42459 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42459 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42460 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,90138,10280,1025,8460,91419,32,73754,73737,8193,16,10509,90139,4096,2340,75023,73771,257,33,16384,513]

theorem envBound42460 : H12AffineFastState.Bounded env42460 := by
  intro p hp
  have h : env42460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42459_42460 : H12AffineEnvironment.transform 16 90138 env42459 = env42460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42459 == env42460) = true)

theorem identity42460 : scanCanonicalize (H12AffineFastState.compose env42460 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound42460 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42461 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,263,24861,10280,1025,8460,25628,32,8477,8462,8193,16,10509,24860,4096,2340,9224,8492,257,33,16384,513]

theorem envBound42461 : H12AffineFastState.Bounded env42461 := by
  intro p hp
  have h : env42461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42460_42461 : H12AffineEnvironment.transform 15 263 env42460 = env42461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env42460 == env42461) = true)

theorem identity42461 : scanCanonicalize (H12AffineFastState.compose env42461 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42461 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42462 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16400,2341,1025,1,17681,32,16,3,268,16,2048,16401,4096,2340,1285,33,257,33,16384,513]

theorem envBound42462 : H12AffineFastState.Bounded env42462 := by
  intro p hp
  have h : env42462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42461_42462 : H12AffineEnvironment.transform 12 269 env42461 = env42462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42461 == env42462) = true)

theorem identity42462 : scanCanonicalize (H12AffineFastState.compose env42462 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound42462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42463 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,4145,0,263,4129,2341,1025,1,5408,32,16,3,268,16,2048,4128,4096,2340,1285,33,257,33,4145,513]

theorem envBound42463 : H12AffineFastState.Bounded env42463 := by
  intro p hp
  have h : env42463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42462_42463 : H12AffineEnvironment.transform 13 4145 env42462 = env42463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env42462 == env42463) = true)

theorem identity42463 : scanCanonicalize (H12AffineFastState.compose env42463 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3631) := by decide +kernel

theorem selectedBound42463 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42464 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3631,269,3614,0,263,3598,2341,1025,1,2831,32,16,3,268,16,2048,3599,3631,2340,1285,33,257,33,3614,513]

theorem envBound42464 : H12AffineFastState.Bounded env42464 := by
  intro p hp
  have h : env42464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42463_42464 : H12AffineEnvironment.transform 11 3631 env42463 = env42464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3631 env42463 == env42464) = true)

theorem identity42464 : scanCanonicalize (H12AffineFastState.compose env42464 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42464 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42465 : List Nat := [2,4,8,16,11,17,9,256,512,1024,2048,3588,269,3614,0,263,3598,2318,1025,1,2831,11,16,3,268,16,2048,3599,3588,2319,1285,10,257,10,3614,513]

theorem envBound42465 : H12AffineFastState.Bounded env42465 := by
  intro p hp
  have h : env42465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42464_42465 : H12AffineEnvironment.transform 4 11 env42464 = env42465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42464 == env42465) = true)

theorem identity42465 : scanCanonicalize (H12AffineFastState.compose env42465 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound42465 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42466 : List Nat := [2,4,8,16,11,17,9,256,512,516,2048,2048,269,2074,0,263,2058,2318,517,1,2831,11,16,3,268,16,2048,2059,2048,2319,769,10,257,10,2074,513]

theorem envBound42466 : H12AffineFastState.Bounded env42466 := by
  intro p hp
  have h : env42466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42465_42466 : H12AffineEnvironment.transform 9 516 env42465 = env42466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env42465 == env42466) = true)

theorem identity42466 : scanCanonicalize (H12AffineFastState.compose env42466 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound42466 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42467 : List Nat := [2,4,8,16,11,17,9,256,512,516,271,271,269,277,0,263,261,1,517,1,512,11,16,3,268,16,271,260,271,0,769,10,257,10,277,513]

theorem envBound42467 : H12AffineFastState.Bounded env42467 := by
  intro p hp
  have h : env42467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42466_42467 : H12AffineEnvironment.transform 10 271 env42466 = env42467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env42466 == env42467) = true)

theorem identity42467 : scanCanonicalize (H12AffineFastState.compose env42467 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42467 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42468 : List Nat := [2,4,8,16,11,17,9,20,512,516,27,27,25,1,0,19,17,1,517,1,512,11,16,3,24,16,27,16,27,0,533,10,21,10,1,513]

theorem envBound42468 : H12AffineFastState.Bounded env42468 := by
  intro p hp
  have h : env42468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42467_42468 : H12AffineEnvironment.transform 7 20 env42467 = env42468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42467 == env42468) = true)

theorem identity42468 : scanCanonicalize (H12AffineFastState.compose env42468 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42468 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env42469 : List Nat := [2,4,8,0,11,1,9,4,512,516,11,11,9,1,0,3,1,1,517,1,512,11,0,3,8,0,11,0,11,0,517,10,5,10,1,513]

theorem envBound42469 : H12AffineFastState.Bounded env42469 := by
  intro p hp
  have h : env42469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42468_42469 : H12AffineEnvironment.transform 3 0 env42468 = env42469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42468 == env42469) = true)

theorem identity42469 : scanCanonicalize (H12AffineFastState.compose env42469 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound42469 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42470 : List Nat := [2,4,8,0,11,1,9,4,7,3,11,11,9,1,0,3,1,1,2,1,7,11,0,3,8,0,11,0,11,0,2,10,5,10,1,6]

theorem envBound42470 : H12AffineFastState.Bounded env42470 := by
  intro p hp
  have h : env42470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42469_42470 : H12AffineEnvironment.transform 8 7 env42469 = env42470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env42469 == env42470) = true)

def env42471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,16777216,8193,65,21080104,18973700,2233681,43048,17024016,23160136,257,19104805,19096841,16966479]

theorem envBound42471 : H12AffineFastState.Bounded env42471 := by
  intro p hp
  have h : env42471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42419_42471 : H12AffineEnvironment.transform 22 147457 env42419 = env42471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env42419 == env42471) = true)

def env42472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,2347268,8193,65,6453548,152832,2233681,43048,2102548,4371532,257,21793,46093,2175563]

theorem envBound42472 : H12AffineFastState.Bounded env42472 := by
  intro p hp
  have h : env42472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42471_42472 : H12AffineEnvironment.transform 23 2347268 env42471 = env42472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347268 env42471 == env42472) = true)

def env42473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147457,98644,8193,65,4204924,152832,17665,43048,148804,4371532,257,21793,46093,221723]

theorem envBound42473 : H12AffineFastState.Bounded env42473 := by
  intro p hp
  have h : env42473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42472_42473 : H12AffineEnvironment.transform 20 151632 env42472 = env42473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env42472 == env42473) = true)

def env42474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,32,147457,98644,8193,65,10588,152832,17665,43048,148804,177260,257,21793,46093,221723]

theorem envBound42474 : H12AffineFastState.Bounded env42474 := by
  intro p hp
  have h : env42474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42473_42474 : H12AffineEnvironment.transform 21 32 env42473 = env42474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env42473 == env42474) = true)

theorem identity42474 : scanCanonicalize (H12AffineFastState.compose env42474 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42474 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77898,32,73755,98644,8193,65,10588,79130,17665,43048,75102,119926,257,21793,46093,513]

theorem envBound42475 : H12AffineFastState.Bounded env42475 := by
  intro p hp
  have h : env42475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42474_42475 : H12AffineEnvironment.transform 16 90138 env42474 = env42475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42474 == env42475) = true)

theorem identity42475 : scanCanonicalize (H12AffineFastState.compose env42475 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42475 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,4160,32,17,41310,8193,65,10588,5392,17665,43048,1364,62588,257,21793,46093,513]

theorem envBound42476 : H12AffineFastState.Bounded env42476 := by
  intro p hp
  have h : env42476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42475_42476 : H12AffineEnvironment.transform 15 8202 env42475 = env42476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42475 == env42476) = true)

theorem identity42476 : scanCanonicalize (H12AffineFastState.compose env42476 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42476 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env42477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16400,2341,1025,32769,4160,32,17,32851,268,65,2129,5392,17665,35109,1364,54641,257,21793,38144,513]

theorem envBound42477 : H12AffineFastState.Bounded env42477 := by
  intro p hp
  have h : env42477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42476_42477 : H12AffineEnvironment.transform 12 269 env42476 = env42477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42476 == env42477) = true)

theorem identity42477 : scanCanonicalize (H12AffineFastState.compose env42477 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound42477 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,263,16400,2341,1025,21840,4160,32,17,21762,268,65,2129,5392,17665,23668,1364,32,257,21793,16465,513]

theorem envBound42478 : H12AffineFastState.Bounded env42478 := by
  intro p hp
  have h : env42478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42477_42478 : H12AffineEnvironment.transform 14 21841 env42477 = env42478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env42477 == env42478) = true)

theorem identity42478 : scanCanonicalize (H12AffineFastState.compose env42478 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42478 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,263,5440,2341,1025,0,4160,32,17,82,268,65,2129,5392,4177,2340,1364,32,257,113,5377,513]

theorem envBound42479 : H12AffineFastState.Bounded env42479 := by
  intro p hp
  have h : env42479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42478_42479 : H12AffineEnvironment.transform 13 5456 env42478 = env42479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42478 == env42479) = true)

theorem identity42479 : scanCanonicalize (H12AffineFastState.compose env42479 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 351) := by decide +kernel

theorem selectedBound42479 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42480 : List Nat := [2,4,8,16,32,64,9,256,351,1024,2048,4096,269,5456,1,263,5440,2341,1025,0,4160,32,17,82,268,65,2129,5392,4177,2340,1364,32,257,113,5377,350]

theorem envBound42480 : H12AffineFastState.Bounded env42480 := by
  intro p hp
  have h : env42480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42479_42480 : H12AffineEnvironment.transform 8 351 env42479 = env42480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 351 env42479 == env42480) = true)

theorem identity42480 : scanCanonicalize (H12AffineFastState.compose env42480 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42480 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42481 : List Nat := [2,4,8,16,32,17,9,256,270,1024,2048,4096,269,5377,1,263,5393,2341,1025,0,4113,32,17,3,268,16,2048,5392,4096,2340,1285,32,257,32,5377,271]

theorem envBound42481 : H12AffineFastState.Bounded env42481 := by
  intro p hp
  have h : env42481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42480_42481 : H12AffineEnvironment.transform 5 17 env42480 = env42481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42480 == env42481) = true)

theorem identity42481 : scanCanonicalize (H12AffineFastState.compose env42481 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound42481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42482 : List Nat := [2,4,8,16,32,17,9,256,270,1024,2048,32,269,1313,1,263,1329,2341,1025,0,49,32,17,3,268,16,2048,1328,32,2340,1285,32,257,32,1313,271]

theorem envBound42482 : H12AffineFastState.Bounded env42482 := by
  intro p hp
  have h : env42482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42481_42482 : H12AffineEnvironment.transform 11 32 env42481 = env42482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env42481 == env42482) = true)

theorem identity42482 : scanCanonicalize (H12AffineFastState.compose env42482 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1322) := by decide +kernel

theorem selectedBound42482 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42483 : List Nat := [2,4,8,16,32,17,9,256,270,1024,1322,32,269,1313,1,263,1329,1039,1025,0,49,32,17,3,268,16,1322,1328,32,1038,1285,32,257,32,1313,271]

theorem envBound42483 : H12AffineFastState.Bounded env42483 := by
  intro p hp
  have h : env42483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42482_42483 : H12AffineEnvironment.transform 10 1322 env42482 = env42483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1322 env42482 == env42483) = true)

theorem identity42483 : scanCanonicalize (H12AffineFastState.compose env42483 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound42483 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42484 : List Nat := [2,4,8,16,32,17,9,30,16,1024,1076,32,19,1087,1,25,1071,1039,1025,0,49,32,17,3,18,16,1076,1070,32,1038,1051,32,31,32,1087,17]

theorem envBound42484 : H12AffineFastState.Bounded env42484 := by
  intro p hp
  have h : env42484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42483_42484 : H12AffineEnvironment.transform 7 30 env42483 = env42484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env42483 == env42484) = true)

theorem identity42484 : scanCanonicalize (H12AffineFastState.compose env42484 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound42484 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42485 : List Nat := [2,4,8,16,32,17,9,30,16,47,27,32,19,16,1,25,0,32,46,0,49,32,17,3,18,16,27,1,32,33,52,32,31,32,16,17]

theorem envBound42485 : H12AffineFastState.Bounded env42485 := by
  intro p hp
  have h : env42485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42484_42485 : H12AffineEnvironment.transform 9 47 env42484 = env42485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env42484 == env42485) = true)

theorem identity42485 : scanCanonicalize (H12AffineFastState.compose env42485 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42485 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42486 : List Nat := [2,4,8,0,32,1,9,14,0,47,11,32,3,0,1,9,0,32,46,0,33,32,1,3,2,0,11,1,32,33,36,32,15,32,0,1]

theorem envBound42486 : H12AffineFastState.Bounded env42486 := by
  intro p hp
  have h : env42486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42485_42486 : H12AffineEnvironment.transform 3 0 env42485 = env42486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42485 == env42486) = true)

theorem identity42486 : scanCanonicalize (H12AffineFastState.compose env42486 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound42486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42487 : List Nat := [2,4,8,0,15,1,9,14,0,0,11,15,3,0,1,9,0,15,1,0,14,15,1,3,2,0,11,1,15,14,11,15,15,15,0,1]

theorem envBound42487 : H12AffineFastState.Bounded env42487 := by
  intro p hp
  have h : env42487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42486_42487 : H12AffineEnvironment.transform 4 15 env42486 = env42487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env42486 == env42487) = true)

theorem identity42487 : scanCanonicalize (H12AffineFastState.compose env42487 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42487 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env42488 : List Nat := [2,4,3,0,4,1,2,5,0,0,0,4,3,0,1,2,0,4,1,0,5,4,1,3,2,0,0,1,4,5,0,4,4,4,0,1]

theorem envBound42488 : H12AffineFastState.Bounded env42488 := by
  intro p hp
  have h : env42488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42487_42488 : H12AffineEnvironment.transform 2 3 env42487 = env42488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42487 == env42488) = true)

theorem identity42488 : scanCanonicalize (H12AffineFastState.compose env42488 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42488 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42489 : List Nat := [2,3,3,0,3,1,2,2,0,0,0,3,3,0,1,2,0,3,1,0,2,3,1,3,2,0,0,1,3,2,0,3,3,3,0,1]

theorem envBound42489 : H12AffineFastState.Bounded env42489 := by
  intro p hp
  have h : env42489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42488_42489 : H12AffineEnvironment.transform 1 3 env42488 = env42489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42488 == env42489) = true)

def env42490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,33,147457,98644,8193,65,10589,152832,17665,43048,148804,177261,257,21793,46093,221723]

theorem envBound42490 : H12AffineFastState.Bounded env42490 := by
  intro p hp
  have h : env42490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42473_42490 : H12AffineEnvironment.transform 21 33 env42473 = env42490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42473 == env42490) = true)

theorem identity42490 : scanCanonicalize (H12AffineFastState.compose env42490 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound42490 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,4160,33,17,98644,8193,65,10589,5392,17665,43048,1364,62589,257,21793,46093,74251]

theorem envBound42491 : H12AffineFastState.Bounded env42491 := by
  intro p hp
  have h : env42491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42490_42491 : H12AffineEnvironment.transform 16 16400 env42490 = env42491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42490 == env42491) = true)

theorem identity42491 : scanCanonicalize (H12AffineFastState.compose env42491 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound42491 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env42492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54278,16400,10280,1025,32769,4160,33,17,21842,8193,65,10589,5392,17665,43048,1364,62589,257,21793,46093,62989]

theorem envBound42492 : H12AffineFastState.Bounded env42492 := by
  intro p hp
  have h : env42492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42491_42492 : H12AffineEnvironment.transform 15 54278 env42491 = env42492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env42491 == env42492) = true)

theorem identity42492 : scanCanonicalize (H12AffineFastState.compose env42492 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42492 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env42493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54278,16400,2421,1025,32769,4160,33,17,21842,348,65,2048,5392,17665,35189,1364,54560,257,21793,38224,55120]

theorem envBound42493 : H12AffineFastState.Bounded env42493 := by
  intro p hp
  have h : env42493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42492_42493 : H12AffineEnvironment.transform 12 349 env42492 = env42493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42492 == env42493) = true)

theorem identity42493 : scanCanonicalize (H12AffineFastState.compose env42493 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42493 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,33110,5440,2421,1025,32769,4160,33,17,2,348,65,2048,5392,4177,35189,1364,32880,257,113,38224,33280]

theorem envBound42494 : H12AffineFastState.Bounded env42494 := by
  intro p hp
  have h : env42494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42493_42494 : H12AffineEnvironment.transform 13 5456 env42493 = env42494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42493 == env42494) = true)

theorem identity42494 : scanCanonicalize (H12AffineFastState.compose env42494 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound42494 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,263,5440,2421,1025,80,4160,33,17,2,348,65,2048,5392,4177,2340,1364,33,257,113,5377,593]

theorem envBound42495 : H12AffineFastState.Bounded env42495 := by
  intro p hp
  have h : env42495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42494_42495 : H12AffineEnvironment.transform 14 81 env42494 = env42495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env42494 == env42495) = true)

theorem identity42495 : scanCanonicalize (H12AffineFastState.compose env42495 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1339) := by decide +kernel

theorem selectedBound42495 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1339,4096,349,5456,81,263,5440,1102,1025,80,4160,33,17,2,348,65,1339,5392,4177,1055,1364,33,257,113,5377,593]

theorem envBound42496 : H12AffineFastState.Bounded env42496 := by
  intro p hp
  have h : env42496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42495_42496 : H12AffineEnvironment.transform 10 1339 env42495 = env42496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1339 env42495 == env42496) = true)

theorem identity42496 : scanCanonicalize (H12AffineFastState.compose env42496 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 286) := by decide +kernel

theorem selectedBound42496 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env42497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1339,286,349,1102,81,263,1118,1102,1025,80,350,33,17,2,348,65,1339,1038,335,1055,1364,33,257,113,1055,593]

theorem envBound42497 : H12AffineFastState.Bounded env42497 := by
  intro p hp
  have h : env42497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42496_42497 : H12AffineEnvironment.transform 11 286 env42496 = env42497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 286 env42496 == env42497) = true)

theorem identity42497 : scanCanonicalize (H12AffineFastState.compose env42497 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound42497 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env42498 : List Nat := [2,4,8,16,17,64,9,256,512,1024,1290,286,349,1102,81,263,1118,1102,1025,80,350,16,17,2,348,65,1290,1038,335,1055,1364,16,257,64,1055,593]

theorem envBound42498 : H12AffineFastState.Bounded env42498 := by
  intro p hp
  have h : env42498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42497_42498 : H12AffineEnvironment.transform 4 17 env42497 = env42498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env42497 == env42498) = true)

theorem identity42498 : scanCanonicalize (H12AffineFastState.compose env42498 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42498 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env42499 : List Nat := [2,4,8,16,17,64,9,5,512,1024,1039,27,88,1102,81,2,1118,1102,1025,80,91,16,17,2,89,65,1039,1038,74,1055,1105,16,4,64,1055,593]

theorem envBound42499 : H12AffineFastState.Bounded env42499 := by
  intro p hp
  have h : env42499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42498_42499 : H12AffineEnvironment.transform 7 5 env42498 = env42499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42498 == env42499) = true)

theorem identity42499 : scanCanonicalize (H12AffineFastState.compose env42499 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42499 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42500 : List Nat := [2,4,8,16,17,1,9,5,512,1024,1039,27,25,1039,16,2,1055,1039,1025,17,26,16,17,2,24,0,1039,1038,11,1055,1040,16,4,1,1055,528]

theorem envBound42500 : H12AffineFastState.Bounded env42500 := by
  intro p hp
  have h : env42500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42499_42500 : H12AffineEnvironment.transform 5 1 env42499 = env42500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42499 == env42500) = true)

theorem identity42500 : scanCanonicalize (H12AffineFastState.compose env42500 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42500 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42501 : List Nat := [2,4,8,0,1,1,9,5,512,1024,1039,11,9,1039,0,2,1039,1039,1025,1,10,0,1,2,8,0,1039,1038,11,1039,1024,0,4,1,1039,512]

theorem envBound42501 : H12AffineFastState.Bounded env42501 := by
  intro p hp
  have h : env42501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42500_42501 : H12AffineEnvironment.transform 3 0 env42500 = env42501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42500 == env42501) = true)

theorem identity42501 : scanCanonicalize (H12AffineFastState.compose env42501 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound42501 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42502 : List Nat := [2,4,8,0,1,1,9,5,512,14,1,11,9,1,0,2,1,1,15,1,10,0,1,2,8,0,1,0,11,1,14,0,4,1,1,512]

theorem envBound42502 : H12AffineFastState.Bounded env42502 := by
  intro p hp
  have h : env42502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42501_42502 : H12AffineEnvironment.transform 9 14 env42501 = env42502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env42501 == env42502) = true)

theorem identity42502 : scanCanonicalize (H12AffineFastState.compose env42502 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound42502 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42503 : List Nat := [2,4,8,0,1,1,9,5,14,14,1,11,9,1,0,2,1,1,15,1,10,0,1,2,8,0,1,0,11,1,14,0,4,1,1,14]

theorem envBound42503 : H12AffineFastState.Bounded env42503 := by
  intro p hp
  have h : env42503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42502_42503 : H12AffineEnvironment.transform 8 14 env42502 = env42503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env42502 == env42503) = true)

theorem identity42503 : scanCanonicalize (H12AffineFastState.compose env42503 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound42503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42504 : List Nat := [2,4,7,0,1,1,6,5,1,1,1,4,6,1,0,2,1,1,0,1,5,0,1,2,7,0,1,0,4,1,1,0,4,1,1,1]

theorem envBound42504 : H12AffineFastState.Bounded env42504 := by
  intro p hp
  have h : env42504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42503_42504 : H12AffineEnvironment.transform 2 7 env42503 = env42504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env42503 == env42504) = true)

theorem identity42504 : scanCanonicalize (H12AffineFastState.compose env42504 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42505 : List Nat := [0,4,5,0,1,1,4,5,1,1,1,4,4,1,0,0,1,1,0,1,5,0,1,0,5,0,1,0,4,1,1,0,4,1,1,1]

theorem envBound42505 : H12AffineFastState.Bounded env42505 := by
  intro p hp
  have h : env42505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42504_42505 : H12AffineEnvironment.transform 0 0 env42504 = env42505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42504 == env42505) = true)

theorem identity42505 : scanCanonicalize (H12AffineFastState.compose env42505 (packedSelected [14] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42505 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env42506 : List Nat := [0,1,0,0,1,1,1,0,1,1,1,1,1,1,0,0,1,1,0,1,0,0,1,0,0,0,1,0,1,1,1,0,1,1,1,1]

theorem envBound42506 : H12AffineFastState.Bounded env42506 := by
  intro p hp
  have h : env42506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42505_42506 : H12AffineEnvironment.transform 1 1 env42505 = env42506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42505 == env42506) = true)

def env42507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147457,98645,8193,65,4204925,152832,17664,43048,148805,4371532,257,21793,46093,221722]

theorem envBound42507 : H12AffineFastState.Bounded env42507 := by
  intro p hp
  have h : env42507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42472_42507 : H12AffineEnvironment.transform 20 151633 env42472 = env42507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env42472 == env42507) = true)

theorem identity42507 : scanCanonicalize (H12AffineFastState.compose env42507 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42507 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env42508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77898,4194304,73754,98645,8193,65,4204925,79131,17664,43048,75102,4314199,257,21793,46093,513]

theorem envBound42508 : H12AffineFastState.Bounded env42508 := by
  intro p hp
  have h : env42508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42507_42508 : H12AffineEnvironment.transform 16 90139 env42507 = env42508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42507 == env42508) = true)

theorem identity42508 : scanCanonicalize (H12AffineFastState.compose env42508 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound42508 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77898,4194304,73754,95496,8193,65,4204925,79131,17664,23669,75102,4268042,257,21793,16464,513]

theorem envBound42509 : H12AffineFastState.Bounded env42509 := by
  intro p hp
  have h : env42509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42508_42509 : H12AffineEnvironment.transform 14 29789 env42508 = env42509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42508 == env42509) = true)

def env42510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77898,32,73754,95496,8193,65,10589,79131,17664,23669,75102,73770,257,21793,16464,513]

theorem envBound42510 : H12AffineFastState.Bounded env42510 := by
  intro p hp
  have h : env42510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42509_42510 : H12AffineEnvironment.transform 21 32 env42509 = env42510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env42509 == env42510) = true)

theorem identity42510 : scanCanonicalize (H12AffineFastState.compose env42510 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound42510 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8283,16448,10280,1025,29788,4113,32,65,21843,8193,65,10589,5440,17664,23669,1285,113,257,21793,16464,513]

theorem envBound42511 : H12AffineFastState.Bounded env42511 := by
  intro p hp
  have h : env42511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42510_42511 : H12AffineEnvironment.transform 15 8283 env42510 = env42511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env42510 == env42511) = true)

theorem identity42511 : scanCanonicalize (H12AffineFastState.compose env42511 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42511 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,342,16448,2341,1025,21841,4113,32,65,21843,268,65,2128,5440,17664,23669,1285,113,257,21793,16464,513]

theorem envBound42512 : H12AffineFastState.Bounded env42512 := by
  intro p hp
  have h : env42512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42511_42512 : H12AffineEnvironment.transform 12 269 env42511 = env42512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42511 == env42512) = true)

theorem identity42512 : scanCanonicalize (H12AffineFastState.compose env42512 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound42512 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,1,342,5393,2341,1025,0,4113,32,65,2,268,65,2128,5440,4177,2340,1285,113,257,112,5377,513]

theorem envBound42513 : H12AffineFastState.Bounded env42513 := by
  intro p hp
  have h : env42513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42512_42513 : H12AffineEnvironment.transform 13 5457 env42512 = env42513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env42512 == env42513) = true)

theorem identity42513 : scanCanonicalize (H12AffineFastState.compose env42513 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound42513 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,512,269,1873,1,342,1809,2341,1025,0,529,32,65,2,268,65,2128,1856,593,2340,1285,113,257,112,1793,513]

theorem envBound42514 : H12AffineFastState.Bounded env42514 := by
  intro p hp
  have h : env42514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42513_42514 : H12AffineEnvironment.transform 11 512 env42513 = env42514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env42513 == env42514) = true)

def env42515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77898,33,73754,95496,8193,65,10588,79131,17664,23669,75102,73771,257,21793,16464,513]

theorem envBound42515 : H12AffineFastState.Bounded env42515 := by
  intro p hp
  have h : env42515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42509_42515 : H12AffineEnvironment.transform 21 33 env42509 = env42515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42509 == env42515) = true)

theorem identity42515 : scanCanonicalize (H12AffineFastState.compose env42515 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound42515 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21510,13341,10280,1025,29788,25676,33,29724,8462,8193,65,10588,24861,17664,23669,29016,29741,257,21793,16464,513]

theorem envBound42516 : H12AffineFastState.Bounded env42516 := by
  intro p hp
  have h : env42516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42515_42516 : H12AffineEnvironment.transform 15 21510 env42515 = env42516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env42515 == env42516) = true)

theorem identity42516 : scanCanonicalize (H12AffineFastState.compose env42516 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound42516 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,8203,13341,10280,1025,81,4161,33,17,8462,8193,65,10588,5392,12557,10360,1365,32,257,8492,13405,513]

theorem envBound42517 : H12AffineFastState.Bounded env42517 := by
  intro p hp
  have h : env42517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42516_42517 : H12AffineEnvironment.transform 13 13325 env42516 = env42517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env42516 == env42517) = true)

theorem identity42517 : scanCanonicalize (H12AffineFastState.compose env42517 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42517 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,342,5440,2421,1025,81,4161,33,17,83,348,65,2049,5392,4176,2341,1365,32,257,113,5376,513]

theorem envBound42518 : H12AffineFastState.Bounded env42518 := by
  intro p hp
  have h : env42518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42517_42518 : H12AffineEnvironment.transform 12 349 env42517 = env42518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42517 == env42518) = true)

theorem identity42518 : scanCanonicalize (H12AffineFastState.compose env42518 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42518 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42519 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1025,0,4112,33,17,2,269,16,2049,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound42519 : H12AffineFastState.Bounded env42519 := by
  intro p hp
  have h : env42519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42518_42519 : H12AffineEnvironment.transform 5 17 env42518 = env42519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42518 == env42519) = true)

theorem identity42519 : scanCanonicalize (H12AffineFastState.compose env42519 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound42519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42520 : List Nat := [2,4,8,16,32,17,9,256,512,288,2048,4096,268,4129,1,263,4145,2340,289,0,4112,33,17,2,269,16,2049,4144,4097,2341,36,32,257,32,4128,513]

theorem envBound42520 : H12AffineFastState.Bounded env42520 := by
  intro p hp
  have h : env42520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42519_42520 : H12AffineEnvironment.transform 9 288 env42519 = env42520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env42519 == env42520) = true)

theorem identity42520 : scanCanonicalize (H12AffineFastState.compose env42520 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound42520 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42521 : List Nat := [2,4,8,16,32,17,9,256,293,288,2048,4096,268,4129,1,263,4145,2340,289,0,4112,33,17,2,269,16,2049,4144,4097,2341,36,32,257,32,4128,292]

theorem envBound42521 : H12AffineFastState.Bounded env42521 := by
  intro p hp
  have h : env42521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42520_42521 : H12AffineEnvironment.transform 8 293 env42520 = env42521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env42520 == env42521) = true)

theorem identity42521 : scanCanonicalize (H12AffineFastState.compose env42521 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound42521 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42522 : List Nat := [2,4,8,16,32,17,9,256,293,288,2048,2081,268,2048,1,263,2064,2340,289,0,2097,33,17,2,269,16,2049,2065,2080,2341,36,32,257,32,2049,292]

theorem envBound42522 : H12AffineFastState.Bounded env42522 := by
  intro p hp
  have h : env42522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42521_42522 : H12AffineEnvironment.transform 11 2081 env42521 = env42522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env42521 == env42522) = true)

theorem identity42522 : scanCanonicalize (H12AffineFastState.compose env42522 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42522 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42523 : List Nat := [2,4,8,16,1,17,9,256,260,257,2048,2048,268,2048,1,263,2064,2309,256,0,2064,0,17,2,269,16,2049,2065,2049,2308,5,1,257,1,2049,261]

theorem envBound42523 : H12AffineFastState.Bounded env42523 := by
  intro p hp
  have h : env42523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42522_42523 : H12AffineEnvironment.transform 4 1 env42522 = env42523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42522 == env42523) = true)

theorem identity42523 : scanCanonicalize (H12AffineFastState.compose env42523 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound42523 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42524 : List Nat := [2,4,8,16,1,17,9,256,260,257,17,17,268,17,1,263,1,276,256,0,1,0,17,2,269,16,16,0,16,277,5,1,257,1,16,261]

theorem envBound42524 : H12AffineFastState.Bounded env42524 := by
  intro p hp
  have h : env42524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42523_42524 : H12AffineEnvironment.transform 10 17 env42523 = env42524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env42523 == env42524) = true)

theorem identity42524 : scanCanonicalize (H12AffineFastState.compose env42524 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42525 : List Nat := [2,4,8,16,1,17,9,21,17,20,17,17,25,17,1,18,1,1,21,0,1,0,17,2,24,16,16,0,16,0,5,1,20,1,16,16]

theorem envBound42525 : H12AffineFastState.Bounded env42525 := by
  intro p hp
  have h : env42525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42524_42525 : H12AffineEnvironment.transform 7 21 env42524 = env42525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42524 == env42525) = true)

def env42526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,2347269,8193,65,6453549,152833,2233681,43048,2102549,4371533,257,21792,46092,2175562]

theorem envBound42526 : H12AffineFastState.Bounded env42526 := by
  intro p hp
  have h : env42526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42471_42526 : H12AffineEnvironment.transform 23 2347269 env42471 = env42526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347269 env42471 == env42526) = true)

def env42527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147457,98645,8193,65,4204925,152833,17665,43048,148805,4371533,257,21792,46092,221722]

theorem envBound42527 : H12AffineFastState.Bounded env42527 := by
  intro p hp
  have h : env42527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42526_42527 : H12AffineEnvironment.transform 20 151632 env42526 = env42527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env42526 == env42527) = true)

theorem identity42527 : scanCanonicalize (H12AffineFastState.compose env42527 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42527 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env42528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77899,4194304,73754,98645,8193,65,4204925,79130,17665,43048,75102,4314198,257,21792,46092,513]

theorem envBound42528 : H12AffineFastState.Bounded env42528 := by
  intro p hp
  have h : env42528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42527_42528 : H12AffineEnvironment.transform 16 90139 env42527 = env42528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42527 == env42528) = true)

theorem identity42528 : scanCanonicalize (H12AffineFastState.compose env42528 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound42528 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,4194304,73754,95497,8193,65,4204925,79130,17665,23668,75102,4268042,257,21792,16464,513]

theorem envBound42529 : H12AffineFastState.Bounded env42529 := by
  intro p hp
  have h : env42529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42528_42529 : H12AffineEnvironment.transform 14 29788 env42528 = env42529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env42528 == env42529) = true)

def env42530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,32,73754,95497,8193,65,10589,79130,17665,23668,75102,73770,257,21792,16464,513]

theorem envBound42530 : H12AffineFastState.Bounded env42530 := by
  intro p hp
  have h : env42530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42529_42530 : H12AffineEnvironment.transform 21 32 env42529 = env42530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env42529 == env42530) = true)

theorem identity42530 : scanCanonicalize (H12AffineFastState.compose env42530 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound42530 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8283,16448,10280,1025,29789,4112,32,65,21842,8193,65,10589,5441,17665,23668,1285,113,257,21792,16464,513]

theorem envBound42531 : H12AffineFastState.Bounded env42531 := by
  intro p hp
  have h : env42531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42530_42531 : H12AffineEnvironment.transform 15 8283 env42530 = env42531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env42530 == env42531) = true)

theorem identity42531 : scanCanonicalize (H12AffineFastState.compose env42531 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42531 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,342,16448,2341,1025,21840,4112,32,65,21842,268,65,2128,5441,17665,23668,1285,113,257,21792,16464,513]

theorem envBound42532 : H12AffineFastState.Bounded env42532 := by
  intro p hp
  have h : env42532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42531_42532 : H12AffineEnvironment.transform 12 269 env42531 = env42532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42531 == env42532) = true)

theorem identity42532 : scanCanonicalize (H12AffineFastState.compose env42532 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42532 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,342,5392,2341,1025,0,4112,32,65,2,268,65,2128,5441,4177,2340,1285,113,257,112,5376,513]

theorem envBound42533 : H12AffineFastState.Bounded env42533 := by
  intro p hp
  have h : env42533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42532_42533 : H12AffineEnvironment.transform 13 5456 env42532 = env42533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42532 == env42533) = true)

theorem identity42533 : scanCanonicalize (H12AffineFastState.compose env42533 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound42533 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,512,269,1872,1,342,1808,2341,1025,0,528,32,65,2,268,65,2128,1857,593,2340,1285,113,257,112,1792,513]

theorem envBound42534 : H12AffineFastState.Bounded env42534 := by
  intro p hp
  have h : env42534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42533_42534 : H12AffineEnvironment.transform 11 512 env42533 = env42534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env42533 == env42534) = true)

def env42535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77899,33,73754,95497,8193,65,10588,79130,17665,23668,75102,73771,257,21792,16464,513]

theorem envBound42535 : H12AffineFastState.Bounded env42535 := by
  intro p hp
  have h : env42535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42529_42535 : H12AffineEnvironment.transform 21 33 env42529 = env42535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42529 == env42535) = true)

theorem identity42535 : scanCanonicalize (H12AffineFastState.compose env42535 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound42535 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21511,13340,10280,1025,29789,25676,33,29725,8462,8193,65,10588,24861,17665,23668,29017,29740,257,21792,16464,513]

theorem envBound42536 : H12AffineFastState.Bounded env42536 := by
  intro p hp
  have h : env42536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42535_42536 : H12AffineEnvironment.transform 15 21511 env42535 = env42536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env42535 == env42536) = true)

theorem identity42536 : scanCanonicalize (H12AffineFastState.compose env42536 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound42536 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8203,13340,10280,1025,81,4160,33,17,8462,8193,65,10588,5393,12557,10360,1365,32,257,8492,13404,513]

theorem envBound42537 : H12AffineFastState.Bounded env42537 := by
  intro p hp
  have h : env42537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42536_42537 : H12AffineEnvironment.transform 13 13324 env42536 = env42537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env42536 == env42537) = true)

theorem identity42537 : scanCanonicalize (H12AffineFastState.compose env42537 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42537 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,80,342,5441,2421,1025,81,4160,33,17,83,348,65,2049,5393,4176,2341,1365,32,257,113,5377,513]

theorem envBound42538 : H12AffineFastState.Bounded env42538 := by
  intro p hp
  have h : env42538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42537_42538 : H12AffineEnvironment.transform 12 349 env42537 = env42538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42537 == env42538) = true)

theorem identity42538 : scanCanonicalize (H12AffineFastState.compose env42538 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42538 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42539 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2340,1025,0,4113,33,17,2,269,16,2049,5393,4097,2341,1284,32,257,32,5377,513]

theorem envBound42539 : H12AffineFastState.Bounded env42539 := by
  intro p hp
  have h : env42539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42538_42539 : H12AffineEnvironment.transform 5 17 env42538 = env42539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42538 == env42539) = true)

theorem identity42539 : scanCanonicalize (H12AffineFastState.compose env42539 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound42539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42540 : List Nat := [2,4,8,16,32,17,9,256,512,289,2048,4096,268,4129,1,263,4145,2340,288,0,4113,33,17,2,269,16,2049,4144,4097,2341,37,32,257,32,4128,513]

theorem envBound42540 : H12AffineFastState.Bounded env42540 := by
  intro p hp
  have h : env42540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42539_42540 : H12AffineEnvironment.transform 9 289 env42539 = env42540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env42539 == env42540) = true)

theorem identity42540 : scanCanonicalize (H12AffineFastState.compose env42540 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound42540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42541 : List Nat := [2,4,8,16,32,17,9,256,293,289,2048,4096,268,4129,1,263,4145,2340,288,0,4113,33,17,2,269,16,2049,4144,4097,2341,37,32,257,32,4128,292]

theorem envBound42541 : H12AffineFastState.Bounded env42541 := by
  intro p hp
  have h : env42541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42540_42541 : H12AffineEnvironment.transform 8 293 env42540 = env42541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env42540 == env42541) = true)

theorem identity42541 : scanCanonicalize (H12AffineFastState.compose env42541 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound42541 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42542 : List Nat := [2,4,8,16,32,17,9,256,293,289,2048,2080,268,2049,1,263,2065,2340,288,0,2097,33,17,2,269,16,2049,2064,2081,2341,37,32,257,32,2048,292]

theorem envBound42542 : H12AffineFastState.Bounded env42542 := by
  intro p hp
  have h : env42542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42541_42542 : H12AffineEnvironment.transform 11 2080 env42541 = env42542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env42541 == env42542) = true)

theorem identity42542 : scanCanonicalize (H12AffineFastState.compose env42542 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42542 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42543 : List Nat := [2,4,8,16,1,17,9,256,260,256,2048,2049,268,2049,1,263,2065,2309,257,0,2064,0,17,2,269,16,2049,2064,2048,2308,4,1,257,1,2048,261]

theorem envBound42543 : H12AffineFastState.Bounded env42543 := by
  intro p hp
  have h : env42543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42542_42543 : H12AffineEnvironment.transform 4 1 env42542 = env42543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42542 == env42543) = true)

theorem identity42543 : scanCanonicalize (H12AffineFastState.compose env42543 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound42543 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42544 : List Nat := [2,4,8,16,1,17,9,256,260,256,17,16,268,16,1,263,0,276,257,0,1,0,17,2,269,16,16,1,17,277,4,1,257,1,17,261]

theorem envBound42544 : H12AffineFastState.Bounded env42544 := by
  intro p hp
  have h : env42544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42543_42544 : H12AffineEnvironment.transform 10 17 env42543 = env42544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env42543 == env42544) = true)

theorem identity42544 : scanCanonicalize (H12AffineFastState.compose env42544 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42545 : List Nat := [2,4,8,16,1,17,9,20,16,20,17,16,24,16,1,19,0,0,21,0,1,0,17,2,25,16,16,1,17,1,4,1,21,1,17,17]

theorem envBound42545 : H12AffineFastState.Bounded env42545 := by
  intro p hp
  have h : env42545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42544_42545 : H12AffineEnvironment.transform 7 20 env42544 = env42545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42544 == env42545) = true)

def env42546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147457,98644,8193,65,4204924,152833,17664,43048,148804,4371533,257,21792,46092,221723]

theorem envBound42546 : H12AffineFastState.Bounded env42546 := by
  intro p hp
  have h : env42546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42526_42546 : H12AffineEnvironment.transform 20 151633 env42526 = env42546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env42526 == env42546) = true)

def env42547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,32,147457,98644,8193,65,10588,152833,17664,43048,148804,177261,257,21792,46092,221723]

theorem envBound42547 : H12AffineFastState.Bounded env42547 := by
  intro p hp
  have h : env42547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42546_42547 : H12AffineEnvironment.transform 21 32 env42546 = env42547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env42546 == env42547) = true)

theorem identity42547 : scanCanonicalize (H12AffineFastState.compose env42547 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42547 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77899,32,73755,98644,8193,65,10588,79131,17664,43048,75102,119927,257,21792,46092,513]

theorem envBound42548 : H12AffineFastState.Bounded env42548 := by
  intro p hp
  have h : env42548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42547_42548 : H12AffineEnvironment.transform 16 90138 env42547 = env42548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42547 == env42548) = true)

theorem identity42548 : scanCanonicalize (H12AffineFastState.compose env42548 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42548 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,4161,32,17,41310,8193,65,10588,5393,17664,43048,1364,62589,257,21792,46092,513]

theorem envBound42549 : H12AffineFastState.Bounded env42549 := by
  intro p hp
  have h : env42549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42548_42549 : H12AffineEnvironment.transform 15 8202 env42548 = env42549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42548 == env42549) = true)

theorem identity42549 : scanCanonicalize (H12AffineFastState.compose env42549 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42549 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env42550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16400,2341,1025,32769,4161,32,17,32851,268,65,2129,5393,17664,35109,1364,54640,257,21792,38145,513]

theorem envBound42550 : H12AffineFastState.Bounded env42550 := by
  intro p hp
  have h : env42550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42549_42550 : H12AffineEnvironment.transform 12 269 env42549 = env42550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42549 == env42550) = true)

theorem identity42550 : scanCanonicalize (H12AffineFastState.compose env42550 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound42550 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,263,16400,2341,1025,21841,4161,32,17,21763,268,65,2129,5393,17664,23669,1364,32,257,21792,16465,513]

theorem envBound42551 : H12AffineFastState.Bounded env42551 := by
  intro p hp
  have h : env42551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42550_42551 : H12AffineEnvironment.transform 14 21840 env42550 = env42551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env42550 == env42551) = true)

theorem identity42551 : scanCanonicalize (H12AffineFastState.compose env42551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound42551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,1,263,5441,2341,1025,0,4161,32,17,82,268,65,2129,5393,4177,2340,1364,32,257,113,5376,513]

theorem envBound42552 : H12AffineFastState.Bounded env42552 := by
  intro p hp
  have h : env42552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42551_42552 : H12AffineEnvironment.transform 13 5457 env42551 = env42552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env42551 == env42552) = true)

theorem identity42552 : scanCanonicalize (H12AffineFastState.compose env42552 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound42552 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42553 : List Nat := [2,4,8,16,32,64,9,256,271,1024,2048,4096,269,5457,1,263,5441,2341,1025,0,4161,32,17,82,268,65,2129,5393,4177,2340,1364,32,257,113,5376,270]

theorem envBound42553 : H12AffineFastState.Bounded env42553 := by
  intro p hp
  have h : env42553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42552_42553 : H12AffineEnvironment.transform 8 271 env42552 = env42553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env42552 == env42553) = true)

theorem identity42553 : scanCanonicalize (H12AffineFastState.compose env42553 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42553 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42554 : List Nat := [2,4,8,16,32,17,9,256,271,1024,2048,4096,269,5376,1,263,5392,2341,1025,0,4112,32,17,3,268,16,2048,5393,4096,2340,1285,32,257,32,5376,270]

theorem envBound42554 : H12AffineFastState.Bounded env42554 := by
  intro p hp
  have h : env42554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42553_42554 : H12AffineEnvironment.transform 5 17 env42553 = env42554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42553 == env42554) = true)

theorem identity42554 : scanCanonicalize (H12AffineFastState.compose env42554 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound42554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42555 : List Nat := [2,4,8,16,32,17,9,256,271,1024,2048,32,269,1312,1,263,1328,2341,1025,0,48,32,17,3,268,16,2048,1329,32,2340,1285,32,257,32,1312,270]

theorem envBound42555 : H12AffineFastState.Bounded env42555 := by
  intro p hp
  have h : env42555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42554_42555 : H12AffineEnvironment.transform 11 32 env42554 = env42555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env42554 == env42555) = true)

theorem identity42555 : scanCanonicalize (H12AffineFastState.compose env42555 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1322) := by decide +kernel

theorem selectedBound42555 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42556 : List Nat := [2,4,8,16,32,17,9,256,271,1024,1322,32,269,1312,1,263,1328,1039,1025,0,48,32,17,3,268,16,1322,1329,32,1038,1285,32,257,32,1312,270]

theorem envBound42556 : H12AffineFastState.Bounded env42556 := by
  intro p hp
  have h : env42556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42555_42556 : H12AffineEnvironment.transform 10 1322 env42555 = env42556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1322 env42555 == env42556) = true)

theorem identity42556 : scanCanonicalize (H12AffineFastState.compose env42556 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound42556 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42557 : List Nat := [2,4,8,16,32,17,9,31,16,1024,1077,32,18,1087,1,24,1071,1039,1025,0,48,32,17,3,19,16,1077,1070,32,1038,1050,32,30,32,1087,17]

theorem envBound42557 : H12AffineFastState.Bounded env42557 := by
  intro p hp
  have h : env42557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42556_42557 : H12AffineEnvironment.transform 7 31 env42556 = env42557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env42556 == env42557) = true)

theorem identity42557 : scanCanonicalize (H12AffineFastState.compose env42557 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound42557 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42558 : List Nat := [2,4,8,16,32,17,9,31,16,46,27,32,18,17,1,24,1,33,47,0,48,32,17,3,19,16,27,0,32,32,52,32,30,32,17,17]

theorem envBound42558 : H12AffineFastState.Bounded env42558 := by
  intro p hp
  have h : env42558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42557_42558 : H12AffineEnvironment.transform 9 46 env42557 = env42558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env42557 == env42558) = true)

theorem identity42558 : scanCanonicalize (H12AffineFastState.compose env42558 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42558 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42559 : List Nat := [2,4,8,1,32,0,9,14,1,46,10,32,3,0,1,9,1,33,47,0,33,32,0,3,2,1,10,0,32,32,37,32,15,32,0,0]

theorem envBound42559 : H12AffineFastState.Bounded env42559 := by
  intro p hp
  have h : env42559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42558_42559 : H12AffineEnvironment.transform 3 1 env42558 = env42559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42558 == env42559) = true)

theorem identity42559 : scanCanonicalize (H12AffineFastState.compose env42559 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound42559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42560 : List Nat := [2,4,8,1,4,0,9,14,1,10,10,4,3,0,1,9,1,5,11,0,5,4,0,3,2,1,10,0,4,4,1,4,15,4,0,0]

theorem envBound42560 : H12AffineFastState.Bounded env42560 := by
  intro p hp
  have h : env42560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42559_42560 : H12AffineEnvironment.transform 4 4 env42559 = env42560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env42559 == env42560) = true)

theorem identity42560 : scanCanonicalize (H12AffineFastState.compose env42560 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42560 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env42561 : List Nat := [2,4,2,1,4,0,3,4,1,0,0,4,3,0,1,3,1,5,1,0,5,4,0,3,2,1,0,0,4,4,1,4,5,4,0,0]

theorem envBound42561 : H12AffineFastState.Bounded env42561 := by
  intro p hp
  have h : env42561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42560_42561 : H12AffineEnvironment.transform 2 2 env42560 = env42561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42560 == env42561) = true)

theorem identity42561 : scanCanonicalize (H12AffineFastState.compose env42561 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42562 : List Nat := [2,2,2,1,2,0,3,2,1,0,0,2,3,0,1,3,1,3,1,0,3,2,0,3,2,1,0,0,2,2,1,2,3,2,0,0]

theorem envBound42562 : H12AffineFastState.Bounded env42562 := by
  intro p hp
  have h : env42562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42561_42562 : H12AffineEnvironment.transform 1 2 env42561 = env42562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42561 == env42562) = true)

def env42563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,33,147457,98644,8193,65,10589,152833,17664,43048,148804,177260,257,21792,46092,221723]

theorem envBound42563 : H12AffineFastState.Bounded env42563 := by
  intro p hp
  have h : env42563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42546_42563 : H12AffineEnvironment.transform 21 33 env42546 = env42563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42546 == env42563) = true)

theorem identity42563 : scanCanonicalize (H12AffineFastState.compose env42563 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42563 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,151633,33,147457,41310,8193,65,10589,152833,17664,43048,148804,177260,257,21792,46092,147985]

theorem envBound42564 : H12AffineFastState.Bounded env42564 := by
  intro p hp
  have h : env42564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42563_42564 : H12AffineEnvironment.transform 15 8202 env42563 = env42564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42563 == env42564) = true)

theorem identity42564 : scanCanonicalize (H12AffineFastState.compose env42564 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound42564 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env42565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24860,10280,1025,32769,12621,33,8477,41310,8193,65,10589,13341,17664,43048,9304,54640,257,21792,46092,8973]

theorem envBound42565 : H12AffineFastState.Bounded env42565 := by
  intro p hp
  have h : env42565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42564_42565 : H12AffineEnvironment.transform 16 24860 env42564 = env42565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env42564 == env42565) = true)

theorem identity42565 : scanCanonicalize (H12AffineFastState.compose env42565 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42565 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env42566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24860,10280,1025,8540,12621,33,8477,3,8193,65,10589,13341,17664,2421,9304,29741,257,21792,5457,8973]

theorem envBound42566 : H12AffineFastState.Bounded env42566 := by
  intro p hp
  have h : env42566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42565_42566 : H12AffineEnvironment.transform 14 8541 env42565 = env42566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42565 == env42566) = true)

theorem identity42566 : scanCanonicalize (H12AffineFastState.compose env42566 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound42566 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env42567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8541,8202,5393,10280,1025,8540,12621,33,8477,3,8193,65,10589,13341,12557,2421,9304,32,257,8493,5457,8973]

theorem envBound42567 : H12AffineFastState.Bounded env42567 := by
  intro p hp
  have h : env42567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42566_42567 : H12AffineEnvironment.transform 13 13325 env42566 = env42567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env42566 == env42567) = true)

theorem identity42567 : scanCanonicalize (H12AffineFastState.compose env42567 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42567 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42568 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8461,8202,5393,10280,1025,8460,12573,33,8477,3,8193,17,10509,13341,12557,2341,9224,32,257,8493,5377,8973]

theorem envBound42568 : H12AffineFastState.Bounded env42568 := by
  intro p hp
  have h : env42568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42567_42568 : H12AffineEnvironment.transform 5 16 env42567 = env42568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42567 == env42568) = true)

theorem identity42568 : scanCanonicalize (H12AffineFastState.compose env42568 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound42568 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42569 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1337,4404,1076,1331,5393,3345,1025,1077,5156,33,1060,3,1336,17,3124,4388,5172,2341,305,32,257,1044,5377,1588]

theorem envBound42569 : H12AffineFastState.Bounded env42569 := by
  intro p hp
  have h : env42569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42568_42569 : H12AffineEnvironment.transform 12 1337 env42568 = env42569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env42568 == env42569) = true)

theorem identity42569 : scanCanonicalize (H12AffineFastState.compose env42569 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42569 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env42570 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,1053,4112,1076,1047,5173,3125,1025,1077,5156,33,1060,3,1052,17,3124,4096,5172,2049,21,32,37,1044,5157,1588]

theorem envBound42570 : H12AffineFastState.Bounded env42570 := by
  intro p hp
  have h : env42570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42569_42570 : H12AffineEnvironment.transform 7 36 env42569 = env42570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42569 == env42570) = true)

theorem identity42570 : scanCanonicalize (H12AffineFastState.compose env42570 (packedSelected [2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 3104) := by decide +kernel

theorem selectedBound42570 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env42571 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,3104,1053,3120,1076,1047,2069,3125,1025,1077,2052,33,1060,3,1052,17,3124,3104,2068,2049,21,32,37,1044,2053,1588]

theorem envBound42571 : H12AffineFastState.Bounded env42571 := by
  intro p hp
  have h : env42571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42570_42571 : H12AffineEnvironment.transform 11 3104 env42570 = env42571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3104 env42570 == env42571) = true)

theorem identity42571 : scanCanonicalize (H12AffineFastState.compose env42571 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1081) := by decide +kernel

theorem selectedBound42571 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42572 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1081,25,1053,9,1076,1047,1068,12,1025,1077,1085,33,1060,3,1052,17,13,25,1069,1080,21,32,37,1044,1084,1588]

theorem envBound42572 : H12AffineFastState.Bounded env42572 := by
  intro p hp
  have h : env42572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42571_42572 : H12AffineEnvironment.transform 10 1081 env42571 = env42572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1081 env42571 == env42572) = true)

theorem identity42572 : scanCanonicalize (H12AffineFastState.compose env42572 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42572 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env42573 : List Nat := [2,4,8,16,32,16,9,36,512,53,12,25,40,9,1,34,25,12,52,0,8,33,17,3,41,17,13,25,24,13,21,32,37,33,9,513]

theorem envBound42573 : H12AffineFastState.Bounded env42573 := by
  intro p hp
  have h : env42573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42572_42573 : H12AffineEnvironment.transform 9 53 env42572 = env42573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42572 == env42573) = true)

theorem identity42573 : scanCanonicalize (H12AffineFastState.compose env42573 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound42573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42574 : List Nat := [2,4,8,16,5,16,9,1,512,16,12,25,13,9,1,7,25,12,17,0,8,4,17,3,12,17,13,25,24,13,21,5,0,4,9,513]

theorem envBound42574 : H12AffineFastState.Bounded env42574 := by
  intro p hp
  have h : env42574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42573_42574 : H12AffineEnvironment.transform 4 5 env42573 = env42574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env42573 == env42574) = true)

def env42575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound42575 : H12AffineFastState.Bounded env42575 := by
  intro p hp
  have h : env42575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42187_42575 : H12AffineEnvironment.transform 26 30393345 env42187 = env42575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env42187 == env42575) = true)

def env42576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound42576 : H12AffineFastState.Bounded env42576 := by
  intro p hp
  have h : env42576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42575_42576 : H12AffineEnvironment.transform 18 1024 env42575 = env42576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env42575 == env42576) = true)

theorem identity42576 : scanCanonicalize (H12AffineFastState.compose env42576 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534761) := by decide +kernel

theorem selectedBound42576 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534761,16777216,8328,65,23162216,18973836,456761,2125160,19343736,23160256,256,17263044,17270881,19271343]

theorem envBound42577 : H12AffineFastState.Bounded env42577 := by
  intro p hp
  have h : env42577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42576_42577 : H12AffineEnvironment.transform 22 2534761 env42576 = env42577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534761 env42576 == env42577) = true)

def env42578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534761,474340,8328,65,6705548,2537576,456761,2125160,2102684,6707492,256,21792,46213,2175563]

theorem envBound42578 : H12AffineFastState.Bounded env42578 := by
  intro p hp
  have h : env42578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42577_42578 : H12AffineEnvironment.transform 23 474340 env42577 = env42578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474340 env42577 == env42578) = true)

def env42579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101329,98780,8328,65,6352052,2098512,17665,2125160,2102684,6349852,256,21792,46213,2175563]

theorem envBound42579 : H12AffineFastState.Bounded env42579 := by
  intro p hp
  have h : env42579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42578_42579 : H12AffineEnvironment.transform 17 179512 env42578 = env42579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env42578 == env42579) = true)

def env42580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,17,98780,8328,65,4259060,5392,17665,32040,1500,4256860,256,21792,46213,74251]

theorem envBound42580 : H12AffineFastState.Bounded env42580 := by
  intro p hp
  have h : env42580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42579_42580 : H12AffineEnvironment.transform 20 4160 env42579 = env42580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42579 == env42580) = true)

theorem identity42580 : scanCanonicalize (H12AffineFastState.compose env42580 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound42580 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169400,17,98780,8328,65,158028,5392,17665,32040,1500,156132,256,21792,46213,74251]

theorem envBound42581 : H12AffineFastState.Bounded env42581 := by
  intro p hp
  have h : env42581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42580_42581 : H12AffineEnvironment.transform 21 169400 env42580 = env42581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env42580 == env42581) = true)

theorem identity42581 : scanCanonicalize (H12AffineFastState.compose env42581 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42581 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env42582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4160,169400,17,41430,8328,65,158028,5392,17665,32040,1500,156132,256,21792,46213,513]

theorem envBound42582 : H12AffineFastState.Bounded env42582 := by
  intro p hp
  have h : env42582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42581_42582 : H12AffineEnvironment.transform 15 8202 env42581 = env42582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42581 == env42582) = true)

theorem identity42582 : scanCanonicalize (H12AffineFastState.compose env42582 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound42582 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,64809,1024,32769,4160,54697,17,41430,8328,65,10589,5392,17665,32040,1500,8693,256,21792,46213,513]

theorem envBound42583 : H12AffineFastState.Bounded env42583 := by
  intro p hp
  have h : env42583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42582_42583 : H12AffineEnvironment.transform 16 16401 env42582 = env42583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42582 == env42583) = true)

theorem identity42583 : scanCanonicalize (H12AffineFastState.compose env42583 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound42583 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env42584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,16401,2341,1024,29709,4160,8613,17,21978,8328,65,10589,5392,17665,32040,1500,8693,256,21792,16521,513]

theorem envBound42584 : H12AffineFastState.Bounded env42584 := by
  intro p hp
  have h : env42584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42583_42584 : H12AffineEnvironment.transform 14 29708 env42583 = env42584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env42583 == env42584) = true)

theorem identity42584 : scanCanonicalize (H12AffineFastState.compose env42584 (packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42584 : packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21761,263,16401,2341,1024,21760,4160,168,17,21978,389,65,2128,5392,17665,23589,1500,248,256,21792,16521,513]

theorem envBound42585 : H12AffineFastState.Bounded env42585 := by
  intro p hp
  have h : env42585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42584_42585 : H12AffineEnvironment.transform 12 269 env42584 = env42585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42584 == env42585) = true)

theorem identity42585 : scanCanonicalize (H12AffineFastState.compose env42585 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42585 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env42586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,1,263,5393,2341,1024,0,4160,168,17,218,389,65,2128,5392,4097,2341,1500,248,256,32,5513,513]

theorem envBound42586 : H12AffineFastState.Bounded env42586 := by
  intro p hp
  have h : env42586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42585_42586 : H12AffineEnvironment.transform 13 5376 env42585 = env42586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42585 == env42586) = true)

theorem identity42586 : scanCanonicalize (H12AffineFastState.compose env42586 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound42586 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42587 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5376,1,263,5393,2341,1024,0,4160,113,17,3,348,65,2128,5392,4097,2341,1285,33,256,32,5456,513]

theorem envBound42587 : H12AffineFastState.Bounded env42587 := by
  intro p hp
  have h : env42587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42586_42587 : H12AffineEnvironment.transform 6 89 env42586 = env42587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env42586 == env42587) = true)

theorem identity42587 : scanCanonicalize (H12AffineFastState.compose env42587 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42588 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1024,0,4160,113,17,3,120,65,2128,5172,4097,2049,1057,33,36,32,5236,513]

theorem envBound42588 : H12AffineFastState.Bounded env42588 := by
  intro p hp
  have h : env42588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42587_42588 : H12AffineEnvironment.transform 7 36 env42587 = env42588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42587 == env42588) = true)

theorem identity42588 : scanCanonicalize (H12AffineFastState.compose env42588 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42588 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42589 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1024,0,4112,33,17,3,40,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound42589 : H12AffineFastState.Bounded env42589 := by
  intro p hp
  have h : env42589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42588_42589 : H12AffineEnvironment.transform 5 16 env42588 = env42589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42588 == env42589) = true)

def env42590 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1044,1,35,1029,2049,1024,0,32,33,17,3,40,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound42590 : H12AffineFastState.Bounded env42590 := by
  intro p hp
  have h : env42590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42589_42590 : H12AffineEnvironment.transform 11 48 env42589 = env42590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42589 == env42590) = true)

theorem identity42590 : scanCanonicalize (H12AffineFastState.compose env42590 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound42590 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42591 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,48,41,1,1,35,16,2049,21,0,32,33,17,3,40,17,2048,17,49,2049,52,33,36,32,1,513]

theorem envBound42591 : H12AffineFastState.Bounded env42591 := by
  intro p hp
  have h : env42591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42590_42591 : H12AffineEnvironment.transform 9 21 env42590 = env42591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42590 == env42591) = true)

def env42592 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,9,1,1,3,16,2049,21,0,0,1,17,3,8,17,2048,17,17,2049,20,1,4,0,1,513]

theorem envBound42592 : H12AffineFastState.Bounded env42592 := by
  intro p hp
  have h : env42592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42591_42592 : H12AffineEnvironment.transform 4 0 env42591 = env42592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42591 == env42592) = true)

theorem identity42592 : scanCanonicalize (H12AffineFastState.compose env42592 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound42592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42593 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,16,9,1,1,3,16,523,21,0,0,1,17,3,8,17,522,17,17,523,20,1,4,0,1,513]

theorem envBound42593 : H12AffineFastState.Bounded env42593 := by
  intro p hp
  have h : env42593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42592_42593 : H12AffineEnvironment.transform 10 522 env42592 = env42593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env42592 == env42593) = true)

def leafEnv42593 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,16,9,1,1,3,16,523,21,0,0,1,17,3,20,8,1,17,522,17,17,523,20,1,4,0,4,2,1,513,1,0,0]

def active42593 : List Nat := [0,1,2,3,8]

def tree42593 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42593 : H12WitnessSearch.Good tree42593 := H12GlobalWitnessIndex.good

theorem leafIdentity42593 : H12AffineFastState.composeSystem env42593 rootObs = leafEnv42593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42593 rootObs == leafEnv42593) = true)

theorem terminalChecked42593 : H12PackedTerminal.terminalCheckFast leafEnv42593 active42593 tree42593 = true := by decide +kernel

def env42594 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,8,1,1,2,16,2049,21,0,1,0,17,3,9,17,2048,17,16,2049,21,0,5,1,1,513]

theorem envBound42594 : H12AffineFastState.Bounded env42594 := by
  intro p hp
  have h : env42594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42591_42594 : H12AffineEnvironment.transform 4 1 env42591 = env42594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42591 == env42594) = true)

theorem identity42594 : scanCanonicalize (H12AffineFastState.compose env42594 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42594 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42595 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,8,1,1,2,16,0,21,0,1,0,17,3,9,17,1,17,16,0,21,0,5,1,1,513]

theorem envBound42595 : H12AffineFastState.Bounded env42595 := by
  intro p hp
  have h : env42595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42594_42595 : H12AffineEnvironment.transform 10 1 env42594 = env42595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42594 == env42595) = true)

def leafEnv42595 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,8,1,1,2,16,0,21,0,1,0,17,3,21,9,1,17,1,17,16,0,21,0,5,1,4,3,1,513,1,1,0]

def active42595 : List Nat := [0,1,2,3,8]

def tree42595 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42595 : H12WitnessSearch.Good tree42595 := H12GlobalWitnessIndex.good

theorem leafIdentity42595 : H12AffineFastState.composeSystem env42595 rootObs = leafEnv42595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42595 rootObs == leafEnv42595) = true)

theorem terminalChecked42595 : H12PackedTerminal.terminalCheckFast leafEnv42595 active42595 tree42595 = true := by decide +kernel

def env42596 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1045,1,35,1028,2049,1024,0,33,33,17,3,40,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound42596 : H12AffineFastState.Bounded env42596 := by
  intro p hp
  have h : env42596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42589_42596 : H12AffineEnvironment.transform 11 49 env42589 = env42596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42589 == env42596) = true)

theorem identity42596 : scanCanonicalize (H12AffineFastState.compose env42596 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42597 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,16,8,1045,1,2,1028,2049,1024,0,0,0,17,3,9,17,2048,1029,17,2049,1024,0,5,1,1045,513]

theorem envBound42597 : H12AffineFastState.Bounded env42597 := by
  intro p hp
  have h : env42597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42596_42597 : H12AffineEnvironment.transform 4 1 env42596 = env42597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42596 == env42597) = true)

def env42598 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,8,1,1,2,16,2049,20,0,0,0,17,3,9,17,2048,17,17,2049,20,0,5,1,1,513]

theorem envBound42598 : H12AffineFastState.Bounded env42598 := by
  intro p hp
  have h : env42598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42597_42598 : H12AffineEnvironment.transform 9 20 env42597 = env42598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42597 == env42598) = true)

theorem identity42598 : scanCanonicalize (H12AffineFastState.compose env42598 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound42598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42599 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,16,8,1,1,2,16,523,20,0,0,0,17,3,9,17,522,17,17,523,20,0,5,1,1,513]

theorem envBound42599 : H12AffineFastState.Bounded env42599 := by
  intro p hp
  have h : env42599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42598_42599 : H12AffineEnvironment.transform 10 522 env42598 = env42599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env42598 == env42599) = true)

end H12CloudChart1