import H12CloudChart1Data150

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound38286 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38287 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1077,1141,121,0,81,115,16,1125,1025,80,1077,32,16,82,120,64,1076,65,1060,1077,1136,33,36,112,80,513]

theorem envBound38287 : H12AffineFastState.Bounded env38287 := by
  intro p hp
  have h : env38287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38286_38287 : H12AffineEnvironment.transform 7 37 env38286 = env38287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38286 == env38287) = true)

theorem identity38287 : scanCanonicalize (H12AffineFastState.compose env38287 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38288 : List Nat := [2,4,8,16,32,64,9,37,512,52,1,65,121,0,81,115,16,81,53,80,1,32,16,82,120,64,0,65,16,1,68,33,36,112,80,513]

theorem envBound38288 : H12AffineFastState.Bounded env38288 := by
  intro p hp
  have h : env38288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38287_38288 : H12AffineEnvironment.transform 9 52 env38287 = env38288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38287 == env38288) = true)

theorem identity38288 : scanCanonicalize (H12AffineFastState.compose env38288 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38288 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env38289 : List Nat := [2,4,8,16,32,16,9,37,512,52,1,17,41,0,1,35,16,1,53,0,1,32,16,2,40,16,0,17,16,1,20,33,36,32,0,513]

theorem envBound38289 : H12AffineFastState.Bounded env38289 := by
  intro p hp
  have h : env38289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38288_38289 : H12AffineEnvironment.transform 5 16 env38288 = env38289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38288 == env38289) = true)

theorem identity38289 : scanCanonicalize (H12AffineFastState.compose env38289 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38290 : List Nat := [2,4,8,16,17,16,9,20,512,5,1,17,24,0,1,18,16,1,4,0,1,17,16,2,25,16,0,17,16,1,20,16,21,17,0,513]

theorem envBound38290 : H12AffineFastState.Bounded env38290 := by
  intro p hp
  have h : env38290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38289_38290 : H12AffineEnvironment.transform 4 17 env38289 = env38290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38289 == env38290) = true)

def env38291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157597,2098513,17665,2377024,2102684,2411677,257,21792,46212,2175563]

theorem envBound38291 : H12AffineFastState.Bounded env38291 := by
  intro p hp
  have h : env38291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38247_38291 : H12AffineEnvironment.transform 21 272513 env38247 = env38291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38247 == env38291) = true)

theorem identity38291 : scanCanonicalize (H12AffineFastState.compose env38291 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38291 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,2097152,272513,2101328,41431,8328,64,2157597,2098513,17665,2377024,2102684,2411677,257,21792,46212,2101824]

theorem envBound38292 : H12AffineFastState.Bounded env38292 := by
  intro p hp
  have h : env38292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38291_38292 : H12AffineEnvironment.transform 15 8203 env38291 = env38292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38291 == env38292) = true)

def env38293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,2097152,272393,2101328,41311,8192,64,2157597,2098513,17665,2377024,2102548,2411541,257,21792,46092,2101824]

theorem envBound38293 : H12AffineFastState.Bounded env38293 := by
  intro p hp
  have h : env38293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38292_38293 : H12AffineEnvironment.transform 6 8 env38292 = env38293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38292 == env38293) = true)

theorem identity38293 : scanCanonicalize (H12AffineFastState.compose env38293 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301365) := by decide +kernel

theorem selectedBound38293 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,301365,272393,297317,41311,8192,64,292136,302180,17665,56437,298017,21792,257,21792,46092,297845]

theorem envBound38294 : H12AffineFastState.Bounded env38294 := by
  intro p hp
  have h : env38294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38293_38294 : H12AffineEnvironment.transform 20 301365 env38293 = env38294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301365 env38293 == env38294) = true)

theorem identity38294 : scanCanonicalize (H12AffineFastState.compose env38294 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 34817) := by decide +kernel

theorem selectedBound38294 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,34817,1025,32769,4404,40968,356,41311,8192,64,64809,5221,17665,56437,1056,21792,257,21792,46092,884]

theorem envBound38295 : H12AffineFastState.Bounded env38295 := by
  intro p hp
  have h : env38295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38294_38295 : H12AffineEnvironment.transform 17 34817 env38294 = env38295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34817 env38294 == env38295) = true)

theorem identity38295 : scanCanonicalize (H12AffineFastState.compose env38295 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38295 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env38296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,13388,10588,1025,8540,4404,341,356,2,8192,64,23668,5221,17665,32040,1056,21792,257,21792,5457,884]

theorem envBound38296 : H12AffineFastState.Bounded env38296 := by
  intro p hp
  have h : env38296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38295_38296 : H12AffineEnvironment.transform 14 8541 env38295 = env38296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38295 == env38296) = true)

theorem identity38296 : scanCanonicalize (H12AffineFastState.compose env38296 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound38296 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env38297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8541,8203,13388,10588,1025,8540,4404,341,356,2,8192,64,10589,5221,12328,2049,1056,8201,257,8201,5457,884]

theorem envBound38297 : H12AffineFastState.Bounded env38297 := by
  intro p hp
  have h : env38297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38296_38297 : H12AffineEnvironment.transform 13 13609 env38296 = env38297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env38296 == env38297) = true)

theorem identity38297 : scanCanonicalize (H12AffineFastState.compose env38297 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38297 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5157,81,263,5440,2128,1025,80,4404,341,356,2,268,64,2129,5221,4388,2049,1056,261,257,261,5457,884]

theorem envBound38298 : H12AffineFastState.Bounded env38298 := by
  intro p hp
  have h : env38298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38297_38298 : H12AffineEnvironment.transform 12 268 env38297 = env38298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38297 == env38298) = true)

theorem identity38298 : scanCanonicalize (H12AffineFastState.compose env38298 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound38298 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env38299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,268,372,81,263,17,2128,1025,80,1125,341,356,2,268,64,2129,308,1141,2049,1056,261,257,261,0,884]

theorem envBound38299 : H12AffineFastState.Bounded env38299 := by
  intro p hp
  have h : env38299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38298_38299 : H12AffineEnvironment.transform 11 1361 env38298 = env38299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env38298 == env38299) = true)

theorem identity38299 : scanCanonicalize (H12AffineFastState.compose env38299 (packedSelected [2,3,5,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound38299 : packedSelected [2,3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env38300 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,96,268,372,81,263,17,2128,304,80,340,341,356,2,268,64,2129,308,324,2049,273,261,257,261,0,884]

theorem envBound38300 : H12AffineFastState.Bounded env38300 := by
  intro p hp
  have h : env38300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38299_38300 : H12AffineEnvironment.transform 9 305 env38299 = env38300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env38299 == env38300) = true)

theorem identity38300 : scanCanonicalize (H12AffineFastState.compose env38300 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38300 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env38301 : List Nat := [2,4,8,16,32,64,8,4,512,53,2048,96,8,112,81,3,17,2128,52,80,80,81,96,2,8,64,2129,48,64,2049,21,1,5,1,0,624]

theorem envBound38301 : H12AffineFastState.Bounded env38301 := by
  intro p hp
  have h : env38301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38300_38301 : H12AffineEnvironment.transform 7 4 env38300 = env38301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38300 == env38301) = true)

theorem identity38301 : scanCanonicalize (H12AffineFastState.compose env38301 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound38301 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env38302 : List Nat := [2,4,8,16,32,64,8,4,512,53,112,96,8,112,81,3,17,32,52,80,80,81,96,2,8,64,33,48,64,113,21,1,5,1,0,624]

theorem envBound38302 : H12AffineFastState.Bounded env38302 := by
  intro p hp
  have h : env38302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38301_38302 : H12AffineEnvironment.transform 10 112 env38301 = env38302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env38301 == env38302) = true)

theorem identity38302 : scanCanonicalize (H12AffineFastState.compose env38302 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38302 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38303 : List Nat := [2,4,8,16,32,48,8,4,512,53,0,16,8,0,33,3,17,32,52,32,32,33,16,2,8,48,33,48,48,1,21,1,5,1,0,512]

theorem envBound38303 : H12AffineFastState.Bounded env38303 := by
  intro p hp
  have h : env38303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38302_38303 : H12AffineEnvironment.transform 5 48 env38302 = env38303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38302 == env38303) = true)

def env38304 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,2097152,272392,2101328,41310,8193,64,2157597,2098513,17665,2377024,2102549,2411540,257,21792,46093,2101824]

theorem envBound38304 : H12AffineFastState.Bounded env38304 := by
  intro p hp
  have h : env38304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38292_38304 : H12AffineEnvironment.transform 6 9 env38292 = env38304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38292 == env38304) = true)

theorem identity38304 : scanCanonicalize (H12AffineFastState.compose env38304 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound38304 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,276584,272392,272440,41310,8193,64,316533,277817,17665,32040,273789,62588,257,21792,46093,272936]

theorem envBound38305 : H12AffineFastState.Bounded env38305 := by
  intro p hp
  have h : env38305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38304_38305 : H12AffineEnvironment.transform 20 276584 env38304 = env38305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env38304 == env38305) = true)

theorem identity38305 : scanCanonicalize (H12AffineFastState.compose env38305 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10280,1025,32769,4160,32,16,41310,8193,64,64605,5393,17665,32040,1365,62588,257,21792,46093,512]

theorem envBound38306 : H12AffineFastState.Bounded env38306 := by
  intro p hp
  have h : env38306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38305_38306 : H12AffineEnvironment.transform 17 10280 env38305 = env38306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38305 == env38306) = true)

theorem identity38306 : scanCanonicalize (H12AffineFastState.compose env38306 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 12620) := by decide +kernel

theorem selectedBound38306 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,12620,8203,9309,10280,1025,12621,4160,32,16,4114,8193,64,19729,5393,17665,32040,1365,17712,257,21792,1345,512]

theorem envBound38307 : H12AffineFastState.Bounded env38307 := by
  intro p hp
  have h : env38307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38306_38307 : H12AffineEnvironment.transform 14 12620 env38306 = env38307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12620 env38306 == env38307) = true)

theorem identity38307 : scanCanonicalize (H12AffineFastState.compose env38307 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 1125) := by decide +kernel

theorem selectedBound38307 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1125,12620,8203,9309,10280,1025,12621,4160,32,16,4114,8193,64,2420,5393,356,14669,1365,341,257,4421,1345,512]

theorem envBound38308 : H12AffineFastState.Bounded env38308 := by
  intro p hp
  have h : env38308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38307_38308 : H12AffineEnvironment.transform 13 1125 env38307 = env38308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1125 env38307 == env38308) = true)

theorem identity38308 : scanCanonicalize (H12AffineFastState.compose env38308 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 4168) := by decide +kernel

theorem selectedBound38308 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,4168,1125,260,4163,5141,6240,1025,261,4160,32,16,4114,4169,64,2420,5393,356,2309,1365,341,257,4421,1345,512]

theorem envBound38309 : H12AffineFastState.Bounded env38309 := by
  intro p hp
  have h : env38309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38308_38309 : H12AffineEnvironment.transform 12 4168 env38308 = env38309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4168 env38308 == env38309) = true)

def env38310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound38310 : H12AffineFastState.Bounded env38310 := by
  intro p hp
  have h : env38310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37896_38310 : H12AffineEnvironment.transform 26 30393345 env37896 = env38310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env37896 == env38310) = true)

def env38311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound38311 : H12AffineFastState.Bounded env38311 := by
  intro p hp
  have h : env38311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38310_38311 : H12AffineEnvironment.transform 18 1024 env38310 = env38311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env38310 == env38311) = true)

def env38312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6705549,8393984,10507601,8830977,2102684,12645453,256,21792,46212,2175562]

theorem envBound38312 : H12AffineFastState.Bounded env38312 := by
  intro p hp
  have h : env38312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38311_38312 : H12AffineEnvironment.transform 23 10588556 env38311 = env38312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env38311 == env38312) = true)

def env38313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98780,8328,64,6705549,2098512,17665,2543697,2102684,6349853,256,21792,46212,2175562]

theorem envBound38313 : H12AffineFastState.Bounded env38313 := by
  intro p hp
  have h : env38313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38312_38313 : H12AffineEnvironment.transform 22 2101328 env38312 = env38313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env38312 == env38313) = true)

def env38314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98780,8328,64,2259213,2098512,17665,2543697,2102684,2411677,256,21792,46212,2175562]

theorem envBound38314 : H12AffineFastState.Bounded env38314 := by
  intro p hp
  have h : env38314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38313_38314 : H12AffineEnvironment.transform 21 272512 env38313 = env38314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38313 == env38314) = true)

theorem identity38314 : scanCanonicalize (H12AffineFastState.compose env38314 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound38314 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,272512,62661,98780,8328,64,171416,57797,17665,406724,61705,272392,256,21792,46212,120543]

theorem envBound38315 : H12AffineFastState.Bounded env38315 := by
  intro p hp
  have h : env38315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38314_38315 : H12AffineEnvironment.transform 20 58517 env38314 = env38315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env38314 == env38315) = true)

def env38316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,272392,62541,98644,8192,64,171280,57677,17665,406604,61705,272392,256,21792,46092,120407]

theorem envBound38316 : H12AffineFastState.Bounded env38316 := by
  intro p hp
  have h : env38316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38315_38316 : H12AffineEnvironment.transform 6 8 env38315 = env38316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38315 == env38316) = true)

theorem identity38316 : scanCanonicalize (H12AffineFastState.compose env38316 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound38316 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env38317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,58397,147504,62541,98644,8192,64,171280,57677,17665,23668,61705,147504,256,21792,46092,120407]

theorem envBound38317 : H12AffineFastState.Bounded env38317 := by
  intro p hp
  have h : env38317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38316_38317 : H12AffineEnvironment.transform 17 157752 env38316 = env38317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env38316 == env38317) = true)

theorem identity38317 : scanCanonicalize (H12AffineFastState.compose env38317 (packedSelected [0,4,5,7,8,16,17,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound38317 : packedSelected [0,4,5,7,8,16,17,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1024,32769,58397,41340,62541,98644,8192,64,31836,57677,17665,23668,61705,41340,256,21792,46092,120407]

theorem envBound38318 : H12AffineFastState.Bounded env38318 := by
  intro p hp
  have h : env38318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38317_38318 : H12AffineEnvironment.transform 16 57676 env38317 = env38318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env38317 == env38318) = true)

theorem identity38318 : scanCanonicalize (H12AffineFastState.compose env38318 (packedSelected [1,5,8,17,19,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38318 : packedSelected [1,5,8,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,46156,35188,1024,32769,45341,41340,41293,98644,8192,64,10588,46157,4097,2420,41993,41340,256,32,46092,99159]

theorem envBound38319 : H12AffineFastState.Bounded env38319 := by
  intro p hp
  have h : env38319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38318_38319 : H12AffineEnvironment.transform 13 5376 env38318 = env38319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38318 == env38319) = true)

theorem identity38319 : scanCanonicalize (H12AffineFastState.compose env38319 (packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound38319 : packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,35,46156,35188,1024,32769,45341,41340,41293,33143,8192,64,10588,46157,4097,2420,41993,41340,256,32,46092,33652]

theorem envBound38320 : H12AffineFastState.Bounded env38320 := by
  intro p hp
  have h : env38320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38319_38320 : H12AffineEnvironment.transform 15 35 env38319 = env38320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env38319 == env38320) = true)

theorem identity38320 : scanCanonicalize (H12AffineFastState.compose env38320 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38320 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env38321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,35,5393,10281,1024,8540,4160,33,16,8234,8192,64,10588,5392,4097,2420,1364,33,256,32,5457,8745]

theorem envBound38321 : H12AffineFastState.Bounded env38321 := by
  intro p hp
  have h : env38321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38320_38321 : H12AffineEnvironment.transform 14 8541 env38320 = env38321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38320 == env38321) = true)

theorem identity38321 : scanCanonicalize (H12AffineFastState.compose env38321 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound38321 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,341,35,5393,2081,1024,340,4160,33,16,34,8,64,2388,5392,4097,2420,1364,33,256,32,5457,545]

theorem envBound38322 : H12AffineFastState.Bounded env38322 := by
  intro p hp
  have h : env38322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38321_38322 : H12AffineEnvironment.transform 12 8 env38321 = env38322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env38321 == env38322) = true)

theorem identity38322 : scanCanonicalize (H12AffineFastState.compose env38322 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound38322 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38323 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,4096,8,4145,341,35,4128,2081,305,340,4160,33,16,34,8,64,2388,4129,4097,2420,101,33,256,32,4192,545]

theorem envBound38323 : H12AffineFastState.Bounded env38323 := by
  intro p hp
  have h : env38323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38322_38323 : H12AffineEnvironment.transform 9 305 env38322 = env38323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env38322 == env38323) = true)

theorem identity38323 : scanCanonicalize (H12AffineFastState.compose env38323 (packedSelected [2,6,11] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38323 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env38324 : List Nat := [2,4,8,16,32,48,8,256,512,305,2048,4096,8,4145,293,35,4128,2081,305,292,4144,33,16,34,8,48,2340,4129,4097,2308,21,33,256,32,4112,545]

theorem envBound38324 : H12AffineFastState.Bounded env38324 := by
  intro p hp
  have h : env38324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38323_38324 : H12AffineEnvironment.transform 5 48 env38323 = env38324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38323 == env38324) = true)

theorem identity38324 : scanCanonicalize (H12AffineFastState.compose env38324 (packedSelected [2,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38324 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env38325 : List Nat := [2,4,8,16,32,48,8,37,512,20,2048,4096,8,4145,0,35,4128,2081,20,1,4144,33,16,34,8,48,2049,4129,4097,2081,21,33,37,32,4112,545]

theorem envBound38325 : H12AffineFastState.Bounded env38325 := by
  intro p hp
  have h : env38325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38324_38325 : H12AffineEnvironment.transform 7 37 env38324 = env38325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38324 == env38325) = true)

theorem identity38325 : scanCanonicalize (H12AffineFastState.compose env38325 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38325 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env38326 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,4096,8,4113,0,3,4096,2049,20,1,4112,1,16,2,8,16,2049,4097,4097,2049,21,1,5,0,4112,513]

theorem envBound38326 : H12AffineFastState.Bounded env38326 := by
  intro p hp
  have h : env38326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38325_38326 : H12AffineEnvironment.transform 4 0 env38325 = env38326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38325 == env38326) = true)

def env38327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,272393,62540,98645,8193,64,171281,57676,17665,406605,61705,272392,256,21792,46093,120406]

theorem envBound38327 : H12AffineFastState.Bounded env38327 := by
  intro p hp
  have h : env38327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38315_38327 : H12AffineEnvironment.transform 6 9 env38315 = env38327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38315 == env38327) = true)

theorem identity38327 : scanCanonicalize (H12AffineFastState.compose env38327 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound38327 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env38328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130175,1024,32769,58396,119926,62540,98645,8193,64,171281,57676,17665,247858,61705,119927,256,21792,46093,120406]

theorem envBound38328 : H12AffineFastState.Bounded env38328 := by
  intro p hp
  have h : env38328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38327_38328 : H12AffineEnvironment.transform 17 130175 env38327 = env38328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env38327 == env38328) = true)

def env38329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67619,1024,29789,4160,73770,16,95497,8193,64,158029,5392,17665,212078,1365,73771,256,21792,16465,74250]

theorem envBound38329 : H12AffineFastState.Bounded env38329 := by
  intro p hp
  have h : env38329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38328_38329 : H12AffineEnvironment.transform 14 29788 env38328 = env38329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env38328 == env38329) = true)

theorem identity38329 : scanCanonicalize (H12AffineFastState.compose env38329 (packedSelected [2,4,6,7,11,14,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound38329 : packedSelected [2,4,6,7,11,14,22,23,27] rootPS < 2^1333 := by decide +kernel

def env38330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,131072,2421,1024,29789,4160,8572,16,29791,8193,64,158029,5392,17665,146744,1365,8573,256,21792,16465,9052]

theorem envBound38330 : H12AffineFastState.Bounded env38330 := by
  intro p hp
  have h : env38330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38329_38330 : H12AffineEnvironment.transform 15 342 env38329 = env38330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env38329 == env38330) = true)

theorem identity38330 : scanCanonicalize (H12AffineFastState.compose env38330 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound38330 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env38331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,16449,2421,1024,29789,4160,8572,16,29791,8193,64,10508,5392,17665,32121,1365,8573,256,21792,16465,9052]

theorem envBound38331 : H12AffineFastState.Bounded env38331 := by
  intro p hp
  have h : env38331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38330_38331 : H12AffineEnvironment.transform 16 16449 env38330 = env38331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env38330 == env38331) = true)

theorem identity38331 : scanCanonicalize (H12AffineFastState.compose env38331 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38331 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env38332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,16449,2421,1024,21761,4160,32,16,21763,349,64,2128,5392,17665,23589,1365,33,256,21792,16465,512]

theorem envBound38332 : H12AffineFastState.Bounded env38332 := by
  intro p hp
  have h : env38332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38331_38332 : H12AffineEnvironment.transform 12 348 env38331 = env38332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38331 == env38332) = true)

theorem identity38332 : scanCanonicalize (H12AffineFastState.compose env38332 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound38332 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5408,32,342,5473,2421,1024,33,4160,32,16,35,349,64,2128,5392,4129,2309,1365,33,256,0,5489,512]

theorem envBound38333 : H12AffineFastState.Bounded env38333 := by
  intro p hp
  have h : env38333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38332_38333 : H12AffineEnvironment.transform 13 5408 env38332 = env38333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env38332 == env38333) = true)

theorem identity38333 : scanCanonicalize (H12AffineFastState.compose env38333 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38333 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38334 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,348,4145,32,342,4208,2421,273,33,4160,32,16,35,349,64,2128,4097,4129,2309,68,33,256,0,4192,512]

theorem envBound38334 : H12AffineFastState.Bounded env38334 := by
  intro p hp
  have h : env38334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38333_38334 : H12AffineEnvironment.transform 9 273 env38333 = env38334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38333 == env38334) = true)

theorem identity38334 : scanCanonicalize (H12AffineFastState.compose env38334 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound38334 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38335 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2097,348,2048,32,342,2113,2421,273,33,2161,32,16,35,349,64,2128,2096,2064,2309,68,33,256,0,2129,512]

theorem envBound38335 : H12AffineFastState.Bounded env38335 := by
  intro p hp
  have h : env38335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38334_38335 : H12AffineEnvironment.transform 11 2097 env38334 = env38335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env38334 == env38335) = true)

theorem identity38335 : scanCanonicalize (H12AffineFastState.compose env38335 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38335 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38336 : List Nat := [2,4,8,16,32,48,9,256,512,273,2048,2097,300,2048,32,294,2097,2309,273,33,2049,32,16,35,301,48,2080,2096,2064,2309,52,33,256,0,2081,512]

theorem envBound38336 : H12AffineFastState.Bounded env38336 := by
  intro p hp
  have h : env38336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38335_38336 : H12AffineEnvironment.transform 5 48 env38335 = env38336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38335 == env38336) = true)

theorem identity38336 : scanCanonicalize (H12AffineFastState.compose env38336 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38336 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38337 : List Nat := [2,4,8,16,32,48,9,5,512,20,2048,2097,41,2048,32,35,2097,2048,20,33,2049,32,16,35,40,48,2080,2096,2064,2048,52,33,5,0,2081,512]

theorem envBound38337 : H12AffineFastState.Bounded env38337 := by
  intro p hp
  have h : env38337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38336_38337 : H12AffineEnvironment.transform 7 5 env38336 = env38337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38336 == env38337) = true)

theorem identity38337 : scanCanonicalize (H12AffineFastState.compose env38337 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38337 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env38338 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2065,9,2048,0,3,2065,2048,20,1,2049,0,16,3,8,16,2048,2064,2064,2048,20,1,5,0,2049,512]

theorem envBound38338 : H12AffineFastState.Bounded env38338 := by
  intro p hp
  have h : env38338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38337_38338 : H12AffineEnvironment.transform 4 0 env38337 = env38338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38337 == env38338) = true)

theorem identity38338 : scanCanonicalize (H12AffineFastState.compose env38338 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38339 : List Nat := [2,4,8,16,0,16,9,5,0,20,2048,2065,9,2048,0,3,2065,2048,20,1,2049,0,16,3,8,16,2048,2064,2064,2048,20,1,5,0,2049,0]

theorem envBound38339 : H12AffineFastState.Bounded env38339 := by
  intro p hp
  have h : env38339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38338_38339 : H12AffineEnvironment.transform 8 0 env38338 = env38339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38338 == env38339) = true)

theorem identity38339 : scanCanonicalize (H12AffineFastState.compose env38339 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound38339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38340 : List Nat := [2,4,8,4,0,4,9,5,0,0,2048,2053,9,2048,0,3,2053,2048,0,1,2049,0,4,3,8,4,2048,2052,2052,2048,0,1,5,0,2049,0]

theorem envBound38340 : H12AffineFastState.Bounded env38340 := by
  intro p hp
  have h : env38340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38339_38340 : H12AffineEnvironment.transform 3 4 env38339 = env38340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env38339 == env38340) = true)

def leafEnv38340 : List Nat := [2,4,8,4,0,4,9,5,0,0,2048,2053,9,2048,0,3,2053,2048,0,1,2049,0,4,3,0,8,1,4,2048,2052,2052,2048,0,1,5,0,4,2,2049,0,1,2048,0]

def active38340 : List Nat := [0,1,2,10]

def tree38340 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38340 : H12WitnessSearch.Good tree38340 := H12GlobalWitnessIndex.good

theorem leafIdentity38340 : H12AffineFastState.composeSystem env38340 rootObs = leafEnv38340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38340 rootObs == leafEnv38340) = true)

theorem terminalChecked38340 : H12PackedTerminal.terminalCheckFast leafEnv38340 active38340 tree38340 = true := by decide +kernel

def env38341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67618,1024,29788,4161,73771,17,95496,8193,64,158028,5393,17665,212079,1364,73770,256,21792,16464,74251]

theorem envBound38341 : H12AffineFastState.Bounded env38341 := by
  intro p hp
  have h : env38341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38328_38341 : H12AffineEnvironment.transform 14 29789 env38328 = env38341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env38328 == env38341) = true)

theorem identity38341 : scanCanonicalize (H12AffineFastState.compose env38341 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38341 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,10280,1024,29788,4161,33,17,21762,8193,64,158028,5393,17665,138341,1364,32,256,21792,16464,513]

theorem envBound38342 : H12AffineFastState.Bounded env38342 := by
  intro p hp
  have h : env38342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38341_38342 : H12AffineEnvironment.transform 15 8202 env38341 = env38342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38341 == env38342) = true)

theorem identity38342 : scanCanonicalize (H12AffineFastState.compose env38342 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38342 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38343 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,10280,1024,29709,4112,33,17,21762,8193,17,157981,5393,17665,138292,1285,32,256,21792,16385,513]

theorem envBound38343 : H12AffineFastState.Bounded env38343 := by
  intro p hp
  have h : env38343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38342_38343 : H12AffineEnvironment.transform 5 17 env38342 = env38343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38342 == env38343) = true)

theorem identity38343 : scanCanonicalize (H12AffineFastState.compose env38343 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound38343 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38344 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8202,131072,10280,1024,1,4112,33,17,8462,8193,17,138513,5393,12557,138292,1285,32,256,8492,13325,513]

theorem envBound38344 : H12AffineFastState.Bounded env38344 := by
  intro p hp
  have h : env38344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38343_38344 : H12AffineEnvironment.transform 13 13324 env38343 = env38344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env38343 == env38344) = true)

theorem identity38344 : scanCanonicalize (H12AffineFastState.compose env38344 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38344 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38345 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,131072,2341,1024,1,4112,33,17,3,268,17,138513,5393,4096,138292,1285,32,256,33,5376,513]

theorem envBound38345 : H12AffineFastState.Bounded env38345 := by
  intro p hp
  have h : env38345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38344_38345 : H12AffineEnvironment.transform 12 269 env38344 = env38345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38344 == env38345) = true)

theorem identity38345 : scanCanonicalize (H12AffineFastState.compose env38345 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound38345 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38346 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,269,2049,0,263,131072,2341,1024,1,3344,33,17,3,268,17,131089,2065,3328,131380,1285,32,256,33,2048,513]

theorem envBound38346 : H12AffineFastState.Bounded env38346 := by
  intro p hp
  have h : env38346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38345_38346 : H12AffineEnvironment.transform 11 3328 env38345 = env38346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env38345 == env38346) = true)

theorem identity38346 : scanCanonicalize (H12AffineFastState.compose env38346 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 2064) := by decide +kernel

theorem selectedBound38346 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38347 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,269,2049,0,263,2064,2341,1024,1,3344,33,17,3,268,17,2049,2065,3328,2340,1285,32,256,33,2048,513]

theorem envBound38347 : H12AffineFastState.Bounded env38347 := by
  intro p hp
  have h : env38347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38346_38347 : H12AffineEnvironment.transform 16 2064 env38346 = env38347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2064 env38346 == env38347) = true)

theorem identity38347 : scanCanonicalize (H12AffineFastState.compose env38347 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38348 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,40,2049,0,34,2064,2048,1024,1,3125,33,17,3,41,17,2049,2065,3109,2049,1056,32,37,33,2048,513]

theorem envBound38348 : H12AffineFastState.Bounded env38348 := by
  intro p hp
  have h : env38348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38347_38348 : H12AffineEnvironment.transform 7 37 env38347 = env38348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38347 == env38348) = true)

theorem identity38348 : scanCanonicalize (H12AffineFastState.compose env38348 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1599) := by decide +kernel

theorem selectedBound38348 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38349 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1599,538,40,1598,0,34,1583,1599,1024,1,522,33,17,3,41,17,1598,1582,538,1598,1056,32,37,33,1599,513]

theorem envBound38349 : H12AffineFastState.Bounded env38349 := by
  intro p hp
  have h : env38349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38348_38349 : H12AffineEnvironment.transform 10 1599 env38348 = env38349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1599 env38348 == env38349) = true)

theorem identity38349 : scanCanonicalize (H12AffineFastState.compose env38349 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound38349 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38350 : List Nat := [2,4,8,16,32,17,9,37,61,1024,1026,39,40,1027,0,34,1042,1026,1024,1,55,33,17,3,41,17,1027,1043,39,1027,1056,32,37,33,1026,60]

theorem envBound38350 : H12AffineFastState.Bounded env38350 := by
  intro p hp
  have h : env38350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38349_38350 : H12AffineEnvironment.transform 8 61 env38349 = env38350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env38349 == env38350) = true)

theorem identity38350 : scanCanonicalize (H12AffineFastState.compose env38350 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound38350 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38351 : List Nat := [2,4,8,16,32,17,9,37,61,34,32,39,40,33,0,34,48,32,34,1,55,33,17,3,41,17,33,49,39,33,2,32,37,33,32,60]

theorem envBound38351 : H12AffineFastState.Bounded env38351 := by
  intro p hp
  have h : env38351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38350_38351 : H12AffineEnvironment.transform 9 34 env38350 = env38351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env38350 == env38351) = true)

theorem identity38351 : scanCanonicalize (H12AffineFastState.compose env38351 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound38351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38352 : List Nat := [2,4,8,5,32,4,9,37,40,34,32,39,40,33,0,34,37,32,34,1,34,33,4,3,41,4,33,36,39,33,2,32,37,33,32,41]

theorem envBound38352 : H12AffineFastState.Bounded env38352 := by
  intro p hp
  have h : env38352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38351_38352 : H12AffineEnvironment.transform 3 5 env38351 = env38352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env38351 == env38352) = true)

def env38353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98780,8328,64,2259212,2098512,17665,2543697,2102684,2411676,256,21792,46212,2175562]

theorem envBound38353 : H12AffineFastState.Bounded env38353 := by
  intro p hp
  have h : env38353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38313_38353 : H12AffineEnvironment.transform 21 272513 env38313 = env38353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38313 == env38353) = true)

theorem identity38353 : scanCanonicalize (H12AffineFastState.compose env38353 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound38353 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,2101328,95497,8328,64,2259212,2098512,17665,2499716,2102684,2373705,256,21792,16465,2175562]

theorem envBound38354 : H12AffineFastState.Bounded env38354 := by
  intro p hp
  have h : env38354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38353_38354 : H12AffineEnvironment.transform 14 29909 env38353 = env38354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env38353 == env38354) = true)

def env38355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,272513,2101328,73737,8328,64,2239500,2098512,4097,2499716,2102684,2373705,256,32,5457,2175562]

theorem envBound38355 : H12AffineFastState.Bounded env38355 := by
  intro p hp
  have h : env38355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38354_38355 : H12AffineEnvironment.transform 13 5376 env38354 = env38355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38354 == env38355) = true)

def env38356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,4160,272513,16,73737,8328,64,146508,5392,4097,406724,1500,272393,256,32,5457,74250]

theorem envBound38356 : H12AffineFastState.Bounded env38356 := by
  intro p hp
  have h : env38356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38355_38356 : H12AffineEnvironment.transform 20 4160 env38355 = env38356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38355 == env38356) = true)

theorem identity38356 : scanCanonicalize (H12AffineFastState.compose env38356 (packedSelected [0,2,4,7,9,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound38356 : packedSelected [0,2,4,7,9,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env38357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138477,1024,8660,4160,144492,16,73737,8328,64,146508,5392,4097,10281,1500,144612,256,32,5457,74250]

theorem envBound38357 : H12AffineFastState.Bounded env38357 := by
  intro p hp
  have h : env38357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38356_38357 : H12AffineEnvironment.transform 17 138477 env38356 = env38357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env38356 == env38357) = true)

theorem identity38357 : scanCanonicalize (H12AffineFastState.compose env38357 (packedSelected [1,2,3,9,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound38357 : packedSelected [1,2,3,9,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79298,76079,1024,8660,4160,65966,16,73737,8328,64,67982,5392,4097,10281,1500,65830,256,32,5457,74250]

theorem envBound38358 : H12AffineFastState.Bounded env38358 := by
  intro p hp
  have h : env38358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38357_38358 : H12AffineEnvironment.transform 16 79298 env38357 = env38358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env38357 == env38358) = true)

theorem identity38358 : scanCanonicalize (H12AffineFastState.compose env38358 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38358 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env38359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,263,13509,10280,1024,8660,4160,169,16,8462,8328,64,2185,5392,4097,10281,1500,33,256,32,5457,8973]

theorem envBound38359 : H12AffineFastState.Bounded env38359 := by
  intro p hp
  have h : env38359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38358_38359 : H12AffineEnvironment.transform 15 263 env38358 = env38359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38358 == env38359) = true)

theorem identity38359 : scanCanonicalize (H12AffineFastState.compose env38359 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38359 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,263,13388,10280,1024,8541,4160,32,16,8462,8193,64,2048,5392,4097,10281,1365,33,256,32,5457,8973]

theorem envBound38360 : H12AffineFastState.Bounded env38360 := by
  intro p hp
  have h : env38360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38359_38360 : H12AffineEnvironment.transform 6 9 env38359 = env38360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38359 == env38360) = true)

theorem identity38360 : scanCanonicalize (H12AffineFastState.compose env38360 (packedSelected [6,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38360 : packedSelected [6,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env38361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,263,5393,2421,1024,0,4160,32,16,83,348,64,2048,5392,4097,2420,1365,33,256,32,5457,592]

theorem envBound38361 : H12AffineFastState.Bounded env38361 := by
  intro p hp
  have h : env38361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38360_38361 : H12AffineEnvironment.transform 12 349 env38360 = env38361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38360 == env38361) = true)

theorem identity38361 : scanCanonicalize (H12AffineFastState.compose env38361 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound38361 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env38362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,512,349,1792,1,263,1809,2421,1024,0,576,32,16,83,348,64,2048,1808,513,2420,1365,33,256,32,1873,592]

theorem envBound38362 : H12AffineFastState.Bounded env38362 := by
  intro p hp
  have h : env38362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38361_38362 : H12AffineEnvironment.transform 11 512 env38361 = env38362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env38361 == env38362) = true)

theorem identity38362 : scanCanonicalize (H12AffineFastState.compose env38362 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38362 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env38363 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,512,269,1792,1,263,1809,2341,1024,0,528,32,16,3,268,16,2048,1808,513,2340,1285,33,256,32,1793,512]

theorem envBound38363 : H12AffineFastState.Bounded env38363 := by
  intro p hp
  have h : env38363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38362_38363 : H12AffineEnvironment.transform 5 16 env38362 = env38363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38362 == env38363) = true)

def env38364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,4161,272513,17,73737,8328,64,146509,5393,4097,406725,1501,272392,256,32,5457,74251]

theorem envBound38364 : H12AffineFastState.Bounded env38364 := by
  intro p hp
  have h : env38364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38355_38364 : H12AffineEnvironment.transform 20 4161 env38355 = env38364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38355 == env38364) = true)

theorem identity38364 : scanCanonicalize (H12AffineFastState.compose env38364 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound38364 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,4161,32,17,73737,8328,64,146509,5393,4097,138340,1501,169,256,32,5457,74251]

theorem envBound38365 : H12AffineFastState.Bounded env38365 := by
  intro p hp
  have h : env38365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38364_38365 : H12AffineEnvironment.transform 17 10401 env38364 = env38365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env38364 == env38365) = true)

theorem identity38365 : scanCanonicalize (H12AffineFastState.compose env38365 (packedSelected [1,2,3,5,8,9,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound38365 : packedSelected [1,2,3,5,8,9,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5376,396,65536,131072,2296,1024,397,4161,32,17,65616,209,64,138260,5393,4097,138340,1501,169,256,32,5457,66130]

theorem envBound38366 : H12AffineFastState.Bounded env38366 := by
  intro p hp
  have h : env38366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38365_38366 : H12AffineEnvironment.transform 12 89 env38365 = env38366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env38365 == env38366) = true)

theorem identity38366 : scanCanonicalize (H12AffineFastState.compose env38366 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound38366 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env38367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5376,396,65536,5392,2296,1024,397,4161,32,17,65616,209,64,2308,5393,4097,2420,1501,169,256,32,5457,66130]

theorem envBound38367 : H12AffineFastState.Bounded env38367 := by
  intro p hp
  have h : env38367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38366_38367 : H12AffineEnvironment.transform 16 5392 env38366 = env38367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env38366 == env38367) = true)

theorem identity38367 : scanCanonicalize (H12AffineFastState.compose env38367 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound38367 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5376,396,83,5392,2296,1024,397,4161,32,17,3,209,64,2308,5393,4097,2420,1501,169,256,32,5457,513]

theorem envBound38368 : H12AffineFastState.Bounded env38368 := by
  intro p hp
  have h : env38368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38367_38368 : H12AffineEnvironment.transform 15 83 env38367 = env38368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env38367 == env38368) = true)

theorem identity38368 : scanCanonicalize (H12AffineFastState.compose env38368 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38368 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env38369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5376,261,83,5392,2161,1024,260,4161,32,17,3,88,64,2308,5393,4097,2420,1364,32,256,32,5457,513]

theorem envBound38369 : H12AffineFastState.Bounded env38369 := by
  intro p hp
  have h : env38369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38368_38369 : H12AffineEnvironment.transform 6 9 env38368 = env38369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38368 == env38369) = true)

def env38370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,272513,2101328,73736,8328,64,2239501,2098512,4096,2499716,2102684,2373705,256,33,5456,2175562]

theorem envBound38370 : H12AffineFastState.Bounded env38370 := by
  intro p hp
  have h : env38370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38354_38370 : H12AffineEnvironment.transform 13 5377 env38354 = env38370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38354 == env38370) = true)

def env38371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,4160,272513,16,73736,8328,64,146509,5392,4096,406724,1500,272393,256,33,5456,74250]

theorem envBound38371 : H12AffineFastState.Bounded env38371 := by
  intro p hp
  have h : env38371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38370_38371 : H12AffineEnvironment.transform 20 4160 env38370 = env38371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38370 == env38371) = true)

theorem identity38371 : scanCanonicalize (H12AffineFastState.compose env38371 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38371 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,272392,16,73736,8193,64,146509,5392,4096,406605,1365,272393,256,33,5456,74250]

theorem envBound38372 : H12AffineFastState.Bounded env38372 := by
  intro p hp
  have h : env38372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38371_38372 : H12AffineEnvironment.transform 6 9 env38371 = env38372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38371 == env38372) = true)

theorem identity38372 : scanCanonicalize (H12AffineFastState.compose env38372 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 138512) := by decide +kernel

theorem selectedBound38372 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,138512,1024,8540,4160,144664,16,73736,8193,64,146509,5392,4096,10589,1365,144665,256,33,5456,74250]

theorem envBound38373 : H12AffineFastState.Bounded env38373 := by
  intro p hp
  have h : env38373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38372_38373 : H12AffineEnvironment.transform 17 138512 env38372 = env38373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138512 env38372 == env38373) = true)

theorem identity38373 : scanCanonicalize (H12AffineFastState.compose env38373 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound38373 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env38374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8574,131072,138512,1024,8540,4160,144664,16,374,8193,64,146509,5392,4096,10589,1365,144665,256,33,5456,884]

theorem envBound38374 : H12AffineFastState.Bounded env38374 := by
  intro p hp
  have h : env38374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38373_38374 : H12AffineEnvironment.transform 15 8574 env38373 = env38374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env38373 == env38374) = true)

theorem identity38374 : scanCanonicalize (H12AffineFastState.compose env38374 (packedSelected [0,2,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38374 : packedSelected [0,2,7,14,20] rootPS < 2^1333 := by decide +kernel

def env38375 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8232,8203,131072,138341,1024,8233,4160,144493,16,3,8193,64,146509,5221,4096,10280,1056,144492,117,33,5157,513]

theorem envBound38375 : H12AffineFastState.Bounded env38375 := by
  intro p hp
  have h : env38375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38374_38375 : H12AffineEnvironment.transform 7 117 env38374 = env38375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38374 == env38375) = true)

theorem identity38375 : scanCanonicalize (H12AffineFastState.compose env38375 (packedSelected [2,14] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound38375 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env38376 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8232,8203,5221,2048,1024,8233,4160,8200,16,3,8193,64,10280,5221,4096,10280,1056,8201,117,33,5157,513]

theorem envBound38376 : H12AffineFastState.Bounded env38376 := by
  intro p hp
  have h : env38376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38375_38376 : H12AffineEnvironment.transform 16 5221 env38375 = env38376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env38375 == env38376) = true)

theorem identity38376 : scanCanonicalize (H12AffineFastState.compose env38376 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound38376 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38377 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1,8192,1141,8232,8203,1124,2048,1024,8233,65,8200,16,3,8193,64,10280,1124,1,10280,1056,8201,117,33,1060,513]

theorem envBound38377 : H12AffineFastState.Bounded env38377 := by
  intro p hp
  have h : env38377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38376_38377 : H12AffineEnvironment.transform 11 1 env38376 = env38377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env38376 == env38377) = true)

theorem identity38377 : scanCanonicalize (H12AffineFastState.compose env38377 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound38377 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env38378 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1,2088,1141,2048,2083,1124,2048,1024,2049,65,2080,16,3,2089,64,0,1124,1,0,1056,2081,117,33,1060,513]

theorem envBound38378 : H12AffineFastState.Bounded env38378 := by
  intro p hp
  have h : env38378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38377_38378 : H12AffineEnvironment.transform 12 2088 env38377 = env38378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env38377 == env38378) = true)

theorem identity38378 : scanCanonicalize (H12AffineFastState.compose env38378 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38378 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env38379 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,1,2088,1061,2048,2083,1076,2048,1024,2049,17,2080,16,3,2089,16,0,1076,1,0,1056,2081,37,33,1060,513]

theorem envBound38379 : H12AffineFastState.Bounded env38379 := by
  intro p hp
  have h : env38379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38378_38379 : H12AffineEnvironment.transform 5 16 env38378 = env38379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38378 == env38379) = true)

theorem identity38379 : scanCanonicalize (H12AffineFastState.compose env38379 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound38379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38380 : List Nat := [2,4,8,16,32,16,9,37,512,1024,16,1,56,1061,16,51,1076,16,1024,17,17,48,16,3,57,16,0,1076,1,0,1056,49,37,33,1060,513]

theorem envBound38380 : H12AffineFastState.Bounded env38380 := by
  intro p hp
  have h : env38380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38379_38380 : H12AffineEnvironment.transform 10 16 env38379 = env38380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env38379 == env38380) = true)

theorem identity38380 : scanCanonicalize (H12AffineFastState.compose env38380 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38380 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38381 : List Nat := [2,4,8,0,32,0,9,37,512,1024,0,1,40,1061,0,35,1060,0,1024,1,1,32,0,3,41,0,0,1060,1,0,1056,33,37,33,1060,513]

theorem envBound38381 : H12AffineFastState.Bounded env38381 := by
  intro p hp
  have h : env38381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38380_38381 : H12AffineEnvironment.transform 3 0 env38380 = env38381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38380 == env38381) = true)

theorem identity38381 : scanCanonicalize (H12AffineFastState.compose env38381 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound38381 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38382 : List Nat := [2,4,8,0,32,0,9,37,512,548,0,1,40,513,0,35,512,0,548,1,1,32,0,3,41,0,0,512,1,0,516,33,37,33,512,513]

theorem envBound38382 : H12AffineFastState.Bounded env38382 := by
  intro p hp
  have h : env38382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38381_38382 : H12AffineEnvironment.transform 9 548 env38381 = env38382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env38381 == env38382) = true)

theorem identity38382 : scanCanonicalize (H12AffineFastState.compose env38382 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38382 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38383 : List Nat := [2,4,8,0,32,0,9,37,0,36,0,1,40,1,0,35,0,0,36,1,1,32,0,3,41,0,0,0,1,0,4,33,37,33,0,1]

theorem envBound38383 : H12AffineFastState.Bounded env38383 := by
  intro p hp
  have h : env38383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38382_38383 : H12AffineEnvironment.transform 8 0 env38382 = env38383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38382 == env38383) = true)

def env38384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,4161,272513,17,73736,8328,64,146508,5393,4096,406725,1501,272392,256,33,5456,74251]

theorem envBound38384 : H12AffineFastState.Bounded env38384 := by
  intro p hp
  have h : env38384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38370_38384 : H12AffineEnvironment.transform 20 4161 env38370 = env38384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38370 == env38384) = true)

theorem identity38384 : scanCanonicalize (H12AffineFastState.compose env38384 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38384 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10280,1024,8661,4161,169,17,73736,8328,64,146508,5393,4096,138477,1501,32,256,33,5456,74251]

theorem envBound38385 : H12AffineFastState.Bounded env38385 := by
  intro p hp
  have h : env38385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38384_38385 : H12AffineEnvironment.transform 17 10280 env38384 = env38385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38384 == env38385) = true)

theorem identity38385 : scanCanonicalize (H12AffineFastState.compose env38385 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound38385 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env38386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,5393,10280,1024,8661,4161,169,17,73736,8328,64,10589,5393,4096,2556,1501,32,256,33,5456,74251]

theorem envBound38386 : H12AffineFastState.Bounded env38386 := by
  intro p hp
  have h : env38386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38385_38386 : H12AffineEnvironment.transform 16 5393 env38385 = env38386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env38385 == env38386) = true)

theorem identity38386 : scanCanonicalize (H12AffineFastState.compose env38386 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound38386 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5377,112,65536,5393,2444,1024,113,4161,169,17,65964,300,64,2297,5393,4096,2556,1501,32,256,33,5456,66479]

theorem envBound38387 : H12AffineFastState.Bounded env38387 := by
  intro p hp
  have h : env38387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38386_38387 : H12AffineEnvironment.transform 12 420 env38386 = env38387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env38386 == env38387) = true)

theorem identity38387 : scanCanonicalize (H12AffineFastState.compose env38387 (packedSelected [2,6,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38387 : packedSelected [2,6,16,20] rootPS < 2^1333 := by decide +kernel

def env38388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,5377,112,65536,5393,2308,1024,113,4161,33,17,65828,300,64,2161,5393,4096,2420,1365,32,256,33,5456,66343]

theorem envBound38388 : H12AffineFastState.Bounded env38388 := by
  intro p hp
  have h : env38388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38387_38388 : H12AffineEnvironment.transform 6 8 env38387 = env38388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38387 == env38388) = true)

theorem identity38388 : scanCanonicalize (H12AffineFastState.compose env38388 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound38388 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,5377,112,294,5393,2308,1024,113,4161,33,17,2,300,64,2161,5393,4096,2420,1365,32,256,33,5456,513]

theorem envBound38389 : H12AffineFastState.Bounded env38389 := by
  intro p hp
  have h : env38389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38388_38389 : H12AffineEnvironment.transform 15 294 env38388 = env38389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env38388 == env38389) = true)

def env38390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98781,8328,64,6705549,2098513,17664,2543696,2102684,6349852,256,21792,46212,2175562]

theorem envBound38390 : H12AffineFastState.Bounded env38390 := by
  intro p hp
  have h : env38390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38312_38390 : H12AffineEnvironment.transform 22 2101329 env38312 = env38390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env38312 == env38390) = true)

def env38391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98781,8328,64,2259213,2098513,17664,2543696,2102684,2411676,256,21792,46212,2175562]

theorem envBound38391 : H12AffineFastState.Bounded env38391 := by
  intro p hp
  have h : env38391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38390_38391 : H12AffineEnvironment.transform 21 272512 env38390 = env38391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38390 == env38391) = true)

theorem identity38391 : scanCanonicalize (H12AffineFastState.compose env38391 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound38391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,272512,16,98781,8328,64,158028,5392,17664,442385,1501,318685,256,21792,46212,74251]

theorem envBound38392 : H12AffineFastState.Bounded env38392 := by
  intro p hp
  have h : env38392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38391_38392 : H12AffineEnvironment.transform 20 4161 env38391 = env38392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38391 == env38392) = true)

theorem identity38392 : scanCanonicalize (H12AffineFastState.compose env38392 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38392 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,272512,16,41431,8328,64,158028,5392,17664,442385,1501,318685,256,21792,46212,513]

theorem envBound38393 : H12AffineFastState.Bounded env38393 := by
  intro p hp
  have h : env38393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38392_38393 : H12AffineEnvironment.transform 15 8202 env38392 = env38393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38392 == env38393) = true)

theorem identity38393 : scanCanonicalize (H12AffineFastState.compose env38393 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound38393 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4161,272512,16,41431,8328,64,56657,5392,17664,291852,1501,318685,256,21792,46212,513]

theorem envBound38394 : H12AffineFastState.Bounded env38394 := by
  intro p hp
  have h : env38394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38393_38394 : H12AffineEnvironment.transform 16 46109 env38393 = env38394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env38393 == env38394) = true)

def env38395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4161,272392,16,41311,8192,64,56657,5392,17664,291852,1365,318549,256,21792,46092,513]

theorem envBound38395 : H12AffineFastState.Bounded env38395 := by
  intro p hp
  have h : env38395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38394_38395 : H12AffineEnvironment.transform 6 8 env38394 = env38395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38394 == env38395) = true)

theorem identity38395 : scanCanonicalize (H12AffineFastState.compose env38395 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,5440,262144,1024,8540,4161,272392,16,2,8192,64,31756,5392,17664,291852,1365,294152,256,21792,5457,513]

theorem envBound38396 : H12AffineFastState.Bounded env38396 := by
  intro p hp
  have h : env38396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38395_38396 : H12AffineEnvironment.transform 14 8541 env38395 = env38396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38395 == env38396) = true)

theorem identity38396 : scanCanonicalize (H12AffineFastState.compose env38396 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound38396 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,5440,2129,1024,8540,4161,8281,16,2,8192,64,31756,5392,17664,31837,1365,30041,256,21792,5457,513]

theorem envBound38397 : H12AffineFastState.Bounded env38397 := by
  intro p hp
  have h : env38397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38396_38397 : H12AffineEnvironment.transform 17 2129 env38396 = env38397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env38396 == env38397) = true)

theorem identity38397 : scanCanonicalize (H12AffineFastState.compose env38397 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38397 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38398 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,8202,4176,2129,272,8540,4161,8281,16,2,8192,64,31004,4096,16400,31053,69,28745,256,20528,4161,513]

theorem envBound38398 : H12AffineFastState.Bounded env38398 := by
  intro p hp
  have h : env38398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38397_38398 : H12AffineEnvironment.transform 9 272 env38397 = env38398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38397 == env38398) = true)

theorem identity38398 : scanCanonicalize (H12AffineFastState.compose env38398 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound38398 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env38399 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8541,8202,4176,2129,272,8540,4161,8281,16,2,8192,64,10508,4096,4096,10589,69,8281,256,32,4161,513]

theorem envBound38399 : H12AffineFastState.Bounded env38399 := by
  intro p hp
  have h : env38399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38398_38399 : H12AffineEnvironment.transform 13 4112 env38398 = env38399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env38398 == env38399) = true)

theorem identity38399 : scanCanonicalize (H12AffineFastState.compose env38399 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38399 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38400 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,373,34,4176,2129,272,372,4161,113,16,2,40,64,2340,4096,4096,2421,69,113,256,32,4161,513]

theorem envBound38400 : H12AffineFastState.Bounded env38400 := by
  intro p hp
  have h : env38400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38399_38400 : H12AffineEnvironment.transform 12 40 env38399 = env38400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38399 == env38400) = true)

theorem identity38400 : scanCanonicalize (H12AffineFastState.compose env38400 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38400 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env38401 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,40,4112,293,34,4096,2049,272,292,4113,33,16,2,40,16,2340,4096,4096,2341,21,33,256,32,4113,513]

theorem envBound38401 : H12AffineFastState.Bounded env38401 := by
  intro p hp
  have h : env38401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38400_38401 : H12AffineEnvironment.transform 5 16 env38400 = env38401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38400 == env38401) = true)

theorem identity38401 : scanCanonicalize (H12AffineFastState.compose env38401 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38402 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,40,4112,0,34,4096,2049,53,1,4113,33,16,2,40,16,2049,4096,4096,2048,21,33,37,32,4113,513]

theorem envBound38402 : H12AffineFastState.Bounded env38402 := by
  intro p hp
  have h : env38402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38401_38402 : H12AffineEnvironment.transform 7 37 env38401 = env38402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38401 == env38402) = true)

theorem identity38402 : scanCanonicalize (H12AffineFastState.compose env38402 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound38402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38403 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,4096,40,4112,0,34,4096,48,53,1,4113,33,16,2,40,16,48,4096,4096,49,21,33,37,32,4113,513]

theorem envBound38403 : H12AffineFastState.Bounded env38403 := by
  intro p hp
  have h : env38403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38402_38403 : H12AffineEnvironment.transform 10 49 env38402 = env38403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env38402 == env38403) = true)

theorem identity38403 : scanCanonicalize (H12AffineFastState.compose env38403 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound38403 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38404 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,40,48,0,34,32,48,53,1,49,33,16,2,40,16,48,32,32,49,21,33,37,32,49,513]

theorem envBound38404 : H12AffineFastState.Bounded env38404 := by
  intro p hp
  have h : env38404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38403_38404 : H12AffineEnvironment.transform 11 32 env38403 = env38404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env38403 == env38404) = true)

def leafEnv38404 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,40,48,0,34,32,48,53,1,49,33,16,2,21,40,1,16,48,32,32,49,21,33,37,32,4,34,49,513,1,48,0]

def active38404 : List Nat := [0,1,2,3,4,8]

def tree38404 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38404 : H12WitnessSearch.Good tree38404 := H12GlobalWitnessIndex.good

theorem leafIdentity38404 : H12AffineFastState.composeSystem env38404 rootObs = leafEnv38404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38404 rootObs == leafEnv38404) = true)

theorem terminalChecked38404 : H12PackedTerminal.terminalCheckFast leafEnv38404 active38404 tree38404 = true := by decide +kernel

def env38405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4161,272393,16,41310,8193,64,56657,5392,17664,291852,1364,318548,256,21792,46093,513]

theorem envBound38405 : H12AffineFastState.Bounded env38405 := by
  intro p hp
  have h : env38405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38394_38405 : H12AffineEnvironment.transform 6 9 env38394 = env38405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38394 == env38405) = true)

theorem identity38405 : scanCanonicalize (H12AffineFastState.compose env38405 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound38405 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env38406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16449,262144,1024,29789,4161,272393,16,21762,8193,64,10509,5392,17664,291852,1364,272392,256,21792,16465,513]

theorem envBound38406 : H12AffineFastState.Bounded env38406 := by
  intro p hp
  have h : env38406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38405_38406 : H12AffineEnvironment.transform 14 29788 env38405 = env38406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env38405 == env38406) = true)

theorem identity38406 : scanCanonicalize (H12AffineFastState.compose env38406 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound38406 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16449,2341,1024,29789,4161,8492,16,21762,8193,64,10509,5392,17664,32041,1364,8493,256,21792,16465,513]

theorem envBound38407 : H12AffineFastState.Bounded env38407 := by
  intro p hp
  have h : env38407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38406_38407 : H12AffineEnvironment.transform 17 2341 env38406 = env38407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env38406 == env38407) = true)

theorem identity38407 : scanCanonicalize (H12AffineFastState.compose env38407 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38407 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38408 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,16400,2341,1024,29708,4112,8492,16,21762,8193,17,10509,5392,17664,32041,1285,8493,256,21792,16384,513]

theorem envBound38408 : H12AffineFastState.Bounded env38408 := by
  intro p hp
  have h : env38408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38407_38408 : H12AffineEnvironment.transform 5 17 env38407 = env38408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38407 == env38408) = true)

theorem identity38408 : scanCanonicalize (H12AffineFastState.compose env38408 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38408 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env38409 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,263,16400,2341,1024,21761,4112,33,16,21762,268,17,2048,5392,17664,23588,1285,32,256,21792,16384,513]

theorem envBound38409 : H12AffineFastState.Bounded env38409 := by
  intro p hp
  have h : env38409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38408_38409 : H12AffineEnvironment.transform 12 269 env38408 = env38409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38408 == env38409) = true)

theorem identity38409 : scanCanonicalize (H12AffineFastState.compose env38409 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38409 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38410 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1024,0,4112,33,16,3,268,17,2048,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound38410 : H12AffineFastState.Bounded env38410 := by
  intro p hp
  have h : env38410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38409_38410 : H12AffineEnvironment.transform 13 5377 env38409 = env38410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38409 == env38410) = true)

theorem identity38410 : scanCanonicalize (H12AffineFastState.compose env38410 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38411 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5173,2049,1024,0,4112,33,16,3,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound38411 : H12AffineFastState.Bounded env38411 := by
  intro p hp
  have h : env38411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38410_38411 : H12AffineEnvironment.transform 7 36 env38410 = env38411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38410 == env38411) = true)

def env38412 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,1,35,1029,2049,1024,0,32,33,16,3,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound38412 : H12AffineFastState.Bounded env38412 := by
  intro p hp
  have h : env38412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38411_38412 : H12AffineEnvironment.transform 11 48 env38411 = env38412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38411 == env38412) = true)

def env38413 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,1,35,1028,2049,1024,0,33,33,16,3,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound38413 : H12AffineFastState.Bounded env38413 := by
  intro p hp
  have h : env38413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38411_38413 : H12AffineEnvironment.transform 11 49 env38411 = env38413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38411 == env38413) = true)

theorem identity38413 : scanCanonicalize (H12AffineFastState.compose env38413 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38414 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,49,41,33,1,35,49,2049,53,0,33,33,16,3,40,17,2048,48,48,2049,20,32,36,33,33,513]

theorem envBound38414 : H12AffineFastState.Bounded env38414 := by
  intro p hp
  have h : env38414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38413_38414 : H12AffineEnvironment.transform 9 53 env38413 = env38414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38413 == env38414) = true)

def env38415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98781,8328,64,2259212,2098513,17664,2543696,2102684,2411677,256,21792,46212,2175562]

theorem envBound38415 : H12AffineFastState.Bounded env38415 := by
  intro p hp
  have h : env38415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38390_38415 : H12AffineEnvironment.transform 21 272513 env38390 = env38415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38390 == env38415) = true)

def env38416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272393,2101329,98645,8192,64,2259212,2098513,17664,2543696,2102548,2411541,256,21792,46092,2175562]

theorem envBound38416 : H12AffineFastState.Bounded env38416 := by
  intro p hp
  have h : env38416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38415_38416 : H12AffineEnvironment.transform 6 8 env38415 = env38416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38415 == env38416) = true)

theorem identity38416 : scanCanonicalize (H12AffineFastState.compose env38416 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound38416 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,272393,2101329,98645,8192,64,2111773,2098513,17664,2396225,2102548,2411541,256,21792,46092,2175562]

theorem envBound38417 : H12AffineFastState.Bounded env38417 := by
  intro p hp
  have h : env38417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38416_38417 : H12AffineEnvironment.transform 16 16401 env38416 = env38417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env38416 == env38417) = true)

def env38418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,4160,272393,17,98645,8192,64,10589,5393,17664,294913,1364,318549,256,21792,46092,74250]

theorem envBound38418 : H12AffineFastState.Bounded env38418 := by
  intro p hp
  have h : env38418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38417_38418 : H12AffineEnvironment.transform 20 4160 env38417 = env38418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38417 == env38418) = true)

theorem identity38418 : scanCanonicalize (H12AffineFastState.compose env38418 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound38418 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1024,32769,4160,41341,17,98645,8192,64,10589,5393,17664,2421,1364,21793,256,21792,46092,74250]

theorem envBound38419 : H12AffineFastState.Bounded env38419 := by
  intro p hp
  have h : env38419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38418_38419 : H12AffineEnvironment.transform 17 35188 env38418 = env38419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env38418 == env38419) = true)

theorem identity38419 : scanCanonicalize (H12AffineFastState.compose env38419 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound38419 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env38420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62810,16401,35188,1024,32769,4160,41341,17,29711,8192,64,10589,5393,17664,2421,1364,21793,256,21792,46092,55120]

theorem envBound38420 : H12AffineFastState.Bounded env38420 := by
  intro p hp
  have h : env38420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38419_38420 : H12AffineEnvironment.transform 15 62810 env38419 = env38420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env38419 == env38420) = true)

theorem identity38420 : scanCanonicalize (H12AffineFastState.compose env38420 (packedSelected [0,1,4,10,11,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38420 : packedSelected [0,1,4,10,11,15,20,24] rootPS < 2^1333 := by decide +kernel

def env38421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21511,16401,10281,1024,8540,4160,32,17,29711,8192,64,10589,5393,17664,2421,1364,21793,256,21792,5457,30221]

theorem envBound38421 : H12AffineFastState.Bounded env38421 := by
  intro p hp
  have h : env38421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38420_38421 : H12AffineEnvironment.transform 14 8541 env38420 = env38421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38420 == env38421) = true)

theorem identity38421 : scanCanonicalize (H12AffineFastState.compose env38421 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound38421 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4453,8541,1378,4468,10281,1024,8540,4160,32,17,9578,8192,64,10589,5393,5221,2421,1364,1092,256,1093,5457,10088]

theorem envBound38422 : H12AffineFastState.Bounded env38422 := by
  intro p hp
  have h : env38422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38421_38422 : H12AffineEnvironment.transform 13 4453 env38421 = env38422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env38421 == env38422) = true)

theorem identity38422 : scanCanonicalize (H12AffineFastState.compose env38422 (packedSelected [0,3,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38422 : packedSelected [0,3,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env38423 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,4453,8541,343,4468,10281,53,8540,4160,32,17,8543,8192,64,10589,4388,4176,2421,353,113,256,112,4452,9053]

theorem envBound38423 : H12AffineFastState.Bounded env38423 := by
  intro p hp
  have h : env38423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38422_38423 : H12AffineEnvironment.transform 9 53 env38422 = env38423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38422 == env38423) = true)

theorem identity38423 : scanCanonicalize (H12AffineFastState.compose env38423 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38423 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env38424 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,8192,4404,8460,262,4389,10281,53,8461,4113,32,17,8462,8192,17,10508,4388,4097,2340,304,32,256,33,4405,8972]

theorem envBound38424 : H12AffineFastState.Bounded env38424 := by
  intro p hp
  have h : env38424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38423_38424 : H12AffineEnvironment.transform 5 17 env38423 = env38424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38423 == env38424) = true)

theorem identity38424 : scanCanonicalize (H12AffineFastState.compose env38424 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38424 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38425 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,4113,8233,35,4096,10281,53,8232,4113,32,17,8235,8192,17,10281,4097,4097,2049,21,32,37,33,4112,8745]

theorem envBound38425 : H12AffineFastState.Bounded env38425 := by
  intro p hp
  have h : env38425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38424_38425 : H12AffineEnvironment.transform 7 37 env38424 = env38425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38424 == env38425) = true)

theorem identity38425 : scanCanonicalize (H12AffineFastState.compose env38425 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38425 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38426 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,0,8192,17,8233,35,0,10281,53,8232,17,32,17,8235,8192,17,10281,1,1,2049,21,32,37,33,16,8745]

theorem envBound38426 : H12AffineFastState.Bounded env38426 := by
  intro p hp
  have h : env38426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38425_38426 : H12AffineEnvironment.transform 11 0 env38425 = env38426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38425 == env38426) = true)

theorem identity38426 : scanCanonicalize (H12AffineFastState.compose env38426 (packedSelected [1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38426 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env38427 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,0,41,17,0,35,0,2048,53,1,17,32,17,2,41,17,2048,1,1,2049,21,32,37,33,16,512]

theorem envBound38427 : H12AffineFastState.Bounded env38427 := by
  intro p hp
  have h : env38427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38426_38427 : H12AffineEnvironment.transform 12 41 env38426 = env38427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38426 == env38427) = true)

theorem identity38427 : scanCanonicalize (H12AffineFastState.compose env38427 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound38427 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38428 : List Nat := [2,4,8,16,32,17,8,37,47,53,2048,0,41,17,0,35,0,2048,53,1,17,32,17,2,41,17,2048,1,1,2049,21,32,37,33,16,47]

theorem envBound38428 : H12AffineFastState.Bounded env38428 := by
  intro p hp
  have h : env38428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38427_38428 : H12AffineEnvironment.transform 8 47 env38427 = env38428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env38427 == env38428) = true)

theorem identity38428 : scanCanonicalize (H12AffineFastState.compose env38428 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound38428 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38429 : List Nat := [2,4,8,14,32,15,8,37,47,43,2048,0,41,15,0,35,0,2048,43,1,15,32,15,2,41,15,2048,1,1,2049,11,32,37,33,14,47]

theorem envBound38429 : H12AffineFastState.Bounded env38429 := by
  intro p hp
  have h : env38429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38428_38429 : H12AffineEnvironment.transform 3 14 env38428 = env38429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env38428 == env38429) = true)

theorem identity38429 : scanCanonicalize (H12AffineFastState.compose env38429 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound38429 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38430 : List Nat := [2,4,8,14,32,15,8,37,47,43,14,0,41,15,0,35,0,14,43,1,15,32,15,2,41,15,14,1,1,15,11,32,37,33,14,47]

theorem envBound38430 : H12AffineFastState.Bounded env38430 := by
  intro p hp
  have h : env38430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38429_38430 : H12AffineEnvironment.transform 10 14 env38429 = env38430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env38429 == env38430) = true)

theorem identity38430 : scanCanonicalize (H12AffineFastState.compose env38430 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38430 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38431 : List Nat := [2,4,8,14,1,15,8,4,14,10,14,0,8,15,0,2,0,14,10,1,15,1,15,2,8,15,14,1,1,15,11,1,4,0,14,14]

theorem envBound38431 : H12AffineFastState.Bounded env38431 := by
  intro p hp
  have h : env38431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38430_38431 : H12AffineEnvironment.transform 4 1 env38430 = env38431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38430 == env38431) = true)

theorem identity38431 : scanCanonicalize (H12AffineFastState.compose env38431 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound38431 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env38432 : List Nat := [2,4,7,1,1,0,7,4,1,5,1,0,7,0,0,2,0,1,5,1,0,1,0,2,7,0,1,1,1,0,4,1,4,0,1,1]

theorem envBound38432 : H12AffineFastState.Bounded env38432 := by
  intro p hp
  have h : env38432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38431_38432 : H12AffineEnvironment.transform 2 7 env38431 = env38432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env38431 == env38432) = true)

def env38433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,4161,272393,16,98645,8192,64,10588,5392,17664,294912,1365,318548,256,21792,46092,74251]

theorem envBound38433 : H12AffineFastState.Bounded env38433 := by
  intro p hp
  have h : env38433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38417_38433 : H12AffineEnvironment.transform 20 4161 env38417 = env38433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38417 == env38433) = true)

theorem identity38433 : scanCanonicalize (H12AffineFastState.compose env38433 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,4161,272393,16,73736,8192,64,10588,5392,17664,270685,1365,294153,256,21792,5457,74251]

theorem envBound38434 : H12AffineFastState.Bounded env38434 := by
  intro p hp
  have h : env38434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38433_38434 : H12AffineEnvironment.transform 14 8541 env38433 = env38434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38433 == env38434) = true)

theorem identity38434 : scanCanonicalize (H12AffineFastState.compose env38434 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38434 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env38435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1024,8540,4161,272393,16,2,8192,64,10588,5392,17664,270685,1365,294153,256,21792,5457,513]

theorem envBound38435 : H12AffineFastState.Bounded env38435 := by
  intro p hp
  have h : env38435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38434_38435 : H12AffineEnvironment.transform 15 8202 env38434 = env38435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38434 == env38435) = true)

theorem identity38435 : scanCanonicalize (H12AffineFastState.compose env38435 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound38435 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2309,1024,8540,4161,8460,16,2,8192,64,10588,5392,17664,10328,1365,29708,256,21792,5457,513]

theorem envBound38436 : H12AffineFastState.Bounded env38436 := by
  intro p hp
  have h : env38436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38435_38436 : H12AffineEnvironment.transform 17 2309 env38435 = env38436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env38435 == env38436) = true)

theorem identity38436 : scanCanonicalize (H12AffineFastState.compose env38436 (packedSelected [6,14] rootPS)) = affineNative (2^(13+1) ^^^ 12604) := by decide +kernel

theorem selectedBound38436 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env38437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12604,8541,8202,12589,2309,1024,8540,4161,8460,16,2,8192,64,10588,5392,13372,10328,1365,1328,256,9244,5457,513]

theorem envBound38437 : H12AffineFastState.Bounded env38437 := by
  intro p hp
  have h : env38437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38436_38437 : H12AffineEnvironment.transform 13 12604 env38436 = env38437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12604 env38436 == env38437) = true)

theorem identity38437 : scanCanonicalize (H12AffineFastState.compose env38437 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38437 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4193,0,343,4208,2309,1024,1,4161,81,16,2,349,64,2049,5392,5473,2309,1365,1328,256,1345,5457,513]

theorem envBound38438 : H12AffineFastState.Bounded env38438 := by
  intro p hp
  have h : env38438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38437_38438 : H12AffineEnvironment.transform 12 349 env38437 = env38438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38437 == env38438) = true)

theorem identity38438 : scanCanonicalize (H12AffineFastState.compose env38438 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2161) := by decide +kernel

theorem selectedBound38438 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2161,349,2064,0,343,2049,2309,1024,1,2096,81,16,2,349,64,2049,3425,3344,2309,1365,1328,256,1345,3360,513]

theorem envBound38439 : H12AffineFastState.Bounded env38439 := by
  intro p hp
  have h : env38439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38438_38439 : H12AffineEnvironment.transform 11 2161 env38438 = env38439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2161 env38438 == env38439) = true)

theorem identity38439 : scanCanonicalize (H12AffineFastState.compose env38439 (packedSelected [1,8,19] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38439 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env38440 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2161,349,2064,0,343,2049,2309,273,1,2096,81,16,2,349,64,2049,2160,2049,2309,68,33,256,80,2097,513]

theorem envBound38440 : H12AffineFastState.Bounded env38440 := by
  intro p hp
  have h : env38440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38439_38440 : H12AffineEnvironment.transform 9 273 env38439 = env38440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38439 == env38440) = true)

theorem identity38440 : scanCanonicalize (H12AffineFastState.compose env38440 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound38440 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38441 : List Nat := [2,4,8,16,32,64,8,256,512,273,293,340,349,309,0,343,292,32,273,1,277,81,16,2,349,64,292,341,292,32,68,33,256,80,276,513]

theorem envBound38441 : H12AffineFastState.Bounded env38441 := by
  intro p hp
  have h : env38441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38440_38441 : H12AffineEnvironment.transform 10 293 env38440 = env38441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env38440 == env38441) = true)

theorem identity38441 : scanCanonicalize (H12AffineFastState.compose env38441 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38441 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38442 : List Nat := [2,4,8,16,0,64,8,256,512,273,261,340,349,277,0,343,260,0,273,1,277,81,16,2,349,64,260,341,260,0,68,1,256,80,276,513]

theorem envBound38442 : H12AffineFastState.Bounded env38442 := by
  intro p hp
  have h : env38442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38441_38442 : H12AffineEnvironment.transform 4 0 env38441 = env38442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38441 == env38442) = true)

theorem identity38442 : scanCanonicalize (H12AffineFastState.compose env38442 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 334) := by decide +kernel

theorem selectedBound38442 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38443 : List Nat := [2,4,8,16,0,64,8,256,334,273,261,340,349,277,0,343,260,0,273,1,277,81,16,2,349,64,260,341,260,0,68,1,256,80,276,335]

theorem envBound38443 : H12AffineFastState.Bounded env38443 := by
  intro p hp
  have h : env38443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38442_38443 : H12AffineEnvironment.transform 8 334 env38442 = env38443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 334 env38442 == env38443) = true)

theorem identity38443 : scanCanonicalize (H12AffineFastState.compose env38443 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38443 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38444 : List Nat := [2,4,3,16,0,64,3,256,325,273,261,340,342,277,0,343,260,0,273,1,277,81,16,2,342,64,260,341,260,0,68,1,256,80,276,324]

theorem envBound38444 : H12AffineFastState.Bounded env38444 := by
  intro p hp
  have h : env38444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38443_38444 : H12AffineEnvironment.transform 2 3 env38443 = env38444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38443 == env38444) = true)

theorem identity38444 : scanCanonicalize (H12AffineFastState.compose env38444 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound38444 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38445 : List Nat := [2,4,3,16,0,64,3,67,6,82,70,23,21,86,0,20,71,0,82,1,86,81,16,2,21,64,71,22,71,0,68,1,67,80,87,7]

theorem envBound38445 : H12AffineFastState.Bounded env38445 := by
  intro p hp
  have h : env38445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38444_38445 : H12AffineEnvironment.transform 7 67 env38444 = env38445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env38444 == env38445) = true)

theorem identity38445 : scanCanonicalize (H12AffineFastState.compose env38445 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38445 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env38446 : List Nat := [2,4,3,0,0,64,3,67,6,66,70,7,5,70,0,4,71,0,66,1,70,65,0,2,5,64,71,6,71,0,68,1,67,64,71,7]

theorem envBound38446 : H12AffineFastState.Bounded env38446 := by
  intro p hp
  have h : env38446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38445_38446 : H12AffineEnvironment.transform 3 0 env38445 = env38446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38445 == env38446) = true)

theorem identity38446 : scanCanonicalize (H12AffineFastState.compose env38446 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38447 : List Nat := [2,1,3,0,0,64,3,67,3,66,67,2,0,67,0,1,66,0,66,1,67,65,0,2,0,64,66,3,66,0,65,1,67,64,66,2]

theorem envBound38447 : H12AffineFastState.Bounded env38447 := by
  intro p hp
  have h : env38447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38446_38447 : H12AffineEnvironment.transform 1 1 env38446 = env38447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38446 == env38447) = true)

theorem identity38447 : scanCanonicalize (H12AffineFastState.compose env38447 (packedSelected [0,11] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound38447 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env38448 : List Nat := [2,1,3,0,0,3,3,0,3,1,0,2,0,0,0,1,1,0,1,1,0,2,0,2,0,3,1,3,1,0,2,1,0,3,1,2]

theorem envBound38448 : H12AffineFastState.Bounded env38448 := by
  intro p hp
  have h : env38448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38447_38448 : H12AffineEnvironment.transform 5 3 env38447 = env38448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env38447 == env38448) = true)

def env38449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272392,2101329,98644,8193,64,2259212,2098513,17664,2543696,2102549,2411540,256,21792,46093,2175562]

theorem envBound38449 : H12AffineFastState.Bounded env38449 := by
  intro p hp
  have h : env38449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38415_38449 : H12AffineEnvironment.transform 6 9 env38415 = env38449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38415 == env38449) = true)

theorem identity38449 : scanCanonicalize (H12AffineFastState.compose env38449 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound38449 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272392,73754,98644,8193,64,215367,79130,17664,516123,75102,392287,256,21792,46093,513]

theorem envBound38450 : H12AffineFastState.Bounded env38450 := by
  intro p hp
  have h : env38450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38449_38450 : H12AffineEnvironment.transform 20 77899 env38449 = env38450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env38449 == env38450) = true)

def env38451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,32,73754,98644,8193,64,215367,79130,17664,247859,75102,119927,256,21792,46093,513]

theorem envBound38451 : H12AffineFastState.Bounded env38451 := by
  intro p hp
  have h : env38451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38450_38451 : H12AffineEnvironment.transform 17 10280 env38450 = env38451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38450 == env38451) = true)

def env38452 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,32,73754,98564,8193,16,215319,79130,17664,247859,75022,119847,256,21792,46093,513]

theorem envBound38452 : H12AffineFastState.Bounded env38452 := by
  intro p hp
  have h : env38452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38451_38452 : H12AffineEnvironment.transform 5 16 env38451 = env38452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38451 == env38452) = true)

theorem identity38452 : scanCanonicalize (H12AffineFastState.compose env38452 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38452 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38453 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,10280,1024,0,77851,32,73754,65797,8193,16,215319,79130,17664,215090,75022,87078,256,21792,13324,513]

theorem envBound38453 : H12AffineFastState.Bounded env38453 := by
  intro p hp
  have h : env38453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38452_38453 : H12AffineEnvironment.transform 14 1 env38452 = env38453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38452 == env38453) = true)

theorem identity38453 : scanCanonicalize (H12AffineFastState.compose env38453 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound38453 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env38454 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,5393,10280,1024,0,77851,32,73754,65797,8193,16,89094,79130,17664,89379,75022,87078,256,21792,13324,513]

theorem envBound38454 : H12AffineFastState.Bounded env38454 := by
  intro p hp
  have h : env38454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38453_38454 : H12AffineEnvironment.transform 16 5393 env38453 = env38454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env38453 == env38454) = true)

theorem identity38454 : scanCanonicalize (H12AffineFastState.compose env38454 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound38454 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38455 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,262,5393,10280,1024,0,12573,32,8476,3,8193,16,23808,13340,17664,23589,9224,21792,256,21792,13324,513]

theorem envBound38455 : H12AffineFastState.Bounded env38455 := by
  intro p hp
  have h : env38455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38454_38455 : H12AffineEnvironment.transform 15 262 env38454 = env38455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env38454 == env38455) = true)

theorem identity38455 : scanCanonicalize (H12AffineFastState.compose env38455 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound38455 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38456 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,1,262,5393,10280,1024,0,12573,32,8476,3,8193,16,10508,13340,12556,10281,9224,8492,256,8492,13324,513]

theorem envBound38456 : H12AffineFastState.Bounded env38456 := by
  intro p hp
  have h : env38456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38455_38456 : H12AffineEnvironment.transform 13 13324 env38455 = env38456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env38455 == env38456) = true)

theorem identity38456 : scanCanonicalize (H12AffineFastState.compose env38456 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38456 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38457 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1024,0,4113,32,16,3,269,16,2048,5392,4096,2341,1284,32,256,32,5376,513]

theorem envBound38457 : H12AffineFastState.Bounded env38457 := by
  intro p hp
  have h : env38457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38456_38457 : H12AffineEnvironment.transform 12 268 env38456 = env38457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38456 == env38457) = true)

theorem identity38457 : scanCanonicalize (H12AffineFastState.compose env38457 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound38457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38458 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,32,268,1312,1,262,1329,2340,1024,0,49,32,16,3,269,16,2048,1328,32,2341,1284,32,256,32,1312,513]

theorem envBound38458 : H12AffineFastState.Bounded env38458 := by
  intro p hp
  have h : env38458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38457_38458 : H12AffineEnvironment.transform 11 32 env38457 = env38458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env38457 == env38458) = true)

theorem identity38458 : scanCanonicalize (H12AffineFastState.compose env38458 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound38458 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38459 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1323,32,268,1312,1,262,1329,1039,1024,0,49,32,16,3,269,16,1323,1328,32,1038,1284,32,256,32,1312,513]

theorem envBound38459 : H12AffineFastState.Bounded env38459 := by
  intro p hp
  have h : env38459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38458_38459 : H12AffineEnvironment.transform 10 1323 env38458 = env38459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env38458 == env38459) = true)

theorem identity38459 : scanCanonicalize (H12AffineFastState.compose env38459 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound38459 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38460 : List Nat := [2,4,8,16,32,16,9,256,270,1024,1323,32,268,1312,1,262,1329,1039,1024,0,49,32,16,3,269,16,1323,1328,32,1038,1284,32,256,32,1312,271]

theorem envBound38460 : H12AffineFastState.Bounded env38460 := by
  intro p hp
  have h : env38460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38459_38460 : H12AffineEnvironment.transform 8 270 env38459 = env38460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env38459 == env38460) = true)

theorem identity38460 : scanCanonicalize (H12AffineFastState.compose env38460 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound38460 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38461 : List Nat := [2,4,8,16,32,16,9,30,16,1024,1077,32,18,1086,1,24,1071,1039,1024,0,49,32,16,3,19,16,1077,1070,32,1038,1050,32,30,32,1086,17]

theorem envBound38461 : H12AffineFastState.Bounded env38461 := by
  intro p hp
  have h : env38461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38460_38461 : H12AffineEnvironment.transform 7 30 env38460 = env38461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env38460 == env38461) = true)

theorem identity38461 : scanCanonicalize (H12AffineFastState.compose env38461 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound38461 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38462 : List Nat := [2,4,8,16,32,16,9,30,16,46,27,32,18,16,1,24,1,33,46,0,49,32,16,3,19,16,27,0,32,32,52,32,30,32,16,17]

theorem envBound38462 : H12AffineFastState.Bounded env38462 := by
  intro p hp
  have h : env38462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38461_38462 : H12AffineEnvironment.transform 9 46 env38461 = env38462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env38461 == env38462) = true)

theorem identity38462 : scanCanonicalize (H12AffineFastState.compose env38462 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38462 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38463 : List Nat := [2,4,8,0,32,0,9,14,0,46,11,32,2,0,1,8,1,33,46,0,33,32,0,3,3,0,11,0,32,32,36,32,14,32,0,1]

theorem envBound38463 : H12AffineFastState.Bounded env38463 := by
  intro p hp
  have h : env38463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38462_38463 : H12AffineEnvironment.transform 3 0 env38462 = env38463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38462 == env38463) = true)

theorem identity38463 : scanCanonicalize (H12AffineFastState.compose env38463 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound38463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38464 : List Nat := [2,4,8,0,15,0,9,14,0,1,11,15,2,0,1,8,1,14,1,0,14,15,0,3,3,0,11,0,15,15,11,15,14,15,0,1]

theorem envBound38464 : H12AffineFastState.Bounded env38464 := by
  intro p hp
  have h : env38464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38463_38464 : H12AffineEnvironment.transform 4 15 env38463 = env38464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env38463 == env38464) = true)

theorem identity38464 : scanCanonicalize (H12AffineFastState.compose env38464 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38464 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env38465 : List Nat := [2,4,2,0,5,0,3,4,0,1,1,5,2,0,1,2,1,4,1,0,4,5,0,3,3,0,1,0,5,5,1,5,4,5,0,1]

theorem envBound38465 : H12AffineFastState.Bounded env38465 := by
  intro p hp
  have h : env38465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38464_38465 : H12AffineEnvironment.transform 2 2 env38464 = env38465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38464 == env38465) = true)

theorem identity38465 : scanCanonicalize (H12AffineFastState.compose env38465 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38466 : List Nat := [2,3,2,0,2,0,3,3,0,1,1,2,2,0,1,2,1,3,1,0,3,2,0,3,3,0,1,0,2,2,1,2,3,2,0,1]

theorem envBound38466 : H12AffineFastState.Bounded env38466 := by
  intro p hp
  have h : env38466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38465_38466 : H12AffineEnvironment.transform 1 3 env38465 = env38466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38465 == env38466) = true)

def env38467 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,32,73754,98565,8193,17,215318,79130,17664,247859,75023,119846,256,21792,46093,513]

theorem envBound38467 : H12AffineFastState.Bounded env38467 := by
  intro p hp
  have h : env38467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38451_38467 : H12AffineEnvironment.transform 5 17 env38451 = env38467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38451 == env38467) = true)

theorem identity38467 : scanCanonicalize (H12AffineFastState.compose env38467 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38467 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38468 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,131072,10280,1024,32769,12573,32,8477,32770,8193,17,149521,13341,17664,182580,9224,54561,256,21792,46093,513]

theorem envBound38468 : H12AffineFastState.Bounded env38468 := by
  intro p hp
  have h : env38468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38467_38468 : H12AffineEnvironment.transform 15 263 env38467 = env38468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38467 == env38468) = true)

theorem identity38468 : scanCanonicalize (H12AffineFastState.compose env38468 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound38468 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38469 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,5392,10280,1024,32769,12573,32,8477,32770,8193,17,23809,13341,17664,56356,9224,54561,256,21792,46093,513]

theorem envBound38469 : H12AffineFastState.Bounded env38469 := by
  intro p hp
  have h : env38469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38468_38469 : H12AffineEnvironment.transform 16 5392 env38468 = env38469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env38468 == env38469) = true)

theorem identity38469 : scanCanonicalize (H12AffineFastState.compose env38469 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38469 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env38470 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,263,5392,10280,1024,32769,12573,32,8477,32770,8193,17,2049,13341,4096,35108,9224,32801,256,32,46093,513]

theorem envBound38470 : H12AffineFastState.Bounded env38470 := by
  intro p hp
  have h : env38470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38469_38470 : H12AffineEnvironment.transform 13 5376 env38469 = env38470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38469 == env38470) = true)

theorem identity38470 : scanCanonicalize (H12AffineFastState.compose env38470 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38470 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env38471 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,263,5392,10280,1024,1,12573,32,8477,2,8193,17,2049,13341,4096,2340,9224,33,256,32,13325,513]

theorem envBound38471 : H12AffineFastState.Bounded env38471 := by
  intro p hp
  have h : env38471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38470_38471 : H12AffineEnvironment.transform 14 0 env38470 = env38471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38470 == env38471) = true)

theorem identity38471 : scanCanonicalize (H12AffineFastState.compose env38471 (packedSelected [1,2,8] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound38471 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env38472 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1288,5376,0,263,5392,3360,1024,1,5141,32,1045,2,1289,17,2049,4373,4096,2340,256,33,256,32,4357,513]

theorem envBound38472 : H12AffineFastState.Bounded env38472 := by
  intro p hp
  have h : env38472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38471_38472 : H12AffineEnvironment.transform 12 1288 env38471 = env38472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env38471 == env38472) = true)

theorem identity38472 : scanCanonicalize (H12AffineFastState.compose env38472 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound38472 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env38473 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,57,4145,0,263,4129,2065,305,1,4388,32,292,2,56,17,2049,4373,4096,2340,256,33,256,32,4357,513]

theorem envBound38473 : H12AffineFastState.Bounded env38473 := by
  intro p hp
  have h : env38473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38472_38473 : H12AffineEnvironment.transform 9 305 env38472 = env38473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env38472 == env38473) = true)

theorem identity38473 : scanCanonicalize (H12AffineFastState.compose env38473 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound38473 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env38474 : List Nat := [2,4,8,16,32,17,9,52,512,5,2048,4096,57,4145,0,51,4129,2065,5,1,4112,32,16,2,56,17,2049,4129,4096,2064,52,33,52,32,4145,513]

theorem envBound38474 : H12AffineFastState.Bounded env38474 := by
  intro p hp
  have h : env38474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38473_38474 : H12AffineEnvironment.transform 7 52 env38473 = env38474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env38473 == env38474) = true)

theorem identity38474 : scanCanonicalize (H12AffineFastState.compose env38474 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38475 : List Nat := [2,4,8,0,32,1,9,36,512,5,2048,4096,41,4129,0,35,4129,2049,5,1,4096,32,0,2,40,1,2049,4129,4096,2048,36,33,36,32,4129,513]

theorem envBound38475 : H12AffineFastState.Bounded env38475 := by
  intro p hp
  have h : env38475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38474_38475 : H12AffineEnvironment.transform 3 0 env38474 = env38475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38474 == env38475) = true)

theorem identity38475 : scanCanonicalize (H12AffineFastState.compose env38475 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38475 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38476 : List Nat := [2,4,8,0,0,1,9,4,512,5,2048,4096,9,4097,0,3,4097,2049,5,1,4096,0,0,2,8,1,2049,4097,4096,2048,4,1,4,0,4097,513]

theorem envBound38476 : H12AffineFastState.Bounded env38476 := by
  intro p hp
  have h : env38476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38475_38476 : H12AffineEnvironment.transform 4 0 env38475 = env38476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38475 == env38476) = true)

theorem identity38476 : scanCanonicalize (H12AffineFastState.compose env38476 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound38476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38477 : List Nat := [2,4,8,0,0,1,9,4,512,5,2048,2561,9,2560,0,3,2560,2049,5,1,2561,0,0,2,8,1,2049,2560,2561,2048,4,1,4,0,2560,513]

theorem envBound38477 : H12AffineFastState.Bounded env38477 := by
  intro p hp
  have h : env38477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38476_38477 : H12AffineEnvironment.transform 11 2561 env38476 = env38477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env38476 == env38477) = true)

theorem identity38477 : scanCanonicalize (H12AffineFastState.compose env38477 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound38477 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38478 : List Nat := [2,4,8,0,0,1,9,4,11,5,2048,2058,9,2059,0,3,2059,2049,5,1,2058,0,0,2,8,1,2049,2059,2058,2048,4,1,4,0,2059,10]

theorem envBound38478 : H12AffineFastState.Bounded env38478 := by
  intro p hp
  have h : env38478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38477_38478 : H12AffineEnvironment.transform 8 11 env38477 = env38478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env38477 == env38478) = true)

theorem identity38478 : scanCanonicalize (H12AffineFastState.compose env38478 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound38478 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38479 : List Nat := [2,4,8,0,0,1,9,4,11,5,10,0,9,1,0,3,1,11,5,1,0,0,0,2,8,1,11,1,0,10,4,1,4,0,1,10]

theorem envBound38479 : H12AffineFastState.Bounded env38479 := by
  intro p hp
  have h : env38479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38478_38479 : H12AffineEnvironment.transform 10 10 env38478 = env38479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env38478 == env38479) = true)

def env38480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,33,73754,98644,8193,64,215367,79130,17664,247858,75102,119926,256,21792,46093,513]

theorem envBound38480 : H12AffineFastState.Bounded env38480 := by
  intro p hp
  have h : env38480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38450_38480 : H12AffineEnvironment.transform 17 10281 env38450 = env38480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38450 == env38480) = true)

theorem identity38480 : scanCanonicalize (H12AffineFastState.compose env38480 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38480 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1024,32769,4161,33,16,41310,8193,64,158029,5392,17664,190520,1364,62588,256,21792,46093,513]

theorem envBound38481 : H12AffineFastState.Bounded env38481 := by
  intro p hp
  have h : env38481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38480_38481 : H12AffineEnvironment.transform 15 8202 env38480 = env38481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38480 == env38481) = true)

theorem identity38481 : scanCanonicalize (H12AffineFastState.compose env38481 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27740) := by decide +kernel

theorem selectedBound38481 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,27740,10281,1024,32769,4161,33,16,41310,8193,64,1297,5392,17664,33892,1364,62588,256,21792,46093,513]

theorem envBound38482 : H12AffineFastState.Bounded env38482 := by
  intro p hp
  have h : env38482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38481_38482 : H12AffineEnvironment.transform 16 27740 env38481 = env38482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27740 env38481 == env38482) = true)

theorem identity38482 : scanCanonicalize (H12AffineFastState.compose env38482 (packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38482 : packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env38483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,19573,2048,1024,32769,4161,33,16,33143,40,64,1297,5392,17664,33892,1364,54357,256,21792,37924,513]

theorem envBound38483 : H12AffineFastState.Bounded env38483 := by
  intro p hp
  have h : env38483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38482_38483 : H12AffineEnvironment.transform 12 41 env38482 = env38483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38482 == env38483) = true)

theorem identity38483 : scanCanonicalize (H12AffineFastState.compose env38483 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 22577) := by decide +kernel

theorem selectedBound38483 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env38484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,22577,35,19573,2048,1024,22576,4161,33,16,22854,40,64,1297,5392,17664,23637,1364,3172,256,21792,19477,513]

theorem envBound38484 : H12AffineFastState.Bounded env38484 := by
  intro p hp
  have h : env38484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38483_38484 : H12AffineEnvironment.transform 14 22577 env38483 = env38484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22577 env38483 == env38484) = true)

theorem identity38484 : scanCanonicalize (H12AffineFastState.compose env38484 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 6208) := by decide +kernel

theorem selectedBound38484 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env38485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,6208,113,35,5173,2048,1024,112,4161,33,16,262,40,64,1297,5392,7488,1045,1364,3172,256,3424,5205,513]

theorem envBound38485 : H12AffineFastState.Bounded env38485 := by
  intro p hp
  have h : env38485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38484_38485 : H12AffineEnvironment.transform 13 6208 env38484 = env38485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6208 env38484 == env38485) = true)

theorem identity38485 : scanCanonicalize (H12AffineFastState.compose env38485 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound38485 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,41,4112,113,35,5173,80,1024,112,4161,33,16,262,40,64,1297,5392,5392,1045,1364,1076,256,1328,5205,513]

theorem envBound38486 : H12AffineFastState.Bounded env38486 := by
  intro p hp
  have h : env38486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38485_38486 : H12AffineEnvironment.transform 10 80 env38485 = env38486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env38485 == env38486) = true)

theorem identity38486 : scanCanonicalize (H12AffineFastState.compose env38486 (packedSelected [2,3,4,5,6,9,12,19] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound38486 : packedSelected [2,3,4,5,6,9,12,19] rootPS < 2^1333 := by decide +kernel

def env38487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,97,41,113,113,35,1108,80,1024,112,32,33,16,262,40,64,1297,1393,1393,1045,1364,1076,256,1328,1076,513]

theorem envBound38487 : H12AffineFastState.Bounded env38487 := by
  intro p hp
  have h : env38487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38486_38487 : H12AffineEnvironment.transform 11 97 env38486 = env38487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env38486 == env38487) = true)

theorem identity38487 : scanCanonicalize (H12AffineFastState.compose env38487 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound38487 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env38488 : List Nat := [2,4,8,16,32,64,9,256,65,1024,80,97,41,113,113,35,1108,80,1024,112,32,33,16,262,40,64,1297,1393,1393,1045,1364,1076,256,1328,1076,64]

theorem envBound38488 : H12AffineFastState.Bounded env38488 := by
  intro p hp
  have h : env38488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38487_38488 : H12AffineEnvironment.transform 8 65 env38487 = env38488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env38487 == env38488) = true)

theorem identity38488 : scanCanonicalize (H12AffineFastState.compose env38488 (packedSelected [0,1,6,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound38488 : packedSelected [0,1,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env38489 : List Nat := [2,4,8,16,32,64,9,256,65,288,80,97,41,113,113,35,372,80,288,112,32,33,16,262,40,64,49,81,81,309,116,276,256,16,276,64]

theorem envBound38489 : H12AffineFastState.Bounded env38489 := by
  intro p hp
  have h : env38489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38488_38489 : H12AffineEnvironment.transform 9 288 env38488 = env38489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env38488 == env38489) = true)

theorem identity38489 : scanCanonicalize (H12AffineFastState.compose env38489 (packedSelected [0,2,3,5,6,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound38489 : packedSelected [0,2,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env38490 : List Nat := [2,4,8,16,32,32,9,256,33,288,48,1,41,17,17,35,276,48,288,16,32,33,16,262,40,32,49,49,49,309,20,276,256,16,276,32]

theorem envBound38490 : H12AffineFastState.Bounded env38490 := by
  intro p hp
  have h : env38490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38489_38490 : H12AffineEnvironment.transform 5 32 env38489 = env38490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env38489 == env38490) = true)

theorem identity38490 : scanCanonicalize (H12AffineFastState.compose env38490 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38490 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38491 : List Nat := [2,4,8,16,16,16,9,256,17,272,0,1,25,17,17,19,276,0,272,16,16,17,16,262,24,16,1,1,1,261,20,276,256,16,276,16]

theorem envBound38491 : H12AffineFastState.Bounded env38491 := by
  intro p hp
  have h : env38491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38490_38491 : H12AffineEnvironment.transform 4 16 env38490 = env38491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38490 == env38491) = true)

theorem identity38491 : scanCanonicalize (H12AffineFastState.compose env38491 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38491 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38492 : List Nat := [2,4,8,0,0,0,9,256,1,256,0,1,9,1,1,3,260,0,256,0,0,1,0,262,8,0,1,1,1,261,4,260,256,0,260,0]

theorem envBound38492 : H12AffineFastState.Bounded env38492 := by
  intro p hp
  have h : env38492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38491_38492 : H12AffineEnvironment.transform 3 0 env38491 = env38492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38491 == env38492) = true)

def env38493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6705548,8393985,10507601,8830977,2102685,12645452,256,21793,46213,2175563]

theorem envBound38493 : H12AffineFastState.Bounded env38493 := by
  intro p hp
  have h : env38493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38311_38493 : H12AffineEnvironment.transform 23 10588557 env38311 = env38493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env38311 == env38493) = true)

def env38494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98781,8328,64,6705548,2098513,17665,2543697,2102685,6349852,256,21793,46213,2175563]

theorem envBound38494 : H12AffineFastState.Bounded env38494 := by
  intro p hp
  have h : env38494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38493_38494 : H12AffineEnvironment.transform 22 2101328 env38493 = env38494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env38493 == env38494) = true)

def env38495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98781,8328,64,2259212,2098513,17665,2543697,2102685,2411676,256,21793,46213,2175563]

theorem envBound38495 : H12AffineFastState.Bounded env38495 := by
  intro p hp
  have h : env38495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38494_38495 : H12AffineEnvironment.transform 21 272512 env38494 = env38495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38494 == env38495) = true)

theorem identity38495 : scanCanonicalize (H12AffineFastState.compose env38495 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38495 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272512,2101328,41431,8328,64,2259212,2098513,17665,2543697,2102685,2411676,256,21793,46213,2101825]

theorem envBound38496 : H12AffineFastState.Bounded env38496 := by
  intro p hp
  have h : env38496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38495_38496 : H12AffineEnvironment.transform 15 8202 env38495 = env38496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38495 == env38496) = true)

def env38497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272392,2101328,41311,8192,64,2259212,2098513,17665,2543697,2102549,2411540,256,21793,46093,2101825]

theorem envBound38497 : H12AffineFastState.Bounded env38497 := by
  intro p hp
  have h : env38497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38496_38497 : H12AffineEnvironment.transform 6 8 env38496 = env38497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38496 == env38497) = true)

theorem identity38497 : scanCanonicalize (H12AffineFastState.compose env38497 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound38497 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5441,262144,1024,32769,2097152,272392,2101328,41311,8192,64,2124877,2098513,17665,2409744,2102549,2411540,256,21793,46093,2101825]

theorem envBound38498 : H12AffineFastState.Bounded env38498 := by
  intro p hp
  have h : env38498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38497_38498 : H12AffineEnvironment.transform 16 5441 env38497 = env38498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env38497 == env38498) = true)

theorem identity38498 : scanCanonicalize (H12AffineFastState.compose env38498 (packedSelected [0,1,9,10,22,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 58444) := by decide +kernel

theorem selectedBound38498 : packedSelected [0,1,9,10,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5441,262144,1024,32769,58444,272392,62492,41311,8192,64,34817,57629,17665,270684,61785,272472,256,21793,46093,62989]

theorem envBound38499 : H12AffineFastState.Bounded env38499 := by
  intro p hp
  have h : env38499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38498_38499 : H12AffineEnvironment.transform 20 58444 env38498 = env38499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58444 env38498 == env38499) = true)

theorem identity38499 : scanCanonicalize (H12AffineFastState.compose env38499 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound38499 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env38500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8202,5441,262144,1024,29709,4160,272392,16,21843,8192,64,31757,5393,17665,270684,1365,272472,256,21793,16385,513]

theorem envBound38500 : H12AffineFastState.Bounded env38500 := by
  intro p hp
  have h : env38500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38499_38500 : H12AffineEnvironment.transform 14 29708 env38499 = env38500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env38499 == env38500) = true)

theorem identity38500 : scanCanonicalize (H12AffineFastState.compose env38500 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound38500 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,372,8202,5441,262144,1024,373,4160,272392,16,8235,8192,64,2421,5393,12409,270684,1365,272472,256,8281,13689,513]

theorem envBound38501 : H12AffineFastState.Bounded env38501 := by
  intro p hp
  have h : env38501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38500_38501 : H12AffineEnvironment.transform 13 13688 env38500 = env38501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env38500 == env38501) = true)

theorem identity38501 : scanCanonicalize (H12AffineFastState.compose env38501 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38501 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5457,372,35,5441,262144,1024,373,4160,264225,16,2,41,64,2421,5393,4176,262517,1365,264305,256,112,5456,513]

theorem envBound38502 : H12AffineFastState.Bounded env38502 := by
  intro p hp
  have h : env38502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38501_38502 : H12AffineEnvironment.transform 12 41 env38501 = env38502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38501 == env38502) = true)

theorem identity38502 : scanCanonicalize (H12AffineFastState.compose env38502 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 3392) := by decide +kernel

theorem selectedBound38502 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5457,372,35,5441,3392,1024,373,4160,1377,16,2,41,64,2421,5393,4176,3125,1365,1329,256,112,5456,513]

theorem envBound38503 : H12AffineFastState.Bounded env38503 := by
  intro p hp
  have h : env38503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38502_38503 : H12AffineEnvironment.transform 17 3392 env38502 = env38503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3392 env38502 == env38503) = true)

theorem identity38503 : scanCanonicalize (H12AffineFastState.compose env38503 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38503 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env38504 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,4161,372,35,4177,2128,272,373,4160,113,16,2,41,64,2421,4097,4176,2341,69,33,256,112,4160,513]

theorem envBound38504 : H12AffineFastState.Bounded env38504 := by
  intro p hp
  have h : env38504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38503_38504 : H12AffineEnvironment.transform 9 272 env38503 = env38504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38503 == env38504) = true)

theorem identity38504 : scanCanonicalize (H12AffineFastState.compose env38504 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38505 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,41,4113,292,35,4097,2048,272,293,4112,33,16,2,41,16,2341,4097,4096,2341,21,33,256,32,4112,513]

theorem envBound38505 : H12AffineFastState.Bounded env38505 := by
  intro p hp
  have h : env38505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38504_38505 : H12AffineEnvironment.transform 5 16 env38504 = env38505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38504 == env38505) = true)

theorem identity38505 : scanCanonicalize (H12AffineFastState.compose env38505 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38505 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38506 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,0,35,4097,2048,52,1,4112,33,16,2,41,16,2049,4097,4096,2049,21,33,36,32,4112,513]

theorem envBound38506 : H12AffineFastState.Bounded env38506 := by
  intro p hp
  have h : env38506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38505_38506 : H12AffineEnvironment.transform 7 36 env38505 = env38506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38505 == env38506) = true)

theorem identity38506 : scanCanonicalize (H12AffineFastState.compose env38506 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound38506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38507 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,528,41,513,0,35,529,2048,52,1,512,33,16,2,41,16,2049,529,528,2049,21,33,36,32,512,513]

theorem envBound38507 : H12AffineFastState.Bounded env38507 := by
  intro p hp
  have h : env38507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38506_38507 : H12AffineEnvironment.transform 11 528 env38506 = env38507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env38506 == env38507) = true)

theorem identity38507 : scanCanonicalize (H12AffineFastState.compose env38507 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38508 : List Nat := [2,4,3,16,32,16,3,36,512,52,2048,528,34,513,0,35,529,2048,52,1,512,33,16,2,34,16,2049,529,528,2049,21,33,36,32,512,513]

theorem envBound38508 : H12AffineFastState.Bounded env38508 := by
  intro p hp
  have h : env38508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38507_38508 : H12AffineEnvironment.transform 2 3 env38507 = env38508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38507 == env38508) = true)

theorem identity38508 : scanCanonicalize (H12AffineFastState.compose env38508 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound38508 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38509 : List Nat := [2,4,3,16,32,16,3,36,512,52,513,528,34,513,0,35,529,513,52,1,512,33,16,2,34,16,512,529,528,512,21,33,36,32,512,513]

theorem envBound38509 : H12AffineFastState.Bounded env38509 := by
  intro p hp
  have h : env38509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38508_38509 : H12AffineEnvironment.transform 10 513 env38508 = env38509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env38508 == env38509) = true)

def env38510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272393,2101328,41310,8193,64,2259212,2098513,17665,2543697,2102548,2411541,256,21793,46092,2101825]

theorem envBound38510 : H12AffineFastState.Bounded env38510 := by
  intro p hp
  have h : env38510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38496_38510 : H12AffineEnvironment.transform 6 9 env38496 = env38510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38496 == env38510) = true)

theorem identity38510 : scanCanonicalize (H12AffineFastState.compose env38510 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound38510 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,2097152,272393,2101328,41310,8193,64,2149648,2098513,17665,2384973,2102548,2411541,256,21793,46092,2101825]

theorem envBound38511 : H12AffineFastState.Bounded env38511 := by
  intro p hp
  have h : env38511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38510_38511 : H12AffineEnvironment.transform 16 46108 env38510 = env38511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env38510 == env38511) = true)

def env38512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4160,272393,16,41310,8193,64,56656,5393,17665,291853,1364,318549,256,21793,46092,513]

theorem envBound38512 : H12AffineFastState.Bounded env38512 := by
  intro p hp
  have h : env38512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38511_38512 : H12AffineEnvironment.transform 20 4160 env38511 = env38512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38511 == env38512) = true)

theorem identity38512 : scanCanonicalize (H12AffineFastState.compose env38512 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound38512 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env38513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16449,262144,1024,29788,4160,272393,16,21763,8193,64,10509,5393,17665,291853,1364,272392,256,21793,16465,513]

theorem envBound38513 : H12AffineFastState.Bounded env38513 := by
  intro p hp
  have h : env38513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38512_38513 : H12AffineEnvironment.transform 14 29789 env38512 = env38513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env38512 == env38513) = true)

theorem identity38513 : scanCanonicalize (H12AffineFastState.compose env38513 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound38513 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16449,2341,1024,29788,4160,8492,16,21763,8193,64,10509,5393,17665,32040,1364,8493,256,21793,16465,513]

theorem envBound38514 : H12AffineFastState.Bounded env38514 := by
  intro p hp
  have h : env38514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38513_38514 : H12AffineEnvironment.transform 17 2341 env38513 = env38514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env38513 == env38514) = true)

theorem identity38514 : scanCanonicalize (H12AffineFastState.compose env38514 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38514 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,16449,2341,1024,21760,4160,112,16,21763,349,64,2129,5393,17665,23668,1364,113,256,21793,16465,513]

theorem envBound38515 : H12AffineFastState.Bounded env38515 := by
  intro p hp
  have h : env38515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38514_38515 : H12AffineEnvironment.transform 12 348 env38514 = env38515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38514 == env38515) = true)

theorem identity38515 : scanCanonicalize (H12AffineFastState.compose env38515 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38515 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5441,2341,1024,0,4160,112,16,3,349,64,2129,5393,4097,2420,1364,113,256,33,5457,513]

theorem envBound38516 : H12AffineFastState.Bounded env38516 := by
  intro p hp
  have h : env38516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38515_38516 : H12AffineEnvironment.transform 13 5376 env38515 = env38516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38515 == env38516) = true)

theorem identity38516 : scanCanonicalize (H12AffineFastState.compose env38516 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38516 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38517 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,5392,2341,1024,0,4113,33,16,3,268,17,2048,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound38517 : H12AffineFastState.Bounded env38517 := by
  intro p hp
  have h : env38517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38516_38517 : H12AffineEnvironment.transform 5 17 env38516 = env38517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38516 == env38517) = true)

theorem identity38517 : scanCanonicalize (H12AffineFastState.compose env38517 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38518 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,1,34,5173,2048,1024,0,4113,33,16,3,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound38518 : H12AffineFastState.Bounded env38518 := by
  intro p hp
  have h : env38518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38517_38518 : H12AffineEnvironment.transform 7 37 env38517 = env38518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38517 == env38518) = true)

def env38519 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1045,1,34,1029,2048,1024,0,33,33,16,3,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound38519 : H12AffineFastState.Bounded env38519 := by
  intro p hp
  have h : env38519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38518_38519 : H12AffineEnvironment.transform 11 48 env38518 = env38519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38518 == env38519) = true)

theorem identity38519 : scanCanonicalize (H12AffineFastState.compose env38519 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound38519 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38520 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,48,40,1045,1,34,1029,1572,1024,0,33,33,16,3,41,17,1572,1028,49,1572,1056,32,37,33,1045,513]

theorem envBound38520 : H12AffineFastState.Bounded env38520 := by
  intro p hp
  have h : env38520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38519_38520 : H12AffineEnvironment.transform 10 1572 env38519 = env38520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env38519 == env38520) = true)

def env38521 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,48,40,33,1,34,49,528,52,0,33,33,16,3,41,17,528,48,49,528,20,32,37,33,33,513]

theorem envBound38521 : H12AffineFastState.Bounded env38521 := by
  intro p hp
  have h : env38521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38520_38521 : H12AffineEnvironment.transform 9 52 env38520 = env38521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38520 == env38521) = true)

theorem identity38521 : scanCanonicalize (H12AffineFastState.compose env38521 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38522 : List Nat := [2,4,8,16,32,17,9,37,43,52,59,48,40,33,1,34,49,59,52,0,33,33,16,3,41,17,59,48,49,59,20,32,37,33,33,42]

theorem envBound38522 : H12AffineFastState.Bounded env38522 := by
  intro p hp
  have h : env38522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38521_38522 : H12AffineEnvironment.transform 8 43 env38521 = env38522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38521 == env38522) = true)

def leafEnv38522 : List Nat := [2,4,8,16,32,17,9,37,43,52,59,48,40,33,1,34,49,59,52,0,33,33,16,3,20,41,1,17,59,48,49,59,20,32,37,33,4,35,33,42,1,33,0]

def active38522 : List Nat := [0,1,2,3,4]

def tree38522 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38522 : H12WitnessSearch.Good tree38522 := H12GlobalWitnessIndex.good

theorem leafIdentity38522 : H12AffineFastState.composeSystem env38522 rootObs = leafEnv38522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38522 rootObs == leafEnv38522) = true)

theorem terminalChecked38522 : H12PackedTerminal.terminalCheckFast leafEnv38522 active38522 tree38522 = true := by decide +kernel

def env38523 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,48,40,32,1,34,48,529,53,0,33,33,16,3,41,17,529,49,49,529,21,32,37,33,32,513]

theorem envBound38523 : H12AffineFastState.Bounded env38523 := by
  intro p hp
  have h : env38523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38520_38523 : H12AffineEnvironment.transform 9 53 env38520 = env38523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38520 == env38523) = true)

def env38524 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1044,1,34,1028,2048,1024,0,32,33,16,3,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound38524 : H12AffineFastState.Bounded env38524 := by
  intro p hp
  have h : env38524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38518_38524 : H12AffineEnvironment.transform 11 49 env38518 = env38524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38518 == env38524) = true)

theorem identity38524 : scanCanonicalize (H12AffineFastState.compose env38524 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound38524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38525 : List Nat := [2,4,8,16,32,17,9,37,512,1024,528,49,40,1044,1,34,1028,528,1024,0,32,33,16,3,41,17,528,1029,48,528,1056,32,37,33,1044,513]

theorem envBound38525 : H12AffineFastState.Bounded env38525 := by
  intro p hp
  have h : env38525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38524_38525 : H12AffineEnvironment.transform 10 528 env38524 = env38525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env38524 == env38525) = true)

def env38526 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,49,40,32,1,34,48,528,52,0,32,33,16,3,41,17,528,49,48,528,20,32,37,33,32,513]

theorem envBound38526 : H12AffineFastState.Bounded env38526 := by
  intro p hp
  have h : env38526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38525_38526 : H12AffineEnvironment.transform 9 52 env38525 = env38526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38525 == env38526) = true)

theorem identity38526 : scanCanonicalize (H12AffineFastState.compose env38526 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound38526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38527 : List Nat := [2,4,8,16,32,17,9,37,42,52,58,49,40,32,1,34,48,58,52,0,32,33,16,3,41,17,58,49,48,58,20,32,37,33,32,43]

theorem envBound38527 : H12AffineFastState.Bounded env38527 := by
  intro p hp
  have h : env38527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38526_38527 : H12AffineEnvironment.transform 8 42 env38526 = env38527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env38526 == env38527) = true)

def leafEnv38527 : List Nat := [2,4,8,16,32,17,9,37,42,52,58,49,40,32,1,34,48,58,52,0,32,33,16,3,20,41,1,17,58,49,48,58,20,32,37,33,4,35,32,43,1,32,0]

def active38527 : List Nat := [0,1,2,3,4]

def tree38527 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38527 : H12WitnessSearch.Good tree38527 := H12GlobalWitnessIndex.good

theorem leafIdentity38527 : H12AffineFastState.composeSystem env38527 rootObs = leafEnv38527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38527 rootObs == leafEnv38527) = true)

theorem terminalChecked38527 : H12PackedTerminal.terminalCheckFast leafEnv38527 active38527 tree38527 = true := by decide +kernel

def env38528 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,49,40,33,1,34,49,528,53,0,32,33,16,3,41,17,528,48,48,528,21,32,37,33,33,513]

theorem envBound38528 : H12AffineFastState.Bounded env38528 := by
  intro p hp
  have h : env38528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38525_38528 : H12AffineEnvironment.transform 9 53 env38525 = env38528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38525 == env38528) = true)

def env38529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4161,272393,17,41310,8193,64,56657,5392,17665,291852,1365,318548,256,21793,46092,512]

theorem envBound38529 : H12AffineFastState.Bounded env38529 := by
  intro p hp
  have h : env38529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38511_38529 : H12AffineEnvironment.transform 20 4161 env38511 = env38529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38511 == env38529) = true)

theorem identity38529 : scanCanonicalize (H12AffineFastState.compose env38529 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound38529 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,56576,1024,32769,4161,62729,17,41310,8193,64,56657,5392,17665,43276,1365,340,256,21793,46092,512]

theorem envBound38530 : H12AffineFastState.Bounded env38530 := by
  intro p hp
  have h : env38530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38529_38530 : H12AffineEnvironment.transform 17 56576 env38529 = env38530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env38529 == env38530) = true)

theorem identity38530 : scanCanonicalize (H12AffineFastState.compose env38530 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound38530 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8202,16692,10280,1024,29993,4161,33,17,21622,8193,64,10361,5392,17665,23588,1365,340,256,21793,16676,512]

theorem envBound38531 : H12AffineFastState.Bounded env38531 := by
  intro p hp
  have h : env38531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38530_38531 : H12AffineEnvironment.transform 14 29992 env38530 = env38531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env38530 == env38531) = true)

theorem identity38531 : scanCanonicalize (H12AffineFastState.compose env38531 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 8201) := by decide +kernel

theorem selectedBound38531 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env38532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,8201,5409,8202,8509,10280,1024,5408,4161,33,17,13439,8193,64,10361,5392,9480,15405,1365,340,256,13608,8493,512]

theorem envBound38532 : H12AffineFastState.Bounded env38532 := by
  intro p hp
  have h : env38532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38531_38532 : H12AffineEnvironment.transform 13 8201 env38531 = env38532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8201 env38531 == env38532) = true)

theorem identity38532 : scanCanonicalize (H12AffineFastState.compose env38532 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 3400) := by decide +kernel

theorem selectedBound38532 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env38533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3400,3393,5409,3394,3189,1376,1024,5408,4161,33,17,6455,3401,64,1329,5392,2112,4453,1365,340,256,6240,3173,512]

theorem envBound38533 : H12AffineFastState.Bounded env38533 := by
  intro p hp
  have h : env38533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38532_38533 : H12AffineEnvironment.transform 12 3400 env38532 = env38533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3400 env38532 == env38533) = true)

theorem identity38533 : scanCanonicalize (H12AffineFastState.compose env38533 (packedSelected [0,1,4,6,7,8,9,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound38533 : packedSelected [0,1,4,6,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env38534 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,2089,2080,4160,2083,2324,1,353,4161,4161,33,17,6455,2088,64,80,4209,2112,4453,52,340,256,6240,2308,512]

theorem envBound38534 : H12AffineFastState.Bounded env38534 := by
  intro p hp
  have h : env38534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38533_38534 : H12AffineEnvironment.transform 9 353 env38533 = env38534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env38533 == env38534) = true)

theorem identity38534 : scanCanonicalize (H12AffineFastState.compose env38534 (packedSelected [0,6,7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound38534 : packedSelected [0,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env38535 : List Nat := [2,4,8,16,32,64,9,84,512,53,2048,4096,2089,2080,4160,2083,2112,1,53,4161,4161,33,17,6243,2088,64,80,4209,2112,4145,52,0,84,6240,2128,512]

theorem envBound38535 : H12AffineFastState.Bounded env38535 := by
  intro p hp
  have h : env38535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38534_38535 : H12AffineEnvironment.transform 7 84 env38534 = env38535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env38534 == env38535) = true)

theorem identity38535 : scanCanonicalize (H12AffineFastState.compose env38535 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound38535 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38536 : List Nat := [2,4,8,16,32,64,9,84,512,53,81,4096,120,113,4160,114,17,1,53,4161,4161,33,17,4146,121,64,80,4209,17,4145,52,0,84,4145,1,512]

theorem envBound38536 : H12AffineFastState.Bounded env38536 := by
  intro p hp
  have h : env38536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38535_38536 : H12AffineEnvironment.transform 10 81 env38535 = env38536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env38535 == env38536) = true)

theorem identity38536 : scanCanonicalize (H12AffineFastState.compose env38536 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38536 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38537 : List Nat := [2,4,8,16,32,48,9,36,512,53,33,4096,8,1,4144,2,17,1,53,4145,4145,33,17,4146,9,48,32,4097,17,4145,52,0,36,4145,1,512]

theorem envBound38537 : H12AffineFastState.Bounded env38537 := by
  intro p hp
  have h : env38537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38536_38537 : H12AffineEnvironment.transform 5 48 env38536 = env38537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38536 == env38537) = true)

theorem identity38537 : scanCanonicalize (H12AffineFastState.compose env38537 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound38537 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38538 : List Nat := [2,4,8,16,32,48,9,36,512,53,33,571,8,1,523,2,17,1,53,522,522,33,17,521,9,48,32,570,17,522,52,0,36,522,1,512]

theorem envBound38538 : H12AffineFastState.Bounded env38538 := by
  intro p hp
  have h : env38538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38537_38538 : H12AffineEnvironment.transform 11 571 env38537 = env38538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env38537 == env38538) = true)

theorem identity38538 : scanCanonicalize (H12AffineFastState.compose env38538 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound38538 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38539 : List Nat := [2,4,8,16,9,25,9,13,512,28,8,530,8,1,523,2,17,1,28,522,522,8,17,521,9,25,9,531,17,522,29,0,13,522,1,512]

theorem envBound38539 : H12AffineFastState.Bounded env38539 := by
  intro p hp
  have h : env38539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38538_38539 : H12AffineEnvironment.transform 4 9 env38538 = env38539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env38538 == env38539) = true)

theorem identity38539 : scanCanonicalize (H12AffineFastState.compose env38539 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound38539 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38540 : List Nat := [2,4,8,16,9,25,9,13,3,28,8,17,8,1,8,2,17,1,28,9,9,8,17,10,9,25,9,16,17,9,29,0,13,9,1,3]

theorem envBound38540 : H12AffineFastState.Bounded env38540 := by
  intro p hp
  have h : env38540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38539_38540 : H12AffineEnvironment.transform 8 3 env38539 = env38540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env38539 == env38540) = true)

theorem identity38540 : scanCanonicalize (H12AffineFastState.compose env38540 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

end H12CloudChart1