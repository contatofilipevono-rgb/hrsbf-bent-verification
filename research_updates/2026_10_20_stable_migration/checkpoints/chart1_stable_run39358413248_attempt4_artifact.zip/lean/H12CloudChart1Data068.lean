import H12CloudChart1Data067

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound17137 : H12AffineFastState.Bounded env17137 := by
  intro p hp
  have h : env17137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17136_17137 : H12AffineEnvironment.transform 13 4541 env17136 = env17137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env17136 == env17137) = true)

theorem identity17137 : scanCanonicalize (H12AffineFastState.compose env17137 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound17137 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17138 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2113,389,2556,136,479,2249,2477,321,137,2340,168,308,138,269,64,2264,2356,2492,2340,441,32,257,477,2185,884]

theorem envBound17138 : H12AffineFastState.Bounded env17138 := by
  intro p hp
  have h : env17138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17137_17138 : H12AffineEnvironment.transform 11 2113 env17137 = env17138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env17137 == env17138) = true)

theorem identity17138 : scanCanonicalize (H12AffineFastState.compose env17138 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound17138 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env17139 : List Nat := [2,4,8,16,32,64,128,256,512,320,429,492,389,81,136,479,356,0,321,137,137,168,308,138,269,64,373,153,17,137,441,32,257,477,292,884]

theorem envBound17139 : H12AffineFastState.Bounded env17139 := by
  intro p hp
  have h : env17139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17138_17139 : H12AffineEnvironment.transform 10 429 env17138 = env17139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env17138 == env17139) = true)

theorem identity17139 : scanCanonicalize (H12AffineFastState.compose env17139 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound17139 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env17140 : List Nat := [2,4,8,16,32,64,89,256,512,320,372,309,348,81,81,262,356,0,321,80,80,113,308,83,269,64,373,64,17,80,352,32,257,260,292,884]

theorem envBound17140 : H12AffineFastState.Bounded env17140 := by
  intro p hp
  have h : env17140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17139_17140 : H12AffineEnvironment.transform 6 89 env17139 = env17140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env17139 == env17140) = true)

theorem identity17140 : scanCanonicalize (H12AffineFastState.compose env17140 (packedSelected [1,2,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound17140 : packedSelected [1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env17141 : List Nat := [2,4,8,16,32,64,89,256,373,320,372,309,348,81,81,262,356,0,321,80,80,113,308,83,269,64,373,64,17,80,352,32,257,260,292,1]

theorem envBound17141 : H12AffineFastState.Bounded env17141 := by
  intro p hp
  have h : env17141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17140_17141 : H12AffineEnvironment.transform 8 373 env17140 = env17141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env17140 == env17141) = true)

theorem identity17141 : scanCanonicalize (H12AffineFastState.compose env17141 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17141 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env17142 : List Nat := [2,4,8,16,32,16,9,256,293,272,292,309,268,1,1,262,308,0,273,0,0,33,308,3,269,16,293,16,17,0,304,32,257,260,292,1]

theorem envBound17142 : H12AffineFastState.Bounded env17142 := by
  intro p hp
  have h : env17142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17141_17142 : H12AffineEnvironment.transform 5 16 env17141 = env17142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17141 == env17142) = true)

theorem identity17142 : scanCanonicalize (H12AffineFastState.compose env17142 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17142 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17143 : List Nat := [2,4,8,16,32,16,9,36,1,52,0,17,40,1,1,34,16,0,53,0,0,33,16,3,41,16,1,16,17,0,20,32,37,32,0,1]

theorem envBound17143 : H12AffineFastState.Bounded env17143 := by
  intro p hp
  have h : env17143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17142_17143 : H12AffineEnvironment.transform 7 36 env17142 = env17143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17142 == env17143) = true)

theorem identity17143 : scanCanonicalize (H12AffineFastState.compose env17143 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17144 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,17,9,1,1,3,16,0,20,0,0,0,16,3,8,16,1,16,17,0,20,1,4,1,0,1]

theorem envBound17144 : H12AffineFastState.Bounded env17144 := by
  intro p hp
  have h : env17144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17143_17144 : H12AffineEnvironment.transform 4 1 env17143 = env17144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17143 == env17144) = true)

theorem identity17144 : scanCanonicalize (H12AffineFastState.compose env17144 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound17144 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17145 : List Nat := [2,4,8,5,1,5,9,5,1,0,0,4,9,1,1,3,5,0,1,0,0,0,5,3,8,5,1,5,4,0,1,1,4,1,0,1]

theorem envBound17145 : H12AffineFastState.Bounded env17145 := by
  intro p hp
  have h : env17145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17144_17145 : H12AffineEnvironment.transform 3 5 env17144 = env17145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env17144 == env17145) = true)

theorem identity17145 : scanCanonicalize (H12AffineFastState.compose env17145 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound17145 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17146 : List Nat := [2,0,8,1,1,1,9,1,1,0,0,0,9,1,1,3,1,0,1,0,0,0,1,3,8,1,1,1,0,0,1,1,0,1,0,1]

theorem envBound17146 : H12AffineFastState.Bounded env17146 := by
  intro p hp
  have h : env17146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17145_17146 : H12AffineEnvironment.transform 1 0 env17145 = env17146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env17145 == env17146) = true)

def env17147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58517,169,62660,98781,8328,64,43477,57797,17664,10400,61705,33,257,21792,46213,120542]

theorem envBound17147 : H12AffineFastState.Bounded env17147 := by
  intro p hp
  have h : env17147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17131_17147 : H12AffineEnvironment.transform 17 10281 env17131 = env17147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env17131 == env17147) = true)

theorem identity17147 : scanCanonicalize (H12AffineFastState.compose env17147 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound17147 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env17148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,13389,10281,1025,32769,58517,169,62660,32906,8328,64,43477,57797,17664,10400,61705,33,257,21792,46213,55177]

theorem envBound17148 : H12AffineFastState.Bounded env17148 := by
  intro p hp
  have h : env17148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17147_17148 : H12AffineEnvironment.transform 15 343 env17147 = env17148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env17147 == env17148) = true)

theorem identity17148 : scanCanonicalize (H12AffineFastState.compose env17148 (packedSelected [0,1,4,7,8,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound17148 : packedSelected [0,1,4,7,8,17,19,22] rootPS < 2^1333 := by decide +kernel

def env17149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,343,13389,10281,1025,137,25629,169,29772,2,8328,64,10589,24909,17664,10400,29057,33,257,21792,13325,22273]

theorem envBound17149 : H12AffineFastState.Bounded env17149 := by
  intro p hp
  have h : env17149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17148_17149 : H12AffineEnvironment.transform 14 136 env17148 = env17149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env17148 == env17149) = true)

theorem identity17149 : scanCanonicalize (H12AffineFastState.compose env17149 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17149 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env17150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,343,13389,10281,1025,137,4160,169,17,2,8328,64,10589,5392,12637,10400,1500,33,257,8573,13325,9052]

theorem envBound17150 : H12AffineFastState.Bounded env17150 := by
  intro p hp
  have h : env17150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17149_17150 : H12AffineEnvironment.transform 13 13405 env17149 = env17150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17149 == env17150) = true)

theorem identity17150 : scanCanonicalize (H12AffineFastState.compose env17150 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17150 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env17151 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,13405,33,343,13389,10281,1025,32,4160,0,17,2,8225,64,10589,5392,12637,10249,1397,33,257,8573,13325,9052]

theorem envBound17151 : H12AffineFastState.Bounded env17151 := by
  intro p hp
  have h : env17151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17150_17151 : H12AffineEnvironment.transform 6 41 env17150 = env17151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17150 == env17151) = true)

theorem identity17151 : scanCanonicalize (H12AffineFastState.compose env17151 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17151 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env17152 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,349,5376,33,343,5392,2420,1025,32,4160,0,17,2,380,64,2048,5392,4096,2388,1397,33,257,32,5456,513]

theorem envBound17152 : H12AffineFastState.Bounded env17152 := by
  intro p hp
  have h : env17152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17151_17152 : H12AffineEnvironment.transform 12 349 env17151 = env17152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17151 == env17152) = true)

theorem identity17152 : scanCanonicalize (H12AffineFastState.compose env17152 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17152 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17153 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,4096,300,5376,33,294,5392,2309,1025,32,4145,0,17,2,269,49,2048,5392,4096,2341,1284,33,257,32,5409,513]

theorem envBound17153 : H12AffineFastState.Bounded env17153 := by
  intro p hp
  have h : env17153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17152_17153 : H12AffineEnvironment.transform 5 49 env17152 = env17153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17152 == env17153) = true)

theorem identity17153 : scanCanonicalize (H12AffineFastState.compose env17153 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound17153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17154 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,292,300,1060,33,294,1076,2309,1025,32,277,0,17,2,269,49,2048,1076,292,2341,1284,33,257,32,1029,513]

theorem envBound17154 : H12AffineFastState.Bounded env17154 := by
  intro p hp
  have h : env17154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17153_17154 : H12AffineEnvironment.transform 11 292 env17153 = env17154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env17153 == env17154) = true)

theorem identity17154 : scanCanonicalize (H12AffineFastState.compose env17154 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound17154 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env17155 : List Nat := [2,4,8,16,32,49,41,256,512,1024,277,292,300,1060,33,294,1076,16,1025,32,277,0,17,2,269,49,277,1076,292,48,1284,33,257,32,1029,513]

theorem envBound17155 : H12AffineFastState.Bounded env17155 := by
  intro p hp
  have h : env17155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17154_17155 : H12AffineEnvironment.transform 10 277 env17154 = env17155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env17154 == env17155) = true)

theorem identity17155 : scanCanonicalize (H12AffineFastState.compose env17155 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound17155 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env17156 : List Nat := [2,4,8,16,32,49,41,256,308,1024,277,292,300,1060,33,294,1076,16,1025,32,277,0,17,2,269,49,277,1076,292,48,1284,33,257,32,1029,309]

theorem envBound17156 : H12AffineFastState.Bounded env17156 := by
  intro p hp
  have h : env17156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17155_17156 : H12AffineEnvironment.transform 8 308 env17155 = env17156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env17155 == env17156) = true)

theorem identity17156 : scanCanonicalize (H12AffineFastState.compose env17156 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17156 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17157 : List Nat := [2,4,8,16,1,16,8,256,277,1024,277,261,269,1029,0,263,1045,16,1025,1,277,0,17,2,269,16,277,1045,261,17,1284,0,257,1,1029,276]

theorem envBound17157 : H12AffineFastState.Bounded env17157 := by
  intro p hp
  have h : env17157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17156_17157 : H12AffineEnvironment.transform 4 1 env17156 = env17157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17156 == env17157) = true)

theorem identity17157 : scanCanonicalize (H12AffineFastState.compose env17157 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17157 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17158 : List Nat := [2,4,8,16,1,16,8,5,16,1024,16,0,8,1029,0,2,1045,16,1025,1,16,0,17,2,8,16,16,1045,0,17,1025,0,4,1,1029,17]

theorem envBound17158 : H12AffineFastState.Bounded env17158 := by
  intro p hp
  have h : env17158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17157_17158 : H12AffineEnvironment.transform 7 5 env17157 = env17158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17157 == env17158) = true)

def env17159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,98781,8328,64,43476,185736,17664,262281,181572,400452,257,21792,46213,254611]

theorem envBound17159 : H12AffineFastState.Bounded env17159 := by
  intro p hp
  have h : env17159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17129_17159 : H12AffineEnvironment.transform 21 272513 env17129 = env17159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17129 == env17159) = true)

theorem identity17159 : scanCanonicalize (H12AffineFastState.compose env17159 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound17159 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140301,272513,144476,95496,8328,64,23809,139613,17664,262281,143761,400452,257,21792,16464,202310]

theorem envBound17160 : H12AffineFastState.Bounded env17160 := by
  intro p hp
  have h : env17160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17159_17160 : H12AffineEnvironment.transform 14 29909 env17159 = env17160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env17159 == env17160) = true)

def env17161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272393,144476,95496,8192,64,23809,139613,17664,262145,143641,400452,257,21792,16464,202310]

theorem envBound17161 : H12AffineFastState.Bounded env17161 := by
  intro p hp
  have h : env17161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17160_17161 : H12AffineEnvironment.transform 6 8 env17160 = env17161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17160 == env17161) = true)

theorem identity17161 : scanCanonicalize (H12AffineFastState.compose env17161 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound17161 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env17162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149861,1025,29788,140301,156012,144476,95496,8192,64,23809,139613,17664,149860,143641,21793,257,21792,16464,202310]

theorem envBound17162 : H12AffineFastState.Bounded env17162 := by
  intro p hp
  have h : env17162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17161_17162 : H12AffineEnvironment.transform 17 149861 env17161 = env17162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env17161 == env17162) = true)

theorem identity17162 : scanCanonicalize (H12AffineFastState.compose env17162 (packedSelected [0,3,4,5,10,12,14,15,17,19,20,22,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 78910) := by decide +kernel

theorem selectedBound17162 : packedSelected [0,3,4,5,10,12,14,15,17,19,20,22,26,27] rootPS < 2^1333 := by decide +kernel

def env17163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,78910,97627,1025,29788,69683,87378,65634,95496,8192,64,23809,71011,17664,97626,66855,21793,257,21792,16464,8824]

theorem envBound17163 : H12AffineFastState.Bounded env17163 := by
  intro p hp
  have h : env17163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17162_17163 : H12AffineEnvironment.transform 16 78910 env17162 = env17163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78910 env17162 == env17163) = true)

theorem identity17163 : scanCanonicalize (H12AffineFastState.compose env17163 (packedSelected [0,3,7,9,10,14,16,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound17163 : packedSelected [0,3,7,9,10,14,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env17164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,373,65536,78910,67699,1025,372,69683,73850,65634,65568,8192,64,10281,71011,12328,67698,66855,8201,257,8200,13688,8824]

theorem envBound17164 : H12AffineFastState.Bounded env17164 := by
  intro p hp
  have h : env17164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17163_17164 : H12AffineEnvironment.transform 13 13608 env17163 = env17164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env17163 == env17164) = true)

theorem identity17164 : scanCanonicalize (H12AffineFastState.compose env17164 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17164 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env17165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5456,373,65536,70726,67699,1025,372,69683,65538,65634,65568,120,64,2129,71011,4176,67698,66855,113,257,112,5376,512]

theorem envBound17165 : H12AffineFastState.Bounded env17165 := by
  intro p hp
  have h : env17165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17164_17165 : H12AffineEnvironment.transform 12 120 env17164 = env17165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17164 == env17165) = true)

theorem identity17165 : scanCanonicalize (H12AffineFastState.compose env17165 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17165 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5456,373,263,5441,2420,1025,372,4404,261,357,295,120,64,2129,5220,4176,2421,1056,113,257,112,5376,512]

theorem envBound17166 : H12AffineFastState.Bounded env17166 := by
  intro p hp
  have h : env17166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17165_17166 : H12AffineEnvironment.transform 15 263 env17165 = env17166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17165 == env17166) = true)

theorem identity17166 : scanCanonicalize (H12AffineFastState.compose env17166 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound17166 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17167 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,8,5408,261,263,5425,2308,1025,260,4404,261,277,295,8,48,2081,5140,4128,2309,1056,1,257,0,5376,512]

theorem envBound17167 : H12AffineFastState.Bounded env17167 := by
  intro p hp
  have h : env17167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17166_17167 : H12AffineEnvironment.transform 5 48 env17166 = env17167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env17166 == env17167) = true)

theorem identity17167 : scanCanonicalize (H12AffineFastState.compose env17167 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17167 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17168 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,8,5377,261,263,5392,2308,1025,260,4373,261,277,262,8,17,2048,5140,4097,2309,1025,1,257,0,5376,512]

theorem envBound17168 : H12AffineFastState.Bounded env17168 := by
  intro p hp
  have h : env17168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17167_17168 : H12AffineEnvironment.transform 4 1 env17167 = env17168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17167 == env17168) = true)

theorem identity17168 : scanCanonicalize (H12AffineFastState.compose env17168 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound17168 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17169 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,1029,8,260,261,263,277,2308,1025,260,1296,261,277,262,8,17,2048,17,1028,2309,1025,1,257,0,261,512]

theorem envBound17169 : H12AffineFastState.Bounded env17169 := by
  intro p hp
  have h : env17169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17168_17169 : H12AffineEnvironment.transform 11 1029 env17168 = env17169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env17168 == env17169) = true)

theorem identity17169 : scanCanonicalize (H12AffineFastState.compose env17169 (packedSelected [2,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17169 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env17170 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1,1029,8,260,261,263,277,261,1025,260,1296,261,277,262,8,17,1,17,1028,260,1025,1,257,0,261,512]

theorem envBound17170 : H12AffineFastState.Bounded env17170 := by
  intro p hp
  have h : env17170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17169_17170 : H12AffineEnvironment.transform 10 1 env17169 = env17170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17169 == env17170) = true)

theorem identity17170 : scanCanonicalize (H12AffineFastState.compose env17170 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17170 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env17171 : List Nat := [2,4,8,16,1,17,8,256,512,273,1,276,8,260,261,263,277,261,272,260,1,261,277,262,8,17,1,17,277,260,272,1,257,0,261,512]

theorem envBound17171 : H12AffineFastState.Bounded env17171 := by
  intro p hp
  have h : env17171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17170_17171 : H12AffineEnvironment.transform 9 273 env17170 = env17171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17170 == env17171) = true)

theorem identity17171 : scanCanonicalize (H12AffineFastState.compose env17171 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17171 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env17172 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,17,8,1,0,2,16,0,21,1,1,0,16,3,8,17,1,17,16,1,21,1,4,0,0,512]

theorem envBound17172 : H12AffineFastState.Bounded env17172 := by
  intro p hp
  have h : env17172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17171_17172 : H12AffineEnvironment.transform 7 5 env17171 = env17172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17171 == env17172) = true)

theorem identity17172 : scanCanonicalize (H12AffineFastState.compose env17172 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound17172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17173 : List Nat := [2,4,8,16,1,17,8,5,16,20,1,17,8,1,0,2,16,0,21,1,1,0,16,3,8,17,1,17,16,1,21,1,4,0,0,16]

theorem envBound17173 : H12AffineFastState.Bounded env17173 := by
  intro p hp
  have h : env17173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17172_17173 : H12AffineEnvironment.transform 8 16 env17172 = env17173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env17172 == env17173) = true)

theorem identity17173 : scanCanonicalize (H12AffineFastState.compose env17173 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound17173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17174 : List Nat := [2,4,8,4,1,5,8,5,4,0,1,5,8,1,0,2,4,0,1,1,1,0,4,3,8,5,1,5,4,1,1,1,4,0,0,4]

theorem envBound17174 : H12AffineFastState.Bounded env17174 := by
  intro p hp
  have h : env17174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17173_17174 : H12AffineEnvironment.transform 3 4 env17173 = env17174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env17173 == env17174) = true)

def env17175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272392,144476,95496,8193,64,23809,139613,17664,262144,143640,400452,257,21792,16464,202310]

theorem envBound17175 : H12AffineFastState.Bounded env17175 := by
  intro p hp
  have h : env17175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17160_17175 : H12AffineEnvironment.transform 6 9 env17160 = env17175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17160 == env17175) = true)

theorem identity17175 : scanCanonicalize (H12AffineFastState.compose env17175 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound17175 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env17176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,215091,1025,29789,140301,221243,144476,95496,8193,64,23809,139613,17664,215091,143640,87159,257,21792,16464,202310]

theorem envBound17176 : H12AffineFastState.Bounded env17176 := by
  intro p hp
  have h : env17176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17175_17176 : H12AffineEnvironment.transform 17 215091 env17175 = env17176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env17175 == env17176) = true)

theorem identity17176 : scanCanonicalize (H12AffineFastState.compose env17176 (packedSelected [0,3,4,7,10,17,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound17176 : packedSelected [0,3,4,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10281,1025,29789,82967,33,87110,95496,8193,64,23809,82247,17664,10281,86274,87159,257,21792,16464,30300]

theorem envBound17177 : H12AffineFastState.Bounded env17177 := by
  intro p hp
  have h : env17177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17176_17177 : H12AffineEnvironment.transform 16 90138 env17176 = env17177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env17176 == env17177) = true)

theorem identity17177 : scanCanonicalize (H12AffineFastState.compose env17177 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17177 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,65536,70727,10281,1025,0,77898,33,73755,65877,8193,64,10588,79130,12637,10281,75103,73770,257,8573,13325,513]

theorem envBound17178 : H12AffineFastState.Bounded env17178 := by
  intro p hp
  have h : env17178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17177_17178 : H12AffineEnvironment.transform 13 13405 env17177 = env17178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17177 == env17178) = true)

theorem identity17178 : scanCanonicalize (H12AffineFastState.compose env17178 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17178 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17179 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,65536,70679,10281,1025,0,77850,33,73755,65797,8193,16,10508,79130,12557,10281,75023,73770,257,8493,13325,513]

theorem envBound17179 : H12AffineFastState.Bounded env17179 := by
  intro p hp
  have h : env17179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17178_17179 : H12AffineEnvironment.transform 5 16 env17178 = env17179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17178 == env17179) = true)

def env17180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,8388608,8601940,8328,64,4489557,8393984,8553864,8830976,181572,12645453,257,21793,46212,254611]

theorem envBound17180 : H12AffineFastState.Bounded env17180 := by
  intro p hp
  have h : env17180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17094_17180 : H12AffineEnvironment.transform 20 184537 env17094 = env17180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env17094 == env17180) = true)

def env17181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,98780,8328,64,4489557,185736,17664,262280,181572,4338885,257,21793,46212,254611]

theorem envBound17181 : H12AffineFastState.Bounded env17181 := by
  intro p hp
  have h : env17181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17180_17181 : H12AffineEnvironment.transform 22 180360 env17180 = env17181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env17180 == env17181) = true)

def env17182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,98780,8328,64,43477,185736,17664,262280,181572,400453,257,21793,46212,254611]

theorem envBound17182 : H12AffineFastState.Bounded env17182 := by
  intro p hp
  have h : env17182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17181_17182 : H12AffineEnvironment.transform 21 272512 env17181 = env17182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17181 == env17182) = true)

theorem identity17182 : scanCanonicalize (H12AffineFastState.compose env17182 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17182 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184537,272512,180360,41431,8328,64,43477,185736,17664,262280,181572,400453,257,21793,46212,180888]

theorem envBound17183 : H12AffineFastState.Bounded env17183 := by
  intro p hp
  have h : env17183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17182_17183 : H12AffineEnvironment.transform 15 8203 env17182 = env17183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17182 == env17183) = true)

theorem identity17183 : scanCanonicalize (H12AffineFastState.compose env17183 (packedSelected [4,7,9,12,15,27,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound17183 : packedSelected [4,7,9,12,15,27,38,41] rootPS < 2^1333 := by decide +kernel

def env17184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,37064,272512,32921,41431,8328,64,43477,38297,17664,262280,34133,285780,257,21793,46212,33417]

theorem envBound17184 : H12AffineFastState.Bounded env17184 := by
  intro p hp
  have h : env17184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17183_17184 : H12AffineEnvironment.transform 16 16401 env17183 = env17184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17183 == env17184) = true)

theorem identity17184 : scanCanonicalize (H12AffineFastState.compose env17184 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32240) := by decide +kernel

theorem selectedBound17184 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env17185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,32240,1025,32769,37064,21872,32921,41431,8328,64,43477,38297,17664,32120,34133,8612,257,21793,46212,33417]

theorem envBound17185 : H12AffineFastState.Bounded env17185 := by
  intro p hp
  have h : env17185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17184_17185 : H12AffineEnvironment.transform 17 32240 env17184 = env17185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env17184 == env17185) = true)

theorem identity17185 : scanCanonicalize (H12AffineFastState.compose env17185 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound17185 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env17186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21841,8203,16401,32240,1025,21840,17817,21872,21960,29830,8328,64,31876,16584,17664,32120,20484,8612,257,21793,25045,22488]

theorem envBound17186 : H12AffineFastState.Bounded env17186 := by
  intro p hp
  have h : env17186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17185_17186 : H12AffineEnvironment.transform 14 21841 env17185 = env17186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env17185 == env17186) = true)

theorem identity17186 : scanCanonicalize (H12AffineFastState.compose env17186 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound17186 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env17187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,137,8203,5577,10280,1025,136,4161,168,16,8542,8328,64,10588,5392,4312,10400,1500,8612,257,249,13325,512]

theorem envBound17187 : H12AffineFastState.Bounded env17187 := by
  intro p hp
  have h : env17187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17186_17187 : H12AffineEnvironment.transform 13 5592 env17186 = env17187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env17186 == env17187) = true)

theorem identity17187 : scanCanonicalize (H12AffineFastState.compose env17187 (packedSelected [1,3,6,10,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound17187 : packedSelected [1,3,6,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3607,5592,137,3612,5577,1599,1025,136,4161,168,16,3913,3743,64,1867,5392,4312,1719,1500,4019,257,249,6682,512]

theorem envBound17188 : H12AffineFastState.Bounded env17188 := by
  intro p hp
  have h : env17188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17187_17188 : H12AffineEnvironment.transform 12 3607 env17187 = env17188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env17187 == env17188) = true)

theorem identity17188 : scanCanonicalize (H12AffineFastState.compose env17188 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound17188 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1647,4096,120,5592,137,115,5577,1599,1025,136,4161,168,16,294,240,64,1867,5392,4312,1719,1500,476,257,249,5237,512]

theorem envBound17189 : H12AffineFastState.Bounded env17189 := by
  intro p hp
  have h : env17189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17188_17189 : H12AffineEnvironment.transform 10 1647 env17188 = env17189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env17188 == env17189) = true)

theorem identity17189 : scanCanonicalize (H12AffineFastState.compose env17189 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound17189 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1647,65,120,1433,137,115,1416,1599,1025,136,0,168,16,294,240,64,1867,1361,153,1719,1500,476,257,249,1076,512]

theorem envBound17190 : H12AffineFastState.Bounded env17190 := by
  intro p hp
  have h : env17190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17189_17190 : H12AffineEnvironment.transform 11 65 env17189 = env17190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env17189 == env17190) = true)

theorem identity17190 : scanCanonicalize (H12AffineFastState.compose env17190 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound17190 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17191 : List Nat := [2,4,8,16,32,64,128,256,512,69,554,65,120,476,137,115,461,634,68,136,0,168,16,294,240,64,782,276,153,754,409,476,257,249,113,512]

theorem envBound17191 : H12AffineFastState.Bounded env17191 := by
  intro p hp
  have h : env17191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17190_17191 : H12AffineEnvironment.transform 9 69 env17190 = env17191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env17190 == env17191) = true)

theorem identity17191 : scanCanonicalize (H12AffineFastState.compose env17191 (packedSelected [0,1,3,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound17191 : packedSelected [0,1,3,7,10] rootPS < 2^1333 := by decide +kernel

def env17192 : List Nat := [2,4,8,16,32,64,128,256,303,69,261,65,120,476,137,115,461,341,68,136,0,168,16,294,240,64,33,276,153,477,409,476,257,249,113,303]

theorem envBound17192 : H12AffineFastState.Bounded env17192 := by
  intro p hp
  have h : env17192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17191_17192 : H12AffineEnvironment.transform 8 303 env17191 = env17192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env17191 == env17192) = true)

theorem identity17192 : scanCanonicalize (H12AffineFastState.compose env17192 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound17192 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17193 : List Nat := [2,4,8,16,32,64,128,253,210,69,248,65,120,33,137,115,48,168,68,136,0,168,16,219,240,64,33,233,153,32,100,33,252,249,113,210]

theorem envBound17193 : H12AffineFastState.Bounded env17193 := by
  intro p hp
  have h : env17193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17192_17193 : H12AffineEnvironment.transform 7 253 env17192 = env17193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env17192 == env17193) = true)

theorem identity17193 : scanCanonicalize (H12AffineFastState.compose env17193 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 113) := by decide +kernel

theorem selectedBound17193 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17194 : List Nat := [2,4,8,16,32,64,113,12,35,69,9,65,120,33,120,115,48,89,68,121,0,89,16,42,1,64,33,24,104,32,100,33,13,8,113,35]

theorem envBound17194 : H12AffineFastState.Bounded env17194 := by
  intro p hp
  have h : env17194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17193_17194 : H12AffineEnvironment.transform 6 113 env17193 = env17194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 113 env17193 == env17194) = true)

theorem identity17194 : scanCanonicalize (H12AffineFastState.compose env17194 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 25) := by decide +kernel

theorem selectedBound17194 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17195 : List Nat := [2,4,8,16,32,25,40,12,35,28,9,24,33,33,33,42,48,0,29,32,0,0,16,42,1,25,33,24,49,32,61,33,13,8,40,35]

theorem envBound17195 : H12AffineFastState.Bounded env17195 := by
  intro p hp
  have h : env17195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17194_17195 : H12AffineEnvironment.transform 5 25 env17194 = env17195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 25 env17194 == env17195) = true)

def env17196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,98780,8328,64,43476,185736,17664,262280,181572,400452,257,21793,46212,254611]

theorem envBound17196 : H12AffineFastState.Bounded env17196 := by
  intro p hp
  have h : env17196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17181_17196 : H12AffineEnvironment.transform 21 272513 env17181 = env17196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17181 == env17196) = true)

theorem identity17196 : scanCanonicalize (H12AffineFastState.compose env17196 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound17196 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,77899,272513,73754,98780,8328,64,43476,79130,17664,262280,75222,392406,257,21793,46212,513]

theorem envBound17197 : H12AffineFastState.Bounded env17197 := by
  intro p hp
  have h : env17197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17196_17197 : H12AffineEnvironment.transform 16 123026 env17196 = env17197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env17196 == env17197) = true)

def env17198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90258,262144,1025,1,77899,272513,73754,66012,8328,64,10708,79130,17664,262280,75222,359638,257,21793,13444,513]

theorem envBound17198 : H12AffineFastState.Bounded env17198 := by
  intro p hp
  have h : env17198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17197_17198 : H12AffineEnvironment.transform 14 0 env17197 = env17198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17197 == env17198) = true)

theorem identity17198 : scanCanonicalize (H12AffineFastState.compose env17198 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17198 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env17199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16400,262144,1025,1,4297,272513,152,8542,8328,64,10708,5528,17664,262280,1364,285780,257,21793,13444,513]

theorem envBound17199 : H12AffineFastState.Bounded env17199 := by
  intro p hp
  have h : env17199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17198_17199 : H12AffineEnvironment.transform 15 8322 env17198 = env17199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17198 == env17199) = true)

theorem identity17199 : scanCanonicalize (H12AffineFastState.compose env17199 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound17199 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env17200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16400,10281,1025,1,4297,168,152,8542,8328,64,10708,5528,17664,10401,1364,29821,257,21793,13444,513]

theorem envBound17200 : H12AffineFastState.Bounded env17200 := by
  intro p hp
  have h : env17200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17199_17200 : H12AffineEnvironment.transform 17 10281 env17199 = env17200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env17199 == env17200) = true)

theorem identity17200 : scanCanonicalize (H12AffineFastState.compose env17200 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound17200 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env17201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,0,342,16400,2557,1025,1,4297,168,152,138,348,64,2048,5528,17664,2421,1364,21929,257,21793,5456,513]

theorem envBound17201 : H12AffineFastState.Bounded env17201 := by
  intro p hp
  have h : env17201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17200_17201 : H12AffineEnvironment.transform 12 468 env17200 = env17201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env17200 == env17201) = true)

theorem identity17201 : scanCanonicalize (H12AffineFastState.compose env17201 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17201 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env17202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,342,5392,2557,1025,1,4297,168,152,138,348,64,2048,5528,4096,2421,1364,169,257,33,5456,513]

theorem envBound17202 : H12AffineFastState.Bounded env17202 := by
  intro p hp
  have h : env17202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17201_17202 : H12AffineEnvironment.transform 13 5376 env17201 = env17202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17201 == env17202) = true)

theorem identity17202 : scanCanonicalize (H12AffineFastState.compose env17202 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17202 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5392,2421,1025,1,4161,32,16,2,348,64,2048,5392,4096,2421,1364,33,257,33,5456,513]

theorem envBound17203 : H12AffineFastState.Bounded env17203 := by
  intro p hp
  have h : env17203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17202_17203 : H12AffineEnvironment.transform 6 8 env17202 = env17203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17202 == env17203) = true)

theorem identity17203 : scanCanonicalize (H12AffineFastState.compose env17203 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17203 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17204 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4113,0,342,4097,2421,272,1,4161,32,16,2,348,64,2048,4097,4096,2421,69,33,257,33,4161,513]

theorem envBound17204 : H12AffineFastState.Bounded env17204 := by
  intro p hp
  have h : env17204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17203_17204 : H12AffineEnvironment.transform 9 273 env17203 = env17204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17203 == env17204) = true)

theorem identity17204 : scanCanonicalize (H12AffineFastState.compose env17204 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17205 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4113,0,263,4097,2340,272,1,4112,32,16,2,269,17,2048,4097,4096,2340,20,33,257,33,4112,513]

theorem envBound17205 : H12AffineFastState.Bounded env17205 := by
  intro p hp
  have h : env17205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17204_17205 : H12AffineEnvironment.transform 5 17 env17204 = env17205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17204 == env17205) = true)

theorem identity17205 : scanCanonicalize (H12AffineFastState.compose env17205 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound17205 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17206 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,308,269,293,0,263,309,2340,272,1,292,32,16,2,269,17,2048,309,308,2340,20,33,257,33,292,513]

theorem envBound17206 : H12AffineFastState.Bounded env17206 := by
  intro p hp
  have h : env17206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17205_17206 : H12AffineEnvironment.transform 11 308 env17205 = env17206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env17205 == env17206) = true)

theorem identity17206 : scanCanonicalize (H12AffineFastState.compose env17206 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound17206 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17207 : List Nat := [2,4,8,16,32,17,8,256,512,273,293,308,269,293,0,263,309,1,272,1,292,32,16,2,269,17,293,309,308,1,20,33,257,33,292,513]

theorem envBound17207 : H12AffineFastState.Bounded env17207 := by
  intro p hp
  have h : env17207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17206_17207 : H12AffineEnvironment.transform 10 293 env17206 = env17207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17206 == env17207) = true)

theorem identity17207 : scanCanonicalize (H12AffineFastState.compose env17207 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17207 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17208 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,16,41,1,0,35,17,1,52,1,0,32,16,2,41,17,1,17,16,1,20,33,37,33,0,513]

theorem envBound17208 : H12AffineFastState.Bounded env17208 := by
  intro p hp
  have h : env17208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17207_17208 : H12AffineEnvironment.transform 7 36 env17207 = env17208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17207 == env17208) = true)

theorem identity17208 : scanCanonicalize (H12AffineFastState.compose env17208 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17209 : List Nat := [2,4,8,16,17,17,8,21,512,4,1,16,24,1,0,18,17,1,5,1,0,17,16,2,24,17,1,17,16,1,20,16,20,16,0,513]

theorem envBound17209 : H12AffineFastState.Bounded env17209 := by
  intro p hp
  have h : env17209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17208_17209 : H12AffineEnvironment.transform 4 17 env17208 = env17209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17208 == env17209) = true)

theorem identity17209 : scanCanonicalize (H12AffineFastState.compose env17209 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17210 : List Nat := [2,4,8,16,17,17,8,21,0,4,1,16,24,1,0,18,17,1,5,1,0,17,16,2,24,17,1,17,16,1,20,16,20,16,0,1]

theorem envBound17210 : H12AffineFastState.Bounded env17210 := by
  intro p hp
  have h : env17210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17209_17210 : H12AffineEnvironment.transform 8 0 env17209 = env17210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17209 == env17210) = true)

def env17211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90259,262144,1025,0,77899,272513,73754,66013,8328,64,10709,79130,17664,262280,75222,359639,257,21793,13445,513]

theorem envBound17211 : H12AffineFastState.Bounded env17211 := by
  intro p hp
  have h : env17211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17197_17211 : H12AffineEnvironment.transform 14 1 env17197 = env17211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17197 == env17211) = true)

theorem identity17211 : scanCanonicalize (H12AffineFastState.compose env17211 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17211 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,262144,1025,0,77899,272392,73754,65876,8193,64,10588,79130,17664,262145,75103,359518,257,21793,13324,513]

theorem envBound17212 : H12AffineFastState.Bounded env17212 := by
  intro p hp
  have h : env17212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17211_17212 : H12AffineEnvironment.transform 6 9 env17211 = env17212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17211 == env17212) = true)

theorem identity17212 : scanCanonicalize (H12AffineFastState.compose env17212 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound17212 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env17213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,67618,1025,0,77899,73770,73754,65876,8193,64,10588,79130,17664,67619,75103,29820,257,21793,13324,513]

theorem envBound17213 : H12AffineFastState.Bounded env17213 := by
  intro p hp
  have h : env17213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17212_17213 : H12AffineEnvironment.transform 17 67618 env17212 = env17213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env17212 == env17213) = true)

theorem identity17213 : scanCanonicalize (H12AffineFastState.compose env17213 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound17213 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env17214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,65536,70726,67618,1025,0,77899,73770,73754,65876,8193,64,10588,79130,12636,67619,75103,32,257,8573,13324,513]

theorem envBound17214 : H12AffineFastState.Bounded env17214 := by
  intro p hp
  have h : env17214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17213_17214 : H12AffineEnvironment.transform 13 13404 env17213 = env17214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env17213 == env17214) = true)

theorem identity17214 : scanCanonicalize (H12AffineFastState.compose env17214 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17214 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,70726,67618,1025,0,69911,65910,65862,65876,349,64,2048,70726,4096,67619,66563,32,257,33,5456,513]

theorem envBound17215 : H12AffineFastState.Bounded env17215 := by
  intro p hp
  have h : env17215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17214_17215 : H12AffineEnvironment.transform 12 348 env17214 = env17215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17214 == env17215) = true)

theorem identity17215 : scanCanonicalize (H12AffineFastState.compose env17215 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound17215 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5393,2421,1025,0,4160,33,17,3,349,64,2048,5393,4096,2420,1364,32,257,33,5456,513]

theorem envBound17216 : H12AffineFastState.Bounded env17216 := by
  intro p hp
  have h : env17216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17215_17216 : H12AffineEnvironment.transform 15 343 env17215 = env17216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env17215 == env17216) = true)

theorem identity17216 : scanCanonicalize (H12AffineFastState.compose env17216 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound17216 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,348,1124,1,343,1141,2421,1025,0,292,33,17,3,349,64,2048,1141,356,2420,1364,32,257,33,1076,513]

theorem envBound17217 : H12AffineFastState.Bounded env17217 := by
  intro p hp
  have h : env17217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17216_17217 : H12AffineEnvironment.transform 11 356 env17216 = env17217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env17216 == env17217) = true)

theorem identity17217 : scanCanonicalize (H12AffineFastState.compose env17217 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound17217 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,356,348,1124,1,343,1141,1297,1025,0,292,33,17,3,349,64,1124,1141,356,1296,1364,32,257,33,1076,513]

theorem envBound17218 : H12AffineFastState.Bounded env17218 := by
  intro p hp
  have h : env17218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17217_17218 : H12AffineEnvironment.transform 10 1124 env17217 = env17218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env17217 == env17218) = true)

theorem identity17218 : scanCanonicalize (H12AffineFastState.compose env17218 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound17218 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env17219 : List Nat := [2,4,8,16,32,64,9,256,308,1024,1124,356,348,1124,1,343,1141,1297,1025,0,292,33,17,3,349,64,1124,1141,356,1296,1364,32,257,33,1076,309]

theorem envBound17219 : H12AffineFastState.Bounded env17219 := by
  intro p hp
  have h : env17219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17218_17219 : H12AffineEnvironment.transform 8 308 env17218 = env17219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env17218 == env17219) = true)

theorem identity17219 : scanCanonicalize (H12AffineFastState.compose env17219 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17219 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env17220 : List Nat := [2,4,8,16,17,64,9,256,261,1024,1109,341,348,1109,1,343,1092,1297,1025,0,277,16,17,3,349,64,1109,1092,341,1296,1364,17,257,16,1029,260]

theorem envBound17220 : H12AffineFastState.Bounded env17220 := by
  intro p hp
  have h : env17220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17219_17220 : H12AffineEnvironment.transform 4 17 env17219 = env17220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17219 == env17220) = true)

theorem identity17220 : scanCanonicalize (H12AffineFastState.compose env17220 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17220 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env17221 : List Nat := [2,4,8,0,1,64,9,256,261,1024,1093,325,332,1093,1,327,1092,1281,1025,0,261,0,1,3,333,64,1093,1092,325,1280,1348,1,257,0,1029,260]

theorem envBound17221 : H12AffineFastState.Bounded env17221 := by
  intro p hp
  have h : env17221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17220_17221 : H12AffineEnvironment.transform 3 0 env17220 = env17221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17220 == env17221) = true)

theorem identity17221 : scanCanonicalize (H12AffineFastState.compose env17221 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound17221 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env17222 : List Nat := [2,4,8,0,1,0,9,256,261,1024,1029,261,268,1029,1,263,1028,1281,1025,0,261,0,1,3,269,0,1029,1028,261,1280,1284,1,257,0,1029,260]

theorem envBound17222 : H12AffineFastState.Bounded env17222 := by
  intro p hp
  have h : env17222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17221_17222 : H12AffineEnvironment.transform 5 0 env17221 = env17222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17221 == env17222) = true)

theorem identity17222 : scanCanonicalize (H12AffineFastState.compose env17222 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound17222 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17223 : List Nat := [2,4,8,0,1,0,9,256,261,257,260,261,268,260,1,263,261,0,256,0,261,0,1,3,269,0,260,261,261,1,5,1,257,0,260,260]

theorem envBound17223 : H12AffineFastState.Bounded env17223 := by
  intro p hp
  have h : env17223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17222_17223 : H12AffineEnvironment.transform 9 257 env17222 = env17223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env17222 == env17223) = true)

theorem identity17223 : scanCanonicalize (H12AffineFastState.compose env17223 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17224 : List Nat := [2,4,8,0,1,0,9,4,1,5,0,1,8,0,1,3,1,0,4,0,1,0,1,3,9,0,0,1,1,1,5,1,5,0,0,0]

theorem envBound17224 : H12AffineFastState.Bounded env17224 := by
  intro p hp
  have h : env17224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17223_17224 : H12AffineEnvironment.transform 7 4 env17223 = env17224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17223 == env17224) = true)

def env17225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,98781,8328,64,4489557,185737,17665,262281,181572,4338884,257,21793,46212,254611]

theorem envBound17225 : H12AffineFastState.Bounded env17225 := by
  intro p hp
  have h : env17225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17180_17225 : H12AffineEnvironment.transform 22 180361 env17180 = env17225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env17180 == env17225) = true)

def env17226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,98781,8328,64,43477,185737,17665,262281,181572,400452,257,21793,46212,254611]

theorem envBound17226 : H12AffineFastState.Bounded env17226 := by
  intro p hp
  have h : env17226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17225_17226 : H12AffineEnvironment.transform 21 272512 env17225 = env17226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17225 == env17226) = true)

theorem identity17226 : scanCanonicalize (H12AffineFastState.compose env17226 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound17226 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184537,272512,180361,21763,8328,64,43477,185737,17665,262281,181572,400452,257,21793,46212,144973]

theorem envBound17227 : H12AffineFastState.Bounded env17227 := by
  intro p hp
  have h : env17227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17226_17227 : H12AffineEnvironment.transform 15 54494 env17226 = env17227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env17226 == env17227) = true)

def env17228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,184401,272392,180225,21763,8192,64,43357,185601,17665,262145,181572,400452,257,21793,46092,144973]

theorem envBound17228 : H12AffineFastState.Bounded env17228 := by
  intro p hp
  have h : env17228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17227_17228 : H12AffineEnvironment.transform 6 8 env17227 = env17228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17227 == env17228) = true)

theorem identity17228 : scanCanonicalize (H12AffineFastState.compose env17228 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17228 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env17229 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,184401,272392,180225,21623,8192,64,43049,185461,17525,262145,181296,400452,117,21589,46092,144973]

theorem envBound17229 : H12AffineFastState.Bounded env17229 := by
  intro p hp
  have h : env17229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17228_17229 : H12AffineEnvironment.transform 7 116 env17228 = env17229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17228 == env17229) = true)

theorem identity17229 : scanCanonicalize (H12AffineFastState.compose env17229 (packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound17229 : packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env17230 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,131072,157752,1025,32769,184401,147504,180225,21623,8192,64,43049,185461,17525,157753,181296,29820,117,21589,46092,144973]

theorem envBound17230 : H12AffineFastState.Bounded env17230 := by
  intro p hp
  have h : env17230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17229_17230 : H12AffineEnvironment.transform 17 157752 env17229 = env17230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env17229 == env17230) = true)

theorem identity17230 : scanCanonicalize (H12AffineFastState.compose env17230 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17230 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env17231 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,32768,54358,131072,149520,1025,32769,184401,147504,180225,21623,40,64,34817,185461,17525,149521,181296,21588,117,21589,37924,136805]

theorem envBound17231 : H12AffineFastState.Bounded env17231 := by
  intro p hp
  have h : env17231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17230_17231 : H12AffineEnvironment.transform 12 40 env17230 = env17231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17230 == env17231) = true)

theorem identity17231 : scanCanonicalize (H12AffineFastState.compose env17231 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound17231 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env17232 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,32768,54358,16400,2048,1025,32769,36929,32,32785,21623,40,64,34817,37989,17525,2049,33824,21588,117,21589,37924,22133]

theorem envBound17232 : H12AffineFastState.Bounded env17232 := by
  intro p hp
  have h : env17232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17231_17232 : H12AffineEnvironment.transform 16 16400 env17231 = env17232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17231 == env17232) = true)

theorem identity17232 : scanCanonicalize (H12AffineFastState.compose env17232 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound17232 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17233 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,1124,20530,16400,2048,1025,1125,5157,32,1141,21623,40,64,3173,4097,17525,2049,68,21588,117,21589,4160,22133]

theorem envBound17233 : H12AffineFastState.Bounded env17233 := by
  intro p hp
  have h : env17233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17232_17233 : H12AffineEnvironment.transform 14 1124 env17232 = env17233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env17232 == env17233) = true)

theorem identity17233 : scanCanonicalize (H12AffineFastState.compose env17233 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17233 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17234 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,4112,1124,34,4096,2048,1025,1125,5157,32,1141,1127,40,64,3173,4097,5221,2049,68,1092,117,1093,4160,1637]

theorem envBound17234 : H12AffineFastState.Bounded env17234 := by
  intro p hp
  have h : env17234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17233_17234 : H12AffineEnvironment.transform 13 4112 env17233 = env17234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env17233 == env17234) = true)

theorem identity17234 : scanCanonicalize (H12AffineFastState.compose env17234 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound17234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17235 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,113,40,97,1124,34,113,2048,1025,1125,1108,32,1141,1127,40,64,3173,112,1044,2049,68,1092,117,1093,49,1637]

theorem envBound17235 : H12AffineFastState.Bounded env17235 := by
  intro p hp
  have h : env17235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17234_17235 : H12AffineEnvironment.transform 11 113 env17234 = env17235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env17234 == env17235) = true)

theorem identity17235 : scanCanonicalize (H12AffineFastState.compose env17235 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound17235 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17236 : List Nat := [2,4,8,16,32,64,8,116,512,20,2048,113,40,97,112,34,113,2048,21,113,64,32,97,115,40,64,2161,112,0,2049,68,80,117,81,49,625]

theorem envBound17236 : H12AffineFastState.Bounded env17236 := by
  intro p hp
  have h : env17236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17235_17236 : H12AffineEnvironment.transform 9 20 env17235 = env17236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17235 == env17236) = true)

theorem identity17236 : scanCanonicalize (H12AffineFastState.compose env17236 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17237 : List Nat := [2,4,8,16,0,64,8,84,512,20,2048,81,8,65,80,2,81,2048,21,81,64,0,65,83,8,64,2129,80,0,2049,68,80,85,81,17,593]

theorem envBound17237 : H12AffineFastState.Bounded env17237 := by
  intro p hp
  have h : env17237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17236_17237 : H12AffineEnvironment.transform 4 0 env17236 = env17237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17236 == env17237) = true)

theorem identity17237 : scanCanonicalize (H12AffineFastState.compose env17237 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound17237 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17238 : List Nat := [2,4,8,16,0,0,8,20,512,20,2048,17,8,1,16,2,17,2048,21,17,0,0,1,19,8,0,2065,16,0,2049,4,16,21,17,17,529]

theorem envBound17238 : H12AffineFastState.Bounded env17238 := by
  intro p hp
  have h : env17238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17237_17238 : H12AffineEnvironment.transform 5 0 env17237 = env17238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17237 == env17238) = true)

theorem identity17238 : scanCanonicalize (H12AffineFastState.compose env17238 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound17238 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env17239 : List Nat := [2,4,8,16,0,0,8,20,512,20,528,17,8,1,16,2,17,528,21,17,0,0,1,19,8,0,513,16,0,529,4,16,21,17,17,529]

theorem envBound17239 : H12AffineFastState.Bounded env17239 := by
  intro p hp
  have h : env17239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17238_17239 : H12AffineEnvironment.transform 10 528 env17238 = env17239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env17238 == env17239) = true)

theorem identity17239 : scanCanonicalize (H12AffineFastState.compose env17239 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17239 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17240 : List Nat := [2,4,8,0,0,0,8,4,512,4,512,1,8,1,0,2,1,512,5,1,0,0,1,3,8,0,513,0,0,513,4,0,5,1,1,513]

theorem envBound17240 : H12AffineFastState.Bounded env17240 := by
  intro p hp
  have h : env17240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17239_17240 : H12AffineEnvironment.transform 3 0 env17239 = env17240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17239 == env17240) = true)

theorem identity17240 : scanCanonicalize (H12AffineFastState.compose env17240 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17241 : List Nat := [2,4,8,0,0,0,8,4,1,4,1,1,8,1,0,2,1,1,5,1,0,0,1,3,8,0,0,0,0,0,4,0,5,1,1,0]

theorem envBound17241 : H12AffineFastState.Bounded env17241 := by
  intro p hp
  have h : env17241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17240_17241 : H12AffineEnvironment.transform 8 1 env17240 = env17241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17240 == env17241) = true)

def env17242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,184400,272393,180224,21763,8193,64,43356,185600,17665,262144,181572,400452,257,21793,46093,144973]

theorem envBound17242 : H12AffineFastState.Bounded env17242 := by
  intro p hp
  have h : env17242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17227_17242 : H12AffineEnvironment.transform 6 9 env17227 = env17242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17227 == env17242) = true)

theorem identity17242 : scanCanonicalize (H12AffineFastState.compose env17242 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound17242 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env17243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,184400,21793,180224,21763,8193,64,43356,185600,17665,32040,181572,156012,257,21793,46093,144973]

theorem envBound17243 : H12AffineFastState.Bounded env17243 := by
  intro p hp
  have h : env17243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17242_17243 : H12AffineEnvironment.transform 17 32040 env17242 = env17243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env17242 == env17243) = true)

theorem identity17243 : scanCanonicalize (H12AffineFastState.compose env17243 (packedSelected [0,4,5,12,14,15,16,17,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound17243 : packedSelected [0,4,5,12,14,15,16,17,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,131072,32040,1025,8461,160092,21793,155916,21763,8193,64,2128,160780,17665,32040,156744,156012,257,21793,5377,144973]

theorem envBound17244 : H12AffineFastState.Bounded env17244 := by
  intro p hp
  have h : env17244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17243_17244 : H12AffineEnvironment.transform 14 8460 env17243 = env17244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env17243 == env17244) = true)

theorem identity17244 : scanCanonicalize (H12AffineFastState.compose env17244 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound17244 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30043,13340,32040,1025,8461,17728,21793,21776,21763,8193,64,2128,16400,17665,32040,20564,21872,257,21793,5377,593]

theorem envBound17245 : H12AffineFastState.Bounded env17245 := by
  intro p hp
  have h : env17245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17244_17245 : H12AffineEnvironment.transform 16 13340 env17244 = env17245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env17244 == env17245) = true)

theorem identity17245 : scanCanonicalize (H12AffineFastState.compose env17245 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17245 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17246 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,29963,13340,32040,1025,8461,17680,21793,21776,21763,8193,16,2048,16400,17665,32040,20484,21792,257,21793,5377,513]

theorem envBound17246 : H12AffineFastState.Bounded env17246 := by
  intro p hp
  have h : env17246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17245_17246 : H12AffineEnvironment.transform 5 16 env17245 = env17246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17245 == env17246) = true)

theorem identity17246 : scanCanonicalize (H12AffineFastState.compose env17246 (packedSelected [1,2,4,6,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound17246 : packedSelected [1,2,4,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env17247 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,16384,1297,20758,4097,22837,1025,1296,17680,21793,21776,21763,1052,16,2048,16400,17665,22837,20484,21792,257,21793,5377,513]

theorem envBound17247 : H12AffineFastState.Bounded env17247 := by
  intro p hp
  have h : env17247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17246_17247 : H12AffineEnvironment.transform 12 1053 env17246 = env17247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env17246 == env17247) = true)

theorem identity17247 : scanCanonicalize (H12AffineFastState.compose env17247 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17247 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env17248 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,4112,1297,262,4097,2341,1025,1296,5376,1329,1280,1299,1052,16,2048,4096,5393,2341,20,1328,257,1329,5377,513]

theorem envBound17248 : H12AffineFastState.Bounded env17248 := by
  intro p hp
  have h : env17248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17247_17248 : H12AffineEnvironment.transform 13 4112 env17247 = env17248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env17247 == env17248) = true)

def env17249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,98781,8328,64,43476,185737,17665,262281,181572,400453,257,21793,46212,254611]

theorem envBound17249 : H12AffineFastState.Bounded env17249 := by
  intro p hp
  have h : env17249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17225_17249 : H12AffineEnvironment.transform 21 272513 env17225 = env17249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17225 == env17249) = true)

theorem identity17249 : scanCanonicalize (H12AffineFastState.compose env17249 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound17249 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,115871,272513,120015,98781,8328,64,43476,115151,17665,262281,119042,329731,257,21793,46212,63189]

theorem envBound17250 : H12AffineFastState.Bounded env17250 := by
  intro p hp
  have h : env17250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17249_17250 : H12AffineEnvironment.transform 16 70726 env17249 = env17250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env17249 == env17250) = true)

def env17251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,115871,33,120015,98781,8328,64,43476,115151,17665,10281,119042,73891,257,21793,46212,63189]

theorem envBound17251 : H12AffineFastState.Bounded env17251 := by
  intro p hp
  have h : env17251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17250_17251 : H12AffineEnvironment.transform 17 10400 env17250 = env17251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17250 == env17251) = true)

theorem identity17251 : scanCanonicalize (H12AffineFastState.compose env17251 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound17251 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env17252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,70726,10400,1025,137,82967,33,87111,65877,8328,64,10588,82247,17665,10281,86410,73891,257,21793,13324,30301]

theorem envBound17252 : H12AffineFastState.Bounded env17252 := by
  intro p hp
  have h : env17252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17251_17252 : H12AffineEnvironment.transform 14 136 env17251 = env17252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env17251 == env17252) = true)

theorem identity17252 : scanCanonicalize (H12AffineFastState.compose env17252 (packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17252 : packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env17253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,8203,13389,10400,1025,137,25628,33,29772,8542,8328,64,10588,24908,17665,10281,29057,168,257,21793,13324,30301]

theorem envBound17253 : H12AffineFastState.Bounded env17253 := by
  intro p hp
  have h : env17253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17252_17253 : H12AffineEnvironment.transform 15 8203 env17252 = env17253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17252 == env17253) = true)

theorem identity17253 : scanCanonicalize (H12AffineFastState.compose env17253 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound17253 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env17254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,13389,10400,1025,137,4160,33,16,8542,8328,64,10588,5392,12637,10281,1501,168,257,8573,13324,513]

theorem envBound17254 : H12AffineFastState.Bounded env17254 := by
  intro p hp
  have h : env17254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17253_17254 : H12AffineEnvironment.transform 13 13404 env17253 = env17254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env17253 == env17254) = true)

theorem identity17254 : scanCanonicalize (H12AffineFastState.compose env17254 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17254 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17255 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,8203,13341,10400,1025,137,4112,33,16,8462,8328,16,10508,5392,12557,10281,1421,168,257,8493,13324,513]

theorem envBound17255 : H12AffineFastState.Bounded env17255 := by
  intro p hp
  have h : env17255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17254_17255 : H12AffineEnvironment.transform 5 16 env17254 = env17255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17254 == env17255) = true)

theorem identity17255 : scanCanonicalize (H12AffineFastState.compose env17255 (packedSelected [7,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5644) := by decide +kernel

theorem selectedBound17255 : packedSelected [7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env17256 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5644,512,136,5639,529,7852,1025,137,4112,33,16,5890,5764,16,7936,5392,1793,7717,1421,168,257,5921,512,513]

theorem envBound17256 : H12AffineFastState.Bounded env17256 := by
  intro p hp
  have h : env17256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17255_17256 : H12AffineEnvironment.transform 12 5644 env17255 = env17256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5644 env17255 == env17256) = true)

theorem identity17256 : scanCanonicalize (H12AffineFastState.compose env17256 (packedSelected [0,2,4,5,7,8,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 2444) := by decide +kernel

theorem selectedBound17256 : packedSelected [0,2,4,5,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env17257 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2444,3968,512,136,3979,529,1824,1025,137,2460,33,16,3726,3848,16,1676,3228,1793,1961,1421,168,257,3757,512,513]

theorem envBound17257 : H12AffineFastState.Bounded env17257 := by
  intro p hp
  have h : env17257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17256_17257 : H12AffineEnvironment.transform 11 2444 env17256 = env17257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2444 env17256 == env17257) = true)

theorem identity17257 : scanCanonicalize (H12AffineFastState.compose env17257 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound17257 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17258 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1541,1929,389,512,136,398,529,1824,1025,137,1945,33,16,139,269,16,1676,665,1793,1961,1421,168,257,168,512,513]

theorem envBound17258 : H12AffineFastState.Bounded env17258 := by
  intro p hp
  have h : env17258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17257_17258 : H12AffineEnvironment.transform 10 1541 env17257 = env17258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env17257 == env17258) = true)

theorem identity17258 : scanCanonicalize (H12AffineFastState.compose env17258 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound17258 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17259 : List Nat := [2,4,8,16,32,16,128,256,277,1024,1296,1180,389,277,136,398,260,1077,1025,137,1164,33,16,139,269,16,1433,396,1044,1212,1421,168,257,168,277,276]

theorem envBound17259 : H12AffineFastState.Bounded env17259 := by
  intro p hp
  have h : env17259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17258_17259 : H12AffineEnvironment.transform 8 277 env17258 = env17259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env17258 == env17259) = true)

theorem identity17259 : scanCanonicalize (H12AffineFastState.compose env17259 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17259 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env17260 : List Nat := [2,4,8,16,32,16,9,256,277,1024,1296,1045,268,277,1,263,260,1077,1025,0,1029,33,16,2,269,16,1296,261,1044,1077,1284,33,257,33,277,276]

theorem envBound17260 : H12AffineFastState.Bounded env17260 := by
  intro p hp
  have h : env17260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17259_17260 : H12AffineEnvironment.transform 6 9 env17259 = env17260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17259 == env17260) = true)

theorem identity17260 : scanCanonicalize (H12AffineFastState.compose env17260 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound17260 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17261 : List Nat := [2,4,8,16,32,16,9,256,277,289,49,308,268,277,1,263,260,276,288,0,292,33,16,2,269,16,49,261,309,276,37,33,257,33,277,276]

theorem envBound17261 : H12AffineFastState.Bounded env17261 := by
  intro p hp
  have h : env17261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17260_17261 : H12AffineEnvironment.transform 9 289 env17260 = env17261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env17260 == env17261) = true)

theorem identity17261 : scanCanonicalize (H12AffineFastState.compose env17261 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17261 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17262 : List Nat := [2,4,8,16,32,16,9,4,17,37,49,48,8,17,1,3,0,16,36,0,32,33,16,2,9,16,49,1,49,16,37,33,5,33,17,16]

theorem envBound17262 : H12AffineFastState.Bounded env17262 := by
  intro p hp
  have h : env17262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17261_17262 : H12AffineEnvironment.transform 7 4 env17261 = env17262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17261 == env17262) = true)

theorem identity17262 : scanCanonicalize (H12AffineFastState.compose env17262 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17262 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17263 : List Nat := [2,4,8,0,32,0,9,4,1,37,33,32,8,1,1,3,0,0,36,0,32,33,0,2,9,0,33,1,33,0,37,33,5,33,1,0]

theorem envBound17263 : H12AffineFastState.Bounded env17263 := by
  intro p hp
  have h : env17263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17262_17263 : H12AffineEnvironment.transform 3 0 env17262 = env17263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17262 == env17263) = true)

theorem identity17263 : scanCanonicalize (H12AffineFastState.compose env17263 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17263 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17264 : List Nat := [2,4,8,0,0,0,9,4,1,5,1,0,8,1,1,3,0,0,4,0,0,1,0,2,9,0,1,1,1,0,5,1,5,1,1,0]

theorem envBound17264 : H12AffineFastState.Bounded env17264 := by
  intro p hp
  have h : env17264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17263_17264 : H12AffineEnvironment.transform 4 0 env17263 = env17264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17263 == env17264) = true)

theorem identity17264 : scanCanonicalize (H12AffineFastState.compose env17264 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17265 : List Nat := [2,4,2,0,0,0,3,4,1,5,1,0,2,1,1,3,0,0,4,0,0,1,0,2,3,0,1,1,1,0,5,1,5,1,1,0]

theorem envBound17265 : H12AffineFastState.Bounded env17265 := by
  intro p hp
  have h : env17265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17264_17265 : H12AffineEnvironment.transform 2 2 env17264 = env17265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17264 == env17265) = true)

def env17266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,115871,32,120015,98781,8328,64,43476,115151,17665,10280,119042,73890,257,21793,46212,63189]

theorem envBound17266 : H12AffineFastState.Bounded env17266 := by
  intro p hp
  have h : env17266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17250_17266 : H12AffineEnvironment.transform 17 10401 env17250 = env17266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17250 == env17266) = true)

theorem identity17266 : scanCanonicalize (H12AffineFastState.compose env17266 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound17266 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env17267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21591,16401,10401,1025,32769,37064,32,32920,54666,8328,64,43476,38296,17665,10280,34133,29941,257,21793,46212,63189]

theorem envBound17267 : H12AffineFastState.Bounded env17267 := by
  intro p hp
  have h : env17267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17266_17267 : H12AffineEnvironment.transform 15 21591 env17266 = env17267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env17266 == env17267) = true)

theorem identity17267 : scanCanonicalize (H12AffineFastState.compose env17267 (packedSelected [1,5,8,16,17,19,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17267 : packedSelected [1,5,8,16,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8202,13388,10401,1025,32769,37064,32,32920,41431,8328,64,43476,38296,12636,10280,34133,168,257,8572,46212,33416]

theorem envBound17268 : H12AffineFastState.Bounded env17268 := by
  intro p hp
  have h : env17268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17267_17268 : H12AffineEnvironment.transform 13 13405 env17267 = env17268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17267 == env17268) = true)

theorem identity17268 : scanCanonicalize (H12AffineFastState.compose env17268 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17268 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env17269 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,32768,8202,13341,10401,1025,32769,37017,32,32920,41350,8328,17,43397,38296,12557,10280,34052,168,257,8493,46212,33416]

theorem envBound17269 : H12AffineFastState.Bounded env17269 := by
  intro p hp
  have h : env17269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17268_17269 : H12AffineEnvironment.transform 5 17 env17268 = env17269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17268 == env17269) = true)

theorem identity17269 : scanCanonicalize (H12AffineFastState.compose env17269 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound17269 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env17270 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,293,8202,13341,10401,1025,292,4540,32,445,8355,8328,17,10400,5309,12557,10280,1057,168,257,8493,13729,941]

theorem envBound17270 : H12AffineFastState.Bounded env17270 := by
  intro p hp
  have h : env17270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17269_17270 : H12AffineEnvironment.transform 14 293 env17269 = env17270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env17269 == env17270) = true)

theorem identity17270 : scanCanonicalize (H12AffineFastState.compose env17270 (packedSelected [6,9,17,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound17270 : packedSelected [6,9,17,22] rootPS < 2^1333 := by decide +kernel

def env17271 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,13324,136,8202,13341,10401,1025,137,4113,32,16,8355,8328,17,10400,5309,12448,10280,1057,168,172,8320,13324,512]

theorem envBound17271 : H12AffineFastState.Bounded env17271 := by
  intro p hp
  have h : env17271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17270_17271 : H12AffineEnvironment.transform 7 173 env17270 = env17271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env17270 == env17271) = true)

theorem identity17271 : scanCanonicalize (H12AffineFastState.compose env17271 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound17271 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17272 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,9,5125,136,3,5140,2216,1025,137,4113,32,16,170,129,17,2217,5309,4265,2081,1057,168,172,137,5125,512]

theorem envBound17272 : H12AffineFastState.Bounded env17272 := by
  intro p hp
  have h : env17272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17271_17272 : H12AffineEnvironment.transform 12 9 env17271 = env17272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env17271 == env17272) = true)

theorem identity17272 : scanCanonicalize (H12AffineFastState.compose env17272 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17272 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17273 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5125,0,3,5140,2080,1025,1,4113,32,16,34,9,17,2081,5173,4129,2081,1057,32,36,1,5125,512]

theorem envBound17273 : H12AffineFastState.Bounded env17273 := by
  intro p hp
  have h : env17273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17272_17273 : H12AffineEnvironment.transform 6 8 env17272 = env17273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17272 == env17273) = true)

def env17274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound17274 : H12AffineFastState.Bounded env17274 := by
  intro p hp
  have h : env17274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17011_17274 : H12AffineEnvironment.transform 26 30393345 env17011 = env17274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env17011 == env17274) = true)

def env17275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound17275 : H12AffineFastState.Bounded env17275 := by
  intro p hp
  have h : env17275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17274_17275 : H12AffineEnvironment.transform 18 1024 env17274 = env17275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17274 == env17275) = true)

theorem identity17275 : scanCanonicalize (H12AffineFastState.compose env17275 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound17275 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2212884,8328,64,15074325,16536,10507601,8830976,10502148,4235733,256,8388792,8446237,10577874]

theorem envBound17276 : H12AffineFastState.Bounded env17276 := by
  intro p hp
  have h : env17276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17275_17276 : H12AffineEnvironment.transform 23 2212884 env17275 = env17276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env17275 == env17276) = true)

def env17277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21912,2212884,8328,64,6705549,16536,2097353,431512,2102684,4235733,256,21792,46213,2175562]

theorem envBound17277 : H12AffineFastState.Bounded env17277 := by
  intro p hp
  have h : env17277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17276_17277 : H12AffineEnvironment.transform 22 21912 env17276 = env17277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21912 env17276 == env17277) = true)

def env17278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21912,98644,8328,64,4592845,16536,17801,431512,20700,4235733,256,21792,46213,96010]

theorem envBound17278 : H12AffineFastState.Bounded env17278 := by
  intro p hp
  have h : env17278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17277_17278 : H12AffineEnvironment.transform 20 17728 env17277 = env17278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env17277 == env17278) = true)

def env17279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21912,98644,8328,64,410093,16536,17801,431512,20700,62709,256,21792,46213,96010]

theorem envBound17279 : H12AffineFastState.Bounded env17279 := by
  intro p hp
  have h : env17279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17278_17279 : H12AffineEnvironment.transform 21 21792 env17278 = env17279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env17278 == env17279) = true)

def env17280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21776,98644,8192,64,409957,16400,17665,431376,20564,62589,256,21792,46093,96010]

theorem envBound17280 : H12AffineFastState.Bounded env17280 := by
  intro p hp
  have h : env17280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17279_17280 : H12AffineEnvironment.transform 6 8 env17279 = env17280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17279 == env17280) = true)

def env17281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98644,8192,64,398437,5392,4097,431376,1364,41341,256,32,46093,74250]

theorem envBound17281 : H12AffineFastState.Bounded env17281 := by
  intro p hp
  have h : env17281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17280_17281 : H12AffineEnvironment.transform 13 5376 env17280 = env17281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17280 == env17281) = true)

theorem identity17281 : scanCanonicalize (H12AffineFastState.compose env17281 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound17281 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,32,16,2,8192,64,398437,5392,4097,431376,1364,41341,256,32,46093,41820]

theorem envBound17282 : H12AffineFastState.Bounded env17282 := by
  intro p hp
  have h : env17282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17281_17282 : H12AffineEnvironment.transform 15 33110 env17281 = env17282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env17281 == env17282) = true)

theorem identity17282 : scanCanonicalize (H12AffineFastState.compose env17282 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound17282 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,262144,1024,32769,4160,32,16,2,8192,64,262516,5392,4097,294913,1364,41341,256,32,46093,41820]

theorem envBound17283 : H12AffineFastState.Bounded env17283 := by
  intro p hp
  have h : env17283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17282_17283 : H12AffineEnvironment.transform 16 5393 env17282 = env17283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env17282 == env17283) = true)

theorem identity17283 : scanCanonicalize (H12AffineFastState.compose env17283 (packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound17283 : packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env17284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,43357,1024,32769,4160,32,16,2,8192,64,43049,5392,4097,10588,1364,41341,256,32,46093,41820]

theorem envBound17284 : H12AffineFastState.Bounded env17284 := by
  intro p hp
  have h : env17284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17283_17284 : H12AffineEnvironment.transform 17 43357 env17283 = env17284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env17283 == env17284) = true)

theorem identity17284 : scanCanonicalize (H12AffineFastState.compose env17284 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound17284 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env17285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8313,8495,5393,2340,1024,8312,4160,32,16,2,8192,64,2128,5392,4097,10588,1364,260,256,32,5236,805]

theorem envBound17285 : H12AffineFastState.Bounded env17285 := by
  intro p hp
  have h : env17285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17284_17285 : H12AffineEnvironment.transform 14 8313 env17284 = env17285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env17284 == env17285) = true)

theorem identity17285 : scanCanonicalize (H12AffineFastState.compose env17285 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17285 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17286 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8232,8495,5393,2340,1024,8233,4113,32,16,2,8192,17,2049,5392,4097,10509,1285,260,256,32,5157,805]

theorem envBound17286 : H12AffineFastState.Bounded env17286 := by
  intro p hp
  have h : env17286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17285_17286 : H12AffineEnvironment.transform 5 17 env17285 = env17286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17285 == env17286) = true)

theorem identity17286 : scanCanonicalize (H12AffineFastState.compose env17286 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17286 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env17287 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,8232,8202,5172,2049,1024,8233,4113,32,16,2,8192,17,2049,5173,4097,10280,1056,33,37,32,5157,512]

theorem envBound17287 : H12AffineFastState.Bounded env17287 := by
  intro p hp
  have h : env17287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17286_17287 : H12AffineEnvironment.transform 7 37 env17286 = env17287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17286 == env17287) = true)

theorem identity17287 : scanCanonicalize (H12AffineFastState.compose env17287 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17288 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8192,5125,8200,8202,5140,2049,1024,8201,4113,0,16,2,8192,17,2049,5141,4097,10248,1024,1,5,0,5125,512]

theorem envBound17288 : H12AffineFastState.Bounded env17288 := by
  intro p hp
  have h : env17288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17287_17288 : H12AffineEnvironment.transform 4 0 env17287 = env17288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17287 == env17288) = true)

theorem identity17288 : scanCanonicalize (H12AffineFastState.compose env17288 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17288 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17289 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5125,0,2,5140,2049,1024,1,4113,0,16,2,8,17,2049,5141,4097,2048,1024,1,5,0,5125,512]

theorem envBound17289 : H12AffineFastState.Bounded env17289 := by
  intro p hp
  have h : env17289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17288_17289 : H12AffineEnvironment.transform 12 8 env17288 = env17289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17288 == env17289) = true)

def env17290 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1045,0,2,1028,2049,1024,1,1,0,16,2,8,17,2049,1029,17,2048,1024,1,5,0,1045,512]

theorem envBound17290 : H12AffineFastState.Bounded env17290 := by
  intro p hp
  have h : env17290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17289_17290 : H12AffineEnvironment.transform 11 16 env17289 = env17290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17289 == env17290) = true)

theorem identity17290 : scanCanonicalize (H12AffineFastState.compose env17290 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound17290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17291 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,16,8,1045,0,2,1028,1044,1024,1,1,0,16,2,8,17,1044,1029,17,1045,1024,1,5,0,1045,512]

theorem envBound17291 : H12AffineFastState.Bounded env17291 := by
  intro p hp
  have h : env17291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17290_17291 : H12AffineEnvironment.transform 10 1045 env17290 = env17291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env17290 == env17291) = true)

def env17292 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,16,8,1,0,2,16,0,20,1,1,0,16,2,8,17,0,17,17,1,20,1,5,0,1,512]

theorem envBound17292 : H12AffineFastState.Bounded env17292 := by
  intro p hp
  have h : env17292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17291_17292 : H12AffineEnvironment.transform 9 20 env17291 = env17292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17291 == env17292) = true)

theorem identity17292 : scanCanonicalize (H12AffineFastState.compose env17292 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound17292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17293 : List Nat := [2,4,8,4,0,5,8,5,512,0,1,4,8,1,0,2,4,0,0,1,1,0,4,2,8,5,0,5,5,1,0,1,5,0,1,512]

theorem envBound17293 : H12AffineFastState.Bounded env17293 := by
  intro p hp
  have h : env17293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17292_17293 : H12AffineEnvironment.transform 3 4 env17292 = env17293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env17292 == env17293) = true)

def leafEnv17293 : List Nat := [2,4,8,4,0,5,8,5,512,0,1,4,8,1,0,2,4,0,0,1,1,0,4,2,0,8,1,5,0,5,5,1,0,1,5,0,4,2,1,512,1,1,0]

def active17293 : List Nat := [0,1,2,8]

def tree17293 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17293 : H12WitnessSearch.Good tree17293 := H12GlobalWitnessIndex.good

theorem leafIdentity17293 : H12AffineFastState.composeSystem env17293 rootObs = leafEnv17293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17293 rootObs == leafEnv17293) = true)

theorem terminalChecked17293 : H12PackedTerminal.terminalCheckFast leafEnv17293 active17293 tree17293 = true := by decide +kernel

def env17294 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,0,0,2,17,1,21,1,1,0,16,2,8,17,1,16,17,0,21,1,5,0,0,512]

theorem envBound17294 : H12AffineFastState.Bounded env17294 := by
  intro p hp
  have h : env17294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17291_17294 : H12AffineEnvironment.transform 9 21 env17291 = env17294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17291 == env17294) = true)

theorem identity17294 : scanCanonicalize (H12AffineFastState.compose env17294 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound17294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17295 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,16,8,0,0,2,17,1,21,1,1,0,16,2,8,17,1,16,17,0,21,1,5,0,0,30]

theorem envBound17295 : H12AffineFastState.Bounded env17295 := by
  intro p hp
  have h : env17295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17294_17295 : H12AffineEnvironment.transform 8 30 env17294 = env17295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env17294 == env17295) = true)

def leafEnv17295 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,16,8,0,0,2,17,1,21,1,1,0,16,2,21,8,1,17,1,16,17,0,21,1,5,0,4,2,0,30,1,1,0]

def active17295 : List Nat := [0,1,2,3]

def tree17295 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17295 : H12WitnessSearch.Good tree17295 := H12GlobalWitnessIndex.good

theorem leafIdentity17295 : H12AffineFastState.composeSystem env17295 rootObs = leafEnv17295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17295 rootObs == leafEnv17295) = true)

theorem terminalChecked17295 : H12PackedTerminal.terminalCheckFast leafEnv17295 active17295 tree17295 = true := by decide +kernel

def env17296 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1044,0,2,1029,2049,1024,1,0,0,16,2,8,17,2049,1028,16,2048,1024,1,5,0,1044,512]

theorem envBound17296 : H12AffineFastState.Bounded env17296 := by
  intro p hp
  have h : env17296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17289_17296 : H12AffineEnvironment.transform 11 17 env17289 = env17296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17289 == env17296) = true)

theorem identity17296 : scanCanonicalize (H12AffineFastState.compose env17296 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17297 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,8,1044,0,2,1029,1,1024,1,0,0,16,2,8,17,1,1028,16,0,1024,1,5,0,1044,512]

theorem envBound17297 : H12AffineFastState.Bounded env17297 := by
  intro p hp
  have h : env17297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17296_17297 : H12AffineEnvironment.transform 10 0 env17296 = env17297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17296 == env17297) = true)

def env17298 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,0,2,17,1,20,1,0,0,16,2,8,17,1,16,16,0,20,1,5,0,0,512]

theorem envBound17298 : H12AffineFastState.Bounded env17298 := by
  intro p hp
  have h : env17298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17297_17298 : H12AffineEnvironment.transform 9 20 env17297 = env17298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17297 == env17298) = true)

theorem identity17298 : scanCanonicalize (H12AffineFastState.compose env17298 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound17298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17299 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,0,2,5,1,0,1,0,0,4,2,8,5,1,4,4,0,0,1,5,0,0,512]

theorem envBound17299 : H12AffineFastState.Bounded env17299 := by
  intro p hp
  have h : env17299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17298_17299 : H12AffineEnvironment.transform 3 4 env17298 = env17299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env17298 == env17299) = true)

def leafEnv17299 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,0,2,5,1,0,1,0,0,4,2,0,8,1,5,1,4,4,0,0,1,5,0,4,2,0,512,1,0,0]

def active17299 : List Nat := [0,1,2,8]

def tree17299 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17299 : H12WitnessSearch.Good tree17299 := H12GlobalWitnessIndex.good

theorem leafIdentity17299 : H12AffineFastState.composeSystem env17299 rootObs = leafEnv17299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17299 rootObs == leafEnv17299) = true)

theorem terminalChecked17299 : H12PackedTerminal.terminalCheckFast leafEnv17299 active17299 tree17299 = true := by decide +kernel

def env17300 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,1,0,2,16,1,21,1,0,0,16,2,8,17,1,17,16,0,21,1,5,0,1,512]

theorem envBound17300 : H12AffineFastState.Bounded env17300 := by
  intro p hp
  have h : env17300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17297_17300 : H12AffineEnvironment.transform 9 21 env17297 = env17300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17297 == env17300) = true)

theorem identity17300 : scanCanonicalize (H12AffineFastState.compose env17300 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound17300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17301 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,8,1,0,2,16,1,21,1,0,0,16,2,8,17,1,17,16,0,21,1,5,0,1,30]

theorem envBound17301 : H12AffineFastState.Bounded env17301 := by
  intro p hp
  have h : env17301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17300_17301 : H12AffineEnvironment.transform 8 30 env17300 = env17301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env17300 == env17301) = true)

def leafEnv17301 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,8,1,0,2,16,1,21,1,0,0,16,2,21,8,1,17,1,17,16,0,21,1,5,0,4,2,1,30,1,0,0]

def active17301 : List Nat := [0,1,2,3]

def tree17301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17301 : H12WitnessSearch.Good tree17301 := H12GlobalWitnessIndex.good

theorem leafIdentity17301 : H12AffineFastState.composeSystem env17301 rootObs = leafEnv17301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17301 rootObs == leafEnv17301) = true)

theorem terminalChecked17301 : H12PackedTerminal.terminalCheckFast leafEnv17301 active17301 tree17301 = true := by decide +kernel

def env17302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,17,98644,8192,64,398436,5393,4096,431376,1365,41340,256,33,46093,74251]

theorem envBound17302 : H12AffineFastState.Bounded env17302 := by
  intro p hp
  have h : env17302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17280_17302 : H12AffineEnvironment.transform 13 5377 env17280 = env17302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17280 == env17302) = true)

theorem identity17302 : scanCanonicalize (H12AffineFastState.compose env17302 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound17302 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1024,32769,4161,33,17,98644,8192,64,245019,5393,4096,212079,1365,41340,256,33,46093,74251]

theorem envBound17303 : H12AffineFastState.Bounded env17303 := by
  intro p hp
  have h : env17303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17302_17303 : H12AffineEnvironment.transform 17 108927 env17302 = env17303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env17302 == env17303) = true)

theorem identity17303 : scanCanonicalize (H12AffineFastState.compose env17303 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound17303 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,108927,1024,32769,4161,33,17,98644,8192,64,108554,5393,4096,76158,1365,41340,256,33,46093,74251]

theorem envBound17304 : H12AffineFastState.Bounded env17304 := by
  intro p hp
  have h : env17304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17303_17304 : H12AffineEnvironment.transform 16 5393 env17303 = env17304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env17303 == env17304) = true)

theorem identity17304 : scanCanonicalize (H12AffineFastState.compose env17304 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17304 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,5393,35189,1024,32769,4161,33,17,41310,8192,64,34816,5393,4096,2420,1365,41340,256,33,46093,513]

theorem envBound17305 : H12AffineFastState.Bounded env17305 := by
  intro p hp
  have h : env17305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17304_17305 : H12AffineEnvironment.transform 15 8202 env17304 = env17305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17304 == env17305) = true)

theorem identity17305 : scanCanonicalize (H12AffineFastState.compose env17305 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound17305 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,9293,8202,5393,11576,1024,9292,4161,33,17,1299,8192,64,11341,5393,4096,2420,1365,1329,256,33,4160,513]

theorem envBound17306 : H12AffineFastState.Bounded env17306 := by
  intro p hp
  have h : env17306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17305_17306 : H12AffineEnvironment.transform 14 9293 env17305 = env17306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env17305 == env17306) = true)

theorem identity17306 : scanCanonicalize (H12AffineFastState.compose env17306 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound17306 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,293,8192,1060,9293,8202,1076,11576,1024,9292,356,33,17,1299,8192,64,11341,1076,293,2420,1365,1329,256,33,357,513]

theorem envBound17307 : H12AffineFastState.Bounded env17307 := by
  intro p hp
  have h : env17307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17306_17307 : H12AffineEnvironment.transform 11 293 env17306 = env17307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env17306 == env17307) = true)

def env17308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21777,98644,8193,64,409956,16401,17664,431377,20565,62588,256,21792,46092,96010]

theorem envBound17308 : H12AffineFastState.Bounded env17308 := by
  intro p hp
  have h : env17308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17279_17308 : H12AffineEnvironment.transform 6 9 env17279 = env17308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17279 == env17308) = true)

def env17309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,17,98644,8193,64,398436,5393,4096,431377,1365,41340,256,32,46092,74250]

theorem envBound17309 : H12AffineFastState.Bounded env17309 := by
  intro p hp
  have h : env17309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17308_17309 : H12AffineEnvironment.transform 13 5376 env17308 = env17309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17308 == env17309) = true)

theorem identity17309 : scanCanonicalize (H12AffineFastState.compose env17309 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound17309 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,4160,32,17,98644,8193,64,203846,5393,4096,236851,1365,41340,256,32,46092,74250]

theorem envBound17310 : H12AffineFastState.Bounded env17310 := by
  intro p hp
  have h : env17310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17309_17310 : H12AffineEnvironment.transform 17 67618 env17309 = env17310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env17309 == env17310) = true)

theorem identity17310 : scanCanonicalize (H12AffineFastState.compose env17310 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17310 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,65536,131072,67618,1024,1,4160,32,17,65876,8193,64,203846,5393,4096,204083,1365,8572,256,32,13324,74250]

theorem envBound17311 : H12AffineFastState.Bounded env17311 := by
  intro p hp
  have h : env17311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17310_17311 : H12AffineEnvironment.transform 14 0 env17310 = env17311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17310 == env17311) = true)

theorem identity17311 : scanCanonicalize (H12AffineFastState.compose env17311 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound17311 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env17312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,65536,70726,67618,1024,1,4160,32,17,65876,8193,64,2048,5393,4096,2421,1365,8572,256,32,13324,74250]

theorem envBound17312 : H12AffineFastState.Bounded env17312 := by
  intro p hp
  have h : env17312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17311_17312 : H12AffineEnvironment.transform 16 70726 env17311 = env17312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env17311 == env17312) = true)

theorem identity17312 : scanCanonicalize (H12AffineFastState.compose env17312 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17312 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,263,5441,2341,1024,1,4160,32,17,83,8193,64,2048,5393,4096,2421,1365,8572,256,32,13324,8973]

theorem envBound17313 : H12AffineFastState.Bounded env17313 := by
  intro p hp
  have h : env17313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17312_17313 : H12AffineEnvironment.transform 15 263 env17312 = env17313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17312 == env17313) = true)

theorem identity17313 : scanCanonicalize (H12AffineFastState.compose env17313 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound17313 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env17314 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,4161,0,263,4096,2341,321,1,4160,32,17,83,8193,64,2048,4176,4096,2421,20,8572,256,32,12621,8973]

theorem envBound17314 : H12AffineFastState.Bounded env17314 := by
  intro p hp
  have h : env17314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17313_17314 : H12AffineEnvironment.transform 9 321 env17313 = env17314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env17313 == env17314) = true)

theorem identity17314 : scanCanonicalize (H12AffineFastState.compose env17314 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17314 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17315 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,268,4161,0,263,4096,2341,321,1,4160,32,17,83,269,64,2048,4176,4096,2421,20,112,256,32,4161,513]

theorem envBound17315 : H12AffineFastState.Bounded env17315 := by
  intro p hp
  have h : env17315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17314_17315 : H12AffineEnvironment.transform 12 268 env17314 = env17315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17314 == env17315) = true)

theorem identity17315 : scanCanonicalize (H12AffineFastState.compose env17315 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17315 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17316 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,4112,0,263,4096,2341,272,1,4113,32,17,2,269,17,2048,4097,4096,2340,20,33,256,32,4112,513]

theorem envBound17316 : H12AffineFastState.Bounded env17316 := by
  intro p hp
  have h : env17316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17315_17316 : H12AffineEnvironment.transform 5 17 env17315 = env17316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17315 == env17316) = true)

theorem identity17316 : scanCanonicalize (H12AffineFastState.compose env17316 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound17316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17317 : List Nat := [2,4,8,16,32,17,9,53,512,37,2048,4096,57,4112,0,50,4096,2064,37,1,4113,32,17,2,56,17,2048,4097,4096,2065,20,33,53,32,4112,513]

theorem envBound17317 : H12AffineFastState.Bounded env17317 := by
  intro p hp
  have h : env17317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17316_17317 : H12AffineEnvironment.transform 7 53 env17316 = env17317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env17316 == env17317) = true)

theorem identity17317 : scanCanonicalize (H12AffineFastState.compose env17317 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2051) := by decide +kernel

theorem selectedBound17317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17318 : List Nat := [2,4,8,16,32,17,9,53,512,37,2048,2051,57,2067,0,50,2051,2064,37,1,2066,32,17,2,56,17,2048,2050,2051,2065,20,33,53,32,2067,513]

theorem envBound17318 : H12AffineFastState.Bounded env17318 := by
  intro p hp
  have h : env17318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17317_17318 : H12AffineEnvironment.transform 11 2051 env17317 = env17318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2051 env17317 == env17318) = true)

theorem identity17318 : scanCanonicalize (H12AffineFastState.compose env17318 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound17318 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17319 : List Nat := [2,4,1,16,32,17,0,53,512,37,2048,2051,48,2067,0,50,2051,2064,37,1,2066,32,17,2,49,17,2048,2050,2051,2065,20,33,53,32,2067,513]

theorem envBound17319 : H12AffineFastState.Bounded env17319 := by
  intro p hp
  have h : env17319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17318_17319 : H12AffineEnvironment.transform 2 1 env17318 = env17319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env17318 == env17319) = true)

theorem identity17319 : scanCanonicalize (H12AffineFastState.compose env17319 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound17319 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17320 : List Nat := [2,4,1,16,2,17,0,23,512,7,2048,2051,18,2067,0,16,2051,2064,7,1,2066,2,17,2,19,17,2048,2050,2051,2065,20,3,23,2,2067,513]

theorem envBound17320 : H12AffineFastState.Bounded env17320 := by
  intro p hp
  have h : env17320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17319_17320 : H12AffineEnvironment.transform 4 2 env17319 = env17320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env17319 == env17320) = true)

theorem identity17320 : scanCanonicalize (H12AffineFastState.compose env17320 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound17320 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17321 : List Nat := [2,4,1,2,2,3,0,5,512,7,2048,2051,0,2049,0,2,2051,2050,7,1,2048,2,3,2,1,3,2048,2050,2051,2051,6,3,5,2,2049,513]

theorem envBound17321 : H12AffineFastState.Bounded env17321 := by
  intro p hp
  have h : env17321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17320_17321 : H12AffineEnvironment.transform 3 2 env17320 = env17321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env17320 == env17321) = true)

def env17322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98644,8193,64,398437,5392,4097,431377,1364,41341,256,33,46092,74251]

theorem envBound17322 : H12AffineFastState.Bounded env17322 := by
  intro p hp
  have h : env17322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17308_17322 : H12AffineEnvironment.transform 13 5377 env17308 = env17322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17308 == env17322) = true)

theorem identity17322 : scanCanonicalize (H12AffineFastState.compose env17322 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17322 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41310,8193,64,398437,5392,4097,431377,1364,41341,256,33,46092,513]

theorem envBound17323 : H12AffineFastState.Bounded env17323 := by
  intro p hp
  have h : env17323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17322_17323 : H12AffineEnvironment.transform 15 8202 env17322 = env17323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17322 == env17323) = true)

theorem identity17323 : scanCanonicalize (H12AffineFastState.compose env17323 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17323 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,3,8193,64,398437,5392,4097,406604,1364,32,256,33,5457,513]

theorem envBound17324 : H12AffineFastState.Bounded env17324 := by
  intro p hp
  have h : env17324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17323_17324 : H12AffineEnvironment.transform 14 8541 env17323 = env17324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17323 == env17324) = true)

theorem identity17324 : scanCanonicalize (H12AffineFastState.compose env17324 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound17324 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,262144,1024,8540,4161,33,16,3,8193,64,262437,5392,4097,270604,1364,32,256,33,5457,513]

theorem envBound17325 : H12AffineFastState.Bounded env17325 := by
  intro p hp
  have h : env17325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17324_17325 : H12AffineEnvironment.transform 16 5440 env17324 = env17325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env17324 == env17325) = true)

theorem identity17325 : scanCanonicalize (H12AffineFastState.compose env17325 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound17325 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,2421,1024,8540,4161,33,16,3,8193,64,2128,5392,4097,10361,1364,32,256,33,5457,513]

theorem envBound17326 : H12AffineFastState.Bounded env17326 := by
  intro p hp
  have h : env17326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17325_17326 : H12AffineEnvironment.transform 17 2421 env17325 = env17326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env17325 == env17326) = true)

theorem identity17326 : scanCanonicalize (H12AffineFastState.compose env17326 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17326 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17327 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,5393,2340,1024,8461,4112,33,16,3,8193,17,2049,5392,4097,10280,1285,32,256,33,5376,513]

theorem envBound17327 : H12AffineFastState.Bounded env17327 := by
  intro p hp
  have h : env17327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17326_17327 : H12AffineEnvironment.transform 5 17 env17326 = env17327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17326 == env17327) = true)

theorem identity17327 : scanCanonicalize (H12AffineFastState.compose env17327 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17327 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17328 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1024,1,4112,33,16,3,269,17,2049,5392,4097,2340,1285,32,256,33,5376,513]

theorem envBound17328 : H12AffineFastState.Bounded env17328 := by
  intro p hp
  have h : env17328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17327_17328 : H12AffineEnvironment.transform 12 268 env17327 = env17328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17327 == env17328) = true)

theorem identity17328 : scanCanonicalize (H12AffineFastState.compose env17328 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17329 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5377,0,262,5393,2308,1024,1,4112,1,16,3,269,17,2049,5392,4097,2308,1285,0,256,1,5376,513]

theorem envBound17329 : H12AffineFastState.Bounded env17329 := by
  intro p hp
  have h : env17329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17328_17329 : H12AffineEnvironment.transform 4 0 env17328 = env17329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17328 == env17329) = true)

theorem identity17329 : scanCanonicalize (H12AffineFastState.compose env17329 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound17329 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17330 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,277,268,1044,0,262,1028,2308,1024,1,261,1,16,3,269,17,2049,1029,276,2308,1285,0,256,1,1045,513]

theorem envBound17330 : H12AffineFastState.Bounded env17330 := by
  intro p hp
  have h : env17330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17329_17330 : H12AffineEnvironment.transform 11 277 env17329 = env17330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env17329 == env17330) = true)

theorem identity17330 : scanCanonicalize (H12AffineFastState.compose env17330 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17330 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17331 : List Nat := [2,4,8,16,0,17,9,256,0,1024,2048,277,268,1044,0,262,1028,2308,1024,1,261,1,16,3,269,17,2049,1029,276,2308,1285,0,256,1,1045,1]

theorem envBound17331 : H12AffineFastState.Bounded env17331 := by
  intro p hp
  have h : env17331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17330_17331 : H12AffineEnvironment.transform 8 0 env17330 = env17331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17330 == env17331) = true)

theorem identity17331 : scanCanonicalize (H12AffineFastState.compose env17331 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound17331 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17332 : List Nat := [2,4,8,16,0,17,9,256,0,1024,1028,277,268,1044,0,262,1028,1280,1024,1,261,1,16,3,269,17,1029,1029,276,1280,1285,0,256,1,1045,1]

theorem envBound17332 : H12AffineFastState.Bounded env17332 := by
  intro p hp
  have h : env17332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17331_17332 : H12AffineEnvironment.transform 10 1028 env17331 = env17332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env17331 == env17332) = true)

theorem identity17332 : scanCanonicalize (H12AffineFastState.compose env17332 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17332 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17333 : List Nat := [2,4,8,16,0,17,9,21,0,1024,1028,0,25,1044,0,19,1028,1045,1024,1,16,1,16,3,24,17,1029,1029,1,1045,1040,0,21,1,1045,1]

theorem envBound17333 : H12AffineFastState.Bounded env17333 := by
  intro p hp
  have h : env17333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17332_17333 : H12AffineEnvironment.transform 7 21 env17332 = env17333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17332 == env17333) = true)

theorem identity17333 : scanCanonicalize (H12AffineFastState.compose env17333 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17333 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env17334 : List Nat := [2,4,8,0,0,1,9,5,0,1024,1028,0,9,1028,0,3,1028,1029,1024,1,0,1,0,3,8,1,1029,1029,1,1029,1024,0,5,1,1029,1]

theorem envBound17334 : H12AffineFastState.Bounded env17334 := by
  intro p hp
  have h : env17334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17333_17334 : H12AffineEnvironment.transform 3 0 env17333 = env17334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17333 == env17334) = true)

theorem identity17334 : scanCanonicalize (H12AffineFastState.compose env17334 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound17334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17335 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,0,9,1,0,3,1,0,5,1,0,1,0,3,8,1,0,0,1,0,5,0,5,1,0,1]

theorem envBound17335 : H12AffineFastState.Bounded env17335 := by
  intro p hp
  have h : env17335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17334_17335 : H12AffineEnvironment.transform 9 5 env17334 = env17335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env17334 == env17335) = true)

theorem identity17335 : scanCanonicalize (H12AffineFastState.compose env17335 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17336 : List Nat := [2,4,2,0,0,1,3,5,0,5,1,0,3,1,0,3,1,0,5,1,0,1,0,3,2,1,0,0,1,0,5,0,5,1,0,1]

theorem envBound17336 : H12AffineFastState.Bounded env17336 := by
  intro p hp
  have h : env17336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17335_17336 : H12AffineEnvironment.transform 2 2 env17335 = env17336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17335 == env17336) = true)

def env17337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21912,98644,8328,64,410092,16536,17801,431512,20700,62708,256,21792,46213,96010]

theorem envBound17337 : H12AffineFastState.Bounded env17337 := by
  intro p hp
  have h : env17337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17278_17337 : H12AffineEnvironment.transform 21 21793 env17278 = env17337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env17278 == env17337) = true)

theorem identity17337 : scanCanonicalize (H12AffineFastState.compose env17337 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound17337 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,169,16,98644,8328,64,398436,5392,4097,431512,1364,41340,256,168,46213,74370]

theorem envBound17338 : H12AffineFastState.Bounded env17338 := by
  intro p hp
  have h : env17338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17337_17338 : H12AffineEnvironment.transform 13 5512 env17337 = env17338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env17337 == env17338) = true)

def env17339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98644,8192,64,398436,5392,4097,431376,1364,41340,256,32,46093,74250]

theorem envBound17339 : H12AffineFastState.Bounded env17339 := by
  intro p hp
  have h : env17339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17338_17339 : H12AffineEnvironment.transform 6 8 env17338 = env17339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17338 == env17339) = true)

theorem identity17339 : scanCanonicalize (H12AffineFastState.compose env17339 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound17339 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,33,16,2,8192,64,398436,5392,4097,431376,1364,41340,256,32,46093,41820]

theorem envBound17340 : H12AffineFastState.Bounded env17340 := by
  intro p hp
  have h : env17340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17339_17340 : H12AffineEnvironment.transform 15 33110 env17339 = env17340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env17339 == env17340) = true)

theorem identity17340 : scanCanonicalize (H12AffineFastState.compose env17340 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound17340 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,46156,262144,1024,32769,4160,33,16,2,8192,64,303144,5392,4097,270684,1364,41340,256,32,46093,41820]

theorem envBound17341 : H12AffineFastState.Bounded env17341 := by
  intro p hp
  have h : env17341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17340_17341 : H12AffineEnvironment.transform 16 46156 env17340 = env17341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env17340 == env17341) = true)

theorem identity17341 : scanCanonicalize (H12AffineFastState.compose env17341 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17341 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,262144,1024,8540,4160,33,16,2,8192,64,262517,5392,4097,270684,1364,33,256,32,5456,513]

theorem envBound17342 : H12AffineFastState.Bounded env17342 := by
  intro p hp
  have h : env17342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17341_17342 : H12AffineEnvironment.transform 14 8541 env17341 = env17342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17341 == env17342) = true)

theorem identity17342 : scanCanonicalize (H12AffineFastState.compose env17342 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound17342 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10280,1024,8540,4160,33,16,2,8192,64,10589,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound17343 : H12AffineFastState.Bounded env17343 := by
  intro p hp
  have h : env17343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17342_17343 : H12AffineEnvironment.transform 17 10280 env17342 = env17343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env17342 == env17343) = true)

theorem identity17343 : scanCanonicalize (H12AffineFastState.compose env17343 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17343 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,341,3,5393,2080,1024,340,4160,33,16,2,8,64,2389,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound17344 : H12AffineFastState.Bounded env17344 := by
  intro p hp
  have h : env17344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17343_17344 : H12AffineEnvironment.transform 12 8 env17343 = env17344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17343 == env17344) = true)

theorem identity17344 : scanCanonicalize (H12AffineFastState.compose env17344 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17344 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17345 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8,4113,341,3,4096,2080,273,340,4160,33,16,2,8,64,2389,4097,4097,2420,69,33,256,32,4161,513]

theorem envBound17345 : H12AffineFastState.Bounded env17345 := by
  intro p hp
  have h : env17345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17344_17345 : H12AffineEnvironment.transform 9 273 env17344 = env17345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17344 == env17345) = true)

theorem identity17345 : scanCanonicalize (H12AffineFastState.compose env17345 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound17345 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17346 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,4096,8,4113,48,3,4096,2080,116,49,4160,33,16,2,8,64,2096,4097,4097,2065,69,33,101,32,4161,513]

theorem envBound17346 : H12AffineFastState.Bounded env17346 := by
  intro p hp
  have h : env17346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17345_17346 : H12AffineEnvironment.transform 7 101 env17345 = env17346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env17345 == env17346) = true)

theorem identity17346 : scanCanonicalize (H12AffineFastState.compose env17346 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound17346 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17347 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,528,8,513,48,3,528,2080,116,49,592,33,16,2,8,64,2096,529,529,2065,69,33,101,32,593,513]

theorem envBound17347 : H12AffineFastState.Bounded env17347 := by
  intro p hp
  have h : env17347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17346_17347 : H12AffineEnvironment.transform 11 528 env17346 = env17347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env17346 == env17347) = true)

theorem identity17347 : scanCanonicalize (H12AffineFastState.compose env17347 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound17347 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env17348 : List Nat := [2,4,8,16,32,64,8,101,512,116,593,528,8,513,48,3,528,625,116,49,592,33,16,2,8,64,609,529,529,576,69,33,101,32,593,513]

theorem envBound17348 : H12AffineFastState.Bounded env17348 := by
  intro p hp
  have h : env17348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17347_17348 : H12AffineEnvironment.transform 10 593 env17347 = env17348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env17347 == env17348) = true)

theorem identity17348 : scanCanonicalize (H12AffineFastState.compose env17348 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17348 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env17349 : List Nat := [2,4,8,16,32,49,8,20,512,5,544,528,8,513,48,3,528,512,5,49,545,33,16,2,8,49,528,529,529,561,52,33,20,32,544,513]

theorem envBound17349 : H12AffineFastState.Bounded env17349 := by
  intro p hp
  have h : env17349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17348_17349 : H12AffineEnvironment.transform 5 49 env17348 = env17349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17348 == env17349) = true)

theorem identity17349 : scanCanonicalize (H12AffineFastState.compose env17349 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17349 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env17350 : List Nat := [2,4,8,16,17,0,8,20,512,5,529,528,8,513,1,3,528,512,5,0,528,16,16,2,8,0,528,529,529,512,5,16,20,17,529,513]

theorem envBound17350 : H12AffineFastState.Bounded env17350 := by
  intro p hp
  have h : env17350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17349_17350 : H12AffineEnvironment.transform 4 17 env17349 = env17350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17349 == env17350) = true)

theorem identity17350 : scanCanonicalize (H12AffineFastState.compose env17350 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound17350 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17351 : List Nat := [2,4,8,16,17,0,8,20,16,5,1,0,8,17,1,3,0,16,5,0,0,16,16,2,8,0,0,1,1,16,5,16,20,17,1,17]

theorem envBound17351 : H12AffineFastState.Bounded env17351 := by
  intro p hp
  have h : env17351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17350_17351 : H12AffineEnvironment.transform 8 16 env17350 = env17351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env17350 == env17351) = true)

theorem identity17351 : scanCanonicalize (H12AffineFastState.compose env17351 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17352 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,0,8,0,1,3,0,1,5,0,0,1,1,2,8,0,0,1,1,1,5,1,5,0,1,0]

theorem envBound17352 : H12AffineFastState.Bounded env17352 := by
  intro p hp
  have h : env17352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17351_17352 : H12AffineEnvironment.transform 3 1 env17351 = env17352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17351 == env17352) = true)

def env17353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98644,8193,64,398436,5392,4097,431377,1364,41340,256,33,46092,74251]

theorem envBound17353 : H12AffineFastState.Bounded env17353 := by
  intro p hp
  have h : env17353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17338_17353 : H12AffineEnvironment.transform 6 9 env17338 = env17353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17338 == env17353) = true)

theorem identity17353 : scanCanonicalize (H12AffineFastState.compose env17353 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17353 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41310,8193,64,398436,5392,4097,431377,1364,41340,256,33,46092,513]

theorem envBound17354 : H12AffineFastState.Bounded env17354 := by
  intro p hp
  have h : env17354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17353_17354 : H12AffineEnvironment.transform 15 8202 env17353 = env17354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17353 == env17354) = true)

theorem identity17354 : scanCanonicalize (H12AffineFastState.compose env17354 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17354 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,3,8193,64,398436,5392,4097,406604,1364,33,256,33,5457,513]

theorem envBound17355 : H12AffineFastState.Bounded env17355 := by
  intro p hp
  have h : env17355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17354_17355 : H12AffineEnvironment.transform 14 8541 env17354 = env17355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17354 == env17355) = true)

theorem identity17355 : scanCanonicalize (H12AffineFastState.compose env17355 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound17355 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,262144,1024,8540,4161,32,16,3,8193,64,262436,5392,4097,270604,1364,33,256,33,5457,513]

theorem envBound17356 : H12AffineFastState.Bounded env17356 := by
  intro p hp
  have h : env17356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17355_17356 : H12AffineEnvironment.transform 16 5440 env17355 = env17356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env17355 == env17356) = true)

theorem identity17356 : scanCanonicalize (H12AffineFastState.compose env17356 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound17356 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,10360,1024,8540,4161,32,16,3,8193,64,10588,5392,4097,2420,1364,33,256,33,5457,513]

theorem envBound17357 : H12AffineFastState.Bounded env17357 := by
  intro p hp
  have h : env17357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17356_17357 : H12AffineEnvironment.transform 17 10360 env17356 = env17357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env17356 == env17357) = true)

theorem identity17357 : scanCanonicalize (H12AffineFastState.compose env17357 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17357 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17358 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,5392,10280,1024,8460,4113,32,16,3,8193,16,10508,5392,4097,2340,1284,33,256,33,5377,513]

theorem envBound17358 : H12AffineFastState.Bounded env17358 := by
  intro p hp
  have h : env17358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17357_17358 : H12AffineEnvironment.transform 5 16 env17357 = env17358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17357 == env17358) = true)

theorem identity17358 : scanCanonicalize (H12AffineFastState.compose env17358 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound17358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17359 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,8192,309,8461,8202,292,10280,1024,8460,1061,32,16,3,8193,16,10508,292,1077,2340,1284,33,256,33,309,513]

theorem envBound17359 : H12AffineFastState.Bounded env17359 := by
  intro p hp
  have h : env17359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17358_17359 : H12AffineEnvironment.transform 11 1076 env17358 = env17359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env17358 == env17359) = true)

theorem identity17359 : scanCanonicalize (H12AffineFastState.compose env17359 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound17359 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17360 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,2083,309,2350,2089,292,11,1024,2351,1061,32,16,3,2082,16,303,292,1077,2340,1284,33,256,33,309,513]

theorem envBound17360 : H12AffineFastState.Bounded env17360 := by
  intro p hp
  have h : env17360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17359_17360 : H12AffineEnvironment.transform 12 2083 env17359 = env17360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env17359 == env17360) = true)

theorem identity17360 : scanCanonicalize (H12AffineFastState.compose env17360 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound17360 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17361 : List Nat := [2,4,8,16,32,16,9,256,512,1024,302,1076,269,309,0,263,292,11,1024,1,1061,32,16,3,268,16,303,292,1077,10,1284,33,256,33,309,513]

theorem envBound17361 : H12AffineFastState.Bounded env17361 := by
  intro p hp
  have h : env17361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17360_17361 : H12AffineEnvironment.transform 10 302 env17360 = env17361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env17360 == env17361) = true)

theorem identity17361 : scanCanonicalize (H12AffineFastState.compose env17361 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17361 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17362 : List Nat := [2,4,8,16,32,16,9,256,512,273,302,293,269,309,0,263,292,11,273,1,308,32,16,3,268,16,303,292,292,10,21,33,256,33,309,513]

theorem envBound17362 : H12AffineFastState.Bounded env17362 := by
  intro p hp
  have h : env17362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17361_17362 : H12AffineEnvironment.transform 9 273 env17361 = env17362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17361 == env17362) = true)

theorem identity17362 : scanCanonicalize (H12AffineFastState.compose env17362 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound17362 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17363 : List Nat := [2,4,8,16,32,16,9,30,512,15,48,59,19,43,0,25,58,11,15,1,42,32,16,3,18,16,49,58,58,10,21,33,30,33,43,513]

theorem envBound17363 : H12AffineFastState.Bounded env17363 := by
  intro p hp
  have h : env17363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17362_17363 : H12AffineEnvironment.transform 7 30 env17362 = env17363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env17362 == env17363) = true)

theorem identity17363 : scanCanonicalize (H12AffineFastState.compose env17363 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound17363 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17364 : List Nat := [2,4,8,16,27,16,9,30,512,15,11,0,19,16,0,25,1,11,15,1,17,27,16,3,18,16,10,1,1,10,21,26,30,26,16,513]

theorem envBound17364 : H12AffineFastState.Bounded env17364 := by
  intro p hp
  have h : env17364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17363_17364 : H12AffineEnvironment.transform 4 27 env17363 = env17364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env17363 == env17364) = true)

theorem identity17364 : scanCanonicalize (H12AffineFastState.compose env17364 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound17364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17365 : List Nat := [2,1,8,16,27,16,9,27,512,10,11,0,19,16,0,25,1,11,10,1,17,27,16,3,18,16,10,1,1,10,16,26,27,26,16,513]

theorem envBound17365 : H12AffineFastState.Bounded env17365 := by
  intro p hp
  have h : env17365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17364_17365 : H12AffineEnvironment.transform 1 1 env17364 = env17365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env17364 == env17365) = true)

theorem identity17365 : scanCanonicalize (H12AffineFastState.compose env17365 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound17365 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17366 : List Nat := [2,1,8,16,27,16,9,27,3,10,11,0,19,16,0,25,1,11,10,1,17,27,16,3,18,16,10,1,1,10,16,26,27,26,16,2]

theorem envBound17366 : H12AffineFastState.Bounded env17366 := by
  intro p hp
  have h : env17366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17365_17366 : H12AffineEnvironment.transform 8 3 env17365 = env17366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env17365 == env17366) = true)

def env17367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21912,98645,8328,64,4592844,16536,17800,431512,20701,4235733,256,21792,46213,96011]

theorem envBound17367 : H12AffineFastState.Bounded env17367 := by
  intro p hp
  have h : env17367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17277_17367 : H12AffineEnvironment.transform 20 17729 env17277 = env17367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env17277 == env17367) = true)

def env17368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21912,98645,8328,64,410092,16536,17800,431512,20701,62709,256,21792,46213,96011]

theorem envBound17368 : H12AffineFastState.Bounded env17368 := by
  intro p hp
  have h : env17368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17367_17368 : H12AffineEnvironment.transform 21 21792 env17367 = env17368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env17367 == env17368) = true)

theorem identity17368 : scanCanonicalize (H12AffineFastState.compose env17368 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound17368 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,17729,21792,21912,95616,8328,64,410092,16536,17800,418125,20701,32,256,21792,16464,96011]

theorem envBound17369 : H12AffineFastState.Bounded env17369 := by
  intro p hp
  have h : env17369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17368_17369 : H12AffineEnvironment.transform 14 29909 env17368 = env17369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env17368 == env17369) = true)

def env17370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32160,1024,29908,17729,21792,21912,95616,8328,64,146508,16536,17800,138477,20701,32,256,21792,16464,96011]

theorem envBound17370 : H12AffineFastState.Bounded env17370 := by
  intro p hp
  have h : env17370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17369_17370 : H12AffineEnvironment.transform 17 32160 env17369 = env17370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env17369 == env17370) = true)

theorem identity17370 : scanCanonicalize (H12AffineFastState.compose env17370 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound17370 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29962,131072,32160,1024,29908,17729,21792,21912,138,8328,64,146508,16536,17800,138477,20701,32,256,21792,16464,513]

theorem envBound17371 : H12AffineFastState.Bounded env17371 := by
  intro p hp
  have h : env17371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17370_17371 : H12AffineEnvironment.transform 15 29962 env17370 = env17371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env17370 == env17371) = true)

theorem identity17371 : scanCanonicalize (H12AffineFastState.compose env17371 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound17371 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29962,5392,32160,1024,29908,17729,21792,21912,138,8328,64,10588,16536,17800,2557,20701,32,256,21792,16464,513]

theorem envBound17372 : H12AffineFastState.Bounded env17372 := by
  intro p hp
  have h : env17372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17371_17372 : H12AffineEnvironment.transform 16 5392 env17371 = env17372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env17371 == env17372) = true)

theorem identity17372 : scanCanonicalize (H12AffineFastState.compose env17372 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17372 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env17373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,5392,10401,1024,8661,4160,33,153,138,8328,64,10588,5529,4233,2557,1500,32,256,33,5457,513]

theorem envBound17373 : H12AffineFastState.Bounded env17373 := by
  intro p hp
  have h : env17373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17372_17373 : H12AffineEnvironment.transform 13 5377 env17372 = env17373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17372 == env17373) = true)

theorem identity17373 : scanCanonicalize (H12AffineFastState.compose env17373 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound17373 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,5377,1296,1231,5392,3173,1024,1297,4160,33,153,138,1100,64,3480,5529,4233,2557,1500,32,256,33,5457,513]

theorem envBound17374 : H12AffineFastState.Bounded env17374 := by
  intro p hp
  have h : env17374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17373_17374 : H12AffineEnvironment.transform 12 1220 env17373 = env17374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env17373 == env17374) = true)

theorem identity17374 : scanCanonicalize (H12AffineFastState.compose env17374 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound17374 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env17375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2405,1220,3172,1296,1231,3189,3173,1024,1297,2341,33,153,138,1100,64,3480,3324,2540,2557,1500,32,256,33,3124,513]

theorem envBound17375 : H12AffineFastState.Bounded env17375 := by
  intro p hp
  have h : env17375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17374_17375 : H12AffineEnvironment.transform 11 2405 env17374 = env17375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env17374 == env17375) = true)

theorem identity17375 : scanCanonicalize (H12AffineFastState.compose env17375 (packedSelected [0,1,2,6,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound17375 : packedSelected [0,1,2,6,8,9] rootPS < 2^1333 := by decide +kernel

def env17376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,80,309,1220,1076,1296,1231,1061,1077,1024,1297,373,33,153,138,1100,64,1480,1196,444,429,1500,32,256,33,1124,513]

theorem envBound17376 : H12AffineFastState.Bounded env17376 := by
  intro p hp
  have h : env17376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17375_17376 : H12AffineEnvironment.transform 10 80 env17375 = env17376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env17375 == env17376) = true)

theorem identity17376 : scanCanonicalize (H12AffineFastState.compose env17376 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound17376 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env17377 : List Nat := [2,4,8,16,32,64,128,173,512,1024,80,152,1220,1076,1213,1231,1061,1077,1024,1212,216,33,153,138,1100,64,1125,1196,17,0,1137,32,173,33,1124,513]

theorem envBound17377 : H12AffineFastState.Bounded env17377 := by
  intro p hp
  have h : env17377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17376_17377 : H12AffineEnvironment.transform 7 173 env17376 = env17377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env17376 == env17377) = true)

theorem identity17377 : scanCanonicalize (H12AffineFastState.compose env17377 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound17377 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17378 : List Nat := [2,4,8,16,32,64,88,117,512,1024,80,64,1052,1076,1125,1047,1061,1077,1024,1124,0,33,65,82,1100,64,1125,1140,17,0,1137,32,117,33,1124,513]

theorem envBound17378 : H12AffineFastState.Bounded env17378 := by
  intro p hp
  have h : env17378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17377_17378 : H12AffineEnvironment.transform 6 88 env17377 = env17378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env17377 == env17378) = true)

theorem identity17378 : scanCanonicalize (H12AffineFastState.compose env17378 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17378 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17379 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,17,1052,1076,1076,1047,1061,1077,1024,1077,0,33,16,3,1053,17,1076,1061,17,0,1056,32,36,33,1077,513]

theorem envBound17379 : H12AffineFastState.Bounded env17379 := by
  intro p hp
  have h : env17379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17378_17379 : H12AffineEnvironment.transform 5 17 env17378 = env17379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17378 == env17379) = true)

theorem identity17379 : scanCanonicalize (H12AffineFastState.compose env17379 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound17379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17380 : List Nat := [2,4,8,16,32,17,9,36,512,36,1,17,56,16,16,51,1,17,36,17,0,33,16,3,57,17,16,1,17,0,4,32,36,33,17,513]

theorem envBound17380 : H12AffineFastState.Bounded env17380 := by
  intro p hp
  have h : env17380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17379_17380 : H12AffineEnvironment.transform 9 36 env17379 = env17380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env17379 == env17380) = true)

theorem identity17380 : scanCanonicalize (H12AffineFastState.compose env17380 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17381 : List Nat := [2,4,8,16,32,17,9,36,0,36,1,17,56,16,16,51,1,17,36,17,0,33,16,3,57,17,16,1,17,0,4,32,36,33,17,1]

theorem envBound17381 : H12AffineFastState.Bounded env17381 := by
  intro p hp
  have h : env17381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17380_17381 : H12AffineEnvironment.transform 8 0 env17380 = env17381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17380 == env17381) = true)

theorem identity17381 : scanCanonicalize (H12AffineFastState.compose env17381 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17381 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17382 : List Nat := [2,4,8,1,32,0,9,36,0,36,1,0,41,1,1,34,1,0,36,0,0,33,1,3,40,0,1,1,0,0,4,32,36,33,0,1]

theorem envBound17382 : H12AffineFastState.Bounded env17382 := by
  intro p hp
  have h : env17382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17381_17382 : H12AffineEnvironment.transform 3 1 env17381 = env17382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17381 == env17382) = true)

theorem identity17382 : scanCanonicalize (H12AffineFastState.compose env17382 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17383 : List Nat := [2,4,2,1,32,0,3,36,0,36,1,0,35,1,1,34,1,0,36,0,0,33,1,3,34,0,1,1,0,0,4,32,36,33,0,1]

theorem envBound17383 : H12AffineFastState.Bounded env17383 := by
  intro p hp
  have h : env17383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17382_17383 : H12AffineEnvironment.transform 2 2 env17382 = env17383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17382 == env17383) = true)

def env17384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32161,1024,29908,17729,21792,21912,95616,8328,64,146509,16536,17800,138476,20701,32,256,21792,16464,96011]

theorem envBound17384 : H12AffineFastState.Bounded env17384 := by
  intro p hp
  have h : env17384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17369_17384 : H12AffineEnvironment.transform 17 32161 env17369 = env17384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env17369 == env17384) = true)

theorem identity17384 : scanCanonicalize (H12AffineFastState.compose env17384 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8322,131072,32161,1024,29908,17729,21792,21912,21762,8328,64,146509,16536,17800,138476,20701,32,256,21792,16464,22409]

theorem envBound17385 : H12AffineFastState.Bounded env17385 := by
  intro p hp
  have h : env17385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17384_17385 : H12AffineEnvironment.transform 15 8322 env17384 = env17385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17384 == env17385) = true)

theorem identity17385 : scanCanonicalize (H12AffineFastState.compose env17385 (packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound17385 : packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env17386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,217,8322,131072,2477,1024,216,12621,8492,8596,8462,8328,64,146509,13460,12676,138476,9425,32,256,8492,13404,9093]

theorem envBound17386 : H12AffineFastState.Bounded env17386 := by
  intro p hp
  have h : env17386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17385_17386 : H12AffineEnvironment.transform 13 13324 env17385 = env17386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env17385 == env17386) = true)

theorem identity17386 : scanCanonicalize (H12AffineFastState.compose env17386 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound17386 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env17387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,217,8322,13388,2477,1024,216,12621,8492,8596,8462,8328,64,2049,13460,12676,10400,9425,32,256,8492,13404,9093]

theorem envBound17387 : H12AffineFastState.Bounded env17387 := by
  intro p hp
  have h : env17387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17386_17387 : H12AffineEnvironment.transform 16 13388 env17386 = env17387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env17386 == env17387) = true)

theorem identity17387 : scanCanonicalize (H12AffineFastState.compose env17387 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound17387 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env17388 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13324,1,8282,13388,2421,1024,0,12621,8492,8524,8462,8272,64,2049,13388,12636,10360,9225,32,256,8492,13404,9053]

theorem envBound17388 : H12AffineFastState.Bounded env17388 := by
  intro p hp
  have h : env17388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17387_17388 : H12AffineEnvironment.transform 6 88 env17387 = env17388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env17387 == env17388) = true)

theorem identity17388 : scanCanonicalize (H12AffineFastState.compose env17388 (packedSelected [0,4,7,9,10,11,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

end H12CloudChart1