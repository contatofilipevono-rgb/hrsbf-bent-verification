import H12CloudChart1Data095

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans24305_24306 : H12AffineEnvironment.transform 8 27 env24305 = env24306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env24305 == env24306) = true)

theorem identity24306 : scanCanonicalize (H12AffineFastState.compose env24306 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24306 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24307 : List Nat := [2,4,8,16,32,16,8,37,27,52,1,16,40,0,0,35,16,0,52,1,0,32,17,3,40,17,1,17,17,1,20,32,37,33,0,26]

theorem envBound24307 : H12AffineFastState.Bounded env24307 := by
  intro p hp
  have h : env24307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24306_24307 : H12AffineEnvironment.transform 6 8 env24306 = env24307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24306 == env24307) = true)

theorem identity24307 : scanCanonicalize (H12AffineFastState.compose env24307 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24308 : List Nat := [2,4,3,16,32,16,3,37,16,52,1,16,35,0,0,35,16,0,52,1,0,32,17,3,35,17,1,17,17,1,20,32,37,33,0,17]

theorem envBound24308 : H12AffineFastState.Bounded env24308 := by
  intro p hp
  have h : env24308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24307_24308 : H12AffineEnvironment.transform 2 3 env24307 = env24308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24307 == env24308) = true)

def env24309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98780,8328,65,4270243,5392,17664,108927,1501,4256860,256,21793,46213,74250]

theorem envBound24309 : H12AffineFastState.Bounded env24309 := by
  intro p hp
  have h : env24309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24293_24309 : H12AffineEnvironment.transform 20 4161 env24293 = env24309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24293 == env24309) = true)

theorem identity24309 : scanCanonicalize (H12AffineFastState.compose env24309 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound24309 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179632,1024,32769,4161,4194304,16,21763,8328,65,4258940,5392,17664,32160,1501,4256860,256,21793,46213,63189]

theorem envBound24310 : H12AffineFastState.Bounded env24310 := by
  intro p hp
  have h : env24310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24309_24310 : H12AffineEnvironment.transform 15 54495 env24309 = env24310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env24309 == env24310) = true)

def env24311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4161,4194304,16,21763,8192,65,4258940,5392,17664,32040,1365,4256860,256,21793,46093,63069]

theorem envBound24311 : H12AffineFastState.Bounded env24311 := by
  intro p hp
  have h : env24311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24310_24311 : H12AffineEnvironment.transform 6 8 env24310 = env24311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24310 == env24311) = true)

theorem identity24311 : scanCanonicalize (H12AffineFastState.compose env24311 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound24311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24908,56436,1024,32769,4161,4194304,16,21763,8192,65,4258940,5392,17664,32040,1365,4256860,256,21793,46093,63069]

theorem envBound24312 : H12AffineFastState.Bounded env24312 := by
  intro p hp
  have h : env24312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24311_24312 : H12AffineEnvironment.transform 16 24908 env24311 = env24312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env24311 == env24312) = true)

theorem identity24312 : scanCanonicalize (H12AffineFastState.compose env24312 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound24312 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env24313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,24908,10280,1024,29789,4161,4194304,16,21763,8192,65,4196384,5392,17664,32040,1365,4194304,256,21793,16465,513]

theorem envBound24313 : H12AffineFastState.Bounded env24313 := by
  intro p hp
  have h : env24313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24312_24313 : H12AffineEnvironment.transform 14 29788 env24312 = env24313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24312 == env24313) = true)

theorem identity24313 : scanCanonicalize (H12AffineFastState.compose env24313 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound24313 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,24908,10280,1024,29789,4161,8492,16,21763,8192,65,10508,5392,17664,32040,1365,8492,256,21793,16465,513]

theorem envBound24314 : H12AffineFastState.Bounded env24314 := by
  intro p hp
  have h : env24314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24313_24314 : H12AffineEnvironment.transform 21 8492 env24313 = env24314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env24313 == env24314) = true)

theorem identity24314 : scanCanonicalize (H12AffineFastState.compose env24314 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24314 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24315 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,24860,10280,1024,29709,4113,8492,16,21763,8192,17,10508,5392,17664,32040,1285,8492,256,21793,16385,513]

theorem envBound24315 : H12AffineFastState.Bounded env24315 := by
  intro p hp
  have h : env24315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24314_24315 : H12AffineEnvironment.transform 5 16 env24314 = env24315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24314 == env24315) = true)

theorem identity24315 : scanCanonicalize (H12AffineFastState.compose env24315 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24315 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24316 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,263,16400,2340,1024,21761,4113,32,16,21763,268,17,2048,5392,17664,23588,1285,32,256,21793,16385,513]

theorem envBound24316 : H12AffineFastState.Bounded env24316 := by
  intro p hp
  have h : env24316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24315_24316 : H12AffineEnvironment.transform 12 268 env24315 = env24316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24315 == env24316) = true)

theorem identity24316 : scanCanonicalize (H12AffineFastState.compose env24316 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2869) := by decide +kernel

theorem selectedBound24316 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24317 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2869,268,16384,20021,263,16400,2340,1024,20020,2852,32,16,20022,268,17,2048,3621,17664,18193,1285,32,256,19988,16385,513]

theorem envBound24317 : H12AffineFastState.Bounded env24317 := by
  intro p hp
  have h : env24317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24316_24317 : H12AffineEnvironment.transform 11 2869 env24316 = env24317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2869 env24316 == env24317) = true)

theorem identity24317 : scanCanonicalize (H12AffineFastState.compose env24317 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1312) := by decide +kernel

theorem selectedBound24317 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env24318 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1312,1557,268,16384,17173,263,16400,1028,1024,17172,1540,32,16,17174,268,17,1312,773,17664,18193,1285,32,256,17204,16385,513]

theorem envBound24318 : H12AffineFastState.Bounded env24318 := by
  intro p hp
  have h : env24318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24317_24318 : H12AffineEnvironment.transform 10 1312 env24317 = env24318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1312 env24317 == env24318) = true)

theorem identity24318 : scanCanonicalize (H12AffineFastState.compose env24318 (packedSelected [0,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound24318 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env24319 : List Nat := [2,4,8,16,32,16,8,256,512,801,513,308,268,16384,17173,263,16400,805,801,17172,293,32,16,17174,268,17,513,773,16929,16432,548,32,256,17204,16385,513]

theorem envBound24319 : H12AffineFastState.Bounded env24319 := by
  intro p hp
  have h : env24319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24318_24319 : H12AffineEnvironment.transform 9 801 env24318 = env24319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env24318 == env24319) = true)

theorem identity24319 : scanCanonicalize (H12AffineFastState.compose env24319 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound24319 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env24320 : List Nat := [2,4,8,16,32,16,8,256,308,21,309,308,268,16384,16417,263,16400,17,21,16416,293,32,16,16418,268,17,309,49,16661,16432,272,32,256,16384,16385,309]

theorem envBound24320 : H12AffineFastState.Bounded env24320 := by
  intro p hp
  have h : env24320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24319_24320 : H12AffineEnvironment.transform 8 308 env24319 = env24320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env24319 == env24320) = true)

def env24321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4161,4194304,16,21763,8193,65,4258940,5392,17664,32041,1364,4256860,256,21793,46092,63068]

theorem envBound24321 : H12AffineFastState.Bounded env24321 := by
  intro p hp
  have h : env24321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24310_24321 : H12AffineEnvironment.transform 6 9 env24310 = env24321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24310 == env24321) = true)

theorem identity24321 : scanCanonicalize (H12AffineFastState.compose env24321 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound24321 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49169,32040,1024,32769,4161,4194304,16,21763,8193,65,4258940,5392,17664,32041,1364,4256860,256,21793,46092,63068]

theorem envBound24322 : H12AffineFastState.Bounded env24322 := by
  intro p hp
  have h : env24322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24321_24322 : H12AffineEnvironment.transform 16 49169 env24321 = env24322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env24321 == env24322) = true)

theorem identity24322 : scanCanonicalize (H12AffineFastState.compose env24322 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24322 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,49169,23669,1024,32769,4161,4194304,16,21763,348,65,4250913,5392,17664,23668,1364,4248833,256,21793,38225,55041]

theorem envBound24323 : H12AffineFastState.Bounded env24323 := by
  intro p hp
  have h : env24323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24322_24323 : H12AffineEnvironment.transform 12 349 env24322 = env24323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24322 == env24323) = true)

theorem identity24323 : scanCanonicalize (H12AffineFastState.compose env24323 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound24323 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,49169,23669,1024,32769,4161,21793,16,21763,348,65,34816,5392,17664,23668,1364,32800,256,21793,38225,55041]

theorem envBound24324 : H12AffineFastState.Bounded env24324 := by
  intro p hp
  have h : env24324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24323_24324 : H12AffineEnvironment.transform 21 21793 env24323 = env24324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env24323 == env24324) = true)

theorem identity24324 : scanCanonicalize (H12AffineFastState.compose env24324 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24324 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env24325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,33111,38160,2420,1024,32769,4161,32,16,2,348,65,34816,5392,4097,2421,1364,32800,256,32,38225,33280]

theorem envBound24325 : H12AffineFastState.Bounded env24325 := by
  intro p hp
  have h : env24325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24324_24325 : H12AffineEnvironment.transform 13 5377 env24324 = env24325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24324 == env24325) = true)

theorem identity24325 : scanCanonicalize (H12AffineFastState.compose env24325 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound24325 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1296,1095,4096,2420,1024,1297,4161,32,16,2,348,65,3344,5392,4097,2421,1364,1328,256,32,4161,1808]

theorem envBound24326 : H12AffineFastState.Bounded env24326 := by
  intro p hp
  have h : env24326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24325_24326 : H12AffineEnvironment.transform 14 1296 env24325 = env24326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env24325 == env24326) = true)

theorem identity24326 : scanCanonicalize (H12AffineFastState.compose env24326 (packedSelected [4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1312) := by decide +kernel

theorem selectedBound24326 : packedSelected [4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1312,4096,349,5377,1296,1095,4096,1108,1024,1297,4161,32,16,2,348,65,48,5392,4097,1109,1364,1328,256,32,4161,1808]

theorem envBound24327 : H12AffineFastState.Bounded env24327 := by
  intro p hp
  have h : env24327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24326_24327 : H12AffineEnvironment.transform 10 1312 env24326 = env24327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1312 env24326 == env24327) = true)

theorem identity24327 : scanCanonicalize (H12AffineFastState.compose env24327 (packedSelected [0,1,3,5,6,7,8,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24327 : packedSelected [0,1,3,5,6,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env24328 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1312,4096,269,5377,1296,1047,4096,1028,1024,1297,4113,32,16,2,268,17,48,5392,4097,1029,1284,1328,256,32,4113,1808]

theorem envBound24328 : H12AffineFastState.Bounded env24328 := by
  intro p hp
  have h : env24328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24327_24328 : H12AffineEnvironment.transform 5 16 env24327 = env24328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24327 == env24328) = true)

theorem identity24328 : scanCanonicalize (H12AffineFastState.compose env24328 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24328 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24329 : List Nat := [2,4,8,16,32,16,9,256,512,20,308,4096,269,4373,260,3,4096,16,20,261,4113,32,16,2,268,17,48,4356,4097,17,272,292,256,32,4113,772]

theorem envBound24329 : H12AffineFastState.Bounded env24329 := by
  intro p hp
  have h : env24329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24328_24329 : H12AffineEnvironment.transform 9 20 env24328 = env24329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24328 == env24329) = true)

theorem identity24329 : scanCanonicalize (H12AffineFastState.compose env24329 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound24329 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env24330 : List Nat := [2,4,8,16,32,16,9,256,512,20,308,292,269,49,260,3,292,16,20,261,309,32,16,2,268,17,48,32,293,17,272,292,256,32,309,772]

theorem envBound24330 : H12AffineFastState.Bounded env24330 := by
  intro p hp
  have h : env24330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24329_24330 : H12AffineEnvironment.transform 11 292 env24329 = env24330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env24329 == env24330) = true)

theorem identity24330 : scanCanonicalize (H12AffineFastState.compose env24330 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24330 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24331 : List Nat := [2,4,8,16,1,16,9,256,512,20,277,261,269,16,260,3,261,16,20,261,276,1,16,2,268,17,17,1,260,17,272,261,256,1,276,772]

theorem envBound24331 : H12AffineFastState.Bounded env24331 := by
  intro p hp
  have h : env24331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24330_24331 : H12AffineEnvironment.transform 4 1 env24330 = env24331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24330 == env24331) = true)

theorem identity24331 : scanCanonicalize (H12AffineFastState.compose env24331 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24331 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env24332 : List Nat := [2,4,8,16,1,16,9,4,512,20,17,1,9,16,0,3,1,16,20,1,16,1,16,2,8,17,17,1,0,17,20,1,4,1,16,512]

theorem envBound24332 : H12AffineFastState.Bounded env24332 := by
  intro p hp
  have h : env24332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24331_24332 : H12AffineEnvironment.transform 7 4 env24331 = env24332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24331 == env24332) = true)

theorem identity24332 : scanCanonicalize (H12AffineFastState.compose env24332 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound24332 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24333 : List Nat := [2,4,8,5,1,5,9,4,512,1,4,1,9,5,0,3,1,5,1,1,5,1,5,2,8,4,4,1,0,4,1,1,4,1,5,512]

theorem envBound24333 : H12AffineFastState.Bounded env24333 := by
  intro p hp
  have h : env24333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24332_24333 : H12AffineEnvironment.transform 3 5 env24332 = env24333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env24332 == env24333) = true)

theorem identity24333 : scanCanonicalize (H12AffineFastState.compose env24333 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound24333 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24334 : List Nat := [2,4,8,5,1,5,9,4,8,1,4,1,9,5,0,3,1,5,1,1,5,1,5,2,8,4,4,1,0,4,1,1,4,1,5,8]

theorem envBound24334 : H12AffineFastState.Bounded env24334 := by
  intro p hp
  have h : env24334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24333_24334 : H12AffineEnvironment.transform 8 8 env24333 = env24334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env24333 == env24334) = true)

theorem identity24334 : scanCanonicalize (H12AffineFastState.compose env24334 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound24334 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24335 : List Nat := [2,1,8,0,1,0,9,1,8,1,1,1,9,0,0,3,1,0,1,1,0,1,0,2,8,1,1,1,0,1,1,1,1,1,0,8]

theorem envBound24335 : H12AffineFastState.Bounded env24335 := by
  intro p hp
  have h : env24335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24334_24335 : H12AffineEnvironment.transform 1 1 env24334 = env24335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env24334 == env24335) = true)

theorem identity24335 : scanCanonicalize (H12AffineFastState.compose env24335 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24335 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24336 : List Nat := [2,1,3,0,1,0,2,1,3,1,1,1,2,0,0,3,1,0,1,1,0,1,0,2,3,1,1,1,0,1,1,1,1,1,0,3]

theorem envBound24336 : H12AffineFastState.Bounded env24336 := by
  intro p hp
  have h : env24336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24335_24336 : H12AffineEnvironment.transform 2 3 env24335 = env24336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24335 == env24336) = true)

def env24337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound24337 : H12AffineFastState.Bounded env24337 := by
  intro p hp
  have h : env24337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24191_24337 : H12AffineEnvironment.transform 18 1025 env24191 = env24337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env24191 == env24337) = true)

theorem identity24337 : scanCanonicalize (H12AffineFastState.compose env24337 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8686062) := by decide +kernel

theorem selectedBound24337 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8686062,8328,65,4409839,10816866,10507601,8830977,331263,15068207,257,2444611,2469094,272937]

theorem envBound24338 : H12AffineFastState.Bounded env24338 := by
  intro p hp
  have h : env24338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24337_24338 : H12AffineEnvironment.transform 23 8686062 env24337 = env24338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8686062 env24337 == env24338) = true)

def env24339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4409703,10816866,10507601,8830977,331127,15068207,257,2444611,2468974,272937]

theorem envBound24339 : H12AffineFastState.Bounded env24339 := by
  intro p hp
  have h : env24339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24338_24339 : H12AffineEnvironment.transform 6 8 env24338 = env24339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24338 == env24339) = true)

theorem identity24339 : scanCanonicalize (H12AffineFastState.compose env24339 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 371054) := by decide +kernel

theorem selectedBound24339 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env24340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,371054,73736,8192,65,4409703,2139148,2489407,223599,331127,6309185,257,2444611,2468974,272937]

theorem envBound24340 : H12AffineFastState.Bounded env24340 := by
  intro p hp
  have h : env24340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24339_24340 : H12AffineEnvironment.transform 22 371054 env24339 = env24340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 371054 env24339 == env24340) = true)

theorem identity24340 : scanCanonicalize (H12AffineFastState.compose env24340 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24340 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env24341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,2097152,4194304,297316,2,8192,65,4352365,2139148,2415669,149861,273789,6309185,257,2387273,2395236,272937]

theorem envBound24341 : H12AffineFastState.Bounded env24341 := by
  intro p hp
  have h : env24341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24340_24341 : H12AffineEnvironment.transform 15 8202 env24340 = env24341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24340 == env24341) = true)

theorem identity24341 : scanCanonicalize (H12AffineFastState.compose env24341 (packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24341 : packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env24342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,2097152,4194304,297316,2,8192,65,4204924,2139148,2415669,2420,273789,6309185,257,2387273,2395236,272937]

theorem envBound24342 : H12AffineFastState.Bounded env24342 := by
  intro p hp
  have h : env24342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24341_24342 : H12AffineEnvironment.transform 16 16401 env24341 = env24342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24341 == env24342) = true)

theorem identity24342 : scanCanonicalize (H12AffineFastState.compose env24342 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24342 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env24343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,2097152,4194304,41292,2,8192,65,4204924,2139148,2159645,2420,1365,6309185,257,2114913,2139212,513]

theorem envBound24343 : H12AffineFastState.Bounded env24343 := by
  intro p hp
  have h : env24343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24342_24343 : H12AffineEnvironment.transform 17 10280 env24342 = env24343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24342 == env24343) = true)

theorem identity24343 : scanCanonicalize (H12AffineFastState.compose env24343 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound24343 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env24344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,58396,4194304,41292,2,8192,65,4204924,16400,4097,2420,1365,4235613,257,41341,16464,513]

theorem envBound24344 : H12AffineFastState.Bounded env24344 := by
  intro p hp
  have h : env24344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24343_24344 : H12AffineEnvironment.transform 20 58396 env24343 = env24344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env24343 == env24344) = true)

theorem identity24344 : scanCanonicalize (H12AffineFastState.compose env24344 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 24924) := by decide +kernel

theorem selectedBound24344 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,24924,8202,16401,10280,1025,24925,1344,4194304,16400,2,8192,65,4204924,16400,4097,2420,1365,4210689,257,16417,16464,513]

theorem envBound24345 : H12AffineFastState.Bounded env24345 := by
  intro p hp
  have h : env24345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24344_24345 : H12AffineEnvironment.transform 14 24924 env24344 = env24345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24924 env24344 == env24345) = true)

theorem identity24345 : scanCanonicalize (H12AffineFastState.compose env24345 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound24345 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env24346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10508,2128,8202,10525,10280,1025,2129,1344,4194304,10524,2,8192,65,4204924,10524,4097,2420,1365,4204813,257,10541,10588,513]

theorem envBound24346 : H12AffineFastState.Bounded env24346 := by
  intro p hp
  have h : env24346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24345_24346 : H12AffineEnvironment.transform 13 10508 env24345 = env24346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env24345 == env24346) = true)

theorem identity24346 : scanCanonicalize (H12AffineFastState.compose env24346 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 7456) := by decide +kernel

theorem selectedBound24346 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env24347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10508,2128,8202,10525,10280,1025,2129,1344,7456,10524,2,8192,65,13404,10524,4097,2420,1365,13357,257,10541,10588,513]

theorem envBound24347 : H12AffineFastState.Bounded env24347 := by
  intro p hp
  have h : env24347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24346_24347 : H12AffineEnvironment.transform 21 7456 env24346 = env24347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7456 env24346 == env24347) = true)

theorem identity24347 : scanCanonicalize (H12AffineFastState.compose env24347 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound24347 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,8192,10508,2128,8202,10525,10280,1025,2129,1344,3376,10524,2,8192,65,9292,10524,17,2420,1365,9277,257,10541,10588,513]

theorem envBound24348 : H12AffineFastState.Bounded env24348 := by
  intro p hp
  have h : env24348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24347_24348 : H12AffineEnvironment.transform 11 16 env24347 = env24348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24347 == env24348) = true)

theorem identity24348 : scanCanonicalize (H12AffineFastState.compose env24348 (packedSelected [4,9,23] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound24348 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env24349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1053,3345,2128,1047,3328,3125,1025,2129,1344,3376,3329,2,1053,65,81,3329,17,2420,1365,32,257,3376,3393,513]

theorem envBound24349 : H12AffineFastState.Bounded env24349 := by
  intro p hp
  have h : env24349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24348_24349 : H12AffineEnvironment.transform 12 1053 env24348 = env24349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env24348 == env24349) = true)

theorem identity24349 : scanCanonicalize (H12AffineFastState.compose env24349 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound24349 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24350 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,16,348,2128,2128,342,2113,2420,320,2129,1,2161,2112,2,348,65,81,2112,17,2420,20,32,257,2161,2048,513]

theorem envBound24350 : H12AffineFastState.Bounded env24350 := by
  intro p hp
  have h : env24350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24349_24350 : H12AffineEnvironment.transform 9 321 env24349 = env24350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env24349 == env24350) = true)

theorem identity24350 : scanCanonicalize (H12AffineFastState.compose env24350 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound24350 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24351 : List Nat := [2,4,8,16,32,64,8,256,512,321,372,16,348,292,292,342,309,0,320,293,1,261,308,2,348,65,81,308,17,0,20,32,257,261,372,513]

theorem envBound24351 : H12AffineFastState.Bounded env24351 := by
  intro p hp
  have h : env24351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24350_24351 : H12AffineEnvironment.transform 10 372 env24350 = env24351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env24350 == env24351) = true)

theorem identity24351 : scanCanonicalize (H12AffineFastState.compose env24351 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound24351 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env24352 : List Nat := [2,4,8,16,32,32,8,256,512,289,276,16,316,292,292,310,309,0,288,293,1,261,308,2,316,33,49,308,17,0,20,32,257,261,276,513]

theorem envBound24352 : H12AffineFastState.Bounded env24352 := by
  intro p hp
  have h : env24352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24351_24352 : H12AffineEnvironment.transform 5 32 env24351 = env24352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env24351 == env24352) = true)

theorem identity24352 : scanCanonicalize (H12AffineFastState.compose env24352 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound24352 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24353 : List Nat := [2,4,8,16,16,16,8,256,512,273,276,16,268,276,276,262,261,0,272,277,1,261,260,2,268,17,1,260,17,0,20,16,257,261,276,513]

theorem envBound24353 : H12AffineFastState.Bounded env24353 := by
  intro p hp
  have h : env24353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24352_24353 : H12AffineEnvironment.transform 4 16 env24352 = env24353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env24352 == env24353) = true)

theorem identity24353 : scanCanonicalize (H12AffineFastState.compose env24353 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound24353 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24354 : List Nat := [2,4,8,16,16,16,8,256,276,273,276,16,268,276,276,262,261,0,272,277,1,261,260,2,268,17,1,260,17,0,20,16,257,261,276,277]

theorem envBound24354 : H12AffineFastState.Bounded env24354 := by
  intro p hp
  have h : env24354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24353_24354 : H12AffineEnvironment.transform 8 276 env24353 = env24354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env24353 == env24354) = true)

theorem identity24354 : scanCanonicalize (H12AffineFastState.compose env24354 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound24354 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env24355 : List Nat := [2,4,8,16,16,16,8,21,1,4,1,16,25,1,1,19,16,0,5,0,1,16,17,2,25,17,1,17,17,0,20,16,20,16,1,0]

theorem envBound24355 : H12AffineFastState.Bounded env24355 := by
  intro p hp
  have h : env24355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24354_24355 : H12AffineEnvironment.transform 7 21 env24354 = env24355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env24354 == env24355) = true)

def env24356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4409702,10816866,10507601,8830977,331126,15068207,257,2444611,2468975,272937]

theorem envBound24356 : H12AffineFastState.Bounded env24356 := by
  intro p hp
  have h : env24356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24338_24356 : H12AffineEnvironment.transform 6 9 env24338 = env24356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24338 == env24356) = true)

def env24357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4262262,10816866,10507601,8683537,331126,15068207,257,2444611,2468975,272937]

theorem envBound24357 : H12AffineFastState.Bounded env24357 := by
  intro p hp
  have h : env24357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24356_24357 : H12AffineEnvironment.transform 16 16400 env24356 = env24357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24356 == env24357) = true)

theorem identity24357 : scanCanonicalize (H12AffineFastState.compose env24357 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24357 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env24358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429903,8193,65,4262262,10560842,10507601,8431673,75102,14795783,257,2188651,2196551,513]

theorem envBound24358 : H12AffineFastState.Bounded env24358 := by
  intro p hp
  have h : env24358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24357_24358 : H12AffineEnvironment.transform 17 10280 env24357 = env24358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24357 == env24358) = true)

def env24359 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429855,8193,17,4262182,10560794,10507521,8431673,75022,14795783,257,2188603,2196503,513]

theorem envBound24359 : H12AffineFastState.Bounded env24359 := by
  intro p hp
  have h : env24359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24358_24359 : H12AffineEnvironment.transform 5 16 env24358 = env24359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24358 == env24359) = true)

theorem identity24359 : scanCanonicalize (H12AffineFastState.compose env24359 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4292919) := by decide +kernel

theorem selectedBound24359 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env24360 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4292919,4268072,8193,17,4262182,6333485,6411318,4270350,75022,2114864,257,2188603,2196503,513]

theorem envBound24360 : H12AffineFastState.Bounded env24360 := by
  intro p hp
  have h : env24360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24359_24360 : H12AffineEnvironment.transform 22 4292919 env24359 = env24360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292919 env24359 == env24360) = true)

theorem identity24360 : scanCanonicalize (H12AffineFastState.compose env24360 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound24360 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env24361 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,8492,106523,65796,8193,17,75786,2131201,2225434,67618,75022,2114864,257,2188603,2196503,513]

theorem envBound24361 : H12AffineFastState.Bounded env24361 := by
  intro p hp
  have h : env24361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24360_24361 : H12AffineEnvironment.transform 21 8492 env24360 = env24361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env24360 == env24361) = true)

theorem identity24361 : scanCanonicalize (H12AffineFastState.compose env24361 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound24361 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24362 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,50448,8492,106523,65796,8193,17,75786,16401,77834,67618,75022,32800,257,106539,82183,513]

theorem envBound24362 : H12AffineFastState.Bounded env24362 := by
  intro p hp
  have h : env24362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24361_24362 : H12AffineEnvironment.transform 20 50448 env24361 = env24362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env24361 == env24362) = true)

theorem identity24362 : scanCanonicalize (H12AffineFastState.compose env24362 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound24362 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24363 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1025,32769,50448,8492,16,41231,8193,17,34817,16401,36865,43049,34053,32800,257,32,57612,513]

theorem envBound24363 : H12AffineFastState.Bounded env24363 := by
  intro p hp
  have h : env24363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24362_24363 : H12AffineEnvironment.transform 15 40971 env24362 = env24363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env24362 == env24363) = true)

theorem identity24363 : scanCanonicalize (H12AffineFastState.compose env24363 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24363 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24364 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,33030,16400,2341,1025,32769,50448,33,16,32770,268,17,34817,16401,36865,35108,34053,32800,257,32,49153,513]

theorem envBound24364 : H12AffineFastState.Bounded env24364 := by
  intro p hp
  have h : env24364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24363_24364 : H12AffineEnvironment.transform 12 269 env24363 = env24364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24363 == env24364) = true)

theorem identity24364 : scanCanonicalize (H12AffineFastState.compose env24364 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24364 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24365 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,262,16400,2341,1025,1,17680,33,16,2,268,17,2049,16401,4097,2340,1285,32,257,32,16385,513]

theorem envBound24365 : H12AffineFastState.Bounded env24365 := by
  intro p hp
  have h : env24365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24364_24365 : H12AffineEnvironment.transform 14 0 env24364 = env24365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24364 == env24365) = true)

theorem identity24365 : scanCanonicalize (H12AffineFastState.compose env24365 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound24365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24366 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1312,269,16384,0,262,16400,2341,1025,1,17680,33,16,2,268,17,2049,16401,1313,2340,1285,32,257,32,16385,513]

theorem envBound24366 : H12AffineFastState.Bounded env24366 := by
  intro p hp
  have h : env24366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24365_24366 : H12AffineEnvironment.transform 11 1312 env24365 = env24366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env24365 == env24366) = true)

theorem identity24366 : scanCanonicalize (H12AffineFastState.compose env24366 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound24366 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24367 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1557,1312,269,16384,0,262,16400,1840,1025,1,17680,33,16,2,268,17,1556,16401,1313,1841,1285,32,257,32,16385,513]

theorem envBound24367 : H12AffineFastState.Bounded env24367 := by
  intro p hp
  have h : env24367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24366_24367 : H12AffineEnvironment.transform 10 1557 env24366 = env24367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env24366 == env24367) = true)

theorem identity24367 : scanCanonicalize (H12AffineFastState.compose env24367 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound24367 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24368 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1557,1312,269,1028,0,262,1044,1840,1025,1,276,33,16,2,268,17,1556,1045,1313,1841,1285,32,257,32,1029,513]

theorem envBound24368 : H12AffineFastState.Bounded env24368 := by
  intro p hp
  have h : env24368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24367_24368 : H12AffineEnvironment.transform 13 1028 env24367 = env24368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env24367 == env24368) = true)

def env24369 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429854,8193,16,4262183,10560795,10507520,8431673,75023,14795783,257,2188602,2196502,513]

theorem envBound24369 : H12AffineFastState.Bounded env24369 := by
  intro p hp
  have h : env24369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24358_24369 : H12AffineEnvironment.transform 5 17 env24358 = env24369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24358 == env24369) = true)

theorem identity24369 : scanCanonicalize (H12AffineFastState.compose env24369 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4235581) := by decide +kernel

theorem selectedBound24369 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env24370 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4235581,4194339,8193,16,4262183,6390822,6353981,4196612,75023,2188602,257,2188602,2196502,513]

theorem envBound24370 : H12AffineFastState.Bounded env24370 := by
  intro p hp
  have h : env24370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24369_24370 : H12AffineEnvironment.transform 22 4235581 env24369 = env24370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235581 env24369 == env24370) = true)

theorem identity24370 : scanCanonicalize (H12AffineFastState.compose env24370 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound24370 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env24371 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,41261,16,41230,8193,16,108554,2172171,2118928,43049,75023,2188602,257,2188602,2196502,513]

theorem envBound24371 : H12AffineFastState.Bounded env24371 := by
  intro p hp
  have h : env24371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24370_24371 : H12AffineEnvironment.transform 21 41261 env24370 = env24371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env24370 == env24371) = true)

theorem identity24371 : scanCanonicalize (H12AffineFastState.compose env24371 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24371 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24372 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1025,32769,2097152,41261,16,41230,8193,16,34817,2098432,2118928,43049,1284,2114865,257,2114865,2139165,513]

theorem envBound24372 : H12AffineFastState.Bounded env24372 := by
  intro p hp
  have h : env24372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24371_24372 : H12AffineEnvironment.transform 15 8203 env24371 = env24372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24371 == env24372) = true)

theorem identity24372 : scanCanonicalize (H12AffineFastState.compose env24372 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24372 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24373 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10280,1025,1,2097152,8493,16,8462,8193,16,2049,2098432,2118928,10281,1284,2114865,257,2114865,2106397,513]

theorem envBound24373 : H12AffineFastState.Bounded env24373 := by
  intro p hp
  have h : env24373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24372_24373 : H12AffineEnvironment.transform 14 0 env24372 = env24373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24372 == env24373) = true)

theorem identity24373 : scanCanonicalize (H12AffineFastState.compose env24373 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24373 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24374 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,262,16400,2341,1025,1,2097152,32,16,3,268,16,2049,2098432,2118928,2340,1284,2114865,257,2114865,2098448,513]

theorem envBound24374 : H12AffineFastState.Bounded env24374 := by
  intro p hp
  have h : env24374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24373_24374 : H12AffineEnvironment.transform 12 269 env24373 = env24374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24373 == env24374) = true)

theorem identity24374 : scanCanonicalize (H12AffineFastState.compose env24374 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24374 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24375 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,269,16384,0,262,16400,1296,1025,1,2097152,32,16,3,268,16,1076,2098432,2118928,1297,1284,2114865,257,2114865,2098448,513]

theorem envBound24375 : H12AffineFastState.Bounded env24375 := by
  intro p hp
  have h : env24375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24374_24375 : H12AffineEnvironment.transform 10 1077 env24374 = env24375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env24374 == env24375) = true)

theorem identity24375 : scanCanonicalize (H12AffineFastState.compose env24375 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(20+1) ^^^ 5157) := by decide +kernel

theorem selectedBound24375 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24376 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,269,16384,0,262,16400,1296,1025,1,5157,32,16,3,268,16,1076,4389,16693,1297,1284,20756,257,20756,4405,513]

theorem envBound24376 : H12AffineFastState.Bounded env24376 := by
  intro p hp
  have h : env24376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24375_24376 : H12AffineEnvironment.transform 20 5157 env24375 = env24376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5157 env24375 == env24376) = true)

theorem identity24376 : scanCanonicalize (H12AffineFastState.compose env24376 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound24376 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24377 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,269,293,0,262,309,1296,1025,1,5157,32,16,3,268,16,1076,4389,16,1297,1284,4145,257,4145,4405,513]

theorem envBound24377 : H12AffineFastState.Bounded env24377 := by
  intro p hp
  have h : env24377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24376_24377 : H12AffineEnvironment.transform 13 293 env24376 = env24377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env24376 == env24377) = true)

theorem identity24377 : scanCanonicalize (H12AffineFastState.compose env24377 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound24377 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24378 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,1060,269,293,0,262,309,1296,1025,1,1,32,16,3,268,16,1076,1281,16,1297,1284,1045,257,1045,1297,513]

theorem envBound24378 : H12AffineFastState.Bounded env24378 := by
  intro p hp
  have h : env24378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24377_24378 : H12AffineEnvironment.transform 11 1060 env24377 = env24378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env24377 == env24378) = true)

theorem identity24378 : scanCanonicalize (H12AffineFastState.compose env24378 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24378 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24379 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,1060,40,0,0,35,16,1077,1025,1,1,32,16,3,41,16,1076,1060,16,1076,1057,1045,36,1045,1076,513]

theorem envBound24379 : H12AffineFastState.Bounded env24379 := by
  intro p hp
  have h : env24379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24378_24379 : H12AffineEnvironment.transform 7 37 env24378 = env24379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24378 == env24379) = true)

theorem identity24379 : scanCanonicalize (H12AffineFastState.compose env24379 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24380 : List Nat := [2,4,8,16,32,17,9,37,512,53,0,17,40,0,0,35,16,0,52,1,1,32,16,3,41,16,1,17,16,1,20,32,36,32,1,513]

theorem envBound24380 : H12AffineFastState.Bounded env24380 := by
  intro p hp
  have h : env24380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24379_24380 : H12AffineEnvironment.transform 9 53 env24379 = env24380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24379 == env24380) = true)

theorem identity24380 : scanCanonicalize (H12AffineFastState.compose env24380 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24381 : List Nat := [2,4,8,16,17,17,9,20,512,4,0,17,25,0,0,18,16,0,5,1,1,17,16,3,24,16,1,17,16,1,20,17,21,17,1,513]

theorem envBound24381 : H12AffineFastState.Bounded env24381 := by
  intro p hp
  have h : env24381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24380_24381 : H12AffineEnvironment.transform 4 17 env24380 = env24381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24380 == env24381) = true)

theorem identity24381 : scanCanonicalize (H12AffineFastState.compose env24381 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24382 : List Nat := [2,4,8,1,0,0,9,5,512,4,0,0,8,0,0,3,1,0,5,1,1,0,1,3,9,1,1,0,1,1,5,0,4,0,1,513]

theorem envBound24382 : H12AffineFastState.Bounded env24382 := by
  intro p hp
  have h : env24382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24381_24382 : H12AffineEnvironment.transform 3 1 env24381 = env24382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24381 == env24382) = true)

def env24383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4262263,10816866,10507601,8683536,331126,15068207,257,2444611,2468975,272937]

theorem envBound24383 : H12AffineFastState.Bounded env24383 := by
  intro p hp
  have h : env24383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24356_24383 : H12AffineEnvironment.transform 16 16401 env24356 = env24383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24356 == env24383) = true)

def env24384 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685879,8193,17,4262183,10816818,10507521,8683536,331046,15068207,257,2444563,2468927,272937]

theorem envBound24384 : H12AffineFastState.Bounded env24384 := by
  intro p hp
  have h : env24384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24383_24384 : H12AffineEnvironment.transform 5 16 env24383 = env24384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24383 == env24384) = true)

def env24385 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685879,8193,17,4262183,10815490,10506289,8683536,329750,15067423,257,2443299,2468111,272937]

theorem envBound24385 : H12AffineFastState.Bounded env24385 := by
  intro p hp
  have h : env24385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24384_24385 : H12AffineEnvironment.transform 9 304 env24384 = env24385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env24384 == env24385) = true)

theorem identity24385 : scanCanonicalize (H12AffineFastState.compose env24385 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4466712) := by decide +kernel

theorem selectedBound24385 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24386 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4466712,4235567,8193,17,4262183,6365210,6584361,4237320,329750,2212103,257,2443299,2468111,272937]

theorem envBound24386 : H12AffineFastState.Bounded env24386 := by
  intro p hp
  have h : env24386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24385_24386 : H12AffineEnvironment.transform 22 4466712 env24385 = env24386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4466712 env24385 == env24386) = true)

def env24387 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,8192,16384,32768,65536,16401,262144,273,32769,2097152,4194304,4466712,4235535,8193,17,4262151,6365210,6584329,4237320,329750,2212103,257,2443267,2468111,272905]

theorem envBound24387 : H12AffineFastState.Bounded env24387 := by
  intro p hp
  have h : env24387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24386_24387 : H12AffineEnvironment.transform 4 0 env24386 = env24387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24386 == env24387) = true)

theorem identity24387 : scanCanonicalize (H12AffineFastState.compose env24387 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24387 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env24388 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,262144,273,32769,2097152,4194304,4458772,4227075,269,17,4262151,6357270,6576389,4229380,329750,2212103,257,2443267,2459651,264965]

theorem envBound24388 : H12AffineFastState.Bounded env24388 := by
  intro p hp
  have h : env24388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24387_24388 : H12AffineEnvironment.transform 12 268 env24387 = env24388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24387 == env24388) = true)

theorem identity24388 : scanCanonicalize (H12AffineFastState.compose env24388 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 280837) := by decide +kernel

theorem selectedBound24388 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24389 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,262144,273,32769,280837,4194304,4458772,4227075,269,17,4262151,4540435,4198400,4229380,329750,362498,257,65798,114950,264965]

theorem envBound24389 : H12AffineFastState.Bounded env24389 := by
  intro p hp
  have h : env24389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24388_24389 : H12AffineEnvironment.transform 20 280837 env24388 = env24389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 280837 env24388 == env24389) = true)

theorem identity24389 : scanCanonicalize (H12AffineFastState.compose env24389 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 362499) := by decide +kernel

theorem selectedBound24389 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24390 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,262144,273,32769,280837,362499,98583,329728,269,17,295172,49168,366595,327943,329750,362498,257,65798,114950,264965]

theorem envBound24390 : H12AffineFastState.Bounded env24390 := by
  intro p hp
  have h : env24390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24389_24390 : H12AffineEnvironment.transform 21 362499 env24389 = env24390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362499 env24389 == env24390) = true)

theorem identity24390 : scanCanonicalize (H12AffineFastState.compose env24390 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound24390 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24391 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,2309,273,32769,16384,98566,98583,65797,269,17,34817,49168,102662,67586,65811,98567,257,65798,114950,512]

theorem envBound24391 : H12AffineFastState.Bounded env24391 := by
  intro p hp
  have h : env24391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24390_24391 : H12AffineEnvironment.transform 17 2309 env24390 = env24391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env24390 == env24391) = true)

theorem identity24391 : scanCanonicalize (H12AffineFastState.compose env24391 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound24391 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24392 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,33031,16401,2309,273,32769,16384,1,16,32770,269,17,34817,49168,4097,35077,32788,0,257,32769,16385,512]

theorem envBound24392 : H12AffineFastState.Bounded env24392 := by
  intro p hp
  have h : env24392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24391_24392 : H12AffineEnvironment.transform 15 33031 env24391 = env24392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env24391 == env24392) = true)

theorem identity24392 : scanCanonicalize (H12AffineFastState.compose env24392 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24392 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24393 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,1,262,16401,2309,273,0,16384,1,16,3,269,17,2048,16401,4097,2308,21,0,257,0,16385,512]

theorem envBound24393 : H12AffineFastState.Bounded env24393 := by
  intro p hp
  have h : env24393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24392_24393 : H12AffineEnvironment.transform 14 1 env24392 = env24393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24392 == env24393) = true)

def env24394 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,32768,65536,16401,262144,272,32769,2097152,4194304,4466712,4235534,8193,17,4262150,6365210,6584328,4237320,329750,2212103,257,2443266,2468111,272904]

theorem envBound24394 : H12AffineFastState.Bounded env24394 := by
  intro p hp
  have h : env24394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24386_24394 : H12AffineEnvironment.transform 4 1 env24386 = env24394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24386 == env24394) = true)

theorem identity24394 : scanCanonicalize (H12AffineFastState.compose env24394 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound24394 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env24395 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,32768,65536,16401,2309,272,32769,2097152,4194304,4202781,4235534,8193,17,4262150,6365210,6320397,4237320,65811,2212103,257,2179335,2203658,8973]

theorem envBound24395 : H12AffineFastState.Bounded env24395 := by
  intro p hp
  have h : env24395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24394_24395 : H12AffineEnvironment.transform 17 2309 env24394 = env24395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env24394 == env24395) = true)

theorem identity24395 : scanCanonicalize (H12AffineFastState.compose env24395 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 122891) := by decide +kernel

theorem selectedBound24395 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env24396 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,32768,65536,16401,2309,272,32769,122891,4194304,4202781,4235534,8193,17,4262150,4243473,4296966,4237320,65811,8460,257,41228,16385,8973]

theorem envBound24396 : H12AffineFastState.Bounded env24396 := by
  intro p hp
  have h : env24396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24395_24396 : H12AffineEnvironment.transform 20 122891 env24395 = env24396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 122891 env24395 == env24396) = true)

theorem identity24396 : scanCanonicalize (H12AffineFastState.compose env24396 (packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24396 : packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env24397 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,1,65536,16401,2309,272,0,90122,4194304,4202781,4202767,8193,17,4262150,4210704,4264199,4204553,65811,8460,257,8461,16385,8973]

theorem envBound24397 : H12AffineFastState.Bounded env24397 := by
  intro p hp
  have h : env24397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24396_24397 : H12AffineEnvironment.transform 14 1 env24396 = env24397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24396 == env24397) = true)

theorem identity24397 : scanCanonicalize (H12AffineFastState.compose env24397 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(21+1) ^^^ 65798) := by decide +kernel

theorem selectedBound24397 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24398 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,1,65536,16401,2309,272,0,90122,65798,73755,73737,8193,17,2048,82198,4097,76047,65811,8460,257,8461,16385,8973]

theorem envBound24398 : H12AffineFastState.Bounded env24398 := by
  intro p hp
  have h : env24398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24397_24398 : H12AffineEnvironment.transform 21 65798 env24397 = env24398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65798 env24397 == env24398) = true)

theorem identity24398 : scanCanonicalize (H12AffineFastState.compose env24398 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound24398 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env24399 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,4372,1,65536,4357,2309,272,0,78110,65798,73755,73737,8193,17,2048,69634,4097,76047,65811,8460,257,8461,4373,8973]

theorem envBound24399 : H12AffineFastState.Bounded env24399 := by
  intro p hp
  have h : env24399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24398_24399 : H12AffineEnvironment.transform 13 4372 env24398 = env24399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env24398 == env24399) = true)

theorem identity24399 : scanCanonicalize (H12AffineFastState.compose env24399 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound24399 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env24400 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,6168,4372,1,65536,4357,2309,272,0,67846,65798,71683,71697,6169,17,2048,69634,4097,69911,65811,6420,257,6421,4373,6933]

theorem envBound24400 : H12AffineFastState.Bounded env24400 := by
  intro p hp
  have h : env24400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24399_24400 : H12AffineEnvironment.transform 12 6168 env24399 = env24400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env24399 == env24400) = true)

theorem identity24400 : scanCanonicalize (H12AffineFastState.compose env24400 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 4375) := by decide +kernel

theorem selectedBound24400 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24401 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,6168,4372,1,4375,4357,2309,272,0,6161,4113,2324,2310,6169,17,2048,277,4097,0,4100,6420,257,6421,4373,6933]

theorem envBound24401 : H12AffineFastState.Bounded env24401 := by
  intro p hp
  have h : env24401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24400_24401 : H12AffineEnvironment.transform 15 4375 env24400 = env24401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4375 env24400 == env24401) = true)

theorem identity24401 : scanCanonicalize (H12AffineFastState.compose env24401 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound24401 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24402 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,2325,269,2049,1,2050,2064,2309,272,0,260,2308,2324,2310,268,17,2048,277,2324,0,2321,1,257,0,2048,512]

theorem envBound24402 : H12AffineFastState.Bounded env24402 := by
  intro p hp
  have h : env24402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24401_24402 : H12AffineEnvironment.transform 11 2325 env24401 = env24402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env24401 == env24402) = true)

theorem identity24402 : scanCanonicalize (H12AffineFastState.compose env24402 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound24402 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24403 : List Nat := [2,4,8,16,1,16,9,256,512,273,261,16,269,260,1,263,277,0,272,0,260,1,17,3,268,17,261,277,17,0,20,1,257,0,261,512]

theorem envBound24403 : H12AffineFastState.Bounded env24403 := by
  intro p hp
  have h : env24403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24402_24403 : H12AffineEnvironment.transform 10 261 env24402 = env24403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env24402 == env24403) = true)

theorem identity24403 : scanCanonicalize (H12AffineFastState.compose env24403 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24404 : List Nat := [2,4,8,0,1,0,9,256,512,257,261,0,269,260,1,263,261,0,256,0,260,1,1,3,268,1,261,261,1,0,4,1,257,0,261,512]

theorem envBound24404 : H12AffineFastState.Bounded env24404 := by
  intro p hp
  have h : env24404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24403_24404 : H12AffineEnvironment.transform 3 0 env24403 = env24404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24403 == env24404) = true)

theorem identity24404 : scanCanonicalize (H12AffineFastState.compose env24404 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24404 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24405 : List Nat := [2,4,2,0,1,0,3,256,512,257,261,0,263,260,1,263,261,0,256,0,260,1,1,3,262,1,261,261,1,0,4,1,257,0,261,512]

theorem envBound24405 : H12AffineFastState.Bounded env24405 := by
  intro p hp
  have h : env24405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24404_24405 : H12AffineEnvironment.transform 2 2 env24404 = env24405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24404 == env24405) = true)

theorem identity24405 : scanCanonicalize (H12AffineFastState.compose env24405 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound24405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24406 : List Nat := [2,4,2,0,1,0,3,3,512,2,6,0,4,7,1,4,6,0,3,0,7,1,1,3,5,1,6,6,1,0,4,1,2,0,6,512]

theorem envBound24406 : H12AffineFastState.Bounded env24406 := by
  intro p hp
  have h : env24406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24405_24406 : H12AffineEnvironment.transform 7 3 env24405 = env24406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env24405 == env24406) = true)

theorem identity24406 : scanCanonicalize (H12AffineFastState.compose env24406 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound24406 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24407 : List Nat := [2,2,2,0,1,0,3,3,512,2,0,0,2,1,1,2,0,0,3,0,1,1,1,3,3,1,0,0,1,0,2,1,2,0,0,512]

theorem envBound24407 : H12AffineFastState.Bounded env24407 := by
  intro p hp
  have h : env24407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24406_24407 : H12AffineEnvironment.transform 1 2 env24406 = env24407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env24406 == env24407) = true)

theorem identity24407 : scanCanonicalize (H12AffineFastState.compose env24407 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound24407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24408 : List Nat := [2,2,2,0,1,0,3,3,3,2,0,0,2,1,1,2,0,0,3,0,1,1,1,3,3,1,0,0,1,0,2,1,2,0,0,3]

theorem envBound24408 : H12AffineFastState.Bounded env24408 := by
  intro p hp
  have h : env24408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24407_24408 : H12AffineEnvironment.transform 8 3 env24407 = env24408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env24407 == env24408) = true)

def env24409 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685879,8193,17,4262183,10815491,10506288,8683536,329751,15067422,257,2443298,2468110,272937]

theorem envBound24409 : H12AffineFastState.Bounded env24409 := by
  intro p hp
  have h : env24409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24384_24409 : H12AffineEnvironment.transform 9 305 env24384 = env24409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env24384 == env24409) = true)

theorem identity24409 : scanCanonicalize (H12AffineFastState.compose env24409 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound24409 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24410 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4194352,4491527,8193,17,4262183,6621235,6311936,4489248,329751,2484526,257,2443298,2468110,272937]

theorem envBound24410 : H12AffineFastState.Bounded env24410 := by
  intro p hp
  have h : env24410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24409_24410 : H12AffineEnvironment.transform 22 4194352 env24409 = env24410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env24409 == env24410) = true)

theorem identity24410 : scanCanonicalize (H12AffineFastState.compose env24410 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24410 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24411 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4194352,4235567,8193,17,4262183,6365211,6311936,4237320,73791,2212102,257,2187274,2195750,513]

theorem envBound24411 : H12AffineFastState.Bounded env24411 := by
  intro p hp
  have h : env24411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24410_24411 : H12AffineEnvironment.transform 17 10280 env24410 = env24411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24410 == env24411) = true)

theorem identity24411 : scanCanonicalize (H12AffineFastState.compose env24411 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 106539) := by decide +kernel

theorem selectedBound24411 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24412 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,106539,106523,65796,8193,17,43276,2129968,2224171,67619,73791,2212102,257,2187274,2195750,513]

theorem envBound24412 : H12AffineFastState.Bounded env24412 := by
  intro p hp
  have h : env24412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24411_24412 : H12AffineEnvironment.transform 21 106539 env24411 = env24412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 106539 env24411 == env24412) = true)

theorem identity24412 : scanCanonicalize (H12AffineFastState.compose env24412 (packedSelected [0,1,3,5,7,8,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24412 : packedSelected [0,1,3,5,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env24413 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,65536,16401,2341,304,32769,2097152,98598,98582,65796,268,17,34817,2129968,2216230,67619,65842,2212102,257,2179335,2195750,513]

theorem envBound24413 : H12AffineFastState.Bounded env24413 := by
  intro p hp
  have h : env24413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24412_24413 : H12AffineEnvironment.transform 12 269 env24412 = env24413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24412 == env24413) = true)

theorem identity24413 : scanCanonicalize (H12AffineFastState.compose env24413 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound24413 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24414 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,262,16401,2341,304,32769,2097152,32800,32784,2,268,17,34817,2129968,2150432,2341,52,2146304,257,2113537,2129952,513]

theorem envBound24414 : H12AffineFastState.Bounded env24414 := by
  intro p hp
  have h : env24414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24413_24414 : H12AffineEnvironment.transform 15 262 env24413 = env24414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env24413 == env24414) = true)

theorem identity24414 : scanCanonicalize (H12AffineFastState.compose env24414 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 16416) := by decide +kernel

theorem selectedBound24414 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24415 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,262,16401,2341,304,32769,16416,32800,32784,2,268,17,34817,49168,36864,2341,52,32800,257,33,49152,513]

theorem envBound24415 : H12AffineFastState.Bounded env24415 := by
  intro p hp
  have h : env24415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24414_24415 : H12AffineEnvironment.transform 20 16416 env24414 = env24415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16416 env24414 == env24415) = true)

theorem identity24415 : scanCanonicalize (H12AffineFastState.compose env24415 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 2058) := by decide +kernel

theorem selectedBound24415 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env24416 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,2058,262,16401,2341,304,2059,16416,2090,2074,2,268,17,11,18458,6154,2341,52,2090,257,33,18442,513]

theorem envBound24416 : H12AffineFastState.Bounded env24416 := by
  intro p hp
  have h : env24416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24415_24416 : H12AffineEnvironment.transform 14 2058 env24415 = env24416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2058 env24415 == env24416) = true)

def env24417 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685878,8193,16,4262182,10816819,10507520,8683536,331047,15068207,257,2444562,2468926,272937]

theorem envBound24417 : H12AffineFastState.Bounded env24417 := by
  intro p hp
  have h : env24417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24383_24417 : H12AffineEnvironment.transform 5 17 env24383 = env24417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24383 == env24417) = true)

def env24418 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685878,8193,16,4262182,10815491,10506288,8683536,329751,15067423,257,2443298,2468110,272937]

theorem envBound24418 : H12AffineFastState.Bounded env24418 := by
  intro p hp
  have h : env24418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24417_24418 : H12AffineEnvironment.transform 9 304 env24417 = env24418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env24417 == env24418) = true)

theorem identity24418 : scanCanonicalize (H12AffineFastState.compose env24418 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4524051) := by decide +kernel

theorem selectedBound24418 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24419 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4524051,4292901,8193,16,4262182,6291472,6641699,4294659,329751,2154764,257,2443298,2468110,272937]

theorem envBound24419 : H12AffineFastState.Bounded env24419 := by
  intro p hp
  have h : env24419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24418_24419 : H12AffineEnvironment.transform 22 4524051 env24418 = env24419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4524051 env24418 == env24419) = true)

def env24420 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,4194304,4268091,4292901,8193,16,4262182,6291472,6385675,4294659,73791,2154764,257,2187274,2195750,513]

theorem envBound24420 : H12AffineFastState.Bounded env24420 := by
  intro p hp
  have h : env24420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24419_24420 : H12AffineEnvironment.transform 17 10280 env24419 = env24420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24419 == env24420) = true)

theorem identity24420 : scanCanonicalize (H12AffineFastState.compose env24420 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24420 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env24421 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,1,65536,16401,10280,305,0,2097152,4194304,4268091,4260132,8193,16,4262182,6291472,6385675,4261890,73791,2121997,257,2187274,2162983,513]

theorem envBound24421 : H12AffineFastState.Bounded env24421 := by
  intro p hp
  have h : env24421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24420_24421 : H12AffineEnvironment.transform 14 1 env24420 = env24421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24420 == env24421) = true)

theorem identity24421 : scanCanonicalize (H12AffineFastState.compose env24421 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24421 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24422 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,1,8202,16401,10280,305,0,2097152,4194304,4194353,4202798,8193,16,4204844,6291472,6311937,4204552,53,2121997,257,2113536,2105645,513]

theorem envBound24422 : H12AffineFastState.Bounded env24422 := by
  intro p hp
  have h : env24422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24421_24422 : H12AffineEnvironment.transform 15 8202 env24421 = env24422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24421 == env24422) = true)

theorem identity24422 : scanCanonicalize (H12AffineFastState.compose env24422 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113537) := by decide +kernel

theorem selectedBound24422 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24423 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,1,8202,16401,10280,305,0,2097152,2113537,2113584,2122031,8193,16,2124077,16401,4096,2123785,53,2121997,257,2113536,2105645,513]

theorem envBound24423 : H12AffineFastState.Bounded env24423 := by
  intro p hp
  have h : env24423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24422_24423 : H12AffineEnvironment.transform 21 2113537 env24422 = env24423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113537 env24422 == env24423) = true)

theorem identity24423 : scanCanonicalize (H12AffineFastState.compose env24423 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24876) := by decide +kernel

theorem selectedBound24423 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24424 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,1,8202,16401,10280,305,0,24876,8493,8476,3,8193,16,2049,16401,4096,2341,53,33,257,8492,16385,513]

theorem envBound24424 : H12AffineFastState.Bounded env24424 := by
  intro p hp
  have h : env24424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24423_24424 : H12AffineEnvironment.transform 20 24876 env24423 = env24424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24876 env24423 == env24424) = true)

theorem identity24424 : scanCanonicalize (H12AffineFastState.compose env24424 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24424 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24425 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,269,16384,1,263,16401,2341,305,0,16417,32,17,3,268,16,2049,16401,4096,2341,53,33,257,33,16385,513]

theorem envBound24425 : H12AffineFastState.Bounded env24425 := by
  intro p hp
  have h : env24425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24424_24425 : H12AffineEnvironment.transform 12 269 env24424 = env24425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24424 == env24425) = true)

theorem identity24425 : scanCanonicalize (H12AffineFastState.compose env24425 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24426 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,4096,269,16384,1,263,16401,2308,272,0,16384,1,17,3,268,16,2049,16401,4096,2308,20,0,257,0,16385,513]

theorem envBound24426 : H12AffineFastState.Bounded env24426 := by
  intro p hp
  have h : env24426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24425_24426 : H12AffineEnvironment.transform 4 1 env24425 = env24426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24425 == env24426) = true)

theorem identity24426 : scanCanonicalize (H12AffineFastState.compose env24426 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound24426 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24427 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,16,269,16384,1,263,16401,2308,272,0,16384,1,17,3,268,16,2049,16401,16,2308,20,0,257,0,16385,513]

theorem envBound24427 : H12AffineFastState.Bounded env24427 := by
  intro p hp
  have h : env24427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24426_24427 : H12AffineEnvironment.transform 11 16 env24426 = env24427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24426 == env24427) = true)

theorem identity24427 : scanCanonicalize (H12AffineFastState.compose env24427 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound24427 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24428 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,16,269,513,1,263,528,2308,272,0,513,1,17,3,268,16,2049,528,16,2308,20,0,257,0,512,513]

theorem envBound24428 : H12AffineFastState.Bounded env24428 := by
  intro p hp
  have h : env24428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24427_24428 : H12AffineEnvironment.transform 13 513 env24427 = env24428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env24427 == env24428) = true)

theorem identity24428 : scanCanonicalize (H12AffineFastState.compose env24428 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound24428 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24429 : List Nat := [2,4,8,16,1,17,9,256,512,273,529,16,269,513,1,263,528,789,272,0,513,1,17,3,268,16,528,528,16,789,20,0,257,0,512,513]

theorem envBound24429 : H12AffineFastState.Bounded env24429 := by
  intro p hp
  have h : env24429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24428_24429 : H12AffineEnvironment.transform 10 529 env24428 = env24429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env24428 == env24429) = true)

theorem identity24429 : scanCanonicalize (H12AffineFastState.compose env24429 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24429 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24430 : List Nat := [2,4,8,1,1,0,9,256,512,256,512,1,269,513,1,263,513,772,257,0,513,1,0,3,268,1,513,513,1,772,5,0,257,0,512,513]

theorem envBound24430 : H12AffineFastState.Bounded env24430 := by
  intro p hp
  have h : env24430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24429_24430 : H12AffineEnvironment.transform 3 1 env24429 = env24430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24429 == env24430) = true)

theorem identity24430 : scanCanonicalize (H12AffineFastState.compose env24430 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound24430 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24431 : List Nat := [2,4,8,1,1,0,9,256,261,256,261,1,269,260,1,263,260,1,257,0,260,1,0,3,268,1,260,260,1,1,5,0,257,0,261,260]

theorem envBound24431 : H12AffineFastState.Bounded env24431 := by
  intro p hp
  have h : env24431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24430_24431 : H12AffineEnvironment.transform 8 261 env24430 = env24431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env24430 == env24431) = true)

def env24432 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,2097152,4194304,4268090,4292901,8193,16,4262182,6291472,6385674,4294659,73790,2154764,257,2187275,2195751,512]

theorem envBound24432 : H12AffineFastState.Bounded env24432 := by
  intro p hp
  have h : env24432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24419_24432 : H12AffineEnvironment.transform 17 10281 env24419 = env24432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24419 == env24432) = true)

theorem identity24432 : scanCanonicalize (H12AffineFastState.compose env24432 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(21+1) ^^^ 2226235) := by decide +kernel

theorem selectedBound24432 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env24433 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,2097152,2226235,2152449,2128158,8193,16,2158877,129067,34865,2125880,73790,2154764,257,2187275,2195751,512]

theorem envBound24433 : H12AffineFastState.Bounded env24433 := by
  intro p hp
  have h : env24433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24432_24433 : H12AffineEnvironment.transform 21 2226235 env24432 = env24433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2226235 env24432 == env24433) = true)

theorem identity24433 : scanCanonicalize (H12AffineFastState.compose env24433 (packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 47130) := by decide +kernel

theorem selectedBound24433 : packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env24434 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,47130,16401,10281,305,32769,2097152,2113569,2152449,2128158,8193,16,2158877,16433,34865,2125880,38948,2154764,257,2152465,2111805,512]

theorem envBound24434 : H12AffineFastState.Bounded env24434 := by
  intro p hp
  have h : env24434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24433_24434 : H12AffineEnvironment.transform 15 47130 env24433 = env24434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47130 env24433 == env24434) = true)

theorem identity24434 : scanCanonicalize (H12AffineFastState.compose env24434 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 55313) := by decide +kernel

theorem selectedBound24434 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24435 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,47130,16401,10281,305,32769,55313,38960,16,41231,8193,16,10508,16433,34865,43049,38948,14621,257,0,57644,512]

theorem envBound24435 : H12AffineFastState.Bounded env24435 := by
  intro p hp
  have h : env24435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24434_24435 : H12AffineEnvironment.transform 20 55313 env24434 = env24435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 55313 env24434 == env24435) = true)

theorem identity24435 : scanCanonicalize (H12AffineFastState.compose env24435 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 26664) := by decide +kernel

theorem selectedBound24435 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24436 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,26664,20530,16401,10281,305,26665,12345,28696,16,18727,8193,16,10508,16433,24601,16385,28684,14621,257,0,2308,512]

theorem envBound24436 : H12AffineFastState.Bounded env24436 := by
  intro p hp
  have h : env24436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24435_24436 : H12AffineEnvironment.transform 14 26664 env24435 = env24436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26664 env24435 == env24436) = true)

theorem identity24436 : scanCanonicalize (H12AffineFastState.compose env24436 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound24436 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24437 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,6168,16384,20528,20530,16401,4145,305,20529,2081,18432,16,18727,6169,16,4372,16433,22529,16385,18452,261,257,0,2308,512]

theorem envBound24437 : H12AffineFastState.Bounded env24437 := by
  intro p hp
  have h : env24437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24436_24437 : H12AffineEnvironment.transform 12 6168 env24436 = env24437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env24436 == env24437) = true)

theorem identity24437 : scanCanonicalize (H12AffineFastState.compose env24437 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound24437 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env24438 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,6168,4404,260,262,4389,4145,305,261,2081,6452,16,6163,6169,16,4372,4357,2357,4405,6432,261,257,0,2308,512]

theorem envBound24438 : H12AffineFastState.Bounded env24438 := by
  intro p hp
  have h : env24438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24437_24438 : H12AffineEnvironment.transform 13 4404 env24437 = env24438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env24437 == env24438) = true)

theorem identity24438 : scanCanonicalize (H12AffineFastState.compose env24438 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound24438 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24439 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,2097,41,2309,260,262,2324,2048,305,261,2081,261,16,34,40,16,2341,2356,2357,2308,273,261,257,0,2308,512]

theorem envBound24439 : H12AffineFastState.Bounded env24439 := by
  intro p hp
  have h : env24439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24438_24439 : H12AffineEnvironment.transform 11 2097 env24438 = env24439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env24438 == env24439) = true)

theorem identity24439 : scanCanonicalize (H12AffineFastState.compose env24439 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound24439 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env24440 : List Nat := [2,4,8,16,32,17,9,256,512,304,261,308,41,0,260,262,17,261,305,261,292,261,16,34,40,16,32,49,48,1,273,261,257,0,1,512]

theorem envBound24440 : H12AffineFastState.Bounded env24440 := by
  intro p hp
  have h : env24440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24439_24440 : H12AffineEnvironment.transform 10 261 env24439 = env24440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env24439 == env24440) = true)

theorem identity24440 : scanCanonicalize (H12AffineFastState.compose env24440 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24440 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24441 : List Nat := [2,4,8,16,0,17,9,256,512,272,261,276,9,0,260,262,17,261,273,261,260,261,16,2,8,16,0,17,16,1,273,261,257,0,1,512]

theorem envBound24441 : H12AffineFastState.Bounded env24441 := by
  intro p hp
  have h : env24441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24440_24441 : H12AffineEnvironment.transform 4 0 env24440 = env24441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24440 == env24441) = true)

def env24442 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685878,8193,16,4262182,10815490,10506289,8683536,329750,15067422,257,2443299,2468111,272937]

theorem envBound24442 : H12AffineFastState.Bounded env24442 := by
  intro p hp
  have h : env24442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24417_24442 : H12AffineEnvironment.transform 9 305 env24417 = env24442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env24417 == env24442) = true)

theorem identity24442 : scanCanonicalize (H12AffineFastState.compose env24442 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4268091) := by decide +kernel

theorem selectedBound24442 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24443 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4268091,4565261,8193,16,4262182,6563897,6385674,4562987,329750,2410789,257,2443299,2468111,272937]

theorem envBound24443 : H12AffineFastState.Bounded env24443 := by
  intro p hp
  have h : env24443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24442_24443 : H12AffineEnvironment.transform 22 4268091 env24442 = env24443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268091 env24442 == env24443) = true)

theorem identity24443 : scanCanonicalize (H12AffineFastState.compose env24443 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24443 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env24444 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4268091,4292901,8193,16,4262182,6291473,6385674,4294659,73790,2154765,257,2187275,2195751,513]

theorem envBound24444 : H12AffineFastState.Bounded env24444 := by
  intro p hp
  have h : env24444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24443_24444 : H12AffineEnvironment.transform 17 10280 env24443 = env24444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24443 == env24444) = true)

theorem identity24444 : scanCanonicalize (H12AffineFastState.compose env24444 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24444 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env24445 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,1,65536,16401,10280,304,0,2097152,4194304,4268091,4260132,8193,16,4262182,6291473,6385674,4261890,73790,2121996,257,2187275,2162982,513]

theorem envBound24445 : H12AffineFastState.Bounded env24445 := by
  intro p hp
  have h : env24445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24444_24445 : H12AffineEnvironment.transform 14 1 env24444 = env24445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24444 == env24445) = true)

theorem identity24445 : scanCanonicalize (H12AffineFastState.compose env24445 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24445 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24446 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,1,8202,16401,10280,304,0,2097152,4194304,4194353,4202798,8193,16,4204844,6291473,6311936,4204552,52,2121996,257,2113537,2105644,513]

theorem envBound24446 : H12AffineFastState.Bounded env24446 := by
  intro p hp
  have h : env24446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24445_24446 : H12AffineEnvironment.transform 15 8202 env24445 = env24446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24445 == env24446) = true)

theorem identity24446 : scanCanonicalize (H12AffineFastState.compose env24446 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113536) := by decide +kernel

theorem selectedBound24446 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24447 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,1,8202,16401,10280,304,0,2097152,2113536,2113585,2122030,8193,16,2124076,16401,4096,2123784,52,2121996,257,2113537,2105644,513]

theorem envBound24447 : H12AffineFastState.Bounded env24447 := by
  intro p hp
  have h : env24447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24446_24447 : H12AffineEnvironment.transform 21 2113536 env24446 = env24447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113536 env24446 == env24447) = true)

theorem identity24447 : scanCanonicalize (H12AffineFastState.compose env24447 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24877) := by decide +kernel

theorem selectedBound24447 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24448 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,1,8202,16401,10280,304,0,24877,8493,8476,3,8193,16,2049,16401,4096,2341,52,33,257,8492,16385,513]

theorem envBound24448 : H12AffineFastState.Bounded env24448 := by
  intro p hp
  have h : env24448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24447_24448 : H12AffineEnvironment.transform 20 24877 env24447 = env24448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24877 env24447 == env24448) = true)

theorem identity24448 : scanCanonicalize (H12AffineFastState.compose env24448 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24448 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24449 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,269,16384,1,263,16401,2341,304,0,16416,32,17,3,268,16,2049,16401,4096,2341,52,33,257,33,16385,513]

theorem envBound24449 : H12AffineFastState.Bounded env24449 := by
  intro p hp
  have h : env24449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24448_24449 : H12AffineEnvironment.transform 12 269 env24448 = env24449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24448 == env24449) = true)

theorem identity24449 : scanCanonicalize (H12AffineFastState.compose env24449 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24450 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,4096,269,16384,1,263,16401,2308,273,0,16385,1,17,3,268,16,2049,16401,4096,2308,21,0,257,0,16385,513]

theorem envBound24450 : H12AffineFastState.Bounded env24450 := by
  intro p hp
  have h : env24450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24449_24450 : H12AffineEnvironment.transform 4 1 env24449 = env24450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24449 == env24450) = true)

theorem identity24450 : scanCanonicalize (H12AffineFastState.compose env24450 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound24450 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24451 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,16,269,16384,1,263,16401,2308,273,0,16385,1,17,3,268,16,2049,16401,16,2308,21,0,257,0,16385,513]

theorem envBound24451 : H12AffineFastState.Bounded env24451 := by
  intro p hp
  have h : env24451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24450_24451 : H12AffineEnvironment.transform 11 16 env24450 = env24451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24450 == env24451) = true)

theorem identity24451 : scanCanonicalize (H12AffineFastState.compose env24451 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound24451 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24452 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,16,269,512,1,263,529,2308,273,0,513,1,17,3,268,16,2049,529,16,2308,21,0,257,0,513,513]

theorem envBound24452 : H12AffineFastState.Bounded env24452 := by
  intro p hp
  have h : env24452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24451_24452 : H12AffineEnvironment.transform 13 512 env24451 = env24452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env24451 == env24452) = true)

theorem identity24452 : scanCanonicalize (H12AffineFastState.compose env24452 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound24452 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24453 : List Nat := [2,4,8,16,1,17,9,256,512,272,529,16,269,512,1,263,529,789,273,0,513,1,17,3,268,16,528,529,16,789,21,0,257,0,513,513]

theorem envBound24453 : H12AffineFastState.Bounded env24453 := by
  intro p hp
  have h : env24453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24452_24453 : H12AffineEnvironment.transform 10 529 env24452 = env24453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env24452 == env24453) = true)

theorem identity24453 : scanCanonicalize (H12AffineFastState.compose env24453 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24453 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24454 : List Nat := [2,4,8,0,1,1,9,256,512,256,513,0,269,512,1,263,513,773,257,0,513,1,1,3,268,0,512,513,0,773,5,0,257,0,513,513]

theorem envBound24454 : H12AffineFastState.Bounded env24454 := by
  intro p hp
  have h : env24454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24453_24454 : H12AffineEnvironment.transform 3 0 env24453 = env24454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24453 == env24454) = true)

theorem identity24454 : scanCanonicalize (H12AffineFastState.compose env24454 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound24454 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24455 : List Nat := [2,4,8,0,1,1,9,256,261,256,260,0,269,261,1,263,260,0,257,0,260,1,1,3,268,0,261,260,0,0,5,0,257,0,260,260]

theorem envBound24455 : H12AffineFastState.Bounded env24455 := by
  intro p hp
  have h : env24455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24454_24455 : H12AffineEnvironment.transform 8 261 env24454 = env24455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env24454 == env24455) = true)

theorem identity24455 : scanCanonicalize (H12AffineFastState.compose env24455 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24455 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24456 : List Nat := [2,4,8,0,1,1,9,5,0,5,1,0,8,0,1,2,1,0,4,0,1,1,1,3,9,0,0,1,0,0,5,0,4,0,1,1]

theorem envBound24456 : H12AffineFastState.Bounded env24456 := by
  intro p hp
  have h : env24456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24455_24456 : H12AffineEnvironment.transform 7 5 env24455 = env24456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24455 == env24456) = true)

theorem identity24456 : scanCanonicalize (H12AffineFastState.compose env24456 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24457 : List Nat := [2,4,2,0,1,1,3,5,0,5,1,0,2,0,1,2,1,0,4,0,1,1,1,3,3,0,0,1,0,0,5,0,4,0,1,1]

theorem envBound24457 : H12AffineFastState.Bounded env24457 := by
  intro p hp
  have h : env24457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24456_24457 : H12AffineEnvironment.transform 2 2 env24456 = env24457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24456 == env24457) = true)

def env24458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound24458 : H12AffineFastState.Bounded env24458 := by
  intro p hp
  have h : env24458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24190_24458 : H12AffineEnvironment.transform 26 30393345 env24190 = env24458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env24190 == env24458) = true)

def env24459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound24459 : H12AffineFastState.Bounded env24459 := by
  intro p hp
  have h : env24459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24458_24459 : H12AffineEnvironment.transform 18 1024 env24458 = env24459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env24458 == env24459) = true)

theorem identity24459 : scanCanonicalize (H12AffineFastState.compose env24459 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493614) := by decide +kernel

theorem selectedBound24459 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493614,8328,65,14797999,493603,10507601,8830977,10979519,4680046,256,8898563,8858022,10923880]

theorem envBound24460 : H12AffineFastState.Bounded env24460 := by
  intro p hp
  have h : env24460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24459_24460 : H12AffineEnvironment.transform 23 2493614 env24459 = env24460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493614 env24459 == env24460) = true)

def env24461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797999,115151,10507601,8423917,10600787,4268162,256,8487407,8478794,10544772]

theorem envBound24461 : H12AffineFastState.Bounded env24461 := by
  intro p hp
  have h : env24461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24460_24461 : H12AffineEnvironment.transform 17 149996 env24460 = env24461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env24460 == env24461) = true)

def env24462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,8388608,21762,8328,65,12705007,115151,8406289,8423917,8507667,4268162,256,8487407,8478794,8451780]

theorem envBound24462 : H12AffineFastState.Bounded env24462 := by
  intro p hp
  have h : env24462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24461_24462 : H12AffineEnvironment.transform 20 4160 env24461 = env24462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24461 == env24462) = true)

def env24463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,16,21762,8328,65,4316415,115151,17665,35325,119043,4268162,256,98815,90202,63188]

theorem envBound24463 : H12AffineFastState.Bounded env24463 := by
  intro p hp
  have h : env24463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24462_24463 : H12AffineEnvironment.transform 22 16 env24462 = env24463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env24462 == env24463) = true)

theorem identity24463 : scanCanonicalize (H12AffineFastState.compose env24463 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24463 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149996,1024,29908,4160,4194304,16,21762,8328,65,4270122,79130,17665,32040,75222,4268162,256,95530,90202,513]

theorem envBound24464 : H12AffineFastState.Bounded env24464 := by
  intro p hp
  have h : env24464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24463_24464 : H12AffineEnvironment.transform 14 29909 env24463 = env24464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24463 == env24464) = true)

def env24465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138476,1024,8660,4160,4194304,16,2,8328,65,4270122,79130,4097,10280,75222,4268162,256,73770,79194,513]

theorem envBound24465 : H12AffineFastState.Bounded env24465 := by
  intro p hp
  have h : env24465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24464_24465 : H12AffineEnvironment.transform 13 5376 env24464 = env24465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24464 == env24465) = true)

theorem identity24465 : scanCanonicalize (H12AffineFastState.compose env24465 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound24465 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,10280,1024,8660,4160,4194304,16,2,8328,65,4270122,79130,4097,10280,75222,4268162,256,73770,79194,513]

theorem envBound24466 : H12AffineFastState.Bounded env24466 := by
  intro p hp
  have h : env24466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24465_24466 : H12AffineEnvironment.transform 16 13508 env24465 = env24466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env24465 == env24466) = true)

def env24467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138477,1024,8661,4160,4194304,16,3,8328,65,4270122,79130,4096,10281,75222,4268162,256,73771,79195,513]

theorem envBound24467 : H12AffineFastState.Bounded env24467 := by
  intro p hp
  have h : env24467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24464_24467 : H12AffineEnvironment.transform 13 5377 env24464 = env24467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24464 == env24467) = true)

theorem identity24467 : scanCanonicalize (H12AffineFastState.compose env24467 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound24467 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,10401,1024,8661,4160,4194304,16,3,8328,65,4270122,79130,4096,10281,75222,4268162,256,73771,79195,513]

theorem envBound24468 : H12AffineFastState.Bounded env24468 := by
  intro p hp
  have h : env24468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24467_24468 : H12AffineEnvironment.transform 16 13388 env24467 = env24468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env24467 == env24468) = true)

theorem identity24468 : scanCanonicalize (H12AffineFastState.compose env24468 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound24468 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env24469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,10401,1024,8661,4160,73891,16,3,8328,65,2185,79130,4096,10281,75222,33,256,73771,79195,513]

theorem envBound24469 : H12AffineFastState.Bounded env24469 := by
  intro p hp
  have h : env24469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24468_24469 : H12AffineEnvironment.transform 21 73891 env24468 = env24469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env24468 == env24469) = true)

theorem identity24469 : scanCanonicalize (H12AffineFastState.compose env24469 (packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound24469 : packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS < 2^1333 := by decide +kernel

def env24470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,342,13388,10401,1024,8661,4160,8693,16,3,8328,65,2185,13388,4096,10281,9344,33,256,8573,13325,513]

theorem envBound24470 : H12AffineFastState.Bounded env24470 := by
  intro p hp
  have h : env24470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24469_24470 : H12AffineEnvironment.transform 15 342 env24469 = env24470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env24469 == env24470) = true)

theorem identity24470 : scanCanonicalize (H12AffineFastState.compose env24470 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound24470 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env24471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,342,5528,2421,1024,1,4160,33,16,3,348,65,2185,5528,4096,2557,1364,33,256,169,5593,513]

theorem envBound24471 : H12AffineFastState.Bounded env24471 := by
  intro p hp
  have h : env24471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24470_24471 : H12AffineEnvironment.transform 12 468 env24470 = env24471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env24470 == env24471) = true)

theorem identity24471 : scanCanonicalize (H12AffineFastState.compose env24471 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24471 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env24472 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5377,0,262,5528,2341,1024,1,4112,33,16,3,268,17,2185,5528,4096,2477,1284,33,256,169,5513,513]

theorem envBound24472 : H12AffineFastState.Bounded env24472 := by
  intro p hp
  have h : env24472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24471_24472 : H12AffineEnvironment.transform 5 16 env24471 = env24472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24471 == env24472) = true)

theorem identity24472 : scanCanonicalize (H12AffineFastState.compose env24472 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24472 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24473 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5393,2341,1024,1,4112,33,16,3,268,17,2048,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound24473 : H12AffineFastState.Bounded env24473 := by
  intro p hp
  have h : env24473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24472_24473 : H12AffineEnvironment.transform 6 9 env24472 = env24473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24472 == env24473) = true)

theorem identity24473 : scanCanonicalize (H12AffineFastState.compose env24473 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound24473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24474 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,277,269,1044,0,262,1028,2341,1024,1,261,33,16,3,268,17,2048,1028,277,2340,1284,33,256,32,1045,513]

theorem envBound24474 : H12AffineFastState.Bounded env24474 := by
  intro p hp
  have h : env24474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24473_24474 : H12AffineEnvironment.transform 11 277 env24473 = env24474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env24473 == env24474) = true)

theorem identity24474 : scanCanonicalize (H12AffineFastState.compose env24474 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24474 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24475 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,277,269,1044,0,262,1028,2308,1024,1,261,0,16,3,268,17,2048,1028,277,2309,1284,0,256,1,1045,513]

theorem envBound24475 : H12AffineFastState.Bounded env24475 := by
  intro p hp
  have h : env24475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24474_24475 : H12AffineEnvironment.transform 4 1 env24474 = env24475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24474 == env24475) = true)

theorem identity24475 : scanCanonicalize (H12AffineFastState.compose env24475 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound24475 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24476 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1556,277,269,1044,0,262,1028,1808,1024,1,261,0,16,3,268,17,1556,1028,277,1809,1284,0,256,1,1045,513]

theorem envBound24476 : H12AffineFastState.Bounded env24476 := by
  intro p hp
  have h : env24476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24475_24476 : H12AffineEnvironment.transform 10 1556 env24475 = env24476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env24475 == env24476) = true)

theorem identity24476 : scanCanonicalize (H12AffineFastState.compose env24476 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound24476 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24477 : List Nat := [2,4,8,16,1,16,9,21,512,1024,1556,0,24,1044,0,19,1028,1541,1024,1,16,0,16,3,25,17,1556,1028,0,1540,1041,0,21,1,1045,513]

theorem envBound24477 : H12AffineFastState.Bounded env24477 := by
  intro p hp
  have h : env24477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24476_24477 : H12AffineEnvironment.transform 7 21 env24476 = env24477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env24476 == env24477) = true)

theorem identity24477 : scanCanonicalize (H12AffineFastState.compose env24477 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24477 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24478 : List Nat := [2,4,8,16,1,16,9,21,1,1024,1045,0,24,1044,0,19,1028,1028,1024,1,16,0,16,3,25,17,1045,1028,0,1029,1041,0,21,1,1045,0]

theorem envBound24478 : H12AffineFastState.Bounded env24478 := by
  intro p hp
  have h : env24478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24477_24478 : H12AffineEnvironment.transform 8 1 env24477 = env24478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24477 == env24478) = true)

theorem identity24478 : scanCanonicalize (H12AffineFastState.compose env24478 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24478 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24479 : List Nat := [2,4,8,1,1,1,9,4,1,1024,1028,0,9,1029,0,2,1028,1028,1024,1,1,0,1,3,8,0,1028,1028,0,1029,1024,0,4,1,1028,0]

theorem envBound24479 : H12AffineFastState.Bounded env24479 := by
  intro p hp
  have h : env24479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24478_24479 : H12AffineEnvironment.transform 3 1 env24478 = env24479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24478 == env24479) = true)

def env24480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,17,21762,8328,65,4316414,115151,17664,35324,119042,4268162,256,98814,90203,63189]

theorem envBound24480 : H12AffineFastState.Bounded env24480 := by
  intro p hp
  have h : env24480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24462_24480 : H12AffineEnvironment.transform 22 17 env24462 = env24480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env24462 == env24480) = true)

theorem identity24480 : scanCanonicalize (H12AffineFastState.compose env24480 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156012) := by decide +kernel

theorem selectedBound24480 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,156012,17,21762,8328,65,245138,115151,17664,35324,119042,213486,256,98814,90203,63189]

theorem envBound24481 : H12AffineFastState.Bounded env24481 := by
  intro p hp
  have h : env24481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24480_24481 : H12AffineEnvironment.transform 21 156012 env24480 = env24481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env24480 == env24481) = true)

def env24482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,156012,17,21762,8192,65,245018,115015,17664,35188,119042,213350,256,98678,90203,63069]

theorem envBound24482 : H12AffineFastState.Bounded env24482 := by
  intro p hp
  have h : env24482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24481_24482 : H12AffineEnvironment.transform 6 8 env24481 = env24482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24481 == env24482) = true)

theorem identity24482 : scanCanonicalize (H12AffineFastState.compose env24482 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24482 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,138340,1024,32769,4160,144492,17,2,8192,65,245018,103495,4096,35188,99330,201830,256,98678,79195,41821]

theorem envBound24483 : H12AffineFastState.Bounded env24483 := by
  intro p hp
  have h : env24483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24482_24483 : H12AffineEnvironment.transform 13 5376 env24482 = env24483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24482 == env24483) = true)

theorem identity24483 : scanCanonicalize (H12AffineFastState.compose env24483 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound24483 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env24484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,65536,131072,138340,1024,8461,4160,144492,17,2,8192,65,203798,79179,4096,10360,75022,201830,256,73850,79195,593]

theorem envBound24484 : H12AffineFastState.Bounded env24484 := by
  intro p hp
  have h : env24484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24483_24484 : H12AffineEnvironment.transform 14 8460 env24483 = env24484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env24483 == env24484) = true)

theorem identity24484 : scanCanonicalize (H12AffineFastState.compose env24484 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24484 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env24485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,8202,131072,138340,1024,8461,4160,144492,17,2,8192,65,146460,5441,4096,10360,1284,144492,256,112,5457,593]

theorem envBound24485 : H12AffineFastState.Bounded env24485 := by
  intro p hp
  have h : env24485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24484_24485 : H12AffineEnvironment.transform 15 8202 env24484 = env24485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24484 == env24485) = true)

theorem identity24485 : scanCanonicalize (H12AffineFastState.compose env24485 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24485 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env24486 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5157,8233,8202,131072,138340,1024,8232,4160,144492,17,2,8192,65,146460,5220,4096,10360,1057,144492,37,112,5236,593]

theorem envBound24486 : H12AffineFastState.Bounded env24486 := by
  intro p hp
  have h : env24486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24485_24486 : H12AffineEnvironment.transform 7 37 env24485 = env24486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24485 == env24486) = true)

theorem identity24486 : scanCanonicalize (H12AffineFastState.compose env24486 (packedSelected [2,3,4,5,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24486 : packedSelected [2,3,4,5,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24487 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5157,80,115,131072,138340,1024,81,4160,136213,17,2,121,65,138341,5220,4096,2049,1057,136213,37,112,5236,593]

theorem envBound24487 : H12AffineFastState.Bounded env24487 := by
  intro p hp
  have h : env24487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24486_24487 : H12AffineEnvironment.transform 12 121 env24486 = env24487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24486 == env24487) = true)

theorem identity24487 : scanCanonicalize (H12AffineFastState.compose env24487 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound24487 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24488 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5157,80,115,5220,2048,1024,81,4160,113,17,2,121,65,2049,5220,4096,2049,1057,113,37,112,5236,593]

theorem envBound24488 : H12AffineFastState.Bounded env24488 := by
  intro p hp
  have h : env24488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24487_24488 : H12AffineEnvironment.transform 16 5220 env24487 = env24488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env24487 == env24488) = true)

def env24489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156012,17,21762,8193,65,245019,115014,17664,35189,119042,213351,256,98679,90203,63068]

theorem envBound24489 : H12AffineFastState.Bounded env24489 := by
  intro p hp
  have h : env24489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24481_24489 : H12AffineEnvironment.transform 6 9 env24481 = env24489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24481 == env24489) = true)

theorem identity24489 : scanCanonicalize (H12AffineFastState.compose env24489 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24489 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149861,1024,29788,4160,156012,17,21762,8193,65,215366,79131,17664,32040,75103,213351,256,95530,90203,513]

theorem envBound24490 : H12AffineFastState.Bounded env24490 := by
  intro p hp
  have h : env24490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24489_24490 : H12AffineEnvironment.transform 14 29789 env24489 = env24490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24489 == env24490) = true)

theorem identity24490 : scanCanonicalize (H12AffineFastState.compose env24490 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24490 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76158,1024,29788,4160,65911,17,21762,8193,65,10589,79131,17664,32040,75103,8572,256,95530,90203,513]

theorem envBound24491 : H12AffineFastState.Bounded env24491 := by
  intro p hp
  have h : env24491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24490_24491 : H12AffineEnvironment.transform 16 90139 env24490 = env24491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24490 == env24491) = true)

theorem identity24491 : scanCanonicalize (H12AffineFastState.compose env24491 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound24491 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5393,23668,1024,29788,4160,29821,17,21762,8193,65,10589,16401,17664,32040,20565,8572,256,32,5457,513]

theorem envBound24492 : H12AffineFastState.Bounded env24492 := by
  intro p hp
  have h : env24492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24491_24492 : H12AffineEnvironment.transform 15 29962 env24491 = env24492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env24491 == env24492) = true)

theorem identity24492 : scanCanonicalize (H12AffineFastState.compose env24492 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound24492 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,343,5393,10281,1024,1,4160,32,17,8543,8193,65,10589,13388,12637,2421,9224,8572,256,32,5457,513]

theorem envBound24493 : H12AffineFastState.Bounded env24493 := by
  intro p hp
  have h : env24493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24492_24493 : H12AffineEnvironment.transform 13 13405 env24492 = env24493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env24492 == env24493) = true)

theorem identity24493 : scanCanonicalize (H12AffineFastState.compose env24493 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound24493 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4113,0,343,5393,3173,1024,1,4160,32,17,1299,1101,65,3345,4096,5393,2421,68,1328,256,32,5457,513]

theorem envBound24494 : H12AffineFastState.Bounded env24494 := by
  intro p hp
  have h : env24494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24493_24494 : H12AffineEnvironment.transform 12 1100 env24493 = env24494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env24493 == env24494) = true)

theorem identity24494 : scanCanonicalize (H12AffineFastState.compose env24494 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24494 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,4096,1100,4113,0,343,5393,1125,1024,1,4160,32,17,1299,1101,65,1297,4096,5393,373,68,1328,256,32,5457,513]

theorem envBound24495 : H12AffineFastState.Bounded env24495 := by
  intro p hp
  have h : env24495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24494_24495 : H12AffineEnvironment.transform 10 0 env24494 = env24495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24494 == env24495) = true)

theorem identity24495 : scanCanonicalize (H12AffineFastState.compose env24495 (packedSelected [0,2,3,4,5,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24495 : packedSelected [0,2,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24496 : List Nat := [2,4,8,16,32,64,9,256,512,52,0,4096,120,4113,0,343,4389,81,52,1,4160,32,17,295,121,65,293,4096,4389,373,68,260,256,32,4453,513]

theorem envBound24496 : H12AffineFastState.Bounded env24496 := by
  intro p hp
  have h : env24496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24495_24496 : H12AffineEnvironment.transform 9 52 env24495 = env24496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24495 == env24496) = true)

theorem identity24496 : scanCanonicalize (H12AffineFastState.compose env24496 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound24496 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env24497 : List Nat := [2,4,8,16,32,64,9,256,512,52,0,308,120,293,0,343,17,81,52,1,372,32,17,295,121,65,293,308,17,373,68,260,256,32,81,513]

theorem envBound24497 : H12AffineFastState.Bounded env24497 := by
  intro p hp
  have h : env24497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24496_24497 : H12AffineEnvironment.transform 11 308 env24496 = env24497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env24496 == env24497) = true)

theorem identity24497 : scanCanonicalize (H12AffineFastState.compose env24497 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24497 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24498 : List Nat := [2,4,8,16,32,17,9,256,512,52,0,308,41,293,0,262,17,0,52,1,293,32,17,295,40,16,293,308,17,292,21,260,256,32,0,513]

theorem envBound24498 : H12AffineFastState.Bounded env24498 := by
  intro p hp
  have h : env24498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24497_24498 : H12AffineEnvironment.transform 5 17 env24497 = env24498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24497 == env24498) = true)

theorem identity24498 : scanCanonicalize (H12AffineFastState.compose env24498 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound24498 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env24499 : List Nat := [2,4,8,16,32,17,9,256,308,52,0,308,41,293,0,262,17,0,52,1,293,32,17,295,40,16,293,308,17,292,21,260,256,32,0,309]

theorem envBound24499 : H12AffineFastState.Bounded env24499 := by
  intro p hp
  have h : env24499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24498_24499 : H12AffineEnvironment.transform 8 308 env24498 = env24499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env24498 == env24499) = true)

def env24500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,8388608,21763,8328,65,12705006,115151,8406288,8423917,8507666,4268162,256,8487407,8478794,8451781]

theorem envBound24500 : H12AffineFastState.Bounded env24500 := by
  intro p hp
  have h : env24500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24461_24500 : H12AffineEnvironment.transform 20 4161 env24461 = env24500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24461 == env24500) = true)

def env24501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,16,21763,8328,65,4316414,115151,17664,35325,119042,4268162,256,98815,90202,63189]

theorem envBound24501 : H12AffineFastState.Bounded env24501 := by
  intro p hp
  have h : env24501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24500_24501 : H12AffineEnvironment.transform 22 16 env24500 = env24501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env24500 == env24501) = true)

def env24502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,16,21763,8192,65,4316278,115015,17664,35189,119042,4268042,256,98679,90202,63069]

theorem envBound24502 : H12AffineFastState.Bounded env24502 := by
  intro p hp
  have h : env24502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24501_24502 : H12AffineEnvironment.transform 6 8 env24501 = env24502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24501 == env24502) = true)

theorem identity24502 : scanCanonicalize (H12AffineFastState.compose env24502 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound24502 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,32041,1024,32769,4161,4194304,16,21763,8192,65,4316278,115015,17664,35189,119042,4268042,256,98679,90202,63069]

theorem envBound24503 : H12AffineFastState.Bounded env24503 := by
  intro p hp
  have h : env24503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24502_24503 : H12AffineEnvironment.transform 16 13389 env24502 = env24503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env24502 == env24503) = true)

theorem identity24503 : scanCanonicalize (H12AffineFastState.compose env24503 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound24503 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env24504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,13389,32041,1024,32769,4161,4194304,16,21763,8192,65,4229152,38161,17664,35189,34132,4224092,256,54561,13324,63069]

theorem envBound24504 : H12AffineFastState.Bounded env24504 := by
  intro p hp
  have h : env24504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24503_24504 : H12AffineEnvironment.transform 15 21590 env24503 = env24504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env24503 == env24504) = true)

theorem identity24504 : scanCanonicalize (H12AffineFastState.compose env24504 (packedSelected [4,5,9,11,12,14,16,18,23,24,26,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound24504 : packedSelected [4,5,9,11,12,14,16,18,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env24505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,8575,13389,2048,1024,32769,4161,4194304,16,8234,8192,65,4229152,38161,12329,35189,34132,4194677,256,40968,13324,33652]

theorem envBound24505 : H12AffineFastState.Bounded env24505 := by
  intro p hp
  have h : env24505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24504_24505 : H12AffineEnvironment.transform 13 13609 env24504 = env24505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env24504 == env24505) = true)

theorem identity24505 : scanCanonicalize (H12AffineFastState.compose env24505 (packedSelected [1,2,3,5,6,7,8,9,10,20,22,23,26,27,32] rootPS)) = affineNative (2^(21+1) ^^^ 33108) := by decide +kernel

theorem selectedBound24505 : packedSelected [1,2,3,5,6,7,8,9,10,20,22,23,26,27,32] rootPS < 2^1333 := by decide +kernel

def env24506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,8575,13389,2048,1024,32769,4161,33108,16,8234,8192,65,2420,38161,12329,35189,34132,32801,256,40968,13324,33652]

theorem envBound24506 : H12AffineFastState.Bounded env24506 := by
  intro p hp
  have h : env24506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24505_24506 : H12AffineEnvironment.transform 21 33108 env24505 = env24506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33108 env24505 == env24506) = true)

theorem identity24506 : scanCanonicalize (H12AffineFastState.compose env24506 (packedSelected [2,4,6,7,11,14,18,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24506 : packedSelected [2,4,6,7,11,14,18,22,27] rootPS < 2^1333 := by decide +kernel

def env24507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,1,8575,13389,2048,1024,0,4161,341,16,8234,8192,65,2420,5392,12329,2420,1365,32,256,8201,13324,885]

theorem envBound24507 : H12AffineFastState.Bounded env24507 := by
  intro p hp
  have h : env24507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24506_24507 : H12AffineEnvironment.transform 14 1 env24506 = env24507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24506 == env24507) = true)

theorem identity24507 : scanCanonicalize (H12AffineFastState.compose env24507 (packedSelected [0,3,4,5,7,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24507 : packedSelected [0,3,4,5,7,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env24508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,1,343,5221,2048,1024,0,4161,341,16,2,40,65,2420,5392,4097,2420,1365,32,256,33,5156,885]

theorem envBound24508 : H12AffineFastState.Bounded env24508 := by
  intro p hp
  have h : env24508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24507_24508 : H12AffineEnvironment.transform 12 40 env24507 = env24508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24507 == env24508) = true)

theorem identity24508 : scanCanonicalize (H12AffineFastState.compose env24508 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24508 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24509 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1,34,5221,2048,1024,0,4161,32,16,2,40,65,2049,5221,4097,2049,1056,32,117,33,5156,512]

theorem envBound24509 : H12AffineFastState.Bounded env24509 := by
  intro p hp
  have h : env24509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24508_24509 : H12AffineEnvironment.transform 7 117 env24508 = env24509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24508 == env24509) = true)

theorem identity24509 : scanCanonicalize (H12AffineFastState.compose env24509 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound24509 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24510 : List Nat := [2,4,8,16,32,64,8,117,512,1024,554,4096,40,5236,1,34,5221,554,1024,0,4161,32,16,2,40,65,555,5221,4097,555,1056,32,117,33,5156,512]

theorem envBound24510 : H12AffineFastState.Bounded env24510 := by
  intro p hp
  have h : env24510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24509_24510 : H12AffineEnvironment.transform 10 554 env24509 = env24510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env24509 == env24510) = true)

theorem identity24510 : scanCanonicalize (H12AffineFastState.compose env24510 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24510 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24511 : List Nat := [2,4,8,16,32,48,8,5,512,1024,554,4096,40,5124,1,34,5141,554,1024,0,4145,32,16,2,40,49,555,5141,4097,555,1056,32,5,33,5156,512]

theorem envBound24511 : H12AffineFastState.Bounded env24511 := by
  intro p hp
  have h : env24511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24510_24511 : H12AffineEnvironment.transform 5 48 env24510 = env24511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24510 == env24511) = true)

theorem identity24511 : scanCanonicalize (H12AffineFastState.compose env24511 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24511 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24512 : List Nat := [2,4,8,16,1,17,8,5,512,1024,523,4096,9,5124,1,3,5141,523,1024,0,4112,1,16,2,9,16,522,5141,4097,522,1025,1,5,0,5125,512]

theorem envBound24512 : H12AffineFastState.Bounded env24512 := by
  intro p hp
  have h : env24512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24511_24512 : H12AffineEnvironment.transform 4 1 env24511 = env24512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24511 == env24512) = true)

def env24513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,16,21763,8193,65,4316279,115014,17664,35188,119042,4268043,256,98678,90202,63068]

theorem envBound24513 : H12AffineFastState.Bounded env24513 := by
  intro p hp
  have h : env24513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24501_24513 : H12AffineEnvironment.transform 6 9 env24501 = env24513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24501 == env24513) = true)

theorem identity24513 : scanCanonicalize (H12AffineFastState.compose env24513 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound24513 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56437,1024,32769,4161,4194304,16,21763,8193,65,4316279,115014,17664,35188,119042,4268043,256,98678,90202,63068]

theorem envBound24514 : H12AffineFastState.Bounded env24514 := by
  intro p hp
  have h : env24514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24513_24514 : H12AffineEnvironment.transform 16 38160 env24513 = env24514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24513 == env24514) = true)

theorem identity24514 : scanCanonicalize (H12AffineFastState.compose env24514 (packedSelected [1,5,7,10,11,12,14,15,20,24,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24514 : packedSelected [1,5,7,10,11,12,14,15,20,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env24515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35189,1024,32769,4161,4194304,16,3,8193,65,4295031,103494,4096,35188,99330,4268043,256,98678,79194,41820]

theorem envBound24515 : H12AffineFastState.Bounded env24515 := by
  intro p hp
  have h : env24515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24514_24515 : H12AffineEnvironment.transform 13 5376 env24514 = env24515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24514 == env24515) = true)

theorem identity24515 : scanCanonicalize (H12AffineFastState.compose env24515 (packedSelected [0,1,5,7,8,10,14,15,16,19,20,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 32881) := by decide +kernel

theorem selectedBound24515 : packedSelected [0,1,5,7,8,10,14,15,16,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35189,1024,32769,4161,32881,16,3,8193,65,67846,103494,4096,35188,99330,106618,256,98678,79194,41820]

theorem envBound24516 : H12AffineFastState.Bounded env24516 := by
  intro p hp
  have h : env24516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24515_24516 : H12AffineEnvironment.transform 21 32881 env24515 = env24516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32881 env24515 == env24516) = true)

theorem identity24516 : scanCanonicalize (H12AffineFastState.compose env24516 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound24516 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env24517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,65536,5441,2340,1024,80,4161,32,16,3,8193,65,67846,70679,4096,2341,66643,73771,256,65831,79194,8973]

theorem envBound24517 : H12AffineFastState.Bounded env24517 := by
  intro p hp
  have h : env24517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24516_24517 : H12AffineEnvironment.transform 14 81 env24516 = env24517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env24516 == env24517) = true)

def env24518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,17,21763,8328,65,4316415,115151,17665,35324,119043,4268162,256,98814,90203,63188]

theorem envBound24518 : H12AffineFastState.Bounded env24518 := by
  intro p hp
  have h : env24518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24500_24518 : H12AffineEnvironment.transform 22 17 env24500 = env24518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env24500 == env24518) = true)

theorem identity24518 : scanCanonicalize (H12AffineFastState.compose env24518 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound24518 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,169401,17,21763,8328,65,215366,115151,17665,35324,119043,243003,256,98814,90203,63188]

theorem envBound24519 : H12AffineFastState.Bounded env24519 := by
  intro p hp
  have h : env24519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24518_24519 : H12AffineEnvironment.transform 21 169401 env24518 = env24519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env24518 == env24519) = true)

def env24520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,17,21763,8192,65,215366,115015,17665,35188,119043,243003,256,98678,90203,63068]

theorem envBound24520 : H12AffineFastState.Bounded env24520 := by
  intro p hp
  have h : env24520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24519_24520 : H12AffineEnvironment.transform 6 8 env24519 = env24520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24519 == env24520) = true)

theorem identity24520 : scanCanonicalize (H12AffineFastState.compose env24520 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24520 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24521 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,138341,1024,32769,4161,169265,17,2,8192,65,203847,103494,4096,35188,99330,243003,256,98678,79194,41821]

theorem envBound24521 : H12AffineFastState.Bounded env24521 := by
  intro p hp
  have h : env24521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24520_24521 : H12AffineEnvironment.transform 13 5377 env24520 = env24521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24520 == env24521) = true)

theorem identity24521 : scanCanonicalize (H12AffineFastState.compose env24521 (packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 103730) := by decide +kernel

theorem selectedBound24521 : packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env24522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103730,100695,1024,32769,4161,65539,17,2,8192,65,35189,103494,4096,35188,99330,8201,256,98678,79194,41821]

theorem envBound24522 : H12AffineFastState.Bounded env24522 := by
  intro p hp
  have h : env24522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24521_24522 : H12AffineEnvironment.transform 16 103730 env24521 = env24522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103730 env24521 == env24522) = true)

theorem identity24522 : scanCanonicalize (H12AffineFastState.compose env24522 (packedSelected [2,4,6,7,10,11,14,19,22,23,26,27,31] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24522 : packedSelected [2,4,6,7,10,11,14,19,22,23,26,27,31] rootPS < 2^1333 := by decide +kernel

def env24523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,65536,103730,100695,1024,32769,4161,65539,17,2,348,65,35189,103494,4096,35188,99330,341,256,98678,70662,33281]

theorem envBound24523 : H12AffineFastState.Bounded env24523 := by
  intro p hp
  have h : env24523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24522_24523 : H12AffineEnvironment.transform 12 348 env24522 = env24523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24522 == env24523) = true)

theorem identity24523 : scanCanonicalize (H12AffineFastState.compose env24523 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24523 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24524 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,32768,65536,103494,100387,1024,32769,4161,65539,17,2,40,65,34817,103494,4096,34816,99330,33,116,98306,70662,33281]

theorem envBound24524 : H12AffineFastState.Bounded env24524 := by
  intro p hp
  have h : env24524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24523_24524 : H12AffineEnvironment.transform 7 116 env24523 = env24524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24523 == env24524) = true)

theorem identity24524 : scanCanonicalize (H12AffineFastState.compose env24524 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24524 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24525 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,32768,65536,103446,100387,1024,32769,4113,65539,17,2,40,17,34817,103446,4096,34816,99330,33,36,98306,70662,33281]

theorem envBound24525 : H12AffineFastState.Bounded env24525 := by
  intro p hp
  have h : env24525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24524_24525 : H12AffineEnvironment.transform 5 16 env24524 = env24525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24524 == env24525) = true)

theorem identity24525 : scanCanonicalize (H12AffineFastState.compose env24525 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound24525 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env24526 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,32768,32802,5172,2049,1024,32769,4113,32801,17,2,40,17,34817,5172,4096,34816,1056,33,36,32,37924,33281]

theorem envBound24526 : H12AffineFastState.Bounded env24526 := by
  intro p hp
  have h : env24526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24525_24526 : H12AffineEnvironment.transform 15 32802 env24525 = env24526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env24525 == env24526) = true)

theorem identity24526 : scanCanonicalize (H12AffineFastState.compose env24526 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 7205) := by decide +kernel

theorem selectedBound24526 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env24527 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,7205,7175,5172,2049,1024,7204,4113,7172,17,2,40,17,5156,5172,4096,5157,1056,33,36,32,2049,7716]

theorem envBound24527 : H12AffineFastState.Bounded env24527 := by
  intro p hp
  have h : env24527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24526_24527 : H12AffineEnvironment.transform 14 7205 env24526 = env24527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7205 env24526 == env24527) = true)

theorem identity24527 : scanCanonicalize (H12AffineFastState.compose env24527 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24527 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env24528 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,40,4113,6161,6195,4096,2049,52,6160,4113,6192,17,2,40,17,4112,4096,4096,4113,20,33,36,32,2049,6672]

theorem envBound24528 : H12AffineFastState.Bounded env24528 := by
  intro p hp
  have h : env24528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24527_24528 : H12AffineEnvironment.transform 9 52 env24527 = env24528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24527 == env24528) = true)

theorem identity24528 : scanCanonicalize (H12AffineFastState.compose env24528 (packedSelected [1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound24528 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env24529 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,40,2049,1,35,2064,2049,52,0,2049,32,17,2,40,17,2048,2064,2064,2049,20,33,36,32,2049,512]

theorem envBound24529 : H12AffineFastState.Bounded env24529 := by
  intro p hp
  have h : env24529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24528_24529 : H12AffineEnvironment.transform 11 2064 env24528 = env24529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env24528 == env24529) = true)

theorem identity24529 : scanCanonicalize (H12AffineFastState.compose env24529 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound24529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24530 : List Nat := [2,4,8,16,32,16,8,36,512,52,513,529,40,512,1,35,529,512,52,0,512,32,17,2,40,17,513,529,529,512,20,33,36,32,512,512]

theorem envBound24530 : H12AffineFastState.Bounded env24530 := by
  intro p hp
  have h : env24530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24529_24530 : H12AffineEnvironment.transform 10 513 env24529 = env24530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env24529 == env24530) = true)

theorem identity24530 : scanCanonicalize (H12AffineFastState.compose env24530 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 62) := by decide +kernel

theorem selectedBound24530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24531 : List Nat := [2,4,8,16,32,16,8,36,62,52,63,47,40,62,1,35,47,62,52,0,62,32,17,2,40,17,63,47,47,62,20,33,36,32,62,62]

theorem envBound24531 : H12AffineFastState.Bounded env24531 := by
  intro p hp
  have h : env24531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24530_24531 : H12AffineEnvironment.transform 8 62 env24530 = env24531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 62 env24530 == env24531) = true)

theorem identity24531 : scanCanonicalize (H12AffineFastState.compose env24531 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24532 : List Nat := [2,4,8,16,17,16,8,21,15,5,14,30,25,15,1,18,30,15,5,0,15,17,17,2,25,17,14,30,30,15,20,16,21,17,15,15]

theorem envBound24532 : H12AffineFastState.Bounded env24532 := by
  intro p hp
  have h : env24532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24531_24532 : H12AffineEnvironment.transform 4 17 env24531 = env24532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24531 == env24532) = true)

theorem identity24532 : scanCanonicalize (H12AffineFastState.compose env24532 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound24532 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24533 : List Nat := [2,4,8,15,14,15,8,10,15,5,14,1,6,15,1,13,1,15,5,0,15,14,14,2,6,14,14,1,1,15,11,15,10,14,15,15]

theorem envBound24533 : H12AffineFastState.Bounded env24533 := by
  intro p hp
  have h : env24533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24532_24533 : H12AffineEnvironment.transform 3 15 env24532 = env24533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env24532 == env24533) = true)

theorem identity24533 : scanCanonicalize (H12AffineFastState.compose env24533 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound24533 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24534 : List Nat := [2,4,6,1,0,1,6,4,1,5,0,1,6,1,1,3,1,1,5,0,1,0,0,2,6,0,0,1,1,1,5,1,4,0,1,1]

theorem envBound24534 : H12AffineFastState.Bounded env24534 := by
  intro p hp
  have h : env24534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24533_24534 : H12AffineEnvironment.transform 2 6 env24533 = env24534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env24533 == env24534) = true)

def env24535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169264,17,21763,8193,65,215366,115014,17665,35189,119043,243003,256,98679,90203,63069]

theorem envBound24535 : H12AffineFastState.Bounded env24535 := by
  intro p hp
  have h : env24535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24519_24535 : H12AffineEnvironment.transform 6 9 env24519 = env24535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24519 == env24535) = true)

theorem identity24535 : scanCanonicalize (H12AffineFastState.compose env24535 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound24535 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149861,1024,29789,4161,156012,17,21763,8193,65,215366,79130,17665,32041,75103,213351,256,95531,90203,513]

theorem envBound24536 : H12AffineFastState.Bounded env24536 := by
  intro p hp
  have h : env24536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24535_24536 : H12AffineEnvironment.transform 14 29788 env24535 = env24536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24535 == env24536) = true)

theorem identity24536 : scanCanonicalize (H12AffineFastState.compose env24536 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24536 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76158,1024,29789,4161,65911,17,21763,8193,65,10589,79130,17665,32041,75103,8572,256,95531,90203,513]

theorem envBound24537 : H12AffineFastState.Bounded env24537 := by
  intro p hp
  have h : env24537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24536_24537 : H12AffineEnvironment.transform 16 90139 env24536 = env24537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24536 == env24537) = true)

theorem identity24537 : scanCanonicalize (H12AffineFastState.compose env24537 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound24537 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,5392,23669,1024,29789,4161,29820,17,21763,8193,65,10589,16401,17665,32041,20564,8572,256,32,5456,513]

theorem envBound24538 : H12AffineFastState.Bounded env24538 := by
  intro p hp
  have h : env24538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24537_24538 : H12AffineEnvironment.transform 15 29963 env24537 = env24538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env24537 == env24538) = true)

theorem identity24538 : scanCanonicalize (H12AffineFastState.compose env24538 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound24538 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,343,5392,10281,1024,1,4161,32,17,8543,8193,65,10589,13389,12637,2421,9224,8572,256,32,5456,513]

theorem envBound24539 : H12AffineFastState.Bounded env24539 := by
  intro p hp
  have h : env24539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24538_24539 : H12AffineEnvironment.transform 13 13404 env24538 = env24539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env24538 == env24539) = true)

theorem identity24539 : scanCanonicalize (H12AffineFastState.compose env24539 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound24539 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4113,0,343,5392,3172,1024,1,4161,32,17,1298,1100,65,3344,4096,5392,2421,69,1329,256,32,5456,513]

theorem envBound24540 : H12AffineFastState.Bounded env24540 := by
  intro p hp
  have h : env24540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24539_24540 : H12AffineEnvironment.transform 12 1101 env24539 = env24540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env24539 == env24540) = true)

theorem identity24540 : scanCanonicalize (H12AffineFastState.compose env24540 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24540 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,4096,1101,4113,0,343,5392,1124,1024,1,4161,32,17,1298,1100,65,1296,4096,5392,373,69,1329,256,32,5456,513]

theorem envBound24541 : H12AffineFastState.Bounded env24541 := by
  intro p hp
  have h : env24541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24540_24541 : H12AffineEnvironment.transform 10 0 env24540 = env24541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24540 == env24541) = true)

theorem identity24541 : scanCanonicalize (H12AffineFastState.compose env24541 (packedSelected [0,2,3,4,5,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24541 : packedSelected [0,2,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24542 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,4096,1101,4113,0,34,5221,1124,1024,1,4161,32,17,1127,1100,65,1125,4096,5221,0,69,1092,117,32,5157,513]

theorem envBound24542 : H12AffineFastState.Bounded env24542 := by
  intro p hp
  have h : env24542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24541_24542 : H12AffineEnvironment.transform 7 117 env24541 = env24542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24541 == env24542) = true)

theorem identity24542 : scanCanonicalize (H12AffineFastState.compose env24542 (packedSelected [1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24542 : packedSelected [1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env24543 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,4096,121,4113,0,34,4177,80,52,1,4161,32,17,83,120,65,81,4096,4177,0,69,112,117,32,4113,513]

theorem envBound24543 : H12AffineFastState.Bounded env24543 := by
  intro p hp
  have h : env24543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24542_24543 : H12AffineEnvironment.transform 9 52 env24542 = env24543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24542 == env24543) = true)

theorem identity24543 : scanCanonicalize (H12AffineFastState.compose env24543 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24543 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24544 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,17,121,0,0,34,64,80,52,1,80,32,17,83,120,65,81,17,64,0,69,112,117,32,0,513]

theorem envBound24544 : H12AffineFastState.Bounded env24544 := by
  intro p hp
  have h : env24544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24543_24544 : H12AffineEnvironment.transform 11 17 env24543 = env24544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24543 == env24544) = true)

theorem identity24544 : scanCanonicalize (H12AffineFastState.compose env24544 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24544 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env24545 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,17,40,0,0,34,17,1,52,1,1,32,17,2,41,16,0,17,17,0,20,33,36,32,0,513]

theorem envBound24545 : H12AffineFastState.Bounded env24545 := by
  intro p hp
  have h : env24545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24544_24545 : H12AffineEnvironment.transform 5 17 env24544 = env24545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24544 == env24545) = true)

def env24546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797999,115150,10507601,8423916,10600786,4268163,256,8487406,8478795,10544773]

theorem envBound24546 : H12AffineFastState.Bounded env24546 := by
  intro p hp
  have h : env24546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24460_24546 : H12AffineEnvironment.transform 17 149997 env24460 = env24546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env24460 == env24546) = true)

def env24547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,8388608,21763,8328,65,12705007,115150,8406289,8423916,8507666,4268163,256,8487406,8478795,8451781]

theorem envBound24547 : H12AffineFastState.Bounded env24547 := by
  intro p hp
  have h : env24547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24546_24547 : H12AffineEnvironment.transform 20 4160 env24546 = env24547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24546 == env24547) = true)

def env24548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,16,21763,8328,65,4316415,115150,17665,35324,119042,4268163,256,98814,90203,63189]

theorem envBound24548 : H12AffineFastState.Bounded env24548 := by
  intro p hp
  have h : env24548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24547_24548 : H12AffineEnvironment.transform 22 16 env24547 = env24548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env24547 == env24548) = true)

theorem identity24548 : scanCanonicalize (H12AffineFastState.compose env24548 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24548 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4160,4194304,16,21763,8328,65,4259060,57797,17665,35324,61705,4194440,256,41461,16464,63189]

theorem envBound24549 : H12AffineFastState.Bounded env24549 := by
  intro p hp
  have h : env24549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24548_24549 : H12AffineEnvironment.transform 15 8203 env24548 = env24549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24548 == env24549) = true)

def env24550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4160,4194304,16,21763,8192,65,4258940,57677,17665,35188,61705,4194304,256,41341,16464,63069]

theorem envBound24550 : H12AffineFastState.Bounded env24550 := by
  intro p hp
  have h : env24550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24549_24550 : H12AffineEnvironment.transform 6 8 env24549 = env24550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24549 == env24550) = true)

theorem identity24550 : scanCanonicalize (H12AffineFastState.compose env24550 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound24550 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13388,32041,1024,32769,4160,4194304,16,21763,8192,65,4258940,57677,17665,35188,61705,4194304,256,41341,16464,63069]

theorem envBound24551 : H12AffineFastState.Bounded env24551 := by
  intro p hp
  have h : env24551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24550_24551 : H12AffineEnvironment.transform 16 13388 env24550 = env24551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env24550 == env24551) = true)

theorem identity24551 : scanCanonicalize (H12AffineFastState.compose env24551 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound24551 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env24552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13388,32041,1024,32769,4160,32801,16,21763,8192,65,31837,57677,17665,35188,61705,32801,256,41341,16464,63069]

theorem envBound24552 : H12AffineFastState.Bounded env24552 := by
  intro p hp
  have h : env24552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24551_24552 : H12AffineEnvironment.transform 21 32801 env24551 = env24552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env24551 == env24552) = true)

theorem identity24552 : scanCanonicalize (H12AffineFastState.compose env24552 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24552 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env24553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,5392,23669,1024,32769,4160,32801,16,21763,348,65,23809,49169,17665,35188,53333,32801,256,32801,16464,55041]

theorem envBound24553 : H12AffineFastState.Bounded env24553 := by
  intro p hp
  have h : env24553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24552_24553 : H12AffineEnvironment.transform 12 348 env24552 = env24553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24552 == env24553) = true)

theorem identity24553 : scanCanonicalize (H12AffineFastState.compose env24553 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21589) := by decide +kernel

theorem selectedBound24553 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env24554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21589,343,5392,23669,1024,21588,4160,21620,16,21763,348,65,23809,5188,17665,23841,1024,21620,256,21620,16464,852]

theorem envBound24554 : H12AffineFastState.Bounded env24554 := by
  intro p hp
  have h : env24554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24553_24554 : H12AffineEnvironment.transform 14 21589 env24553 = env24554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21589 env24553 == env24554) = true)

def env24555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4160,4194304,16,21763,8193,65,4258941,57676,17665,35189,61705,4194305,256,41340,16464,63068]

theorem envBound24555 : H12AffineFastState.Bounded env24555 := by
  intro p hp
  have h : env24555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24549_24555 : H12AffineEnvironment.transform 6 9 env24549 = env24555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24549 == env24555) = true)

theorem identity24555 : scanCanonicalize (H12AffineFastState.compose env24555 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound24555 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,56437,1024,32769,4160,4194304,16,21763,8193,65,4258941,57676,17665,35189,61705,4194305,256,41340,16464,63068]

theorem envBound24556 : H12AffineFastState.Bounded env24556 := by
  intro p hp
  have h : env24556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24555_24556 : H12AffineEnvironment.transform 16 38161 env24555 = env24556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env24555 == env24556) = true)

theorem identity24556 : scanCanonicalize (H12AffineFastState.compose env24556 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24556 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env24557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,38161,35188,1024,32769,4160,4194304,16,2,8193,65,4237692,46157,4096,35189,41992,4194305,256,41340,5457,41821]

theorem envBound24557 : H12AffineFastState.Bounded env24557 := by
  intro p hp
  have h : env24557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24556_24557 : H12AffineEnvironment.transform 13 5377 env24556 = env24557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24556 == env24557) = true)

def env24558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,17,21763,8328,65,4316414,115150,17664,35325,119043,4268163,256,98815,90202,63188]

theorem envBound24558 : H12AffineFastState.Bounded env24558 := by
  intro p hp
  have h : env24558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24547_24558 : H12AffineEnvironment.transform 22 17 env24547 = env24558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env24547 == env24558) = true)

theorem identity24558 : scanCanonicalize (H12AffineFastState.compose env24558 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243122) := by decide +kernel

theorem selectedBound24558 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,243122,17,21763,8328,65,158028,115150,17664,35325,119043,169265,256,98815,90202,63188]

theorem envBound24559 : H12AffineFastState.Bounded env24559 := by
  intro p hp
  have h : env24559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24558_24559 : H12AffineEnvironment.transform 21 243122 env24558 = env24559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243122 env24558 == env24559) = true)

theorem identity24559 : scanCanonicalize (H12AffineFastState.compose env24559 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24559 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149997,1024,29908,4160,213351,17,21763,8328,65,158028,79131,17664,32040,75222,156132,256,95530,90202,513]

theorem envBound24560 : H12AffineFastState.Bounded env24560 := by
  intro p hp
  have h : env24560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24559_24560 : H12AffineEnvironment.transform 14 29909 env24559 = env24560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24559 == env24560) = true)

theorem identity24560 : scanCanonicalize (H12AffineFastState.compose env24560 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24560 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,76278,1024,29908,4160,8572,17,21763,8328,65,67927,79131,17664,32040,75222,66047,256,95530,90202,513]

theorem envBound24561 : H12AffineFastState.Bounded env24561 := by
  intro p hp
  have h : env24561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24560_24561 : H12AffineEnvironment.transform 16 90139 env24560 = env24561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24560 == env24561) = true)

def env24562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79131,76278,1024,8660,4160,8572,17,3,8328,65,67927,79131,4096,10280,75222,66047,256,73770,79194,513]

theorem envBound24562 : H12AffineFastState.Bounded env24562 := by
  intro p hp
  have h : env24562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24561_24562 : H12AffineEnvironment.transform 13 5376 env24561 = env24562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24561 == env24562) = true)

theorem identity24562 : scanCanonicalize (H12AffineFastState.compose env24562 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24562 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79131,76159,1024,8541,4160,8572,17,3,8193,65,67927,79131,4096,10280,75103,65910,256,73770,79194,513]

theorem envBound24563 : H12AffineFastState.Bounded env24563 := by
  intro p hp
  have h : env24563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24562_24563 : H12AffineEnvironment.transform 6 9 env24562 = env24563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24562 == env24563) = true)

theorem identity24563 : scanCanonicalize (H12AffineFastState.compose env24563 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24563 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1