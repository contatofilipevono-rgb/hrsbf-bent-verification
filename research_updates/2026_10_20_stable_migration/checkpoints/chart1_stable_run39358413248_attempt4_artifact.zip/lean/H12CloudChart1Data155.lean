import H12CloudChart1Data154

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound39302 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39303 : List Nat := [2,4,8,16,32,64,9,36,512,101,0,65,41,80,1,114,16,81,100,0,81,112,64,3,40,65,80,64,17,81,68,33,37,113,0,513]

theorem envBound39303 : H12AffineFastState.Bounded env39303 := by
  intro p hp
  have h : env39303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39302_39303 : H12AffineEnvironment.transform 7 36 env39302 = env39303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39302 == env39303) = true)

theorem identity39303 : scanCanonicalize (H12AffineFastState.compose env39303 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound39303 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39304 : List Nat := [2,4,8,16,32,32,9,36,512,5,0,33,41,48,1,18,16,49,4,0,49,16,32,3,40,33,48,32,17,49,36,33,37,17,0,513]

theorem envBound39304 : H12AffineFastState.Bounded env39304 := by
  intro p hp
  have h : env39304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39303_39304 : H12AffineEnvironment.transform 5 32 env39303 = env39304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env39303 == env39304) = true)

theorem identity39304 : scanCanonicalize (H12AffineFastState.compose env39304 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound39304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39305 : List Nat := [2,4,8,16,32,32,9,36,48,5,0,33,41,48,1,18,16,49,4,0,49,16,32,3,40,33,48,32,17,49,36,33,37,17,0,49]

theorem envBound39305 : H12AffineFastState.Bounded env39305 := by
  intro p hp
  have h : env39305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39304_39305 : H12AffineEnvironment.transform 8 48 env39304 = env39305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env39304 == env39305) = true)

def env39306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318701,466225,8328,65,4456925,313837,449004,138476,148941,4466848,257,21793,46213,221723]

theorem envBound39306 : H12AffineFastState.Bounded env39306 := by
  intro p hp
  have h : env39306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39230_39306 : H12AffineEnvironment.transform 20 151633 env39230 = env39306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env39230 == env39306) = true)

theorem identity39306 : scanCanonicalize (H12AffineFastState.compose env39306 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90259) := by decide +kernel

theorem selectedBound39306 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env39307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90259,262144,1025,32769,78018,4194304,318701,294306,8328,65,4456925,313837,375167,97407,75102,4466848,257,21793,46213,648]

theorem envBound39307 : H12AffineFastState.Bounded env39307 := by
  intro p hp
  have h : env39307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39306_39307 : H12AffineEnvironment.transform 16 90259 env39306 = env39307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90259 env39306 == env39307) = true)

def env39308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77898,4194304,318565,294186,8192,65,4456789,313701,375167,97407,75102,4466728,257,21793,46093,512]

theorem envBound39308 : H12AffineFastState.Bounded env39308 := by
  intro p hp
  have h : env39308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39307_39308 : H12AffineEnvironment.transform 6 8 env39307 = env39308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39307 == env39308) = true)

theorem identity39308 : scanCanonicalize (H12AffineFastState.compose env39308 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 130314) := by decide +kernel

theorem selectedBound39308 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,130314,1025,32769,77898,4194304,74095,98336,8192,65,4324447,78959,17525,97407,75102,4314402,257,21793,46093,512]

theorem envBound39309 : H12AffineFastState.Bounded env39309 := by
  intro p hp
  have h : env39309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39308_39309 : H12AffineEnvironment.transform 17 130314 env39308 = env39309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130314 env39308 == env39309) = true)

theorem identity39309 : scanCanonicalize (H12AffineFastState.compose env39309 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39309 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5393,34816,1025,32769,17728,4194304,21605,62762,8192,65,4229461,16741,17525,2421,20564,4235304,257,21793,46093,512]

theorem envBound39310 : H12AffineFastState.Bounded env39310 := by
  intro p hp
  have h : env39310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39309_39310 : H12AffineEnvironment.transform 15 29962 env39309 = env39310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39309 == env39310) = true)

theorem identity39310 : scanCanonicalize (H12AffineFastState.compose env39310 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 373) := by decide +kernel

theorem selectedBound39310 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5393,34816,1025,32769,17728,373,21605,62762,8192,65,34848,16741,17525,2421,20564,41309,257,21793,46093,512]

theorem envBound39311 : H12AffineFastState.Bounded env39311 := by
  intro p hp
  have h : env39311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39310_39311 : H12AffineEnvironment.transform 21 373 env39310 = env39311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 373 env39310 == env39311) = true)

theorem identity39311 : scanCanonicalize (H12AffineFastState.compose env39311 (packedSelected [9,14,22] rootPS)) = affineNative (2^(14+1) ^^^ 29821) := by decide +kernel

theorem selectedBound39311 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env39312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29821,29962,5393,31869,1025,29820,17728,373,21605,343,8192,65,31837,16741,17525,2421,20564,21792,257,21793,16496,512]

theorem envBound39312 : H12AffineFastState.Bounded env39312 := by
  intro p hp
  have h : env39312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39311_39312 : H12AffineEnvironment.transform 14 29821 env39311 = env39312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29821 env39311 == env39312) = true)

theorem identity39312 : scanCanonicalize (H12AffineFastState.compose env39312 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound39312 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env39313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8201,8574,5393,10249,1025,8200,4404,373,17,343,8192,65,10281,5393,4097,2421,1056,340,257,341,5124,512]

theorem envBound39313 : H12AffineFastState.Bounded env39313 := by
  intro p hp
  have h : env39313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39312_39313 : H12AffineEnvironment.transform 13 5236 env39312 = env39313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env39312 == env39313) = true)

theorem identity39313 : scanCanonicalize (H12AffineFastState.compose env39313 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound39313 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,32,343,5393,2080,1025,33,4404,373,17,343,41,65,2048,5393,4097,2421,1056,340,257,341,5124,512]

theorem envBound39314 : H12AffineFastState.Bounded env39314 := by
  intro p hp
  have h : env39314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39313_39314 : H12AffineEnvironment.transform 12 41 env39313 = env39314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env39313 == env39314) = true)

def env39315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77899,4194304,318564,294187,8193,65,4456788,313700,375167,97407,75102,4466729,257,21793,46092,513]

theorem envBound39315 : H12AffineFastState.Bounded env39315 := by
  intro p hp
  have h : env39315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39307_39315 : H12AffineEnvironment.transform 6 9 env39307 = env39315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39307 == env39315) = true)

theorem identity39315 : scanCanonicalize (H12AffineFastState.compose env39315 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound39315 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56437,1025,32769,77899,4194304,17,41310,8193,65,4250913,5393,91402,97407,75102,4256860,257,21793,46092,513]

theorem envBound39316 : H12AffineFastState.Bounded env39316 := by
  intro p hp
  have h : env39316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39315_39316 : H12AffineEnvironment.transform 17 56437 env39315 = env39316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env39315 == env39316) = true)

theorem identity39316 : scanCanonicalize (H12AffineFastState.compose env39316 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39316 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,35188,1025,32769,77899,4194304,17,41310,8193,65,4229152,5393,77835,76158,75102,4235613,257,32,46092,513]

theorem envBound39317 : H12AffineFastState.Bounded env39317 := by
  intro p hp
  have h : env39317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39316_39317 : H12AffineEnvironment.transform 13 5377 env39316 = env39317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39316 == env39317) = true)

theorem identity39317 : scanCanonicalize (H12AffineFastState.compose env39317 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39317 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env39318 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79131,10280,1025,8541,77899,4194304,17,2,8193,65,4204924,5393,77835,76158,75102,4194305,257,32,5456,513]

theorem envBound39318 : H12AffineFastState.Bounded env39318 := by
  intro p hp
  have h : env39318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39317_39318 : H12AffineEnvironment.transform 14 8540 env39317 = env39318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39317 == env39318) = true)

theorem identity39318 : scanCanonicalize (H12AffineFastState.compose env39318 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39318 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39319 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,65536,70727,2420,1025,1,69911,4194304,17,2,349,65,4196384,5393,69975,67618,66562,4194305,257,32,5456,513]

theorem envBound39319 : H12AffineFastState.Bounded env39319 := by
  intro p hp
  have h : env39319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39318_39319 : H12AffineEnvironment.transform 12 348 env39318 = env39319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39318 == env39319) = true)

theorem identity39319 : scanCanonicalize (H12AffineFastState.compose env39319 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound39319 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env39320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5393,2420,1025,1,4161,4194304,17,2,349,65,4196384,5393,4097,2420,1364,4194305,257,32,5456,513]

theorem envBound39320 : H12AffineFastState.Bounded env39320 := by
  intro p hp
  have h : env39320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39319_39320 : H12AffineEnvironment.transform 15 342 env39319 = env39320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env39319 == env39320) = true)

theorem identity39320 : scanCanonicalize (H12AffineFastState.compose env39320 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound39320 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5393,2420,1025,1,4161,113,17,2,349,65,2129,5393,4097,2420,1364,112,257,32,5456,513]

theorem envBound39321 : H12AffineFastState.Bounded env39321 := by
  intro p hp
  have h : env39321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39320_39321 : H12AffineEnvironment.transform 21 113 env39320 = env39321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env39320 == env39321) = true)

theorem identity39321 : scanCanonicalize (H12AffineFastState.compose env39321 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39321 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39322 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1025,1,4113,33,17,2,269,17,2049,5393,4097,2340,1284,32,257,32,5376,513]

theorem envBound39322 : H12AffineFastState.Bounded env39322 := by
  intro p hp
  have h : env39322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39321_39322 : H12AffineEnvironment.transform 5 16 env39321 = env39322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39321 == env39322) = true)

theorem identity39322 : scanCanonicalize (H12AffineFastState.compose env39322 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound39322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39323 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,268,1280,0,262,1296,2340,1025,1,16,33,17,2,269,17,2049,1296,0,2340,1284,32,257,32,1281,513]

theorem envBound39323 : H12AffineFastState.Bounded env39323 := by
  intro p hp
  have h : env39323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39322_39323 : H12AffineEnvironment.transform 11 1 env39322 = env39323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39322 == env39323) = true)

theorem identity39323 : scanCanonicalize (H12AffineFastState.compose env39323 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound39323 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39324 : List Nat := [2,4,8,16,32,16,9,256,512,1024,318,1,268,1280,0,262,1296,26,1025,1,16,33,17,2,269,17,319,1296,0,26,1284,32,257,32,1281,513]

theorem envBound39324 : H12AffineFastState.Bounded env39324 := by
  intro p hp
  have h : env39324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39323_39324 : H12AffineEnvironment.transform 10 318 env39323 = env39324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env39323 == env39324) = true)

theorem identity39324 : scanCanonicalize (H12AffineFastState.compose env39324 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound39324 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39325 : List Nat := [2,4,8,16,32,16,9,256,512,20,318,1,268,276,0,262,260,26,21,1,16,33,17,2,269,17,319,260,0,26,272,32,257,32,277,513]

theorem envBound39325 : H12AffineFastState.Bounded env39325 := by
  intro p hp
  have h : env39325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39324_39325 : H12AffineEnvironment.transform 9 20 env39324 = env39325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env39324 == env39325) = true)

theorem identity39325 : scanCanonicalize (H12AffineFastState.compose env39325 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound39325 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39326 : List Nat := [2,4,8,16,32,16,9,53,512,20,11,1,57,33,0,51,49,26,21,1,16,33,17,2,56,17,10,49,0,26,37,32,52,32,32,513]

theorem envBound39326 : H12AffineFastState.Bounded env39326 := by
  intro p hp
  have h : env39326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39325_39326 : H12AffineEnvironment.transform 7 53 env39325 = env39326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env39325 == env39326) = true)

theorem identity39326 : scanCanonicalize (H12AffineFastState.compose env39326 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound39326 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39327 : List Nat := [2,4,8,16,26,16,9,15,512,20,11,1,3,27,0,9,11,26,21,1,16,27,17,2,2,17,10,11,0,26,31,26,14,26,26,513]

theorem envBound39327 : H12AffineFastState.Bounded env39327 := by
  intro p hp
  have h : env39327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39326_39327 : H12AffineEnvironment.transform 4 26 env39326 = env39327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env39326 == env39327) = true)

theorem identity39327 : scanCanonicalize (H12AffineFastState.compose env39327 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39327 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39328 : List Nat := [2,4,3,16,17,16,2,4,512,20,0,1,3,16,0,2,0,17,21,1,16,16,17,2,2,17,1,0,0,17,20,17,5,17,17,513]

theorem envBound39328 : H12AffineFastState.Bounded env39328 := by
  intro p hp
  have h : env39328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39327_39328 : H12AffineEnvironment.transform 2 3 env39327 = env39328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39327 == env39328) = true)

theorem identity39328 : scanCanonicalize (H12AffineFastState.compose env39328 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39328 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39329 : List Nat := [1,4,0,16,17,16,1,4,512,20,0,1,0,16,0,1,0,17,21,1,16,16,17,1,1,17,1,0,0,17,20,17,5,17,17,513]

theorem envBound39329 : H12AffineFastState.Bounded env39329 := by
  intro p hp
  have h : env39329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39328_39329 : H12AffineEnvironment.transform 0 1 env39328 = env39329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39328 == env39329) = true)

theorem identity39329 : scanCanonicalize (H12AffineFastState.compose env39329 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39329 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env39330 : List Nat := [1,4,0,1,0,1,1,4,512,5,0,1,0,1,0,1,0,0,4,1,1,1,0,1,1,0,1,0,0,0,5,0,5,0,0,513]

theorem envBound39330 : H12AffineFastState.Bounded env39330 := by
  intro p hp
  have h : env39330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39329_39330 : H12AffineEnvironment.transform 3 1 env39329 = env39330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39329 == env39330) = true)

theorem identity39330 : scanCanonicalize (H12AffineFastState.compose env39330 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39331 : List Nat := [1,1,0,1,0,1,1,1,512,0,0,1,0,1,0,1,0,0,1,1,1,1,0,1,1,0,1,0,0,0,0,0,0,0,0,513]

theorem envBound39331 : H12AffineFastState.Bounded env39331 := by
  intro p hp
  have h : env39331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39330_39331 : H12AffineEnvironment.transform 1 1 env39330 = env39331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39330 == env39331) = true)

def env39332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound39332 : H12AffineFastState.Bounded env39332 := by
  intro p hp
  have h : env39332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38907_39332 : H12AffineEnvironment.transform 26 30393345 env38907 = env39332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env38907 == env39332) = true)

def env39333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound39333 : H12AffineFastState.Bounded env39333 := by
  intro p hp
  have h : env39333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39332_39333 : H12AffineEnvironment.transform 18 1024 env39332 = env39333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env39332 == env39333) = true)

theorem identity39333 : scanCanonicalize (H12AffineFastState.compose env39333 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898593) := by decide +kernel

theorem selectedBound39333 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898593,8328,65,4196384,10898605,10507600,8830977,412720,15117792,256,2493581,2551081,486375]

theorem envBound39334 : H12AffineFastState.Bounded env39334 := by
  intro p hp
  have h : env39334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39333_39334 : H12AffineEnvironment.transform 23 8898593 env39333 = env39334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898593 env39333 == env39334) = true)

def env39335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,8388608,8898593,8328,65,4196384,8393985,8785148,8830977,412720,12645452,256,21793,46213,486375]

theorem envBound39335 : H12AffineFastState.Bounded env39335 := by
  intro p hp
  have h : env39335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39334_39335 : H12AffineEnvironment.transform 20 416172 env39334 = env39335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416172 env39334 == env39335) = true)

def env39336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441640,95497,8328,65,4196384,436265,45524,32041,412720,4606308,256,21793,46213,486375]

theorem envBound39336 : H12AffineFastState.Bounded env39336 := by
  intro p hp
  have h : env39336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39335_39336 : H12AffineEnvironment.transform 22 441640 env39335 = env39336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env39335 == env39336) = true)

def env39337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441640,95497,8328,65,270496,436265,45524,32041,412720,156132,256,21793,46213,486375]

theorem envBound39337 : H12AffineFastState.Bounded env39337 := by
  intro p hp
  have h : env39337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39336_39337 : H12AffineEnvironment.transform 21 272512 env39336 = env39337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39336 == env39337) = true)

theorem identity39337 : scanCanonicalize (H12AffineFastState.compose env39337 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound39337 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,77898,213350,120014,95497,8328,65,215366,115151,45524,32041,75222,156132,256,21793,46213,513]

theorem envBound39338 : H12AffineFastState.Bounded env39338 := by
  intro p hp
  have h : env39338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39337_39338 : H12AffineEnvironment.transform 17 223718 env39337 = env39338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env39337 == env39338) = true)

def env39339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77898,213350,119878,95497,8192,65,215366,115015,45404,32041,75102,156012,256,21793,46093,513]

theorem envBound39339 : H12AffineFastState.Bounded env39339 := by
  intro p hp
  have h : env39339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39338_39339 : H12AffineEnvironment.transform 6 8 env39338 = env39339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39338 == env39339) = true)

theorem identity39339 : scanCanonicalize (H12AffineFastState.compose env39339 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound39339 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,2421,1024,32769,77898,8573,119878,95497,8192,65,10589,115015,45404,32041,75102,65911,256,21793,46093,513]

theorem envBound39340 : H12AffineFastState.Bounded env39340 := by
  intro p hp
  have h : env39340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39339_39340 : H12AffineEnvironment.transform 16 90139 env39339 = env39340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env39339 == env39340) = true)

theorem identity39340 : scanCanonicalize (H12AffineFastState.compose env39340 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound39340 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env39341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,90139,2421,1024,29709,77898,8573,73802,95497,8192,65,10589,79179,17744,32041,75102,65911,256,21793,16385,513]

theorem envBound39341 : H12AffineFastState.Bounded env39341 := by
  intro p hp
  have h : env39341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39340_39341 : H12AffineEnvironment.transform 14 29708 env39340 = env39341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env39340 == env39341) = true)

theorem identity39341 : scanCanonicalize (H12AffineFastState.compose env39341 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound39341 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,29963,5392,2421,1024,29709,17729,8573,21825,2,8192,65,10589,16448,17744,32041,20565,29820,256,21793,16385,513]

theorem envBound39342 : H12AffineFastState.Bounded env39342 := by
  intro p hp
  have h : env39342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39341_39342 : H12AffineEnvironment.transform 15 29963 env39341 = env39342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env39341 == env39342) = true)

theorem identity39342 : scanCanonicalize (H12AffineFastState.compose env39342 (packedSelected [2,3,5,6,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound39342 : packedSelected [2,3,5,6,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env39343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21621,21874,5392,2421,1024,21620,17729,260,21825,2,121,65,2340,16448,17744,23888,20565,21509,256,21793,16385,513]

theorem envBound39343 : H12AffineFastState.Bounded env39343 := by
  intro p hp
  have h : env39343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39342_39343 : H12AffineEnvironment.transform 12 121 env39342 = env39343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env39342 == env39343) = true)

theorem identity39343 : scanCanonicalize (H12AffineFastState.compose env39343 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39343 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env39344 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,16384,21540,21795,5392,2340,1024,21541,17680,260,21776,2,40,16,2340,16401,17665,23809,20484,21509,256,21793,16385,513]

theorem envBound39344 : H12AffineFastState.Bounded env39344 := by
  intro p hp
  have h : env39344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39343_39344 : H12AffineEnvironment.transform 5 17 env39343 = env39344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39343 == env39344) = true)

theorem identity39344 : scanCanonicalize (H12AffineFastState.compose env39344 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound39344 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env39345 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,5156,0,263,5392,2340,1024,1,4404,260,308,2,40,16,2340,5173,4389,2341,1056,33,256,261,5157,513]

theorem envBound39345 : H12AffineFastState.Bounded env39345 := by
  intro p hp
  have h : env39345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39344_39345 : H12AffineEnvironment.transform 13 5156 env39344 = env39345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env39344 == env39345) = true)

theorem identity39345 : scanCanonicalize (H12AffineFastState.compose env39345 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound39345 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env39346 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3108,40,2048,0,263,2356,2340,1024,1,3344,260,308,2,40,16,2340,2065,3329,2341,1056,33,256,261,2049,513]

theorem envBound39346 : H12AffineFastState.Bounded env39346 := by
  intro p hp
  have h : env39346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39345_39346 : H12AffineEnvironment.transform 11 3108 env39345 = env39346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env39345 == env39346) = true)

theorem identity39346 : scanCanonicalize (H12AffineFastState.compose env39346 (packedSelected [1,3,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39346 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env39347 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,40,2048,0,34,2065,2049,1024,1,3125,33,17,2,40,16,2049,2065,3108,2048,1056,33,37,32,2049,513]

theorem envBound39347 : H12AffineFastState.Bounded env39347 := by
  intro p hp
  have h : env39347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39346_39347 : H12AffineEnvironment.transform 7 37 env39346 = env39347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39346 == env39347) = true)

theorem identity39347 : scanCanonicalize (H12AffineFastState.compose env39347 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39348 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2065,40,2048,0,34,2065,2049,53,1,2048,33,17,2,40,16,2049,2065,2065,2048,21,33,37,32,2049,513]

theorem envBound39348 : H12AffineFastState.Bounded env39348 := by
  intro p hp
  have h : env39348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39347_39348 : H12AffineEnvironment.transform 9 53 env39347 = env39348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39347 == env39348) = true)

theorem identity39348 : scanCanonicalize (H12AffineFastState.compose env39348 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound39348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39349 : List Nat := [2,4,8,16,32,17,8,37,512,53,17,0,40,17,0,34,0,16,53,1,17,33,17,2,40,16,16,0,0,17,21,33,37,32,16,513]

theorem envBound39349 : H12AffineFastState.Bounded env39349 := by
  intro p hp
  have h : env39349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39348_39349 : H12AffineEnvironment.transform 10 17 env39348 = env39349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env39348 == env39349) = true)

theorem identity39349 : scanCanonicalize (H12AffineFastState.compose env39349 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound39349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39350 : List Nat := [2,4,8,16,32,17,8,37,26,53,17,0,40,17,0,34,0,16,53,1,17,33,17,2,40,16,16,0,0,17,21,33,37,32,16,27]

theorem envBound39350 : H12AffineFastState.Bounded env39350 := by
  intro p hp
  have h : env39350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39349_39350 : H12AffineEnvironment.transform 8 26 env39349 = env39350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env39349 == env39350) = true)

def env39351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213350,119879,95497,8193,65,215366,115014,45405,32041,75103,156013,256,21793,46092,513]

theorem envBound39351 : H12AffineFastState.Bounded env39351 := by
  intro p hp
  have h : env39351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39338_39351 : H12AffineEnvironment.transform 6 9 env39338 = env39351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39338 == env39351) = true)

theorem identity39351 : scanCanonicalize (H12AffineFastState.compose env39351 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound39351 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env39352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,77898,33,119879,95497,8193,65,2049,115014,45405,32041,75103,73770,256,21793,46092,513]

theorem envBound39352 : H12AffineFastState.Bounded env39352 := by
  intro p hp
  have h : env39352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39351_39352 : H12AffineEnvironment.transform 16 82247 env39351 = env39352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env39351 == env39352) = true)

theorem identity39352 : scanCanonicalize (H12AffineFastState.compose env39352 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39352 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env39353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,82247,10280,1024,1,77898,33,87111,95497,8193,65,2049,82246,12637,32041,75103,73770,256,21793,13324,513]

theorem envBound39353 : H12AffineFastState.Bounded env39353 := by
  intro p hp
  have h : env39353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39352_39353 : H12AffineEnvironment.transform 14 0 env39352 = env39353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39352 == env39353) = true)

theorem identity39353 : scanCanonicalize (H12AffineFastState.compose env39353 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39353 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,65536,82247,2421,1024,1,69911,33,87111,87124,348,65,2049,82246,4096,23668,66562,65911,256,21793,5457,513]

theorem envBound39354 : H12AffineFastState.Bounded env39354 := by
  intro p hp
  have h : env39354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39353_39354 : H12AffineEnvironment.transform 12 349 env39353 = env39354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39353 == env39354) = true)

theorem identity39354 : scanCanonicalize (H12AffineFastState.compose env39354 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound39354 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,21510,5441,2421,1024,1,17681,33,65,82,348,65,2049,5440,4096,23668,20484,21873,256,21793,5457,513]

theorem envBound39355 : H12AffineFastState.Bounded env39355 := by
  intro p hp
  have h : env39355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39354_39355 : H12AffineEnvironment.transform 15 21510 env39354 = env39355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env39354 == env39355) = true)

theorem identity39355 : scanCanonicalize (H12AffineFastState.compose env39355 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39355 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,262,5441,2421,1024,1,4113,33,65,82,348,65,2049,5440,4096,2420,1284,113,256,33,5457,513]

theorem envBound39356 : H12AffineFastState.Bounded env39356 := by
  intro p hp
  have h : env39356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39355_39356 : H12AffineEnvironment.transform 13 5376 env39355 = env39356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39355 == env39356) = true)

theorem identity39356 : scanCanonicalize (H12AffineFastState.compose env39356 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39356 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39357 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1024,1,4113,33,16,3,269,16,2049,5393,4096,2341,1284,32,256,33,5376,513]

theorem envBound39357 : H12AffineFastState.Bounded env39357 := by
  intro p hp
  have h : env39357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39356_39357 : H12AffineEnvironment.transform 5 17 env39356 = env39357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39356 == env39357) = true)

theorem identity39357 : scanCanonicalize (H12AffineFastState.compose env39357 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39357 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39358 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4404,0,262,4388,2340,52,1,4113,33,16,3,269,16,2049,4389,4096,2341,304,32,256,33,4404,513]

theorem envBound39358 : H12AffineFastState.Bounded env39358 := by
  intro p hp
  have h : env39358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39357_39358 : H12AffineEnvironment.transform 9 52 env39357 = env39358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39357 == env39358) = true)

theorem identity39358 : scanCanonicalize (H12AffineFastState.compose env39358 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound39358 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39359 : List Nat := [2,4,8,16,32,17,9,256,512,52,522,4096,268,4404,0,262,4388,814,52,1,4113,33,16,3,269,16,523,4389,4096,815,304,32,256,33,4404,513]

theorem envBound39359 : H12AffineFastState.Bounded env39359 := by
  intro p hp
  have h : env39359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39358_39359 : H12AffineEnvironment.transform 10 522 env39358 = env39359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env39358 == env39359) = true)

theorem identity39359 : scanCanonicalize (H12AffineFastState.compose env39359 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 799) := by decide +kernel

theorem selectedBound39359 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39360 : List Nat := [2,4,8,16,32,17,9,256,512,52,522,799,268,555,0,262,571,814,52,1,782,33,16,3,269,16,523,570,799,815,304,32,256,33,555,513]

theorem envBound39360 : H12AffineFastState.Bounded env39360 := by
  intro p hp
  have h : env39360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39359_39360 : H12AffineEnvironment.transform 11 799 env39359 = env39360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 799 env39359 == env39360) = true)

def env39361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441640,95497,8328,65,270497,436265,45524,32041,412720,156133,256,21793,46213,486375]

theorem envBound39361 : H12AffineFastState.Bounded env39361 := by
  intro p hp
  have h : env39361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39336_39361 : H12AffineEnvironment.transform 21 272513 env39336 = env39361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39336 == env39361) = true)

theorem identity39361 : scanCanonicalize (H12AffineFastState.compose env39361 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound39361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,416172,272513,441640,41431,8328,65,270497,436265,45524,32041,412720,156133,256,21793,46213,442169]

theorem envBound39362 : H12AffineFastState.Bounded env39362 := by
  intro p hp
  have h : env39362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39361_39362 : H12AffineEnvironment.transform 15 54494 env39361 = env39362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env39361 == env39362) = true)

def env39363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416036,272393,441640,41311,8192,65,270377,436265,45404,32041,412720,156013,256,21793,46093,442169]

theorem envBound39363 : H12AffineFastState.Bounded env39363 := by
  intro p hp
  have h : env39363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39362_39363 : H12AffineEnvironment.transform 6 8 env39362 = env39363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39362 == env39363) = true)

theorem identity39363 : scanCanonicalize (H12AffineFastState.compose env39363 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 149521) := by decide +kernel

theorem selectedBound39363 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env39364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149521,1024,32769,4405,155672,62777,41311,8192,65,157752,57400,45404,32041,1057,156013,256,21793,46093,63272]

theorem envBound39364 : H12AffineFastState.Bounded env39364 := by
  intro p hp
  have h : env39364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39363_39364 : H12AffineEnvironment.transform 17 149521 env39363 = env39364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149521 env39363 == env39364) = true)

theorem identity39364 : scanCanonicalize (H12AffineFastState.compose env39364 (packedSelected [7,17,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound39364 : packedSelected [7,17,20,27,35] rootPS < 2^1333 := by decide +kernel

def env39365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,31836,1024,32769,4405,21589,62777,41311,8192,65,23669,57400,45404,32041,1057,21792,256,21793,46093,63272]

theorem envBound39365 : H12AffineFastState.Bounded env39365 := by
  intro p hp
  have h : env39365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39364_39365 : H12AffineEnvironment.transform 16 13389 env39364 = env39365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env39364 == env39365) = true)

theorem identity39365 : scanCanonicalize (H12AffineFastState.compose env39365 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39365 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env39366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,13389,10588,1024,32769,4405,341,41017,41311,8192,65,2421,46392,45404,10281,1057,32,256,33,46093,41512]

theorem envBound39366 : H12AffineFastState.Bounded env39366 := by
  intro p hp
  have h : env39366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39365_39366 : H12AffineEnvironment.transform 13 5376 env39365 = env39366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39365 == env39366) = true)

theorem identity39366 : scanCanonicalize (H12AffineFastState.compose env39366 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound39366 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8233,8575,13389,10588,1024,8232,4405,341,16,374,8192,65,2421,5393,4469,10281,1057,32,256,33,5156,513]

theorem envBound39367 : H12AffineFastState.Bounded env39367 := by
  intro p hp
  have h : env39367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39366_39367 : H12AffineEnvironment.transform 14 8233 env39366 = env39367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env39366 == env39367) = true)

theorem identity39367 : scanCanonicalize (H12AffineFastState.compose env39367 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound39367 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,1,343,5221,2420,1024,0,4405,341,16,374,40,65,2421,5393,4469,2049,1057,32,256,33,5156,513]

theorem envBound39368 : H12AffineFastState.Bounded env39368 := by
  intro p hp
  have h : env39368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39367_39368 : H12AffineEnvironment.transform 12 40 env39367 = env39368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env39367 == env39368) = true)

theorem identity39368 : scanCanonicalize (H12AffineFastState.compose env39368 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound39368 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env39369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2404,40,3172,1,343,3329,2420,1024,0,2129,341,16,374,40,65,2421,3189,2065,2049,1057,32,256,33,3392,513]

theorem envBound39369 : H12AffineFastState.Bounded env39369 := by
  intro p hp
  have h : env39369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39368_39369 : H12AffineEnvironment.transform 11 2404 env39368 = env39369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env39368 == env39369) = true)

theorem identity39369 : scanCanonicalize (H12AffineFastState.compose env39369 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 347) := by decide +kernel

theorem selectedBound39369 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env39370 : List Nat := [2,4,8,16,32,64,8,256,512,347,2048,2404,40,2367,1,343,2138,2420,347,0,2129,341,16,374,40,65,2421,2350,2065,2049,378,32,256,33,2075,513]

theorem envBound39370 : H12AffineFastState.Bounded env39370 := by
  intro p hp
  have h : env39370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39369_39370 : H12AffineEnvironment.transform 9 347 env39369 = env39370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 347 env39369 == env39370) = true)

theorem identity39370 : scanCanonicalize (H12AffineFastState.compose env39370 (packedSelected [2,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound39370 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env39371 : List Nat := [2,4,8,16,32,10,8,256,512,273,2048,2350,40,2367,1,285,2064,2366,273,0,2075,287,16,316,40,11,2367,2350,2065,2049,304,32,256,33,2075,513]

theorem envBound39371 : H12AffineFastState.Bounded env39371 := by
  intro p hp
  have h : env39371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39370_39371 : H12AffineEnvironment.transform 5 10 env39370 = env39371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env39370 == env39371) = true)

theorem identity39371 : scanCanonicalize (H12AffineFastState.compose env39371 (packedSelected [5,6] rootPS)) = affineNative (2^(10+1) ^^^ 807) := by decide +kernel

theorem selectedBound39371 : packedSelected [5,6] rootPS < 2^1333 := by decide +kernel

def env39372 : List Nat := [2,4,8,16,32,10,8,256,512,273,807,521,40,536,1,285,823,537,273,0,828,287,16,316,40,11,536,521,822,806,304,32,256,33,828,513]

theorem envBound39372 : H12AffineFastState.Bounded env39372 := by
  intro p hp
  have h : env39372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39371_39372 : H12AffineEnvironment.transform 10 807 env39371 = env39372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 807 env39371 == env39372) = true)

theorem identity39372 : scanCanonicalize (H12AffineFastState.compose env39372 (packedSelected [2,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39372 : packedSelected [2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39373 : List Nat := [2,4,8,12,32,10,8,256,512,269,807,521,40,516,1,257,811,517,269,0,800,259,12,288,40,11,516,521,810,806,300,32,256,33,800,513]

theorem envBound39373 : H12AffineFastState.Bounded env39373 := by
  intro p hp
  have h : env39373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39372_39373 : H12AffineEnvironment.transform 3 12 env39372 = env39373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39372 == env39373) = true)

theorem identity39373 : scanCanonicalize (H12AffineFastState.compose env39373 (packedSelected [4,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39373 : packedSelected [4,8] rootPS < 2^1333 := by decide +kernel

def env39374 : List Nat := [2,2,8,10,32,10,8,256,512,267,801,521,40,514,1,257,811,515,267,0,800,259,10,288,40,11,514,521,810,800,298,32,256,33,800,513]

theorem envBound39374 : H12AffineFastState.Bounded env39374 := by
  intro p hp
  have h : env39374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39373_39374 : H12AffineEnvironment.transform 1 2 env39373 = env39374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39373 == env39374) = true)

theorem identity39374 : scanCanonicalize (H12AffineFastState.compose env39374 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 41) := by decide +kernel

theorem selectedBound39374 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39375 : List Nat := [2,2,8,10,32,10,8,256,41,267,264,32,40,43,1,257,258,42,267,0,265,259,10,288,40,11,43,32,259,265,298,32,256,33,265,40]

theorem envBound39375 : H12AffineFastState.Bounded env39375 := by
  intro p hp
  have h : env39375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39374_39375 : H12AffineEnvironment.transform 8 41 env39374 = env39375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 41 env39374 == env39375) = true)

theorem identity39375 : scanCanonicalize (H12AffineFastState.compose env39375 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound39375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39376 : List Nat := [2,2,8,10,32,10,8,3,41,8,11,32,40,43,1,2,1,42,8,0,10,0,10,35,40,11,43,32,0,10,41,32,3,33,10,40]

theorem envBound39376 : H12AffineFastState.Bounded env39376 := by
  intro p hp
  have h : env39376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39375_39376 : H12AffineEnvironment.transform 7 3 env39375 = env39376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env39375 == env39376) = true)

theorem identity39376 : scanCanonicalize (H12AffineFastState.compose env39376 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39376 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39377 : List Nat := [2,2,8,10,1,10,8,3,8,8,11,1,9,10,1,2,1,11,8,0,10,0,10,2,9,11,10,1,0,10,8,1,3,0,10,9]

theorem envBound39377 : H12AffineFastState.Bounded env39377 := by
  intro p hp
  have h : env39377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39376_39377 : H12AffineEnvironment.transform 4 1 env39376 = env39377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39376 == env39377) = true)

theorem identity39377 : scanCanonicalize (H12AffineFastState.compose env39377 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39378 : List Nat := [2,2,3,1,1,1,3,3,3,3,0,1,2,1,1,2,1,0,3,0,1,0,1,2,2,0,1,1,0,1,3,1,3,0,1,2]

theorem envBound39378 : H12AffineFastState.Bounded env39378 := by
  intro p hp
  have h : env39378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39377_39378 : H12AffineEnvironment.transform 2 3 env39377 = env39378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39377 == env39378) = true)

def env39379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416037,272392,441640,41310,8193,65,270376,436265,45405,32041,412720,156012,256,21793,46092,442169]

theorem envBound39379 : H12AffineFastState.Bounded env39379 := by
  intro p hp
  have h : env39379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39362_39379 : H12AffineEnvironment.transform 6 9 env39362 = env39379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39362 == env39379) = true)

theorem identity39379 : scanCanonicalize (H12AffineFastState.compose env39379 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound39379 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env39380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1024,32769,140300,21793,180225,41310,8193,65,23809,185600,45405,32041,143641,156012,256,21793,46092,180752]

theorem envBound39380 : H12AffineFastState.Bounded env39380 := by
  intro p hp
  have h : env39380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39379_39380 : H12AffineEnvironment.transform 17 32041 env39379 = env39380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env39379 == env39380) = true)

theorem identity39380 : scanCanonicalize (H12AffineFastState.compose env39380 (packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39380 : packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env39381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,131072,32041,1024,8540,140300,21793,155996,3,8193,65,23809,160861,4096,32041,143641,156012,256,21793,5457,156493]

theorem envBound39381 : H12AffineFastState.Bounded env39381 := by
  intro p hp
  have h : env39381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39380_39381 : H12AffineEnvironment.transform 14 8541 env39380 = env39381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39380 == env39381) = true)

theorem identity39381 : scanCanonicalize (H12AffineFastState.compose env39381 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39381 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env39382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21590,131072,23669,1024,0,132432,21793,147456,3,349,65,23809,152833,4096,23669,135237,147504,256,21793,5457,147985]

theorem envBound39382 : H12AffineFastState.Bounded env39382 := by
  intro p hp
  have h : env39382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39381_39382 : H12AffineEnvironment.transform 12 348 env39381 = env39382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39381 == env39382) = true)

theorem identity39382 : scanCanonicalize (H12AffineFastState.compose env39382 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39382 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21590,5393,23669,1024,0,4161,21793,21777,3,349,65,23809,16400,4096,23669,1364,21793,256,21793,5457,22272]

theorem envBound39383 : H12AffineFastState.Bounded env39383 := by
  intro p hp
  have h : env39383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39382_39383 : H12AffineEnvironment.transform 16 5393 env39382 = env39383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39382 == env39383) = true)

theorem identity39383 : scanCanonicalize (H12AffineFastState.compose env39383 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39383 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39384 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,1,21590,5220,23669,1024,0,4161,21588,21604,3,40,65,23668,16400,4096,23669,1057,21588,117,21588,5156,22133]

theorem envBound39384 : H12AffineFastState.Bounded env39384 := by
  intro p hp
  have h : env39384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39383_39384 : H12AffineEnvironment.transform 7 117 env39383 = env39384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39383 == env39384) = true)

theorem identity39384 : scanCanonicalize (H12AffineFastState.compose env39384 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39384 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env39385 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,4096,41,16384,1,21590,5220,21620,1024,0,4161,21588,21604,3,40,65,21621,16400,4096,21620,1057,21588,117,21588,5156,22133]

theorem envBound39385 : H12AffineFastState.Bounded env39385 := by
  intro p hp
  have h : env39385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39384_39385 : H12AffineEnvironment.transform 10 1 env39384 = env39385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39384 == env39385) = true)

theorem identity39385 : scanCanonicalize (H12AffineFastState.compose env39385 (packedSelected [0,2,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39385 : packedSelected [0,2,6,7,10] rootPS < 2^1333 := by decide +kernel

def env39386 : List Nat := [2,4,8,16,32,64,9,117,512,52,1,4096,41,16384,1,20578,4176,20544,52,0,4161,20576,20560,3,40,65,20545,16400,4096,20544,21,20576,117,20576,4112,21057]

theorem envBound39386 : H12AffineFastState.Bounded env39386 := by
  intro p hp
  have h : env39386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39385_39386 : H12AffineEnvironment.transform 9 52 env39385 = env39386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39385 == env39386) = true)

theorem identity39386 : scanCanonicalize (H12AffineFastState.compose env39386 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound39386 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39387 : List Nat := [2,4,8,16,32,64,9,117,512,52,1,16,41,16384,1,16498,64,16464,52,0,81,16496,16448,3,40,65,16465,16400,16,16464,21,16496,117,16496,0,16977]

theorem envBound39387 : H12AffineFastState.Bounded env39387 := by
  intro p hp
  have h : env39387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39386_39387 : H12AffineEnvironment.transform 11 16 env39386 = env39387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env39386 == env39387) = true)

theorem identity39387 : scanCanonicalize (H12AffineFastState.compose env39387 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound39387 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39388 : List Nat := [2,4,8,16,32,64,9,117,512,52,1,16,41,1,1,115,64,81,52,0,81,113,65,3,40,65,80,17,16,81,21,113,117,113,0,592]

theorem envBound39388 : H12AffineFastState.Bounded env39388 := by
  intro p hp
  have h : env39388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39387_39388 : H12AffineEnvironment.transform 13 1 env39387 = env39388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env39387 == env39388) = true)

def env39389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441641,95496,8328,65,4196384,436264,45525,32040,412720,4606309,256,21793,46213,486375]

theorem envBound39389 : H12AffineFastState.Bounded env39389 := by
  intro p hp
  have h : env39389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39335_39389 : H12AffineEnvironment.transform 22 441641 env39335 = env39389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env39335 == env39389) = true)

def env39390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441641,95496,8328,65,270496,436264,45525,32040,412720,156133,256,21793,46213,486375]

theorem envBound39390 : H12AffineFastState.Bounded env39390 := by
  intro p hp
  have h : env39390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39389_39390 : H12AffineEnvironment.transform 21 272512 env39389 = env39390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39389 == env39390) = true)

theorem identity39390 : scanCanonicalize (H12AffineFastState.compose env39390 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound39390 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,115870,243122,73755,95496,8328,65,245138,79130,45525,32040,119042,156133,256,21793,46213,63189]

theorem envBound39391 : H12AffineFastState.Bounded env39391 := by
  intro p hp
  have h : env39391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39390_39391 : H12AffineEnvironment.transform 17 236850 env39390 = env39391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env39390 == env39391) = true)

def env39392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,67754,1024,32769,115870,73770,73755,95496,8328,65,75786,79130,45525,32040,119042,62589,256,21793,46213,63189]

theorem envBound39392 : H12AffineFastState.Bounded env39392 := by
  intro p hp
  have h : env39392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39391_39392 : H12AffineEnvironment.transform 16 38296 env39391 = env39392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env39391 == env39392) = true)

theorem identity39392 : scanCanonicalize (H12AffineFastState.compose env39392 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound39392 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env39393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,38296,56572,1024,32769,4296,62588,62541,41310,8328,65,64604,57676,45525,32040,1364,62589,256,21793,46213,63189]

theorem envBound39393 : H12AffineFastState.Bounded env39393 := by
  intro p hp
  have h : env39393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39392_39393 : H12AffineEnvironment.transform 15 54358 env39392 = env39393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env39392 == env39393) = true)

theorem identity39393 : scanCanonicalize (H12AffineFastState.compose env39393 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound39393 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env39394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,343,16537,2557,1024,21760,4296,8573,8524,29791,8328,65,10589,13389,25812,32040,1364,8572,256,21793,24964,9172]

theorem envBound39394 : H12AffineFastState.Bounded env39394 := by
  intro p hp
  have h : env39394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39393_39394 : H12AffineEnvironment.transform 14 21761 env39393 = env39394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env39393 == env39394) = true)

theorem identity39394 : scanCanonicalize (H12AffineFastState.compose env39394 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,18,19,35] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound39394 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,18,19,35] rootPS < 2^1333 := by decide +kernel

def env39395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8661,343,13389,2557,1024,8660,4296,8573,8524,139,8328,65,10589,13389,4096,2556,1364,8572,256,8693,5456,9172]

theorem envBound39395 : H12AffineFastState.Bounded env39395 := by
  intro p hp
  have h : env39395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39394_39395 : H12AffineEnvironment.transform 13 13524 env39394 = env39395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env39394 == env39395) = true)

theorem identity39395 : scanCanonicalize (H12AffineFastState.compose env39395 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,343,13389,2420,1024,8541,4161,8573,8524,2,8193,65,10589,13389,4096,2421,1364,8572,256,8572,5456,9053]

theorem envBound39396 : H12AffineFastState.Bounded env39396 := by
  intro p hp
  have h : env39396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39395_39396 : H12AffineEnvironment.transform 6 9 env39395 = env39396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39395 == env39396) = true)

theorem identity39396 : scanCanonicalize (H12AffineFastState.compose env39396 (packedSelected [1,2,5,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound39396 : packedSelected [1,2,5,10,11] rootPS < 2^1333 := by decide +kernel

def env39397 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,8192,12604,8540,343,12588,2420,353,8541,4161,8573,8524,2,8193,65,10589,12588,4096,2421,53,8572,256,8572,4145,9053]

theorem envBound39397 : H12AffineFastState.Bounded env39397 := by
  intro p hp
  have h : env39397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39396_39397 : H12AffineEnvironment.transform 9 353 env39396 = env39397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env39396 == env39397) = true)

theorem identity39397 : scanCanonicalize (H12AffineFastState.compose env39397 (packedSelected [0,2,5,6,7,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound39397 : packedSelected [0,2,5,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env39398 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,88,4452,260,343,4468,2420,353,261,4161,293,276,2,89,65,2309,4468,4096,2421,53,292,256,292,4145,773]

theorem envBound39398 : H12AffineFastState.Bounded env39398 := by
  intro p hp
  have h : env39398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39397_39398 : H12AffineEnvironment.transform 12 88 env39397 = env39398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env39397 == env39398) = true)

theorem identity39398 : scanCanonicalize (H12AffineFastState.compose env39398 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound39398 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39399 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,2144,88,2308,260,343,2324,2420,353,261,2081,293,276,2,89,65,2309,2324,2144,2421,53,292,256,292,2129,773]

theorem envBound39399 : H12AffineFastState.Bounded env39399 := by
  intro p hp
  have h : env39399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39398_39399 : H12AffineEnvironment.transform 11 2144 env39398 = env39399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env39398 == env39399) = true)

theorem identity39399 : scanCanonicalize (H12AffineFastState.compose env39399 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound39399 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39400 : List Nat := [2,4,8,16,32,64,9,85,512,52,2048,2144,88,2129,81,2,2113,2081,52,80,2081,112,65,2,89,65,2128,2113,2144,2080,53,113,85,113,2129,592]

theorem envBound39400 : H12AffineFastState.Bounded env39400 := by
  intro p hp
  have h : env39400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39399_39400 : H12AffineEnvironment.transform 7 85 env39399 = env39400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env39399 == env39400) = true)

theorem identity39400 : scanCanonicalize (H12AffineFastState.compose env39400 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39400 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env39401 : List Nat := [2,4,8,16,32,64,9,85,512,52,0,96,88,81,81,2,65,33,52,80,33,112,65,2,89,65,80,65,96,32,53,113,85,113,81,592]

theorem envBound39401 : H12AffineFastState.Bounded env39401 := by
  intro p hp
  have h : env39401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39400_39401 : H12AffineEnvironment.transform 10 0 env39400 = env39401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39400 == env39401) = true)

theorem identity39401 : scanCanonicalize (H12AffineFastState.compose env39401 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound39401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39402 : List Nat := [2,4,8,16,32,49,9,36,512,52,0,17,41,32,32,2,48,33,52,33,33,1,48,2,40,48,33,48,17,32,53,0,36,0,32,545]

theorem envBound39402 : H12AffineFastState.Bounded env39402 := by
  intro p hp
  have h : env39402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39401_39402 : H12AffineEnvironment.transform 5 49 env39401 = env39402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env39401 == env39402) = true)

theorem identity39402 : scanCanonicalize (H12AffineFastState.compose env39402 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound39402 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env39403 : List Nat := [2,4,8,16,32,49,9,36,49,52,0,17,41,32,32,2,48,33,52,33,33,1,48,2,40,48,33,48,17,32,53,0,36,0,32,16]

theorem envBound39403 : H12AffineFastState.Bounded env39403 := by
  intro p hp
  have h : env39403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39402_39403 : H12AffineEnvironment.transform 8 49 env39402 = env39403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env39402 == env39403) = true)

theorem identity39403 : scanCanonicalize (H12AffineFastState.compose env39403 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39403 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39404 : List Nat := [2,4,8,16,0,17,9,4,17,20,0,17,9,0,0,2,16,1,20,1,1,1,16,2,8,16,1,16,17,0,21,0,4,0,0,16]

theorem envBound39404 : H12AffineFastState.Bounded env39404 := by
  intro p hp
  have h : env39404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39403_39404 : H12AffineEnvironment.transform 4 0 env39403 = env39404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39403 == env39404) = true)

theorem identity39404 : scanCanonicalize (H12AffineFastState.compose env39404 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39405 : List Nat := [2,4,8,0,0,1,9,4,1,4,0,1,9,0,0,2,0,1,4,1,1,1,0,2,8,0,1,0,1,0,5,0,4,0,0,0]

theorem envBound39405 : H12AffineFastState.Bounded env39405 := by
  intro p hp
  have h : env39405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39404_39405 : H12AffineEnvironment.transform 3 0 env39404 = env39405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39404 == env39405) = true)

theorem identity39405 : scanCanonicalize (H12AffineFastState.compose env39405 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39406 : List Nat := [2,4,3,0,0,1,2,4,1,4,0,1,2,0,0,2,0,1,4,1,1,1,0,2,3,0,1,0,1,0,5,0,4,0,0,0]

theorem envBound39406 : H12AffineFastState.Bounded env39406 := by
  intro p hp
  have h : env39406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39405_39406 : H12AffineEnvironment.transform 2 3 env39405 = env39406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39405 == env39406) = true)

def env39407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,67755,1024,32769,115870,73771,73755,95496,8328,65,75787,79130,45525,32040,119042,62588,256,21793,46213,63189]

theorem envBound39407 : H12AffineFastState.Bounded env39407 := by
  intro p hp
  have h : env39407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39391_39407 : H12AffineEnvironment.transform 16 38297 env39391 = env39407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env39391 == env39407) = true)

theorem identity39407 : scanCanonicalize (H12AffineFastState.compose env39407 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound39407 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env39408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,38297,64929,1024,32769,12692,54561,54545,32770,8328,65,56577,49168,45525,32040,9224,62588,256,21793,46213,63189]

theorem envBound39408 : H12AffineFastState.Bounded env39408 := by
  intro p hp
  have h : env39408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39407_39408 : H12AffineEnvironment.transform 15 62730 env39407 = env39408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env39407 == env39408) = true)

theorem identity39408 : scanCanonicalize (H12AffineFastState.compose env39408 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39408 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env39409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,64809,1024,32769,12572,54561,54545,32770,8192,65,56577,49168,45405,32040,9224,62588,256,21793,46093,63069]

theorem envBound39409 : H12AffineFastState.Bounded env39409 := by
  intro p hp
  have h : env39409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39408_39409 : H12AffineEnvironment.transform 6 8 env39408 = env39409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39408 == env39409) = true)

theorem identity39409 : scanCanonicalize (H12AffineFastState.compose env39409 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound39409 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,33110,38161,35189,1024,32769,12572,41341,41293,32770,8192,65,43357,46156,45405,2420,9224,32800,256,8573,46093,33281]

theorem envBound39410 : H12AffineFastState.Bounded env39410 := by
  intro p hp
  have h : env39410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39409_39410 : H12AffineEnvironment.transform 13 13404 env39409 = env39410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env39409 == env39410) = true)

theorem identity39410 : scanCanonicalize (H12AffineFastState.compose env39410 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39410 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env39411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33110,38161,35189,1024,32769,4160,32801,32785,32770,348,65,34817,38160,36865,2420,1364,32800,256,33,38225,33281]

theorem envBound39411 : H12AffineFastState.Bounded env39411 := by
  intro p hp
  have h : env39411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39410_39411 : H12AffineEnvironment.transform 12 348 env39410 = env39411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39410 == env39411) = true)

theorem identity39411 : scanCanonicalize (H12AffineFastState.compose env39411 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound39411 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env39412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,373,35,5220,2048,1024,372,4160,340,356,375,348,65,2420,5221,4468,2420,1364,341,256,33,5156,884]

theorem envBound39412 : H12AffineFastState.Bounded env39412 := by
  intro p hp
  have h : env39412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39411_39412 : H12AffineEnvironment.transform 14 373 env39411 = env39412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env39411 == env39412) = true)

theorem identity39412 : scanCanonicalize (H12AffineFastState.compose env39412 (packedSelected [0,1,3,5,6,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39412 : packedSelected [0,1,3,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env39413 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,1,35,5220,2048,1024,0,4160,32,16,3,40,65,2048,5221,4096,2048,1056,33,116,33,5156,512]

theorem envBound39413 : H12AffineFastState.Bounded env39413 := by
  intro p hp
  have h : env39413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39412_39413 : H12AffineEnvironment.transform 7 116 env39412 = env39413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39412 == env39413) = true)

theorem identity39413 : scanCanonicalize (H12AffineFastState.compose env39413 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound39413 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39414 : List Nat := [2,4,8,16,32,64,8,116,512,1024,122,4096,40,5236,1,35,5220,122,1024,0,4160,32,16,3,40,65,122,5221,4096,122,1056,33,116,33,5156,512]

theorem envBound39414 : H12AffineFastState.Bounded env39414 := by
  intro p hp
  have h : env39414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39413_39414 : H12AffineEnvironment.transform 10 122 env39413 = env39414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env39413 == env39414) = true)

theorem identity39414 : scanCanonicalize (H12AffineFastState.compose env39414 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39414 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39415 : List Nat := [2,4,8,16,0,64,8,84,512,1024,90,4096,8,5204,1,3,5188,90,1024,0,4160,0,16,3,8,65,90,5189,4096,90,1024,1,84,1,5124,512]

theorem envBound39415 : H12AffineFastState.Bounded env39415 := by
  intro p hp
  have h : env39415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39414_39415 : H12AffineEnvironment.transform 4 0 env39414 = env39415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39414 == env39415) = true)

theorem identity39415 : scanCanonicalize (H12AffineFastState.compose env39415 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound39415 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39416 : List Nat := [2,4,8,16,0,64,8,84,512,1024,90,0,8,1108,1,3,1092,90,1024,0,64,0,16,3,8,65,90,1093,0,90,1024,1,84,1,1028,512]

theorem envBound39416 : H12AffineFastState.Bounded env39416 := by
  intro p hp
  have h : env39416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39415_39416 : H12AffineEnvironment.transform 11 0 env39415 = env39416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39415 == env39416) = true)

theorem identity39416 : scanCanonicalize (H12AffineFastState.compose env39416 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39416 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39417 : List Nat := [2,4,2,16,0,64,2,84,512,1024,80,0,2,1108,1,3,1092,80,1024,0,64,0,16,3,2,65,80,1093,0,80,1024,1,84,1,1028,512]

theorem envBound39417 : H12AffineFastState.Bounded env39417 := by
  intro p hp
  have h : env39417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39416_39417 : H12AffineEnvironment.transform 2 2 env39416 = env39417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39416 == env39417) = true)

theorem identity39417 : scanCanonicalize (H12AffineFastState.compose env39417 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39417 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39418 : List Nat := [2,4,2,16,0,64,2,84,512,4,80,0,2,80,1,3,64,80,4,0,64,0,16,3,2,65,80,65,0,80,4,1,84,1,0,512]

theorem envBound39418 : H12AffineFastState.Bounded env39418 := by
  intro p hp
  have h : env39418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39417_39418 : H12AffineEnvironment.transform 9 4 env39417 = env39418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39417 == env39418) = true)

theorem identity39418 : scanCanonicalize (H12AffineFastState.compose env39418 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39418 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39419 : List Nat := [2,1,2,16,0,64,2,81,512,1,80,0,2,80,1,3,64,80,1,0,64,0,16,3,2,65,80,65,0,80,1,1,81,1,0,512]

theorem envBound39419 : H12AffineFastState.Bounded env39419 := by
  intro p hp
  have h : env39419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39418_39419 : H12AffineEnvironment.transform 1 1 env39418 = env39419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39418 == env39419) = true)

theorem identity39419 : scanCanonicalize (H12AffineFastState.compose env39419 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound39419 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39420 : List Nat := [2,1,2,16,0,64,2,81,17,1,80,0,2,80,1,3,64,80,1,0,64,0,16,3,2,65,80,65,0,80,1,1,81,1,0,17]

theorem envBound39420 : H12AffineFastState.Bounded env39420 := by
  intro p hp
  have h : env39420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39419_39420 : H12AffineEnvironment.transform 8 17 env39419 = env39420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env39419 == env39420) = true)

theorem identity39420 : scanCanonicalize (H12AffineFastState.compose env39420 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound39420 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39421 : List Nat := [2,1,2,16,0,3,2,18,17,1,19,0,2,19,1,3,3,19,1,0,3,0,16,3,2,2,19,2,0,19,1,1,18,1,0,17]

theorem envBound39421 : H12AffineFastState.Bounded env39421 := by
  intro p hp
  have h : env39421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39420_39421 : H12AffineEnvironment.transform 5 3 env39420 = env39421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env39420 == env39421) = true)

def env39422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441641,95496,8328,65,270497,436264,45525,32040,412720,156132,256,21793,46213,486375]

theorem envBound39422 : H12AffineFastState.Bounded env39422 := by
  intro p hp
  have h : env39422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39389_39422 : H12AffineEnvironment.transform 21 272513 env39389 = env39422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39389 == env39422) = true)

theorem identity39422 : scanCanonicalize (H12AffineFastState.compose env39422 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39422 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416172,272513,441641,21763,8328,65,270497,436264,45525,32040,412720,156132,256,21793,46213,412652]

theorem envBound39423 : H12AffineFastState.Bounded env39423 := by
  intro p hp
  have h : env39423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39422_39423 : H12AffineEnvironment.transform 15 8203 env39422 = env39423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39422 == env39423) = true)

def env39424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416036,272393,441641,21763,8192,65,270377,436264,45405,32040,412720,156012,256,21793,46093,412516]

theorem envBound39424 : H12AffineFastState.Bounded env39424 := by
  intro p hp
  have h : env39424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39423_39424 : H12AffineEnvironment.transform 6 8 env39423 = env39424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39423 == env39424) = true)

theorem identity39424 : scanCanonicalize (H12AffineFastState.compose env39424 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39424 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env39425 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,415825,272393,441436,21622,8192,65,270377,436264,45096,31837,412720,155673,117,21588,46093,412177]

theorem envBound39425 : H12AffineFastState.Bounded env39425 := by
  intro p hp
  have h : env39425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39424_39425 : H12AffineEnvironment.transform 7 117 env39424 = env39425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39424 == env39425) = true)

theorem identity39425 : scanCanonicalize (H12AffineFastState.compose env39425 (packedSelected [2,3,5,7,10,11,12,15,19,20,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound39425 : packedSelected [2,3,5,7,10,11,12,15,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env39426 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,23669,1024,32769,132132,29820,188457,21622,8192,65,31836,193629,45096,31837,135237,155673,117,21588,46093,136804]

theorem envBound39426 : H12AffineFastState.Bounded env39426 := by
  intro p hp
  have h : env39426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39425_39426 : H12AffineEnvironment.transform 17 23669 env39425 = env39426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env39425 == env39426) = true)

theorem identity39426 : scanCanonicalize (H12AffineFastState.compose env39426 (packedSelected [0,1,3,4,5,6,7,8,9,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound39426 : packedSelected [0,1,3,4,5,6,7,8,9,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env39427 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,8203,131072,23669,1024,8232,132132,29820,147456,21622,8192,65,31836,152692,4097,31837,135237,155673,117,21588,5156,136804]

theorem envBound39427 : H12AffineFastState.Bounded env39427 := by
  intro p hp
  have h : env39427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39426_39427 : H12AffineEnvironment.transform 14 8233 env39426 = env39427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env39426 == env39427) = true)

theorem identity39427 : scanCanonicalize (H12AffineFastState.compose env39427 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound39427 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env39428 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,1,35,131072,23669,1024,0,132132,21588,147456,21622,40,65,23668,152692,4097,23669,135237,147505,117,21588,5156,136804]

theorem envBound39428 : H12AffineFastState.Bounded env39428 := by
  intro p hp
  have h : env39428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39427_39428 : H12AffineEnvironment.transform 12 40 env39427 = env39428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env39427 == env39428) = true)

theorem identity39428 : scanCanonicalize (H12AffineFastState.compose env39428 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound39428 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39429 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,35,131072,2048,1024,0,132132,33,136309,3,40,65,2049,131073,4097,2048,135237,136260,117,33,5156,136804]

theorem envBound39429 : H12AffineFastState.Bounded env39429 := by
  intro p hp
  have h : env39429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39428_39429 : H12AffineEnvironment.transform 13 5237 env39428 = env39429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env39428 == env39429) = true)

theorem identity39429 : scanCanonicalize (H12AffineFastState.compose env39429 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(16+1) ^^^ 3108) := by decide +kernel

theorem selectedBound39429 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env39430 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,35,3108,2048,1024,0,2048,33,6225,3,40,65,2049,3109,4097,2048,7265,6240,117,33,5156,6720]

theorem envBound39430 : H12AffineFastState.Bounded env39430 := by
  intro p hp
  have h : env39430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39429_39430 : H12AffineEnvironment.transform 16 3108 env39429 = env39430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3108 env39429 == env39430) = true)

theorem identity39430 : scanCanonicalize (H12AffineFastState.compose env39430 (packedSelected [0,1,4,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound39430 : packedSelected [0,1,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env39431 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3188,40,2049,1,35,3108,2048,1024,0,2048,33,1061,3,40,65,2049,3109,3189,2048,21,1044,117,33,2128,1588]

theorem envBound39431 : H12AffineFastState.Bounded env39431 := by
  intro p hp
  have h : env39431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39430_39431 : H12AffineEnvironment.transform 11 3188 env39430 = env39431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env39430 == env39431) = true)

theorem identity39431 : scanCanonicalize (H12AffineFastState.compose env39431 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39431 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env39432 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2113,40,2049,1,35,2065,2048,53,0,2048,33,16,3,40,65,2049,2064,2112,2048,21,33,117,33,2128,513]

theorem envBound39432 : H12AffineFastState.Bounded env39432 := by
  intro p hp
  have h : env39432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39431_39432 : H12AffineEnvironment.transform 9 53 env39431 = env39432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39431 == env39432) = true)

theorem identity39432 : scanCanonicalize (H12AffineFastState.compose env39432 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound39432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39433 : List Nat := [2,4,8,16,32,64,8,117,512,53,80,17,40,81,1,35,65,80,53,0,80,33,16,3,40,65,81,64,16,80,21,33,117,33,0,513]

theorem envBound39433 : H12AffineFastState.Bounded env39433 := by
  intro p hp
  have h : env39433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39432_39433 : H12AffineEnvironment.transform 10 80 env39432 = env39433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env39432 == env39433) = true)

theorem identity39433 : scanCanonicalize (H12AffineFastState.compose env39433 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39433 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39434 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,17,40,1,1,35,17,0,53,0,0,33,16,3,40,17,1,16,16,0,21,33,37,33,0,513]

theorem envBound39434 : H12AffineFastState.Bounded env39434 := by
  intro p hp
  have h : env39434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39433_39434 : H12AffineEnvironment.transform 5 16 env39433 = env39434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39433 == env39434) = true)

theorem identity39434 : scanCanonicalize (H12AffineFastState.compose env39434 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound39434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39435 : List Nat := [2,4,8,16,32,16,8,37,49,53,0,17,40,1,1,35,17,0,53,0,0,33,16,3,40,17,1,16,16,0,21,33,37,33,0,48]

theorem envBound39435 : H12AffineFastState.Bounded env39435 := by
  intro p hp
  have h : env39435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39434_39435 : H12AffineEnvironment.transform 8 49 env39434 = env39435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env39434 == env39435) = true)

theorem identity39435 : scanCanonicalize (H12AffineFastState.compose env39435 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39436 : List Nat := [2,4,8,0,32,0,8,37,33,37,0,1,40,1,1,35,1,0,37,0,0,33,0,3,40,1,1,0,0,0,5,33,37,33,0,32]

theorem envBound39436 : H12AffineFastState.Bounded env39436 := by
  intro p hp
  have h : env39436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39435_39436 : H12AffineEnvironment.transform 3 0 env39435 = env39436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39435 == env39436) = true)

def env39437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416037,272392,441641,21763,8193,65,270376,436264,45404,32040,412720,156013,256,21793,46092,412517]

theorem envBound39437 : H12AffineFastState.Bounded env39437 := by
  intro p hp
  have h : env39437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39423_39437 : H12AffineEnvironment.transform 6 9 env39423 = env39437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39423 == env39437) = true)

theorem identity39437 : scanCanonicalize (H12AffineFastState.compose env39437 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound39437 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env39438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,171108,1024,32769,50497,177260,8525,21763,8193,65,179276,13388,45404,32040,53332,156013,256,21793,46092,55041]

theorem envBound39438 : H12AffineFastState.Bounded env39438 := by
  intro p hp
  have h : env39438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39437_39438 : H12AffineEnvironment.transform 17 171108 env39437 = env39438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env39437 == env39438) = true)

theorem identity39438 : scanCanonicalize (H12AffineFastState.compose env39438 (packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39438 : packedSelected [0,1,3,7,8,9,10,11,12,14,15,20,22,24,32] rootPS < 2^1333 := by decide +kernel

def env39439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,5393,35189,1024,32769,50497,41341,8525,21763,8193,65,43357,13388,45404,32040,53332,29820,256,21793,46092,55041]

theorem envBound39439 : H12AffineFastState.Bounded env39439 := by
  intro p hp
  have h : env39439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39438_39439 : H12AffineEnvironment.transform 16 5393 env39438 = env39439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39438 == env39439) = true)

theorem identity39439 : scanCanonicalize (H12AffineFastState.compose env39439 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound39439 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env39440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,5393,23669,1024,21761,4161,29821,8525,21763,8193,65,31837,13388,25692,32040,1364,29820,256,21793,24844,513]

theorem envBound39440 : H12AffineFastState.Bounded env39440 := by
  intro p hp
  have h : env39440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39439_39440 : H12AffineEnvironment.transform 14 21760 env39439 = env39440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env39439 == env39440) = true)

theorem identity39440 : scanCanonicalize (H12AffineFastState.compose env39440 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound39440 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8203,5393,10281,1024,8541,4161,33,8525,8543,8193,65,2049,13388,4096,2420,1364,32,256,8573,5456,513]

theorem envBound39441 : H12AffineFastState.Bounded env39441 := by
  intro p hp
  have h : env39441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39440_39441 : H12AffineEnvironment.transform 13 13404 env39440 = env39441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env39440 == env39441) = true)

theorem identity39441 : scanCanonicalize (H12AffineFastState.compose env39441 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39441 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39442 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12621,8540,8203,4096,10281,273,8541,4161,33,8525,8543,8193,65,2049,12637,4096,2420,69,32,256,8573,4161,513]

theorem envBound39442 : H12AffineFastState.Bounded env39442 := by
  intro p hp
  have h : env39442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39441_39442 : H12AffineEnvironment.transform 9 273 env39441 = env39442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39441 == env39442) = true)

theorem identity39442 : scanCanonicalize (H12AffineFastState.compose env39442 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 4201) := by decide +kernel

theorem selectedBound39442 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39443 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,4201,292,4405,4194,4096,6208,273,4404,4161,33,4388,4406,4200,65,2049,308,4096,2420,69,32,256,4372,4161,513]

theorem envBound39443 : H12AffineFastState.Bounded env39443 := by
  intro p hp
  have h : env39443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39442_39443 : H12AffineEnvironment.transform 12 4201 env39442 = env39443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4201 env39442 == env39443) = true)

theorem identity39443 : scanCanonicalize (H12AffineFastState.compose env39443 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39443 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env39444 : List Nat := [2,4,8,16,32,64,9,256,512,273,0,4096,4201,292,4405,4194,4096,4160,273,4404,4161,33,4388,4406,4200,65,1,308,4096,372,69,32,256,4372,4161,513]

theorem envBound39444 : H12AffineFastState.Bounded env39444 := by
  intro p hp
  have h : env39444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39443_39444 : H12AffineEnvironment.transform 10 0 env39443 = env39444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39443 == env39444) = true)

theorem identity39444 : scanCanonicalize (H12AffineFastState.compose env39444 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound39444 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env39445 : List Nat := [2,4,8,16,32,64,9,256,512,273,0,309,348,292,0,343,309,373,273,1,372,33,17,3,349,65,1,308,309,372,69,32,256,33,372,513]

theorem envBound39445 : H12AffineFastState.Bounded env39445 := by
  intro p hp
  have h : env39445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39444_39445 : H12AffineEnvironment.transform 11 309 env39444 = env39445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env39444 == env39445) = true)

theorem identity39445 : scanCanonicalize (H12AffineFastState.compose env39445 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39446 : List Nat := [2,4,8,16,32,64,9,117,512,100,0,64,41,81,0,34,64,0,100,1,1,33,17,3,40,65,1,65,64,1,69,32,117,33,1,513]

theorem envBound39446 : H12AffineFastState.Bounded env39446 := by
  intro p hp
  have h : env39446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39445_39446 : H12AffineEnvironment.transform 7 117 env39445 = env39446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39445 == env39446) = true)

theorem identity39446 : scanCanonicalize (H12AffineFastState.compose env39446 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 20) := by decide +kernel

theorem selectedBound39446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39447 : List Nat := [2,4,8,16,32,20,9,33,512,48,0,20,41,5,0,34,20,0,48,1,1,33,17,3,40,21,1,21,20,1,17,32,33,33,1,513]

theorem envBound39447 : H12AffineFastState.Bounded env39447 := by
  intro p hp
  have h : env39447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39446_39447 : H12AffineEnvironment.transform 5 20 env39446 = env39447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env39446 == env39447) = true)

theorem identity39447 : scanCanonicalize (H12AffineFastState.compose env39447 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound39447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39448 : List Nat := [2,4,8,16,32,20,9,33,18,48,0,20,41,5,0,34,20,0,48,1,1,33,17,3,40,21,1,21,20,1,17,32,33,33,1,19]

theorem envBound39448 : H12AffineFastState.Bounded env39448 := by
  intro p hp
  have h : env39448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39447_39448 : H12AffineEnvironment.transform 8 18 env39447 = env39448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env39447 == env39448) = true)

theorem identity39448 : scanCanonicalize (H12AffineFastState.compose env39448 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39448 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39449 : List Nat := [2,4,8,12,32,8,9,33,14,44,0,8,41,5,0,34,8,0,44,1,1,33,13,3,40,9,1,9,8,1,13,32,33,33,1,15]

theorem envBound39449 : H12AffineFastState.Bounded env39449 := by
  intro p hp
  have h : env39449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39448_39449 : H12AffineEnvironment.transform 3 12 env39448 = env39449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39448 == env39449) = true)

theorem identity39449 : scanCanonicalize (H12AffineFastState.compose env39449 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound39449 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39450 : List Nat := [2,4,8,12,5,8,9,4,14,9,0,8,12,5,0,7,8,0,9,1,1,4,13,3,13,9,1,9,8,1,13,5,4,4,1,15]

theorem envBound39450 : H12AffineFastState.Bounded env39450 := by
  intro p hp
  have h : env39450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39449_39450 : H12AffineEnvironment.transform 4 5 env39449 = env39450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env39449 == env39450) = true)

def env39451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,8388608,8898593,8328,65,4196384,8393984,8785149,8830977,412720,12645453,256,21792,46212,486375]

theorem envBound39451 : H12AffineFastState.Bounded env39451 := by
  intro p hp
  have h : env39451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39334_39451 : H12AffineEnvironment.transform 20 416173 env39334 = env39451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416173 env39334 == env39451) = true)

def env39452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441640,95497,8328,65,4196384,436264,45525,32041,412720,4606309,256,21792,46212,486375]

theorem envBound39452 : H12AffineFastState.Bounded env39452 := by
  intro p hp
  have h : env39452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39451_39452 : H12AffineEnvironment.transform 22 441640 env39451 = env39452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env39451 == env39452) = true)

def env39453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441640,95497,8328,65,270496,436264,45525,32041,412720,156133,256,21792,46212,486375]

theorem envBound39453 : H12AffineFastState.Bounded env39453 := by
  intro p hp
  have h : env39453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39452_39453 : H12AffineEnvironment.transform 21 272512 env39452 = env39453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39452 == env39453) = true)

theorem identity39453 : scanCanonicalize (H12AffineFastState.compose env39453 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound39453 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416173,272512,412157,95497,8328,65,270496,417021,17664,32041,412720,156133,256,21792,16465,486375]

theorem envBound39454 : H12AffineFastState.Bounded env39454 := by
  intro p hp
  have h : env39454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39453_39454 : H12AffineEnvironment.transform 14 29909 env39453 = env39454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env39453 == env39454) = true)

def env39455 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272512,412077,95497,8328,17,270496,416941,17664,32041,412720,156085,256,21792,16385,486327]

theorem envBound39455 : H12AffineFastState.Bounded env39455 := by
  intro p hp
  have h : env39455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39454_39455 : H12AffineEnvironment.transform 5 16 env39454 = env39455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39454 == env39455) = true)

theorem identity39455 : scanCanonicalize (H12AffineFastState.compose env39455 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound39455 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env39456 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,29963,131072,262144,1024,29828,416173,272512,412077,2,8328,17,270496,416941,17664,32041,412720,156085,256,21792,16385,401084]

theorem envBound39456 : H12AffineFastState.Bounded env39456 := by
  intro p hp
  have h : env39456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39455_39456 : H12AffineEnvironment.transform 15 29963 env39455 = env39456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env39455 == env39456) = true)

theorem identity39456 : scanCanonicalize (H12AffineFastState.compose env39456 (packedSelected [1,4,7,9,14,17,18,19,23,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound39456 : packedSelected [1,4,7,9,14,17,18,19,23,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env39457 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,29963,16537,262144,1024,29828,268596,272512,264500,2,8328,17,270496,269364,17664,32041,265385,8492,256,21792,16385,286245]

theorem envBound39457 : H12AffineFastState.Bounded env39457 := by
  intro p hp
  have h : env39457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39456_39457 : H12AffineEnvironment.transform 16 16537 env39456 = env39457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env39456 == env39457) = true)

theorem identity39457 : scanCanonicalize (H12AffineFastState.compose env39457 (packedSelected [0,3,9,10,18,19,22,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound39457 : packedSelected [0,3,9,10,18,19,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env39458 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,29963,16537,23588,1024,29828,17680,29860,21776,2,8328,17,31876,16400,17664,32041,20621,8492,256,21792,16385,513]

theorem envBound39458 : H12AffineFastState.Bounded env39458 := by
  intro p hp
  have h : env39458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39457_39458 : H12AffineEnvironment.transform 17 23588 env39457 = env39458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env39457 == env39458) = true)

theorem identity39458 : scanCanonicalize (H12AffineFastState.compose env39458 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound39458 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env39459 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8460,8322,5392,2477,1024,8461,4249,8493,153,2,8328,17,10509,5529,4233,10400,1284,8492,256,169,5512,513]

theorem envBound39459 : H12AffineFastState.Bounded env39459 := by
  intro p hp
  have h : env39459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39458_39459 : H12AffineEnvironment.transform 13 5513 env39458 = env39459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env39458 == env39459) = true)

theorem identity39459 : scanCanonicalize (H12AffineFastState.compose env39459 (packedSelected [0,1,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39459 : packedSelected [0,1,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39460 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,5293,8232,8322,5172,2185,1024,8233,4249,8201,153,2,8328,17,10281,5309,4233,10400,1056,8200,36,169,5292,513]

theorem envBound39460 : H12AffineFastState.Bounded env39460 := by
  intro p hp
  have h : env39460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39459_39460 : H12AffineEnvironment.transform 7 36 env39459 = env39460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39459 == env39460) = true)

theorem identity39460 : scanCanonicalize (H12AffineFastState.compose env39460 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound39460 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env39461 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,1173,5293,1213,1047,5172,2185,1024,1212,4249,1180,153,2,1053,17,3260,5309,4233,3125,1056,1181,36,169,5292,513]

theorem envBound39461 : H12AffineFastState.Bounded env39461 := by
  intro p hp
  have h : env39461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39460_39461 : H12AffineEnvironment.transform 12 1173 env39460 = env39461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env39460 == env39461) = true)

theorem identity39461 : scanCanonicalize (H12AffineFastState.compose env39461 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound39461 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39462 : List Nat := [2,4,8,16,32,16,128,36,512,189,2048,4096,40,4112,0,170,4233,2185,189,1,4249,33,153,2,160,17,2049,4096,4233,2184,157,32,36,169,4113,513]

theorem envBound39462 : H12AffineFastState.Bounded env39462 := by
  intro p hp
  have h : env39462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39461_39462 : H12AffineEnvironment.transform 9 189 env39461 = env39462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env39461 == env39462) = true)

theorem identity39462 : scanCanonicalize (H12AffineFastState.compose env39462 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39462 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39463 : List Nat := [2,4,8,1,32,1,128,36,512,172,2048,4096,40,4097,0,170,4233,2185,172,1,4232,33,136,2,160,0,2049,4096,4233,2184,140,32,36,169,4096,513]

theorem envBound39463 : H12AffineFastState.Bounded env39463 := by
  intro p hp
  have h : env39463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39462_39463 : H12AffineEnvironment.transform 3 1 env39462 = env39463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39462 == env39463) = true)

theorem identity39463 : scanCanonicalize (H12AffineFastState.compose env39463 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39463 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39464 : List Nat := [2,4,8,1,32,1,9,36,512,37,2048,4096,40,4097,0,35,4096,2048,37,1,4097,33,1,2,41,0,2049,4096,4096,2049,5,32,36,32,4096,513]

theorem envBound39464 : H12AffineFastState.Bounded env39464 := by
  intro p hp
  have h : env39464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39463_39464 : H12AffineEnvironment.transform 6 9 env39463 = env39464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39463 == env39464) = true)

theorem identity39464 : scanCanonicalize (H12AffineFastState.compose env39464 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound39464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39465 : List Nat := [2,4,8,1,32,1,9,36,512,37,2048,32,40,33,0,35,32,2048,37,1,33,33,1,2,41,0,2049,32,32,2049,5,32,36,32,32,513]

theorem envBound39465 : H12AffineFastState.Bounded env39465 := by
  intro p hp
  have h : env39465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39464_39465 : H12AffineEnvironment.transform 11 32 env39464 = env39465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env39464 == env39465) = true)

def env39466 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272512,412076,95497,8328,16,270496,416940,17664,32041,412720,156084,256,21792,16384,486326]

theorem envBound39466 : H12AffineFastState.Bounded env39466 := by
  intro p hp
  have h : env39466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39454_39466 : H12AffineEnvironment.transform 5 17 env39454 = env39466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39454 == env39466) = true)

theorem identity39466 : scanCanonicalize (H12AffineFastState.compose env39466 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound39466 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env39467 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,10400,1024,29829,160013,32,155916,95497,8328,16,2048,160780,17664,32041,156816,156084,256,21792,16384,213782]

theorem envBound39467 : H12AffineFastState.Bounded env39467 := by
  intro p hp
  have h : env39467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39466_39467 : H12AffineEnvironment.transform 17 10400 env39466 = env39467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env39466 == env39467) = true)

theorem identity39467 : scanCanonicalize (H12AffineFastState.compose env39467 (packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,19,20,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 24752) := by decide +kernel

theorem selectedBound39467 : packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env39468 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24752,10400,1024,29829,4541,32,444,95497,8328,16,2048,5308,17664,32041,1056,260,256,21792,16384,74662]

theorem envBound39468 : H12AffineFastState.Bounded env39468 := by
  intro p hp
  have h : env39468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39467_39468 : H12AffineEnvironment.transform 16 24752 env39467 = env39468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24752 env39467 == env39468) = true)

theorem identity39468 : scanCanonicalize (H12AffineFastState.compose env39468 (packedSelected [2,5,6,9,10,11,12,14,15,16,19,20,22,23,24,31] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound39468 : packedSelected [2,5,6,9,10,11,12,14,15,16,19,20,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env39469 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21761,65536,16693,2341,1024,21760,4541,32,444,87180,269,16,2048,5308,17664,23724,1056,260,256,21792,16384,66083]

theorem envBound39469 : H12AffineFastState.Bounded env39469 := by
  intro p hp
  have h : env39469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39468_39469 : H12AffineEnvironment.transform 12 389 env39468 = env39469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env39468 == env39469) = true)

theorem identity39469 : scanCanonicalize (H12AffineFastState.compose env39469 (packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound39469 : packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env39470 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21761,21795,16693,2341,1024,21760,4541,32,444,431,269,16,2048,5308,17664,23724,1056,260,256,21792,16384,22272]

theorem envBound39470 : H12AffineFastState.Bounded env39470 := by
  intro p hp
  have h : env39470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39469_39470 : H12AffineEnvironment.transform 15 21795 env39469 = env39470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env39469 == env39470) = true)

theorem identity39470 : scanCanonicalize (H12AffineFastState.compose env39470 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound39470 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39471 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5513,136,170,5308,2341,1024,137,4541,32,444,431,269,16,2048,5308,4233,2341,1056,260,256,169,5513,649]

theorem envBound39471 : H12AffineFastState.Bounded env39471 := by
  intro p hp
  have h : env39471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39470_39471 : H12AffineEnvironment.transform 13 5513 env39470 = env39471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env39470 == env39471) = true)

theorem identity39471 : scanCanonicalize (H12AffineFastState.compose env39471 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound39471 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39472 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,5157,136,170,5308,2185,1024,137,4113,32,16,3,161,16,2048,5308,4233,2185,1056,168,172,169,5157,649]

theorem envBound39472 : H12AffineFastState.Bounded env39472 := by
  intro p hp
  have h : env39472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39471_39472 : H12AffineEnvironment.transform 7 172 env39471 = env39472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39471 == env39472) = true)

theorem identity39472 : scanCanonicalize (H12AffineFastState.compose env39472 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound39472 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39473 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1212,41,153,136,170,0,2185,1024,137,1197,32,16,3,161,16,2048,0,1077,2185,1056,168,172,169,153,649]

theorem envBound39473 : H12AffineFastState.Bounded env39473 := by
  intro p hp
  have h : env39473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39472_39473 : H12AffineEnvironment.transform 11 1212 env39472 = env39473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env39472 == env39473) = true)

theorem identity39473 : scanCanonicalize (H12AffineFastState.compose env39473 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound39473 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env39474 : List Nat := [2,4,8,16,32,17,128,172,512,36,2048,152,41,153,136,170,0,2185,36,137,137,32,16,3,161,16,2048,0,17,2185,4,168,172,169,153,649]

theorem envBound39474 : H12AffineFastState.Bounded env39474 := by
  intro p hp
  have h : env39474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39473_39474 : H12AffineEnvironment.transform 9 36 env39473 = env39474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env39473 == env39474) = true)

theorem identity39474 : scanCanonicalize (H12AffineFastState.compose env39474 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39474 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39475 : List Nat := [2,4,8,16,0,17,128,140,512,4,2048,152,9,153,136,138,0,2185,4,137,137,0,16,3,129,16,2048,0,17,2185,4,136,140,137,153,649]

theorem envBound39475 : H12AffineFastState.Bounded env39475 := by
  intro p hp
  have h : env39475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39474_39475 : H12AffineEnvironment.transform 4 0 env39474 = env39475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39474 == env39475) = true)

theorem identity39475 : scanCanonicalize (H12AffineFastState.compose env39475 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39475 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39476 : List Nat := [2,4,8,16,0,17,9,5,512,4,2048,17,9,16,1,3,0,2048,4,0,0,0,16,3,8,16,2048,0,17,2048,4,1,5,0,16,512]

theorem envBound39476 : H12AffineFastState.Bounded env39476 := by
  intro p hp
  have h : env39476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39475_39476 : H12AffineEnvironment.transform 6 9 env39475 = env39476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39475 == env39476) = true)

theorem identity39476 : scanCanonicalize (H12AffineFastState.compose env39476 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound39476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39477 : List Nat := [2,4,8,16,0,17,9,5,512,4,528,17,9,16,1,3,0,528,4,0,0,0,16,3,8,16,528,0,17,528,4,1,5,0,16,512]

theorem envBound39477 : H12AffineFastState.Bounded env39477 := by
  intro p hp
  have h : env39477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39476_39477 : H12AffineEnvironment.transform 10 528 env39476 = env39477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env39476 == env39477) = true)

theorem identity39477 : scanCanonicalize (H12AffineFastState.compose env39477 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39478 : List Nat := [2,4,8,0,0,1,9,5,512,4,512,1,9,0,1,3,0,512,4,0,0,0,0,3,8,0,512,0,1,512,4,1,5,0,0,512]

theorem envBound39478 : H12AffineFastState.Bounded env39478 := by
  intro p hp
  have h : env39478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39477_39478 : H12AffineEnvironment.transform 3 0 env39477 = env39478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39477 == env39478) = true)

theorem identity39478 : scanCanonicalize (H12AffineFastState.compose env39478 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound39478 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39479 : List Nat := [2,4,8,0,0,1,9,5,14,4,14,1,9,0,1,3,0,14,4,0,0,0,0,3,8,0,14,0,1,14,4,1,5,0,0,14]

theorem envBound39479 : H12AffineFastState.Bounded env39479 := by
  intro p hp
  have h : env39479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39478_39479 : H12AffineEnvironment.transform 8 14 env39478 = env39479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env39478 == env39479) = true)

theorem identity39479 : scanCanonicalize (H12AffineFastState.compose env39479 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound39479 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39480 : List Nat := [2,4,7,0,0,1,6,5,1,4,1,1,6,0,1,3,0,1,4,0,0,0,0,3,7,0,1,0,1,1,4,1,5,0,0,1]

theorem envBound39480 : H12AffineFastState.Bounded env39480 := by
  intro p hp
  have h : env39480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39479_39480 : H12AffineEnvironment.transform 2 7 env39479 = env39480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env39479 == env39480) = true)

def env39481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441640,95497,8328,65,270497,436264,45525,32041,412720,156132,256,21792,46212,486375]

theorem envBound39481 : H12AffineFastState.Bounded env39481 := by
  intro p hp
  have h : env39481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39452_39481 : H12AffineEnvironment.transform 21 272513 env39452 = env39481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39452 == env39481) = true)

theorem identity39481 : scanCanonicalize (H12AffineFastState.compose env39481 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound39481 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,156012,62661,95497,8328,65,158028,57797,45525,32041,1501,156132,256,21792,46212,74250]

theorem envBound39482 : H12AffineFastState.Bounded env39482 := by
  intro p hp
  have h : env39482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39481_39482 : H12AffineEnvironment.transform 17 149997 env39481 = env39482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env39481 == env39482) = true)

theorem identity39482 : scanCanonicalize (H12AffineFastState.compose env39482 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39482 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env39483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4160,156012,62661,21762,8328,65,158028,57797,45525,32041,1501,156132,256,21792,46212,513]

theorem envBound39483 : H12AffineFastState.Bounded env39483 := by
  intro p hp
  have h : env39483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39482_39483 : H12AffineEnvironment.transform 15 8203 env39482 = env39483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39482 == env39483) = true)

theorem identity39483 : scanCanonicalize (H12AffineFastState.compose env39483 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound39483 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env39484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,131072,146744,1024,32769,4160,136633,32784,8663,8328,65,138649,38160,45525,2556,1501,136497,256,8693,46212,513]

theorem envBound39484 : H12AffineFastState.Bounded env39484 := by
  intro p hp
  have h : env39484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39483_39484 : H12AffineEnvironment.transform 13 13525 env39483 = env39484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env39483 == env39484) = true)

theorem identity39484 : scanCanonicalize (H12AffineFastState.compose env39484 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound39484 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env39485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,5529,10401,1024,32769,4160,32,32784,8663,8328,65,2048,38160,45525,2556,1501,168,256,8693,46212,513]

theorem envBound39485 : H12AffineFastState.Bounded env39485 := by
  intro p hp
  have h : env39485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39484_39485 : H12AffineEnvironment.transform 16 5529 env39484 = env39485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env39484 == env39485) = true)

theorem identity39485 : scanCanonicalize (H12AffineFastState.compose env39485 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound39485 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env39486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8460,8203,5529,10401,1024,8461,4160,32,8476,8663,8328,65,2048,13340,4313,2556,1501,168,256,8693,5512,513]

theorem envBound39486 : H12AffineFastState.Bounded env39486 := by
  intro p hp
  have h : env39486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39485_39486 : H12AffineEnvironment.transform 14 8460 env39485 = env39486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env39485 == env39486) = true)

theorem identity39486 : scanCanonicalize (H12AffineFastState.compose env39486 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound39486 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5457,136,399,5529,2341,1024,137,4160,32,152,83,268,65,2048,5528,4313,2556,1501,168,256,113,5512,513]

theorem envBound39487 : H12AffineFastState.Bounded env39487 := by
  intro p hp
  have h : env39487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39486_39487 : H12AffineEnvironment.transform 12 388 env39486 = env39487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env39486 == env39487) = true)

theorem identity39487 : scanCanonicalize (H12AffineFastState.compose env39487 (packedSelected [0,1,2,3,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound39487 : packedSelected [0,1,2,3,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39488 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,81,342,5440,2341,1024,80,4160,32,65,83,268,65,2048,5441,4096,2341,1284,113,256,113,5457,513]

theorem envBound39488 : H12AffineFastState.Bounded env39488 := by
  intro p hp
  have h : env39488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39487_39488 : H12AffineEnvironment.transform 6 89 env39487 = env39488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env39487 == env39488) = true)

theorem identity39488 : scanCanonicalize (H12AffineFastState.compose env39488 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound39488 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39489 : List Nat := [2,4,8,16,32,64,89,256,512,305,2048,4096,349,4192,81,342,4209,2341,305,80,4160,32,65,83,268,65,2048,4208,4096,2341,53,113,256,113,4192,513]

theorem envBound39489 : H12AffineFastState.Bounded env39489 := by
  intro p hp
  have h : env39489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39488_39489 : H12AffineEnvironment.transform 9 305 env39488 = env39489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env39488 == env39489) = true)

def env39490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441641,95496,8328,65,4196384,436265,45524,32040,412720,4606308,256,21792,46212,486375]

theorem envBound39490 : H12AffineFastState.Bounded env39490 := by
  intro p hp
  have h : env39490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39451_39490 : H12AffineEnvironment.transform 22 441641 env39451 = env39490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env39451 == env39490) = true)

def env39491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441641,95496,8328,65,270496,436265,45524,32040,412720,156132,256,21792,46212,486375]

theorem envBound39491 : H12AffineFastState.Bounded env39491 := by
  intro p hp
  have h : env39491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39490_39491 : H12AffineEnvironment.transform 21 272512 env39490 = env39491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39490 == env39491) = true)

def env39492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272392,441641,95496,8192,65,270376,436265,45404,32040,412720,156012,256,21792,46092,486255]

theorem envBound39492 : H12AffineFastState.Bounded env39492 := by
  intro p hp
  have h : env39492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39491_39492 : H12AffineEnvironment.transform 6 8 env39491 = env39492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39491 == env39492) = true)

def env39493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314421,272392,272441,95496,8192,65,270376,277817,45404,32040,317728,62588,256,21792,46092,392831]

theorem envBound39493 : H12AffineFastState.Bounded env39493 := by
  intro p hp
  have h : env39493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39492_39493 : H12AffineEnvironment.transform 16 38160 env39492 = env39493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env39492 == env39493) = true)

theorem identity39493 : scanCanonicalize (H12AffineFastState.compose env39493 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39493 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,13388,262144,1024,8541,290153,272392,272441,95496,8192,65,270376,277817,4096,32040,292988,21792,256,21792,5456,352035]

theorem envBound39494 : H12AffineFastState.Bounded env39494 := by
  intro p hp
  have h : env39494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39493_39494 : H12AffineEnvironment.transform 14 8540 env39493 = env39494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39493 == env39494) = true)

theorem identity39494 : scanCanonicalize (H12AffineFastState.compose env39494 (packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound39494 : packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS < 2^1333 := by decide +kernel

def env39495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,13388,97326,1024,8541,69959,87078,87063,95496,8192,65,89094,82199,4096,32040,66642,21792,256,21792,5456,8973]

theorem envBound39495 : H12AffineFastState.Bounded env39495 := by
  intro p hp
  have h : env39495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39494_39495 : H12AffineEnvironment.transform 17 97326 env39494 = env39495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env39494 == env39495) = true)

theorem identity39495 : scanCanonicalize (H12AffineFastState.compose env39495 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,19,22,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39495 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39496 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8232,65536,13388,97326,1024,8233,69683,87078,87063,95356,8192,65,89094,82019,4096,31836,66642,21588,116,21588,5156,8825]

theorem envBound39496 : H12AffineFastState.Bounded env39496 := by
  intro p hp
  have h : env39496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39495_39496 : H12AffineEnvironment.transform 7 116 env39495 = env39496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39495 == env39496) = true)

theorem identity39496 : scanCanonicalize (H12AffineFastState.compose env39496 (packedSelected [1,8,12,15,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound39496 : packedSelected [1,8,12,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env39497 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8232,65536,13388,75866,1024,8233,69683,65618,65635,73736,8192,65,67698,70679,4096,10280,66642,32,116,32,5156,8825]

theorem envBound39497 : H12AffineFastState.Bounded env39497 := by
  intro p hp
  have h : env39497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39496_39497 : H12AffineEnvironment.transform 13 5236 env39496 = env39497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env39496 == env39497) = true)

theorem identity39497 : scanCanonicalize (H12AffineFastState.compose env39497 (packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39497 : packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env39498 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8232,8202,13388,2128,1024,8233,12345,8280,8297,2,8192,65,10360,13341,4096,10280,9304,32,116,32,5156,8825]

theorem envBound39498 : H12AffineFastState.Bounded env39498 := by
  intro p hp
  have h : env39498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39497_39498 : H12AffineEnvironment.transform 15 8202 env39497 = env39498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39497 == env39498) = true)

theorem identity39498 : scanCanonicalize (H12AffineFastState.compose env39498 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound39498 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39499 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,0,34,5220,2128,1024,1,4113,112,65,2,40,65,2128,5173,4096,2048,1136,32,116,32,5156,593]

theorem envBound39499 : H12AffineFastState.Bounded env39499 := by
  intro p hp
  have h : env39499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39498_39499 : H12AffineEnvironment.transform 12 40 env39498 = env39499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env39498 == env39499) = true)

theorem identity39499 : scanCanonicalize (H12AffineFastState.compose env39499 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound39499 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39500 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,48,40,1092,0,34,1108,2128,1024,1,33,112,65,2,40,65,2128,1029,48,2048,1136,32,116,32,1044,593]

theorem envBound39500 : H12AffineFastState.Bounded env39500 := by
  intro p hp
  have h : env39500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39499_39500 : H12AffineEnvironment.transform 11 48 env39499 = env39500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39499 == env39500) = true)

theorem identity39500 : scanCanonicalize (H12AffineFastState.compose env39500 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound39500 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env39501 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1044,48,40,1092,0,34,1108,1092,1024,1,33,112,65,2,40,65,1092,1029,48,1044,1136,32,116,32,1044,593]

theorem envBound39501 : H12AffineFastState.Bounded env39501 := by
  intro p hp
  have h : env39501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39500_39501 : H12AffineEnvironment.transform 10 1044 env39500 = env39501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env39500 == env39501) = true)

theorem identity39501 : scanCanonicalize (H12AffineFastState.compose env39501 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39501 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39502 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,40,1045,0,34,1029,1045,1024,1,33,33,16,2,40,16,1045,1029,48,1044,1057,32,37,32,1044,512]

theorem envBound39502 : H12AffineFastState.Bounded env39502 := by
  intro p hp
  have h : env39502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39501_39502 : H12AffineEnvironment.transform 5 17 env39501 = env39502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39501 == env39502) = true)

theorem identity39502 : scanCanonicalize (H12AffineFastState.compose env39502 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39502 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39503 : List Nat := [2,4,8,16,32,17,8,37,512,4,16,48,40,17,0,34,1,17,4,1,33,33,16,2,40,16,17,1,48,16,37,32,37,32,16,512]

theorem envBound39503 : H12AffineFastState.Bounded env39503 := by
  intro p hp
  have h : env39503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39502_39503 : H12AffineEnvironment.transform 9 4 env39502 = env39503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39502 == env39503) = true)

theorem identity39503 : scanCanonicalize (H12AffineFastState.compose env39503 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39504 : List Nat := [2,4,8,16,1,17,8,4,512,4,16,17,9,17,0,3,1,17,4,1,0,0,16,2,9,16,17,1,17,16,4,1,4,1,16,512]

theorem envBound39504 : H12AffineFastState.Bounded env39504 := by
  intro p hp
  have h : env39504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39503_39504 : H12AffineEnvironment.transform 4 1 env39503 = env39504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39503 == env39504) = true)

theorem identity39504 : scanCanonicalize (H12AffineFastState.compose env39504 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39505 : List Nat := [2,4,8,16,1,17,8,4,1,4,16,17,9,17,0,3,1,17,4,1,0,0,16,2,9,16,17,1,17,16,4,1,4,1,16,1]

theorem envBound39505 : H12AffineFastState.Bounded env39505 := by
  intro p hp
  have h : env39505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39504_39505 : H12AffineEnvironment.transform 8 1 env39504 = env39505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39504 == env39505) = true)

def env39506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314420,272392,272440,95496,8192,65,270376,277816,45404,32040,317729,62589,256,21792,46092,392830]

theorem envBound39506 : H12AffineFastState.Bounded env39506 := by
  intro p hp
  have h : env39506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39492_39506 : H12AffineEnvironment.transform 16 38161 env39492 = env39506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39492 == env39506) = true)

theorem identity39506 : scanCanonicalize (H12AffineFastState.compose env39506 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound39506 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35189,1024,32769,17729,41341,41293,95496,8192,65,43357,46157,45404,32040,20564,62589,256,21792,46092,96011]

theorem envBound39507 : H12AffineFastState.Bounded env39507 := by
  intro p hp
  have h : env39507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39506_39507 : H12AffineEnvironment.transform 17 35189 env39506 = env39507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env39506 == env39507) = true)

theorem identity39507 : scanCanonicalize (H12AffineFastState.compose env39507 (packedSelected [7,8,10,12,14,15,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound39507 : packedSelected [7,8,10,12,14,15,20,27,28] rootPS < 2^1333 := by decide +kernel

def env39508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,65536,38161,35189,1024,32769,12345,41341,41293,65648,8192,65,43357,46157,45404,2128,9516,33029,256,8280,46092,66163]

theorem envBound39508 : H12AffineFastState.Bounded env39508 := by
  intro p hp
  have h : env39508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39507_39508 : H12AffineEnvironment.transform 13 13688 env39507 = env39508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env39507 == env39508) = true)

theorem identity39508 : scanCanonicalize (H12AffineFastState.compose env39508 (packedSelected [1,2,4,6,8,11,12,15,16,18,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound39508 : packedSelected [1,2,4,6,8,11,12,15,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env39509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,114,38161,35189,1024,32769,12345,41341,41293,2,8192,65,43357,46157,45404,2128,9516,33029,256,8280,46092,513]

theorem envBound39509 : H12AffineFastState.Bounded env39509 := by
  intro p hp
  have h : env39509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39508_39509 : H12AffineEnvironment.transform 15 114 env39508 = env39509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env39508 == env39509) = true)

theorem identity39509 : scanCanonicalize (H12AffineFastState.compose env39509 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound39509 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env39510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,9293,114,12636,11576,1024,9292,12345,1328,1280,2,8192,65,3344,4096,5393,2128,9516,9544,256,8280,4161,513]

theorem envBound39510 : H12AffineFastState.Bounded env39510 := by
  intro p hp
  have h : env39510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39509_39510 : H12AffineEnvironment.transform 14 9293 env39509 = env39510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env39509 == env39510) = true)

theorem identity39510 : scanCanonicalize (H12AffineFastState.compose env39510 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound39510 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env39511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,1077,114,4388,3392,1024,1076,4161,1328,1280,2,120,65,3344,4096,5393,2128,1364,1328,256,32,4161,513]

theorem envBound39511 : H12AffineFastState.Bounded env39511 := by
  intro p hp
  have h : env39511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39510_39511 : H12AffineEnvironment.transform 12 120 env39510 = env39511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env39510 == env39511) = true)

theorem identity39511 : scanCanonicalize (H12AffineFastState.compose env39511 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39511 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env39512 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,120,4113,292,114,4388,2129,273,293,4161,33,17,2,120,65,2049,4096,4096,2128,69,33,256,32,4161,513]

theorem envBound39512 : H12AffineFastState.Bounded env39512 := by
  intro p hp
  have h : env39512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39511_39512 : H12AffineEnvironment.transform 9 273 env39511 = env39512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39511 == env39512) = true)

theorem identity39512 : scanCanonicalize (H12AffineFastState.compose env39512 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39512 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39513 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,120,4113,0,114,4096,2129,53,1,4161,33,17,2,120,65,2049,4096,4096,2128,69,33,36,32,4161,513]

theorem envBound39513 : H12AffineFastState.Bounded env39513 := by
  intro p hp
  have h : env39513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39512_39513 : H12AffineEnvironment.transform 7 36 env39512 = env39513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39512 == env39513) = true)

theorem identity39513 : scanCanonicalize (H12AffineFastState.compose env39513 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39513 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39514 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,40,4113,0,34,4096,2049,53,1,4113,33,17,2,40,17,2049,4096,4096,2048,21,33,36,32,4113,513]

theorem envBound39514 : H12AffineFastState.Bounded env39514 := by
  intro p hp
  have h : env39514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39513_39514 : H12AffineEnvironment.transform 5 16 env39513 = env39514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39513 == env39514) = true)

theorem identity39514 : scanCanonicalize (H12AffineFastState.compose env39514 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound39514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39515 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,40,2048,0,34,2065,2049,53,1,2048,33,17,2,40,17,2049,2065,2065,2048,21,33,36,32,2048,513]

theorem envBound39515 : H12AffineFastState.Bounded env39515 := by
  intro p hp
  have h : env39515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39514_39515 : H12AffineEnvironment.transform 11 2065 env39514 = env39515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env39514 == env39515) = true)

theorem identity39515 : scanCanonicalize (H12AffineFastState.compose env39515 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39515 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39516 : List Nat := [2,4,8,10,32,10,8,36,512,47,2048,2059,40,2048,0,34,2059,2049,47,1,2048,33,11,2,40,11,2049,2059,2059,2048,15,33,36,32,2048,513]

theorem envBound39516 : H12AffineFastState.Bounded env39516 := by
  intro p hp
  have h : env39516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39515_39516 : H12AffineEnvironment.transform 3 10 env39515 = env39516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39515 == env39516) = true)

theorem identity39516 : scanCanonicalize (H12AffineFastState.compose env39516 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39516 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39517 : List Nat := [2,4,8,10,32,10,8,36,512,47,1,10,40,1,0,34,10,0,47,1,1,33,11,2,40,11,0,10,10,1,15,33,36,32,1,513]

theorem envBound39517 : H12AffineFastState.Bounded env39517 := by
  intro p hp
  have h : env39517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39516_39517 : H12AffineEnvironment.transform 10 1 env39516 = env39517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39516 == env39517) = true)

def env39518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441641,95496,8193,65,270377,436265,45405,32040,412720,156013,256,21792,46093,486254]

theorem envBound39518 : H12AffineFastState.Bounded env39518 := by
  intro p hp
  have h : env39518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39491_39518 : H12AffineEnvironment.transform 6 9 env39491 = env39518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39491 == env39518) = true)

def env39519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272441,95496,8193,65,270377,277817,45405,32040,317728,62589,256,21792,46093,392830]

theorem envBound39519 : H12AffineFastState.Bounded env39519 := by
  intro p hp
  have h : env39519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39518_39519 : H12AffineEnvironment.transform 16 38160 env39518 = env39519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env39518 == env39519) = true)

theorem identity39519 : scanCanonicalize (H12AffineFastState.compose env39519 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound39519 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,58396,33,17,95496,8193,65,2049,5393,45405,32040,61704,62589,256,21792,46093,120406]

theorem envBound39520 : H12AffineFastState.Bounded env39520 := by
  intro p hp
  have h : env39520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39519_39520 : H12AffineEnvironment.transform 17 10280 env39519 = env39520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39519 == env39520) = true)

theorem identity39520 : scanCanonicalize (H12AffineFastState.compose env39520 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39520 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10280,1024,32769,45341,33,17,73737,8193,65,2049,5393,45405,10281,41993,41340,256,33,46093,99159]

theorem envBound39521 : H12AffineFastState.Bounded env39521 := by
  intro p hp
  have h : env39521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39520_39521 : H12AffineEnvironment.transform 13 5377 env39520 = env39521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39520 == env39521) = true)

theorem identity39521 : scanCanonicalize (H12AffineFastState.compose env39521 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39521 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env39522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,38160,10280,1024,32769,45341,33,17,3,8193,65,2049,5393,45405,10281,41993,41340,256,33,46093,41821]

theorem envBound39522 : H12AffineFastState.Bounded env39522 := by
  intro p hp
  have h : env39522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39521_39522 : H12AffineEnvironment.transform 15 8202 env39521 = env39522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39521 == env39522) = true)

theorem identity39522 : scanCanonicalize (H12AffineFastState.compose env39522 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39522 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,13389,10280,1024,8540,4160,33,17,3,8193,65,2049,5393,4096,10281,1364,33,256,33,5456,512]

theorem envBound39523 : H12AffineFastState.Bounded env39523 := by
  intro p hp
  have h : env39523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39522_39523 : H12AffineEnvironment.transform 14 8541 env39522 = env39523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39522 == env39523) = true)

theorem identity39523 : scanCanonicalize (H12AffineFastState.compose env39523 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39523 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39524 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,13389,10248,1024,8540,4160,1,17,3,8193,65,2049,5393,4096,10249,1364,1,256,1,5456,512]

theorem envBound39524 : H12AffineFastState.Bounded env39524 := by
  intro p hp
  have h : env39524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39523_39524 : H12AffineEnvironment.transform 4 0 env39523 = env39524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39523 == env39524) = true)

theorem identity39524 : scanCanonicalize (H12AffineFastState.compose env39524 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39524 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39525 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,8192,5124,8280,8202,13389,10248,1024,8281,4160,1,17,3,8193,65,2049,5140,4096,10249,1105,1,5,1,5205,512]

theorem envBound39525 : H12AffineFastState.Bounded env39525 := by
  intro p hp
  have h : env39525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39524_39525 : H12AffineEnvironment.transform 7 5 env39524 = env39525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39524 == env39525) = true)

theorem identity39525 : scanCanonicalize (H12AffineFastState.compose env39525 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound39525 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env39526 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,5132,5124,5204,5126,65,7172,1024,5205,4160,1,17,3,5133,65,2049,5140,4096,7173,1105,1,5,1,5205,512]

theorem envBound39526 : H12AffineFastState.Bounded env39526 := by
  intro p hp
  have h : env39526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39525_39526 : H12AffineEnvironment.transform 12 5132 env39525 = env39526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env39525 == env39526) = true)

theorem identity39526 : scanCanonicalize (H12AffineFastState.compose env39526 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound39526 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env39527 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,1109,89,81,1,83,65,2129,1024,0,1045,1,17,3,88,65,2049,65,1109,2128,1105,1,5,1,0,512]

theorem envBound39527 : H12AffineFastState.Bounded env39527 := by
  intro p hp
  have h : env39527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39526_39527 : H12AffineEnvironment.transform 11 1109 env39526 = env39527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env39526 == env39527) = true)

theorem identity39527 : scanCanonicalize (H12AffineFastState.compose env39527 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound39527 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39528 : List Nat := [2,4,8,16,0,64,9,5,512,68,2048,17,89,81,1,83,65,2129,68,0,81,1,17,3,88,65,2049,65,17,2128,21,1,5,1,0,512]

theorem envBound39528 : H12AffineFastState.Bounded env39528 := by
  intro p hp
  have h : env39528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39527_39528 : H12AffineEnvironment.transform 9 68 env39527 = env39528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env39527 == env39528) = true)

theorem identity39528 : scanCanonicalize (H12AffineFastState.compose env39528 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound39528 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env39529 : List Nat := [2,4,8,16,0,64,9,5,512,68,81,17,89,81,1,83,65,0,68,0,81,1,17,3,88,65,80,65,17,1,21,1,5,1,0,512]

theorem envBound39529 : H12AffineFastState.Bounded env39529 := by
  intro p hp
  have h : env39529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39528_39529 : H12AffineEnvironment.transform 10 81 env39528 = env39529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env39528 == env39529) = true)

def env39530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272440,95496,8193,65,270377,277816,45405,32040,317729,62588,256,21792,46093,392831]

theorem envBound39530 : H12AffineFastState.Bounded env39530 := by
  intro p hp
  have h : env39530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39518_39530 : H12AffineEnvironment.transform 16 38161 env39518 = env39530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39518 == env39530) = true)

theorem identity39530 : scanCanonicalize (H12AffineFastState.compose env39530 (packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39530 : packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env39531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1024,32769,314421,272393,272440,21762,8193,65,270377,277816,45405,32040,317729,62588,256,21792,46093,319093]

theorem envBound39531 : H12AffineFastState.Bounded env39531 := by
  intro p hp
  have h : env39531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39530_39531 : H12AffineEnvironment.transform 15 8202 env39530 = env39531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39530 == env39531) = true)

theorem identity39531 : scanCanonicalize (H12AffineFastState.compose env39531 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound39531 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env39532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,43049,1024,32769,25628,32800,32785,21762,8193,65,34816,38161,45405,32040,28936,62588,256,21792,46093,30300]

theorem envBound39532 : H12AffineFastState.Bounded env39532 := by
  intro p hp
  have h : env39532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39531_39532 : H12AffineEnvironment.transform 17 43049 env39531 = env39532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env39531 == env39532) = true)

theorem identity39532 : scanCanonicalize (H12AffineFastState.compose env39532 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound39532 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,24909,23669,1024,29789,25628,29820,29773,21762,8193,65,31836,24909,17665,32040,28936,32,256,21792,16465,30300]

theorem envBound39533 : H12AffineFastState.Bounded env39533 := by
  intro p hp
  have h : env39533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39532_39533 : H12AffineEnvironment.transform 14 29788 env39532 = env39533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env39532 == env39533) = true)

theorem identity39533 : scanCanonicalize (H12AffineFastState.compose env39533 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39533 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env39534 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,24861,23589,1024,29709,25628,29740,29725,21762,8193,17,31756,24861,17665,32040,28936,32,256,21792,16385,30220]

theorem envBound39534 : H12AffineFastState.Bounded env39534 := by
  intro p hp
  have h : env39534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39533_39534 : H12AffineEnvironment.transform 5 16 env39533 = env39534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39533 == env39534) = true)

theorem identity39534 : scanCanonicalize (H12AffineFastState.compose env39534 (packedSelected [0,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound39534 : packedSelected [0,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39535 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,12345,1077,8202,4388,11292,1024,1076,5157,1045,1060,9531,8193,17,3125,4388,13624,3345,305,32,256,9497,12344,1589]

theorem envBound39535 : H12AffineFastState.Bounded env39535 := by
  intro p hp
  have h : env39535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39534_39535 : H12AffineEnvironment.transform 13 12345 env39534 = env39535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env39534 == env39535) = true)

theorem identity39535 : scanCanonicalize (H12AffineFastState.compose env39535 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39535 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env39536 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,12345,0,8202,4388,10281,53,1,4112,32,17,8462,8193,17,2048,4388,12557,2340,305,32,256,8492,12344,512]

theorem envBound39536 : H12AffineFastState.Bounded env39536 := by
  intro p hp
  have h : env39536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39535_39536 : H12AffineEnvironment.transform 9 53 env39535 = env39536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39535 == env39536) = true)

theorem identity39536 : scanCanonicalize (H12AffineFastState.compose env39536 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound39536 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39537 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,301,4372,0,295,4388,2308,53,1,4112,32,17,35,300,17,2048,4388,4128,2340,305,32,256,1,4373,512]

theorem envBound39537 : H12AffineFastState.Bounded env39537 := by
  intro p hp
  have h : env39537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39536_39537 : H12AffineEnvironment.transform 12 301 env39536 = env39537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env39536 == env39537) = true)

theorem identity39537 : scanCanonicalize (H12AffineFastState.compose env39537 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39537 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env39538 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8,4145,0,2,4097,2081,53,1,4112,32,17,35,9,17,2048,4097,4128,2049,20,32,37,1,4144,512]

theorem envBound39538 : H12AffineFastState.Bounded env39538 := by
  intro p hp
  have h : env39538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39537_39538 : H12AffineEnvironment.transform 7 37 env39537 = env39538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39537 == env39538) = true)

theorem identity39538 : scanCanonicalize (H12AffineFastState.compose env39538 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound39538 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39539 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2097,8,2048,0,2,2096,2081,53,1,2081,32,17,35,9,17,2048,2096,2065,2049,20,32,37,1,2049,512]

theorem envBound39539 : H12AffineFastState.Bounded env39539 := by
  intro p hp
  have h : env39539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39538_39539 : H12AffineEnvironment.transform 11 2097 env39538 = env39539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env39538 == env39539) = true)

theorem identity39539 : scanCanonicalize (H12AffineFastState.compose env39539 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39539 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env39540 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,2065,8,2048,0,2,2064,2049,21,1,2049,0,17,3,9,17,2048,2064,2065,2049,20,0,5,1,2049,512]

theorem envBound39540 : H12AffineFastState.Bounded env39540 := by
  intro p hp
  have h : env39540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39539_39540 : H12AffineEnvironment.transform 4 0 env39539 = env39540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39539 == env39540) = true)

theorem identity39540 : scanCanonicalize (H12AffineFastState.compose env39540 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound39540 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39541 : List Nat := [2,4,8,16,0,16,9,5,512,21,5,20,8,5,0,2,21,4,21,1,4,0,17,3,9,17,5,21,20,4,20,0,5,1,4,512]

theorem envBound39541 : H12AffineFastState.Bounded env39541 := by
  intro p hp
  have h : env39541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39540_39541 : H12AffineEnvironment.transform 10 5 env39540 = env39541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env39540 == env39541) = true)

def env39542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441641,95496,8328,65,270497,436265,45524,32040,412720,156133,256,21792,46212,486375]

theorem envBound39542 : H12AffineFastState.Bounded env39542 := by
  intro p hp
  have h : env39542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39490_39542 : H12AffineEnvironment.transform 21 272513 env39490 = env39542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39490 == env39542) = true)

theorem identity39542 : scanCanonicalize (H12AffineFastState.compose env39542 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound39542 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58516,169400,16,95496,8328,65,171416,5392,45524,32040,61705,156133,256,21792,46212,120542]

theorem envBound39543 : H12AffineFastState.Bounded env39543 := by
  intro p hp
  have h : env39543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39542_39543 : H12AffineEnvironment.transform 17 179513 env39542 = env39543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env39542 == env39543) = true)

def env39544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58396,169264,16,95496,8192,65,171280,5392,45404,32040,61705,156013,256,21792,46092,120406]

theorem envBound39544 : H12AffineFastState.Bounded env39544 := by
  intro p hp
  have h : env39544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39543_39544 : H12AffineEnvironment.transform 6 8 env39543 = env39544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39543 == env39544) = true)

theorem identity39544 : scanCanonicalize (H12AffineFastState.compose env39544 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound39544 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35189,1024,32769,58396,41340,16,95496,8192,65,43356,5392,45404,32040,61705,21793,256,21792,46092,120406]

theorem envBound39545 : H12AffineFastState.Bounded env39545 := by
  intro p hp
  have h : env39545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39544_39545 : H12AffineEnvironment.transform 16 13388 env39544 = env39545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env39544 == env39545) = true)

theorem identity39545 : scanCanonicalize (H12AffineFastState.compose env39545 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39545 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env39546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13388,35189,1024,32769,45341,41340,16,73737,8192,65,43356,5392,45404,10281,41992,32,256,33,46092,99159]

theorem envBound39546 : H12AffineFastState.Bounded env39546 := by
  intro p hp
  have h : env39546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39545_39546 : H12AffineEnvironment.transform 13 5377 env39545 = env39546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39545 == env39546) = true)

theorem identity39546 : scanCanonicalize (H12AffineFastState.compose env39546 (packedSelected [4,5,9,12,14,15,18,20,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound39546 : packedSelected [4,5,9,12,14,15,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env39547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,115,13388,35189,1024,32769,45341,41340,16,8314,8192,65,43356,5392,45404,10281,41992,32,256,33,46092,33572]

theorem envBound39547 : H12AffineFastState.Bounded env39547 := by
  intro p hp
  have h : env39547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39546_39547 : H12AffineEnvironment.transform 15 115 env39546 = env39547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env39546 == env39547) = true)

def env39548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58397,169265,16,95496,8193,65,171281,5392,45405,32040,61705,156012,256,21792,46093,120407]

theorem envBound39548 : H12AffineFastState.Bounded env39548 := by
  intro p hp
  have h : env39548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39543_39548 : H12AffineEnvironment.transform 6 9 env39543 = env39548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39543 == env39548) = true)

theorem identity39548 : scanCanonicalize (H12AffineFastState.compose env39548 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound39548 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,58397,32,16,95496,8193,65,2048,5392,45405,32040,61705,62589,256,21792,46093,120407]

theorem envBound39549 : H12AffineFastState.Bounded env39549 := by
  intro p hp
  have h : env39549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39548_39549 : H12AffineEnvironment.transform 16 38161 env39548 = env39549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39548 == env39549) = true)

theorem identity39549 : scanCanonicalize (H12AffineFastState.compose env39549 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound39549 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,38161,10280,1024,32769,58397,32,16,8543,8193,65,2048,5392,45405,32040,61705,62589,256,21792,46093,33280]

theorem envBound39550 : H12AffineFastState.Bounded env39550 := by
  intro p hp
  have h : env39550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39549_39550 : H12AffineEnvironment.transform 15 21591 env39549 = env39550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env39549 == env39550) = true)

theorem identity39550 : scanCanonicalize (H12AffineFastState.compose env39550 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39550 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,342,38161,10280,1024,32769,45340,32,16,8543,8193,65,2048,5392,45405,10281,41992,41340,256,33,46093,33280]

theorem envBound39551 : H12AffineFastState.Bounded env39551 := by
  intro p hp
  have h : env39551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39550_39551 : H12AffineEnvironment.transform 13 5377 env39550 = env39551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39550 == env39551) = true)

theorem identity39551 : scanCanonicalize (H12AffineFastState.compose env39551 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39551 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env39552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,342,38161,2340,1024,32769,36880,32,16,83,269,65,2048,5392,36945,2341,34052,32880,256,33,38145,33280]

theorem envBound39552 : H12AffineFastState.Bounded env39552 := by
  intro p hp
  have h : env39552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39551_39552 : H12AffineEnvironment.transform 12 268 env39551 = env39552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39551 == env39552) = true)

theorem identity39552 : scanCanonicalize (H12AffineFastState.compose env39552 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound39552 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env39553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,342,5440,2340,1024,80,4161,32,16,83,269,65,2048,5392,4096,2341,1365,33,256,33,5456,593]

theorem envBound39553 : H12AffineFastState.Bounded env39553 := by
  intro p hp
  have h : env39553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39552_39553 : H12AffineEnvironment.transform 14 81 env39552 = env39553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env39552 == env39553) = true)

theorem identity39553 : scanCanonicalize (H12AffineFastState.compose env39553 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2421) := by decide +kernel

theorem selectedBound39553 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2421,268,3188,81,342,3125,2340,1024,80,2356,32,16,83,269,65,2048,3173,2421,2341,1365,33,256,33,3109,593]

theorem envBound39554 : H12AffineFastState.Bounded env39554 := by
  intro p hp
  have h : env39554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39553_39554 : H12AffineEnvironment.transform 11 2421 env39553 = env39554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2421 env39553 == env39554) = true)

theorem identity39554 : scanCanonicalize (H12AffineFastState.compose env39554 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound39554 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39555 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,2081,88,3188,81,2,3125,2160,1024,80,2144,32,16,83,89,65,2048,3173,2081,2161,1025,33,84,33,3109,593]

theorem envBound39555 : H12AffineFastState.Bounded env39555 := by
  intro p hp
  have h : env39555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39554_39555 : H12AffineEnvironment.transform 7 84 env39554 = env39555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env39554 == env39555) = true)

theorem identity39555 : scanCanonicalize (H12AffineFastState.compose env39555 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound39555 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39556 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1093,1124,88,49,81,2,112,1077,1024,80,1061,32,16,83,89,65,1093,32,1124,1076,1025,33,84,33,96,593]

theorem envBound39556 : H12AffineFastState.Bounded env39556 := by
  intro p hp
  have h : env39556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39555_39556 : H12AffineEnvironment.transform 10 1093 env39555 = env39556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env39555 == env39556) = true)

theorem identity39556 : scanCanonicalize (H12AffineFastState.compose env39556 (packedSelected [1,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound39556 : packedSelected [1,6,8,11] rootPS < 2^1333 := by decide +kernel

def env39557 : List Nat := [2,4,8,16,32,64,9,84,512,84,17,48,88,49,81,2,112,97,84,80,113,32,16,83,89,65,17,32,48,96,85,33,84,33,96,593]

theorem envBound39557 : H12AffineFastState.Bounded env39557 := by
  intro p hp
  have h : env39557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39556_39557 : H12AffineEnvironment.transform 9 84 env39556 = env39557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env39556 == env39557) = true)

end H12CloudChart1