import H12CloudChart1Data174

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity44361 : scanCanonicalize (H12AffineFastState.compose env44361 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44362 : List Nat := [2,4,8,1,0,1,9,256,261,257,261,260,268,260,1,263,261,0,257,0,260,1,1,3,269,0,261,261,260,1,5,0,256,1,260,260]

theorem envBound44362 : H12AffineFastState.Bounded env44362 := by
  intro p hp
  have h : env44362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44361_44362 : H12AffineEnvironment.transform 5 1 env44361 = env44362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44361 == env44362) = true)

theorem identity44362 : scanCanonicalize (H12AffineFastState.compose env44362 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound44362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44363 : List Nat := [2,4,8,1,0,1,9,15,10,14,10,11,3,11,1,8,10,0,14,0,11,1,1,3,2,0,10,10,11,1,5,0,15,1,11,11]

theorem envBound44363 : H12AffineFastState.Bounded env44363 := by
  intro p hp
  have h : env44363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44362_44363 : H12AffineEnvironment.transform 7 15 env44362 = env44363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env44362 == env44363) = true)

def env44364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,276585,272392,272440,98645,8193,65,316533,277817,17665,32041,273788,62589,256,21792,46092,330274]

theorem envBound44364 : H12AffineFastState.Bounded env44364 := by
  intro p hp
  have h : env44364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44345_44364 : H12AffineEnvironment.transform 16 38161 env44345 = env44364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env44345 == env44364) = true)

theorem identity44364 : scanCanonicalize (H12AffineFastState.compose env44364 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound44364 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,33,17,98645,8193,65,64604,5392,17665,32041,1365,62589,256,21792,46092,74251]

theorem envBound44365 : H12AffineFastState.Bounded env44365 := by
  intro p hp
  have h : env44365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44364_44365 : H12AffineEnvironment.transform 17 10281 env44364 = env44365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44364 == env44365) = true)

theorem identity44365 : scanCanonicalize (H12AffineFastState.compose env44365 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound44365 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env44366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54278,38161,10281,1024,32769,4160,33,17,21843,8193,65,64604,5392,17665,32041,1365,62589,256,21792,46092,62989]

theorem envBound44366 : H12AffineFastState.Bounded env44366 := by
  intro p hp
  have h : env44366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44365_44366 : H12AffineEnvironment.transform 15 54278 env44365 = env44366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env44365 == env44366) = true)

theorem identity44366 : scanCanonicalize (H12AffineFastState.compose env44366 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound44366 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env44367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,40970,38161,10281,1024,32769,4160,33,17,8543,8193,65,34896,5392,12557,2341,1365,32881,256,8492,46092,33281]

theorem envBound44367 : H12AffineFastState.Bounded env44367 := by
  intro p hp
  have h : env44367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44366_44367 : H12AffineEnvironment.transform 13 13324 env44366 = env44367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env44366 == env44367) = true)

theorem identity44367 : scanCanonicalize (H12AffineFastState.compose env44367 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44367 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,8202,5393,10281,1024,1,4160,33,17,8543,8193,65,2128,5392,12557,2341,1365,113,256,8492,13324,513]

theorem envBound44368 : H12AffineFastState.Bounded env44368 := by
  intro p hp
  have h : env44368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44367_44368 : H12AffineEnvironment.transform 14 0 env44367 = env44368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44367 == env44368) = true)

theorem identity44368 : scanCanonicalize (H12AffineFastState.compose env44368 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44368 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,0,342,5393,2421,1024,1,4160,33,17,3,349,65,2128,5392,4177,2341,1365,113,256,112,5456,513]

theorem envBound44369 : H12AffineFastState.Bounded env44369 := by
  intro p hp
  have h : env44369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44368_44369 : H12AffineEnvironment.transform 12 348 env44368 = env44369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44368 == env44369) = true)

theorem identity44369 : scanCanonicalize (H12AffineFastState.compose env44369 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44369 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44370 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1024,1,4112,33,17,3,269,17,2048,5392,4097,2341,1285,33,256,32,5376,513]

theorem envBound44370 : H12AffineFastState.Bounded env44370 := by
  intro p hp
  have h : env44370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44369_44370 : H12AffineEnvironment.transform 5 16 env44369 = env44370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44369 == env44370) = true)

theorem identity44370 : scanCanonicalize (H12AffineFastState.compose env44370 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44371 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,0,34,5173,2049,1024,1,4112,33,17,3,41,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound44371 : H12AffineFastState.Bounded env44371 := by
  intro p hp
  have h : env44371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44370_44371 : H12AffineEnvironment.transform 7 36 env44370 = env44371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44370 == env44371) = true)

def env44372 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1044,0,34,1029,2049,1024,1,32,33,17,3,41,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound44372 : H12AffineFastState.Bounded env44372 := by
  intro p hp
  have h : env44372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44371_44372 : H12AffineEnvironment.transform 11 48 env44371 = env44372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44371 == env44372) = true)

theorem identity44372 : scanCanonicalize (H12AffineFastState.compose env44372 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44373 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,48,40,0,0,34,17,2049,20,1,32,33,17,3,41,17,2048,16,49,2049,53,33,36,32,0,513]

theorem envBound44373 : H12AffineFastState.Bounded env44373 := by
  intro p hp
  have h : env44373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44372_44373 : H12AffineEnvironment.transform 9 20 env44372 = env44373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44372 == env44373) = true)

def env44374 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,8,0,0,2,17,2049,20,1,0,1,17,3,9,17,2048,16,17,2049,21,1,4,0,0,513]

theorem envBound44374 : H12AffineFastState.Bounded env44374 := by
  intro p hp
  have h : env44374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44373_44374 : H12AffineEnvironment.transform 4 0 env44373 = env44374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44373 == env44374) = true)

theorem identity44374 : scanCanonicalize (H12AffineFastState.compose env44374 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44375 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,8,0,0,2,17,0,20,1,0,1,17,3,9,17,1,16,17,0,21,1,4,0,0,513]

theorem envBound44375 : H12AffineFastState.Bounded env44375 := by
  intro p hp
  have h : env44375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44374_44375 : H12AffineEnvironment.transform 10 1 env44374 = env44375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44374 == env44375) = true)

def leafEnv44375 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,8,0,0,2,17,0,20,1,0,1,17,3,21,9,1,17,1,16,17,0,21,1,4,0,4,3,0,513,1,0,0]

def active44375 : List Nat := [0,1,2,3,8]

def tree44375 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44375 : H12WitnessSearch.Good tree44375 := H12GlobalWitnessIndex.good

theorem leafIdentity44375 : H12AffineFastState.composeSystem env44375 rootObs = leafEnv44375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44375 rootObs == leafEnv44375) = true)

theorem terminalChecked44375 : H12PackedTerminal.terminalCheckFast leafEnv44375 active44375 tree44375 = true := by decide +kernel

def env44376 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,9,0,0,3,17,2049,20,1,1,0,17,3,8,17,2048,16,16,2049,20,0,5,1,0,513]

theorem envBound44376 : H12AffineFastState.Bounded env44376 := by
  intro p hp
  have h : env44376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44373_44376 : H12AffineEnvironment.transform 4 1 env44373 = env44376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44373 == env44376) = true)

theorem identity44376 : scanCanonicalize (H12AffineFastState.compose env44376 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound44376 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44377 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,17,9,0,0,3,17,522,20,1,1,0,17,3,8,17,523,16,16,522,20,0,5,1,0,513]

theorem envBound44377 : H12AffineFastState.Bounded env44377 := by
  intro p hp
  have h : env44377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44376_44377 : H12AffineEnvironment.transform 10 523 env44376 = env44377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env44376 == env44377) = true)

def leafEnv44377 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,17,9,0,0,3,17,522,20,1,1,0,17,3,20,8,1,17,523,16,16,522,20,0,5,1,4,2,0,513,1,1,0]

def active44377 : List Nat := [0,1,2,3,8]

def tree44377 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44377 : H12WitnessSearch.Good tree44377 := H12GlobalWitnessIndex.good

theorem leafIdentity44377 : H12AffineFastState.composeSystem env44377 rootObs = leafEnv44377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44377 rootObs == leafEnv44377) = true)

theorem terminalChecked44377 : H12PackedTerminal.terminalCheckFast leafEnv44377 active44377 tree44377 = true := by decide +kernel

def env44378 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1045,0,34,1028,2049,1024,1,33,33,17,3,41,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound44378 : H12AffineFastState.Bounded env44378 := by
  intro p hp
  have h : env44378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44371_44378 : H12AffineEnvironment.transform 11 49 env44371 = env44378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44371 == env44378) = true)

theorem identity44378 : scanCanonicalize (H12AffineFastState.compose env44378 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44378 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44379 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,17,8,1045,0,2,1028,2049,1024,1,1,1,17,3,9,17,2048,1029,16,2049,1025,1,4,0,1045,513]

theorem envBound44379 : H12AffineFastState.Bounded env44379 := by
  intro p hp
  have h : env44379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44378_44379 : H12AffineEnvironment.transform 4 0 env44378 = env44379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44378 == env44379) = true)

def env44380 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,8,1,0,2,16,2049,20,1,1,1,17,3,9,17,2048,17,16,2049,21,1,4,0,1,513]

theorem envBound44380 : H12AffineFastState.Bounded env44380 := by
  intro p hp
  have h : env44380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44379_44380 : H12AffineEnvironment.transform 9 20 env44379 = env44380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44379 == env44380) = true)

theorem identity44380 : scanCanonicalize (H12AffineFastState.compose env44380 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44381 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,8,1,0,2,16,1,20,1,1,1,17,3,9,17,0,17,16,1,21,1,4,0,1,513]

theorem envBound44381 : H12AffineFastState.Bounded env44381 := by
  intro p hp
  have h : env44381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44380_44381 : H12AffineEnvironment.transform 10 0 env44380 = env44381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44380 == env44381) = true)

def leafEnv44381 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,8,1,0,2,16,1,20,1,1,1,17,3,21,9,1,17,0,17,16,1,21,1,4,0,4,3,1,513,1,1,0]

def active44381 : List Nat := [0,1,2,3,8]

def tree44381 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44381 : H12WitnessSearch.Good tree44381 := H12GlobalWitnessIndex.good

theorem leafIdentity44381 : H12AffineFastState.composeSystem env44381 rootObs = leafEnv44381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44381 rootObs == leafEnv44381) = true)

theorem terminalChecked44381 : H12PackedTerminal.terminalCheckFast leafEnv44381 active44381 tree44381 = true := by decide +kernel

def env44382 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,8,0,0,2,17,2049,21,1,1,1,17,3,9,17,2048,16,16,2049,20,1,4,0,0,513]

theorem envBound44382 : H12AffineFastState.Bounded env44382 := by
  intro p hp
  have h : env44382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44379_44382 : H12AffineEnvironment.transform 9 21 env44379 = env44382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44379 == env44382) = true)

theorem identity44382 : scanCanonicalize (H12AffineFastState.compose env44382 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound44382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44383 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,17,8,0,0,2,17,522,21,1,1,1,17,3,9,17,523,16,16,522,20,1,4,0,0,513]

theorem envBound44383 : H12AffineFastState.Bounded env44383 := by
  intro p hp
  have h : env44383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44382_44383 : H12AffineEnvironment.transform 10 523 env44382 = env44383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env44382 == env44383) = true)

def leafEnv44383 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,17,8,0,0,2,17,522,21,1,1,1,17,3,20,9,1,17,523,16,16,522,20,1,4,0,4,3,0,513,1,1,0]

def active44383 : List Nat := [0,1,2,3,8]

def tree44383 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44383 : H12WitnessSearch.Good tree44383 := H12GlobalWitnessIndex.good

theorem leafIdentity44383 : H12AffineFastState.composeSystem env44383 rootObs = leafEnv44383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44383 rootObs == leafEnv44383) = true)

theorem terminalChecked44383 : H12PackedTerminal.terminalCheckFast leafEnv44383 active44383 tree44383 = true := by decide +kernel

def env44384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound44384 : H12AffineFastState.Bounded env44384 := by
  intro p hp
  have h : env44384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44141_44384 : H12AffineEnvironment.transform 18 1025 env44141 = env44384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env44141 == env44384) = true)

theorem identity44384 : scanCanonicalize (H12AffineFastState.compose env44384 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833400) := by decide +kernel

theorem selectedBound44384 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833400,8328,65,6458872,8702325,10507600,8830977,2410985,12855352,257,297300,289008,2485823]

theorem envBound44385 : H12AffineFastState.Bounded env44385 := by
  intro p hp
  have h : env44385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44384_44385 : H12AffineEnvironment.transform 23 10833400 env44384 = env44385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833400 env44384 == env44385) = true)

def env44386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458872,8393985,10507600,8526965,2102685,12645452,257,21792,46212,2175563]

theorem envBound44386 : H12AffineFastState.Bounded env44386 := by
  intro p hp
  have h : env44386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44385_44386 : H12AffineEnvironment.transform 17 56436 env44385 = env44386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env44385 == env44386) = true)

def env44387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,4194304,8388608,8487372,8328,65,4365752,8393985,8406288,8526965,1501,12645452,257,21792,46212,74251]

theorem envBound44387 : H12AffineFastState.Bounded env44387 := by
  intro p hp
  have h : env44387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44386_44387 : H12AffineEnvironment.transform 20 4160 env44386 = env44387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44386 == env44387) = true)

def env44388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,32,8388608,8487372,8328,65,171416,8393985,8406288,8526965,1501,8451180,257,21792,46212,74251]

theorem envBound44388 : H12AffineFastState.Bounded env44388 := by
  intro p hp
  have h : env44388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44387_44388 : H12AffineEnvironment.transform 21 32 env44387 = env44388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44387 == env44388) = true)

theorem identity44388 : scanCanonicalize (H12AffineFastState.compose env44388 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound44388 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,56436,1025,32769,4160,32,8388608,8410387,8328,65,171416,8393985,8406288,8526965,1501,8451180,257,21792,46212,63188]

theorem envBound44389 : H12AffineFastState.Bounded env44389 := by
  intro p hp
  have h : env44389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44388_44389 : H12AffineEnvironment.transform 15 54495 env44388 = env44389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env44388 == env44389) = true)

def env44390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56436,1025,32769,4160,32,8388608,8410387,8192,65,171280,8393985,8406288,8526965,1365,8451180,257,21792,46092,63068]

theorem envBound44390 : H12AffineFastState.Bounded env44390 := by
  intro p hp
  have h : env44390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44389_44390 : H12AffineEnvironment.transform 6 8 env44389 = env44390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44389 == env44390) = true)

theorem identity44390 : scanCanonicalize (H12AffineFastState.compose env44390 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound44390 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46156,56436,1025,32769,4160,32,8388608,8410387,8192,65,10588,8393985,8406288,8431673,1365,8451180,257,21792,46092,63068]

theorem envBound44391 : H12AffineFastState.Bounded env44391 := by
  intro p hp
  have h : env44391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44390_44391 : H12AffineEnvironment.transform 16 46156 env44390 = env44391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env44390 == env44391) = true)

theorem identity44391 : scanCanonicalize (H12AffineFastState.compose env44391 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound44391 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env44392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16401,10281,1025,29788,4160,32,8388608,8410387,8192,65,10588,8393985,8406288,8412260,1365,8388657,257,21792,16465,513]

theorem envBound44392 : H12AffineFastState.Bounded env44392 := by
  intro p hp
  have h : env44392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44391_44392 : H12AffineEnvironment.transform 14 29789 env44391 = env44392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env44391 == env44392) = true)

theorem identity44392 : scanCanonicalize (H12AffineFastState.compose env44392 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound44392 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env44393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16401,10281,1025,29788,4160,32,17,21762,8192,65,10588,5392,17665,23669,1365,32,257,21792,16465,513]

theorem envBound44393 : H12AffineFastState.Bounded env44393 := by
  intro p hp
  have h : env44393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44392_44393 : H12AffineEnvironment.transform 22 17 env44392 = env44393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env44392 == env44393) = true)

theorem identity44393 : scanCanonicalize (H12AffineFastState.compose env44393 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44393 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env44394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21841,262,16401,2341,1025,21840,4160,32,17,21762,268,65,2128,5392,17665,23669,1365,32,257,21792,16465,513]

theorem envBound44394 : H12AffineFastState.Bounded env44394 := by
  intro p hp
  have h : env44394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44393_44394 : H12AffineEnvironment.transform 12 268 env44393 = env44394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44393 == env44394) = true)

theorem identity44394 : scanCanonicalize (H12AffineFastState.compose env44394 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound44394 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,262,5441,2341,1025,0,4160,32,17,82,268,65,2128,5392,4177,2341,1365,32,257,112,5377,513]

theorem envBound44395 : H12AffineFastState.Bounded env44395 := by
  intro p hp
  have h : env44395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44394_44395 : H12AffineEnvironment.transform 13 5456 env44394 = env44395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env44394 == env44395) = true)

theorem identity44395 : scanCanonicalize (H12AffineFastState.compose env44395 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1792) := by decide +kernel

theorem selectedBound44395 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env44396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1792,268,592,1,262,577,2341,1025,0,1856,32,17,82,268,65,2128,528,1873,2341,1365,32,257,112,513,513]

theorem envBound44396 : H12AffineFastState.Bounded env44396 := by
  intro p hp
  have h : env44396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44395_44396 : H12AffineEnvironment.transform 11 1792 env44395 = env44396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1792 env44395 == env44396) = true)

def env44397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56436,1025,32769,4160,32,8388608,8410387,8193,65,171281,8393985,8406288,8526965,1364,8451180,257,21792,46093,63069]

theorem envBound44397 : H12AffineFastState.Bounded env44397 := by
  intro p hp
  have h : env44397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44389_44397 : H12AffineEnvironment.transform 6 9 env44389 = env44397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44389 == env44397) = true)

theorem identity44397 : scanCanonicalize (H12AffineFastState.compose env44397 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 57400) := by decide +kernel

theorem selectedBound44397 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,57400,56436,1025,32769,4160,32,8388608,8410387,8193,65,32041,8393985,8406288,8453197,1364,8451180,257,21792,46093,63069]

theorem envBound44398 : H12AffineFastState.Bounded env44398 := by
  intro p hp
  have h : env44398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44397_44398 : H12AffineEnvironment.transform 16 57400 env44397 = env44398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57400 env44397 == env44398) = true)

theorem identity44398 : scanCanonicalize (H12AffineFastState.compose env44398 (packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound44398 : packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,29823,16401,31837,1025,8232,4160,32,8388608,8410387,8193,65,32041,8393985,8406288,8412260,1364,8410181,257,21792,5156,22132]

theorem envBound44399 : H12AffineFastState.Bounded env44399 := by
  intro p hp
  have h : env44399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44398_44399 : H12AffineEnvironment.transform 14 8233 env44398 = env44399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env44398 == env44399) = true)

theorem identity44399 : scanCanonicalize (H12AffineFastState.compose env44399 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44399 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env44400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8233,8574,5392,10588,1025,8232,4160,32,8388608,8388626,8193,65,10280,8393985,8392721,8391013,1364,8388932,257,33,5156,885]

theorem envBound44400 : H12AffineFastState.Bounded env44400 := by
  intro p hp
  have h : env44400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44399_44400 : H12AffineEnvironment.transform 13 5377 env44399 = env44400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44399 == env44400) = true)

theorem identity44400 : scanCanonicalize (H12AffineFastState.compose env44400 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44400 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env44401 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,8233,8202,5220,10280,1025,8232,4160,32,8388608,8388626,8193,65,10280,8393845,8392721,8390673,1056,8388656,117,33,5156,513]

theorem envBound44401 : H12AffineFastState.Bounded env44401 := by
  intro p hp
  have h : env44401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44400_44401 : H12AffineEnvironment.transform 7 116 env44400 = env44401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44400 == env44401) = true)

theorem identity44401 : scanCanonicalize (H12AffineFastState.compose env44401 (packedSelected [3,5,10] rootPS)) = affineNative (2^(22+1) ^^^ 1141) := by decide +kernel

theorem selectedBound44401 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44402 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,8233,8202,5220,10280,1025,8232,4160,32,1141,1127,8193,65,10280,4096,5220,3172,1056,1093,117,33,5156,513]

theorem envBound44402 : H12AffineFastState.Bounded env44402 := by
  intro p hp
  have h : env44402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44401_44402 : H12AffineEnvironment.transform 22 1141 env44401 = env44402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 1141 env44401 == env44402) = true)

theorem identity44402 : scanCanonicalize (H12AffineFastState.compose env44402 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound44402 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env44403 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,6200,5237,6161,6194,5220,4112,1025,6160,4160,32,1141,1127,6201,65,4112,4096,5220,3172,1056,1093,117,33,5156,513]

theorem envBound44403 : H12AffineFastState.Bounded env44403 := by
  intro p hp
  have h : env44403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44402_44403 : H12AffineEnvironment.transform 12 6200 env44402 = env44403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env44402 == env44403) = true)

theorem identity44403 : scanCanonicalize (H12AffineFastState.compose env44403 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44403 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44404 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,4096,6200,4161,6161,6194,4176,4112,53,6160,4160,32,65,83,6201,65,4112,4096,4176,2128,20,113,117,33,4112,513]

theorem envBound44404 : H12AffineFastState.Bounded env44404 := by
  intro p hp
  have h : env44404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44403_44404 : H12AffineEnvironment.transform 9 52 env44403 = env44404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44403 == env44404) = true)

theorem identity44404 : scanCanonicalize (H12AffineFastState.compose env44404 (packedSelected [0,2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2672) := by decide +kernel

theorem selectedBound44404 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env44405 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2672,584,2609,609,578,2592,2656,53,608,2608,32,65,83,585,65,2656,2672,2592,2128,20,113,117,33,2656,513]

theorem envBound44405 : H12AffineFastState.Bounded env44405 := by
  intro p hp
  have h : env44405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44404_44405 : H12AffineEnvironment.transform 11 2672 env44404 = env44405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2672 env44404 == env44405) = true)

theorem identity44405 : scanCanonicalize (H12AffineFastState.compose env44405 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound44405 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env44406 : List Nat := [2,4,8,16,32,64,9,116,512,52,16,608,584,545,609,578,560,624,53,608,544,32,65,83,585,65,624,608,560,64,20,113,117,33,624,513]

theorem envBound44406 : H12AffineFastState.Bounded env44406 := by
  intro p hp
  have h : env44406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44405_44406 : H12AffineEnvironment.transform 10 16 env44405 = env44406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env44405 == env44406) = true)

theorem identity44406 : scanCanonicalize (H12AffineFastState.compose env44406 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44407 : List Nat := [2,4,8,1,32,64,9,101,512,37,1,608,584,545,609,578,545,609,36,608,544,32,65,66,585,65,609,608,545,64,5,96,100,33,609,513]

theorem envBound44407 : H12AffineFastState.Bounded env44407 := by
  intro p hp
  have h : env44407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44406_44407 : H12AffineEnvironment.transform 3 1 env44406 = env44407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44406 == env44407) = true)

theorem identity44407 : scanCanonicalize (H12AffineFastState.compose env44407 (packedSelected [0,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound44407 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env44408 : List Nat := [2,4,8,1,32,0,9,37,512,37,1,544,520,545,545,514,545,545,36,544,544,32,1,2,521,1,545,544,545,0,5,32,36,33,545,513]

theorem envBound44408 : H12AffineFastState.Bounded env44408 := by
  intro p hp
  have h : env44408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44407_44408 : H12AffineEnvironment.transform 5 0 env44407 = env44408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env44407 == env44408) = true)

theorem identity44408 : scanCanonicalize (H12AffineFastState.compose env44408 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound44408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44409 : List Nat := [2,4,8,1,32,0,9,37,33,37,1,1,41,0,0,35,0,0,36,1,1,32,1,2,40,1,0,1,0,0,5,32,36,33,0,32]

theorem envBound44409 : H12AffineFastState.Bounded env44409 := by
  intro p hp
  have h : env44409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44408_44409 : H12AffineEnvironment.transform 8 33 env44408 = env44409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env44408 == env44409) = true)

def env44410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,8388608,8487372,8328,65,171417,8393985,8406288,8526965,1501,8451181,257,21792,46212,74251]

theorem envBound44410 : H12AffineFastState.Bounded env44410 := by
  intro p hp
  have h : env44410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44387_44410 : H12AffineEnvironment.transform 21 33 env44387 = env44410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44387 == env44410) = true)

theorem identity44410 : scanCanonicalize (H12AffineFastState.compose env44410 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound44410 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,120014,21762,8328,65,171417,115151,102878,247995,1501,73891,257,21792,46212,74251]

theorem envBound44411 : H12AffineFastState.Bounded env44411 := by
  intro p hp
  have h : env44411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44410_44411 : H12AffineEnvironment.transform 22 120014 env44410 = env44411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env44410 == env44411) = true)

def env44412 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56356,1025,32769,4112,33,119966,21762,8328,17,171417,115103,102798,247995,1421,73891,257,21792,46212,74251]

theorem envBound44412 : H12AffineFastState.Bounded env44412 := by
  intro p hp
  have h : env44412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44411_44412 : H12AffineEnvironment.transform 5 16 env44411 = env44412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44411 == env44412) = true)

theorem identity44412 : scanCanonicalize (H12AffineFastState.compose env44412 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound44412 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env44413 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,114967,56356,1025,32769,4112,33,119966,21762,8328,17,89230,115103,102798,2476,1421,73891,257,21792,46212,74251]

theorem envBound44413 : H12AffineFastState.Bounded env44413 := by
  intro p hp
  have h : env44413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44412_44413 : H12AffineEnvironment.transform 16 114967 env44412 = env44413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env44412 == env44413) = true)

theorem identity44413 : scanCanonicalize (H12AffineFastState.compose env44413 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound44413 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env44414 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8322,57749,56356,1025,32769,4112,33,62492,21762,8328,17,31756,57629,45324,2476,1421,33,257,21792,46212,649]

theorem envBound44414 : H12AffineFastState.Bounded env44414 := by
  intro p hp
  have h : env44414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44413_44414 : H12AffineEnvironment.transform 15 8322 env44413 = env44414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env44413 == env44414) = true)

theorem identity44414 : scanCanonicalize (H12AffineFastState.compose env44414 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound44414 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env44415 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,8322,13460,2341,1025,21760,4112,33,8477,21762,8328,17,31756,13340,25613,2476,1421,33,257,21792,24965,649]

theorem envBound44415 : H12AffineFastState.Bounded env44415 := by
  intro p hp
  have h : env44415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44414_44415 : H12AffineEnvironment.transform 14 21761 env44414 = env44415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env44414 == env44415) = true)

theorem identity44415 : scanCanonicalize (H12AffineFastState.compose env44415 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44415 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env44416 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,8202,13340,2341,1025,21760,4112,33,8477,21762,8192,17,31756,13340,25613,2340,1285,33,257,21792,24845,513]

theorem envBound44416 : H12AffineFastState.Bounded env44416 := by
  intro p hp
  have h : env44416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44415_44416 : H12AffineEnvironment.transform 6 8 env44415 = env44416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44415 == env44416) = true)

theorem identity44416 : scanCanonicalize (H12AffineFastState.compose env44416 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44416 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44417 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,0,8202,13340,2341,1025,1,4112,33,8477,3,8192,17,10509,13340,12556,2340,1285,33,257,33,13324,513]

theorem envBound44417 : H12AffineFastState.Bounded env44417 := by
  intro p hp
  have h : env44417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44416_44417 : H12AffineEnvironment.transform 13 5377 env44416 = env44417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44416 == env44417) = true)

theorem identity44417 : scanCanonicalize (H12AffineFastState.compose env44417 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound44417 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44418 : List Nat := [2,4,8,16,32,16,8,256,512,37,2048,4096,8192,4388,0,8202,12345,2341,36,1,4112,33,8477,3,8192,17,10509,12345,12556,2340,288,33,257,33,12329,513]

theorem envBound44418 : H12AffineFastState.Bounded env44418 := by
  intro p hp
  have h : env44418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44417_44418 : H12AffineEnvironment.transform 9 37 env44417 = env44418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env44417 == env44418) = true)

theorem identity44418 : scanCanonicalize (H12AffineFastState.compose env44418 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound44418 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env44419 : List Nat := [2,4,8,16,32,16,8,256,512,37,2048,49,8192,277,0,8202,8200,2341,36,1,33,33,8477,3,8192,17,10509,8200,8509,2340,288,33,257,33,8216,513]

theorem envBound44419 : H12AffineFastState.Bounded env44419 := by
  intro p hp
  have h : env44419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44418_44419 : H12AffineEnvironment.transform 11 49 env44418 = env44419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44418 == env44419) = true)

theorem identity44419 : scanCanonicalize (H12AffineFastState.compose env44419 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound44419 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44420 : List Nat := [2,4,8,16,32,16,8,256,512,37,2048,49,2349,277,0,2343,2341,2341,36,1,33,33,2096,3,2349,17,32,2341,2064,2340,288,33,257,33,2357,513]

theorem envBound44420 : H12AffineFastState.Bounded env44420 := by
  intro p hp
  have h : env44420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44419_44420 : H12AffineEnvironment.transform 12 2349 env44419 = env44420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env44419 == env44420) = true)

theorem identity44420 : scanCanonicalize (H12AffineFastState.compose env44420 (packedSelected [2,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound44420 : packedSelected [2,10,15] rootPS < 2^1333 := by decide +kernel

def env44421 : List Nat := [2,4,8,16,32,16,8,256,512,37,33,49,268,277,0,262,260,260,36,1,33,33,17,3,268,17,32,260,49,261,288,33,257,33,276,513]

theorem envBound44421 : H12AffineFastState.Bounded env44421 := by
  intro p hp
  have h : env44421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44420_44421 : H12AffineEnvironment.transform 10 33 env44420 = env44421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env44420 == env44421) = true)

theorem identity44421 : scanCanonicalize (H12AffineFastState.compose env44421 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44422 : List Nat := [2,4,8,16,32,16,8,4,512,37,33,49,8,17,0,2,0,0,36,1,33,33,17,3,8,17,32,0,49,1,36,33,5,33,16,513]

theorem envBound44422 : H12AffineFastState.Bounded env44422 := by
  intro p hp
  have h : env44422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44421_44422 : H12AffineEnvironment.transform 7 4 env44421 = env44422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44421 == env44422) = true)

theorem identity44422 : scanCanonicalize (H12AffineFastState.compose env44422 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44422 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44423 : List Nat := [2,4,8,16,32,16,8,4,0,37,33,49,8,17,0,2,0,0,36,1,33,33,17,3,8,17,32,0,49,1,36,33,5,33,16,1]

theorem envBound44423 : H12AffineFastState.Bounded env44423 := by
  intro p hp
  have h : env44423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44422_44423 : H12AffineEnvironment.transform 8 0 env44422 = env44423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44422 == env44423) = true)

theorem identity44423 : scanCanonicalize (H12AffineFastState.compose env44423 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44423 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44424 : List Nat := [2,4,8,1,32,1,8,4,0,37,33,32,8,0,0,2,0,0,36,1,33,33,0,3,8,0,32,0,32,1,36,33,5,33,1,1]

theorem envBound44424 : H12AffineFastState.Bounded env44424 := by
  intro p hp
  have h : env44424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44423_44424 : H12AffineEnvironment.transform 3 1 env44423 = env44424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44423 == env44424) = true)

theorem identity44424 : scanCanonicalize (H12AffineFastState.compose env44424 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44425 : List Nat := [2,4,8,1,0,1,8,4,0,5,1,0,8,0,0,2,0,0,4,1,1,1,0,3,8,0,0,0,0,1,4,1,5,1,1,1]

theorem envBound44425 : H12AffineFastState.Bounded env44425 := by
  intro p hp
  have h : env44425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44424_44425 : H12AffineEnvironment.transform 4 0 env44424 = env44425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44424 == env44425) = true)

def env44426 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56357,1025,32769,4113,33,119967,21762,8328,16,171417,115102,102799,247995,1420,73891,257,21792,46212,74251]

theorem envBound44426 : H12AffineFastState.Bounded env44426 := by
  intro p hp
  have h : env44426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44411_44426 : H12AffineEnvironment.transform 5 17 env44411 = env44426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44411 == env44426) = true)

theorem identity44426 : scanCanonicalize (H12AffineFastState.compose env44426 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound44426 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env44427 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,57628,56357,1025,32769,4113,33,119967,21762,8328,16,31877,115102,102799,76199,1420,73891,257,21792,46212,74251]

theorem envBound44427 : H12AffineFastState.Bounded env44427 := by
  intro p hp
  have h : env44427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44426_44427 : H12AffineEnvironment.transform 16 57628 env44426 = env44427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env44426 == env44427) = true)

theorem identity44427 : scanCanonicalize (H12AffineFastState.compose env44427 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound44427 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env44428 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,65536,5392,10281,1025,29709,4113,33,73875,21762,8328,16,31877,79250,91523,76199,1420,73891,257,21792,16520,74251]

theorem envBound44428 : H12AffineFastState.Bounded env44428 := by
  intro p hp
  have h : env44428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44427_44428 : H12AffineEnvironment.transform 14 29708 env44427 = env44428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env44427 == env44428) = true)

theorem identity44428 : scanCanonicalize (H12AffineFastState.compose env44428 (packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44428 : packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env44429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8460,65536,5392,10281,1025,8461,4113,33,73875,2,8328,16,10629,79250,77955,76199,1420,73891,257,32,5512,74251]

theorem envBound44429 : H12AffineFastState.Bounded env44429 := by
  intro p hp
  have h : env44429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44428_44429 : H12AffineEnvironment.transform 13 5376 env44428 = env44429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44428 == env44429) = true)

theorem identity44429 : scanCanonicalize (H12AffineFastState.compose env44429 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44429 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44430 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,1,65536,5392,2340,1025,0,4113,33,65950,2,389,16,2184,70815,70030,67754,1420,65966,257,32,5512,66310]

theorem envBound44430 : H12AffineFastState.Bounded env44430 := by
  intro p hp
  have h : env44430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44429_44430 : H12AffineEnvironment.transform 12 269 env44429 = env44430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44429 == env44430) = true)

theorem identity44430 : scanCanonicalize (H12AffineFastState.compose env44430 (packedSelected [1,3,5,8,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound44430 : packedSelected [1,3,5,8,14,16,17] rootPS < 2^1333 := by decide +kernel

def env44431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4113,33,152,2,389,16,2184,5529,4232,2476,1420,168,257,32,5512,512]

theorem envBound44431 : H12AffineFastState.Bounded env44431 := by
  intro p hp
  have h : env44431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44430_44431 : H12AffineEnvironment.transform 15 262 env44430 = env44431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env44430 == env44431) = true)

theorem identity44431 : scanCanonicalize (H12AffineFastState.compose env44431 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound44431 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44432 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4113,33,49,2,300,16,2081,5424,4129,2309,1317,1,257,32,5409,512]

theorem envBound44432 : H12AffineFastState.Bounded env44432 := by
  intro p hp
  have h : env44432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44431_44432 : H12AffineEnvironment.transform 6 41 env44431 = env44432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env44431 == env44432) = true)

theorem identity44432 : scanCanonicalize (H12AffineFastState.compose env44432 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound44432 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44433 : List Nat := [2,4,8,16,32,17,41,256,512,305,2048,4096,269,4145,1,262,4129,2340,304,0,4113,33,49,2,300,16,2081,4097,4129,2309,20,1,257,32,4112,512]

theorem envBound44433 : H12AffineFastState.Bounded env44433 := by
  intro p hp
  have h : env44433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44432_44433 : H12AffineEnvironment.transform 9 305 env44432 = env44433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env44432 == env44433) = true)

theorem identity44433 : scanCanonicalize (H12AffineFastState.compose env44433 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound44433 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44434 : List Nat := [2,4,8,16,32,17,41,256,512,305,522,4096,269,4145,1,262,4129,814,304,0,4113,33,49,2,300,16,555,4097,4129,783,20,1,257,32,4112,512]

theorem envBound44434 : H12AffineFastState.Bounded env44434 := by
  intro p hp
  have h : env44434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44433_44434 : H12AffineEnvironment.transform 10 522 env44433 = env44434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env44433 == env44434) = true)

theorem identity44434 : scanCanonicalize (H12AffineFastState.compose env44434 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44434 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env44435 : List Nat := [2,4,8,16,32,17,41,37,512,20,522,4096,40,4145,1,35,4129,523,21,0,4113,33,49,2,9,16,555,4097,4129,554,20,1,36,32,4112,512]

theorem envBound44435 : H12AffineFastState.Bounded env44435 := by
  intro p hp
  have h : env44435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44434_44435 : H12AffineEnvironment.transform 7 37 env44434 = env44435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44434 == env44435) = true)

theorem identity44435 : scanCanonicalize (H12AffineFastState.compose env44435 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound44435 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44436 : List Nat := [2,4,8,16,32,17,41,37,60,20,54,4096,40,4145,1,35,4129,55,21,0,4113,33,49,2,9,16,23,4097,4129,22,20,1,36,32,4112,60]

theorem envBound44436 : H12AffineFastState.Bounded env44436 := by
  intro p hp
  have h : env44436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44435_44436 : H12AffineEnvironment.transform 8 60 env44435 = env44436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env44435 == env44436) = true)

theorem identity44436 : scanCanonicalize (H12AffineFastState.compose env44436 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound44436 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env44437 : List Nat := [2,4,8,14,32,15,41,37,34,10,40,4096,40,4143,1,35,4129,41,11,0,4111,33,47,2,9,14,9,4097,4129,8,10,1,36,32,4110,34]

theorem envBound44437 : H12AffineFastState.Bounded env44437 := by
  intro p hp
  have h : env44437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44436_44437 : H12AffineEnvironment.transform 3 14 env44436 = env44437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env44436 == env44437) = true)

def env44438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,4194304,8388608,8487373,8328,65,4365753,8393985,8406289,8526965,1500,12645452,257,21792,46212,74250]

theorem envBound44438 : H12AffineFastState.Bounded env44438 := by
  intro p hp
  have h : env44438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44386_44438 : H12AffineEnvironment.transform 20 4161 env44386 = env44438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44386 == env44438) = true)

def env44439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,32,8388608,8487373,8328,65,171417,8393985,8406289,8526965,1500,8451180,257,21792,46212,74250]

theorem envBound44439 : H12AffineFastState.Bounded env44439 := by
  intro p hp
  have h : env44439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44438_44439 : H12AffineEnvironment.transform 21 32 env44438 = env44439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44438 == env44439) = true)

theorem identity44439 : scanCanonicalize (H12AffineFastState.compose env44439 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44439 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4161,32,8388608,8430022,8328,65,171417,8393985,8406289,8526965,1500,8451180,257,21792,46212,513]

theorem envBound44440 : H12AffineFastState.Bounded env44440 := by
  intro p hp
  have h : env44440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44439_44440 : H12AffineEnvironment.transform 15 8203 env44439 = env44440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44439 == env44440) = true)

def env44441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1025,32769,4161,32,8388608,8430022,8328,65,56713,8393985,8406289,8412261,1500,8451180,257,21792,46212,513]

theorem envBound44441 : H12AffineFastState.Bounded env44441 := by
  intro p hp
  have h : env44441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44440_44441 : H12AffineEnvironment.transform 16 16400 env44440 = env44441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env44440 == env44441) = true)

def env44442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1025,32769,4161,32,20480,61894,8328,65,56713,17665,5393,3173,1500,42092,257,21792,46212,513]

theorem envBound44442 : H12AffineFastState.Bounded env44442 := by
  intro p hp
  have h : env44442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44441_44442 : H12AffineEnvironment.transform 22 20480 env44441 = env44442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env44441 == env44442) = true)

theorem identity44442 : scanCanonicalize (H12AffineFastState.compose env44442 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9364) := by decide +kernel

theorem selectedBound44442 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env44443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9364,8203,16400,30944,1025,9365,4161,32,20480,21842,8328,65,31005,17665,5393,3173,1500,248,257,21792,4112,513]

theorem envBound44443 : H12AffineFastState.Bounded env44443 := by
  intro p hp
  have h : env44443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44442_44443 : H12AffineEnvironment.transform 14 9364 env44442 = env44443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9364 env44442 == env44443) = true)

theorem identity44443 : scanCanonicalize (H12AffineFastState.compose env44443 (packedSelected [0,1,3,7,20,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound44443 : packedSelected [0,1,3,7,20,24,28] rootPS < 2^1333 := by decide +kernel

def env44444 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,8660,8203,16400,30944,321,8661,4161,32,20480,20498,8328,65,31005,16449,4177,2341,156,248,257,20576,4112,513]

theorem envBound44444 : H12AffineFastState.Bounded env44444 := by
  intro p hp
  have h : env44444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44443_44444 : H12AffineEnvironment.transform 9 320 env44443 = env44444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44443 == env44444) = true)

theorem identity44444 : scanCanonicalize (H12AffineFastState.compose env44444 (packedSelected [0,1,5,7,8,18,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound44444 : packedSelected [0,1,5,7,8,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44445 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,8192,16384,8460,8203,16400,30776,321,8461,4161,32,20480,20498,8272,65,31005,16449,4177,2341,68,32,257,20576,4112,513]

theorem envBound44445 : H12AffineFastState.Bounded env44445 := by
  intro p hp
  have h : env44445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44444_44445 : H12AffineEnvironment.transform 6 88 env44444 = env44445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env44444 == env44445) = true)

theorem identity44445 : scanCanonicalize (H12AffineFastState.compose env44445 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound44445 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44446 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,8192,12620,8460,8203,12636,2420,321,8461,4161,32,8524,8542,8272,65,2129,12557,4177,2341,68,32,257,8492,4112,513]

theorem envBound44446 : H12AffineFastState.Bounded env44446 := by
  intro p hp
  have h : env44446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44445_44446 : H12AffineEnvironment.transform 13 12620 env44445 = env44446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env44445 == env44446) = true)

theorem identity44446 : scanCanonicalize (H12AffineFastState.compose env44446 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44446 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44447 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,349,4113,81,342,4097,2420,321,80,4161,32,17,3,269,65,2129,4176,4177,2341,68,32,257,113,4112,513]

theorem envBound44447 : H12AffineFastState.Bounded env44447 := by
  intro p hp
  have h : env44447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44446_44447 : H12AffineEnvironment.transform 12 349 env44446 = env44447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44446 == env44447) = true)

theorem identity44447 : scanCanonicalize (H12AffineFastState.compose env44447 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44447 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env44448 : List Nat := [2,4,8,16,32,64,88,116,512,52,2048,4096,41,4113,81,34,4097,2048,53,80,4161,32,17,3,121,65,2129,4176,4177,2129,68,32,117,113,4112,513]

theorem envBound44448 : H12AffineFastState.Bounded env44448 := by
  intro p hp
  have h : env44448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44447_44448 : H12AffineEnvironment.transform 7 116 env44447 = env44448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44447 == env44448) = true)

theorem identity44448 : scanCanonicalize (H12AffineFastState.compose env44448 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44448 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44449 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4113,0,34,4097,2048,53,1,4112,32,17,3,40,16,2048,4097,4096,2048,21,32,36,32,4112,513]

theorem envBound44449 : H12AffineFastState.Bounded env44449 := by
  intro p hp
  have h : env44449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44448_44449 : H12AffineEnvironment.transform 5 17 env44448 = env44449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44448 == env44449) = true)

theorem identity44449 : scanCanonicalize (H12AffineFastState.compose env44449 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound44449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44450 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,4096,41,4113,0,34,4097,528,53,1,4112,32,17,3,40,16,528,4097,4096,528,21,32,36,32,4112,513]

theorem envBound44450 : H12AffineFastState.Bounded env44450 := by
  intro p hp
  have h : env44450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44449_44450 : H12AffineEnvironment.transform 10 528 env44449 = env44450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env44449 == env44450) = true)

theorem identity44450 : scanCanonicalize (H12AffineFastState.compose env44450 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound44450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44451 : List Nat := [2,4,8,16,32,17,9,37,10,52,26,4096,41,4113,0,34,4097,26,53,1,4112,32,17,3,40,16,26,4097,4096,26,21,32,36,32,4112,11]

theorem envBound44451 : H12AffineFastState.Bounded env44451 := by
  intro p hp
  have h : env44451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44450_44451 : H12AffineEnvironment.transform 8 10 env44450 = env44451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env44450 == env44451) = true)

def env44452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1025,32769,4161,32,20481,61895,8328,65,56713,17664,5392,3172,1500,42093,257,21792,46212,513]

theorem envBound44452 : H12AffineFastState.Bounded env44452 := by
  intro p hp
  have h : env44452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44441_44452 : H12AffineEnvironment.transform 22 20481 env44441 = env44452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env44441 == env44452) = true)

theorem identity44452 : scanCanonicalize (H12AffineFastState.compose env44452 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound44452 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env44453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9245,8203,16400,30825,1025,9244,4161,32,20481,21978,8328,65,31124,17664,5392,3172,1500,112,257,21792,4249,513]

theorem envBound44453 : H12AffineFastState.Bounded env44453 := by
  intro p hp
  have h : env44453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44452_44453 : H12AffineEnvironment.transform 14 9245 env44452 = env44453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env44452 == env44453) = true)

theorem identity44453 : scanCanonicalize (H12AffineFastState.compose env44453 (packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound44453 : packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS < 2^1333 := by decide +kernel

def env44454 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,16384,8540,8203,16400,30825,320,8541,4161,32,20481,20635,8328,65,31124,16449,4177,2341,157,112,257,20577,4249,513]

theorem envBound44454 : H12AffineFastState.Bounded env44454 := by
  intro p hp
  have h : env44454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44453_44454 : H12AffineEnvironment.transform 9 321 env44453 = env44454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44453 == env44454) = true)

theorem identity44454 : scanCanonicalize (H12AffineFastState.compose env44454 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44454 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env44455 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,16384,8540,8203,16400,30825,320,8541,4161,32,20481,20499,8192,65,31004,16449,4177,2341,21,112,257,20577,4113,513]

theorem envBound44455 : H12AffineFastState.Bounded env44455 := by
  intro p hp
  have h : env44455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44454_44455 : H12AffineEnvironment.transform 6 8 env44454 = env44455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44454 == env44455) = true)

theorem identity44455 : scanCanonicalize (H12AffineFastState.compose env44455 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound44455 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env44456 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,12621,8540,8203,12637,2340,320,8541,4161,32,8524,8542,8192,65,2129,12556,4177,2341,21,112,257,8492,4113,513]

theorem envBound44456 : H12AffineFastState.Bounded env44456 := by
  intro p hp
  have h : env44456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44455_44456 : H12AffineEnvironment.transform 13 12621 env44455 = env44456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env44455 == env44456) = true)

theorem identity44456 : scanCanonicalize (H12AffineFastState.compose env44456 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44456 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44457 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,269,4160,81,262,4176,2340,320,80,4161,32,65,83,269,65,2129,4097,4177,2341,21,112,257,33,4113,513]

theorem envBound44457 : H12AffineFastState.Bounded env44457 := by
  intro p hp
  have h : env44457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44456_44457 : H12AffineEnvironment.transform 12 269 env44456 = env44457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44456 == env44457) = true)

theorem identity44457 : scanCanonicalize (H12AffineFastState.compose env44457 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound44457 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env44458 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2577,269,2641,81,262,2625,2340,320,80,2640,32,65,83,269,65,2129,2576,2624,2341,21,112,257,33,2560,513]

theorem envBound44458 : H12AffineFastState.Bounded env44458 := by
  intro p hp
  have h : env44458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44457_44458 : H12AffineEnvironment.transform 11 2577 env44457 = env44458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env44457 == env44458) = true)

theorem identity44458 : scanCanonicalize (H12AffineFastState.compose env44458 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44458 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env44459 : List Nat := [2,4,8,16,1,64,8,256,512,321,2048,2577,269,2641,81,262,2625,2309,320,80,2640,1,65,83,269,65,2129,2576,2624,2308,21,81,257,0,2560,513]

theorem envBound44459 : H12AffineFastState.Bounded env44459 := by
  intro p hp
  have h : env44459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44458_44459 : H12AffineEnvironment.transform 4 1 env44458 = env44459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44458 == env44459) = true)

theorem identity44459 : scanCanonicalize (H12AffineFastState.compose env44459 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound44459 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env44460 : List Nat := [2,4,8,16,1,64,8,256,512,321,276,773,269,837,81,262,853,17,320,80,836,1,65,83,269,65,325,772,852,16,21,81,257,0,788,513]

theorem envBound44460 : H12AffineFastState.Bounded env44460 := by
  intro p hp
  have h : env44460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44459_44460 : H12AffineEnvironment.transform 10 276 env44459 = env44460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env44459 == env44460) = true)

theorem identity44460 : scanCanonicalize (H12AffineFastState.compose env44460 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44460 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44461 : List Nat := [2,4,8,16,1,64,8,4,512,69,16,513,9,577,81,2,593,17,68,80,576,1,65,83,9,65,65,512,592,16,21,81,5,0,528,513]

theorem envBound44461 : H12AffineFastState.Bounded env44461 := by
  intro p hp
  have h : env44461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44460_44461 : H12AffineEnvironment.transform 7 4 env44460 = env44461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44460 == env44461) = true)

theorem identity44461 : scanCanonicalize (H12AffineFastState.compose env44461 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound44461 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env44462 : List Nat := [2,4,8,16,1,0,8,4,512,5,16,513,9,513,17,2,529,17,4,16,512,1,1,19,9,1,1,512,528,16,21,17,5,0,528,513]

theorem envBound44462 : H12AffineFastState.Bounded env44462 := by
  intro p hp
  have h : env44462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44461_44462 : H12AffineEnvironment.transform 5 0 env44461 = env44462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env44461 == env44462) = true)

def env44463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56436,1025,32769,4161,32,8388608,8430022,8328,65,56712,8393985,8406289,8412260,1500,8451180,257,21792,46212,513]

theorem envBound44463 : H12AffineFastState.Bounded env44463 := by
  intro p hp
  have h : env44463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44440_44463 : H12AffineEnvironment.transform 16 16401 env44440 = env44463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env44440 == env44463) = true)

theorem identity44463 : scanCanonicalize (H12AffineFastState.compose env44463 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound44463 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56436,1025,32769,4161,32,17,41431,8328,65,56712,5392,17664,23669,1500,62589,257,21792,46212,513]

theorem envBound44464 : H12AffineFastState.Bounded env44464 := by
  intro p hp
  have h : env44464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44463_44464 : H12AffineEnvironment.transform 22 17 env44463 = env44464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env44463 == env44464) = true)

theorem identity44464 : scanCanonicalize (H12AffineFastState.compose env44464 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44464 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56436,1025,32769,4161,32,17,41311,8192,65,56576,5392,17664,23669,1364,62589,257,21792,46092,513]

theorem envBound44465 : H12AffineFastState.Bounded env44465 := by
  intro p hp
  have h : env44465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44464_44465 : H12AffineEnvironment.transform 6 8 env44464 = env44465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44464 == env44465) = true)

theorem identity44465 : scanCanonicalize (H12AffineFastState.compose env44465 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44465 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,5392,35189,1025,32769,4161,32,17,41311,8192,65,34817,5392,4097,2420,1364,41340,257,33,46092,513]

theorem envBound44466 : H12AffineFastState.Bounded env44466 := by
  intro p hp
  have h : env44466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44465_44466 : H12AffineEnvironment.transform 13 5377 env44465 = env44466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44465 == env44466) = true)

theorem identity44466 : scanCanonicalize (H12AffineFastState.compose env44466 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44466 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,343,5392,35189,1025,32769,4161,32,17,32771,348,65,34817,5392,4097,2420,1364,32800,257,33,38224,513]

theorem envBound44467 : H12AffineFastState.Bounded env44467 := by
  intro p hp
  have h : env44467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44466_44467 : H12AffineEnvironment.transform 12 348 env44466 = env44467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44466 == env44467) = true)

theorem identity44467 : scanCanonicalize (H12AffineFastState.compose env44467 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound44467 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,81,343,5392,2340,1025,80,4161,32,17,82,348,65,2128,5392,4097,2420,1364,113,257,33,5377,513]

theorem envBound44468 : H12AffineFastState.Bounded env44468 := by
  intro p hp
  have h : env44468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44467_44468 : H12AffineEnvironment.transform 14 81 env44467 = env44468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env44467 == env44468) = true)

def env44469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,8388608,8487373,8328,65,171416,8393985,8406289,8526965,1500,8451181,257,21792,46212,74250]

theorem envBound44469 : H12AffineFastState.Bounded env44469 := by
  intro p hp
  have h : env44469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44438_44469 : H12AffineEnvironment.transform 21 33 env44438 = env44469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44438 == env44469) = true)

theorem identity44469 : scanCanonicalize (H12AffineFastState.compose env44469 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound44469 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,73754,41431,8328,65,171416,79131,91403,212079,1500,119927,257,21792,46212,74250]

theorem envBound44470 : H12AffineFastState.Bounded env44470 := by
  intro p hp
  have h : env44470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44469_44470 : H12AffineEnvironment.transform 22 73754 env44469 = env44470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env44469 == env44470) = true)

def env44471 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,73754,41123,8328,65,171244,78959,91263,212079,1192,119927,117,21588,46212,74250]

theorem envBound44471 : H12AffineFastState.Bounded env44471 := by
  intro p hp
  have h : env44471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44470_44471 : H12AffineEnvironment.transform 7 116 env44470 = env44471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44470 == env44471) = true)

theorem identity44471 : scanCanonicalize (H12AffineFastState.compose env44471 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44471 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44472 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4161,33,17,41123,8328,65,171244,5220,17524,138340,1192,62588,117,21588,46212,513]

theorem envBound44472 : H12AffineFastState.Bounded env44472 := by
  intro p hp
  have h : env44472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44471_44472 : H12AffineEnvironment.transform 15 8203 env44471 = env44472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44471 == env44472) = true)

theorem identity44472 : scanCanonicalize (H12AffineFastState.compose env44472 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound44472 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44473 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4161,33,17,41082,8273,65,171061,5220,17524,138340,1137,62588,117,21588,46173,513]

theorem envBound44473 : H12AffineFastState.Bounded env44473 := by
  intro p hp
  have h : env44473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44472_44473 : H12AffineEnvironment.transform 6 89 env44472 = env44473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env44472 == env44473) = true)

theorem identity44473 : scanCanonicalize (H12AffineFastState.compose env44473 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44473 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env44474 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,0,8203,131072,23668,1025,1,4161,33,17,8314,8273,65,138293,5220,17524,138340,1137,29820,117,21588,13405,513]

theorem envBound44474 : H12AffineFastState.Bounded env44474 := by
  intro p hp
  have h : env44474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44473_44474 : H12AffineEnvironment.transform 14 0 env44473 = env44474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44473 == env44474) = true)

theorem identity44474 : scanCanonicalize (H12AffineFastState.compose env44474 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 24680) := by decide +kernel

theorem selectedBound44474 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env44475 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,0,8203,24680,23668,1025,1,4161,33,17,8314,8273,65,31837,5220,17524,31756,1137,29820,117,21588,13405,513]

theorem envBound44475 : H12AffineFastState.Bounded env44475 := by
  intro p hp
  have h : env44475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44474_44475 : H12AffineEnvironment.transform 16 24680 env44474 = env44475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24680 env44474 == env44475) = true)

theorem identity44475 : scanCanonicalize (H12AffineFastState.compose env44475 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound44475 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env44476 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,5157,0,8203,13389,2129,1025,1,4161,33,17,8314,8273,65,10360,5220,4177,10281,1137,8281,117,113,13405,513]

theorem envBound44476 : H12AffineFastState.Bounded env44476 := by
  intro p hp
  have h : env44476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44475_44476 : H12AffineEnvironment.transform 13 5157 env44475 = env44476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env44475 == env44476) = true)

theorem identity44476 : scanCanonicalize (H12AffineFastState.compose env44476 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44476 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env44477 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,0,8203,13340,2048,1025,1,4112,33,17,8235,8192,16,10281,5173,4096,10281,1056,8200,36,32,13324,513]

theorem envBound44477 : H12AffineFastState.Bounded env44477 := by
  intro p hp
  have h : env44477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44476_44477 : H12AffineEnvironment.transform 5 17 env44476 = env44477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44476 == env44477) = true)

theorem identity44477 : scanCanonicalize (H12AffineFastState.compose env44477 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44477 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44478 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5173,2048,1025,1,4112,33,17,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound44478 : H12AffineFastState.Bounded env44478 := by
  intro p hp
  have h : env44478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44477_44478 : H12AffineEnvironment.transform 12 41 env44477 = env44478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44477 == env44478) = true)

def env44479 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,73754,41122,8328,65,171245,78958,91262,212079,1193,119927,116,21589,46212,74250]

theorem envBound44479 : H12AffineFastState.Bounded env44479 := by
  intro p hp
  have h : env44479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44470_44479 : H12AffineEnvironment.transform 7 117 env44470 = env44479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44470 == env44479) = true)

def env44480 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,131072,56324,1025,32769,4145,33,73754,41122,8328,49,171165,78878,91150,211999,1193,119815,4,21541,46212,74250]

theorem envBound44480 : H12AffineFastState.Bounded env44480 := by
  intro p hp
  have h : env44480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44479_44480 : H12AffineEnvironment.transform 5 48 env44479 = env44480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env44479 == env44480) = true)

theorem identity44480 : scanCanonicalize (H12AffineFastState.compose env44480 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 81971) := by decide +kernel

theorem selectedBound44480 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env44481 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,81971,56324,1025,32769,4145,33,73754,41122,8328,49,122030,78878,91150,31788,1193,119815,4,21541,46212,74250]

theorem envBound44481 : H12AffineFastState.Bounded env44481 := by
  intro p hp
  have h : env44481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44480_44481 : H12AffineEnvironment.transform 16 81971 env44480 = env44481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 81971 env44480 == env44481) = true)

theorem identity44481 : scanCanonicalize (H12AffineFastState.compose env44481 (packedSelected [0,2,4,5,6,8,9,11,17,18,20,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21542) := by decide +kernel

theorem selectedBound44481 : packedSelected [0,2,4,5,6,8,9,11,17,18,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44482 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,21542,5141,56324,1025,32769,4145,33,29756,41122,8328,49,34952,24632,12328,31788,1193,32801,4,21541,46212,30252]

theorem envBound44482 : H12AffineFastState.Bounded env44482 := by
  intro p hp
  have h : env44482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44481_44482 : H12AffineEnvironment.transform 15 21542 env44481 = env44482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21542 env44481 == env44482) = true)

theorem identity44482 : scanCanonicalize (H12AffineFastState.compose env44482 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound44482 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env44483 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,8232,21542,5141,31788,1025,8233,4145,33,29756,138,8328,49,10400,24632,12328,31788,1193,8201,4,21541,5292,30252]

theorem envBound44483 : H12AffineFastState.Bounded env44483 := by
  intro p hp
  have h : env44483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44482_44483 : H12AffineEnvironment.transform 14 8232 env44482 = env44483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env44482 == env44483) = true)

theorem identity44483 : scanCanonicalize (H12AffineFastState.compose env44483 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5261) := by decide +kernel

theorem selectedBound44483 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44484 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,5261,8232,171,5141,10401,1025,8233,4145,33,8369,138,8328,49,10400,13493,12328,10401,1193,8201,4,168,5292,8865]

theorem envBound44484 : H12AffineFastState.Bounded env44484 := by
  intro p hp
  have h : env44484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44483_44484 : H12AffineEnvironment.transform 13 5261 env44483 = env44484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5261 env44483 == env44484) = true)

theorem identity44484 : scanCanonicalize (H12AffineFastState.compose env44484 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound44484 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44485 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,9,5261,33,171,5141,2216,1025,32,4145,33,184,138,129,49,2217,5308,4129,2216,1193,0,4,168,5292,680]

theorem envBound44485 : H12AffineFastState.Bounded env44485 := by
  intro p hp
  have h : env44485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44484_44485 : H12AffineEnvironment.transform 12 9 env44484 = env44485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env44484 == env44485) = true)

theorem identity44485 : scanCanonicalize (H12AffineFastState.compose env44485 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44485 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env44486 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,9,5125,33,35,5141,2080,1025,32,4145,33,48,2,9,49,2081,5172,4129,2080,1057,0,4,32,5156,544]

theorem envBound44486 : H12AffineFastState.Bounded env44486 := by
  intro p hp
  have h : env44486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44485_44486 : H12AffineEnvironment.transform 6 8 env44485 = env44486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44485 == env44486) = true)

theorem identity44486 : scanCanonicalize (H12AffineFastState.compose env44486 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44486 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44487 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,5125,0,2,5141,2049,1025,1,4112,0,17,2,9,16,2048,5141,4096,2049,1024,0,4,1,5125,513]

theorem envBound44487 : H12AffineFastState.Bounded env44487 := by
  intro p hp
  have h : env44487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44486_44487 : H12AffineEnvironment.transform 4 1 env44486 = env44487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44486 == env44487) = true)

def env44488 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,131072,56325,1025,32769,4144,33,73754,41122,8328,48,171164,78879,91151,211998,1193,119814,5,21540,46212,74250]

theorem envBound44488 : H12AffineFastState.Bounded env44488 := by
  intro p hp
  have h : env44488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44479_44488 : H12AffineEnvironment.transform 5 49 env44479 = env44488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env44479 == env44488) = true)

theorem identity44488 : scanCanonicalize (H12AffineFastState.compose env44488 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 111767) := by decide +kernel

theorem selectedBound44488 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env44489 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,111767,56325,1025,32769,4144,33,73754,41122,8328,48,75787,78879,91151,34953,1193,119814,5,21540,46212,74250]

theorem envBound44489 : H12AffineFastState.Bounded env44489 := by
  intro p hp
  have h : env44489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44488_44489 : H12AffineEnvironment.transform 16 111767 env44488 = env44489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111767 env44488 == env44489) = true)

theorem identity44489 : scanCanonicalize (H12AffineFastState.compose env44489 (packedSelected [3,4,5,8,20,22,23,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound44489 : packedSelected [3,4,5,8,20,22,23,28,32] rootPS < 2^1333 := by decide +kernel

def env44490 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,29831,49168,56325,1025,32769,4144,33,21661,41122,8328,48,23692,16536,4232,34953,1193,41089,5,21540,46212,22157]

theorem envBound44490 : H12AffineFastState.Bounded env44490 := by
  intro p hp
  have h : env44490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44489_44490 : H12AffineEnvironment.transform 15 29831 env44489 = env44490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env44489 == env44490) = true)

theorem identity44490 : scanCanonicalize (H12AffineFastState.compose env44490 (packedSelected [0,5,6,7,9,11,12,15,19,20,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound44490 : packedSelected [0,5,6,7,9,11,12,15,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env44491 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,160,16384,32768,21543,49168,56325,1025,32769,4144,33,21661,32770,40,48,23692,16536,4232,34953,1193,32801,5,21540,37924,22157]

theorem envBound44491 : H12AffineFastState.Bounded env44491 := by
  intro p hp
  have h : env44491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44490_44491 : H12AffineEnvironment.transform 12 160 env44490 = env44491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env44490 == env44491) = true)

theorem identity44491 : scanCanonicalize (H12AffineFastState.compose env44491 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44491 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env44492 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,160,16384,0,21543,16400,23557,1025,1,4144,33,21661,2,40,48,23692,16536,4232,2185,1193,33,5,21540,5156,22157]

theorem envBound44492 : H12AffineFastState.Bounded env44492 := by
  intro p hp
  have h : env44492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44491_44492 : H12AffineEnvironment.transform 14 0 env44491 = env44492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44491 == env44492) = true)

theorem identity44492 : scanCanonicalize (H12AffineFastState.compose env44492 (packedSelected [0,1,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5261) := by decide +kernel

theorem selectedBound44492 : packedSelected [0,1,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env44493 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,160,5261,0,170,5277,2184,1025,1,4144,33,16,2,40,48,2049,5141,4232,2185,1193,33,5,169,5156,512]

theorem envBound44493 : H12AffineFastState.Bounded env44493 := by
  intro p hp
  have h : env44493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44492_44493 : H12AffineEnvironment.transform 13 5261 env44492 = env44493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5261 env44492 == env44493) = true)

theorem identity44493 : scanCanonicalize (H12AffineFastState.compose env44493 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44493 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44494 : List Nat := [2,4,8,16,32,49,8,4,512,1024,2048,4096,40,5125,0,34,5141,2048,1025,1,4144,33,16,2,40,48,2049,5141,4096,2049,1057,33,5,33,5156,512]

theorem envBound44494 : H12AffineFastState.Bounded env44494 := by
  intro p hp
  have h : env44494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44493_44494 : H12AffineEnvironment.transform 6 8 env44493 = env44494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44493 == env44494) = true)

theorem identity44494 : scanCanonicalize (H12AffineFastState.compose env44494 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44494 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44495 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,8,5125,0,2,5141,2048,1025,1,4112,1,16,2,8,16,2049,5141,4096,2049,1025,1,5,1,5124,512]

theorem envBound44495 : H12AffineFastState.Bounded env44495 := by
  intro p hp
  have h : env44495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44494_44495 : H12AffineEnvironment.transform 4 0 env44494 = env44495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44494 == env44495) = true)

theorem identity44495 : scanCanonicalize (H12AffineFastState.compose env44495 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound44495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44496 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,17,8,1044,0,2,1028,2048,1025,1,1,1,16,2,8,16,2049,1028,17,2049,1025,1,5,1,1045,512]

theorem envBound44496 : H12AffineFastState.Bounded env44496 := by
  intro p hp
  have h : env44496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44495_44496 : H12AffineEnvironment.transform 11 17 env44495 = env44496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env44495 == env44496) = true)

theorem identity44496 : scanCanonicalize (H12AffineFastState.compose env44496 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound44496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44497 : List Nat := [2,4,8,16,0,17,8,4,512,532,2048,17,8,512,0,2,528,2048,533,1,1,1,16,2,8,16,2049,528,17,2049,533,1,5,1,513,512]

theorem envBound44497 : H12AffineFastState.Bounded env44497 := by
  intro p hp
  have h : env44497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44496_44497 : H12AffineEnvironment.transform 9 532 env44496 = env44497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env44496 == env44497) = true)

theorem identity44497 : scanCanonicalize (H12AffineFastState.compose env44497 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44497 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44498 : List Nat := [2,4,8,16,0,17,8,4,1,21,2048,17,8,1,0,2,17,2048,20,1,1,1,16,2,8,16,2049,17,17,2049,20,1,5,1,0,1]

theorem envBound44498 : H12AffineFastState.Bounded env44498 := by
  intro p hp
  have h : env44498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44497_44498 : H12AffineEnvironment.transform 8 1 env44497 = env44498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44497 == env44498) = true)

theorem identity44498 : scanCanonicalize (H12AffineFastState.compose env44498 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound44498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44499 : List Nat := [2,4,7,16,0,17,7,4,1,21,2048,17,7,1,0,2,17,2048,20,1,1,1,16,2,7,16,2049,17,17,2049,20,1,5,1,0,1]

theorem envBound44499 : H12AffineFastState.Bounded env44499 := by
  intro p hp
  have h : env44499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44498_44499 : H12AffineEnvironment.transform 2 7 env44498 = env44499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env44498 == env44499) = true)

def env44500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458872,8393984,10507600,8526964,2102684,12645453,257,21793,46213,2175562]

theorem envBound44500 : H12AffineFastState.Bounded env44500 := by
  intro p hp
  have h : env44500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44385_44500 : H12AffineEnvironment.transform 17 56437 env44385 = env44500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env44385 == env44500) = true)

def env44501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,4194304,8388608,8487373,8328,65,4365752,8393984,8406288,8526964,1500,12645453,257,21793,46213,74250]

theorem envBound44501 : H12AffineFastState.Bounded env44501 := by
  intro p hp
  have h : env44501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44500_44501 : H12AffineEnvironment.transform 20 4160 env44500 = env44501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44500 == env44501) = true)

def env44502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,8388608,8487373,8328,65,171416,8393984,8406288,8526964,1500,8451181,257,21793,46213,74250]

theorem envBound44502 : H12AffineFastState.Bounded env44502 := by
  intro p hp
  have h : env44502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44501_44502 : H12AffineEnvironment.transform 21 32 env44501 = env44502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44501 == env44502) = true)

def env44503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,152,98645,8328,65,171416,5528,17800,138476,1500,62709,257,21793,46213,74250]

theorem envBound44503 : H12AffineFastState.Bounded env44503 := by
  intro p hp
  have h : env44503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44502_44503 : H12AffineEnvironment.transform 22 152 env44502 = env44503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env44502 == env44503) = true)

theorem identity44503 : scanCanonicalize (H12AffineFastState.compose env44503 (packedSelected [1,3,4,5,7,8,9,10,12,14,15,16,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound44503 : packedSelected [1,3,4,5,7,8,9,10,12,14,15,16,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env44504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46156,56437,1025,32769,4160,32,152,98645,8328,65,10708,5528,17800,43168,1500,62709,257,21793,46213,74250]

theorem envBound44504 : H12AffineFastState.Bounded env44504 := by
  intro p hp
  have h : env44504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44503_44504 : H12AffineEnvironment.transform 16 46156 env44503 = env44504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env44503 == env44504) = true)

def env44505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46156,35189,1025,32769,4160,32,152,98645,8328,65,10708,5528,4232,43168,1500,41461,257,33,46213,74250]

theorem envBound44505 : H12AffineFastState.Bounded env44505 := by
  intro p hp
  have h : env44505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44504_44505 : H12AffineEnvironment.transform 13 5376 env44504 = env44505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44504 == env44505) = true)

theorem identity44505 : scanCanonicalize (H12AffineFastState.compose env44505 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound44505 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5528,10401,1025,8661,4160,32,152,73857,8328,65,10708,5528,4232,2420,1500,33,257,33,5457,74250]

theorem envBound44506 : H12AffineFastState.Bounded env44506 := by
  intro p hp
  have h : env44506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44505_44506 : H12AffineEnvironment.transform 14 8660 env44505 = env44506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env44505 == env44506) = true)

def env44507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,46156,35188,1025,32769,4160,32,152,98645,8328,65,10708,5528,4233,43168,1500,41460,257,32,46213,74250]

theorem envBound44507 : H12AffineFastState.Bounded env44507 := by
  intro p hp
  have h : env44507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44504_44507 : H12AffineEnvironment.transform 13 5377 env44504 = env44507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44504 == env44507) = true)

theorem identity44507 : scanCanonicalize (H12AffineFastState.compose env44507 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44507 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,5393,10281,1025,8540,4160,32,152,73736,8328,65,10708,5528,4233,2557,1500,169,257,32,5592,74250]

theorem envBound44508 : H12AffineFastState.Bounded env44508 := by
  intro p hp
  have h : env44508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44507_44508 : H12AffineEnvironment.transform 14 8541 env44507 = env44508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44507 == env44508) = true)

theorem identity44508 : scanCanonicalize (H12AffineFastState.compose env44508 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44508 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env44509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,65536,5393,2421,1025,0,4160,32,152,65876,468,65,2184,5528,4233,2557,1500,169,257,32,5592,66390]

theorem envBound44509 : H12AffineFastState.Bounded env44509 := by
  intro p hp
  have h : env44509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44508_44509 : H12AffineEnvironment.transform 12 348 env44508 = env44509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44508 == env44509) = true)

theorem identity44509 : scanCanonicalize (H12AffineFastState.compose env44509 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound44509 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env44510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,342,5393,2421,1025,0,4160,32,152,2,468,65,2184,5528,4233,2557,1500,169,257,32,5592,512]

theorem envBound44510 : H12AffineFastState.Bounded env44510 := by
  intro p hp
  have h : env44510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44509_44510 : H12AffineEnvironment.transform 15 342 env44509 = env44510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env44509 == env44510) = true)

theorem identity44510 : scanCanonicalize (H12AffineFastState.compose env44510 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44510 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5393,2421,1025,0,4160,32,16,2,348,65,2048,5392,4097,2421,1364,33,257,32,5456,512]

theorem envBound44511 : H12AffineFastState.Bounded env44511 := by
  intro p hp
  have h : env44511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44510_44511 : H12AffineEnvironment.transform 6 8 env44510 = env44511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44510 == env44511) = true)

theorem identity44511 : scanCanonicalize (H12AffineFastState.compose env44511 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound44511 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44512 : List Nat := [2,4,8,16,32,64,8,256,512,21,2048,4096,348,4372,1,342,4356,2421,20,0,4160,32,16,2,348,65,2048,4357,4097,2421,321,33,257,32,4421,512]

theorem envBound44512 : H12AffineFastState.Bounded env44512 := by
  intro p hp
  have h : env44512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44511_44512 : H12AffineEnvironment.transform 9 21 env44511 = env44512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44511 == env44512) = true)

theorem identity44512 : scanCanonicalize (H12AffineFastState.compose env44512 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound44512 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44513 : List Nat := [2,4,8,16,32,48,8,256,512,21,2048,4096,300,4372,1,294,4356,2309,20,0,4144,32,16,2,300,49,2048,4357,4097,2309,305,33,257,32,4405,512]

theorem envBound44513 : H12AffineFastState.Bounded env44513 := by
  intro p hp
  have h : env44513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44512_44513 : H12AffineEnvironment.transform 5 48 env44512 = env44513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env44512 == env44513) = true)

theorem identity44513 : scanCanonicalize (H12AffineFastState.compose env44513 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44513 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44514 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,4096,268,4372,1,262,4356,2309,20,0,4112,0,16,2,268,17,2048,4357,4097,2309,273,1,257,0,4373,512]

theorem envBound44514 : H12AffineFastState.Bounded env44514 := by
  intro p hp
  have h : env44514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44513_44514 : H12AffineEnvironment.transform 4 0 env44513 = env44514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44513 == env44514) = true)

theorem identity44514 : scanCanonicalize (H12AffineFastState.compose env44514 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound44514 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44515 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,17,268,261,1,262,277,2309,20,0,1,0,16,2,268,17,2048,276,16,2309,273,1,257,0,260,512]

theorem envBound44515 : H12AffineFastState.Bounded env44515 := by
  intro p hp
  have h : env44515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44514_44515 : H12AffineEnvironment.transform 11 17 env44514 = env44515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env44514 == env44515) = true)

theorem identity44515 : scanCanonicalize (H12AffineFastState.compose env44515 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound44515 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44516 : List Nat := [2,4,8,16,0,16,8,256,512,21,261,17,268,261,1,262,277,0,20,0,1,0,16,2,268,17,261,276,16,0,273,1,257,0,260,512]

theorem envBound44516 : H12AffineFastState.Bounded env44516 := by
  intro p hp
  have h : env44516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44515_44516 : H12AffineEnvironment.transform 10 261 env44515 = env44516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env44515 == env44516) = true)

theorem identity44516 : scanCanonicalize (H12AffineFastState.compose env44516 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44516 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44517 : List Nat := [2,4,8,16,0,16,8,5,512,21,0,17,9,0,1,3,16,0,20,0,1,0,16,2,9,17,0,17,16,0,20,1,4,0,1,512]

theorem envBound44517 : H12AffineFastState.Bounded env44517 := by
  intro p hp
  have h : env44517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44516_44517 : H12AffineEnvironment.transform 7 5 env44516 = env44517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44516 == env44517) = true)

def env44518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,153,98644,8328,65,171416,5529,17801,138477,1500,62708,257,21793,46213,74250]

theorem envBound44518 : H12AffineFastState.Bounded env44518 := by
  intro p hp
  have h : env44518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44502_44518 : H12AffineEnvironment.transform 22 153 env44502 = env44518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 153 env44502 == env44518) = true)

def env44519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1025,32769,4160,32,153,98644,8328,65,171416,5529,4233,138477,1500,41460,257,33,46213,74250]

theorem envBound44519 : H12AffineFastState.Bounded env44519 := by
  intro p hp
  have h : env44519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44518_44519 : H12AffineEnvironment.transform 13 5376 env44518 = env44519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44518 == env44519) = true)

theorem identity44519 : scanCanonicalize (H12AffineFastState.compose env44519 (packedSelected [5,8,11,18,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44519 : packedSelected [5,8,11,18,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env44520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8203,131072,35189,1025,32769,4160,32,153,41311,8328,65,171416,5529,4233,138477,1500,41460,257,33,46213,513]

theorem envBound44520 : H12AffineFastState.Bounded env44520 := by
  intro p hp
  have h : env44520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44519_44520 : H12AffineEnvironment.transform 15 8203 env44519 = env44520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44519 == env44520) = true)

theorem identity44520 : scanCanonicalize (H12AffineFastState.compose env44520 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound44520 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8203,38161,35189,1025,32769,4160,32,153,41311,8328,65,2185,5529,4233,35324,1500,41460,257,33,46213,513]

theorem envBound44521 : H12AffineFastState.Bounded env44521 := by
  intro p hp
  have h : env44521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44520_44521 : H12AffineEnvironment.transform 16 38161 env44520 = env44521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env44520 == env44521) = true)

theorem identity44521 : scanCanonicalize (H12AffineFastState.compose env44521 (packedSelected [1,2,4,5,6,8,9,14,16,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44521 : packedSelected [1,2,4,5,6,8,9,14,16,24] rootPS < 2^1333 := by decide +kernel

def env44522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,32768,342,38161,35189,1025,32769,4160,32,153,32770,469,65,2185,5529,4233,35324,1500,32937,257,33,38360,513]

theorem envBound44522 : H12AffineFastState.Bounded env44522 := by
  intro p hp
  have h : env44522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44521_44522 : H12AffineEnvironment.transform 12 349 env44521 = env44522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44521 == env44522) = true)

theorem identity44522 : scanCanonicalize (H12AffineFastState.compose env44522 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44522 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1025,0,4160,32,153,3,469,65,2185,5529,4233,2557,1500,168,257,33,5593,513]

theorem envBound44523 : H12AffineFastState.Bounded env44523 := by
  intro p hp
  have h : env44523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44522_44523 : H12AffineEnvironment.transform 14 1 env44522 = env44523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44522 == env44523) = true)

theorem identity44523 : scanCanonicalize (H12AffineFastState.compose env44523 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44523 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1025,0,4160,32,17,3,349,65,2049,5393,4097,2421,1364,32,257,33,5457,513]

theorem envBound44524 : H12AffineFastState.Bounded env44524 := by
  intro p hp
  have h : env44524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44523_44524 : H12AffineEnvironment.transform 6 8 env44523 = env44524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44523 == env44524) = true)

theorem identity44524 : scanCanonicalize (H12AffineFastState.compose env44524 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44524 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44525 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,349,4404,1,342,4388,2420,53,0,4160,32,17,3,349,65,2049,4389,4097,2421,352,32,257,33,4453,513]

theorem envBound44525 : H12AffineFastState.Bounded env44525 := by
  intro p hp
  have h : env44525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44524_44525 : H12AffineEnvironment.transform 9 52 env44524 = env44525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44524 == env44525) = true)

theorem identity44525 : scanCanonicalize (H12AffineFastState.compose env44525 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44526 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4404,1,262,4388,2340,53,0,4112,32,17,3,269,17,2049,4389,4097,2341,304,32,257,33,4405,513]

theorem envBound44526 : H12AffineFastState.Bounded env44526 := by
  intro p hp
  have h : env44526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44525_44526 : H12AffineEnvironment.transform 5 16 env44525 = env44526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44525 == env44526) = true)

theorem identity44526 : scanCanonicalize (H12AffineFastState.compose env44526 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44527 : List Nat := [2,4,8,16,32,16,8,4,512,52,2048,4096,9,4144,1,2,4128,2080,53,0,4112,32,17,3,9,17,2049,4129,4097,2081,52,32,5,33,4145,513]

theorem envBound44527 : H12AffineFastState.Bounded env44527 := by
  intro p hp
  have h : env44527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44526_44527 : H12AffineEnvironment.transform 7 4 env44526 = env44527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44526 == env44527) = true)

theorem identity44527 : scanCanonicalize (H12AffineFastState.compose env44527 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound44527 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44528 : List Nat := [2,4,8,16,32,16,8,4,512,52,2048,2608,9,2560,1,2,2576,2080,53,0,2592,32,17,3,9,17,2049,2577,2609,2081,52,32,5,33,2561,513]

theorem envBound44528 : H12AffineFastState.Bounded env44528 := by
  intro p hp
  have h : env44528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44527_44528 : H12AffineEnvironment.transform 11 2608 env44527 = env44528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env44527 == env44528) = true)

theorem identity44528 : scanCanonicalize (H12AffineFastState.compose env44528 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44528 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44529 : List Nat := [2,4,8,16,32,16,8,4,48,52,2048,2048,9,2096,1,2,2080,2080,53,0,2064,32,17,3,9,17,2049,2081,2049,2081,52,32,5,33,2097,49]

theorem envBound44529 : H12AffineFastState.Bounded env44529 := by
  intro p hp
  have h : env44529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44528_44529 : H12AffineEnvironment.transform 8 48 env44528 = env44529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44528 == env44529) = true)

theorem identity44529 : scanCanonicalize (H12AffineFastState.compose env44529 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound44529 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44530 : List Nat := [2,4,8,16,32,16,8,4,48,52,48,48,9,0,1,2,16,16,53,0,32,32,17,3,9,17,49,17,49,17,52,32,5,33,1,49]

theorem envBound44530 : H12AffineFastState.Bounded env44530 := by
  intro p hp
  have h : env44530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44529_44530 : H12AffineEnvironment.transform 10 48 env44529 = env44530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env44529 == env44530) = true)

theorem identity44530 : scanCanonicalize (H12AffineFastState.compose env44530 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44530 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env44531 : List Nat := [2,4,8,16,1,16,8,4,17,21,17,17,9,0,1,2,16,16,20,0,1,1,17,3,9,17,16,17,16,17,21,1,5,0,1,16]

theorem envBound44531 : H12AffineFastState.Bounded env44531 := by
  intro p hp
  have h : env44531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44530_44531 : H12AffineEnvironment.transform 4 1 env44530 = env44531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44530 == env44531) = true)

theorem identity44531 : scanCanonicalize (H12AffineFastState.compose env44531 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44532 : List Nat := [2,4,8,11,1,11,8,4,10,14,10,10,9,0,1,2,11,11,15,0,1,1,10,3,9,10,11,10,11,10,14,1,5,0,1,11]

theorem envBound44532 : H12AffineFastState.Bounded env44532 := by
  intro p hp
  have h : env44532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44531_44532 : H12AffineEnvironment.transform 3 11 env44531 = env44532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44531 == env44532) = true)

def env44533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1025,32769,4160,32,153,98644,8328,65,171416,5529,4232,138477,1500,41461,257,32,46213,74250]

theorem envBound44533 : H12AffineFastState.Bounded env44533 := by
  intro p hp
  have h : env44533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44518_44533 : H12AffineEnvironment.transform 13 5377 env44518 = env44533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44518 == env44533) = true)

theorem identity44533 : scanCanonicalize (H12AffineFastState.compose env44533 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44533 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1025,32769,4160,32,17,98644,8192,65,171280,5393,4096,138341,1364,41341,257,32,46093,74250]

theorem envBound44534 : H12AffineFastState.Bounded env44534 := by
  intro p hp
  have h : env44534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44533_44534 : H12AffineEnvironment.transform 6 8 env44533 = env44534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44533 == env44534) = true)

theorem identity44534 : scanCanonicalize (H12AffineFastState.compose env44534 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44534 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35188,1025,32769,4160,32,17,41311,8192,65,171280,5393,4096,138341,1364,41341,257,32,46093,513]

theorem envBound44535 : H12AffineFastState.Bounded env44535 := by
  intro p hp
  have h : env44535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44534_44535 : H12AffineEnvironment.transform 15 8203 env44534 = env44535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44534 == env44535) = true)

theorem identity44535 : scanCanonicalize (H12AffineFastState.compose env44535 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound44535 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44536 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,46156,35188,1025,32769,4160,32,17,41311,8192,65,10588,5393,4096,43049,1364,41341,257,32,46093,513]

theorem envBound44536 : H12AffineFastState.Bounded env44536 := by
  intro p hp
  have h : env44536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44535_44536 : H12AffineEnvironment.transform 16 46156 env44535 = env44536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env44535 == env44536) = true)

theorem identity44536 : scanCanonicalize (H12AffineFastState.compose env44536 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44536 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,10281,1025,8540,4160,32,17,2,8192,65,10588,5393,4096,2420,1364,32,257,32,5456,513]

theorem envBound44537 : H12AffineFastState.Bounded env44537 := by
  intro p hp
  have h : env44537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44536_44537 : H12AffineEnvironment.transform 14 8541 env44536 = env44537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44536 == env44537) = true)

theorem identity44537 : scanCanonicalize (H12AffineFastState.compose env44537 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44537 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44538 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,5393,10281,1025,8461,4113,32,17,2,8192,16,10509,5393,4096,2341,1285,32,257,32,5377,513]

theorem envBound44538 : H12AffineFastState.Bounded env44538 := by
  intro p hp
  have h : env44538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44537_44538 : H12AffineEnvironment.transform 5 17 env44537 = env44538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44537 == env44538) = true)

theorem identity44538 : scanCanonicalize (H12AffineFastState.compose env44538 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound44538 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44539 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,5377,32,295,5393,2309,1025,33,4113,32,17,2,300,16,2081,5393,4096,2341,1285,32,257,32,5377,513]

theorem envBound44539 : H12AffineFastState.Bounded env44539 := by
  intro p hp
  have h : env44539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44538_44539 : H12AffineEnvironment.transform 12 300 env44538 = env44539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env44538 == env44539) = true)

theorem identity44539 : scanCanonicalize (H12AffineFastState.compose env44539 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44539 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44540 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5156,32,2,5172,2080,1025,33,4113,32,17,2,9,16,2081,5172,4096,2048,1056,32,36,32,5156,513]

theorem envBound44540 : H12AffineFastState.Bounded env44540 := by
  intro p hp
  have h : env44540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44539_44540 : H12AffineEnvironment.transform 7 37 env44539 = env44540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44539 == env44540) = true)

theorem identity44540 : scanCanonicalize (H12AffineFastState.compose env44540 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44540 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44541 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1,4096,9,5156,32,2,5172,33,1025,33,4113,32,17,2,9,16,32,5172,4096,1,1056,32,36,32,5156,513]

theorem envBound44541 : H12AffineFastState.Bounded env44541 := by
  intro p hp
  have h : env44541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44540_44541 : H12AffineEnvironment.transform 10 1 env44540 = env44541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44540 == env44541) = true)

theorem identity44541 : scanCanonicalize (H12AffineFastState.compose env44541 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44541 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44542 : List Nat := [2,4,8,16,32,17,8,37,1,1024,1,4096,9,5156,32,2,5172,33,1025,33,4113,32,17,2,9,16,32,5172,4096,1,1056,32,36,32,5156,0]

theorem envBound44542 : H12AffineFastState.Bounded env44542 := by
  intro p hp
  have h : env44542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44541_44542 : H12AffineEnvironment.transform 8 1 env44541 = env44542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44541 == env44542) = true)

def env44543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,8388608,8487373,8328,65,171417,8393984,8406288,8526964,1500,8451180,257,21793,46213,74250]

theorem envBound44543 : H12AffineFastState.Bounded env44543 := by
  intro p hp
  have h : env44543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44501_44543 : H12AffineEnvironment.transform 21 33 env44501 = env44543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44501 == env44543) = true)

theorem identity44543 : scanCanonicalize (H12AffineFastState.compose env44543 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound44543 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,17,98780,8328,65,171417,5393,17665,138341,1500,62589,257,21793,46213,74250]

theorem envBound44544 : H12AffineFastState.Bounded env44544 := by
  intro p hp
  have h : env44544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44543_44544 : H12AffineEnvironment.transform 22 17 env44543 = env44544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env44543 == env44544) = true)

def env44545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,17,98644,8192,65,171281,5393,17665,138341,1364,62589,257,21793,46093,74250]

theorem envBound44545 : H12AffineFastState.Bounded env44545 := by
  intro p hp
  have h : env44545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44544_44545 : H12AffineEnvironment.transform 6 8 env44544 = env44545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44544 == env44545) = true)

theorem identity44545 : scanCanonicalize (H12AffineFastState.compose env44545 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44545 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env44546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4160,33,17,41311,8192,65,171281,5393,17665,138341,1364,62589,257,21793,46093,513]

theorem envBound44546 : H12AffineFastState.Bounded env44546 := by
  intro p hp
  have h : env44546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44545_44546 : H12AffineEnvironment.transform 15 8203 env44545 = env44546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44545 == env44546) = true)

theorem identity44546 : scanCanonicalize (H12AffineFastState.compose env44546 (packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44546 : packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,131072,23669,1025,1,4160,33,17,8543,8192,65,138513,5393,17665,138341,1364,29821,257,21793,13325,513]

theorem envBound44547 : H12AffineFastState.Bounded env44547 := by
  intro p hp
  have h : env44547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44546_44547 : H12AffineEnvironment.transform 14 0 env44546 = env44547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44546 == env44547) = true)

theorem identity44547 : scanCanonicalize (H12AffineFastState.compose env44547 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44547 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,131072,23669,1025,1,4160,33,17,2,349,65,138513,5393,17665,138341,1364,21792,257,21793,5456,513]

theorem envBound44548 : H12AffineFastState.Bounded env44548 := by
  intro p hp
  have h : env44548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44547_44548 : H12AffineEnvironment.transform 12 349 env44547 = env44548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44547 == env44548) = true)

theorem identity44548 : scanCanonicalize (H12AffineFastState.compose env44548 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound44548 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,5440,23669,1025,1,4160,33,17,2,349,65,2129,5393,17665,2341,1364,21792,257,21793,5456,513]

theorem envBound44549 : H12AffineFastState.Bounded env44549 := by
  intro p hp
  have h : env44549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44548_44549 : H12AffineEnvironment.transform 16 5440 env44548 = env44549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env44548 == env44549) = true)

theorem identity44549 : scanCanonicalize (H12AffineFastState.compose env44549 (packedSelected [2,6,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44549 : packedSelected [2,6,12,18] rootPS < 2^1333 := by decide +kernel

def env44550 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,5393,23588,1025,1,4113,33,17,2,268,16,2048,5393,17665,2341,1285,21792,257,21793,5377,513]

theorem envBound44550 : H12AffineFastState.Bounded env44550 := by
  intro p hp
  have h : env44550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44549_44550 : H12AffineEnvironment.transform 5 17 env44549 = env44550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44549 == env44550) = true)

theorem identity44550 : scanCanonicalize (H12AffineFastState.compose env44550 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44550 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env44551 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,0,34,5172,23588,1025,1,4113,33,17,2,41,16,2048,5172,17444,2048,1056,21509,36,21508,5156,513]

theorem envBound44551 : H12AffineFastState.Bounded env44551 := by
  intro p hp
  have h : env44551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44550_44551 : H12AffineEnvironment.transform 7 37 env44550 = env44551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44550 == env44551) = true)

theorem identity44551 : scanCanonicalize (H12AffineFastState.compose env44551 (packedSelected [2,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound44551 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env44552 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5172,2048,1025,1,4113,33,17,2,41,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound44552 : H12AffineFastState.Bounded env44552 := by
  intro p hp
  have h : env44552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44551_44552 : H12AffineEnvironment.transform 13 5156 env44551 = env44552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env44551 == env44552) = true)

def env44553 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,0,34,1028,2048,1025,1,33,33,17,2,41,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound44553 : H12AffineFastState.Bounded env44553 := by
  intro p hp
  have h : env44553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44552_44553 : H12AffineEnvironment.transform 11 48 env44552 = env44553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44552 == env44553) = true)

theorem identity44553 : scanCanonicalize (H12AffineFastState.compose env44553 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound44553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44554 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,41,1044,0,34,1028,1044,1025,1,33,33,17,2,41,16,1044,1028,48,1044,1056,33,36,32,1044,513]

theorem envBound44554 : H12AffineFastState.Bounded env44554 := by
  intro p hp
  have h : env44554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44553_44554 : H12AffineEnvironment.transform 10 1044 env44553 = env44554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env44553 == env44554) = true)

def env44555 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,32,0,34,48,32,53,1,33,33,17,2,41,16,32,48,48,32,20,33,36,32,32,513]

theorem envBound44555 : H12AffineFastState.Bounded env44555 := by
  intro p hp
  have h : env44555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44554_44555 : H12AffineEnvironment.transform 9 52 env44554 = env44555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44554 == env44555) = true)

theorem identity44555 : scanCanonicalize (H12AffineFastState.compose env44555 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44556 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,0,2,16,0,21,1,1,1,17,2,9,16,0,16,16,0,20,1,4,0,0,513]

theorem envBound44556 : H12AffineFastState.Bounded env44556 := by
  intro p hp
  have h : env44556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44555_44556 : H12AffineEnvironment.transform 4 0 env44555 = env44556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44555 == env44556) = true)

def leafEnv44556 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,0,2,16,0,21,1,1,1,17,2,21,9,1,16,0,16,16,0,20,1,4,0,5,2,0,513,1,1,0]

def active44556 : List Nat := [0,1,2,3,8]

def tree44556 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44556 : H12WitnessSearch.Good tree44556 := H12GlobalWitnessIndex.good

theorem leafIdentity44556 : H12AffineFastState.composeSystem env44556 rootObs = leafEnv44556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44556 rootObs == leafEnv44556) = true)

theorem terminalChecked44556 : H12PackedTerminal.terminalCheckFast leafEnv44556 active44556 tree44556 = true := by decide +kernel

def env44557 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,41,33,0,34,49,33,52,1,33,33,17,2,41,16,33,49,48,33,21,33,36,32,33,513]

theorem envBound44557 : H12AffineFastState.Bounded env44557 := by
  intro p hp
  have h : env44557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44554_44557 : H12AffineEnvironment.transform 9 53 env44554 = env44557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44554 == env44557) = true)

theorem identity44557 : scanCanonicalize (H12AffineFastState.compose env44557 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound44557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44558 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,41,33,0,34,49,33,52,1,33,33,17,2,41,16,33,49,48,33,21,33,36,32,33,10]

theorem envBound44558 : H12AffineFastState.Bounded env44558 := by
  intro p hp
  have h : env44558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44557_44558 : H12AffineEnvironment.transform 8 11 env44557 = env44558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env44557 == env44558) = true)

def leafEnv44558 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,41,33,0,34,49,33,52,1,33,33,17,2,20,41,1,16,33,49,48,33,21,33,36,32,5,34,33,10,1,33,0]

def active44558 : List Nat := [0,1,2,3,4]

def tree44558 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44558 : H12WitnessSearch.Good tree44558 := H12GlobalWitnessIndex.good

theorem leafIdentity44558 : H12AffineFastState.composeSystem env44558 rootObs = leafEnv44558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44558 rootObs == leafEnv44558) = true)

theorem terminalChecked44558 : H12PackedTerminal.terminalCheckFast leafEnv44558 active44558 tree44558 = true := by decide +kernel

def env44559 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,0,34,1029,2048,1025,1,32,33,17,2,41,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound44559 : H12AffineFastState.Bounded env44559 := by
  intro p hp
  have h : env44559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44552_44559 : H12AffineEnvironment.transform 11 49 env44552 = env44559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44552 == env44559) = true)

theorem identity44559 : scanCanonicalize (H12AffineFastState.compose env44559 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound44559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44560 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,41,1045,0,34,1029,32,1025,1,32,33,17,2,41,16,32,1029,49,32,1056,33,36,32,1045,513]

theorem envBound44560 : H12AffineFastState.Bounded env44560 := by
  intro p hp
  have h : env44560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44559_44560 : H12AffineEnvironment.transform 10 32 env44559 = env44560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env44559 == env44560) = true)

def env44561 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,41,33,0,34,49,32,53,1,32,33,17,2,41,16,32,49,49,32,20,33,36,32,33,513]

theorem envBound44561 : H12AffineFastState.Bounded env44561 := by
  intro p hp
  have h : env44561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44560_44561 : H12AffineEnvironment.transform 9 52 env44560 = env44561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44560 == env44561) = true)

theorem identity44561 : scanCanonicalize (H12AffineFastState.compose env44561 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44562 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,0,2,17,0,21,1,0,1,17,2,9,16,0,17,17,0,20,1,4,0,1,513]

theorem envBound44562 : H12AffineFastState.Bounded env44562 := by
  intro p hp
  have h : env44562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44561_44562 : H12AffineEnvironment.transform 4 0 env44561 = env44562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44561 == env44562) = true)

def leafEnv44562 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,0,2,17,0,21,1,0,1,17,2,21,9,1,16,0,17,17,0,20,1,4,0,5,2,1,513,1,0,0]

def active44562 : List Nat := [0,1,2,3,8]

def tree44562 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44562 : H12WitnessSearch.Good tree44562 := H12GlobalWitnessIndex.good

theorem leafIdentity44562 : H12AffineFastState.composeSystem env44562 rootObs = leafEnv44562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44562 rootObs == leafEnv44562) = true)

theorem terminalChecked44562 : H12PackedTerminal.terminalCheckFast leafEnv44562 active44562 tree44562 = true := by decide +kernel

def env44563 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,32,0,34,48,32,52,1,32,33,17,2,41,16,32,48,49,32,21,33,36,32,32,513]

theorem envBound44563 : H12AffineFastState.Bounded env44563 := by
  intro p hp
  have h : env44563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44560_44563 : H12AffineEnvironment.transform 9 53 env44560 = env44563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44560 == env44563) = true)

theorem identity44563 : scanCanonicalize (H12AffineFastState.compose env44563 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound44563 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44564 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,41,32,0,34,48,32,52,1,32,33,17,2,41,16,32,48,49,32,21,33,36,32,32,11]

theorem envBound44564 : H12AffineFastState.Bounded env44564 := by
  intro p hp
  have h : env44564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44563_44564 : H12AffineEnvironment.transform 8 10 env44563 = env44564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env44563 == env44564) = true)

def leafEnv44564 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,41,32,0,34,48,32,52,1,32,33,17,2,20,41,1,16,32,48,49,32,21,33,36,32,5,34,32,11,1,32,0]

def active44564 : List Nat := [0,1,2,3,4]

def tree44564 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44564 : H12WitnessSearch.Good tree44564 := H12GlobalWitnessIndex.good

theorem leafIdentity44564 : H12AffineFastState.composeSystem env44564 rootObs = leafEnv44564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44564 rootObs == leafEnv44564) = true)

theorem terminalChecked44564 : H12PackedTerminal.terminalCheckFast leafEnv44564 active44564 tree44564 = true := by decide +kernel

def env44565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,17,98645,8193,65,171280,5393,17665,138341,1365,62589,257,21793,46092,74250]

theorem envBound44565 : H12AffineFastState.Bounded env44565 := by
  intro p hp
  have h : env44565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44544_44565 : H12AffineEnvironment.transform 6 9 env44544 = env44565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44544 == env44565) = true)

theorem identity44565 : scanCanonicalize (H12AffineFastState.compose env44565 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44565 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32040,1025,8540,4160,33,17,73736,8193,65,146509,5393,17665,138341,1365,21792,257,21793,5457,74250]

theorem envBound44566 : H12AffineFastState.Bounded env44566 := by
  intro p hp
  have h : env44566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44565_44566 : H12AffineEnvironment.transform 14 8541 env44565 = env44566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44565 == env44566) = true)

theorem identity44566 : scanCanonicalize (H12AffineFastState.compose env44566 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound44566 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,131072,32040,1025,8540,4160,33,17,21763,8193,65,146509,5393,17665,138341,1365,21792,257,21793,5457,22273]

theorem envBound44567 : H12AffineFastState.Bounded env44567 := by
  intro p hp
  have h : env44567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44566_44567 : H12AffineEnvironment.transform 15 29963 env44566 = env44567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env44566 == env44567) = true)

theorem identity44567 : scanCanonicalize (H12AffineFastState.compose env44567 (packedSelected [2,4,9,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound44567 : packedSelected [2,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env44568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,263,131072,2340,1025,8540,4160,33,17,8463,8193,65,146509,5393,12557,138341,1365,8492,257,8493,5457,8973]

theorem envBound44568 : H12AffineFastState.Bounded env44568 := by
  intro p hp
  have h : env44568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44567_44568 : H12AffineEnvironment.transform 13 13324 env44567 = env44568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env44567 == env44568) = true)

theorem identity44568 : scanCanonicalize (H12AffineFastState.compose env44568 (packedSelected [0,4,6,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound44568 : packedSelected [0,4,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,263,5441,2340,1025,8540,4160,33,17,8463,8193,65,10508,5393,12557,2340,1365,8492,257,8493,5457,8973]

theorem envBound44569 : H12AffineFastState.Bounded env44569 := by
  intro p hp
  have h : env44569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44568_44569 : H12AffineEnvironment.transform 16 5441 env44568 = env44569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env44568 == env44569) = true)

theorem identity44569 : scanCanonicalize (H12AffineFastState.compose env44569 (packedSelected [0,1,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44569 : packedSelected [0,1,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env44570 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,13324,8313,35,5221,2048,1025,8312,4160,33,17,8235,8193,65,10280,5173,12329,2048,1137,8200,37,8201,5237,8745]

theorem envBound44570 : H12AffineFastState.Bounded env44570 := by
  intro p hp
  have h : env44570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44569_44570 : H12AffineEnvironment.transform 7 36 env44569 = env44570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44569 == env44570) = true)

theorem identity44570 : scanCanonicalize (H12AffineFastState.compose env44570 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6249) := by decide +kernel

theorem selectedBound44570 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env44571 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,6249,3173,6160,35,5221,2048,1025,6161,4160,33,17,6210,6248,65,4161,5173,2112,2048,1137,6241,37,6240,5237,6720]

theorem envBound44571 : H12AffineFastState.Bounded env44571 := by
  intro p hp
  have h : env44571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44570_44571 : H12AffineEnvironment.transform 12 6249 env44570 = env44571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6249 env44570 == env44571) = true)

theorem identity44571 : scanCanonicalize (H12AffineFastState.compose env44571 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound44571 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env44572 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2113,40,3173,81,35,3108,2048,1025,80,2049,33,17,3,41,65,2048,3188,2112,2048,1137,32,37,33,3124,513]

theorem envBound44572 : H12AffineFastState.Bounded env44572 := by
  intro p hp
  have h : env44572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44571_44572 : H12AffineEnvironment.transform 11 2113 env44571 = env44572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env44571 == env44572) = true)

theorem identity44572 : scanCanonicalize (H12AffineFastState.compose env44572 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44572 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44573 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,2113,40,2049,81,35,2112,2048,101,80,2049,33,17,3,41,65,2048,2064,2112,2048,21,32,37,33,2128,513]

theorem envBound44573 : H12AffineFastState.Bounded env44573 := by
  intro p hp
  have h : env44573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44572_44573 : H12AffineEnvironment.transform 9 100 env44572 = env44573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44572 == env44573) = true)

def env44574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,4194304,8388608,8487372,8328,65,4365753,8393984,8406289,8526964,1501,12645453,257,21793,46213,74251]

theorem envBound44574 : H12AffineFastState.Bounded env44574 := by
  intro p hp
  have h : env44574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44500_44574 : H12AffineEnvironment.transform 20 4161 env44500 = env44574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44500 == env44574) = true)

def env44575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,8388608,8487372,8328,65,171417,8393984,8406289,8526964,1501,8451181,257,21793,46213,74251]

theorem envBound44575 : H12AffineFastState.Bounded env44575 := by
  intro p hp
  have h : env44575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44574_44575 : H12AffineEnvironment.transform 21 32 env44574 = env44575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44574 == env44575) = true)

theorem identity44575 : scanCanonicalize (H12AffineFastState.compose env44575 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound44575 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1025,29909,4161,32,8388608,8484120,8328,65,158029,8393984,8406289,8526964,1501,8388793,257,21793,16465,74251]

theorem envBound44576 : H12AffineFastState.Bounded env44576 := by
  intro p hp
  have h : env44576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44575_44576 : H12AffineEnvironment.transform 14 29908 env44575 = env44576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env44575 == env44576) = true)

theorem identity44576 : scanCanonicalize (H12AffineFastState.compose env44576 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44576 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env44577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,10401,1025,29909,4161,32,8388608,8410386,8328,65,158029,8393984,8406289,8526964,1501,8388793,257,21793,16465,513]

theorem envBound44577 : H12AffineFastState.Bounded env44577 := by
  intro p hp
  have h : env44577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44576_44577 : H12AffineEnvironment.transform 15 8202 env44576 = env44577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44576 == env44577) = true)

def env44578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,131072,10401,1025,8661,4161,32,8388608,8388626,8328,65,146509,8393984,8392721,8526964,1501,8388793,257,33,5457,513]

theorem envBound44578 : H12AffineFastState.Bounded env44578 := by
  intro p hp
  have h : env44578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44577_44578 : H12AffineEnvironment.transform 13 5376 env44577 = env44578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44577 == env44578) = true)

theorem identity44578 : scanCanonicalize (H12AffineFastState.compose env44578 (packedSelected [1,3,4,5,7,8,9,10,11,12,15,16,18,19,20,27] rootPS)) = affineNative (2^(22+1) ^^^ 144396) := by decide +kernel

theorem selectedBound44578 : packedSelected [1,3,4,5,7,8,9,10,11,12,15,16,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env44579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,131072,10401,1025,8661,4161,32,144396,144414,8328,65,146509,139532,140317,10360,1501,144565,257,33,5457,513]

theorem envBound44579 : H12AffineFastState.Bounded env44579 := by
  intro p hp
  have h : env44579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44578_44579 : H12AffineEnvironment.transform 22 144396 env44578 = env44579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 144396 env44578 == env44579) = true)

theorem identity44579 : scanCanonicalize (H12AffineFastState.compose env44579 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound44579 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env44580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,5441,10401,1025,8661,4161,32,8525,8543,8328,65,10508,13389,12636,10360,1501,8692,257,33,5457,513]

theorem envBound44580 : H12AffineFastState.Bounded env44580 := by
  intro p hp
  have h : env44580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44579_44580 : H12AffineEnvironment.transform 16 5441 env44579 = env44580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env44579 == env44580) = true)

theorem identity44580 : scanCanonicalize (H12AffineFastState.compose env44580 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound44580 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env44581 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8460,8202,5441,10361,1025,8461,4161,32,8525,8543,8272,65,10508,13389,12636,10360,1285,8492,257,33,5457,513]

theorem envBound44581 : H12AffineFastState.Bounded env44581 := by
  intro p hp
  have h : env44581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44580_44581 : H12AffineEnvironment.transform 6 88 env44580 = env44581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env44580 == env44581) = true)

def env44582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,131072,10401,1025,8660,4161,32,8388608,8388627,8328,65,146508,8393984,8392720,8526964,1501,8388793,257,32,5456,513]

theorem envBound44582 : H12AffineFastState.Bounded env44582 := by
  intro p hp
  have h : env44582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44577_44582 : H12AffineEnvironment.transform 13 5377 env44577 = env44582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44577 == env44582) = true)

theorem identity44582 : scanCanonicalize (H12AffineFastState.compose env44582 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44582 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,10281,1025,8540,4161,32,8388608,8388627,8192,65,146508,8393984,8392720,8526964,1365,8388657,257,32,5456,513]

theorem envBound44583 : H12AffineFastState.Bounded env44583 := by
  intro p hp
  have h : env44583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44582_44583 : H12AffineEnvironment.transform 6 8 env44582 = env44583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44582 == env44583) = true)

theorem identity44583 : scanCanonicalize (H12AffineFastState.compose env44583 (packedSelected [0,1,4,7,8,9,10,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 136528) := by decide +kernel

theorem selectedBound44583 : packedSelected [0,1,4,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env44584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,10281,1025,8540,4161,32,136528,136515,8192,65,146508,131152,132416,2340,1365,136545,257,32,5456,513]

theorem envBound44584 : H12AffineFastState.Bounded env44584 := by
  intro p hp
  have h : env44584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44583_44584 : H12AffineEnvironment.transform 22 136528 env44583 = env44584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136528 env44583 == env44584) = true)

theorem identity44584 : scanCanonicalize (H12AffineFastState.compose env44584 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44584 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env44585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,263,131072,2340,1025,81,4161,32,136528,136515,269,65,138561,131152,132416,2340,1365,136545,257,32,5456,513]

theorem envBound44585 : H12AffineFastState.Bounded env44585 := by
  intro p hp
  have h : env44585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44584_44585 : H12AffineEnvironment.transform 12 269 env44584 = env44585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44584 == env44585) = true)

theorem identity44585 : scanCanonicalize (H12AffineFastState.compose env44585 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44585 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44586 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,263,131072,2340,1025,1,4113,32,136448,136467,269,17,138513,131072,132368,2340,1285,136497,257,32,5376,513]

theorem envBound44586 : H12AffineFastState.Bounded env44586 := by
  intro p hp
  have h : env44586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44585_44586 : H12AffineEnvironment.transform 5 16 env44585 = env44586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44585 == env44586) = true)

theorem identity44586 : scanCanonicalize (H12AffineFastState.compose env44586 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(16+1) ^^^ 7440) := by decide +kernel

theorem selectedBound44586 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44587 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,263,7440,2340,1025,1,4113,32,2064,2051,269,17,1,7440,6144,2340,1285,2081,257,32,5376,513]

theorem envBound44587 : H12AffineFastState.Bounded env44587 := by
  intro p hp
  have h : env44587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44586_44587 : H12AffineEnvironment.transform 16 7440 env44586 = env44587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 7440 env44586 == env44587) = true)

theorem identity44587 : scanCanonicalize (H12AffineFastState.compose env44587 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound44587 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env44588 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2356,269,3125,0,263,1060,2340,1025,1,2341,32,2064,2051,269,17,1,1060,308,2340,1285,2081,257,32,3124,513]

theorem envBound44588 : H12AffineFastState.Bounded env44588 := by
  intro p hp
  have h : env44588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44587_44588 : H12AffineEnvironment.transform 11 2356 env44587 = env44588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env44587 == env44588) = true)

theorem identity44588 : scanCanonicalize (H12AffineFastState.compose env44588 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44588 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env44589 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,308,269,1077,0,263,1060,292,1025,1,293,32,16,3,269,17,1,1060,308,292,1285,33,257,32,1076,513]

theorem envBound44589 : H12AffineFastState.Bounded env44589 := by
  intro p hp
  have h : env44589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44588_44589 : H12AffineEnvironment.transform 10 0 env44588 = env44589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44588 == env44589) = true)

def env44590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,8388608,8487372,8328,65,171416,8393984,8406289,8526964,1501,8451180,257,21793,46213,74251]

theorem envBound44590 : H12AffineFastState.Bounded env44590 := by
  intro p hp
  have h : env44590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44574_44590 : H12AffineEnvironment.transform 21 33 env44574 = env44590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44574 == env44590) = true)

theorem identity44590 : scanCanonicalize (H12AffineFastState.compose env44590 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62661) := by decide +kernel

theorem selectedBound44590 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,62661,95497,8328,65,171416,57797,45524,190641,1501,169,257,21793,46213,74251]

theorem envBound44591 : H12AffineFastState.Bounded env44591 := by
  intro p hp
  have h : env44591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44590_44591 : H12AffineEnvironment.transform 22 62661 env44590 = env44591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env44590 == env44591) = true)

def env44592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,62541,95497,8192,65,171280,57677,45404,190521,1365,33,257,21793,46093,74251]

theorem envBound44592 : H12AffineFastState.Bounded env44592 := by
  intro p hp
  have h : env44592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44591_44592 : H12AffineEnvironment.transform 6 8 env44591 = env44592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44591 == env44592) = true)

theorem identity44592 : scanCanonicalize (H12AffineFastState.compose env44592 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound44592 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,4161,33,17,95497,8192,65,158028,5393,17664,138341,1365,33,257,21793,16465,74251]

theorem envBound44593 : H12AffineFastState.Bounded env44593 := by
  intro p hp
  have h : env44593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44592_44593 : H12AffineEnvironment.transform 14 29788 env44592 = env44593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env44592 == env44593) = true)

theorem identity44593 : scanCanonicalize (H12AffineFastState.compose env44593 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44593 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,10281,1025,29789,4161,33,17,21763,8192,65,158028,5393,17664,138341,1365,33,257,21793,16465,513]

theorem envBound44594 : H12AffineFastState.Bounded env44594 := by
  intro p hp
  have h : env44594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44593_44594 : H12AffineEnvironment.transform 15 8202 env44593 = env44594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44593 == env44594) = true)

theorem identity44594 : scanCanonicalize (H12AffineFastState.compose env44594 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44594 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env44595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,131072,2420,1025,21760,4161,33,17,21763,349,65,149521,5393,17664,138341,1365,33,257,21793,16465,513]

theorem envBound44595 : H12AffineFastState.Bounded env44595 := by
  intro p hp
  have h : env44595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44594_44595 : H12AffineEnvironment.transform 12 349 env44594 = env44595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44594 == env44595) = true)

theorem identity44595 : scanCanonicalize (H12AffineFastState.compose env44595 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound44595 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,5392,2420,1025,21760,4161,33,17,21763,349,65,23809,5393,17664,2421,1365,33,257,21793,16465,513]

theorem envBound44596 : H12AffineFastState.Bounded env44596 := by
  intro p hp
  have h : env44596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44595_44596 : H12AffineEnvironment.transform 16 5392 env44595 = env44596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env44595 == env44596) = true)

theorem identity44596 : scanCanonicalize (H12AffineFastState.compose env44596 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44596 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5392,2420,1025,1,4161,33,17,2,349,65,2048,5393,4097,2421,1365,33,257,32,5456,513]

theorem envBound44597 : H12AffineFastState.Bounded env44597 := by
  intro p hp
  have h : env44597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44596_44597 : H12AffineEnvironment.transform 13 5377 env44596 = env44597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44596 == env44597) = true)

theorem identity44597 : scanCanonicalize (H12AffineFastState.compose env44597 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound44597 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,868,349,1637,0,343,1652,2420,1025,1,805,33,17,2,349,65,2048,1653,869,2421,1365,33,257,32,1588,513]

theorem envBound44598 : H12AffineFastState.Bounded env44598 := by
  intro p hp
  have h : env44598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44597_44598 : H12AffineEnvironment.transform 11 868 env44597 = env44598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env44597 == env44598) = true)

theorem identity44598 : scanCanonicalize (H12AffineFastState.compose env44598 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound44598 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,529,868,349,1637,0,343,1652,869,1025,1,805,33,17,2,349,65,529,1653,869,868,1365,33,257,32,1588,513]

theorem envBound44599 : H12AffineFastState.Bounded env44599 := by
  intro p hp
  have h : env44599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44598_44599 : H12AffineEnvironment.transform 10 529 env44598 = env44599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env44598 == env44599) = true)

theorem identity44599 : scanCanonicalize (H12AffineFastState.compose env44599 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44599 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env44600 : List Nat := [2,4,8,16,0,64,8,256,512,1024,529,836,349,1605,0,343,1620,837,1025,1,773,1,17,2,349,65,529,1621,837,836,1365,1,257,0,1556,513]

theorem envBound44600 : H12AffineFastState.Bounded env44600 := by
  intro p hp
  have h : env44600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44599_44600 : H12AffineEnvironment.transform 4 0 env44599 = env44600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44599 == env44600) = true)

theorem identity44600 : scanCanonicalize (H12AffineFastState.compose env44600 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44600 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env44601 : List Nat := [2,4,8,16,0,17,8,256,512,1024,529,789,268,1556,0,262,1541,788,1025,1,773,1,17,2,268,16,529,1540,788,789,1284,1,257,0,1556,513]

theorem envBound44601 : H12AffineFastState.Bounded env44601 := by
  intro p hp
  have h : env44601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44600_44601 : H12AffineEnvironment.transform 5 17 env44600 = env44601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44600 == env44601) = true)

theorem identity44601 : scanCanonicalize (H12AffineFastState.compose env44601 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44602 : List Nat := [2,4,8,16,0,17,8,256,512,5,529,789,268,529,0,262,512,788,4,1,773,1,17,2,268,16,529,513,788,789,257,1,257,0,529,513]

theorem envBound44602 : H12AffineFastState.Bounded env44602 := by
  intro p hp
  have h : env44602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44601_44602 : H12AffineEnvironment.transform 9 5 env44601 = env44602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44601 == env44602) = true)

theorem identity44602 : scanCanonicalize (H12AffineFastState.compose env44602 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44602 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44603 : List Nat := [2,4,8,16,0,17,8,4,512,5,529,529,8,529,0,2,512,528,4,1,513,1,17,2,8,16,529,513,528,529,5,1,5,0,529,513]

theorem envBound44603 : H12AffineFastState.Bounded env44603 := by
  intro p hp
  have h : env44603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44602_44603 : H12AffineEnvironment.transform 7 4 env44602 = env44603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44602 == env44603) = true)

def env44604 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,62540,95497,8193,65,171281,57676,45405,190520,1364,32,257,21793,46092,74251]

theorem envBound44604 : H12AffineFastState.Bounded env44604 := by
  intro p hp
  have h : env44604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44591_44604 : H12AffineEnvironment.transform 6 9 env44591 = env44604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44591 == env44604) = true)

theorem identity44604 : scanCanonicalize (H12AffineFastState.compose env44604 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44604 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1025,32769,4161,33,41292,73737,8193,65,171281,46156,45405,179512,1364,32,257,33,46092,74251]

theorem envBound44605 : H12AffineFastState.Bounded env44605 := by
  intro p hp
  have h : env44605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44604_44605 : H12AffineEnvironment.transform 13 5376 env44604 = env44605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44604 == env44605) = true)

theorem identity44605 : scanCanonicalize (H12AffineFastState.compose env44605 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound44605 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env44606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,70679,35189,1025,32769,4161,33,41292,73737,8193,65,100614,46156,45405,108847,1364,32,257,33,46092,74251]

theorem envBound44606 : H12AffineFastState.Bounded env44606 := by
  intro p hp
  have h : env44606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44605_44606 : H12AffineEnvironment.transform 16 70679 env44605 = env44606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env44605 == env44606) = true)

theorem identity44606 : scanCanonicalize (H12AffineFastState.compose env44606 (packedSelected [0,3,4,7,9,10,11,12,14,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound44606 : packedSelected [0,3,4,7,9,10,11,12,14,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,32768,65536,70679,35189,1025,32769,4161,33,33077,65648,120,65,100614,37941,37156,100694,1364,32,257,33,38005,66162]

theorem envBound44607 : H12AffineFastState.Bounded env44607 := by
  intro p hp
  have h : env44607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44606_44607 : H12AffineEnvironment.transform 12 121 env44606 = env44607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env44606 == env44607) = true)

theorem identity44607 : scanCanonicalize (H12AffineFastState.compose env44607 (packedSelected [2,4,6,9,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44607 : packedSelected [2,4,6,9,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env44608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,0,65536,70679,2421,1025,1,4161,33,309,65648,120,65,67846,5173,4388,67926,1364,32,257,33,5237,66162]

theorem envBound44608 : H12AffineFastState.Bounded env44608 := by
  intro p hp
  have h : env44608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44607_44608 : H12AffineEnvironment.transform 14 0 env44607 = env44608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44607 == env44608) = true)

theorem identity44608 : scanCanonicalize (H12AffineFastState.compose env44608 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44608 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44609 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,0,65536,70679,2049,1025,1,4161,33,65,65648,120,65,67698,5173,4176,67618,1056,32,117,33,5237,66162]

theorem envBound44609 : H12AffineFastState.Bounded env44609 := by
  intro p hp
  have h : env44609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44608_44609 : H12AffineEnvironment.transform 7 116 env44608 = env44609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44608 == env44609) = true)

theorem identity44609 : scanCanonicalize (H12AffineFastState.compose env44609 (packedSelected [0,2,3,4,5,6,7,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound44609 : packedSelected [0,2,3,4,5,6,7,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env44610 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,0,115,5220,2049,1025,1,4161,33,65,3,120,65,2049,5173,4176,2129,1056,32,117,33,5237,513]

theorem envBound44610 : H12AffineFastState.Bounded env44610 := by
  intro p hp
  have h : env44610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44609_44610 : H12AffineEnvironment.transform 15 115 env44609 = env44610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env44609 == env44610) = true)

theorem identity44610 : scanCanonicalize (H12AffineFastState.compose env44610 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44610 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44611 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,0,34,5173,2049,1025,1,4112,33,16,3,41,16,2049,5173,4097,2048,1056,32,36,33,5156,513]

theorem envBound44611 : H12AffineFastState.Bounded env44611 := by
  intro p hp
  have h : env44611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44610_44611 : H12AffineEnvironment.transform 5 17 env44610 = env44611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44610 == env44611) = true)

theorem identity44611 : scanCanonicalize (H12AffineFastState.compose env44611 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound44611 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44612 : List Nat := [2,4,8,16,32,17,9,37,512,36,2048,4096,40,4097,0,34,4113,2049,37,1,4112,33,16,3,41,16,2049,4113,4097,2048,4,32,36,33,4096,513]

theorem envBound44612 : H12AffineFastState.Bounded env44612 := by
  intro p hp
  have h : env44612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44611_44612 : H12AffineEnvironment.transform 9 36 env44611 = env44612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env44611 == env44612) = true)

theorem identity44612 : scanCanonicalize (H12AffineFastState.compose env44612 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

end H12CloudChart1