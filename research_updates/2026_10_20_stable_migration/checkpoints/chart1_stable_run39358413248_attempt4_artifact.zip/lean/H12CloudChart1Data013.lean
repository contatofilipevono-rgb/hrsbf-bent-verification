import H12CloudChart1Data012

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans3189_3190 : H12AffineEnvironment.transform 14 8461 env3189 = env3190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env3189 == env3190) = true)

theorem identity3190 : scanCanonicalize (H12AffineFastState.compose env3190 (packedSelected [0,2,3,4,5,7,9,10,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3190 : packedSelected [0,2,3,4,5,7,9,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3191 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1676,8192,16384,8352,8235,1676,2080,1024,8352,1677,18093,17956,138,8329,17956,20109,16384,16385,20141,1024,17957,173,18060,1572,17444]

theorem envBound3191 : H12AffineFastState.Bounded env3191 := by
  intro p hp
  have h : env3191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3190_3191 : H12AffineEnvironment.transform 7 173 env3190 = env3191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3190 == env3191) = true)

theorem identity3191 : scanCanonicalize (H12AffineFastState.compose env3191 (packedSelected [0,3,5,6,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound3191 : packedSelected [0,3,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env3192 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1676,1156,16384,1060,1199,1676,2080,1024,1060,1677,18093,17956,138,1037,17956,20109,16384,16385,20141,1024,17957,173,18060,1572,17444]

theorem envBound3192 : H12AffineFastState.Bounded env3192 := by
  intro p hp
  have h : env3192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3191_3192 : H12AffineEnvironment.transform 12 1156 env3191 = env3192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env3191 == env3192) = true)

theorem identity3192 : scanCanonicalize (H12AffineFastState.compose env3192 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound3192 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env3193 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1676,1156,2090,1060,1199,1676,2080,1024,1060,1677,3719,3598,138,1037,3598,1703,2090,2091,1671,1024,3599,173,3750,1572,3086]

theorem envBound3193 : H12AffineFastState.Bounded env3193 := by
  intro p hp
  have h : env3193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3192_3193 : H12AffineEnvironment.transform 13 2090 env3192 = env3193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env3192 == env3193) = true)

theorem identity3193 : scanCanonicalize (H12AffineFastState.compose env3193 (packedSelected [0,1,2,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3193 : packedSelected [0,1,2,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env3194 : List Nat := [2,4,8,0,32,1,128,173,1,1024,2048,1165,1156,2090,1060,1199,1165,2080,1024,1060,1164,3206,3087,138,1037,3087,1190,2090,2091,1158,1024,3086,173,3239,1061,3086]

theorem envBound3194 : H12AffineFastState.Bounded env3194 := by
  intro p hp
  have h : env3194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3193_3194 : H12AffineEnvironment.transform 8 1 env3193 = env3194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3193 == env3194) = true)

theorem identity3194 : scanCanonicalize (H12AffineFastState.compose env3194 (packedSelected [1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3194 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env3195 : List Nat := [2,4,8,0,32,1,34,15,1,1024,2048,1071,1062,2090,1060,1037,1071,2080,1024,1060,1070,3108,3087,40,1037,3087,1028,2090,2091,1060,1024,3086,15,3077,1061,3086]

theorem envBound3195 : H12AffineFastState.Bounded env3195 := by
  intro p hp
  have h : env3195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3194_3195 : H12AffineEnvironment.transform 6 34 env3194 = env3195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3194 == env3195) = true)

theorem identity3195 : scanCanonicalize (H12AffineFastState.compose env3195 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound3195 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env3196 : List Nat := [2,4,8,0,32,1,34,15,1,1024,11,1071,1062,33,1060,1037,1071,43,1024,1060,1070,1071,1028,40,1037,1028,1028,33,32,1060,1024,1029,15,1038,1061,1029]

theorem envBound3196 : H12AffineFastState.Bounded env3196 := by
  intro p hp
  have h : env3196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3195_3196 : H12AffineEnvironment.transform 10 11 env3195 = env3196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env3195 == env3196) = true)

theorem identity3196 : scanCanonicalize (H12AffineFastState.compose env3196 (packedSelected [0,1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3196 : packedSelected [0,1,2,8] rootPS < 2^1333 := by decide +kernel

def env3197 : List Nat := [2,4,2,0,32,1,34,5,1,1024,1,1061,1062,33,1060,1031,1061,33,1024,1060,1060,1061,1028,34,1031,1028,1028,33,32,1060,1024,1029,5,1028,1061,1029]

theorem envBound3197 : H12AffineFastState.Bounded env3197 := by
  intro p hp
  have h : env3197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3196_3197 : H12AffineEnvironment.transform 2 2 env3196 = env3197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3196 == env3197) = true)

theorem identity3197 : scanCanonicalize (H12AffineFastState.compose env3197 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound3197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3198 : List Nat := [2,4,2,0,32,1,34,5,1,36,1,1,2,33,0,35,1,33,36,0,0,1,32,34,35,32,32,33,32,0,36,33,5,32,1,33]

theorem envBound3198 : H12AffineFastState.Bounded env3198 := by
  intro p hp
  have h : env3198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3197_3198 : H12AffineEnvironment.transform 9 36 env3197 = env3198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env3197 == env3198) = true)

theorem identity3198 : scanCanonicalize (H12AffineFastState.compose env3198 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3198 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3199 : List Nat := [2,4,2,0,0,1,2,5,1,4,1,1,2,1,0,3,1,1,4,0,0,1,0,2,3,0,0,1,0,0,4,1,5,0,1,1]

theorem envBound3199 : H12AffineFastState.Bounded env3199 := by
  intro p hp
  have h : env3199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3198_3199 : H12AffineEnvironment.transform 4 0 env3198 = env3199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3198 == env3199) = true)

def env3200 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,20740,41002,8329,20740,323713,16384,16812,22561,74795,4235304,256,20480,77955,21160]

theorem envBound3200 : H12AffineFastState.Bounded env3200 := by
  intro p hp
  have h : env3200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3179_3200 : H12AffineEnvironment.transform 3 1 env3179 = env3200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3179 == env3200) = true)

theorem identity3200 : scanCanonicalize (H12AffineFastState.compose env3200 (packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 338222) := by decide +kernel

theorem selectedBound3200 : packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3201 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,338222,20740,41002,8329,20740,323713,16384,16812,22561,74795,362758,256,20480,77955,21160]

theorem envBound3201 : H12AffineFastState.Bounded env3201 := by
  intro p hp
  have h : env3201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3200_3201 : H12AffineEnvironment.transform 21 338222 env3200 = env3201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 338222 env3200 == env3201) = true)

def env3202 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2184,1024,32768,4097,74150,20740,41002,8329,20740,63497,16384,16812,22561,74795,98702,256,20480,77955,21160]

theorem envBound3202 : H12AffineFastState.Bounded env3202 := by
  intro p hp
  have h : env3202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3201_3202 : H12AffineEnvironment.transform 17 2184 env3201 = env3202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env3201 == env3202) = true)

theorem identity3202 : scanCanonicalize (H12AffineFastState.compose env3202 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound3202 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3203 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,28803,4525,2184,1024,32768,4097,20773,20740,41002,8329,20740,63497,16384,16812,22561,21672,61709,256,20480,16384,21160]

theorem envBound3203 : H12AffineFastState.Bounded env3203 := by
  intro p hp
  have h : env3203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3202_3203 : H12AffineEnvironment.transform 15 28803 env3202 = env3203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env3202 == env3203) = true)

theorem identity3203 : scanCanonicalize (H12AffineFastState.compose env3203 (packedSelected [0,2,3,4,5,7,10,11,13,17,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound3203 : packedSelected [0,2,3,4,5,7,10,11,13,17,18,22] rootPS < 2^1333 := by decide +kernel

def env3204 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,4097,32768,8322,4525,2184,1024,32768,4097,292,261,41002,8329,261,43016,4097,4525,2080,1193,41228,256,1,4097,681]

theorem envBound3204 : H12AffineFastState.Bounded env3204 := by
  intro p hp
  have h : env3204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3203_3204 : H12AffineEnvironment.transform 13 4097 env3203 = env3204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3203 == env3204) = true)

theorem identity3204 : scanCanonicalize (H12AffineFastState.compose env3204 (packedSelected [0,2,4,7,9,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3204 : packedSelected [0,2,4,7,9,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3205 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1572,8192,1573,32768,8322,1929,2184,1024,32768,1573,292,261,41002,8329,261,43016,1573,1929,2080,1193,41228,256,1,1573,681]

theorem envBound3205 : H12AffineFastState.Bounded env3205 := by
  intro p hp
  have h : env3205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3204_3205 : H12AffineEnvironment.transform 11 1572 env3204 = env3205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env3204 == env3205) = true)

theorem identity3205 : scanCanonicalize (H12AffineFastState.compose env3205 (packedSelected [3,4,5,9,10,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound3205 : packedSelected [3,4,5,9,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3206 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1572,8192,1573,8200,8322,1929,2184,1024,8200,1573,292,261,34,8329,261,2048,1573,1929,2080,1193,260,256,1,1573,681]

theorem envBound3206 : H12AffineFastState.Bounded env3206 := by
  intro p hp
  have h : env3206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3205_3206 : H12AffineEnvironment.transform 14 8200 env3205 = env3206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env3205 == env3206) = true)

theorem identity3206 : scanCanonicalize (H12AffineFastState.compose env3206 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3206 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3207 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,1572,8192,1573,8200,8234,1825,2080,1024,8200,1573,292,261,34,8225,261,2048,1573,1825,2080,1025,260,256,1,1573,513]

theorem envBound3207 : H12AffineFastState.Bounded env3207 := by
  intro p hp
  have h : env3207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3206_3207 : H12AffineEnvironment.transform 6 40 env3206 = env3207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3206 == env3207) = true)

theorem identity3207 : scanCanonicalize (H12AffineFastState.compose env3207 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3207 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3208 : List Nat := [2,4,8,1,32,0,40,256,512,1024,1551,1572,8192,1573,8200,8234,1825,1583,1024,8200,1573,292,261,34,8225,261,1551,1573,1825,1583,1025,260,256,1,1573,513]

theorem envBound3208 : H12AffineFastState.Bounded env3208 := by
  intro p hp
  have h : env3208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3207_3208 : H12AffineEnvironment.transform 10 1551 env3207 = env3208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env3207 == env3208) = true)

theorem identity3208 : scanCanonicalize (H12AffineFastState.compose env3208 (packedSelected [1,6,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3208 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env3209 : List Nat := [2,4,3,1,32,0,35,256,512,1024,1540,1572,8192,1573,8195,8225,1825,1572,1024,8195,1573,292,261,34,8225,261,1540,1573,1825,1572,1025,260,256,1,1573,513]

theorem envBound3209 : H12AffineFastState.Bounded env3209 := by
  intro p hp
  have h : env3209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3208_3209 : H12AffineEnvironment.transform 2 3 env3208 = env3209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3208 == env3209) = true)

theorem identity3209 : scanCanonicalize (H12AffineFastState.compose env3209 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3209 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env3210 : List Nat := [2,4,3,1,32,0,35,5,512,1024,1540,1572,8192,1573,8195,8225,1572,1572,1024,8195,1573,33,0,34,8225,0,1540,1573,1572,1572,1025,1,5,1,1573,513]

theorem envBound3210 : H12AffineFastState.Bounded env3210 := by
  intro p hp
  have h : env3210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3209_3210 : H12AffineEnvironment.transform 7 5 env3209 = env3210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3209 == env3210) = true)

theorem identity3210 : scanCanonicalize (H12AffineFastState.compose env3210 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound3210 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3211 : List Nat := [2,4,3,1,32,0,35,5,512,1024,1540,1572,1031,1573,1028,1062,1572,1572,1024,1028,1573,33,0,34,1062,0,1540,1573,1572,1572,1025,1,5,1,1573,513]

theorem envBound3211 : H12AffineFastState.Bounded env3211 := by
  intro p hp
  have h : env3211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3210_3211 : H12AffineEnvironment.transform 12 1031 env3210 = env3211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env3210 == env3211) = true)

theorem identity3211 : scanCanonicalize (H12AffineFastState.compose env3211 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound3211 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3212 : List Nat := [2,4,3,1,32,0,35,5,5,1024,1025,1057,1031,1056,1028,1062,1057,1057,1024,1028,1056,33,0,34,1062,0,1025,1056,1057,1057,1025,1,5,1,1056,4]

theorem envBound3212 : H12AffineFastState.Bounded env3212 := by
  intro p hp
  have h : env3212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3211_3212 : H12AffineEnvironment.transform 8 5 env3211 = env3212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env3211 == env3212) = true)

theorem identity3212 : scanCanonicalize (H12AffineFastState.compose env3212 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3212 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3213 : List Nat := [2,0,3,1,32,0,35,1,1,1024,1025,1057,1027,1056,1024,1058,1057,1057,1024,1024,1056,33,0,34,1058,0,1025,1056,1057,1057,1025,1,1,1,1056,0]

theorem envBound3213 : H12AffineFastState.Bounded env3213 := by
  intro p hp
  have h : env3213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3212_3213 : H12AffineEnvironment.transform 1 0 env3212 = env3213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3212 == env3213) = true)

theorem identity3213 : scanCanonicalize (H12AffineFastState.compose env3213 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound3213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3214 : List Nat := [2,0,3,1,32,0,35,1,1,32,33,1,35,0,32,2,1,1,32,32,0,33,0,34,2,0,33,0,1,1,33,1,1,1,0,0]

theorem envBound3214 : H12AffineFastState.Bounded env3214 := by
  intro p hp
  have h : env3214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3213_3214 : H12AffineEnvironment.transform 9 32 env3213 = env3214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3213 == env3214) = true)

def leafEnv3214 : List Nat := [2,0,3,1,32,0,35,1,1,32,33,1,35,0,32,2,1,1,32,32,0,33,0,34,33,2,1,0,33,0,1,1,33,1,1,1,0,35,0,0,1,0,0]

def active3214 : List Nat := [0,4]

def tree3214 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3214 : H12WitnessSearch.Good tree3214 := H12GlobalWitnessIndex.good

theorem leafIdentity3214 : H12AffineFastState.composeSystem env3214 rootObs = leafEnv3214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3214 rootObs == leafEnv3214) = true)

theorem terminalChecked3214 : H12PackedTerminal.terminalCheckFast leafEnv3214 active3214 tree3214 = true := by decide +kernel

def env3215 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2185,1024,32768,4097,74151,20740,41002,8329,20740,63496,16384,16812,22561,74795,98703,256,20480,77955,21160]

theorem envBound3215 : H12AffineFastState.Bounded env3215 := by
  intro p hp
  have h : env3215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3201_3215 : H12AffineEnvironment.transform 17 2185 env3201 = env3215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env3201 == env3215) = true)

theorem identity3215 : scanCanonicalize (H12AffineFastState.compose env3215 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 29062) := by decide +kernel

theorem selectedBound3215 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3216 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,29062,4525,2185,1024,32768,4097,20513,20740,41002,8329,20740,63496,16384,16812,22561,21933,61449,256,20480,16645,21160]

theorem envBound3216 : H12AffineFastState.Bounded env3216 := by
  intro p hp
  have h : env3216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3215_3216 : H12AffineEnvironment.transform 15 29062 env3215 = env3216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29062 env3215 == env3216) = true)

theorem identity3216 : scanCanonicalize (H12AffineFastState.compose env3216 (packedSelected [0,2,4,7,11,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound3216 : packedSelected [0,2,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env3217 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,8612,29062,4525,2185,1024,8612,4097,20513,20740,398,8329,20740,22956,16384,16812,22561,21933,20909,256,20480,16645,21160]

theorem envBound3217 : H12AffineFastState.Bounded env3217 := by
  intro p hp
  have h : env3217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3216_3217 : H12AffineEnvironment.transform 14 8612 env3216 = env3217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env3216 == env3217) = true)

theorem identity3217 : scanCanonicalize (H12AffineFastState.compose env3217 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3217 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3218 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,1573,8612,14243,4525,2185,1024,8612,4097,5636,5921,398,8329,5921,8073,1573,1929,7684,5000,6024,256,5669,1824,5261]

theorem envBound3218 : H12AffineFastState.Bounded env3218 := by
  intro p hp
  have h : env3218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3217_3218 : H12AffineEnvironment.transform 13 1573 env3217 = env3218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env3217 == env3218) = true)

theorem identity3218 : scanCanonicalize (H12AffineFastState.compose env3218 (packedSelected [0,4,7,9,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3218 : packedSelected [0,4,7,9,12,15,17] rootPS < 2^1333 := by decide +kernel

def env3219 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,1573,8461,14090,4356,2080,1024,8461,4097,5636,5921,295,8224,5921,7968,1573,1824,7684,4897,5921,256,5669,1824,5156]

theorem envBound3219 : H12AffineFastState.Bounded env3219 := by
  intro p hp
  have h : env3219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3218_3219 : H12AffineEnvironment.transform 6 41 env3218 = env3219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3218 == env3219) = true)

theorem identity3219 : scanCanonicalize (H12AffineFastState.compose env3219 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound3219 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env3220 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,2351,8192,1573,8461,11813,2091,2080,1024,8461,2350,3883,3598,295,8224,3598,1551,1573,1824,1835,2574,3598,256,3850,1824,3339]

theorem envBound3220 : H12AffineFastState.Bounded env3220 := by
  intro p hp
  have h : env3220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3219_3220 : H12AffineEnvironment.transform 11 2351 env3219 = env3220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env3219 == env3220) = true)

theorem identity3220 : scanCanonicalize (H12AffineFastState.compose env3220 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound3220 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3221 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,2351,2601,1573,2852,1036,2091,2080,1024,2852,2350,3883,3598,295,2569,3598,1551,1573,1824,1835,2574,3598,256,3850,1824,3339]

theorem envBound3221 : H12AffineFastState.Bounded env3221 := by
  intro p hp
  have h : env3221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3220_3221 : H12AffineEnvironment.transform 12 2601 env3220 = env3221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env3220 == env3221) = true)

def env3222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323793,16384,16893,22641,74794,12644669,257,20560,8479126,8389613]

theorem envBound3222 : H12AffineFastState.Bounded env3222 := by
  intro p hp
  have h : env3222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3166_3222 : H12AffineEnvironment.transform 18 1025 env3166 = env3222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3166 == env3222) = true)

theorem identity3222 : scanCanonicalize (H12AffineFastState.compose env3222 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound3222 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1092,8192,16384,32768,65536,1464,262144,1025,32768,1093,4194304,8388608,41002,8329,8388688,320661,16384,16893,19509,74794,12641657,257,17428,8479126,8389613]

theorem envBound3223 : H12AffineFastState.Bounded env3223 := by
  intro p hp
  have h : env3223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3222_3223 : H12AffineEnvironment.transform 11 1092 env3222 = env3223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env3222 == env3223) = true)

def env3224 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,32768,65536,1464,262144,1025,32768,1045,4194304,8388608,41002,8329,8388608,320661,16384,16813,19509,74794,12641577,257,17428,8479126,8389565]

theorem envBound3224 : H12AffineFastState.Bounded env3224 := by
  intro p hp
  have h : env3224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3223_3224 : H12AffineEnvironment.transform 5 16 env3223 = env3224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3223 == env3224) = true)

def env3225 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1045,4194304,8388608,41002,8329,8388608,320661,16384,16401,19509,74794,12641429,189,17428,8478762,8389121]

theorem envBound3225 : H12AffineFastState.Bounded env3225 := by
  intro p hp
  have h : env3225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3224_3225 : H12AffineEnvironment.transform 7 188 env3224 = env3225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3224 == env3225) = true)

theorem identity3225 : scanCanonicalize (H12AffineFastState.compose env3225 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound3225 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3226 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1045,4194304,4194352,41002,8329,4194352,320661,16384,16401,19509,74794,58533,189,17428,4284442,4194865]

theorem envBound3226 : H12AffineFastState.Bounded env3226 := by
  intro p hp
  have h : env3226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3225_3226 : H12AffineEnvironment.transform 22 4194352 env3225 = env3226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env3225 == env3226) = true)

def env3227 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,32768,65536,1028,262144,1025,32768,1029,4194304,4194336,41002,8329,4194336,320645,16384,16385,19493,74794,58533,173,17412,4284426,4194849]

theorem envBound3227 : H12AffineFastState.Bounded env3227 := by
  intro p hp
  have h : env3227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3226_3227 : H12AffineEnvironment.transform 3 0 env3226 = env3227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3226 == env3227) = true)

theorem identity3227 : scanCanonicalize (H12AffineFastState.compose env3227 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound3227 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3228 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8200,65536,1028,262144,1025,8200,1029,4194304,4194336,34,8329,4194336,279693,16384,16385,19493,74794,17581,173,17412,4284426,4194849]

theorem envBound3228 : H12AffineFastState.Bounded env3228 := by
  intro p hp
  have h : env3228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3227_3228 : H12AffineEnvironment.transform 14 8200 env3227 = env3228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env3227 == env3228) = true)

theorem identity3228 : scanCanonicalize (H12AffineFastState.compose env3228 (packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 281605) := by decide +kernel

theorem selectedBound3228 : packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env3229 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8200,65536,1028,262144,1025,8200,1029,281605,281637,34,8329,281637,279693,16384,16385,19493,74794,17581,173,17412,338959,282148]

theorem envBound3229 : H12AffineFastState.Bounded env3229 := by
  intro p hp
  have h : env3229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3228_3229 : H12AffineEnvironment.transform 21 281605 env3228 = env3229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281605 env3228 == env3229) = true)

theorem identity3229 : scanCanonicalize (H12AffineFastState.compose env3229 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound3229 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3230 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8200,25647,1028,262144,1025,8200,1029,281605,281637,34,8329,281637,279693,16384,16385,19493,16389,17581,173,17412,280608,282148]

theorem envBound3230 : H12AffineFastState.Bounded env3230 := by
  intro p hp
  have h : env3230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3229_3230 : H12AffineEnvironment.transform 15 25647 env3229 = env3230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env3229 == env3230) = true)

theorem identity3230 : scanCanonicalize (H12AffineFastState.compose env3230 (packedSelected [1,4,6,8,9,12] rootPS)) = affineNative (2^(17+1) ^^^ 16514) := by decide +kernel

theorem selectedBound3230 : packedSelected [1,4,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env3231 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,16384,8200,25647,1028,16514,1025,8200,1029,3207,3239,34,8329,3239,1039,16384,16385,19493,16389,17581,173,17412,2210,3750]

theorem envBound3231 : H12AffineFastState.Bounded env3231 := by
  intro p hp
  have h : env3231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3230_3231 : H12AffineEnvironment.transform 17 16514 env3230 = env3231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16514 env3230 == env3231) = true)

theorem identity3231 : scanCanonicalize (H12AffineFastState.compose env3231 (packedSelected [2,3,5,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 11308) := by decide +kernel

theorem selectedBound3231 : packedSelected [2,3,5,15,17] rootPS < 2^1333 := by decide +kernel

def env3232 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1028,8192,11308,8200,2051,1028,11438,1025,8200,1029,3207,3239,34,8329,3239,1039,11308,11309,8201,11305,10369,173,10280,2210,3750]

theorem envBound3232 : H12AffineFastState.Bounded env3232 := by
  intro p hp
  have h : env3232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3231_3232 : H12AffineEnvironment.transform 13 11308 env3231 = env3232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11308 env3231 == env3232) = true)

theorem identity3232 : scanCanonicalize (H12AffineFastState.compose env3232 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound3232 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env3233 : List Nat := [2,4,8,0,32,0,128,172,169,1024,2048,1028,8192,11308,8200,2051,1028,11438,1025,8200,1029,3207,3239,34,8329,3239,1039,11308,11309,8201,11305,10369,173,10280,2210,3087]

theorem envBound3233 : H12AffineFastState.Bounded env3233 := by
  intro p hp
  have h : env3233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3232_3233 : H12AffineEnvironment.transform 8 169 env3232 = env3233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env3232 == env3233) = true)

theorem identity3233 : scanCanonicalize (H12AffineFastState.compose env3233 (packedSelected [4,7,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound3233 : packedSelected [4,7,11,13] rootPS < 2^1333 := by decide +kernel

def env3234 : List Nat := [2,4,8,0,32,0,128,172,169,1024,2048,1028,2208,1164,2216,2051,1028,1038,1025,2216,1029,3207,3239,34,2089,3239,1039,1164,1165,2217,1161,33,173,136,2210,3087]

theorem envBound3234 : H12AffineFastState.Bounded env3234 := by
  intro p hp
  have h : env3234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3233_3234 : H12AffineEnvironment.transform 12 2208 env3233 = env3234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env3233 == env3234) = true)

theorem identity3234 : scanCanonicalize (H12AffineFastState.compose env3234 (packedSelected [0,2,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound3234 : packedSelected [0,2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env3235 : List Nat := [2,4,8,0,32,0,128,172,169,1024,137,1028,41,1164,33,138,1028,1038,1025,33,1029,1038,1070,34,160,1070,1039,1164,1165,32,1161,33,173,136,43,1158]

theorem envBound3235 : H12AffineFastState.Bounded env3235 := by
  intro p hp
  have h : env3235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3234_3235 : H12AffineEnvironment.transform 10 137 env3234 = env3235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env3234 == env3235) = true)

theorem identity3235 : scanCanonicalize (H12AffineFastState.compose env3235 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound3235 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3236 : List Nat := [2,4,8,0,32,0,35,15,10,1024,42,1028,41,1071,33,41,1028,1038,1025,33,1029,1038,1070,34,3,1070,1039,1071,1070,32,1066,33,14,43,43,1061]

theorem envBound3236 : H12AffineFastState.Bounded env3236 := by
  intro p hp
  have h : env3236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3235_3236 : H12AffineEnvironment.transform 6 35 env3235 = env3236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env3235 == env3236) = true)

theorem identity3236 : scanCanonicalize (H12AffineFastState.compose env3236 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3236 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env3237 : List Nat := [2,4,8,0,32,0,35,15,10,15,42,11,41,32,33,41,11,1,14,33,10,1,33,34,3,33,0,32,33,32,37,33,14,43,43,42]

theorem envBound3237 : H12AffineFastState.Bounded env3237 := by
  intro p hp
  have h : env3237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3236_3237 : H12AffineEnvironment.transform 9 15 env3236 = env3237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3236 == env3237) = true)

theorem identity3237 : scanCanonicalize (H12AffineFastState.compose env3237 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3237 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3238 : List Nat := [2,4,2,0,32,0,35,5,0,5,32,1,35,32,33,35,1,1,4,33,0,1,33,34,3,33,0,32,33,32,37,33,4,33,33,32]

theorem envBound3238 : H12AffineFastState.Bounded env3238 := by
  intro p hp
  have h : env3238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3237_3238 : H12AffineEnvironment.transform 2 2 env3237 = env3238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3237 == env3238) = true)

def env3239 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,65536,1028,262144,1025,32768,1028,4194304,4194337,41002,8329,4194337,320644,16384,16384,19492,74794,58533,172,17413,4284427,4194848]

theorem envBound3239 : H12AffineFastState.Bounded env3239 := by
  intro p hp
  have h : env3239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3226_3239 : H12AffineEnvironment.transform 3 1 env3226 = env3239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3226 == env3239) = true)

theorem identity3239 : scanCanonicalize (H12AffineFastState.compose env3239 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 50215) := by decide +kernel

theorem selectedBound3239 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3240 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50215,1028,262144,1025,32768,1028,4194304,4194337,41002,8329,4194337,320644,16384,16384,19492,57357,58533,172,17413,4236332,4194848]

theorem envBound3240 : H12AffineFastState.Bounded env3240 := by
  intro p hp
  have h : env3240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3239_3240 : H12AffineEnvironment.transform 15 50215 env3239 = env3240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50215 env3239 == env3240) = true)

theorem identity3240 : scanCanonicalize (H12AffineFastState.compose env3240 (packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 19596) := by decide +kernel

theorem selectedBound3240 : packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3241 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50215,1028,19596,1025,32768,1028,4194304,4194337,41002,8329,4194337,43016,16384,16384,19492,57357,58533,172,17413,4236332,4194848]

theorem envBound3241 : H12AffineFastState.Bounded env3241 := by
  intro p hp
  have h : env3241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3240_3241 : H12AffineEnvironment.transform 17 19596 env3240 = env3241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19596 env3240 == env3241) = true)

theorem identity3241 : scanCanonicalize (H12AffineFastState.compose env3241 (packedSelected [0,4,7,13,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound3241 : packedSelected [0,4,7,13,21,22] rootPS < 2^1333 := by decide +kernel

def env3242 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50215,1028,19596,1025,32768,1028,41001,40968,41002,8329,40968,43016,16384,16384,19492,57357,58533,172,17413,1029,41481]

theorem envBound3242 : H12AffineFastState.Bounded env3242 := by
  intro p hp
  have h : env3242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3241_3242 : H12AffineEnvironment.transform 21 41001 env3241 = env3242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env3241 == env3242) = true)

theorem identity3242 : scanCanonicalize (H12AffineFastState.compose env3242 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound3242 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3243 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,1677,32768,33450,1028,2561,1025,32768,1028,41001,40968,41002,8329,40968,43016,1677,1677,2729,42624,41512,172,648,1029,41481]

theorem envBound3243 : H12AffineFastState.Bounded env3243 := by
  intro p hp
  have h : env3243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3242_3243 : H12AffineEnvironment.transform 13 1677 env3242 = env3243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env3242 == env3243) = true)

theorem identity3243 : scanCanonicalize (H12AffineFastState.compose env3243 (packedSelected [0,1,2,3,4,7,9,11,12,13,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound3243 : packedSelected [0,1,2,3,4,7,9,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env3244 : List Nat := [2,4,8,1,32,1,128,173,137,1024,2048,1029,8192,1028,32768,32803,1028,2184,1025,32768,1028,41001,40968,41002,8329,40968,43016,1028,1028,2080,41993,41121,172,1,1029,41088]

theorem envBound3244 : H12AffineFastState.Bounded env3244 := by
  intro p hp
  have h : env3244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3243_3244 : H12AffineEnvironment.transform 8 137 env3243 = env3244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env3243 == env3244) = true)

theorem identity3244 : scanCanonicalize (H12AffineFastState.compose env3244 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3244 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3245 : List Nat := [2,4,8,1,32,1,41,4,32,1024,2048,1029,8192,1028,32768,32803,1028,2081,1025,32768,1028,41001,40968,41002,8224,40968,43016,1028,1028,2080,41993,40968,5,1,1029,41001]

theorem envBound3245 : H12AffineFastState.Bounded env3245 := by
  intro p hp
  have h : env3245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3244_3245 : H12AffineEnvironment.transform 6 41 env3244 = env3245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3244 == env3245) = true)

theorem identity3245 : scanCanonicalize (H12AffineFastState.compose env3245 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 1068) := by decide +kernel

theorem selectedBound3245 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env3246 : List Nat := [2,4,8,1,32,1,41,4,32,1024,2048,1029,1068,1028,32768,32803,1028,2081,1025,32768,1028,33797,33828,33798,1036,33828,35876,1028,1028,2080,32805,33828,5,1,1029,33797]

theorem envBound3246 : H12AffineFastState.Bounded env3246 := by
  intro p hp
  have h : env3246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3245_3246 : H12AffineEnvironment.transform 12 1068 env3245 = env3246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1068 env3245 == env3246) = true)

theorem identity3246 : scanCanonicalize (H12AffineFastState.compose env3246 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound3246 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3247 : List Nat := [2,4,8,1,32,1,41,4,32,1024,1070,1029,1068,1028,32768,32803,1028,1039,1025,32768,1028,33797,33828,33798,1036,33828,32778,1028,1028,1038,32805,33828,5,1,1029,33797]

theorem envBound3247 : H12AffineFastState.Bounded env3247 := by
  intro p hp
  have h : env3247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3246_3247 : H12AffineEnvironment.transform 10 1070 env3246 = env3247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env3246 == env3247) = true)

theorem identity3247 : scanCanonicalize (H12AffineFastState.compose env3247 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound3247 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3248 : List Nat := [2,4,8,1,32,1,41,4,32,1024,1070,1029,1068,1028,1071,1036,1028,1039,1025,1071,1028,42,11,41,1036,11,1061,1028,1028,1038,1034,11,5,1,1029,42]

theorem envBound3248 : H12AffineFastState.Bounded env3248 := by
  intro p hp
  have h : env3248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3247_3248 : H12AffineEnvironment.transform 14 1071 env3247 = env3248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env3247 == env3248) = true)

theorem identity3248 : scanCanonicalize (H12AffineFastState.compose env3248 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound3248 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env3249 : List Nat := [2,4,8,1,32,1,41,4,32,47,1,42,3,43,0,35,43,32,46,0,43,42,11,41,35,11,10,43,43,33,37,11,5,1,42,42]

theorem envBound3249 : H12AffineFastState.Bounded env3249 := by
  intro p hp
  have h : env3249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3248_3249 : H12AffineEnvironment.transform 9 47 env3248 = env3249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env3248 == env3249) = true)

theorem identity3249 : scanCanonicalize (H12AffineFastState.compose env3249 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3249 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3250 : List Nat := [2,4,8,1,1,1,8,4,1,14,1,11,3,10,0,2,10,1,15,0,10,11,11,8,2,11,10,10,10,0,4,11,5,1,11,11]

theorem envBound3250 : H12AffineFastState.Bounded env3250 := by
  intro p hp
  have h : env3250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3249_3250 : H12AffineEnvironment.transform 4 1 env3249 = env3250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3249 == env3250) = true)

theorem identity3250 : scanCanonicalize (H12AffineFastState.compose env3250 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3250 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3251 : List Nat := [2,4,3,1,1,1,3,4,1,5,1,0,3,1,0,2,1,1,4,0,1,0,0,3,2,0,1,1,1,0,4,0,5,1,0,0]

theorem envBound3251 : H12AffineFastState.Bounded env3251 := by
  intro p hp
  have h : env3251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3250_3251 : H12AffineEnvironment.transform 2 3 env3250 = env3251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3250 == env3251) = true)

theorem identity3251 : scanCanonicalize (H12AffineFastState.compose env3251 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3252 : List Nat := [2,1,3,1,1,1,3,1,1,0,1,0,3,1,0,2,1,1,1,0,1,0,0,3,2,0,1,1,1,0,1,0,0,1,0,0]

theorem envBound3252 : H12AffineFastState.Bounded env3252 := by
  intro p hp
  have h : env3252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3251_3252 : H12AffineEnvironment.transform 1 1 env3251 = env3252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3251 == env3252) = true)

def env3253 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,65536,1029,262144,1025,32768,1045,4194304,8388608,41002,8329,8388608,320661,16384,16400,19509,74794,12641428,188,17428,8478763,8389120]

theorem envBound3253 : H12AffineFastState.Bounded env3253 := by
  intro p hp
  have h : env3253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3224_3253 : H12AffineEnvironment.transform 7 189 env3224 = env3253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3224 == env3253) = true)

theorem identity3253 : scanCanonicalize (H12AffineFastState.compose env3253 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50319) := by decide +kernel

theorem selectedBound3253 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3254 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,50319,1029,262144,1025,32768,1045,4194304,8388608,41002,8329,8388608,320661,16384,16400,19509,57509,12641428,188,17428,8430756,8389120]

theorem envBound3254 : H12AffineFastState.Bounded env3254 := by
  intro p hp
  have h : env3254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3253_3254 : H12AffineEnvironment.transform 15 50319 env3253 = env3254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50319 env3253 == env3254) = true)

def env3255 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,50319,1029,262144,1025,32768,1045,4194304,4235392,41002,8329,4235392,320661,16384,16400,19509,57509,17428,188,17428,4195364,4235904]

theorem envBound3255 : H12AffineFastState.Bounded env3255 := by
  intro p hp
  have h : env3255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3254_3255 : H12AffineEnvironment.transform 22 4235392 env3254 = env3255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env3254 == env3255) = true)

theorem identity3255 : scanCanonicalize (H12AffineFastState.compose env3255 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound3255 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3256 : List Nat := [2,4,8,16,32,16,57,4,512,1024,2048,1044,8192,16384,32768,50230,1029,262144,1025,32768,1045,4194304,4235321,41002,8240,4235321,320556,16384,16400,19509,57372,17428,5,17428,4195364,4235833]

theorem envBound3256 : H12AffineFastState.Bounded env3256 := by
  intro p hp
  have h : env3256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3255_3256 : H12AffineEnvironment.transform 6 57 env3255 = env3256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env3255 == env3256) = true)

theorem identity3256 : scanCanonicalize (H12AffineFastState.compose env3256 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound3256 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3257 : List Nat := [2,4,8,16,32,16,57,4,512,1024,2048,1044,8192,16384,8217,25647,1029,262144,1025,8217,1045,4194304,4194336,51,8240,4194336,279605,16384,16400,19509,16389,17428,5,17428,4195364,4194848]

theorem envBound3257 : H12AffineFastState.Bounded env3257 := by
  intro p hp
  have h : env3257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3256_3257 : H12AffineEnvironment.transform 14 8217 env3256 = env3257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env3256 == env3257) = true)

theorem identity3257 : scanCanonicalize (H12AffineFastState.compose env3257 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3257 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3258 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,16384,8201,25647,1029,262144,1025,8201,1029,4194304,4194336,35,8224,4194336,279589,16384,16384,19493,16389,17412,5,17412,4195364,4194848]

theorem envBound3258 : H12AffineFastState.Bounded env3258 := by
  intro p hp
  have h : env3258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3257_3258 : H12AffineEnvironment.transform 3 0 env3257 = env3258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3257 == env3258) = true)

theorem identity3258 : scanCanonicalize (H12AffineFastState.compose env3258 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 264224) := by decide +kernel

theorem selectedBound3258 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3259 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,16384,8201,25647,1029,262144,1025,8201,1029,264224,264192,35,8224,264192,279589,16384,16384,19493,16389,17412,5,17412,265220,264704]

theorem envBound3259 : H12AffineFastState.Bounded env3259 := by
  intro p hp
  have h : env3259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3258_3259 : H12AffineEnvironment.transform 21 264224 env3258 = env3259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264224 env3258 == env3259) = true)

theorem identity3259 : scanCanonicalize (H12AffineFastState.compose env3259 (packedSelected [0,6,7] rootPS)) = affineNative (2^(17+1) ^^^ 25091) := by decide +kernel

theorem selectedBound3259 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env3260 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,16384,8201,25647,1029,25091,1025,8201,1029,27171,27139,35,8224,27139,9766,16384,16384,19493,16389,17412,5,17412,28167,26627]

theorem envBound3260 : H12AffineFastState.Bounded env3260 := by
  intro p hp
  have h : env3260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3259_3260 : H12AffineEnvironment.transform 17 25091 env3259 = env3260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25091 env3259 == env3260) = true)

theorem identity3260 : scanCanonicalize (H12AffineFastState.compose env3260 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound3260 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env3261 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8,16384,1,17447,1029,16907,1025,1,1029,18987,18955,35,40,18955,1582,16384,16384,19493,16389,17412,5,17412,19983,18443]

theorem envBound3261 : H12AffineFastState.Bounded env3261 := by
  intro p hp
  have h : env3261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3260_3261 : H12AffineEnvironment.transform 12 8 env3260 = env3261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env3260 == env3261) = true)

theorem identity3261 : scanCanonicalize (H12AffineFastState.compose env3261 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound3261 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env3262 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8,2081,1,3078,1029,2602,1025,1,1029,522,554,35,40,554,1582,2081,2081,1028,2084,3109,5,3109,1582,42]

theorem envBound3262 : H12AffineFastState.Bounded env3262 := by
  intro p hp
  have h : env3262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3261_3262 : H12AffineEnvironment.transform 13 2081 env3261 = env3262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env3261 == env3262) = true)

theorem identity3262 : scanCanonicalize (H12AffineFastState.compose env3262 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3262 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3263 : List Nat := [2,4,8,0,32,0,41,4,512,1024,1582,1028,8,1551,1,552,1029,1028,1025,1,1029,522,554,35,40,554,1582,1551,1551,1028,1546,523,5,523,1582,42]

theorem envBound3263 : H12AffineFastState.Bounded env3263 := by
  intro p hp
  have h : env3263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3262_3263 : H12AffineEnvironment.transform 10 1582 env3262 = env3263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env3262 == env3263) = true)

theorem identity3263 : scanCanonicalize (H12AffineFastState.compose env3263 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound3263 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3264 : List Nat := [2,4,8,0,32,0,41,4,512,526,32,522,8,1,1,552,523,522,527,1,523,522,554,35,40,554,32,1,1,522,4,523,5,523,32,42]

theorem envBound3264 : H12AffineFastState.Bounded env3264 := by
  intro p hp
  have h : env3264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3263_3264 : H12AffineEnvironment.transform 9 526 env3263 = env3264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env3263 == env3264) = true)

theorem identity3264 : scanCanonicalize (H12AffineFastState.compose env3264 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3264 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3265 : List Nat := [2,4,8,0,10,0,3,4,512,526,10,522,8,1,1,514,523,522,527,1,523,522,512,9,2,512,10,1,1,522,4,523,5,523,10,0]

theorem envBound3265 : H12AffineFastState.Bounded env3265 := by
  intro p hp
  have h : env3265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3264_3265 : H12AffineEnvironment.transform 4 10 env3264 = env3265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3264 == env3265) = true)

theorem identity3265 : scanCanonicalize (H12AffineFastState.compose env3265 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound3265 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env3266 : List Nat := [2,4,8,0,10,0,3,4,11,5,10,1,8,1,1,9,0,1,4,1,0,1,11,9,2,11,10,1,1,1,4,0,5,0,10,0]

theorem envBound3266 : H12AffineFastState.Bounded env3266 := by
  intro p hp
  have h : env3266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3265_3266 : H12AffineEnvironment.transform 8 11 env3265 = env3266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env3265 == env3266) = true)

def env3267 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,50319,1029,262144,1025,32768,1045,4194304,4235393,41002,8329,4235393,320661,16384,16400,19509,57509,17429,188,17428,4195365,4235905]

theorem envBound3267 : H12AffineFastState.Bounded env3267 := by
  intro p hp
  have h : env3267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3254_3267 : H12AffineEnvironment.transform 22 4235393 env3254 = env3267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env3254 == env3267) = true)

theorem identity3267 : scanCanonicalize (H12AffineFastState.compose env3267 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3267 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3268 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,50319,1029,262144,1025,32768,1029,4194304,4235393,41002,8329,4235393,320645,16384,16384,19493,57509,17413,172,17412,4195365,4235905]

theorem envBound3268 : H12AffineFastState.Bounded env3268 := by
  intro p hp
  have h : env3268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3267_3268 : H12AffineEnvironment.transform 3 0 env3267 = env3268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3267 == env3268) = true)

theorem identity3268 : scanCanonicalize (H12AffineFastState.compose env3268 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound3268 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3269 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,50319,1029,262144,1025,32768,1029,41001,168,41002,8329,168,320645,16384,16384,19493,57509,17413,172,17412,41996,680]

theorem envBound3269 : H12AffineFastState.Bounded env3269 := by
  intro p hp
  have h : env3269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3268_3269 : H12AffineEnvironment.transform 21 41001 env3268 = env3269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env3268 == env3269) = true)

theorem identity3269 : scanCanonicalize (H12AffineFastState.compose env3269 (packedSelected [0,3,5,7,10,17,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 19973) := by decide +kernel

theorem selectedBound3269 : packedSelected [0,3,5,7,10,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3270 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,50319,1029,19973,1025,32768,1029,41001,168,41002,8329,168,43648,16384,16384,19493,57509,17413,172,17412,41996,680]

theorem envBound3270 : H12AffineFastState.Bounded env3270 := by
  intro p hp
  have h : env3270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3269_3270 : H12AffineEnvironment.transform 17 19973 env3269 = env3270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19973 env3269 == env3270) = true)

theorem identity3270 : scanCanonicalize (H12AffineFastState.compose env3270 (packedSelected [1,3,11,13,17,23] rootPS)) = affineNative (2^(14+1) ^^^ 25732) := by decide +kernel

theorem selectedBound3270 : packedSelected [1,3,11,13,17,23] rootPS < 2^1333 := by decide +kernel

def env3271 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,25732,8203,1029,19973,1025,25732,1029,17581,168,17582,8329,168,19972,16384,16384,19493,1057,17413,172,17412,16520,680]

theorem envBound3271 : H12AffineFastState.Bounded env3271 := by
  intro p hp
  have h : env3271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3270_3271 : H12AffineEnvironment.transform 14 25732 env3270 = env3271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25732 env3270 == env3271) = true)

theorem identity3271 : scanCanonicalize (H12AffineFastState.compose env3271 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3271 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3272 : List Nat := [2,4,8,0,32,0,128,173,1,1024,2048,1028,8192,16384,25732,8203,1029,19460,1025,25732,1029,17581,168,17582,8329,168,19461,16384,16384,19493,1057,17413,172,17412,16520,169]

theorem envBound3272 : H12AffineFastState.Bounded env3272 := by
  intro p hp
  have h : env3272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3271_3272 : H12AffineEnvironment.transform 8 1 env3271 = env3272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3271 == env3272) = true)

theorem identity3272 : scanCanonicalize (H12AffineFastState.compose env3272 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 8195) := by decide +kernel

theorem selectedBound3272 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env3273 : List Nat := [2,4,8,0,32,0,128,173,1,1024,2048,1028,8192,8195,1159,8203,1029,11271,1025,1159,1029,9390,168,9389,8329,168,11270,8195,8195,11302,1057,9222,172,9223,8331,169]

theorem envBound3273 : H12AffineFastState.Bounded env3273 := by
  intro p hp
  have h : env3273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3272_3273 : H12AffineEnvironment.transform 13 8195 env3272 = env3273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8195 env3272 == env3273) = true)

theorem identity3273 : scanCanonicalize (H12AffineFastState.compose env3273 (packedSelected [0,2,3,6,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound3273 : packedSelected [0,2,3,6,8,10] rootPS < 2^1333 := by decide +kernel

def env3274 : List Nat := [2,4,8,0,32,0,128,173,1,1024,32,1028,8192,8195,1159,8203,1029,9255,1025,1159,1029,9390,168,9389,8329,168,9254,8195,8195,9222,1057,9222,172,9223,8331,169]

theorem envBound3274 : H12AffineFastState.Bounded env3274 := by
  intro p hp
  have h : env3274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3273_3274 : H12AffineEnvironment.transform 10 32 env3273 = env3274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env3273 == env3274) = true)

theorem identity3274 : scanCanonicalize (H12AffineFastState.compose env3274 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3275 : List Nat := [2,4,8,0,32,0,40,5,1,1024,32,1028,8192,8195,1071,8203,1029,9255,1025,1071,1029,9222,0,9221,8225,0,9254,8195,8195,9222,1057,9222,4,9223,8227,1]

theorem envBound3275 : H12AffineFastState.Bounded env3275 := by
  intro p hp
  have h : env3275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3274_3275 : H12AffineEnvironment.transform 6 40 env3274 = env3275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3274 == env3275) = true)

theorem identity3275 : scanCanonicalize (H12AffineFastState.compose env3275 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1068) := by decide +kernel

theorem selectedBound3275 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env3276 : List Nat := [2,4,8,0,32,0,40,5,1,1024,32,1028,1068,1071,1071,1063,1029,11,1025,1071,1029,42,0,41,1037,0,10,1071,1071,42,1057,42,4,43,1039,1]

theorem envBound3276 : H12AffineFastState.Bounded env3276 := by
  intro p hp
  have h : env3276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3275_3276 : H12AffineEnvironment.transform 12 1068 env3275 = env3276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1068 env3275 == env3276) = true)

theorem identity3276 : scanCanonicalize (H12AffineFastState.compose env3276 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound3276 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3277 : List Nat := [2,4,8,0,32,0,40,5,1,37,32,33,9,10,10,2,32,11,36,10,32,42,0,41,40,0,10,10,10,42,4,42,4,43,42,1]

theorem envBound3277 : H12AffineFastState.Bounded env3277 := by
  intro p hp
  have h : env3277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3276_3277 : H12AffineEnvironment.transform 9 37 env3276 = env3277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env3276 == env3277) = true)

def env3278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1025,32768,1044,4194304,8388608,41002,8329,8388609,320661,16384,16812,19509,74794,12641576,257,17428,8479126,8389564]

theorem envBound3278 : H12AffineFastState.Bounded env3278 := by
  intro p hp
  have h : env3278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3223_3278 : H12AffineEnvironment.transform 5 17 env3223 = env3278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3223 == env3278) = true)

theorem identity3278 : scanCanonicalize (H12AffineFastState.compose env3278 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3278 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3279 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1025,32768,1044,4194304,444,41002,8329,445,320661,16384,16812,19509,74794,4252820,257,17428,90154,512]

theorem envBound3279 : H12AffineFastState.Bounded env3279 := by
  intro p hp
  have h : env3279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3278_3279 : H12AffineEnvironment.transform 22 444 env3278 = env3279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3278 == env3279) = true)

theorem identity3279 : scanCanonicalize (H12AffineFastState.compose env3279 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3279 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3280 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1025,32768,1044,41348,444,41002,8329,445,320661,16384,16812,19509,74794,17680,257,17428,90154,512]

theorem envBound3280 : H12AffineFastState.Bounded env3280 := by
  intro p hp
  have h : env3280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3279_3280 : H12AffineEnvironment.transform 21 41348 env3279 = env3280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3279 == env3280) = true)

theorem identity3280 : scanCanonicalize (H12AffineFastState.compose env3280 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33711) := by decide +kernel

theorem selectedBound3280 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3281 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,33711,1464,262144,1025,32768,1044,41348,444,41002,8329,445,320661,16384,16812,19509,42885,17680,257,17428,58245,512]

theorem envBound3281 : H12AffineFastState.Bounded env3281 := by
  intro p hp
  have h : env3281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3280_3281 : H12AffineEnvironment.transform 15 33711 env3280 = env3281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33711 env3280 == env3281) = true)

theorem identity3281 : scanCanonicalize (H12AffineFastState.compose env3281 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3281 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3282 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25751,1464,262144,1025,26424,1044,18108,444,18194,8329,445,263085,16384,16812,19509,16573,17680,257,17428,1213,512]

theorem envBound3282 : H12AffineFastState.Bounded env3282 := by
  intro p hp
  have h : env3282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3281_3282 : H12AffineEnvironment.transform 14 26424 env3281 = env3282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3281 == env3282) = true)

theorem identity3282 : scanCanonicalize (H12AffineFastState.compose env3282 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound3282 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3283 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25751,1464,20156,1025,26424,1044,18108,444,18194,8329,445,19729,16384,16812,19509,16573,17680,257,17428,1213,512]

theorem envBound3283 : H12AffineFastState.Bounded env3283 := by
  intro p hp
  have h : env3283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3282_3283 : H12AffineEnvironment.transform 17 20156 env3282 = env3283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env3282 == env3283) = true)

def env3284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849104,16385,16892,547952,598059,12644669,525568,545873,8479126,8914924]

theorem envBound3284 : H12AffineFastState.Bounded env3284 := by
  intro p hp
  have h : env3284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3165_3284 : H12AffineEnvironment.transform 27 16385 env3165 = env3284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3165 == env3284) = true)

def env3285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323792,16385,16892,22640,74795,12644669,256,20561,8479126,8389612]

theorem envBound3285 : H12AffineFastState.Bounded env3285 := by
  intro p hp
  have h : env3285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3284_3285 : H12AffineEnvironment.transform 18 1024 env3284 = env3285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3284 == env3285) = true)

theorem identity3285 : scanCanonicalize (H12AffineFastState.compose env3285 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61909) := by decide +kernel

theorem selectedBound3285 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,61909,8388608,41002,8329,8388689,323792,16385,16892,22640,74795,8388840,256,20561,8479126,8389612]

theorem envBound3286 : H12AffineFastState.Bounded env3286 := by
  intro p hp
  have h : env3286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3285_3286 : H12AffineEnvironment.transform 21 61909 env3285 = env3286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61909 env3285 == env3286) = true)

def env3287 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61829,8388608,41002,8329,8388609,323712,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3287 : H12AffineFastState.Bounded env3287 := by
  intro p hp
  have h : env3287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3286_3287 : H12AffineEnvironment.transform 5 16 env3286 = env3287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3286 == env3287) = true)

def env3288 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,262144,1024,8352,4097,20773,8388608,138,8329,8388609,282656,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3288 : H12AffineFastState.Bounded env3288 := by
  intro p hp
  have h : env3288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3287_3288 : H12AffineEnvironment.transform 14 8352 env3287 = env3288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3287 == env3288) = true)

theorem identity3288 : scanCanonicalize (H12AffineFastState.compose env3288 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96267) := by decide +kernel

theorem selectedBound3288 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3289 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96267,1024,8352,4097,20773,8388608,138,8329,8388609,75819,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3289 : H12AffineFastState.Bounded env3289 := by
  intro p hp
  have h : env3289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3288_3289 : H12AffineEnvironment.transform 17 96267 env3288 = env3289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96267 env3288 == env3289) = true)

theorem identity3289 : scanCanonicalize (H12AffineFastState.compose env3289 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound3289 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env3290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96267,1024,8352,4097,20773,73875,138,8329,73874,75819,16385,16812,22560,74795,73771,256,20481,16645,74543]

theorem envBound3290 : H12AffineFastState.Bounded env3290 := by
  intro p hp
  have h : env3290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3289_3290 : H12AffineEnvironment.transform 22 73875 env3289 = env3290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env3289 == env3290) = true)

theorem identity3290 : scanCanonicalize (H12AffineFastState.compose env3290 (packedSelected [1,5,6,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound3290 : packedSelected [1,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3291 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2106,8192,16384,8352,65536,2454,90161,1024,8352,2107,18719,73875,138,8329,73874,75819,16385,16812,16410,74795,73771,256,18491,16645,74543]

theorem envBound3291 : H12AffineFastState.Bounded env3291 := by
  intro p hp
  have h : env3291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3290_3291 : H12AffineEnvironment.transform 11 2106 env3290 = env3291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env3290 == env3291) = true)

theorem identity3291 : scanCanonicalize (H12AffineFastState.compose env3291 (packedSelected [2,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 27068) := by decide +kernel

theorem selectedBound3291 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env3292 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2106,8192,16384,8352,27068,2454,2445,1024,8352,2107,18719,18735,138,8329,18734,16791,16385,16812,16410,19863,18839,256,18491,16645,19091]

theorem envBound3292 : H12AffineFastState.Bounded env3292 := by
  intro p hp
  have h : env3292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3291_3292 : H12AffineEnvironment.transform 15 27068 env3291 = env3292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 27068 env3291 == env3292) = true)

theorem identity3292 : scanCanonicalize (H12AffineFastState.compose env3292 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3292 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env3293 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2106,8192,1692,8352,12064,2454,2445,1024,8352,2107,3971,4019,138,8329,4018,1803,1693,1840,1670,2827,3851,256,3751,1945,3087]

theorem envBound3293 : H12AffineFastState.Bounded env3293 := by
  intro p hp
  have h : env3293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3292_3293 : H12AffineEnvironment.transform 13 1692 env3292 = env3293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env3292 == env3293) = true)

theorem identity3293 : scanCanonicalize (H12AffineFastState.compose env3293 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3293 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env3294 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,2106,8192,1692,8352,11812,2194,2185,1024,8352,2107,3719,3767,138,8329,3766,1551,1693,1588,1670,2575,3599,4,3751,1693,3087]

theorem envBound3294 : H12AffineFastState.Bounded env3294 := by
  intro p hp
  have h : env3294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3293_3294 : H12AffineEnvironment.transform 7 4 env3293 = env3294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3293 == env3294) = true)

theorem identity3294 : scanCanonicalize (H12AffineFastState.compose env3294 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound3294 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3295 : List Nat := [2,4,8,16,32,16,51,4,512,1024,2048,2106,8192,1583,8211,11812,2081,2106,1024,8211,2107,3636,3588,57,8250,3589,1551,1582,1588,1589,2575,3599,4,3604,1582,3087]

theorem envBound3295 : H12AffineFastState.Bounded env3295 := by
  intro p hp
  have h : env3295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3294_3295 : H12AffineEnvironment.transform 6 51 env3294 = env3295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env3294 == env3295) = true)

theorem identity3295 : scanCanonicalize (H12AffineFastState.compose env3295 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound3295 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env3296 : List Nat := [2,4,8,16,32,16,51,4,512,1024,2048,2106,2600,1583,2619,1036,2081,2106,1024,2619,2107,3636,3588,57,2578,3589,1551,1582,1588,1589,2575,3599,4,3604,1582,3087]

theorem envBound3296 : H12AffineFastState.Bounded env3296 := by
  intro p hp
  have h : env3296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3295_3296 : H12AffineEnvironment.transform 12 2600 env3295 = env3296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env3295 == env3296) = true)

theorem identity3296 : scanCanonicalize (H12AffineFastState.compose env3296 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3296 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env3297 : List Nat := [2,4,8,11,32,11,40,4,512,1024,2048,2081,2600,1583,2592,1036,2081,2081,1024,2592,2080,3631,3588,34,2569,3589,1551,1582,1583,1582,2575,3599,4,3599,1582,3087]

theorem envBound3297 : H12AffineFastState.Bounded env3297 := by
  intro p hp
  have h : env3297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3296_3297 : H12AffineEnvironment.transform 3 11 env3296 = env3297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3296 == env3297) = true)

theorem identity3297 : scanCanonicalize (H12AffineFastState.compose env3297 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3297 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3298 : List Nat := [2,4,8,11,32,11,40,4,1,1024,2048,2081,2089,1070,2081,1036,2081,2081,1024,2081,2080,3118,3077,34,2056,3076,1038,1071,1070,1071,2062,3086,4,3086,1071,3087]

theorem envBound3298 : H12AffineFastState.Bounded env3298 := by
  intro p hp
  have h : env3298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3297_3298 : H12AffineEnvironment.transform 8 1 env3297 = env3298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3297 == env3298) = true)

theorem identity3298 : scanCanonicalize (H12AffineFastState.compose env3298 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound3298 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3299 : List Nat := [2,4,8,11,32,11,40,4,1,1024,32,1,9,1070,1,1036,1,1,1024,1,0,1038,1061,34,40,1060,1038,1071,1070,1071,46,1070,4,1070,1071,1071]

theorem envBound3299 : H12AffineFastState.Bounded env3299 := by
  intro p hp
  have h : env3299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3298_3299 : H12AffineEnvironment.transform 10 32 env3298 = env3299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env3298 == env3299) = true)

def env3300 : List Nat := [2,4,8,11,32,11,40,4,1,32,32,1,9,14,1,44,1,1,32,1,0,46,5,34,40,4,46,15,14,15,46,14,4,14,15,15]

theorem envBound3300 : H12AffineFastState.Bounded env3300 := by
  intro p hp
  have h : env3300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3299_3300 : H12AffineEnvironment.transform 9 32 env3299 = env3300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3299 == env3300) = true)

theorem identity3300 : scanCanonicalize (H12AffineFastState.compose env3300 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3301 : List Nat := [2,4,7,4,32,4,39,4,1,32,32,1,6,1,1,35,1,1,32,1,0,33,5,34,39,4,33,0,1,0,33,1,4,1,0,0]

theorem envBound3301 : H12AffineFastState.Bounded env3301 := by
  intro p hp
  have h : env3301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3300_3301 : H12AffineEnvironment.transform 2 7 env3300 = env3301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3300 == env3301) = true)

theorem identity3301 : scanCanonicalize (H12AffineFastState.compose env3301 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3301 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3302 : List Nat := [2,0,3,0,32,0,35,0,1,32,32,1,2,1,1,35,1,1,32,1,0,33,1,34,35,0,33,0,1,0,33,1,0,1,0,0]

theorem envBound3302 : H12AffineFastState.Bounded env3302 := by
  intro p hp
  have h : env3302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3301_3302 : H12AffineEnvironment.transform 1 0 env3301 = env3302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3301 == env3302) = true)

def leafEnv3302 : List Nat := [2,0,3,0,32,0,35,0,1,32,32,1,2,1,1,35,1,1,32,1,0,33,1,34,33,35,1,0,33,0,1,0,33,1,0,1,0,2,0,0,1,1,0]

def active3302 : List Nat := [0,4]

def tree3302 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3302 : H12WitnessSearch.Good tree3302 := H12GlobalWitnessIndex.good

theorem leafIdentity3302 : H12AffineFastState.composeSystem env3302 rootObs = leafEnv3302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3302 rootObs == leafEnv3302) = true)

theorem terminalChecked3302 : H12PackedTerminal.terminalCheckFast leafEnv3302 active3302 tree3302 = true := by decide +kernel

def env3303 : List Nat := [2,4,8,11,32,11,40,4,1,33,32,1,9,15,1,45,1,1,33,1,0,47,4,34,40,5,47,14,15,14,46,15,4,15,14,14]

theorem envBound3303 : H12AffineFastState.Bounded env3303 := by
  intro p hp
  have h : env3303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3299_3303 : H12AffineEnvironment.transform 9 33 env3299 = env3303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env3299 == env3303) = true)

def env3304 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,262144,1024,8353,4097,20772,8388608,139,8329,8388609,282657,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3304 : H12AffineFastState.Bounded env3304 := by
  intro p hp
  have h : env3304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3287_3304 : H12AffineEnvironment.transform 14 8353 env3287 = env3304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3287 == env3304) = true)

theorem identity3304 : scanCanonicalize (H12AffineFastState.compose env3304 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96679) := by decide +kernel

theorem selectedBound3304 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3305 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96679,1024,8353,4097,20772,8388608,139,8329,8388609,76166,16385,16812,22560,74795,8388792,256,20481,8479126,8389564]

theorem envBound3305 : H12AffineFastState.Bounded env3305 := by
  intro p hp
  have h : env3305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3304_3305 : H12AffineEnvironment.transform 17 96679 env3304 = env3305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96679 env3304 == env3305) = true)

theorem identity3305 : scanCanonicalize (H12AffineFastState.compose env3305 (packedSelected [1,3,4,9,11,13,18,20,21,23,24,28,32] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound3305 : packedSelected [1,3,4,9,11,13,18,20,21,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env3306 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96679,1024,8353,4097,20772,73874,139,8329,73875,76166,16385,16812,22560,74795,73770,256,20481,16644,74542]

theorem envBound3306 : H12AffineFastState.Bounded env3306 := by
  intro p hp
  have h : env3306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3305_3306 : H12AffineEnvironment.transform 22 73874 env3305 = env3306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env3305 == env3306) = true)

theorem identity3306 : scanCanonicalize (H12AffineFastState.compose env3306 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound3306 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3307 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8353,65536,4524,76047,1024,8353,4097,396,73874,139,8329,73875,76166,4265,4356,2184,74795,73770,256,169,4524,74542]

theorem envBound3307 : H12AffineFastState.Bounded env3307 := by
  intro p hp
  have h : env3307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3306_3307 : H12AffineEnvironment.transform 13 4264 env3306 = env3307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3306 == env3307) = true)

theorem identity3307 : scanCanonicalize (H12AffineFastState.compose env3307 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 11149) := by decide +kernel

theorem selectedBound3307 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3308 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8353,11149,4524,642,1024,8353,4097,396,2847,139,8329,2846,523,4265,4356,2184,4006,2983,256,169,4524,2211]

theorem envBound3308 : H12AffineFastState.Bounded env3308 := by
  intro p hp
  have h : env3308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3307_3308 : H12AffineEnvironment.transform 15 11149 env3307 = env3308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11149 env3307 == env3308) = true)

theorem identity3308 : scanCanonicalize (H12AffineFastState.compose env3308 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 5945) := by decide +kernel

theorem selectedBound3308 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env3309 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5945,4264,6040,7348,4524,642,1024,6040,4097,396,2847,139,6064,2846,523,4265,4356,2184,4006,2983,256,169,4524,2211]

theorem envBound3309 : H12AffineFastState.Bounded env3309 := by
  intro p hp
  have h : env3309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3308_3309 : H12AffineEnvironment.transform 12 5945 env3308 = env3309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5945 env3308 == env3309) = true)

theorem identity3309 : scanCanonicalize (H12AffineFastState.compose env3309 (packedSelected [0,1,3,5,7,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3261) := by decide +kernel

theorem selectedBound3309 : packedSelected [0,1,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env3310 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3261,2948,3093,2853,9,3345,642,1024,2853,3260,396,2847,139,2829,2846,523,3092,3513,2184,4006,2983,256,169,3345,2211]

theorem envBound3310 : H12AffineFastState.Bounded env3310 := by
  intro p hp
  have h : env3310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3309_3310 : H12AffineEnvironment.transform 11 3261 env3309 = env3310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3261 env3309 == env3310) = true)

theorem identity3310 : scanCanonicalize (H12AffineFastState.compose env3310 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound3310 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env3311 : List Nat := [2,4,8,16,32,16,128,256,512,1024,799,1954,155,1802,58,9,1550,642,1024,58,1955,396,0,139,18,1,523,1803,1702,919,1209,184,256,169,1550,956]

theorem envBound3311 : H12AffineFastState.Bounded env3311 := by
  intro p hp
  have h : env3311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3310_3311 : H12AffineEnvironment.transform 10 799 env3310 = env3311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env3310 == env3311) = true)

theorem identity3311 : scanCanonicalize (H12AffineFastState.compose env3311 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3311 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3312 : List Nat := [2,4,8,0,32,0,128,256,512,1024,783,1954,139,1802,42,9,1550,642,1024,42,1955,396,0,139,2,1,523,1803,1702,903,1193,168,256,169,1550,940]

theorem envBound3312 : H12AffineFastState.Bounded env3312 := by
  intro p hp
  have h : env3312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3311_3312 : H12AffineEnvironment.transform 3 0 env3311 = env3312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3311 == env3312) = true)

theorem identity3312 : scanCanonicalize (H12AffineFastState.compose env3312 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound3312 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3313 : List Nat := [2,4,8,0,32,0,35,256,512,1024,783,1793,40,1802,42,9,1550,545,1024,42,1792,303,0,40,2,1,523,1803,1541,804,1034,11,256,10,1550,783]

theorem envBound3313 : H12AffineFastState.Bounded env3313 := by
  intro p hp
  have h : env3313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3312_3313 : H12AffineEnvironment.transform 6 35 env3312 = env3313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env3312 == env3313) = true)

theorem identity3313 : scanCanonicalize (H12AffineFastState.compose env3313 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound3313 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3314 : List Nat := [2,4,8,0,32,0,35,46,512,1024,545,1583,40,1572,42,9,1550,545,1024,42,1582,1,0,40,2,1,523,1573,1541,522,1034,11,46,10,1550,545]

theorem envBound3314 : H12AffineFastState.Bounded env3314 := by
  intro p hp
  have h : env3314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3313_3314 : H12AffineEnvironment.transform 7 46 env3313 = env3314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env3313 == env3314) = true)

theorem identity3314 : scanCanonicalize (H12AffineFastState.compose env3314 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound3314 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3315 : List Nat := [2,4,8,0,32,0,35,46,42,1024,11,1029,40,1038,42,9,1060,11,1024,42,1028,1,0,40,2,1,33,1039,1071,32,1034,11,46,10,1060,11]

theorem envBound3315 : H12AffineFastState.Bounded env3315 := by
  intro p hp
  have h : env3315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3314_3315 : H12AffineEnvironment.transform 8 42 env3314 = env3315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env3314 == env3315) = true)

theorem identity3315 : scanCanonicalize (H12AffineFastState.compose env3315 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3315 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3316 : List Nat := [2,4,2,0,32,0,35,36,32,1024,1,1029,34,1028,32,3,1060,1,1024,32,1028,1,0,34,2,1,33,1029,1061,32,1024,1,36,0,1060,1]

theorem envBound3316 : H12AffineFastState.Bounded env3316 := by
  intro p hp
  have h : env3316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3315_3316 : H12AffineEnvironment.transform 2 2 env3315 = env3316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3315 == env3316) = true)

theorem identity3316 : scanCanonicalize (H12AffineFastState.compose env3316 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3317 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1029,3,1028,1,3,1029,1,1024,1,1028,1,0,3,2,1,0,1029,1028,1,1024,1,5,0,1029,1]

theorem envBound3317 : H12AffineFastState.Bounded env3317 := by
  intro p hp
  have h : env3317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3316_3317 : H12AffineEnvironment.transform 4 1 env3316 = env3317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3316 == env3317) = true)

def leafEnv3317 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1029,3,1028,1,3,1029,1,1024,1,1028,1,0,3,1024,2,1,1,0,1029,1028,1,1024,1,5,0,4,3,1029,1,1,1028,0]

def active3317 : List Nat := [0,1,9]

def tree3317 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3317 : H12WitnessSearch.Good tree3317 := H12GlobalWitnessIndex.good

theorem leafIdentity3317 : H12AffineFastState.composeSystem env3317 rootObs = leafEnv3317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3317 rootObs == leafEnv3317) = true)

theorem terminalChecked3317 : H12PackedTerminal.terminalCheckFast leafEnv3317 active3317 tree3317 = true := by decide +kernel

def env3318 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61828,8388608,41002,8329,8388608,323713,16385,16813,22561,74795,8388793,256,20480,8479126,8389565]

theorem envBound3318 : H12AffineFastState.Bounded env3318 := by
  intro p hp
  have h : env3318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3286_3318 : H12AffineEnvironment.transform 5 17 env3286 = env3318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3286 == env3318) = true)

theorem identity3318 : scanCanonicalize (H12AffineFastState.compose env3318 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3318 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3319 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61828,445,41002,8329,445,323713,16385,16813,22561,74795,260,256,20480,90155,512]

theorem envBound3319 : H12AffineFastState.Bounded env3319 := by
  intro p hp
  have h : env3319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3318_3319 : H12AffineEnvironment.transform 22 445 env3318 = env3319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3318 == env3319) = true)

theorem identity3319 : scanCanonicalize (H12AffineFastState.compose env3319 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound3319 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3320 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1024,32768,4097,41348,445,41002,8329,445,303233,4097,4525,2081,74795,260,256,0,77867,512]

theorem envBound3320 : H12AffineFastState.Bounded env3320 := by
  intro p hp
  have h : env3320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3319_3320 : H12AffineEnvironment.transform 13 4096 env3319 = env3320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3319 == env3320) = true)

theorem identity3320 : scanCanonicalize (H12AffineFastState.compose env3320 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3320 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3321 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,38842,4525,262144,1024,32768,4097,41348,445,41002,8329,445,303233,4097,4525,2081,45969,260,256,0,42897,512]

theorem envBound3321 : H12AffineFastState.Bounded env3321 := by
  intro p hp
  have h : env3321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3320_3321 : H12AffineEnvironment.transform 15 38842 env3320 = env3321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3320 == env3321) = true)

theorem identity3321 : scanCanonicalize (H12AffineFastState.compose env3321 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound3321 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,262144,1024,14137,4097,5821,445,5907,8329,445,268216,4097,4525,2081,1192,260,256,0,4264,512]

theorem envBound3322 : H12AffineFastState.Bounded env3322 := by
  intro p hp
  have h : env3322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3321_3322 : H12AffineEnvironment.transform 14 14137 env3321 = env3322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env3321 == env3322) = true)

theorem identity3322 : scanCanonicalize (H12AffineFastState.compose env3322 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound3322 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3323 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,2184,1024,14137,4097,5821,445,5907,8329,445,7984,4097,4525,2081,1192,260,256,0,4264,512]

theorem envBound3323 : H12AffineFastState.Bounded env3323 := by
  intro p hp
  have h : env3323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3322_3323 : H12AffineEnvironment.transform 17 2184 env3322 = env3323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env3322 == env3323) = true)

theorem identity3323 : scanCanonicalize (H12AffineFastState.compose env3323 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3323 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env3324 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,13972,8323,4096,2184,1024,13972,4097,5821,16,5822,8329,16,7837,4097,4096,2081,1192,169,173,0,4264,512]

theorem envBound3324 : H12AffineFastState.Bounded env3324 := by
  intro p hp
  have h : env3324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3323_3324 : H12AffineEnvironment.transform 7 173 env3323 = env3324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3323 == env3324) = true)

theorem identity3324 : scanCanonicalize (H12AffineFastState.compose env3324 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound3324 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3325 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,4096,8192,4096,13972,8323,4096,643,1024,13972,4097,5821,16,5822,8329,16,5270,4097,4096,554,1192,169,173,0,4264,512]

theorem envBound3325 : H12AffineFastState.Bounded env3325 := by
  intro p hp
  have h : env3325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3324_3325 : H12AffineEnvironment.transform 10 523 env3324 = env3325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env3324 == env3325) = true)

theorem identity3325 : scanCanonicalize (H12AffineFastState.compose env3325 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3325 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3326 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,1693,8192,1693,8201,8323,1693,643,1024,8201,1692,32,16,35,8329,16,523,1692,1693,554,1192,169,173,0,1589,512]

theorem envBound3326 : H12AffineFastState.Bounded env3326 := by
  intro p hp
  have h : env3326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3325_3326 : H12AffineEnvironment.transform 11 1693 env3325 = env3326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3325 == env3326) = true)

theorem identity3326 : scanCanonicalize (H12AffineFastState.compose env3326 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 170) := by decide +kernel

theorem selectedBound3326 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3327 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,1693,170,1693,163,41,1693,643,1024,163,1692,32,16,35,35,16,523,1692,1693,554,1192,169,173,0,1589,512]

theorem envBound3327 : H12AffineFastState.Bounded env3327 := by
  intro p hp
  have h : env3327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3326_3327 : H12AffineEnvironment.transform 12 170 env3326 = env3327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 170 env3326 == env3327) = true)

theorem identity3327 : scanCanonicalize (H12AffineFastState.compose env3327 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound3327 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env3328 : List Nat := [2,4,8,16,32,17,3,46,512,1024,523,1566,41,1566,32,41,1566,512,1024,32,1567,32,16,35,35,16,523,1567,1566,554,1067,42,46,0,1589,512]

theorem envBound3328 : H12AffineFastState.Bounded env3328 := by
  intro p hp
  have h : env3328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3327_3328 : H12AffineEnvironment.transform 6 3 env3327 = env3328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env3327 == env3328) = true)

theorem identity3328 : scanCanonicalize (H12AffineFastState.compose env3328 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3328 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env3329 : List Nat := [2,4,8,16,1,17,3,15,512,1024,523,1566,8,1566,1,8,1566,512,1024,1,1567,1,16,2,2,16,523,1567,1566,523,1034,11,15,0,1556,512]

theorem envBound3329 : H12AffineFastState.Bounded env3329 := by
  intro p hp
  have h : env3329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3328_3329 : H12AffineEnvironment.transform 4 1 env3328 = env3329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3328 == env3329) = true)

theorem identity3329 : scanCanonicalize (H12AffineFastState.compose env3329 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3330 : List Nat := [2,4,8,16,1,17,3,15,1,1024,10,1055,8,1055,1,8,1055,1,1024,1,1054,1,16,2,2,16,10,1054,1055,10,1034,11,15,0,1045,1]

theorem envBound3330 : H12AffineFastState.Bounded env3330 := by
  intro p hp
  have h : env3330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3329_3330 : H12AffineEnvironment.transform 8 1 env3329 = env3330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3329 == env3330) = true)

theorem identity3330 : scanCanonicalize (H12AffineFastState.compose env3330 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3330 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3331 : List Nat := [2,4,8,1,1,0,3,15,1,1024,10,1038,8,1038,1,8,1038,1,1024,1,1039,1,1,2,2,1,10,1039,1038,10,1034,11,15,0,1028,1]

theorem envBound3331 : H12AffineFastState.Bounded env3331 := by
  intro p hp
  have h : env3331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3330_3331 : H12AffineEnvironment.transform 3 1 env3330 = env3331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3330 == env3331) = true)

theorem identity3331 : scanCanonicalize (H12AffineFastState.compose env3331 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3331 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env3332 : List Nat := [2,4,2,1,1,0,3,5,1,1024,0,1028,2,1028,1,2,1028,1,1024,1,1029,1,1,2,2,1,0,1029,1028,0,1024,1,5,0,1028,1]

theorem envBound3332 : H12AffineFastState.Bounded env3332 := by
  intro p hp
  have h : env3332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3331_3332 : H12AffineEnvironment.transform 2 2 env3331 = env3332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3331 == env3332) = true)

def leafEnv3332 : List Nat := [2,4,2,1,1,0,3,5,1,1024,0,1028,2,1028,1,2,1028,1,1024,1,1029,1,1,2,1024,2,1,1,0,1029,1028,0,1024,1,5,0,4,3,1028,1,1,1028,0]

def active3332 : List Nat := [0,1,9]

def tree3332 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3332 : H12WitnessSearch.Good tree3332 := H12GlobalWitnessIndex.good

theorem leafIdentity3332 : H12AffineFastState.composeSystem env3332 rootObs = leafEnv3332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3332 rootObs == leafEnv3332) = true)

theorem terminalChecked3332 : H12PackedTerminal.terminalCheckFast leafEnv3332 active3332 tree3332 = true := by decide +kernel

def env3333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323793,16385,16892,22641,74794,12644669,257,20560,8479126,8389613]

theorem envBound3333 : H12AffineFastState.Bounded env3333 := by
  intro p hp
  have h : env3333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3284_3333 : H12AffineEnvironment.transform 18 1025 env3284 = env3333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3284 == env3333) = true)

theorem identity3333 : scanCanonicalize (H12AffineFastState.compose env3333 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240596) := by decide +kernel

theorem selectedBound3333 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,4240596,41002,8329,4240516,323793,16385,16892,22641,74794,17897,257,20560,4314434,4241209]

theorem envBound3334 : H12AffineFastState.Bounded env3334 := by
  intro p hp
  have h : env3334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3333_3334 : H12AffineEnvironment.transform 22 4240596 env3333 = env3334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240596 env3333 == env3334) = true)

def env3335 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4240516,41002,8329,4240516,323713,16385,16812,22561,74794,17849,257,20480,4314386,4241209]

theorem envBound3335 : H12AffineFastState.Bounded env3335 := by
  intro p hp
  have h : env3335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3334_3335 : H12AffineEnvironment.transform 5 16 env3334 = env3335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3334 == env3335) = true)

theorem identity3335 : scanCanonicalize (H12AffineFastState.compose env3335 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 46393) := by decide +kernel

theorem selectedBound3335 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3336 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46393,445,41002,8329,445,323713,16385,16812,22561,74794,17849,257,20480,90155,512]

theorem envBound3336 : H12AffineFastState.Bounded env3336 := by
  intro p hp
  have h : env3336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3335_3336 : H12AffineEnvironment.transform 21 46393 env3335 = env3336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46393 env3335 == env3336) = true)

theorem identity3336 : scanCanonicalize (H12AffineFastState.compose env3336 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound3336 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3337 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1025,32768,1213,41349,445,41002,8329,445,320573,16385,16812,19613,74794,17849,257,17596,90155,512]

theorem envBound3337 : H12AffineFastState.Bounded env3337 := by
  intro p hp
  have h : env3337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3336_3337 : H12AffineEnvironment.transform 11 1212 env3336 = env3337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env3336 == env3337) = true)

theorem identity3337 : scanCanonicalize (H12AffineFastState.compose env3337 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound3337 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3338 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33542,1296,262144,1025,32768,1213,41349,445,41002,8329,445,320573,16385,16812,19613,42796,17849,257,17596,58157,512]

theorem envBound3338 : H12AffineFastState.Bounded env3338 := by
  intro p hp
  have h : env3338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3337_3338 : H12AffineEnvironment.transform 15 33542 env3337 = env3338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env3337 == env3338) = true)

theorem identity3338 : scanCanonicalize (H12AffineFastState.compose env3338 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound3338 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3339 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25663,1296,262144,1025,26425,1213,18108,445,18195,8329,445,262916,16385,16812,19613,16405,17849,257,17596,1044,512]

theorem envBound3339 : H12AffineFastState.Bounded env3339 := by
  intro p hp
  have h : env3339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3338_3339 : H12AffineEnvironment.transform 14 26425 env3338 = env3339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env3338 == env3339) = true)

theorem identity3339 : scanCanonicalize (H12AffineFastState.compose env3339 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3339 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env3340 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,1692,8613,8867,1296,262144,1025,8613,1213,32,445,399,8329,445,262916,1693,1840,2561,1673,805,257,544,1044,512]

theorem envBound3340 : H12AffineFastState.Bounded env3340 := by
  intro p hp
  have h : env3340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3339_3340 : H12AffineEnvironment.transform 13 1692 env3339 = env3340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env3339 == env3340) = true)

theorem identity3340 : scanCanonicalize (H12AffineFastState.compose env3340 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3340 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3341 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1045,8192,1589,8460,8714,1296,262144,1025,8460,1044,32,276,294,8224,276,262916,1588,1840,2561,1568,805,257,544,1044,512]

theorem envBound3341 : H12AffineFastState.Bounded env3341 := by
  intro p hp
  have h : env3341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3340_3341 : H12AffineEnvironment.transform 6 41 env3340 = env3341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3340 == env3341) = true)

theorem identity3341 : scanCanonicalize (H12AffineFastState.compose env3341 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 9245) := by decide +kernel

theorem selectedBound3341 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3342 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1045,8192,1589,8460,8714,1296,9245,1025,8460,1044,32,276,294,8224,276,10009,1588,1840,2561,1568,805,257,544,1044,512]

theorem envBound3342 : H12AffineFastState.Bounded env3342 := by
  intro p hp
  have h : env3342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3341_3342 : H12AffineEnvironment.transform 17 9245 env3341 = env3342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9245 env3341 == env3342) = true)

theorem identity3342 : scanCanonicalize (H12AffineFastState.compose env3342 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3342 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3343 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,1589,8200,8714,1044,9245,1025,8200,1044,32,16,34,8224,16,9757,1588,1588,2561,1568,545,5,544,1044,512]

theorem envBound3343 : H12AffineFastState.Bounded env3343 := by
  intro p hp
  have h : env3343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3342_3343 : H12AffineEnvironment.transform 7 4 env3342 = env3343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3342 == env3343) = true)

theorem identity3343 : scanCanonicalize (H12AffineFastState.compose env3343 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3343 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3344 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1582,1045,8192,1589,8200,8714,1044,9245,1025,8200,1044,32,16,34,8224,16,9757,1588,1588,1071,1568,545,5,544,1044,512]

theorem envBound3344 : H12AffineFastState.Bounded env3344 := by
  intro p hp
  have h : env3344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3343_3344 : H12AffineEnvironment.transform 10 1582 env3343 = env3344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env3343 == env3344) = true)

theorem identity3344 : scanCanonicalize (H12AffineFastState.compose env3344 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 563) := by decide +kernel

theorem selectedBound3344 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3345 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1582,1045,563,1589,571,57,1044,1582,1025,571,1044,32,16,34,531,16,1070,1588,1588,1071,1568,545,5,544,1044,512]

theorem envBound3345 : H12AffineFastState.Bounded env3345 := by
  intro p hp
  have h : env3345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3344_3345 : H12AffineEnvironment.transform 12 563 env3344 = env3345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 563 env3344 == env3345) = true)

theorem identity3345 : scanCanonicalize (H12AffineFastState.compose env3345 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound3345 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3346 : List Nat := [2,4,8,16,32,16,41,4,512,565,27,544,563,0,571,57,545,27,564,571,545,32,16,34,531,16,539,1,1,538,21,545,5,544,545,512]

theorem envBound3346 : H12AffineFastState.Bounded env3346 := by
  intro p hp
  have h : env3346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3345_3346 : H12AffineEnvironment.transform 9 565 env3345 = env3346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env3345 == env3346) = true)

theorem identity3346 : scanCanonicalize (H12AffineFastState.compose env3346 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3346 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3347 : List Nat := [2,4,8,10,32,10,41,4,512,559,1,544,553,0,545,35,545,1,558,545,545,32,10,34,521,10,513,1,1,512,15,545,5,544,545,512]

theorem envBound3347 : H12AffineFastState.Bounded env3347 := by
  intro p hp
  have h : env3347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3346_3347 : H12AffineEnvironment.transform 3 10 env3346 = env3347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3346 == env3347) = true)

theorem identity3347 : scanCanonicalize (H12AffineFastState.compose env3347 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3347 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3348 : List Nat := [2,4,8,10,32,10,41,4,1,46,1,33,40,0,32,35,32,1,47,32,32,32,10,34,8,10,0,1,1,1,15,32,5,33,32,1]

theorem envBound3348 : H12AffineFastState.Bounded env3348 := by
  intro p hp
  have h : env3348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3347_3348 : H12AffineEnvironment.transform 8 1 env3347 = env3348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3347 == env3348) = true)

def env3349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16813,22560,74794,17848,257,20481,4314387,4241209]

theorem envBound3349 : H12AffineFastState.Bounded env3349 := by
  intro p hp
  have h : env3349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3334_3349 : H12AffineEnvironment.transform 5 17 env3334 = env3349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3334 == env3349) = true)

def env3350 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16401,22560,74794,17412,189,20481,4314287,4241029]

theorem envBound3350 : H12AffineFastState.Bounded env3350 := by
  intro p hp
  have h : env3350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3349_3350 : H12AffineEnvironment.transform 7 188 env3349 = env3350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3349 == env3350) = true)

theorem identity3350 : scanCanonicalize (H12AffineFastState.compose env3350 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13493) := by decide +kernel

theorem selectedBound3350 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3351 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,13493,65536,4113,262144,1025,13493,4097,4194304,4194352,5279,8329,4194353,279605,16385,16401,22560,74794,17412,189,20481,4284442,4194864]

theorem envBound3351 : H12AffineFastState.Bounded env3351 := by
  intro p hp
  have h : env3351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3350_3351 : H12AffineEnvironment.transform 14 13493 env3350 = env3351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13493 env3350 == env3351) = true)

def env3352 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,65536,4097,262144,1025,13477,4097,4194304,4194336,5263,8329,4194337,279589,16385,16385,22560,74794,17412,173,20481,4284426,4194848]

theorem envBound3352 : H12AffineFastState.Bounded env3352 := by
  intro p hp
  have h : env3352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3351_3352 : H12AffineEnvironment.transform 3 0 env3351 = env3352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3351 == env3352) = true)

theorem identity3352 : scanCanonicalize (H12AffineFastState.compose env3352 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3352 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3353 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13325,65536,4097,262144,1025,13325,4097,4194304,4194336,5159,8225,4194337,279589,16385,16385,22560,74794,17412,5,20481,4284426,4194848]

theorem envBound3353 : H12AffineFastState.Bounded env3353 := by
  intro p hp
  have h : env3353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3352_3353 : H12AffineEnvironment.transform 6 40 env3352 = env3353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3352 == env3353) = true)

theorem identity3353 : scanCanonicalize (H12AffineFastState.compose env3353 (packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound3353 : packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env3354 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13325,25647,4097,262144,1025,13325,4097,4194304,4194336,5159,8225,4194337,279589,16385,16385,22560,16389,17412,5,20481,4195365,4194848]

theorem envBound3354 : H12AffineFastState.Bounded env3354 := by
  intro p hp
  have h : env3354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3353_3354 : H12AffineEnvironment.transform 15 25647 env3353 = env3354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env3353 == env3354) = true)

theorem identity3354 : scanCanonicalize (H12AffineFastState.compose env3354 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 22528) := by decide +kernel

theorem selectedBound3354 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env3355 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13325,25647,4097,22528,1025,13325,4097,4194304,4194336,5159,8225,4194337,7205,16385,16385,22560,16389,17412,5,20481,4195365,4194848]

theorem envBound3355 : H12AffineFastState.Bounded env3355 := by
  intro p hp
  have h : env3355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3354_3355 : H12AffineEnvironment.transform 17 22528 env3354 = env3355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22528 env3354 == env3355) = true)

theorem identity3355 : scanCanonicalize (H12AffineFastState.compose env3355 (packedSelected [0,1,3,4,6,7,9,12,13,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 3631) := by decide +kernel

theorem selectedBound3355 : packedSelected [0,1,3,4,6,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env3356 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,4096,8192,16384,13325,25647,4097,22528,1025,13325,4097,3631,3599,5159,8225,3598,7205,16385,16385,22560,16389,17412,5,20481,2570,3087]

theorem envBound3356 : H12AffineFastState.Bounded env3356 := by
  intro p hp
  have h : env3356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3355_3356 : H12AffineEnvironment.transform 21 3631 env3355 = env3356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3631 env3355 == env3356) = true)

theorem identity3356 : scanCanonicalize (H12AffineFastState.compose env3356 (packedSelected [1,3,4,5,8,9,12,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 2571) := by decide +kernel

theorem selectedBound3356 : packedSelected [1,3,4,5,8,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env3357 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,2571,8192,16384,11782,25647,2570,16907,1025,11782,2570,3631,3599,3628,8225,3598,1582,16385,16385,16939,16389,17412,5,18954,2570,3087]

theorem envBound3357 : H12AffineFastState.Bounded env3357 := by
  intro p hp
  have h : env3357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3356_3357 : H12AffineEnvironment.transform 11 2571 env3356 = env3357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2571 env3356 == env3357) = true)

theorem identity3357 : scanCanonicalize (H12AffineFastState.compose env3357 (packedSelected [5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3357 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3358 : List Nat := [2,4,8,0,32,1,40,4,0,1024,2048,2059,8192,16384,11270,25647,2058,16395,1025,11270,2058,3119,3087,3116,8225,3086,1070,16385,16385,16427,16389,17412,5,18442,2058,3087]

theorem envBound3358 : H12AffineFastState.Bounded env3358 := by
  intro p hp
  have h : env3358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3357_3358 : H12AffineEnvironment.transform 8 0 env3357 = env3358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3357 == env3358) = true)

theorem identity3358 : scanCanonicalize (H12AffineFastState.compose env3358 (packedSelected [0,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10274) := by decide +kernel

theorem selectedBound3358 : packedSelected [0,7,9,11] rootPS < 2^1333 := by decide +kernel

def env3359 : List Nat := [2,4,8,0,32,1,40,4,0,1024,2048,2059,8192,10274,11270,3085,2058,10281,1025,11270,2058,3119,3087,3116,8225,3086,1070,10275,10275,10249,10279,11302,5,8232,2058,3087]

theorem envBound3359 : H12AffineFastState.Bounded env3359 := by
  intro p hp
  have h : env3359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3358_3359 : H12AffineEnvironment.transform 13 10274 env3358 = env3359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10274 env3358 == env3359) = true)

theorem identity3359 : scanCanonicalize (H12AffineFastState.compose env3359 (packedSelected [1,2,3,6,13] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound3359 : packedSelected [1,2,3,6,13] rootPS < 2^1333 := by decide +kernel

def env3360 : List Nat := [2,4,8,0,32,1,40,4,0,1024,2048,2059,2088,10,1070,3085,2058,1,1025,1070,2058,3119,3087,3116,2057,3086,1070,11,11,33,15,1038,5,2048,2058,3087]

theorem envBound3360 : H12AffineFastState.Bounded env3360 := by
  intro p hp
  have h : env3360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3359_3360 : H12AffineEnvironment.transform 12 2088 env3359 = env3360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env3359 == env3360) = true)

theorem identity3360 : scanCanonicalize (H12AffineFastState.compose env3360 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound3360 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env3361 : List Nat := [2,4,8,0,32,1,40,4,0,1024,1060,1071,1036,10,1070,41,1070,1,1025,1070,1070,11,43,8,1069,42,1070,11,11,33,15,1038,5,1060,1070,43]

theorem envBound3361 : H12AffineFastState.Bounded env3361 := by
  intro p hp
  have h : env3361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3360_3361 : H12AffineEnvironment.transform 10 1060 env3360 = env3361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env3360 == env3361) = true)

theorem identity3361 : scanCanonicalize (H12AffineFastState.compose env3361 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3361 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env3362 : List Nat := [2,4,8,0,10,1,2,4,0,1024,1038,1029,1036,10,1028,3,1028,1,1025,1028,1028,11,1,8,1031,0,1028,11,11,11,15,1038,5,1038,1028,1]

theorem envBound3362 : H12AffineFastState.Bounded env3362 := by
  intro p hp
  have h : env3362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3361_3362 : H12AffineEnvironment.transform 4 10 env3361 = env3362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3361 == env3362) = true)

theorem identity3362 : scanCanonicalize (H12AffineFastState.compose env3362 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound3362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3363 : List Nat := [2,4,8,0,10,1,2,4,0,11,5,14,7,10,15,3,15,1,10,15,15,11,1,8,12,0,15,11,11,11,15,5,5,5,15,1]

theorem envBound3363 : H12AffineFastState.Bounded env3363 := by
  intro p hp
  have h : env3363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3362_3363 : H12AffineEnvironment.transform 9 11 env3362 = env3363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env3362 == env3363) = true)

theorem identity3363 : scanCanonicalize (H12AffineFastState.compose env3363 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3363 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3364 : List Nat := [2,4,7,0,5,1,2,4,0,4,5,1,7,5,0,3,0,1,5,0,0,4,1,7,3,0,0,4,4,4,0,5,5,5,0,1]

theorem envBound3364 : H12AffineFastState.Bounded env3364 := by
  intro p hp
  have h : env3364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3363_3364 : H12AffineEnvironment.transform 2 7 env3363 = env3364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3363 == env3364) = true)

def env3365 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13476,65536,4096,262144,1025,13476,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,74794,17412,172,20481,4284427,4194849]

theorem envBound3365 : H12AffineFastState.Bounded env3365 := by
  intro p hp
  have h : env3365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3351_3365 : H12AffineEnvironment.transform 3 1 env3351 = env3365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3351 == env3365) = true)

theorem identity3365 : scanCanonicalize (H12AffineFastState.compose env3365 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound3365 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3366 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13476,28802,4096,262144,1025,13476,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,21672,17412,172,20481,4198537,4194849]

theorem envBound3366 : H12AffineFastState.Bounded env3366 := by
  intro p hp
  have h : env3366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3365_3366 : H12AffineEnvironment.transform 15 28802 env3365 = env3366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env3365 == env3366) = true)

theorem identity3366 : scanCanonicalize (H12AffineFastState.compose env3366 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 5261) := by decide +kernel

theorem selectedBound3366 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3367 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13476,28802,4096,262144,1025,13476,4097,5261,5292,5262,8329,5293,279588,16385,16384,22560,21672,17412,172,20481,1028,5804]

theorem envBound3367 : H12AffineFastState.Bounded env3367 := by
  intro p hp
  have h : env3367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3366_3367 : H12AffineEnvironment.transform 21 5261 env3366 = env3367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5261 env3366 == env3367) = true)

theorem identity3367 : scanCanonicalize (H12AffineFastState.compose env3367 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound3367 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3368 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1677,8192,16384,8745,26127,1677,262144,1025,8745,1676,512,545,515,8329,544,279588,16385,16384,20141,16933,17412,172,18060,1028,33]

theorem envBound3368 : H12AffineFastState.Bounded env3368 := by
  intro p hp
  have h : env3368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3367_3368 : H12AffineEnvironment.transform 11 1677 env3367 = env3368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env3367 == env3368) = true)

theorem identity3368 : scanCanonicalize (H12AffineFastState.compose env3368 (packedSelected [0,1,3,7,12,15,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound3368 : packedSelected [0,1,3,7,12,15,20] rootPS < 2^1333 := by decide +kernel

def env3369 : List Nat := [2,4,8,1,32,0,128,173,32,1024,2048,1197,8192,16384,8201,25647,1197,262144,1025,8201,1196,32,1,35,8329,0,279588,16385,16384,19597,16389,17412,172,17580,1028,33]

theorem envBound3369 : H12AffineFastState.Bounded env3369 := by
  intro p hp
  have h : env3369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3368_3369 : H12AffineEnvironment.transform 8 32 env3368 = env3369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3368 == env3369) = true)

theorem identity3369 : scanCanonicalize (H12AffineFastState.compose env3369 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16394) := by decide +kernel

theorem selectedBound3369 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3370 : List Nat := [2,4,8,1,32,0,128,173,32,1024,2048,1197,8192,16384,8201,25647,1197,16394,1025,8201,1196,32,1,35,8329,0,1070,16385,16384,19597,16389,17412,172,17580,1028,33]

theorem envBound3370 : H12AffineFastState.Bounded env3370 := by
  intro p hp
  have h : env3370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3369_3370 : H12AffineEnvironment.transform 17 16394 env3369 = env3370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16394 env3369 == env3370) = true)

theorem identity3370 : scanCanonicalize (H12AffineFastState.compose env3370 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3370 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env3371 : List Nat := [2,4,8,1,32,0,40,5,32,1024,2048,1029,8192,16384,8201,25647,1029,16394,1025,8201,1028,32,1,35,8225,0,1070,16385,16384,19493,16389,17412,4,17412,1028,33]

theorem envBound3371 : H12AffineFastState.Bounded env3371 := by
  intro p hp
  have h : env3371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3370_3371 : H12AffineEnvironment.transform 6 40 env3370 = env3371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3370 == env3371) = true)

theorem identity3371 : scanCanonicalize (H12AffineFastState.compose env3371 (packedSelected [5] rootPS)) = affineNative (2^(13+1) ^^^ 10285) := by decide +kernel

theorem selectedBound3371 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3372 : List Nat := [2,4,8,1,32,0,40,5,32,1024,2048,1029,8192,10285,8201,3074,1029,10279,1025,8201,1028,32,1,35,8225,0,1070,10284,10285,9224,10280,11305,4,11305,1028,33]

theorem envBound3372 : H12AffineFastState.Bounded env3372 := by
  intro p hp
  have h : env3372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3371_3372 : H12AffineEnvironment.transform 13 10285 env3371 = env3372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10285 env3371 == env3372) = true)

theorem identity3372 : scanCanonicalize (H12AffineFastState.compose env3372 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3372 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3373 : List Nat := [2,4,8,1,32,0,40,5,32,1024,1039,1029,8192,9250,8201,13,1029,9256,1025,8201,1028,32,1,35,8225,0,1070,9251,9250,9224,9255,8230,4,8230,1028,33]

theorem envBound3373 : H12AffineFastState.Bounded env3373 := by
  intro p hp
  have h : env3373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3372_3373 : H12AffineEnvironment.transform 10 1039 env3372 = env3373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env3372 == env3373) = true)

theorem identity3373 : scanCanonicalize (H12AffineFastState.compose env3373 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound3373 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3374 : List Nat := [2,4,8,1,32,0,40,5,32,1024,1039,1029,1063,5,1070,13,1029,15,1025,1070,1028,32,1,35,1030,0,1070,4,5,47,0,1025,4,1025,1028,33]

theorem envBound3374 : H12AffineFastState.Bounded env3374 := by
  intro p hp
  have h : env3374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3373_3374 : H12AffineEnvironment.transform 12 1063 env3373 = env3374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env3373 == env3374) = true)

theorem identity3374 : scanCanonicalize (H12AffineFastState.compose env3374 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound3374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3375 : List Nat := [2,4,8,1,32,0,40,5,32,47,32,42,8,5,1,13,42,15,46,1,43,32,1,35,41,0,1,4,5,47,0,46,4,46,43,33]

theorem envBound3375 : H12AffineFastState.Bounded env3375 := by
  intro p hp
  have h : env3375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3374_3375 : H12AffineEnvironment.transform 9 47 env3374 = env3375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env3374 == env3375) = true)

theorem identity3375 : scanCanonicalize (H12AffineFastState.compose env3375 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound3375 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3376 : List Nat := [2,4,8,1,4,0,12,5,4,11,4,14,8,5,1,13,14,15,10,1,15,4,1,7,13,0,1,4,5,11,0,10,4,10,15,5]

theorem envBound3376 : H12AffineFastState.Bounded env3376 := by
  intro p hp
  have h : env3376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3375_3376 : H12AffineEnvironment.transform 4 4 env3375 = env3376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env3375 == env3376) = true)

theorem identity3376 : scanCanonicalize (H12AffineFastState.compose env3376 (packedSelected [2,12] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3376 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env3377 : List Nat := [2,4,7,1,4,0,3,5,4,4,4,1,7,5,1,2,1,0,5,1,0,4,1,7,2,0,1,4,5,4,0,5,4,5,0,5]

theorem envBound3377 : H12AffineFastState.Bounded env3377 := by
  intro p hp
  have h : env3377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3376_3377 : H12AffineEnvironment.transform 2 7 env3376 = env3377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3376 == env3377) = true)

def leafEnv3377 : List Nat := [2,4,7,1,4,0,3,5,4,4,4,1,7,5,1,2,1,0,5,1,0,4,1,7,0,2,1,0,1,4,5,4,0,5,4,5,4,6,0,5,1,4,0]

def active3377 : List Nat := [0,1]

def tree3377 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3377 : H12WitnessSearch.Good tree3377 := H12GlobalWitnessIndex.good

theorem leafIdentity3377 : H12AffineFastState.composeSystem env3377 rootObs = leafEnv3377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3377 rootObs == leafEnv3377) = true)

theorem terminalChecked3377 : H12PackedTerminal.terminalCheckFast leafEnv3377 active3377 tree3377 = true := by decide +kernel

def env3378 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16400,22560,74794,17413,188,20481,4314286,4241028]

theorem envBound3378 : H12AffineFastState.Bounded env3378 := by
  intro p hp
  have h : env3378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3349_3378 : H12AffineEnvironment.transform 7 189 env3349 = env3378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3349 == env3378) = true)

theorem identity3378 : scanCanonicalize (H12AffineFastState.compose env3378 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound3378 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3379 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53403,4112,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16400,22560,62641,17413,188,20481,4195381,4241028]

theorem envBound3379 : H12AffineFastState.Bounded env3379 := by
  intro p hp
  have h : env3379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3378_3379 : H12AffineEnvironment.transform 15 53403 env3378 = env3379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env3378 == env3379) = true)

def env3380 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16384,22560,62625,17413,172,20481,4195365,4241028]

theorem envBound3380 : H12AffineFastState.Bounded env3380 := by
  intro p hp
  have h : env3380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3379_3380 : H12AffineEnvironment.transform 3 0 env3379 = env3380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3379 == env3380) = true)

theorem identity3380 : scanCanonicalize (H12AffineFastState.compose env3380 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3380 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3381 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1028,8192,16384,32768,50319,1028,262144,1025,32768,1029,4194304,4235393,41002,8329,4235392,320644,16385,16384,19492,57509,17413,172,17413,4195365,4235904]

theorem envBound3381 : H12AffineFastState.Bounded env3381 := by
  intro p hp
  have h : env3381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3380_3381 : H12AffineEnvironment.transform 11 1028 env3380 = env3381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env3380 == env3381) = true)

theorem identity3381 : scanCanonicalize (H12AffineFastState.compose env3381 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3381 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3382 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,32768,50215,1028,262144,1025,32768,1029,4194304,4235305,41002,8225,4235304,320556,16385,16384,19492,57357,17413,4,17413,4195365,4235816]

theorem envBound3382 : H12AffineFastState.Bounded env3382 := by
  intro p hp
  have h : env3382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3381_3382 : H12AffineEnvironment.transform 6 40 env3381 = env3382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3381 == env3382) = true)

theorem identity3382 : scanCanonicalize (H12AffineFastState.compose env3382 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound3382 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3383 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,32768,50215,1028,43048,1025,32768,1029,4194304,4235305,41002,8225,4235304,19460,16385,16384,19492,57357,17413,4,17413,4195365,4235816]

theorem envBound3383 : H12AffineFastState.Bounded env3383 := by
  intro p hp
  have h : env3383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3382_3383 : H12AffineEnvironment.transform 17 43048 env3382 = env3383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env3382 == env3383) = true)

theorem identity3383 : scanCanonicalize (H12AffineFastState.compose env3383 (packedSelected [1,2,3,4,5,6,7,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound3383 : packedSelected [1,2,3,4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3384 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,8233,25614,1028,2049,1025,8233,1029,4194304,4194304,3,8225,4194305,19460,16385,16384,19492,16420,17413,4,17413,4195365,4194817]

theorem envBound3384 : H12AffineFastState.Bounded env3384 := by
  intro p hp
  have h : env3384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3383_3384 : H12AffineEnvironment.transform 14 8233 env3383 = env3384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env3383 == env3384) = true)

theorem identity3384 : scanCanonicalize (H12AffineFastState.compose env3384 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3384 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3385 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,8192,16384,8201,25614,1028,2049,1025,8201,1029,4194304,4194304,3,8193,4194305,19460,16385,16384,19460,16388,17413,4,17413,4195333,4194817]

theorem envBound3385 : H12AffineFastState.Bounded env3385 := by
  intro p hp
  have h : env3385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3384_3385 : H12AffineEnvironment.transform 4 0 env3384 = env3385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3384 == env3385) = true)

theorem identity3385 : scanCanonicalize (H12AffineFastState.compose env3385 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound3385 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3386 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,8192,1029,8201,8203,1028,2049,1025,8201,1029,4194304,4194304,3,8193,4194305,2049,1028,1029,2049,1025,0,4,0,4195333,4194817]

theorem envBound3386 : H12AffineFastState.Bounded env3386 := by
  intro p hp
  have h : env3386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3385_3386 : H12AffineEnvironment.transform 13 1029 env3385 = env3386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env3385 == env3386) = true)

theorem identity3386 : scanCanonicalize (H12AffineFastState.compose env3386 (packedSelected [0] rootPS)) = affineNative (2^(21+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3387 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,8192,1029,8201,8203,1028,2049,1025,8201,1029,1039,1039,3,8193,1038,2049,1028,1029,2049,1025,0,4,0,10,1550]

theorem envBound3387 : H12AffineFastState.Bounded env3387 := by
  intro p hp
  have h : env3387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3386_3387 : H12AffineEnvironment.transform 21 1039 env3386 = env3387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1039 env3386 == env3387) = true)

theorem identity3387 : scanCanonicalize (H12AffineFastState.compose env3387 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound3387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3388 : List Nat := [2,4,8,0,0,1,8,5,512,1024,2048,1028,2056,1029,2049,2051,1028,2049,1025,2049,1029,1039,1039,3,2057,1038,2049,1028,1029,2049,1025,0,4,0,10,1550]

theorem envBound3388 : H12AffineFastState.Bounded env3388 := by
  intro p hp
  have h : env3388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3387_3388 : H12AffineEnvironment.transform 12 2056 env3387 = env3388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env3387 == env3388) = true)

theorem identity3388 : scanCanonicalize (H12AffineFastState.compose env3388 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3388 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3389 : List Nat := [2,4,8,0,0,1,8,5,512,1024,1028,1028,1036,1029,1029,1031,1028,1029,1025,1029,1029,1039,1039,3,1037,1038,1029,1028,1029,1029,1025,0,4,0,10,1550]

theorem envBound3389 : H12AffineFastState.Bounded env3389 := by
  intro p hp
  have h : env3389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3388_3389 : H12AffineEnvironment.transform 10 1028 env3388 = env3389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env3388 == env3389) = true)

theorem identity3389 : scanCanonicalize (H12AffineFastState.compose env3389 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3389 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env3390 : List Nat := [2,4,8,0,0,1,8,5,512,4,0,0,8,1,1,3,0,1,5,1,1,11,11,3,9,10,1,0,1,1,5,0,4,0,10,522]

theorem envBound3390 : H12AffineFastState.Bounded env3390 := by
  intro p hp
  have h : env3390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3389_3390 : H12AffineEnvironment.transform 9 4 env3389 = env3390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3389 == env3390) = true)

theorem identity3390 : scanCanonicalize (H12AffineFastState.compose env3390 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound3390 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3391 : List Nat := [2,4,8,0,0,1,8,5,11,4,0,0,8,1,1,3,0,1,5,1,1,11,11,3,9,10,1,0,1,1,5,0,4,0,10,1]

theorem envBound3391 : H12AffineFastState.Bounded env3391 := by
  intro p hp
  have h : env3391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3390_3391 : H12AffineEnvironment.transform 8 11 env3390 = env3391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env3390 == env3391) = true)

def env3392 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16385,22560,62624,17413,173,20481,4195364,4241028]

theorem envBound3392 : H12AffineFastState.Bounded env3392 := by
  intro p hp
  have h : env3392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3379_3392 : H12AffineEnvironment.transform 3 1 env3379 = env3392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3379 == env3392) = true)

def env3393 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,41088,5125,41002,8329,5124,323712,16385,16385,22560,62624,17413,173,20481,42148,5636]

theorem envBound3393 : H12AffineFastState.Bounded env3393 := by
  intro p hp
  have h : env3393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3392_3393 : H12AffineEnvironment.transform 21 41088 env3392 = env3393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3392 == env3393) = true)

theorem identity3393 : scanCanonicalize (H12AffineFastState.compose env3393 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 43680) := by decide +kernel

theorem selectedBound3393 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3394 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,43680,1025,32768,4097,41088,5125,41002,8329,5124,23072,16385,16385,22560,62624,17413,173,20481,42148,5636]

theorem envBound3394 : H12AffineFastState.Bounded env3394 := by
  intro p hp
  have h : env3394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3393_3394 : H12AffineEnvironment.transform 17 43680 env3393 = env3394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43680 env3393 == env3394) = true)

theorem identity3394 : scanCanonicalize (H12AffineFastState.compose env3394 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3394 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env3395 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,4096,8192,16384,32768,53283,4097,43529,1025,32768,4097,41001,5125,41002,8224,5124,23072,16385,16385,22560,62473,17413,4,20481,41997,5636]

theorem envBound3395 : H12AffineFastState.Bounded env3395 := by
  intro p hp
  have h : env3395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3394_3395 : H12AffineEnvironment.transform 6 41 env3394 = env3395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3394 == env3395) = true)

theorem identity3395 : scanCanonicalize (H12AffineFastState.compose env3395 (packedSelected [2,3,5,8,11,12,13,15,17,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3395 : packedSelected [2,3,5,8,11,12,13,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env3396 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,32768,50215,1029,43529,1025,32768,1029,41001,1,41002,8224,0,20004,16385,16385,19492,57357,17413,4,17413,41997,512]

theorem envBound3396 : H12AffineFastState.Bounded env3396 := by
  intro p hp
  have h : env3396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3395_3396 : H12AffineEnvironment.transform 11 1028 env3395 = env3396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env3395 == env3396) = true)

theorem identity3396 : scanCanonicalize (H12AffineFastState.compose env3396 (packedSelected [0,2,3,4,6,7,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 1061) := by decide +kernel

theorem selectedBound3396 : packedSelected [0,2,3,4,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3397 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,1061,16386,1029,11820,1025,1061,1029,9228,1,9231,8224,0,20004,16385,16385,19492,25640,17413,4,17413,8232,512]

theorem envBound3397 : H12AffineFastState.Bounded env3397 := by
  intro p hp
  have h : env3397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3396_3397 : H12AffineEnvironment.transform 14 1061 env3396 = env3397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1061 env3396 == env3397) = true)

theorem identity3397 : scanCanonicalize (H12AffineFastState.compose env3397 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 2091) := by decide +kernel

theorem selectedBound3397 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env3398 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,2091,1061,2089,1029,11820,1025,1061,1029,9228,1,9231,8224,0,1551,2090,2090,1039,11267,3118,4,3118,8232,512]

theorem envBound3398 : H12AffineFastState.Bounded env3398 := by
  intro p hp
  have h : env3398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3397_3398 : H12AffineEnvironment.transform 13 2091 env3397 = env3398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2091 env3397 == env3398) = true)

theorem identity3398 : scanCanonicalize (H12AffineFastState.compose env3398 (packedSelected [0,2,4,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound3398 : packedSelected [0,2,4,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env3399 : List Nat := [2,4,8,1,32,0,41,5,32,1024,2048,1028,8192,2091,1061,2089,1029,11276,1025,1061,1029,9228,1,9231,8224,0,1071,2090,2090,1039,11267,3118,4,3118,8232,32]

theorem envBound3399 : H12AffineFastState.Bounded env3399 := by
  intro p hp
  have h : env3399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3398_3399 : H12AffineEnvironment.transform 8 32 env3398 = env3399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3398 == env3399) = true)

theorem identity3399 : scanCanonicalize (H12AffineFastState.compose env3399 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1068) := by decide +kernel

theorem selectedBound3399 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3400 : List Nat := [2,4,8,1,32,0,41,5,32,1024,2048,1028,1068,2091,1061,2089,1029,2080,1025,1061,1029,32,1,35,1036,0,1071,2090,2090,1039,2095,3118,4,3118,1028,32]

theorem envBound3400 : H12AffineFastState.Bounded env3400 := by
  intro p hp
  have h : env3400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3399_3400 : H12AffineEnvironment.transform 12 1068 env3399 = env3400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1068 env3399 == env3400) = true)

theorem identity3400 : scanCanonicalize (H12AffineFastState.compose env3400 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3400 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env3401 : List Nat := [2,4,8,1,0,0,9,5,0,1024,2048,1028,1036,2059,1029,2057,1029,2048,1025,1029,1029,0,1,3,1036,0,1039,2058,2058,1039,2063,3086,4,3086,1028,0]

theorem envBound3401 : H12AffineFastState.Bounded env3401 := by
  intro p hp
  have h : env3401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3400_3401 : H12AffineEnvironment.transform 4 0 env3400 = env3401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3400 == env3401) = true)

theorem identity3401 : scanCanonicalize (H12AffineFastState.compose env3401 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3401 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3402 : List Nat := [2,4,8,1,0,0,9,5,0,1024,1028,1028,1036,1039,1029,1037,1029,1028,1025,1029,1029,0,1,3,1036,0,1039,1038,1038,1039,1035,10,4,10,1028,0]

theorem envBound3402 : H12AffineFastState.Bounded env3402 := by
  intro p hp
  have h : env3402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3401_3402 : H12AffineEnvironment.transform 10 1028 env3401 = env3402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env3401 == env3402) = true)

theorem identity3402 : scanCanonicalize (H12AffineFastState.compose env3402 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3403 : List Nat := [2,4,2,1,0,0,3,5,0,1024,1028,1028,1030,1029,1029,1031,1029,1028,1025,1029,1029,0,1,3,1030,0,1029,1028,1028,1029,1025,0,4,0,1028,0]

theorem envBound3403 : H12AffineFastState.Bounded env3403 := by
  intro p hp
  have h : env3403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3402_3403 : H12AffineEnvironment.transform 2 2 env3402 = env3403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3402 == env3403) = true)

theorem identity3403 : scanCanonicalize (H12AffineFastState.compose env3403 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3404 : List Nat := [2,4,2,1,0,0,3,5,0,5,1,1,3,0,0,2,0,1,4,0,0,0,1,3,3,0,0,1,1,0,4,0,4,0,1,0]

theorem envBound3404 : H12AffineFastState.Bounded env3404 := by
  intro p hp
  have h : env3404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3403_3404 : H12AffineEnvironment.transform 9 5 env3403 = env3404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3403 == env3404) = true)

def env3405 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,41089,5124,41002,8329,5125,323712,16385,16385,22560,62624,17413,173,20481,42149,5637]

theorem envBound3405 : H12AffineFastState.Bounded env3405 := by
  intro p hp
  have h : env3405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3392_3405 : H12AffineEnvironment.transform 21 41089 env3392 = env3405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3392 == env3405) = true)

theorem identity3405 : scanCanonicalize (H12AffineFastState.compose env3405 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 60940) := by decide +kernel

theorem selectedBound3405 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3406 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,60940,1025,32768,4097,41089,5124,41002,8329,5125,7820,16385,16385,22560,62624,17413,173,20481,42149,5637]

theorem envBound3406 : H12AffineFastState.Bounded env3406 := by
  intro p hp
  have h : env3406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3405_3406 : H12AffineEnvironment.transform 17 60940 env3405 = env3406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60940 env3405 == env3406) = true)

theorem identity3406 : scanCanonicalize (H12AffineFastState.compose env3406 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound3406 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env3407 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50215,1196,60940,1025,32768,1196,41089,169,41002,8329,168,2593,16385,16385,19597,57357,17413,173,17580,42149,680]

theorem envBound3407 : H12AffineFastState.Bounded env3407 := by
  intro p hp
  have h : env3407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3406_3407 : H12AffineEnvironment.transform 11 1197 env3406 = env3407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env3406 == env3407) = true)

theorem identity3407 : scanCanonicalize (H12AffineFastState.compose env3407 (packedSelected [1,5,10,12,13,15,21] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound3407 : packedSelected [1,5,10,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env3408 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,8353,25734,1196,20141,1025,8353,1196,32,169,139,8329,168,2593,16385,16385,19597,16556,17413,173,17580,1028,680]

theorem envBound3408 : H12AffineFastState.Bounded env3408 := by
  intro p hp
  have h : env3408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3407_3408 : H12AffineEnvironment.transform 14 8353 env3407 = env3408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3407 == env3408) = true)

theorem identity3408 : scanCanonicalize (H12AffineFastState.compose env3408 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3408 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3409 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,1573,8353,8867,1196,2184,1025,8353,1196,32,169,139,8329,168,2593,1572,1572,2728,1673,544,173,649,1028,680]

theorem envBound3409 : H12AffineFastState.Bounded env3409 := by
  intro p hp
  have h : env3409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3408_3409 : H12AffineEnvironment.transform 13 1573 env3408 = env3409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env3408 == env3409) = true)

theorem identity3409 : scanCanonicalize (H12AffineFastState.compose env3409 (packedSelected [1,2,3,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1575) := by decide +kernel

theorem selectedBound3409 : packedSelected [1,2,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env3410 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,1575,1573,1670,1156,1196,2184,1025,1670,1196,32,169,139,1710,168,2593,1572,1572,2728,1673,544,173,649,1028,680]

theorem envBound3410 : H12AffineFastState.Bounded env3410 := by
  intro p hp
  have h : env3410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3409_3410 : H12AffineEnvironment.transform 12 1575 env3409 = env3410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1575 env3409 == env3410) = true)

theorem identity3410 : scanCanonicalize (H12AffineFastState.compose env3410 (packedSelected [4,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound3410 : packedSelected [4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3411 : List Nat := [2,4,8,1,32,0,128,172,512,1024,1702,1197,1575,1573,1670,1156,1196,1582,1025,1670,1196,32,169,139,1710,168,1159,1572,1572,1038,1673,544,173,649,1028,680]

theorem envBound3411 : H12AffineFastState.Bounded env3411 := by
  intro p hp
  have h : env3411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3410_3411 : H12AffineEnvironment.transform 10 1702 env3410 = env3411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env3410 == env3411) = true)

theorem identity3411 : scanCanonicalize (H12AffineFastState.compose env3411 (packedSelected [1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound3411 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env3412 : List Nat := [2,4,8,1,32,0,128,172,512,135,545,42,672,674,513,3,43,681,134,513,43,32,169,139,553,168,0,675,675,137,526,544,173,649,131,680]

theorem envBound3412 : H12AffineFastState.Bounded env3412 := by
  intro p hp
  have h : env3412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3411_3412 : H12AffineEnvironment.transform 9 135 env3411 = env3412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env3411 == env3412) = true)

theorem identity3412 : scanCanonicalize (H12AffineFastState.compose env3412 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3412 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env3413 : List Nat := [2,4,8,1,32,0,40,4,512,47,545,42,520,522,513,3,43,513,46,513,43,32,1,35,553,0,0,523,523,33,526,544,5,545,43,512]

theorem envBound3413 : H12AffineFastState.Bounded env3413 := by
  intro p hp
  have h : env3413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3412_3413 : H12AffineEnvironment.transform 6 40 env3412 = env3413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3412 == env3413) = true)

theorem identity3413 : scanCanonicalize (H12AffineFastState.compose env3413 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3414 : List Nat := [2,4,8,1,32,0,40,4,0,47,33,42,8,10,1,3,43,1,46,1,43,32,1,35,41,0,0,11,11,33,14,32,5,33,43,0]

theorem envBound3414 : H12AffineFastState.Bounded env3414 := by
  intro p hp
  have h : env3414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3413_3414 : H12AffineEnvironment.transform 8 0 env3413 = env3414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3413 == env3414) = true)

def env3415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,11015248,849105,268435456,268435965,547953,2699306,12644668,525568,545872,8479127,8914924]

theorem envBound3415 : H12AffineFastState.Bounded env3415 := by
  intro p hp
  have h : env3415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2955_3415 : H12AffineEnvironment.transform 26 849105 env2955 = env3415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849105 env2955 == env3415) = true)

def env3416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849105,268435456,268435965,547953,598058,12644668,525568,545872,8479127,8914924]

theorem envBound3416 : H12AffineFastState.Bounded env3416 := by
  intro p hp
  have h : env3416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3415_3416 : H12AffineEnvironment.transform 20 4096 env3415 = env3416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env3415 == env3416) = true)

def env3417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849105,16384,16893,547953,598058,12644668,525568,545872,8479127,8914924]

theorem envBound3417 : H12AffineFastState.Bounded env3417 := by
  intro p hp
  have h : env3417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3416_3417 : H12AffineEnvironment.transform 27 16384 env3416 = env3417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3416 == env3417) = true)

def env3418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323793,16384,16893,22641,74794,12644668,256,20560,8479127,8389612]

theorem envBound3418 : H12AffineFastState.Bounded env3418 := by
  intro p hp
  have h : env3418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3417_3418 : H12AffineEnvironment.transform 18 1024 env3417 = env3418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3417 == env3418) = true)

theorem identity3418 : scanCanonicalize (H12AffineFastState.compose env3418 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5456) := by decide +kernel

theorem selectedBound3418 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,5456,41002,8329,5376,323793,16384,16893,22641,74794,4252780,256,20560,95431,5820]

theorem envBound3419 : H12AffineFastState.Bounded env3419 := by
  intro p hp
  have h : env3419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3418_3419 : H12AffineEnvironment.transform 22 5456 env3418 = env3419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5456 env3418 == env3419) = true)

def env3420 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,5376,41002,8329,5376,323713,16384,16813,22561,74794,4252732,256,20480,95383,5820]

theorem envBound3420 : H12AffineFastState.Bounded env3420 := by
  intro p hp
  have h : env3420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3419_3420 : H12AffineEnvironment.transform 5 16 env3419 = env3420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3419 == env3420) = true)

theorem identity3420 : scanCanonicalize (H12AffineFastState.compose env3420 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound3420 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3421 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,4194304,444,41002,8329,444,320573,16384,16813,19613,74794,4252732,256,17596,90155,512]

theorem envBound3421 : H12AffineFastState.Bounded env3421 := by
  intro p hp
  have h : env3421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3420_3421 : H12AffineEnvironment.transform 11 1212 env3420 = env3421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env3420 == env3421) = true)

theorem identity3421 : scanCanonicalize (H12AffineFastState.compose env3421 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3421 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3422 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,41348,444,41002,8329,444,320573,16384,16813,19613,74794,17848,256,17596,90155,512]

theorem envBound3422 : H12AffineFastState.Bounded env3422 := by
  intro p hp
  have h : env3422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3421_3422 : H12AffineEnvironment.transform 21 41348 env3421 = env3422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3421 == env3422) = true)

theorem identity3422 : scanCanonicalize (H12AffineFastState.compose env3422 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound3422 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3423 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33543,1296,262144,1024,32768,1212,41348,444,41002,8329,444,320573,16384,16813,19613,42797,17848,256,17596,58156,512]

theorem envBound3423 : H12AffineFastState.Bounded env3423 := by
  intro p hp
  have h : env3423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3422_3423 : H12AffineEnvironment.transform 15 33543 env3422 = env3423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env3422 == env3423) = true)

theorem identity3423 : scanCanonicalize (H12AffineFastState.compose env3423 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound3423 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3424 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,262144,1024,26425,1212,18109,444,18195,8329,444,262916,16384,16813,19613,16404,17848,256,17596,1045,512]

theorem envBound3424 : H12AffineFastState.Bounded env3424 := by
  intro p hp
  have h : env3424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3423_3424 : H12AffineEnvironment.transform 14 26425 env3423 = env3424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env3423 == env3424) = true)

theorem identity3424 : scanCanonicalize (H12AffineFastState.compose env3424 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound3424 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env3425 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,20156,1024,26425,1212,18109,444,18195,8329,444,19896,16384,16813,19613,16404,17848,256,17596,1045,512]

theorem envBound3425 : H12AffineFastState.Bounded env3425 := by
  intro p hp
  have h : env3425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3424_3425 : H12AffineEnvironment.transform 17 20156 env3424 = env3425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env3424 == env3425) = true)

def env3426 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,5377,41002,8329,5376,323712,16384,16812,22560,74794,4252733,256,20481,95382,5820]

theorem envBound3426 : H12AffineFastState.Bounded env3426 := by
  intro p hp
  have h : env3426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3419_3426 : H12AffineEnvironment.transform 5 17 env3419 = env3426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3419 == env3426) = true)

def env3427 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41260,5377,41002,8329,5376,323712,16384,16812,22560,74794,17681,256,20481,95382,5820]

theorem envBound3427 : H12AffineFastState.Bounded env3427 := by
  intro p hp
  have h : env3427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3426_3427 : H12AffineEnvironment.transform 21 41260 env3426 = env3427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env3426 == env3427) = true)

theorem identity3427 : scanCanonicalize (H12AffineFastState.compose env3427 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound3427 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env3428 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1024,32768,4096,41260,5377,41002,8329,5376,323712,16384,16812,22560,16824,17681,256,20481,4356,5820]

theorem envBound3428 : H12AffineFastState.Bounded env3428 := by
  intro p hp
  have h : env3428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3427_3428 : H12AffineEnvironment.transform 15 26002 env3427 = env3428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env3427 == env3428) = true)

def env3429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,16384,32768,26002,1213,262144,1024,32768,1296,41260,17,41002,8329,16,320912,16384,16812,19760,16824,17681,256,17681,1044,940]

theorem envBound3429 : H12AffineFastState.Bounded env3429 := by
  intro p hp
  have h : env3429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3428_3429 : H12AffineEnvironment.transform 11 1296 env3428 = env3429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env3428 == env3429) = true)

theorem identity3429 : scanCanonicalize (H12AffineFastState.compose env3429 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3429 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3430 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,16384,32768,25750,1213,262144,1024,32768,1044,41000,17,41002,8329,16,320660,16384,16552,19508,16572,17429,4,17429,1044,680]

theorem envBound3430 : H12AffineFastState.Bounded env3430 := by
  intro p hp
  have h : env3430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3429_3430 : H12AffineEnvironment.transform 7 4 env3429 = env3430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3429 == env3430) = true)

theorem identity3430 : scanCanonicalize (H12AffineFastState.compose env3430 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3430 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3431 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1693,32768,8715,1213,262144,1024,32768,1044,41000,17,41002,8329,16,303625,1693,1589,2729,1569,648,4,648,1044,680]

theorem envBound3431 : H12AffineFastState.Bounded env3431 := by
  intro p hp
  have h : env3431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3430_3431 : H12AffineEnvironment.transform 13 1693 env3430 = env3431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env3430 == env3431) = true)

theorem identity3431 : scanCanonicalize (H12AffineFastState.compose env3431 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound3431 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env3432 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1693,8200,8715,1213,262144,1024,8200,1044,32,17,34,8329,16,262657,1693,1589,2729,1569,648,4,648,1044,680]

theorem envBound3432 : H12AffineFastState.Bounded env3432 := by
  intro p hp
  have h : env3432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3431_3432 : H12AffineEnvironment.transform 14 8200 env3431 = env3432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env3431 == env3432) = true)

theorem identity3432 : scanCanonicalize (H12AffineFastState.compose env3432 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2728) := by decide +kernel

theorem selectedBound3432 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3433 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1693,8200,8715,1213,2728,1024,8200,1044,32,17,34,8329,16,2217,1693,1589,2729,1569,648,4,648,1044,680]

theorem envBound3433 : H12AffineFastState.Bounded env3433 := by
  intro p hp
  have h : env3433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3432_3433 : H12AffineEnvironment.transform 17 2728 env3432 = env3433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2728 env3432 == env3433) = true)

theorem identity3433 : scanCanonicalize (H12AffineFastState.compose env3433 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3433 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3434 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,8192,1589,8200,8715,1045,2560,1024,8200,1044,32,17,34,8225,16,2049,1589,1589,2561,1569,544,4,544,1044,512]

theorem envBound3434 : H12AffineFastState.Bounded env3434 := by
  intro p hp
  have h : env3434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3433_3434 : H12AffineEnvironment.transform 6 40 env3433 = env3434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3433 == env3434) = true)

theorem identity3434 : scanCanonicalize (H12AffineFastState.compose env3434 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound3434 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3435 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,1085,1589,1077,1590,1045,2560,1024,1077,1044,32,17,34,1052,16,2049,1589,1589,2561,1569,544,4,544,1044,512]

theorem envBound3435 : H12AffineFastState.Bounded env3435 := by
  intro p hp
  have h : env3435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3434_3435 : H12AffineEnvironment.transform 12 1085 env3434 = env3435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env3434 == env3435) = true)

theorem identity3435 : scanCanonicalize (H12AffineFastState.compose env3435 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3435 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3436 : List Nat := [2,4,8,16,27,17,19,4,512,1024,2048,1044,1030,1550,1038,1549,1045,2560,1024,1038,1044,27,17,25,1052,16,2049,1550,1550,2561,1562,539,4,539,1044,512]

theorem envBound3436 : H12AffineFastState.Bounded env3436 := by
  intro p hp
  have h : env3436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3435_3436 : H12AffineEnvironment.transform 4 27 env3435 = env3436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3435 == env3436) = true)

theorem identity3436 : scanCanonicalize (H12AffineFastState.compose env3436 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound3436 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3437 : List Nat := [2,4,8,16,27,17,19,4,512,1024,1044,1044,1030,1550,1038,1549,1045,1556,1024,1038,1044,27,17,25,1052,16,1045,1550,1550,1557,1562,539,4,539,1044,512]

theorem envBound3437 : H12AffineFastState.Bounded env3437 := by
  intro p hp
  have h : env3437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3436_3437 : H12AffineEnvironment.transform 10 1044 env3436 = env3437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env3436 == env3437) = true)

theorem identity3437 : scanCanonicalize (H12AffineFastState.compose env3437 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3438 : List Nat := [2,4,8,16,27,17,19,4,1,1024,1044,1044,1030,1039,1038,1036,1045,1045,1024,1038,1044,27,17,25,1052,16,1045,1039,1039,1044,1051,26,4,26,1044,1]

theorem envBound3438 : H12AffineFastState.Bounded env3438 := by
  intro p hp
  have h : env3438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3437_3438 : H12AffineEnvironment.transform 8 1 env3437 = env3438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3437 == env3438) = true)

theorem identity3438 : scanCanonicalize (H12AffineFastState.compose env3438 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3438 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3439 : List Nat := [2,4,8,16,27,17,19,4,1,15,27,27,9,0,1,3,26,26,15,1,27,27,17,25,19,16,26,0,0,27,20,26,4,26,27,1]

theorem envBound3439 : H12AffineFastState.Bounded env3439 := by
  intro p hp
  have h : env3439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3438_3439 : H12AffineEnvironment.transform 9 15 env3438 = env3439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3438 == env3439) = true)

def env3440 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,16384,32768,26002,1212,262144,1024,32768,1297,41260,16,41002,8329,17,320913,16384,16812,19761,16824,17681,256,17680,1045,941]

theorem envBound3440 : H12AffineFastState.Bounded env3440 := by
  intro p hp
  have h : env3440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1