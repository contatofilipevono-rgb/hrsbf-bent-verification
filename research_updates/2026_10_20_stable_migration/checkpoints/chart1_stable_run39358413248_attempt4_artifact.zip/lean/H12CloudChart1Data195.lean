import H12CloudChart1Data194

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans49397_49398 : H12AffineEnvironment.transform 11 2065 env49397 = env49398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env49397 == env49398) = true)

theorem identity49398 : scanCanonicalize (H12AffineFastState.compose env49398 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49399 : List Nat := [2,4,8,16,32,17,8,36,43,53,2048,2065,41,2049,1,34,2064,2049,53,0,2049,32,16,2,41,17,2049,2064,2065,2048,20,32,36,32,2048,42]

theorem envBound49399 : H12AffineFastState.Bounded env49399 := by
  intro p hp
  have h : env49399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49398_49399 : H12AffineEnvironment.transform 8 43 env49398 = env49399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49398 == env49399) = true)

def env49400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,4161,21793,95514,73857,8328,64,215366,5392,77835,212199,94422,32,256,73771,90323,22272]

theorem envBound49400 : H12AffineFastState.Bounded env49400 := by
  intro p hp
  have h : env49400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49388_49400 : H12AffineEnvironment.transform 17 10401 env49388 = env49400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49388 == env49400) = true)

def env49401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,4161,33,73754,73857,8328,64,203846,5392,77835,212199,75222,32,256,73771,79315,512]

theorem envBound49401 : H12AffineFastState.Bounded env49401 := by
  intro p hp
  have h : env49401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49400_49401 : H12AffineEnvironment.transform 13 5376 env49400 = env49401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49400 == env49401) = true)

theorem identity49401 : scanCanonicalize (H12AffineFastState.compose env49401 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 67911) := by decide +kernel

theorem selectedBound49401 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env49402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,67911,10401,1024,8540,4161,33,73754,73857,8328,64,5377,5392,77835,13728,75222,32,256,73771,79315,512]

theorem envBound49402 : H12AffineFastState.Bounded env49402 := by
  intro p hp
  have h : env49402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49401_49402 : H12AffineEnvironment.transform 16 67911 env49401 = env49402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 67911 env49401 == env49402) = true)

theorem identity49402 : scanCanonicalize (H12AffineFastState.compose env49402 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49402 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,10572,10401,1024,8540,4161,33,17,138,8328,64,5377,5392,4096,13728,1501,32,256,32,5592,512]

theorem envBound49403 : H12AffineFastState.Bounded env49403 := by
  intro p hp
  have h : env49403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49402_49403 : H12AffineEnvironment.transform 15 8203 env49402 = env49403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49402 == env49403) = true)

theorem identity49403 : scanCanonicalize (H12AffineFastState.compose env49403 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound49403 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49404 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5376,8541,8203,10572,10248,1024,8540,4161,33,17,35,8225,64,5377,5392,4096,13577,1396,32,256,32,5489,512]

theorem envBound49404 : H12AffineFastState.Bounded env49404 := by
  intro p hp
  have h : env49404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49403_49404 : H12AffineEnvironment.transform 6 41 env49403 = env49404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env49403 == env49404) = true)

def env49405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10401,1024,8540,4161,32,73755,73857,8328,64,203847,5392,77835,212199,75223,32,256,73771,79314,513]

theorem envBound49405 : H12AffineFastState.Bounded env49405 := by
  intro p hp
  have h : env49405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49400_49405 : H12AffineEnvironment.transform 13 5377 env49400 = env49405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49400 == env49405) = true)

theorem identity49405 : scanCanonicalize (H12AffineFastState.compose env49405 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound49405 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env49406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,13508,10401,1024,8540,4161,32,73755,73857,8328,64,75907,5392,77835,67619,75223,32,256,73771,79314,513]

theorem envBound49406 : H12AffineFastState.Bounded env49406 := by
  intro p hp
  have h : env49406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49405_49406 : H12AffineEnvironment.transform 16 13508 env49405 = env49406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env49405 == env49406) = true)

theorem identity49406 : scanCanonicalize (H12AffineFastState.compose env49406 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound49406 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,343,13508,10401,1024,8540,4161,32,8524,8662,8328,64,10708,5392,12636,2420,9344,32,256,8572,13445,513]

theorem envBound49407 : H12AffineFastState.Bounded env49407 := by
  intro p hp
  have h : env49407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49406_49407 : H12AffineEnvironment.transform 15 343 env49406 = env49407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env49406 == env49407) = true)

theorem identity49407 : scanCanonicalize (H12AffineFastState.compose env49407 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49407 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env49408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,81,343,5576,2477,1024,80,4161,32,64,218,388,64,2264,5392,4176,2420,1420,32,256,112,5513,513]

theorem envBound49408 : H12AffineFastState.Bounded env49408 := by
  intro p hp
  have h : env49408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49407_49408 : H12AffineEnvironment.transform 12 268 env49407 = env49408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49407 == env49408) = true)

theorem identity49408 : scanCanonicalize (H12AffineFastState.compose env49408 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49408 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env49409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,343,5441,2340,1024,80,4161,32,64,83,269,64,2129,5392,4176,2420,1285,32,256,112,5376,513]

theorem envBound49409 : H12AffineFastState.Bounded env49409 := by
  intro p hp
  have h : env49409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49408_49409 : H12AffineEnvironment.transform 6 9 env49408 = env49409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49408 == env49409) = true)

theorem identity49409 : scanCanonicalize (H12AffineFastState.compose env49409 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3418) := by decide +kernel

theorem selectedBound49409 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3418,268,2139,81,343,2075,2340,1024,80,3355,32,64,83,269,64,2129,2122,3338,2420,1285,32,256,112,2138,513]

theorem envBound49410 : H12AffineFastState.Bounded env49410 := by
  intro p hp
  have h : env49410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49409_49410 : H12AffineEnvironment.transform 11 3418 env49409 = env49410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3418 env49409 == env49410) = true)

theorem identity49410 : scanCanonicalize (H12AffineFastState.compose env49410 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49410 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49411 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3338,268,2059,1,263,2075,2340,1024,0,3355,32,16,3,269,16,2049,2074,3338,2340,1285,32,256,32,2058,513]

theorem envBound49411 : H12AffineFastState.Bounded env49411 := by
  intro p hp
  have h : env49411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49410_49411 : H12AffineEnvironment.transform 5 16 env49410 = env49411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49410 == env49411) = true)

theorem identity49411 : scanCanonicalize (H12AffineFastState.compose env49411 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 287) := by decide +kernel

theorem selectedBound49411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49412 : List Nat := [2,4,8,16,32,16,9,256,512,1024,287,1045,268,276,1,263,260,59,1024,0,1028,32,16,3,269,16,286,261,1045,59,1285,32,256,32,277,513]

theorem envBound49412 : H12AffineFastState.Bounded env49412 := by
  intro p hp
  have h : env49412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49411_49412 : H12AffineEnvironment.transform 10 287 env49411 = env49412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 287 env49411 == env49412) = true)

theorem identity49412 : scanCanonicalize (H12AffineFastState.compose env49412 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound49412 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49413 : List Nat := [2,4,8,16,32,16,9,256,512,817,287,804,268,276,1,263,260,59,817,0,821,32,16,3,269,16,286,261,804,59,564,32,256,32,277,513]

theorem envBound49413 : H12AffineFastState.Bounded env49413 := by
  intro p hp
  have h : env49413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49412_49413 : H12AffineEnvironment.transform 9 817 env49412 = env49413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env49412 == env49413) = true)

theorem identity49413 : scanCanonicalize (H12AffineFastState.compose env49413 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49413 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49414 : List Nat := [2,4,8,16,17,16,9,256,512,768,287,789,268,276,1,263,260,10,768,0,772,17,16,3,269,16,286,261,789,10,517,17,256,17,277,513]

theorem envBound49414 : H12AffineFastState.Bounded env49414 := by
  intro p hp
  have h : env49414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49413_49414 : H12AffineEnvironment.transform 4 17 env49413 = env49414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49413 == env49414) = true)

theorem identity49414 : scanCanonicalize (H12AffineFastState.compose env49414 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound49414 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49415 : List Nat := [2,4,8,16,17,16,9,256,10,266,287,287,268,276,1,263,260,10,266,0,270,17,16,3,269,16,286,261,287,10,15,17,256,17,277,11]

theorem envBound49415 : H12AffineFastState.Bounded env49415 := by
  intro p hp
  have h : env49415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49414_49415 : H12AffineEnvironment.transform 8 10 env49414 = env49415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env49414 == env49415) = true)

theorem identity49415 : scanCanonicalize (H12AffineFastState.compose env49415 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49415 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49416 : List Nat := [2,4,8,11,10,11,9,256,10,266,260,260,268,271,1,263,260,10,266,0,270,10,11,3,269,11,261,261,260,10,15,10,256,10,270,11]

theorem envBound49416 : H12AffineFastState.Bounded env49416 := by
  intro p hp
  have h : env49416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49415_49416 : H12AffineEnvironment.transform 3 11 env49415 = env49416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49415 == env49416) = true)

theorem identity49416 : scanCanonicalize (H12AffineFastState.compose env49416 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound49416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49417 : List Nat := [2,4,7,4,5,4,6,256,5,261,260,260,259,256,1,263,260,5,261,0,257,5,4,3,258,4,261,261,260,5,0,5,256,5,257,4]

theorem envBound49417 : H12AffineFastState.Bounded env49417 := by
  intro p hp
  have h : env49417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49416_49417 : H12AffineEnvironment.transform 2 7 env49416 = env49417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env49416 == env49417) = true)

theorem identity49417 : scanCanonicalize (H12AffineFastState.compose env49417 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49417 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env49418 : List Nat := [2,0,3,0,1,0,2,256,1,257,256,256,259,256,1,259,256,1,257,0,257,1,0,3,258,0,257,257,256,1,0,1,256,1,257,0]

theorem envBound49418 : H12AffineFastState.Bounded env49418 := by
  intro p hp
  have h : env49418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49417_49418 : H12AffineEnvironment.transform 1 0 env49417 = env49418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49417 == env49418) = true)

theorem identity49418 : scanCanonicalize (H12AffineFastState.compose env49418 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound49418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49419 : List Nat := [2,0,3,0,1,0,2,3,1,2,3,3,0,3,1,0,3,1,2,0,2,1,0,3,1,0,2,2,3,1,0,1,3,1,2,0]

theorem envBound49419 : H12AffineFastState.Bounded env49419 := by
  intro p hp
  have h : env49419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49418_49419 : H12AffineEnvironment.transform 7 3 env49418 = env49419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env49418 == env49419) = true)

def env49420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175169,8328,64,2609402,46156,77835,2598234,119178,2101344,256,2199862,2191507,63068]

theorem envBound49420 : H12AffineFastState.Bounded env49420 := by
  intro p hp
  have h : env49420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49357_49420 : H12AffineEnvironment.transform 23 2175169 env49357 = env49420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env49357 == env49420) = true)

def env49421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73857,8328,64,508090,46156,77835,505114,119178,32,256,98678,90323,63068]

theorem envBound49421 : H12AffineFastState.Bounded env49421 := by
  intro p hp
  have h : env49421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49420_49421 : H12AffineEnvironment.transform 20 4160 env49420 = env49421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49420 == env49421) = true)

theorem identity49421 : scanCanonicalize (H12AffineFastState.compose env49421 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49421 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73857,8328,64,497082,46156,77835,505114,99466,32,256,98678,79315,41820]

theorem envBound49422 : H12AffineFastState.Bounded env49422 := by
  intro p hp
  have h : env49422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49421_49422 : H12AffineEnvironment.transform 13 5376 env49421 = env49422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49421 == env49422) = true)

def env49423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73737,8192,64,496946,46156,77835,505114,99330,32,256,98678,79195,41820]

theorem envBound49423 : H12AffineFastState.Bounded env49423 := by
  intro p hp
  have h : env49423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49422_49423 : H12AffineEnvironment.transform 6 8 env49422 = env49423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49422 == env49423) = true)

def env49424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,4160,32,73755,73737,8192,64,245018,46156,77835,236850,99330,32,256,98678,79195,41820]

theorem envBound49424 : H12AffineFastState.Bounded env49424 := by
  intro p hp
  have h : env49424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49423_49424 : H12AffineEnvironment.transform 17 10280 env49423 = env49424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49423 == env49424) = true)

theorem identity49424 : scanCanonicalize (H12AffineFastState.compose env49424 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49424 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1024,32769,4160,32,16,2,8192,64,171281,46156,4096,179513,41993,32,256,41341,5456,41820]

theorem envBound49425 : H12AffineFastState.Bounded env49425 := by
  intro p hp
  have h : env49425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49424_49425 : H12AffineEnvironment.transform 15 8203 env49424 = env49425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49424 == env49425) = true)

theorem identity49425 : scanCanonicalize (H12AffineFastState.compose env49425 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound49425 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,13340,10280,1024,32769,4160,32,16,2,8192,64,43277,46156,4096,35109,41993,32,256,41341,5456,41820]

theorem envBound49426 : H12AffineFastState.Bounded env49426 := by
  intro p hp
  have h : env49426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49425_49426 : H12AffineEnvironment.transform 16 13340 env49425 = env49426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env49425 == env49426) = true)

theorem identity49426 : scanCanonicalize (H12AffineFastState.compose env49426 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound49426 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env49427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1345,8203,13340,10280,1024,1344,4160,32,16,2,8192,64,11340,12557,4096,3172,8520,32,256,9276,5456,9757]

theorem envBound49427 : H12AffineFastState.Bounded env49427 := by
  intro p hp
  have h : env49427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49426_49427 : H12AffineEnvironment.transform 14 1345 env49426 = env49427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env49426 == env49427) = true)

theorem identity49427 : scanCanonicalize (H12AffineFastState.compose env49427 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound49427 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env49428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,1345,115,5220,2128,1024,1344,4160,32,16,2,120,64,3124,4469,4096,3172,304,32,256,1092,5456,1637]

theorem envBound49428 : H12AffineFastState.Bounded env49428 := by
  intro p hp
  have h : env49428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49427_49428 : H12AffineEnvironment.transform 12 120 env49427 = env49428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env49427 == env49428) = true)

theorem identity49428 : scanCanonicalize (H12AffineFastState.compose env49428 (packedSelected [1,2,3,5,8,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49428 : packedSelected [1,2,3,5,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49429 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5376,1296,34,5173,2049,1024,1297,4113,32,16,2,41,17,3124,4388,4096,3125,304,32,256,1045,5377,1588]

theorem envBound49429 : H12AffineFastState.Bounded env49429 := by
  intro p hp
  have h : env49429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49428_49429 : H12AffineEnvironment.transform 5 17 env49428 = env49429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49428 == env49429) = true)

theorem identity49429 : scanCanonicalize (H12AffineFastState.compose env49429 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound49429 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env49430 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,41,4113,1,34,4388,2049,273,0,4113,32,16,2,41,17,2341,4388,4096,2340,304,32,256,260,4112,805]

theorem envBound49430 : H12AffineFastState.Bounded env49430 := by
  intro p hp
  have h : env49430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49429_49430 : H12AffineEnvironment.transform 9 273 env49429 = env49430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env49429 == env49430) = true)

theorem identity49430 : scanCanonicalize (H12AffineFastState.compose env49430 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49430 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49431 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4113,1,34,4097,2049,52,0,4113,32,16,2,41,17,2048,4097,4096,2049,21,32,37,33,4112,512]

theorem envBound49431 : H12AffineFastState.Bounded env49431 := by
  intro p hp
  have h : env49431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49430_49431 : H12AffineEnvironment.transform 7 37 env49430 = env49431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49430 == env49431) = true)

theorem identity49431 : scanCanonicalize (H12AffineFastState.compose env49431 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49431 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49432 : List Nat := [2,4,8,16,32,17,8,37,0,52,2048,4096,41,4113,1,34,4097,2049,52,0,4113,32,16,2,41,17,2048,4097,4096,2049,21,32,37,33,4112,0]

theorem envBound49432 : H12AffineFastState.Bounded env49432 := by
  intro p hp
  have h : env49432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49431_49432 : H12AffineEnvironment.transform 8 0 env49431 = env49432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49431 == env49432) = true)

theorem identity49432 : scanCanonicalize (H12AffineFastState.compose env49432 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 63) := by decide +kernel

theorem selectedBound49432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49433 : List Nat := [2,4,8,16,32,17,8,37,0,52,63,4096,41,4113,1,34,4097,62,52,0,4113,32,16,2,41,17,63,4097,4096,62,21,32,37,33,4112,0]

theorem envBound49433 : H12AffineFastState.Bounded env49433 := by
  intro p hp
  have h : env49433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49432_49433 : H12AffineEnvironment.transform 10 63 env49432 = env49433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 63 env49432 == env49433) = true)

theorem identity49433 : scanCanonicalize (H12AffineFastState.compose env49433 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49434 : List Nat := [2,4,8,16,0,17,8,5,0,20,31,4096,9,4113,1,2,4097,30,20,0,4113,0,16,2,9,17,31,4097,4096,30,21,0,5,1,4112,0]

theorem envBound49434 : H12AffineFastState.Bounded env49434 := by
  intro p hp
  have h : env49434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49433_49434 : H12AffineEnvironment.transform 4 0 env49433 = env49434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49433 == env49434) = true)

theorem identity49434 : scanCanonicalize (H12AffineFastState.compose env49434 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 15) := by decide +kernel

theorem selectedBound49434 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49435 : List Nat := [2,4,8,16,0,17,8,5,0,20,31,15,9,30,1,2,14,30,20,0,30,0,16,2,9,17,31,14,15,30,21,0,5,1,31,0]

theorem envBound49435 : H12AffineFastState.Bounded env49435 := by
  intro p hp
  have h : env49435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49434_49435 : H12AffineEnvironment.transform 11 15 env49434 = env49435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 15 env49434 == env49435) = true)

def leafEnv49435 : List Nat := [2,4,8,16,0,17,8,5,0,20,31,15,9,30,1,2,14,30,20,0,30,0,16,2,21,9,1,17,31,14,15,30,21,0,5,1,4,2,31,0,1,31,0]

def active49435 : List Nat := [0,1,2,3]

def tree49435 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49435 : H12WitnessSearch.Good tree49435 := H12GlobalWitnessIndex.good

theorem leafIdentity49435 : H12AffineFastState.composeSystem env49435 rootObs = leafEnv49435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49435 rootObs == leafEnv49435) = true)

theorem terminalChecked49435 : H12PackedTerminal.terminalCheckFast leafEnv49435 active49435 tree49435 = true := by decide +kernel

def env49436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4160,32,73755,73737,8192,64,245019,46156,77835,236851,99330,32,256,98678,79195,41820]

theorem envBound49436 : H12AffineFastState.Bounded env49436 := by
  intro p hp
  have h : env49436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49423_49436 : H12AffineEnvironment.transform 17 10281 env49423 = env49436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49423 == env49436) = true)

theorem identity49436 : scanCanonicalize (H12AffineFastState.compose env49436 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound49436 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env49437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13341,10281,1024,32769,4160,32,73755,73737,8192,64,100614,46156,77835,108846,99330,32,256,98678,79195,41820]

theorem envBound49437 : H12AffineFastState.Bounded env49437 := by
  intro p hp
  have h : env49437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49436_49437 : H12AffineEnvironment.transform 16 13341 env49436 = env49437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env49436 == env49437) = true)

theorem identity49437 : scanCanonicalize (H12AffineFastState.compose env49437 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49437 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env49438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13341,10281,1024,8540,4160,32,73755,73737,8192,64,75867,5393,77835,67699,75103,32,256,73771,79195,513]

theorem envBound49438 : H12AffineFastState.Bounded env49438 := by
  intro p hp
  have h : env49438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49437_49438 : H12AffineEnvironment.transform 14 8541 env49437 = env49438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49437 == env49438) = true)

theorem identity49438 : scanCanonicalize (H12AffineFastState.compose env49438 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49438 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49439 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,65536,13341,10281,1024,8460,4112,32,73755,73737,8192,16,75787,5393,77835,67619,75023,32,256,73771,79115,513]

theorem envBound49439 : H12AffineFastState.Bounded env49439 := by
  intro p hp
  have h : env49439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49438_49439 : H12AffineEnvironment.transform 5 16 env49438 = env49439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49438 == env49439) = true)

theorem identity49439 : scanCanonicalize (H12AffineFastState.compose env49439 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound49439 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49440 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,263,13341,10281,1024,8460,4112,32,8476,8462,8192,16,10508,5393,12556,2340,9224,32,256,8492,13324,513]

theorem envBound49440 : H12AffineFastState.Bounded env49440 := by
  intro p hp
  have h : env49440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49439_49440 : H12AffineEnvironment.transform 15 263 env49439 = env49440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env49439 == env49440) = true)

theorem identity49440 : scanCanonicalize (H12AffineFastState.compose env49440 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound49440 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49441 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5133,5376,5376,263,16,7204,1024,5377,4112,32,5393,5379,5133,16,7425,5393,1281,2340,4101,32,256,5409,1,513]

theorem envBound49441 : H12AffineFastState.Bounded env49441 := by
  intro p hp
  have h : env49441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49440_49441 : H12AffineEnvironment.transform 12 5133 env49440 = env49441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env49440 == env49441) = true)

theorem identity49441 : scanCanonicalize (H12AffineFastState.compose env49441 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound49441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49442 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1281,268,1,1,263,16,2341,1024,0,1297,32,16,2,268,16,2048,16,1281,2340,1284,32,256,32,1,513]

theorem envBound49442 : H12AffineFastState.Bounded env49442 := by
  intro p hp
  have h : env49442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49441_49442 : H12AffineEnvironment.transform 11 1281 env49441 = env49442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env49441 == env49442) = true)

theorem identity49442 : scanCanonicalize (H12AffineFastState.compose env49442 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49442 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49443 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,1281,268,1,1,263,16,2308,1024,0,1297,1,16,2,268,16,2048,16,1281,2309,1284,1,256,1,1,513]

theorem envBound49443 : H12AffineFastState.Bounded env49443 := by
  intro p hp
  have h : env49443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49442_49443 : H12AffineEnvironment.transform 4 1 env49442 = env49443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49442 == env49443) = true)

theorem identity49443 : scanCanonicalize (H12AffineFastState.compose env49443 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound49443 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49444 : List Nat := [2,4,8,16,1,16,8,256,512,1024,512,1281,268,1,1,263,16,772,1024,0,1297,1,16,2,268,16,512,16,1281,773,1284,1,256,1,1,513]

theorem envBound49444 : H12AffineFastState.Bounded env49444 := by
  intro p hp
  have h : env49444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49443_49444 : H12AffineEnvironment.transform 10 512 env49443 = env49444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env49443 == env49444) = true)

theorem identity49444 : scanCanonicalize (H12AffineFastState.compose env49444 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49444 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49445 : List Nat := [2,4,8,0,1,0,8,256,512,1024,512,1281,268,1,1,263,0,772,1024,0,1281,1,0,2,268,0,512,0,1281,773,1284,1,256,1,1,513]

theorem envBound49445 : H12AffineFastState.Bounded env49445 := by
  intro p hp
  have h : env49445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49444_49445 : H12AffineEnvironment.transform 3 0 env49444 = env49445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49444 == env49445) = true)

theorem identity49445 : scanCanonicalize (H12AffineFastState.compose env49445 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound49445 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49446 : List Nat := [2,4,8,0,1,0,8,256,260,1024,260,1281,268,1,1,263,0,0,1024,0,1281,1,0,2,268,0,260,0,1281,1,1284,1,256,1,1,261]

theorem envBound49446 : H12AffineFastState.Bounded env49446 := by
  intro p hp
  have h : env49446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49445_49446 : H12AffineEnvironment.transform 8 260 env49445 = env49446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env49445 == env49446) = true)

def env49447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73736,8193,64,496947,46156,77835,505114,99331,32,256,98678,79194,41820]

theorem envBound49447 : H12AffineFastState.Bounded env49447 := by
  intro p hp
  have h : env49447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49422_49447 : H12AffineEnvironment.transform 6 9 env49422 = env49447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49422 == env49447) = true)

theorem identity49447 : scanCanonicalize (H12AffineFastState.compose env49447 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound49447 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env49448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79130,262144,1024,32769,4160,32,73755,73736,8193,64,303145,46156,77835,294912,99331,32,256,98678,79194,41820]

theorem envBound49448 : H12AffineFastState.Bounded env49448 := by
  intro p hp
  have h : env49448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49447_49448 : H12AffineEnvironment.transform 16 79130 env49447 = env49448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env49447 == env49448) = true)

theorem identity49448 : scanCanonicalize (H12AffineFastState.compose env49448 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49448 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env49449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79130,262144,1024,8540,4160,32,73755,73736,8193,64,262516,5393,77835,270685,75102,32,256,73771,79194,513]

theorem envBound49449 : H12AffineFastState.Bounded env49449 := by
  intro p hp
  have h : env49449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49448_49449 : H12AffineEnvironment.transform 14 8541 env49448 = env49449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49448 == env49449) = true)

theorem identity49449 : scanCanonicalize (H12AffineFastState.compose env49449 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound49449 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,292,65536,71011,262144,1024,293,4160,32,65634,65649,120,64,262516,5393,69746,262436,66855,32,256,65618,70947,513]

theorem envBound49450 : H12AffineFastState.Bounded env49450 := by
  intro p hp
  have h : env49450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49449_49450 : H12AffineEnvironment.transform 12 121 env49449 = env49450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env49449 == env49450) = true)

theorem identity49450 : scanCanonicalize (H12AffineFastState.compose env49450 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound49450 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env49451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,292,1378,4097,262144,1024,293,4160,32,1280,1299,120,64,262516,5393,5392,262436,69,32,256,1328,4161,513]

theorem envBound49451 : H12AffineFastState.Bounded env49451 := by
  intro p hp
  have h : env49451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49450_49451 : H12AffineEnvironment.transform 15 1378 env49450 = env49451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env49450 == env49451) = true)

theorem identity49451 : scanCanonicalize (H12AffineFastState.compose env49451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound49451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,292,1378,4097,2129,1024,293,4160,32,1280,1299,120,64,2341,5393,5392,2421,69,32,256,1328,4161,513]

theorem envBound49452 : H12AffineFastState.Bounded env49452 := by
  intro p hp
  have h : env49452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49451_49452 : H12AffineEnvironment.transform 17 2129 env49451 = env49452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env49451 == env49452) = true)

theorem identity49452 : scanCanonicalize (H12AffineFastState.compose env49452 (packedSelected [0,1,3,4,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49452 : packedSelected [0,1,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env49453 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,80,1046,4097,2129,1024,81,4160,32,1140,1127,120,64,2129,5221,5220,2049,69,32,116,1092,4161,513]

theorem envBound49453 : H12AffineFastState.Bounded env49453 := by
  intro p hp
  have h : env49453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49452_49453 : H12AffineEnvironment.transform 7 116 env49452 = env49453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49452 == env49453) = true)

theorem identity49453 : scanCanonicalize (H12AffineFastState.compose env49453 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound49453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49454 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,16,121,1124,80,1046,17,2129,1024,81,80,32,1140,1127,120,64,2129,1141,1140,2049,69,32,116,1092,81,513]

theorem envBound49454 : H12AffineFastState.Bounded env49454 := by
  intro p hp
  have h : env49454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49453_49454 : H12AffineEnvironment.transform 11 16 env49453 = env49454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49453 == env49454) = true)

theorem identity49454 : scanCanonicalize (H12AffineFastState.compose env49454 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49454 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env49455 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1,16,121,1124,80,1046,17,80,1024,81,80,32,1140,1127,120,64,80,1141,1140,0,69,32,116,1092,81,513]

theorem envBound49455 : H12AffineFastState.Bounded env49455 := by
  intro p hp
  have h : env49455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49454_49455 : H12AffineEnvironment.transform 10 1 env49454 = env49455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49454 == env49455) = true)

theorem identity49455 : scanCanonicalize (H12AffineFastState.compose env49455 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound49455 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env49456 : List Nat := [2,4,8,16,32,64,9,116,32,1024,1,16,121,1124,80,1046,17,80,1024,81,80,32,1140,1127,120,64,80,1141,1140,0,69,32,116,1092,81,33]

theorem envBound49456 : H12AffineFastState.Bounded env49456 := by
  intro p hp
  have h : env49456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49455_49456 : H12AffineEnvironment.transform 8 32 env49455 = env49456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env49455 == env49456) = true)

def env49457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73856,8328,64,508091,46156,77835,505115,119178,33,256,98679,90322,63068]

theorem envBound49457 : H12AffineFastState.Bounded env49457 := by
  intro p hp
  have h : env49457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49420_49457 : H12AffineEnvironment.transform 20 4161 env49420 = env49457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49420 == env49457) = true)

theorem identity49457 : scanCanonicalize (H12AffineFastState.compose env49457 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49457 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73736,8192,64,507955,46156,77835,505115,119042,33,256,98679,90202,63068]

theorem envBound49458 : H12AffineFastState.Bounded env49458 := by
  intro p hp
  have h : env49458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49457_49458 : H12AffineEnvironment.transform 6 8 env49457 = env49458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49457 == env49458) = true)

theorem identity49458 : scanCanonicalize (H12AffineFastState.compose env49458 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound49458 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1024,32769,4161,21793,95514,73736,8192,64,203847,46156,77835,223599,119042,33,256,98679,90202,63068]

theorem envBound49459 : H12AffineFastState.Bounded env49459 := by
  intro p hp
  have h : env49459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49458_49459 : H12AffineEnvironment.transform 17 56436 env49458 = env49459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env49458 == env49459) = true)

theorem identity49459 : scanCanonicalize (H12AffineFastState.compose env49459 (packedSelected [1,5,8,19,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49459 : packedSelected [1,5,8,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env49460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,4161,21793,95514,73736,8192,64,203847,16401,77835,223599,75103,33,256,95530,90202,513]

theorem envBound49460 : H12AffineFastState.Bounded env49460 := by
  intro p hp
  have h : env49460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49459_49460 : H12AffineEnvironment.transform 14 29789 env49459 = env49460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49459 == env49460) = true)

theorem identity49460 : scanCanonicalize (H12AffineFastState.compose env49460 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound49460 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env49461 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,79179,10281,1024,29788,4161,21793,95514,73736,8192,64,10508,16401,77835,23588,75103,33,256,95530,90202,513]

theorem envBound49461 : H12AffineFastState.Bounded env49461 := by
  intro p hp
  have h : env49461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49460_49461 : H12AffineEnvironment.transform 16 79179 env49460 = env49461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env49460 == env49461) = true)

theorem identity49461 : scanCanonicalize (H12AffineFastState.compose env49461 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound49461 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env49462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21591,24860,10281,1024,29788,4161,21793,8525,29791,8192,64,10508,16401,25692,23588,28936,33,256,8573,13325,513]

theorem envBound49462 : H12AffineFastState.Bounded env49462 := by
  intro p hp
  have h : env49462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49461_49462 : H12AffineEnvironment.transform 15 21591 env49461 = env49462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env49461 == env49462) = true)

theorem identity49462 : scanCanonicalize (H12AffineFastState.compose env49462 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49462 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21591,16448,2421,1024,21760,4161,21793,17,21763,348,64,2128,16401,17664,23588,20564,33,256,33,5457,513]

theorem envBound49463 : H12AffineFastState.Bounded env49463 := by
  intro p hp
  have h : env49463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49462_49463 : H12AffineEnvironment.transform 12 348 env49462 = env49463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49462 == env49463) = true)

theorem identity49463 : scanCanonicalize (H12AffineFastState.compose env49463 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49463 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49464 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,16384,21540,21591,16448,2128,1024,21541,4161,21508,17,21542,121,64,2128,16401,17445,23588,20564,33,37,33,5236,513]

theorem envBound49464 : H12AffineFastState.Bounded env49464 := by
  intro p hp
  have h : env49464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49463_49464 : H12AffineEnvironment.transform 7 37 env49463 = env49464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49463 == env49464) = true)

theorem identity49464 : scanCanonicalize (H12AffineFastState.compose env49464 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound49464 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49465 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,3125,6161,6242,3189,2128,1024,6160,4161,6193,17,6163,121,64,2128,3108,2064,4113,7265,33,37,33,5236,513]

theorem envBound49465 : H12AffineFastState.Bounded env49465 := by
  intro p hp
  have h : env49465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49464_49465 : H12AffineEnvironment.transform 13 3125 env49464 = env49465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env49464 == env49465) = true)

def env49466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,16777216,8328,64,17227834,18973837,77835,2598234,18932043,16851104,256,16818679,16793682,18990749]

theorem envBound49466 : H12AffineFastState.Bounded env49466 := by
  intro p hp
  have h : env49466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49356_49466 : H12AffineEnvironment.transform 21 2114913 env49356 = env49466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env49356 == env49466) = true)

def env49467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175168,8328,64,2609402,46157,77835,2598234,119179,2101344,256,2199863,2191506,63069]

theorem envBound49467 : H12AffineFastState.Bounded env49467 := by
  intro p hp
  have h : env49467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49466_49467 : H12AffineEnvironment.transform 23 2175168 env49466 = env49467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env49466 == env49467) = true)

def env49468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73856,8328,64,508090,46157,77835,505114,119179,32,256,98679,90322,63069]

theorem envBound49468 : H12AffineFastState.Bounded env49468 := by
  intro p hp
  have h : env49468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49467_49468 : H12AffineEnvironment.transform 20 4160 env49467 = env49468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49467 == env49468) = true)

theorem identity49468 : scanCanonicalize (H12AffineFastState.compose env49468 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound49468 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,1024,32769,4160,21793,62660,41311,8328,64,409957,46157,45524,406725,20564,32,256,168,57613,63069]

theorem envBound49469 : H12AffineFastState.Bounded env49469 := by
  intro p hp
  have h : env49469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49468_49469 : H12AffineEnvironment.transform 15 33247 env49468 = env49469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env49468 == env49469) = true)

def env49470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,10280,1024,32769,4160,21793,62660,41311,8328,64,158029,46157,45524,138477,20564,32,256,168,57613,63069]

theorem envBound49470 : H12AffineFastState.Bounded env49470 := by
  intro p hp
  have h : env49470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49469_49470 : H12AffineEnvironment.transform 17 10280 env49469 = env49470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49469 == env49470) = true)

theorem identity49470 : scanCanonicalize (H12AffineFastState.compose env49470 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound49470 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env49471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16401,10280,1024,32769,4160,21793,62660,41311,8328,64,10588,46157,45524,23804,20564,32,256,168,57613,63069]

theorem envBound49471 : H12AffineFastState.Bounded env49471 := by
  intro p hp
  have h : env49471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49470_49471 : H12AffineEnvironment.transform 16 16401 env49470 = env49471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49470 == env49471) = true)

theorem identity49471 : scanCanonicalize (H12AffineFastState.compose env49471 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 20633) := by decide +kernel

theorem selectedBound49471 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env49472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20633,20806,16401,10280,1024,20632,4160,21793,9309,29126,8328,64,10588,25812,24909,23804,20564,32,256,168,12692,9924]

theorem envBound49472 : H12AffineFastState.Bounded env49472 := by
  intro p hp
  have h : env49472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49471_49472 : H12AffineEnvironment.transform 14 20633 env49471 = env49472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20633 env49471 == env49472) = true)

theorem identity49472 : scanCanonicalize (H12AffineFastState.compose env49472 (packedSelected [0,3,4,5,7,10,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound49472 : packedSelected [0,3,4,5,7,10,21,22] rootPS < 2^1333 := by decide +kernel

def env49473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12621,8660,8203,12636,10280,1024,8661,4160,9324,9309,139,8328,64,10588,5529,4096,11697,8473,32,256,168,12692,9924]

theorem envBound49473 : H12AffineFastState.Bounded env49473 := by
  intro p hp
  have h : env49473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49472_49473 : H12AffineEnvironment.transform 13 12621 env49472 = env49473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env49472 == env49473) = true)

theorem identity49473 : scanCanonicalize (H12AffineFastState.compose env49473 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound49473 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env49474 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,12512,8313,8203,12529,10280,1024,8312,4160,9324,9309,139,8328,64,10481,5172,4096,11292,8372,32,173,168,12345,9924]

theorem envBound49474 : H12AffineFastState.Bounded env49474 := by
  intro p hp
  have h : env49474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49473_49474 : H12AffineEnvironment.transform 7 173 env49473 = env49474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49473 == env49474) = true)

theorem identity49474 : scanCanonicalize (H12AffineFastState.compose env49474 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound49474 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49475 : List Nat := [2,4,8,16,32,64,128,173,512,20,2048,4096,8192,12512,8313,8203,12529,10280,20,8312,4160,8312,8265,139,8328,64,10481,4128,4096,10248,8372,32,173,168,12345,8912]

theorem envBound49475 : H12AffineFastState.Bounded env49475 := by
  intro p hp
  have h : env49475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49474_49475 : H12AffineEnvironment.transform 9 20 env49474 = env49475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env49474 == env49475) = true)

theorem identity49475 : scanCanonicalize (H12AffineFastState.compose env49475 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound49475 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49476 : List Nat := [2,4,8,16,32,64,128,173,512,20,2048,4096,120,4248,1,115,4233,2128,20,0,4160,0,49,139,240,64,2185,4128,4096,2160,204,32,173,168,4161,680]

theorem envBound49476 : H12AffineFastState.Bounded env49476 := by
  intro p hp
  have h : env49476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49475_49476 : H12AffineEnvironment.transform 12 120 env49475 = env49476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env49475 == env49476) = true)

theorem identity49476 : scanCanonicalize (H12AffineFastState.compose env49476 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49476 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env49477 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,4096,120,4113,1,115,4096,2128,20,0,4160,0,49,2,121,64,2048,4128,4096,2160,69,32,36,33,4161,545]

theorem envBound49477 : H12AffineFastState.Bounded env49477 := by
  intro p hp
  have h : env49477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49476_49477 : H12AffineEnvironment.transform 6 9 env49476 = env49477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49476 == env49477) = true)

theorem identity49477 : scanCanonicalize (H12AffineFastState.compose env49477 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound49477 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49478 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,33,120,48,1,115,33,2128,20,0,97,0,49,2,121,64,2048,1,33,2160,69,32,36,33,96,545]

theorem envBound49478 : H12AffineFastState.Bounded env49478 := by
  intro p hp
  have h : env49478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49477_49478 : H12AffineEnvironment.transform 11 33 env49477 = env49478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env49477 == env49478) = true)

theorem identity49478 : scanCanonicalize (H12AffineFastState.compose env49478 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49478 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49479 : List Nat := [2,4,8,16,1,64,9,5,512,20,2048,0,89,17,1,82,0,2128,20,0,64,0,16,2,88,64,2048,1,0,2129,69,1,5,0,65,512]

theorem envBound49479 : H12AffineFastState.Bounded env49479 := by
  intro p hp
  have h : env49479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49478_49479 : H12AffineEnvironment.transform 4 1 env49478 = env49479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49478 == env49479) = true)

theorem identity49479 : scanCanonicalize (H12AffineFastState.compose env49479 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49479 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49480 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,0,9,17,1,2,0,2048,20,0,16,0,16,2,8,16,2048,1,0,2049,21,1,5,0,17,512]

theorem envBound49480 : H12AffineFastState.Bounded env49480 := by
  intro p hp
  have h : env49480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49479_49480 : H12AffineEnvironment.transform 5 16 env49479 = env49480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49479 == env49480) = true)

theorem identity49480 : scanCanonicalize (H12AffineFastState.compose env49480 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound49480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49481 : List Nat := [2,4,8,16,1,16,9,5,5,20,2048,0,9,17,1,2,0,2048,20,0,16,0,16,2,8,16,2048,1,0,2049,21,1,5,0,17,5]

theorem envBound49481 : H12AffineFastState.Bounded env49481 := by
  intro p hp
  have h : env49481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49480_49481 : H12AffineEnvironment.transform 8 5 env49480 = env49481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env49480 == env49481) = true)

theorem identity49481 : scanCanonicalize (H12AffineFastState.compose env49481 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound49481 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49482 : List Nat := [2,4,8,16,1,16,9,5,5,20,9,0,9,17,1,2,0,9,20,0,16,0,16,2,8,16,9,1,0,8,21,1,5,0,17,5]

theorem envBound49482 : H12AffineFastState.Bounded env49482 := by
  intro p hp
  have h : env49482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49481_49482 : H12AffineEnvironment.transform 10 9 env49481 = env49482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env49481 == env49482) = true)

theorem identity49482 : scanCanonicalize (H12AffineFastState.compose env49482 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound49482 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49483 : List Nat := [2,4,8,3,1,3,9,5,5,7,9,0,9,2,1,2,0,9,7,0,3,0,3,2,8,3,9,1,0,8,6,1,5,0,2,5]

theorem envBound49483 : H12AffineFastState.Bounded env49483 := by
  intro p hp
  have h : env49483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49482_49483 : H12AffineEnvironment.transform 3 3 env49482 = env49483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env49482 == env49483) = true)

theorem identity49483 : scanCanonicalize (H12AffineFastState.compose env49483 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49483 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49484 : List Nat := [0,4,8,1,1,1,9,5,5,5,9,0,9,0,1,0,0,9,5,0,1,0,1,0,8,1,9,1,0,8,4,1,5,0,0,5]

theorem envBound49484 : H12AffineFastState.Bounded env49484 := by
  intro p hp
  have h : env49484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49483_49484 : H12AffineEnvironment.transform 0 0 env49483 = env49484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49483 == env49484) = true)

theorem identity49484 : scanCanonicalize (H12AffineFastState.compose env49484 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49484 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env49485 : List Nat := [0,4,1,1,1,1,0,5,5,5,0,0,0,0,1,0,0,0,5,0,1,0,1,0,1,1,0,1,0,1,4,1,5,0,0,5]

theorem envBound49485 : H12AffineFastState.Bounded env49485 := by
  intro p hp
  have h : env49485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49484_49485 : H12AffineEnvironment.transform 2 1 env49484 = env49485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49484 == env49485) = true)

def env49486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,10281,1024,32769,4160,21793,62660,41311,8328,64,158028,46157,45524,138476,20564,32,256,168,57613,63069]

theorem envBound49486 : H12AffineFastState.Bounded env49486 := by
  intro p hp
  have h : env49486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49469_49486 : H12AffineEnvironment.transform 17 10281 env49469 = env49486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49469 == env49486) = true)

theorem identity49486 : scanCanonicalize (H12AffineFastState.compose env49486 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49486 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env49487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29963,131072,10281,1024,29909,4160,21793,16,21899,8328,64,158028,16537,17664,138476,20564,32,256,168,5593,649]

theorem envBound49487 : H12AffineFastState.Bounded env49487 := by
  intro p hp
  have h : env49487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49486_49487 : H12AffineEnvironment.transform 14 29908 env49486 = env49487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49486 == env49487) = true)

theorem identity49487 : scanCanonicalize (H12AffineFastState.compose env49487 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound49487 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env49488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29963,13625,10281,1024,29909,4160,21793,16,21899,8328,64,23669,16537,17664,10709,20564,32,256,168,5593,649]

theorem envBound49488 : H12AffineFastState.Bounded env49488 := by
  intro p hp
  have h : env49488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49487_49488 : H12AffineEnvironment.transform 16 13625 env49487 = env49488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env49487 == env49488) = true)

theorem identity49488 : scanCanonicalize (H12AffineFastState.compose env49488 (packedSelected [1,4,6,8,9,10,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49488 : packedSelected [1,4,6,8,9,10,15,20] rootPS < 2^1333 := by decide +kernel

def env49489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,29963,13625,10281,1024,29829,4112,21793,16,21899,8328,16,23589,16537,17664,10629,20484,32,256,168,5513,649]

theorem envBound49489 : H12AffineFastState.Bounded env49489 := by
  intro p hp
  have h : env49489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49488_49489 : H12AffineEnvironment.transform 5 16 env49488 = env49489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49488 == env49489) = true)

theorem identity49489 : scanCanonicalize (H12AffineFastState.compose env49489 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49489 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env49490 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,8203,13625,10281,1024,8581,4112,33,16,139,8328,16,2341,5529,4096,10629,1284,32,256,168,5513,649]

theorem envBound49490 : H12AffineFastState.Bounded env49490 := by
  intro p hp
  have h : env49490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49489_49490 : H12AffineEnvironment.transform 13 5376 env49489 = env49490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49489 == env49490) = true)

theorem identity49490 : scanCanonicalize (H12AffineFastState.compose env49490 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49490 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env49491 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8203,13625,10281,1024,8460,4112,33,16,2,8193,16,2341,5392,4096,10508,1284,32,256,33,5376,512]

theorem envBound49491 : H12AffineFastState.Bounded env49491 := by
  intro p hp
  have h : env49491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49490_49491 : H12AffineEnvironment.transform 6 9 env49490 = env49491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49490 == env49491) = true)

theorem identity49491 : scanCanonicalize (H12AffineFastState.compose env49491 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49491 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49492 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8192,5125,8200,8203,13372,10281,1024,8201,4112,33,16,2,8193,16,2080,5141,4096,10249,1025,32,5,33,5125,512]

theorem envBound49492 : H12AffineFastState.Bounded env49492 := by
  intro p hp
  have h : env49492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49491_49492 : H12AffineEnvironment.transform 7 5 env49491 = env49492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49491 == env49492) = true)

theorem identity49492 : scanCanonicalize (H12AffineFastState.compose env49492 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49492 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49493 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8192,5125,8200,8203,13341,10248,1024,8201,4112,0,16,2,8193,16,2049,5141,4096,10249,1025,1,5,0,5125,512]

theorem envBound49493 : H12AffineFastState.Bounded env49493 := by
  intro p hp
  have h : env49493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49492_49493 : H12AffineEnvironment.transform 4 1 env49492 = env49493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49492 == env49493) = true)

theorem identity49493 : scanCanonicalize (H12AffineFastState.compose env49493 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound49493 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49494 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,4096,8192,4112,8200,8203,12296,10248,21,8201,4112,0,16,2,8193,16,2049,4096,4096,10249,20,1,5,0,4112,512]

theorem envBound49494 : H12AffineFastState.Bounded env49494 := by
  intro p hp
  have h : env49494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49493_49494 : H12AffineEnvironment.transform 9 21 env49493 = env49494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env49493 == env49494) = true)

theorem identity49494 : scanCanonicalize (H12AffineFastState.compose env49494 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound49494 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49495 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,4096,8,4112,0,3,4096,2048,21,1,4112,0,16,2,9,16,2049,4096,4096,2049,20,1,5,0,4112,512]

theorem envBound49495 : H12AffineFastState.Bounded env49495 := by
  intro p hp
  have h : env49495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49494_49495 : H12AffineEnvironment.transform 12 8 env49494 = env49495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env49494 == env49495) = true)

theorem identity49495 : scanCanonicalize (H12AffineFastState.compose env49495 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound49495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49496 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,8,0,0,3,16,2048,21,1,0,0,16,2,9,16,2049,16,16,2049,20,1,5,0,0,512]

theorem envBound49496 : H12AffineFastState.Bounded env49496 := by
  intro p hp
  have h : env49496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49495_49496 : H12AffineEnvironment.transform 11 16 env49495 = env49496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49495 == env49496) = true)

theorem identity49496 : scanCanonicalize (H12AffineFastState.compose env49496 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound49496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49497 : List Nat := [2,4,8,5,1,5,9,5,512,0,2048,5,8,0,0,3,5,2048,0,1,0,0,5,2,9,5,2049,5,5,2049,1,1,5,0,0,512]

theorem envBound49497 : H12AffineFastState.Bounded env49497 := by
  intro p hp
  have h : env49497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49496_49497 : H12AffineEnvironment.transform 3 5 env49496 = env49497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49496 == env49497) = true)

def env49498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73857,8328,64,508091,46157,77835,505115,119179,33,256,98678,90323,63069]

theorem envBound49498 : H12AffineFastState.Bounded env49498 := by
  intro p hp
  have h : env49498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49467_49498 : H12AffineEnvironment.transform 20 4161 env49467 = env49498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49467 == env49498) = true)

theorem identity49498 : scanCanonicalize (H12AffineFastState.compose env49498 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound49498 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,21792,41293,62678,8328,64,398572,46157,58460,418124,1500,33,256,21793,46212,63069]

theorem envBound49499 : H12AffineFastState.Bounded env49499 := by
  intro p hp
  have h : env49499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49498_49499 : H12AffineEnvironment.transform 15 54359 env49498 = env49499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env49498 == env49499) = true)

def env49500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,4161,21792,41293,62678,8328,64,146628,46157,58460,149860,1500,33,256,21793,46212,63069]

theorem envBound49500 : H12AffineFastState.Bounded env49500 := by
  intro p hp
  have h : env49500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49499_49500 : H12AffineEnvironment.transform 17 10280 env49499 = env49500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49499 == env49500) = true)

theorem identity49500 : scanCanonicalize (H12AffineFastState.compose env49500 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49500 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10280,1024,8540,4161,21792,16,21899,8328,64,146628,5392,17665,149860,1500,33,256,21793,5593,22272]

theorem envBound49501 : H12AffineFastState.Bounded env49501 := by
  intro p hp
  have h : env49501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49500_49501 : H12AffineEnvironment.transform 14 8541 env49500 = env49501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49500 == env49501) = true)

theorem identity49501 : scanCanonicalize (H12AffineFastState.compose env49501 (packedSelected [1,2,3,4,6,11,16,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound49501 : packedSelected [1,2,3,4,6,11,16,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env49502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,5173,10280,1024,8540,4161,21792,16,21899,8328,64,10481,5392,17665,23889,1500,33,256,21793,5593,22272]

theorem envBound49502 : H12AffineFastState.Bounded env49502 := by
  intro p hp
  have h : env49502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49501_49502 : H12AffineEnvironment.transform 16 5173 env49501 = env49502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env49501 == env49502) = true)

theorem identity49502 : scanCanonicalize (H12AffineFastState.compose env49502 (packedSelected [0,3,4,7,10,12,15,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49502 : packedSelected [0,3,4,7,10,12,15,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8541,9498,5173,10280,1024,8540,4161,1328,16,1435,8328,64,10481,5392,5393,3393,1500,33,256,1329,5593,1808]

theorem envBound49503 : H12AffineFastState.Bounded env49503 := by
  intro p hp
  have h : env49503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49502_49503 : H12AffineEnvironment.transform 13 4112 env49502 = env49503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49502 == env49503) = true)

theorem identity49503 : scanCanonicalize (H12AffineFastState.compose env49503 (packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound49503 : packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env49504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,4112,1344,263,5173,3125,1024,1345,4161,1328,16,1435,1173,64,3308,5392,5393,3393,1500,33,256,1329,5593,1808]

theorem envBound49504 : H12AffineFastState.Bounded env49504 := by
  intro p hp
  have h : env49504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49503_49504 : H12AffineEnvironment.transform 12 1053 env49503 = env49504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env49503 == env49504) = true)

theorem identity49504 : scanCanonicalize (H12AffineFastState.compose env49504 (packedSelected [2,4,6,12,15,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound49504 : packedSelected [2,4,6,12,15,20,22] rootPS < 2^1333 := by decide +kernel

def env49505 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,469,4112,136,263,4605,2557,456,137,4161,248,16,83,349,64,2340,4312,4313,2185,20,33,256,249,4113,728]

theorem envBound49505 : H12AffineFastState.Bounded env49505 := by
  intro p hp
  have h : env49505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49504_49505 : H12AffineEnvironment.transform 9 456 env49504 = env49505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env49504 == env49505) = true)

theorem identity49505 : scanCanonicalize (H12AffineFastState.compose env49505 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound49505 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env49506 : List Nat := [2,4,8,16,32,64,128,172,512,100,2048,4096,121,4112,136,171,4177,2129,100,137,4161,248,16,83,241,64,2184,4312,4313,2185,20,33,172,249,4113,728]

theorem envBound49506 : H12AffineFastState.Bounded env49506 := by
  intro p hp
  have h : env49506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49505_49506 : H12AffineEnvironment.transform 7 172 env49505 = env49506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49505 == env49506) = true)

theorem identity49506 : scanCanonicalize (H12AffineFastState.compose env49506 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound49506 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env49507 : List Nat := [2,4,8,16,32,64,128,172,512,100,2048,2064,121,2048,136,171,2113,2129,100,137,2129,248,16,83,241,64,2184,2248,2249,2185,20,33,172,249,2049,728]

theorem envBound49507 : H12AffineFastState.Bounded env49507 := by
  intro p hp
  have h : env49507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49506_49507 : H12AffineEnvironment.transform 11 2064 env49506 = env49507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env49506 == env49507) = true)

theorem identity49507 : scanCanonicalize (H12AffineFastState.compose env49507 (packedSelected [2,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49507 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env49508 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,2064,41,2048,136,171,2065,2049,52,137,2049,168,16,3,161,16,2184,2200,2201,2185,20,33,172,169,2049,648]

theorem envBound49508 : H12AffineFastState.Bounded env49508 := by
  intro p hp
  have h : env49508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49507_49508 : H12AffineEnvironment.transform 5 16 env49507 = env49508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49507 == env49508) = true)

theorem identity49508 : scanCanonicalize (H12AffineFastState.compose env49508 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49508 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49509 : List Nat := [2,4,8,16,32,16,128,172,0,52,2048,2064,41,2048,136,171,2065,2049,52,137,2049,168,16,3,161,16,2184,2200,2201,2185,20,33,172,169,2049,136]

theorem envBound49509 : H12AffineFastState.Bounded env49509 := by
  intro p hp
  have h : env49509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49508_49509 : H12AffineEnvironment.transform 8 0 env49508 = env49509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49508 == env49509) = true)

theorem identity49509 : scanCanonicalize (H12AffineFastState.compose env49509 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49509 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env49510 : List Nat := [2,4,8,16,32,16,8,36,0,52,2048,2064,41,2048,0,35,2065,2049,52,1,2049,32,16,3,41,16,2048,2064,2065,2049,20,33,36,33,2049,0]

theorem envBound49510 : H12AffineFastState.Bounded env49510 := by
  intro p hp
  have h : env49510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49509_49510 : H12AffineEnvironment.transform 6 8 env49509 = env49510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49509 == env49510) = true)

theorem identity49510 : scanCanonicalize (H12AffineFastState.compose env49510 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound49510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49511 : List Nat := [2,4,8,16,32,16,8,36,0,52,16,0,41,16,0,35,1,17,52,1,17,32,16,3,41,16,16,0,1,17,20,33,36,33,17,0]

theorem envBound49511 : H12AffineFastState.Bounded env49511 := by
  intro p hp
  have h : env49511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49510_49511 : H12AffineEnvironment.transform 10 16 env49510 = env49511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env49510 == env49511) = true)

theorem identity49511 : scanCanonicalize (H12AffineFastState.compose env49511 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound49511 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49512 : List Nat := [2,4,8,16,31,16,8,27,0,11,16,0,22,16,0,28,1,17,11,1,17,31,16,3,22,16,16,0,1,17,20,30,27,30,17,0]

theorem envBound49512 : H12AffineFastState.Bounded env49512 := by
  intro p hp
  have h : env49512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49511_49512 : H12AffineEnvironment.transform 4 31 env49511 = env49512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env49511 == env49512) = true)

theorem identity49512 : scanCanonicalize (H12AffineFastState.compose env49512 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49513 : List Nat := [2,4,8,1,14,1,8,10,0,11,1,0,7,1,0,13,1,0,11,1,0,14,1,3,7,1,1,0,1,0,5,15,10,15,0,0]

theorem envBound49513 : H12AffineFastState.Bounded env49513 := by
  intro p hp
  have h : env49513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49512_49513 : H12AffineEnvironment.transform 3 1 env49512 = env49513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49512 == env49513) = true)

theorem identity49513 : scanCanonicalize (H12AffineFastState.compose env49513 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound49513 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49514 : List Nat := [2,4,6,1,0,1,6,4,0,5,1,0,7,1,0,3,1,0,5,1,0,0,1,3,7,1,1,0,1,0,5,1,4,1,0,0]

theorem envBound49514 : H12AffineFastState.Bounded env49514 := by
  intro p hp
  have h : env49514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49513_49514 : H12AffineEnvironment.transform 2 6 env49513 = env49514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env49513 == env49514) = true)

def env49515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4161,21792,41293,62678,8328,64,146629,46157,58460,149861,1500,33,256,21793,46212,63069]

theorem envBound49515 : H12AffineFastState.Bounded env49515 := by
  intro p hp
  have h : env49515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49499_49515 : H12AffineEnvironment.transform 17 10281 env49499 = env49515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49499 == env49515) = true)

def env49516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,5392,10281,1024,32769,4161,21792,41293,62678,8328,64,10709,46157,58460,23669,1500,33,256,21793,46212,63069]

theorem envBound49516 : H12AffineFastState.Bounded env49516 := by
  intro p hp
  have h : env49516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49515_49516 : H12AffineEnvironment.transform 16 5392 env49515 = env49516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env49515 == env49516) = true)

theorem identity49516 : scanCanonicalize (H12AffineFastState.compose env49516 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49516 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env49517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,5392,10281,1024,32769,4161,33,41293,41431,8328,64,10709,46157,45405,2420,1500,33,256,32,46212,41820]

theorem envBound49517 : H12AffineFastState.Bounded env49517 := by
  intro p hp
  have h : env49517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49516_49517 : H12AffineEnvironment.transform 13 5377 env49516 = env49517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49516 == env49517) = true)

theorem identity49517 : scanCanonicalize (H12AffineFastState.compose env49517 (packedSelected [5,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound49517 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env49518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8323,5392,10281,1024,8660,4161,33,152,2,8328,64,10709,5528,4232,2420,1500,33,256,32,5457,649]

theorem envBound49518 : H12AffineFastState.Bounded env49518 := by
  intro p hp
  have h : env49518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49517_49518 : H12AffineEnvironment.transform 14 8661 env49517 = env49518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env49517 == env49518) = true)

theorem identity49518 : scanCanonicalize (H12AffineFastState.compose env49518 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49518 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5377,80,262,5392,2476,1024,81,4161,33,152,2,269,64,2128,5528,4232,2420,1500,33,256,32,5457,649]

theorem envBound49519 : H12AffineFastState.Bounded env49519 := by
  intro p hp
  have h : env49519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49518_49519 : H12AffineEnvironment.transform 12 389 env49518 = env49519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49518 == env49519) = true)

theorem identity49519 : scanCanonicalize (H12AffineFastState.compose env49519 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49519 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,262,5392,2340,1024,81,4161,33,16,2,269,64,2128,5392,4096,2420,1364,33,256,32,5457,513]

theorem envBound49520 : H12AffineFastState.Bounded env49520 := by
  intro p hp
  have h : env49520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49519_49520 : H12AffineEnvironment.transform 6 8 env49519 = env49520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49519 == env49520) = true)

theorem identity49520 : scanCanonicalize (H12AffineFastState.compose env49520 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49520 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49521 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5237,80,114,5220,2128,1024,81,4161,33,16,2,121,64,2128,5220,4096,2048,1056,33,116,32,5157,513]

theorem envBound49521 : H12AffineFastState.Bounded env49521 := by
  intro p hp
  have h : env49521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49520_49521 : H12AffineEnvironment.transform 7 116 env49520 = env49521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49520 == env49521) = true)

theorem identity49521 : scanCanonicalize (H12AffineFastState.compose env49521 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49521 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env49522 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,34,5172,2048,1024,1,4113,33,16,2,41,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound49522 : H12AffineFastState.Bounded env49522 := by
  intro p hp
  have h : env49522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49521_49522 : H12AffineEnvironment.transform 5 16 env49521 = env49522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49521 == env49522) = true)

def env49523 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,0,34,1028,2048,1024,1,33,33,16,2,41,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound49523 : H12AffineFastState.Bounded env49523 := by
  intro p hp
  have h : env49523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49522_49523 : H12AffineEnvironment.transform 11 48 env49522 = env49523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49522 == env49523) = true)

theorem identity49523 : scanCanonicalize (H12AffineFastState.compose env49523 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound49523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49524 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,48,41,1045,0,34,1028,1076,1024,1,33,33,16,2,41,16,1076,1028,48,1076,1056,33,36,32,1045,513]

theorem envBound49524 : H12AffineFastState.Bounded env49524 := by
  intro p hp
  have h : env49524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49523_49524 : H12AffineEnvironment.transform 10 1076 env49523 = env49524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env49523 == env49524) = true)

def env49525 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,41,33,0,34,48,0,52,1,33,33,16,2,41,16,0,48,48,0,20,33,36,32,33,513]

theorem envBound49525 : H12AffineFastState.Bounded env49525 := by
  intro p hp
  have h : env49525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49524_49525 : H12AffineEnvironment.transform 9 52 env49524 = env49525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49524 == env49525) = true)

def env49526 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,48,41,32,0,34,49,1,53,1,33,33,16,2,41,16,1,49,48,1,21,33,36,32,32,513]

theorem envBound49526 : H12AffineFastState.Bounded env49526 := by
  intro p hp
  have h : env49526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49524_49526 : H12AffineEnvironment.transform 9 53 env49524 = env49526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49524 == env49526) = true)

theorem identity49526 : scanCanonicalize (H12AffineFastState.compose env49526 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49527 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,48,41,32,0,34,49,1,53,1,33,33,16,2,41,16,1,49,48,1,21,33,36,32,32,42]

theorem envBound49527 : H12AffineFastState.Bounded env49527 := by
  intro p hp
  have h : env49527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49526_49527 : H12AffineEnvironment.transform 8 43 env49526 = env49527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49526 == env49527) = true)

def leafEnv49527 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,48,41,32,0,34,49,1,53,1,33,33,16,2,21,41,1,16,1,49,48,1,21,33,36,32,4,34,32,42,1,33,0]

def active49527 : List Nat := [0,1,2,3,4]

def tree49527 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49527 : H12WitnessSearch.Good tree49527 := H12GlobalWitnessIndex.good

theorem leafIdentity49527 : H12AffineFastState.composeSystem env49527 rootObs = leafEnv49527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49527 rootObs == leafEnv49527) = true)

theorem terminalChecked49527 : H12PackedTerminal.terminalCheckFast leafEnv49527 active49527 tree49527 = true := by decide +kernel

def env49528 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,0,34,1029,2048,1024,1,32,33,16,2,41,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound49528 : H12AffineFastState.Bounded env49528 := by
  intro p hp
  have h : env49528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49522_49528 : H12AffineEnvironment.transform 11 49 env49522 = env49528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49522 == env49528) = true)

theorem identity49528 : scanCanonicalize (H12AffineFastState.compose env49528 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49528 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49529 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,49,41,1044,0,34,1029,1,1024,1,32,33,16,2,41,16,1,1029,49,1,1056,33,36,32,1044,513]

theorem envBound49529 : H12AffineFastState.Bounded env49529 := by
  intro p hp
  have h : env49529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49528_49529 : H12AffineEnvironment.transform 10 1 env49528 = env49529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49528 == env49529) = true)

def env49530 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,49,41,32,0,34,49,1,52,1,32,33,16,2,41,16,1,49,49,1,20,33,36,32,32,513]

theorem envBound49530 : H12AffineFastState.Bounded env49530 := by
  intro p hp
  have h : env49530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49529_49530 : H12AffineEnvironment.transform 9 52 env49529 = env49530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49529 == env49530) = true)

def env49531 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,41,33,0,34,48,1,53,1,32,33,16,2,41,16,1,48,49,1,21,33,36,32,33,513]

theorem envBound49531 : H12AffineFastState.Bounded env49531 := by
  intro p hp
  have h : env49531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49529_49531 : H12AffineEnvironment.transform 9 53 env49529 = env49531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49529 == env49531) = true)

theorem identity49531 : scanCanonicalize (H12AffineFastState.compose env49531 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49532 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,49,41,33,0,34,48,1,53,1,32,33,16,2,41,16,1,48,49,1,21,33,36,32,33,42]

theorem envBound49532 : H12AffineFastState.Bounded env49532 := by
  intro p hp
  have h : env49532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49531_49532 : H12AffineEnvironment.transform 8 43 env49531 = env49532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49531 == env49532) = true)

def leafEnv49532 : List Nat := [2,4,8,16,32,16,8,36,43,53,1,49,41,33,0,34,48,1,53,1,32,33,16,2,21,41,1,16,1,48,49,1,21,33,36,32,4,34,33,42,1,32,0]

def active49532 : List Nat := [0,1,2,3,4]

def tree49532 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49532 : H12WitnessSearch.Good tree49532 := H12GlobalWitnessIndex.good

theorem leafIdentity49532 : H12AffineFastState.composeSystem env49532 rootObs = leafEnv49532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49532 rootObs == leafEnv49532) = true)

theorem terminalChecked49532 : H12PackedTerminal.terminalCheckFast leafEnv49532 active49532 tree49532 = true := by decide +kernel

def env49533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,5393,10281,1024,32769,4161,21792,41293,62678,8328,64,10708,46157,58460,23668,1500,33,256,21793,46212,63069]

theorem envBound49533 : H12AffineFastState.Bounded env49533 := by
  intro p hp
  have h : env49533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49515_49533 : H12AffineEnvironment.transform 16 5393 env49515 = env49533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env49515 == env49533) = true)

theorem identity49533 : scanCanonicalize (H12AffineFastState.compose env49533 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound49533 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8203,5393,10281,1024,29789,4161,21792,21777,138,8328,64,10708,16401,4096,23668,1500,33,256,21793,16600,513]

theorem envBound49534 : H12AffineFastState.Bounded env49534 := by
  intro p hp
  have h : env49534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49533_49534 : H12AffineEnvironment.transform 14 29788 env49533 = env49534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env49533 == env49534) = true)

theorem identity49534 : scanCanonicalize (H12AffineFastState.compose env49534 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound49534 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env49535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,81,8203,5393,10281,1024,80,4161,8493,8476,138,8328,64,10708,13340,4096,10361,1500,33,256,8492,13525,513]

theorem envBound49535 : H12AffineFastState.Bounded env49535 := by
  intro p hp
  have h : env49535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49534_49535 : H12AffineEnvironment.transform 13 13325 env49534 = env49535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env49534 == env49535) = true)

theorem identity49535 : scanCanonicalize (H12AffineFastState.compose env49535 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound49535 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5513,81,399,5393,2477,1024,80,4161,169,152,138,268,64,2128,5528,4096,2557,1500,33,256,168,5457,513]

theorem envBound49536 : H12AffineFastState.Bounded env49536 := by
  intro p hp
  have h : env49536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49535_49536 : H12AffineEnvironment.transform 12 388 env49535 = env49536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env49535 == env49536) = true)

theorem identity49536 : scanCanonicalize (H12AffineFastState.compose env49536 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound49536 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3108,388,2477,81,399,2357,2477,1024,80,3173,169,152,138,268,64,2128,2492,3108,2557,1500,33,256,168,2421,513]

theorem envBound49537 : H12AffineFastState.Bounded env49537 := by
  intro p hp
  have h : env49537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49536_49537 : H12AffineEnvironment.transform 11 3108 env49536 = env49537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env49536 == env49537) = true)

theorem identity49537 : scanCanonicalize (H12AffineFastState.compose env49537 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49537 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env49538 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3108,348,2421,81,343,2357,2421,1024,80,3173,113,64,82,268,64,2128,2404,3108,2341,1284,33,256,112,2421,513]

theorem envBound49538 : H12AffineFastState.Bounded env49538 := by
  intro p hp
  have h : env49538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49537_49538 : H12AffineEnvironment.transform 6 88 env49537 = env49538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49537 == env49538) = true)

theorem identity49538 : scanCanonicalize (H12AffineFastState.compose env49538 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49538 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49539 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,268,2341,1,263,2357,2341,1024,0,3125,33,16,2,268,16,2048,2356,3108,2341,1284,33,256,32,2341,513]

theorem envBound49539 : H12AffineFastState.Bounded env49539 := by
  intro p hp
  have h : env49539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49538_49539 : H12AffineEnvironment.transform 5 16 env49538 = env49539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49538 == env49539) = true)

theorem identity49539 : scanCanonicalize (H12AffineFastState.compose env49539 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound49539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49540 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,293,268,1060,1,263,1076,1060,1024,0,308,33,16,2,268,16,1281,1077,293,1060,1284,33,256,32,1060,513]

theorem envBound49540 : H12AffineFastState.Bounded env49540 := by
  intro p hp
  have h : env49540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49539_49540 : H12AffineEnvironment.transform 10 1281 env49539 = env49540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env49539 == env49540) = true)

theorem identity49540 : scanCanonicalize (H12AffineFastState.compose env49540 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound49540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49541 : List Nat := [2,4,8,16,32,16,8,256,512,266,11,293,268,302,1,263,318,302,266,0,308,33,16,2,268,16,11,319,293,302,14,33,256,32,302,513]

theorem envBound49541 : H12AffineFastState.Bounded env49541 := by
  intro p hp
  have h : env49541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49540_49541 : H12AffineEnvironment.transform 9 266 env49540 = env49541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env49540 == env49541) = true)

theorem identity49541 : scanCanonicalize (H12AffineFastState.compose env49541 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound49541 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49542 : List Nat := [2,4,8,16,32,16,8,15,512,5,11,42,3,33,1,8,49,33,5,0,59,33,16,2,3,16,11,48,42,33,14,33,15,32,33,513]

theorem envBound49542 : H12AffineFastState.Bounded env49542 := by
  intro p hp
  have h : env49542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49541_49542 : H12AffineEnvironment.transform 7 15 env49541 = env49542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env49541 == env49542) = true)

def env49543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175169,8328,64,2609403,46156,77835,2598234,119178,2101345,256,2199862,2191507,63068]

theorem envBound49543 : H12AffineFastState.Bounded env49543 := by
  intro p hp
  have h : env49543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49466_49543 : H12AffineEnvironment.transform 23 2175169 env49466 = env49543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env49466 == env49543) = true)

def env49544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73857,8328,64,508091,46156,77835,505114,119178,33,256,98678,90323,63068]

theorem envBound49544 : H12AffineFastState.Bounded env49544 := by
  intro p hp
  have h : env49544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49543_49544 : H12AffineEnvironment.transform 20 4160 env49543 = env49544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49543 == env49544) = true)

theorem identity49544 : scanCanonicalize (H12AffineFastState.compose env49544 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49544 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,21793,21776,138,8328,64,450736,46156,4096,431377,61825,33,256,41341,16600,63068]

theorem envBound49545 : H12AffineFastState.Bounded env49545 := by
  intro p hp
  have h : env49545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49544_49545 : H12AffineEnvironment.transform 15 8203 env49544 = env49545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49544 == env49545) = true)

def env49546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32160,1024,32769,4160,21793,21776,138,8328,64,171280,46156,4096,190641,61825,33,256,41341,16600,63068]

theorem envBound49546 : H12AffineFastState.Bounded env49546 := by
  intro p hp
  have h : env49546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49545_49546 : H12AffineEnvironment.transform 17 32160 env49545 = env49546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env49545 == env49546) = true)

theorem identity49546 : scanCanonicalize (H12AffineFastState.compose env49546 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49546 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env49547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1024,32769,4160,21793,21776,3,8193,64,171280,46156,4096,190520,61704,33,256,41341,16465,63068]

theorem envBound49547 : H12AffineFastState.Bounded env49547 := by
  intro p hp
  have h : env49547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49546_49547 : H12AffineEnvironment.transform 6 9 env49546 = env49547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49546 == env49547) = true)

theorem identity49547 : scanCanonicalize (H12AffineFastState.compose env49547 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49547 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32041,1024,8540,4160,21793,21776,3,8193,64,146509,5393,4096,149861,20565,33,256,32,16465,22273]

theorem envBound49548 : H12AffineFastState.Bounded env49548 := by
  intro p hp
  have h : env49548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49547_49548 : H12AffineEnvironment.transform 14 8541 env49547 = env49548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49547 == env49548) = true)

theorem identity49548 : scanCanonicalize (H12AffineFastState.compose env49548 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7513) := by decide +kernel

theorem selectedBound49548 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7513,16384,7172,7506,131072,16496,1024,7173,4160,21793,21776,3,7512,64,131348,5393,4096,149861,20565,33,256,32,16465,22273]

theorem envBound49549 : H12AffineFastState.Bounded env49549 := by
  intro p hp
  have h : env49549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49548_49549 : H12AffineEnvironment.transform 12 7513 env49548 = env49549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7513 env49548 == env49549) = true)

theorem identity49549 : scanCanonicalize (H12AffineFastState.compose env49549 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 113) := by decide +kernel

theorem selectedBound49549 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env49550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7513,113,7172,7506,131072,1,1024,7173,4160,5456,5473,3,7512,64,131348,5393,4096,133396,4132,33,256,32,32,6000]

theorem envBound49550 : H12AffineFastState.Bounded env49550 := by
  intro p hp
  have h : env49550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49549_49550 : H12AffineEnvironment.transform 13 113 env49549 = env49550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 113 env49549 == env49550) = true)

theorem identity49550 : scanCanonicalize (H12AffineFastState.compose env49550 (packedSelected [1,4,6,8,9,10,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound49550 : packedSelected [1,4,6,8,9,10,15,16] rootPS < 2^1333 := by decide +kernel

def env49551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,3133,113,3424,3126,131072,1,1024,3425,292,1076,1029,3,3132,64,131348,1141,356,133396,320,33,256,32,32,1556]

theorem envBound49551 : H12AffineFastState.Bounded env49551 := by
  intro p hp
  have h : env49551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49550_49551 : H12AffineEnvironment.transform 11 356 env49550 = env49551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env49550 == env49551) = true)

theorem identity49551 : scanCanonicalize (H12AffineFastState.compose env49551 (packedSelected [0,1,2,7,8,10,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49551 : packedSelected [0,1,2,7,8,10,15,18] rootPS < 2^1333 := by decide +kernel

def env49552 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,356,2056,113,2389,2051,131072,1,53,2388,292,1,48,3,2057,64,131348,64,356,133396,320,33,256,32,32,545]

theorem envBound49552 : H12AffineFastState.Bounded env49552 := by
  intro p hp
  have h : env49552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49551_49552 : H12AffineEnvironment.transform 9 53 env49551 = env49552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49551 == env49552) = true)

theorem identity49552 : scanCanonicalize (H12AffineFastState.compose env49552 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 2096) := by decide +kernel

theorem selectedBound49552 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env49553 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,356,2056,113,2389,2051,2096,1,53,2388,292,1,48,3,2057,64,2340,64,356,292,320,33,256,32,32,545]

theorem envBound49553 : H12AffineFastState.Bounded env49553 := by
  intro p hp
  have h : env49553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49552_49553 : H12AffineEnvironment.transform 16 2096 env49552 = env49553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2096 env49552 == env49553) = true)

theorem identity49553 : scanCanonicalize (H12AffineFastState.compose env49553 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49553 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env49554 : List Nat := [2,4,8,16,17,64,9,256,512,4,2048,341,2056,64,2389,2051,2049,1,4,2388,277,1,1,3,2057,64,2325,64,341,277,320,16,256,17,17,528]

theorem envBound49554 : H12AffineFastState.Bounded env49554 := by
  intro p hp
  have h : env49554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49553_49554 : H12AffineEnvironment.transform 4 17 env49553 = env49554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49553 == env49554) = true)

theorem identity49554 : scanCanonicalize (H12AffineFastState.compose env49554 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound49554 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env49555 : List Nat := [2,4,8,16,17,64,9,256,512,4,80,341,88,64,261,83,81,1,4,260,277,1,1,3,89,64,325,64,341,277,320,16,256,17,17,528]

theorem envBound49555 : H12AffineFastState.Bounded env49555 := by
  intro p hp
  have h : env49555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49554_49555 : H12AffineEnvironment.transform 10 80 env49554 = env49555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env49554 == env49555) = true)

theorem identity49555 : scanCanonicalize (H12AffineFastState.compose env49555 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound49555 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49556 : List Nat := [2,4,8,16,17,64,9,256,65,4,80,341,88,64,261,83,81,1,4,260,277,1,1,3,89,64,325,64,341,277,320,16,256,17,17,81]

theorem envBound49556 : H12AffineFastState.Bounded env49556 := by
  intro p hp
  have h : env49556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49555_49556 : H12AffineEnvironment.transform 8 65 env49555 = env49556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env49555 == env49556) = true)

def env49557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32161,1024,32769,4160,21793,21776,138,8328,64,171281,46156,4096,190640,61825,33,256,41341,16600,63068]

theorem envBound49557 : H12AffineFastState.Bounded env49557 := by
  intro p hp
  have h : env49557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49545_49557 : H12AffineEnvironment.transform 17 32161 env49545 = env49557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env49545 == env49557) = true)

theorem identity49557 : scanCanonicalize (H12AffineFastState.compose env49557 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound49557 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env49558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,32161,1024,32769,4160,21793,21776,138,8328,64,23944,46156,4096,10281,61825,33,256,41341,16600,63068]

theorem envBound49558 : H12AffineFastState.Bounded env49558 := by
  intro p hp
  have h : env49558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49557_49558 : H12AffineEnvironment.transform 16 49305 env49557 = env49558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env49557 == env49558) = true)

def env49559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,32041,1024,32769,4160,21793,21776,2,8192,64,23808,46156,4096,10281,61705,33,256,41341,16464,63068]

theorem envBound49559 : H12AffineFastState.Bounded env49559 := by
  intro p hp
  have h : env49559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49558_49559 : H12AffineEnvironment.transform 6 8 env49558 = env49559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49558 == env49559) = true)

theorem identity49559 : scanCanonicalize (H12AffineFastState.compose env49559 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49559 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,38161,10281,1024,32769,4160,33,16,2,8192,64,2048,46156,4096,10281,41993,33,256,41341,5456,41820]

theorem envBound49560 : H12AffineFastState.Bounded env49560 := by
  intro p hp
  have h : env49560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49559_49560 : H12AffineEnvironment.transform 13 5376 env49559 = env49560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49559 == env49560) = true)

theorem identity49560 : scanCanonicalize (H12AffineFastState.compose env49560 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49560 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13388,10281,1024,8540,4160,33,16,2,8192,64,2048,5393,4096,10281,1364,33,256,32,5456,513]

theorem envBound49561 : H12AffineFastState.Bounded env49561 := by
  intro p hp
  have h : env49561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49560_49561 : H12AffineEnvironment.transform 14 8541 env49560 = env49561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49560 == env49561) = true)

theorem identity49561 : scanCanonicalize (H12AffineFastState.compose env49561 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49561 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49562 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8203,13340,10281,1024,8460,4112,33,16,2,8192,16,2048,5393,4096,10281,1284,33,256,32,5376,513]

theorem envBound49562 : H12AffineFastState.Bounded env49562 := by
  intro p hp
  have h : env49562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49561_49562 : H12AffineEnvironment.transform 5 16 env49561 = env49562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49561 == env49562) = true)

theorem identity49562 : scanCanonicalize (H12AffineFastState.compose env49562 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49562 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49563 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,262,5393,2340,1024,1,4112,33,16,2,269,16,2048,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound49563 : H12AffineFastState.Bounded env49563 := by
  intro p hp
  have h : env49563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49562_49563 : H12AffineEnvironment.transform 12 269 env49562 = env49563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49562 == env49563) = true)

theorem identity49563 : scanCanonicalize (H12AffineFastState.compose env49563 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49563 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49564 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4112,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound49564 : H12AffineFastState.Bounded env49564 := by
  intro p hp
  have h : env49564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49563_49564 : H12AffineEnvironment.transform 7 36 env49563 = env49564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49563 == env49564) = true)

def env49565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,32040,1024,32769,4160,21793,21776,3,8193,64,23809,46156,4096,10281,61704,33,256,41341,16465,63068]

theorem envBound49565 : H12AffineFastState.Bounded env49565 := by
  intro p hp
  have h : env49565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49558_49565 : H12AffineEnvironment.transform 6 9 env49558 = env49565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49558 == env49565) = true)

theorem identity49565 : scanCanonicalize (H12AffineFastState.compose env49565 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49565 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,13389,32040,1024,29788,4160,21793,21776,3,8193,64,23809,16401,4096,10281,1365,33,256,21792,16465,513]

theorem envBound49566 : H12AffineFastState.Bounded env49566 := by
  intro p hp
  have h : env49566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49565_49566 : H12AffineEnvironment.transform 14 29789 env49565 = env49566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49565 == env49566) = true)

theorem identity49566 : scanCanonicalize (H12AffineFastState.compose env49566 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound49566 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21540,114,5172,23889,1024,21541,4160,21793,21776,3,120,64,23809,16401,4096,2128,1365,33,256,21792,16465,513]

theorem envBound49567 : H12AffineFastState.Bounded env49567 := by
  intro p hp
  have h : env49567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49566_49567 : H12AffineEnvironment.transform 12 121 env49566 = env49567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env49566 == env49567) = true)

def env49568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73856,8328,64,508090,46156,77835,505115,119178,32,256,98679,90322,63068]

theorem envBound49568 : H12AffineFastState.Bounded env49568 := by
  intro p hp
  have h : env49568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49543_49568 : H12AffineEnvironment.transform 20 4161 env49543 = env49568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49543 == env49568) = true)

theorem identity49568 : scanCanonicalize (H12AffineFastState.compose env49568 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound49568 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30082,131072,262144,1024,32769,4161,21792,152,21762,8328,64,439608,46156,17801,442521,41992,32,256,62709,5456,63068]

theorem envBound49569 : H12AffineFastState.Bounded env49569 := by
  intro p hp
  have h : env49569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49568_49569 : H12AffineEnvironment.transform 15 30082 env49568 = env49569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env49568 == env49569) = true)

def env49570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,4161,21792,16,21762,8192,64,439608,46156,17665,442385,41992,32,256,62589,5456,63068]

theorem envBound49570 : H12AffineFastState.Bounded env49570 := by
  intro p hp
  have h : env49570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49569_49570 : H12AffineEnvironment.transform 6 8 env49569 = env49570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49569 == env49570) = true)

theorem identity49570 : scanCanonicalize (H12AffineFastState.compose env49570 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49570 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,4161,21792,16,21762,8192,64,409957,16401,17665,406604,20565,32,256,32,5456,513]

theorem envBound49571 : H12AffineFastState.Bounded env49571 := by
  intro p hp
  have h : env49571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49570_49571 : H12AffineEnvironment.transform 14 29789 env49570 = env49571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49570 == env49571) = true)

theorem identity49571 : scanCanonicalize (H12AffineFastState.compose env49571 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound49571 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env49572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,131072,23669,1024,29788,4161,21792,16,21762,8192,64,138512,16401,17665,157753,20565,32,256,32,5456,513]

theorem envBound49572 : H12AffineFastState.Bounded env49572 := by
  intro p hp
  have h : env49572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49571_49572 : H12AffineEnvironment.transform 17 23669 env49571 = env49572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env49571 == env49572) = true)

theorem identity49572 : scanCanonicalize (H12AffineFastState.compose env49572 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49572 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env49573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,343,131072,10280,1024,1,4161,8573,16,8543,8192,64,138512,13388,12636,138340,9224,32,256,32,5456,513]

theorem envBound49573 : H12AffineFastState.Bounded env49573 := by
  intro p hp
  have h : env49573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49572_49573 : H12AffineEnvironment.transform 13 13405 env49572 = env49573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49572 == env49573) = true)

theorem identity49573 : scanCanonicalize (H12AffineFastState.compose env49573 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1133) := by decide +kernel

theorem selectedBound49573 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1133,4144,0,343,131072,3141,1024,1,4161,1296,16,1330,1133,64,138512,4129,5425,138340,101,32,256,32,5456,513]

theorem envBound49574 : H12AffineFastState.Bounded env49574 := by
  intro p hp
  have h : env49574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49573_49574 : H12AffineEnvironment.transform 12 1133 env49573 = env49574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1133 env49573 == env49574) = true)

theorem identity49574 : scanCanonicalize (H12AffineFastState.compose env49574 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 6177) := by decide +kernel

theorem selectedBound49574 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env49575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1133,4144,0,343,6177,3141,1024,1,4161,1296,16,1330,1133,64,1329,4129,5425,1093,101,32,256,32,5456,513]

theorem envBound49575 : H12AffineFastState.Bounded env49575 := by
  intro p hp
  have h : env49575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49574_49575 : H12AffineEnvironment.transform 16 6177 env49574 = env49575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6177 env49574 == env49575) = true)

theorem identity49575 : scanCanonicalize (H12AffineFastState.compose env49575 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound49575 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1133,1377,0,343,3440,3141,1024,1,1296,1296,16,1330,1133,64,1329,1392,96,1093,101,32,256,32,1,513]

theorem envBound49576 : H12AffineFastState.Bounded env49576 := by
  intro p hp
  have h : env49576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49575_49576 : H12AffineEnvironment.transform 11 1361 env49575 = env49576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env49575 == env49576) = true)

theorem identity49576 : scanCanonicalize (H12AffineFastState.compose env49576 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49576 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1361,1133,1377,0,343,1393,1092,1024,1,1296,1296,16,1330,1133,64,1329,1392,96,1093,101,32,256,32,1,513]

theorem envBound49577 : H12AffineFastState.Bounded env49577 := by
  intro p hp
  have h : env49577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49576_49577 : H12AffineEnvironment.transform 10 1 env49576 = env49577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49576 == env49577) = true)

theorem identity49577 : scanCanonicalize (H12AffineFastState.compose env49577 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound49577 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env49578 : List Nat := [2,4,8,16,32,64,8,256,512,816,1,609,861,593,0,343,577,884,816,1,544,544,16,514,861,64,513,576,96,885,101,32,256,32,1,513]

theorem envBound49578 : H12AffineFastState.Bounded env49578 := by
  intro p hp
  have h : env49578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49577_49578 : H12AffineEnvironment.transform 9 816 env49577 = env49578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env49577 == env49578) = true)

theorem identity49578 : scanCanonicalize (H12AffineFastState.compose env49578 (packedSelected [0,3,5,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound49578 : packedSelected [0,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env49579 : List Nat := [2,4,8,16,32,64,8,256,32,272,1,65,381,113,0,343,97,340,272,1,0,0,16,34,381,64,33,96,96,341,101,32,256,32,1,33]

theorem envBound49579 : H12AffineFastState.Bounded env49579 := by
  intro p hp
  have h : env49579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49578_49579 : H12AffineEnvironment.transform 8 32 env49578 = env49579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env49578 == env49579) = true)

theorem identity49579 : scanCanonicalize (H12AffineFastState.compose env49579 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49579 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49580 : List Nat := [2,4,8,16,32,64,8,116,32,100,1,65,9,113,0,35,97,32,100,1,0,0,16,34,9,64,33,96,96,33,101,32,116,32,1,33]

theorem envBound49580 : H12AffineFastState.Bounded env49580 := by
  intro p hp
  have h : env49580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49579_49580 : H12AffineEnvironment.transform 7 116 env49579 = env49580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49579 == env49580) = true)

theorem identity49580 : scanCanonicalize (H12AffineFastState.compose env49580 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound49580 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49581 : List Nat := [2,4,8,16,32,49,8,5,32,21,1,48,9,0,0,35,16,32,21,1,0,0,16,34,9,49,33,17,17,33,20,32,5,32,1,33]

theorem envBound49581 : H12AffineFastState.Bounded env49581 := by
  intro p hp
  have h : env49581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49580_49581 : H12AffineEnvironment.transform 5 49 env49580 = env49581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env49580 == env49581) = true)

theorem identity49581 : scanCanonicalize (H12AffineFastState.compose env49581 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49582 : List Nat := [2,4,8,1,32,32,8,5,32,4,1,33,9,0,0,35,1,32,4,1,0,0,1,34,9,32,33,0,0,33,5,32,5,32,1,33]

theorem envBound49582 : H12AffineFastState.Bounded env49582 := by
  intro p hp
  have h : env49582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49581_49582 : H12AffineEnvironment.transform 3 1 env49581 = env49582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49581 == env49582) = true)

def env49583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,4161,21792,17,21762,8193,64,439608,46156,17664,442384,41992,32,256,62588,5456,63068]

theorem envBound49583 : H12AffineFastState.Bounded env49583 := by
  intro p hp
  have h : env49583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49569_49583 : H12AffineEnvironment.transform 6 9 env49569 = env49583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49569 == env49583) = true)

theorem identity49583 : scanCanonicalize (H12AffineFastState.compose env49583 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound49583 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,35189,1024,32769,4161,21792,17,21762,8193,64,146509,46156,17664,149861,41992,32,256,62588,5456,63068]

theorem envBound49584 : H12AffineFastState.Bounded env49584 := by
  intro p hp
  have h : env49584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49583_49584 : H12AffineEnvironment.transform 17 35189 env49583 = env49584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env49583 == env49584) = true)

theorem identity49584 : scanCanonicalize (H12AffineFastState.compose env49584 (packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound49584 : packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env49585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,29963,131072,32120,1024,29708,4161,21792,17,21762,8193,64,146509,16449,17664,149861,20485,32,256,113,5456,593]

theorem envBound49585 : H12AffineFastState.Bounded env49585 := by
  intro p hp
  have h : env49585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49584_49585 : H12AffineEnvironment.transform 14 29709 env49584 = env49585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env49584 == env49585) = true)

theorem identity49585 : scanCanonicalize (H12AffineFastState.compose env49585 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound49585 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8283,131072,10280,1024,8540,4161,112,17,82,8193,64,146509,5393,4176,138293,1365,32,256,113,5456,593]

theorem envBound49586 : H12AffineFastState.Bounded env49586 := by
  intro p hp
  have h : env49586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49585_49586 : H12AffineEnvironment.transform 13 5456 env49585 = env49586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env49585 == env49586) = true)

theorem identity49586 : scanCanonicalize (H12AffineFastState.compose env49586 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 4129) := by decide +kernel

theorem selectedBound49586 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env49587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8283,4129,10280,1024,8540,4161,112,17,82,8193,64,11372,5393,4176,3092,1365,32,256,113,5456,593]

theorem envBound49587 : H12AffineFastState.Bounded env49587 := by
  intro p hp
  have h : env49587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49586_49587 : H12AffineEnvironment.transform 16 4129 env49586 = env49587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4129 env49586 == env49587) = true)

theorem identity49587 : scanCanonicalize (H12AffineFastState.compose env49587 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound49587 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env49588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5456,293,35,4129,2128,1024,292,4161,112,17,82,121,64,3092,5393,4176,3092,1365,32,256,113,5456,593]

theorem envBound49588 : H12AffineFastState.Bounded env49588 := by
  intro p hp
  have h : env49588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49587_49588 : H12AffineEnvironment.transform 12 120 env49587 = env49588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env49587 == env49588) = true)

theorem identity49588 : scanCanonicalize (H12AffineFastState.compose env49588 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49588 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49589 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,120,5205,32,35,4129,2128,1024,33,4161,112,17,82,121,64,3092,5140,4176,3092,1104,32,5,113,5205,593]

theorem envBound49589 : H12AffineFastState.Bounded env49589 := by
  intro p hp
  have h : env49589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49588_49589 : H12AffineEnvironment.transform 7 5 env49588 = env49589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49588 == env49589) = true)

theorem identity49589 : scanCanonicalize (H12AffineFastState.compose env49589 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound49589 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49590 : List Nat := [2,4,8,16,32,64,9,5,512,69,2048,4096,120,4112,32,35,4129,2128,69,33,4161,112,17,82,121,64,2129,4177,4176,2129,21,32,5,113,4112,593]

theorem envBound49590 : H12AffineFastState.Bounded env49590 := by
  intro p hp
  have h : env49590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49589_49590 : H12AffineEnvironment.transform 9 69 env49589 = env49590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env49589 == env49590) = true)

theorem identity49590 : scanCanonicalize (H12AffineFastState.compose env49590 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound49590 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49591 : List Nat := [2,4,8,16,32,49,9,5,512,52,2048,4096,9,4112,32,35,4129,2081,52,33,4144,1,17,35,8,49,2080,4128,4129,2080,21,32,5,0,4112,544]

theorem envBound49591 : H12AffineFastState.Bounded env49591 := by
  intro p hp
  have h : env49591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49590_49591 : H12AffineEnvironment.transform 5 49 env49590 = env49591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env49590 == env49591) = true)

theorem identity49591 : scanCanonicalize (H12AffineFastState.compose env49591 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound49591 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49592 : List Nat := [2,4,8,16,32,49,9,5,512,52,49,4096,9,4112,32,35,4129,16,52,33,4144,1,17,35,8,49,17,4128,4129,17,21,32,5,0,4112,544]

theorem envBound49592 : H12AffineFastState.Bounded env49592 := by
  intro p hp
  have h : env49592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49591_49592 : H12AffineEnvironment.transform 10 49 env49591 = env49592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env49591 == env49592) = true)

theorem identity49592 : scanCanonicalize (H12AffineFastState.compose env49592 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound49592 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env49593 : List Nat := [2,4,8,16,32,49,9,5,512,52,49,545,9,561,32,35,512,16,52,33,529,1,17,35,8,49,17,513,512,17,21,32,5,0,561,544]

theorem envBound49593 : H12AffineFastState.Bounded env49593 := by
  intro p hp
  have h : env49593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49592_49593 : H12AffineEnvironment.transform 11 545 env49592 = env49593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env49592 == env49593) = true)

theorem identity49593 : scanCanonicalize (H12AffineFastState.compose env49593 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49593 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env49594 : List Nat := [2,4,8,16,1,16,9,5,512,21,16,512,9,528,1,2,512,16,21,0,529,1,17,2,8,16,17,513,512,17,21,1,5,0,528,513]

theorem envBound49594 : H12AffineFastState.Bounded env49594 := by
  intro p hp
  have h : env49594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49593_49594 : H12AffineEnvironment.transform 4 1 env49593 = env49594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49593 == env49594) = true)

theorem identity49594 : scanCanonicalize (H12AffineFastState.compose env49594 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49595 : List Nat := [2,0,8,16,1,16,9,1,512,17,16,512,9,528,1,2,512,16,17,0,529,1,17,2,8,16,17,513,512,17,17,1,1,0,528,513]

theorem envBound49595 : H12AffineFastState.Bounded env49595 := by
  intro p hp
  have h : env49595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49594_49595 : H12AffineEnvironment.transform 1 0 env49594 = env49595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49594 == env49595) = true)

theorem identity49595 : scanCanonicalize (H12AffineFastState.compose env49595 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound49595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49596 : List Nat := [2,0,8,3,1,3,9,1,512,2,3,512,9,515,1,2,512,3,2,0,514,1,2,2,8,3,2,513,512,2,2,1,1,0,515,513]

theorem envBound49596 : H12AffineFastState.Bounded env49596 := by
  intro p hp
  have h : env49596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49595_49596 : H12AffineEnvironment.transform 3 3 env49595 = env49596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env49595 == env49596) = true)

theorem identity49596 : scanCanonicalize (H12AffineFastState.compose env49596 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound49596 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49597 : List Nat := [2,0,8,3,1,3,9,1,8,2,3,8,9,11,1,2,8,3,2,0,10,1,2,2,8,3,2,9,8,2,2,1,1,0,11,9]

theorem envBound49597 : H12AffineFastState.Bounded env49597 := by
  intro p hp
  have h : env49597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49596_49597 : H12AffineEnvironment.transform 8 8 env49596 = env49597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env49596 == env49597) = true)

theorem identity49597 : scanCanonicalize (H12AffineFastState.compose env49597 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49597 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env49598 : List Nat := [2,0,1,3,1,3,0,1,1,2,3,1,0,2,1,2,1,3,2,0,3,1,2,2,1,3,2,0,1,2,2,1,1,0,2,0]

theorem envBound49598 : H12AffineFastState.Bounded env49598 := by
  intro p hp
  have h : env49598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49597_49598 : H12AffineEnvironment.transform 2 1 env49597 = env49598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49597 == env49598) = true)

def env49599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound49599 : H12AffineFastState.Bounded env49599 := by
  intro p hp
  have h : env49599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49354_49599 : H12AffineEnvironment.transform 18 1025 env49354 = env49599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env49354 == env49599) = true)

theorem identity49599 : scanCanonicalize (H12AffineFastState.compose env49599 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262491) := by decide +kernel

theorem selectedBound49599 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262491,8328,64,15025626,196951,10507600,8830976,10682827,4448282,257,8601974,8626386,10626588]

theorem envBound49600 : H12AffineFastState.Bounded env49600 := by
  intro p hp
  have h : env49600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49599_49600 : H12AffineEnvironment.transform 23 2262491 env49599 = env49600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262491 env49599 == env49600) = true)

def env49601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025626,115151,10507600,8650904,10600787,4268162,257,8487406,8478794,10544772]

theorem envBound49601 : H12AffineFastState.Bounded env49601 := by
  intro p hp
  have h : env49601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49600_49601 : H12AffineEnvironment.transform 16 49304 env49600 = env49601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env49600 == env49601) = true)

def env49602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543882,115151,17664,2363592,119043,4268162,257,2199998,2191386,63188]

theorem envBound49602 : H12AffineFastState.Bounded env49602 := by
  intro p hp
  have h : env49602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49601_49602 : H12AffineEnvironment.transform 22 2101328 env49601 = env49602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env49601 == env49602) = true)

def env49603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97546,115151,17664,2363592,119043,329730,257,2199998,2191386,63188]

theorem envBound49603 : H12AffineFastState.Bounded env49603 := by
  intro p hp
  have h : env49603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49602_49603 : H12AffineEnvironment.transform 21 272512 env49602 = env49603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49602 == env49603) = true)

theorem identity49603 : scanCanonicalize (H12AffineFastState.compose env49603 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound49603 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58516,272512,62660,41431,8328,64,97546,115151,17664,324700,119043,329730,257,95530,103566,63188]

theorem envBound49604 : H12AffineFastState.Bounded env49604 := by
  intro p hp
  have h : env49604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49603_49604 : H12AffineEnvironment.transform 20 58516 env49603 = env49604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env49603 == env49604) = true)

def env49605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58516,272512,62612,41351,8328,16,97546,115103,17664,324620,119043,329730,257,95530,103566,63108]

theorem envBound49605 : H12AffineFastState.Bounded env49605 := by
  intro p hp
  have h : env49605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49604_49605 : H12AffineEnvironment.transform 5 16 env49604 = env49605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49604 == env49605) = true)

theorem identity49605 : scanCanonicalize (H12AffineFastState.compose env49605 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49605 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env49606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,65536,49304,262144,1025,32769,50584,264588,54680,32907,388,16,89094,115103,17664,316672,119043,329730,257,87078,103566,55176]

theorem envBound49606 : H12AffineFastState.Bounded env49606 := by
  intro p hp
  have h : env49606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49605_49606 : H12AffineEnvironment.transform 12 268 env49605 = env49606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49605 == env49606) = true)

theorem identity49606 : scanCanonicalize (H12AffineFastState.compose env49606 (packedSelected [4,7,9,10,16,17,19,20,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 122283) := by decide +kernel

theorem selectedBound49606 : packedSelected [4,7,9,10,16,17,19,20,26,27,31] rootPS < 2^1333 := by decide +kernel

def env49607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,65536,49304,122283,1025,32769,50584,119847,54680,32907,388,16,89094,115103,17664,67755,119043,54697,257,87078,103566,55176]

theorem envBound49607 : H12AffineFastState.Bounded env49607 := by
  intro p hp
  have h : env49607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49606_49607 : H12AffineEnvironment.transform 17 122283 env49606 = env49607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122283 env49606 == env49607) = true)

theorem identity49607 : scanCanonicalize (H12AffineFastState.compose env49607 (packedSelected [0,4,7,16,17,19,20,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound49607 : packedSelected [0,4,7,16,17,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env49608 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,21647,49304,35108,1025,32769,50584,32936,54680,32907,388,16,2185,38160,17664,23588,34188,54697,257,169,49153,55176]

theorem envBound49608 : H12AffineFastState.Bounded env49608 := by
  intro p hp
  have h : env49608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49607_49608 : H12AffineEnvironment.transform 15 21647 env49607 = env49608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env49607 == env49608) = true)

theorem identity49608 : scanCanonicalize (H12AffineFastState.compose env49608 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound49608 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env49609 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21897,21647,5393,23725,1025,21896,4113,21793,17,21762,388,16,2185,16537,17664,23588,20485,32,257,169,5512,513]

theorem envBound49609 : H12AffineFastState.Bounded env49609 := by
  intro p hp
  have h : env49609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49608_49609 : H12AffineEnvironment.transform 14 21897 env49608 = env49609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env49608 == env49609) = true)

def env49610 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58516,272512,62613,41350,8328,17,97546,115102,17664,324621,119043,329730,257,95530,103566,63109]

theorem envBound49610 : H12AffineFastState.Bounded env49610 := by
  intro p hp
  have h : env49610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49604_49610 : H12AffineEnvironment.transform 5 17 env49604 = env49610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49604 == env49610) = true)

theorem identity49610 : scanCanonicalize (H12AffineFastState.compose env49610 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound49610 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env49611 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,65536,46109,262144,1025,32769,36881,272512,32784,41350,8328,17,67983,111899,12677,295048,107910,329730,257,65967,103566,33280]

theorem envBound49611 : H12AffineFastState.Bounded env49611 := by
  intro p hp
  have h : env49611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49610_49611 : H12AffineEnvironment.transform 13 13445 env49610 = env49611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env49610 == env49611) = true)

theorem identity49611 : scanCanonicalize (H12AffineFastState.compose env49611 (packedSelected [0,3,4,7,16,17,20,22,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound49611 : packedSelected [0,3,4,7,16,17,20,22,24,26,31] rootPS < 2^1333 := by decide +kernel

def env49612 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8580,65536,5529,262144,1025,8581,12693,272512,8596,2,8328,17,67983,70815,12677,270604,66562,329730,257,65967,79114,9092]

theorem envBound49612 : H12AffineFastState.Bounded env49612 := by
  intro p hp
  have h : env49612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49611_49612 : H12AffineEnvironment.transform 14 8580 env49611 = env49612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env49611 == env49612) = true)

theorem identity49612 : scanCanonicalize (H12AffineFastState.compose env49612 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound49612 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env49613 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8580,65536,5529,67754,1025,8581,12693,73770,8596,2,8328,17,67983,70815,12677,76198,66562,168,257,65967,79114,9092]

theorem envBound49613 : H12AffineFastState.Bounded env49613 := by
  intro p hp
  have h : env49613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49612_49613 : H12AffineEnvironment.transform 17 67754 env49612 = env49613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env49612 == env49613) = true)

theorem identity49613 : scanCanonicalize (H12AffineFastState.compose env49613 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49613 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env49614 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8461,65536,5392,67619,1025,8460,12572,73770,8477,2,8193,17,67846,70678,12556,76079,66562,33,257,65830,79114,8973]

theorem envBound49614 : H12AffineFastState.Bounded env49614 := by
  intro p hp
  have h : env49614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49613_49614 : H12AffineEnvironment.transform 6 9 env49613 = env49614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49613 == env49614) = true)

theorem identity49614 : scanCanonicalize (H12AffineFastState.compose env49614 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound49614 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49615 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8461,262,5392,2341,1025,8460,12572,8492,8477,2,8193,17,2048,5392,12556,10281,1284,33,257,32,13324,8973]

theorem envBound49615 : H12AffineFastState.Bounded env49615 := by
  intro p hp
  have h : env49615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49614_49615 : H12AffineEnvironment.transform 15 262 env49614 = env49615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env49614 == env49615) = true)

theorem identity49615 : scanCanonicalize (H12AffineFastState.compose env49615 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49615 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49616 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,8192,13324,8461,262,5392,2308,1025,8460,12572,8461,8477,2,8193,17,2048,5392,12556,10248,1284,0,257,1,13324,8973]

theorem envBound49616 : H12AffineFastState.Bounded env49616 := by
  intro p hp
  have h : env49616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49615_49616 : H12AffineEnvironment.transform 4 1 env49615 = env49616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49615 == env49616) = true)

def env49617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97547,115151,17664,2363592,119043,329731,257,2199998,2191386,63188]

theorem envBound49617 : H12AffineFastState.Bounded env49617 := by
  intro p hp
  have h : env49617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49602_49617 : H12AffineEnvironment.transform 21 272513 env49602 = env49617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49602 == env49617) = true)

theorem identity49617 : scanCanonicalize (H12AffineFastState.compose env49617 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49617 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,262144,1025,29908,2097152,272513,2101328,2114883,8328,64,97547,79130,17664,2363592,75222,329731,257,2188651,2191386,513]

theorem envBound49618 : H12AffineFastState.Bounded env49618 := by
  intro p hp
  have h : env49618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49617_49618 : H12AffineEnvironment.transform 14 29909 env49617 = env49618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49617 == env49618) = true)

def env49619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,32240,1025,29908,2097152,21873,2101328,2114883,8328,64,97547,79130,17664,2125112,75222,95731,257,2188651,2191386,513]

theorem envBound49619 : H12AffineFastState.Bounded env49619 := by
  intro p hp
  have h : env49619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49618_49619 : H12AffineEnvironment.transform 17 32240 env49618 = env49619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env49618 == env49619) = true)

theorem identity49619 : scanCanonicalize (H12AffineFastState.compose env49619 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49619 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env49620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32121,1025,29789,2097152,21873,2101328,2114883,8193,64,97547,79130,17664,2125112,75103,95610,257,2188651,2191386,513]

theorem envBound49620 : H12AffineFastState.Bounded env49620 := by
  intro p hp
  have h : env49620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49619_49620 : H12AffineEnvironment.transform 6 9 env49619 = env49620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49619 == env49620) = true)

theorem identity49620 : scanCanonicalize (H12AffineFastState.compose env49620 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 12573) := by decide +kernel

theorem selectedBound49620 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env49621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32121,1025,29789,12573,21873,8525,29790,8193,64,97547,79130,17664,23589,75103,95610,257,87158,82183,513]

theorem envBound49621 : H12AffineFastState.Bounded env49621 := by
  intro p hp
  have h : env49621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49620_49621 : H12AffineEnvironment.transform 20 12573 env49620 = env49621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12573 env49620 == env49621) = true)

theorem identity49621 : scanCanonicalize (H12AffineFastState.compose env49621 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound49621 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8283,13389,32121,1025,29789,12573,21873,8525,29790,8193,64,23888,5441,17664,23589,1284,21793,257,29741,24924,513]

theorem envBound49622 : H12AffineFastState.Bounded env49622 := by
  intro p hp
  have h : env49622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49621_49622 : H12AffineEnvironment.transform 15 8283 env49621 = env49622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env49621 == env49622) = true)

theorem identity49622 : scanCanonicalize (H12AffineFastState.compose env49622 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound49622 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8283,13389,2421,1025,81,12573,8573,8525,82,8193,64,10588,5441,12556,10281,1284,8493,257,33,5456,513]

theorem envBound49623 : H12AffineFastState.Bounded env49623 := by
  intro p hp
  have h : env49623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49622_49623 : H12AffineEnvironment.transform 13 13324 env49622 = env49623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env49622 == env49623) = true)

theorem identity49623 : scanCanonicalize (H12AffineFastState.compose env49623 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49623 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env49624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,80,263,5393,2421,1025,81,4161,33,17,82,349,64,2048,5441,4176,2421,1284,113,257,33,5456,513]

theorem envBound49624 : H12AffineFastState.Bounded env49624 := by
  intro p hp
  have h : env49624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49623_49624 : H12AffineEnvironment.transform 12 348 env49623 = env49624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49623 == env49624) = true)

theorem identity49624 : scanCanonicalize (H12AffineFastState.compose env49624 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49624 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49625 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1025,0,4112,33,17,3,268,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound49625 : H12AffineFastState.Bounded env49625 := by
  intro p hp
  have h : env49625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49624_49625 : H12AffineEnvironment.transform 5 17 env49624 = env49625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49624 == env49625) = true)

theorem identity49625 : scanCanonicalize (H12AffineFastState.compose env49625 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49625 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49626 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1077,269,308,1,263,292,2340,1025,0,1061,33,17,3,268,17,2048,293,1076,2340,1284,32,257,33,308,513]

theorem envBound49626 : H12AffineFastState.Bounded env49626 := by
  intro p hp
  have h : env49626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49625_49626 : H12AffineEnvironment.transform 11 1077 env49625 = env49626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env49625 == env49626) = true)

theorem identity49626 : scanCanonicalize (H12AffineFastState.compose env49626 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49626 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49627 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1077,269,308,1,263,292,2340,1025,0,1061,33,17,3,268,17,2048,293,1076,2340,1284,32,257,33,308,0]

theorem envBound49627 : H12AffineFastState.Bounded env49627 := by
  intro p hp
  have h : env49627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49626_49627 : H12AffineEnvironment.transform 8 1 env49626 = env49627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49626 == env49627) = true)

theorem identity49627 : scanCanonicalize (H12AffineFastState.compose env49627 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49627 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49628 : List Nat := [2,4,8,16,32,17,9,37,1,1024,2048,1077,40,17,1,34,1,2049,1025,0,1061,33,17,3,41,17,2048,0,1076,2049,1057,32,36,33,17,0]

theorem envBound49628 : H12AffineFastState.Bounded env49628 := by
  intro p hp
  have h : env49628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49627_49628 : H12AffineEnvironment.transform 7 37 env49627 = env49628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49627 == env49628) = true)

def env49629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,32241,1025,29908,2097152,21872,2101328,2114883,8328,64,97547,79130,17664,2125113,75222,95730,257,2188651,2191386,513]

theorem envBound49629 : H12AffineFastState.Bounded env49629 := by
  intro p hp
  have h : env49629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49618_49629 : H12AffineEnvironment.transform 17 32241 env49618 = env49629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env49618 == env49629) = true)

def env49630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32121,1025,29788,2097152,21872,2101328,2114883,8192,64,97547,79130,17664,2125113,75102,95610,257,2188651,2191386,513]

theorem envBound49630 : H12AffineFastState.Bounded env49630 := by
  intro p hp
  have h : env49630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49629_49630 : H12AffineEnvironment.transform 6 8 env49629 = env49630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49629 == env49630) = true)

theorem identity49630 : scanCanonicalize (H12AffineFastState.compose env49630 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound49630 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32121,1025,29788,12392,21872,8248,29995,8192,64,97547,79130,17664,23889,75102,95610,257,87299,82034,513]

theorem envBound49631 : H12AffineFastState.Bounded env49631 := by
  intro p hp
  have h : env49631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49630_49631 : H12AffineEnvironment.transform 20 12392 env49630 = env49631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env49630 == env49631) = true)

theorem identity49631 : scanCanonicalize (H12AffineFastState.compose env49631 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound49631 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env49632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,20759,13389,32121,1025,29788,12392,21872,8248,29995,8192,64,11292,25613,17664,23889,29769,9325,257,1044,4453,513]

theorem envBound49632 : H12AffineFastState.Bounded env49632 := by
  intro p hp
  have h : env49632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49631_49632 : H12AffineEnvironment.transform 15 20759 env49631 = env49632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env49631 == env49632) = true)

theorem identity49632 : scanCanonicalize (H12AffineFastState.compose env49632 (packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49632 : packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS < 2^1333 := by decide +kernel

def env49633 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,16384,28957,20759,12557,30777,321,28956,12392,20528,8248,28779,8192,64,10588,24909,16448,22545,28937,8493,257,340,4453,513]

theorem envBound49633 : H12AffineFastState.Bounded env49633 := by
  intro p hp
  have h : env49633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49632_49633 : H12AffineEnvironment.transform 9 320 env49632 = env49633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49632 == env49633) = true)

theorem identity49633 : scanCanonicalize (H12AffineFastState.compose env49633 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound49633 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env49634 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,4160,8541,343,12557,10361,321,8540,12392,112,8248,8235,8192,64,10588,12557,4096,2129,8521,8493,257,340,4453,513]

theorem envBound49634 : H12AffineFastState.Bounded env49634 := by
  intro p hp
  have h : env49634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49633_49634 : H12AffineEnvironment.transform 13 4160 env49633 = env49634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env49633 == env49634) = true)

def env49635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32120,1025,29789,2097152,21872,2101328,2114883,8193,64,97547,79130,17664,2125113,75103,95611,257,2188651,2191386,513]

theorem envBound49635 : H12AffineFastState.Bounded env49635 := by
  intro p hp
  have h : env49635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49629_49635 : H12AffineEnvironment.transform 6 9 env49629 = env49635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49629 == env49635) = true)

theorem identity49635 : scanCanonicalize (H12AffineFastState.compose env49635 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound49635 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32120,1025,29789,77851,21872,73803,95576,8193,64,97547,79130,17664,89378,75103,95611,257,21872,16385,513]

theorem envBound49636 : H12AffineFastState.Bounded env49636 := by
  intro p hp
  have h : env49636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49635_49636 : H12AffineEnvironment.transform 20 77851 env49635 = env49636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env49635 == env49636) = true)

theorem identity49636 : scanCanonicalize (H12AffineFastState.compose env49636 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound49636 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env49637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,13389,32120,1025,29789,12620,21872,8476,29711,8193,64,31836,13389,17664,23669,9224,29740,257,21872,16385,513]

theorem envBound49637 : H12AffineFastState.Bounded env49637 := by
  intro p hp
  have h : env49637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49636_49637 : H12AffineEnvironment.transform 15 343 env49636 = env49637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env49636 == env49637) = true)

theorem identity49637 : scanCanonicalize (H12AffineFastState.compose env49637 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49637 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,5392,23589,1025,21760,4113,21872,65,21842,348,64,23809,5392,17664,23669,1365,21873,257,21872,16385,513]

theorem envBound49638 : H12AffineFastState.Bounded env49638 := by
  intro p hp
  have h : env49638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49637_49638 : H12AffineEnvironment.transform 12 349 env49637 = env49638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49637 == env49638) = true)

theorem identity49638 : scanCanonicalize (H12AffineFastState.compose env49638 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound49638 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,80,343,5392,2420,1025,81,4113,33,65,3,348,64,2128,5392,4177,2340,1365,32,257,33,5456,513]

theorem envBound49639 : H12AffineFastState.Bounded env49639 := by
  intro p hp
  have h : env49639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49638_49639 : H12AffineEnvironment.transform 13 5457 env49638 = env49639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env49638 == env49639) = true)

theorem identity49639 : scanCanonicalize (H12AffineFastState.compose env49639 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49639 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49640 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5236,80,114,5173,2129,1025,81,4113,33,65,3,121,64,2128,5173,4177,2049,1136,32,36,33,5237,513]

theorem envBound49640 : H12AffineFastState.Bounded env49640 := by
  intro p hp
  have h : env49640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49639_49640 : H12AffineEnvironment.transform 7 37 env49639 = env49640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49639 == env49640) = true)

def env49641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543883,115151,17665,2363593,119042,4268162,257,2199999,2191387,63189]

theorem envBound49641 : H12AffineFastState.Bounded env49641 := by
  intro p hp
  have h : env49641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49601_49641 : H12AffineEnvironment.transform 22 2101329 env49601 = env49641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env49601 == env49641) = true)

def env49642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97547,115151,17665,2363593,119042,329730,257,2199999,2191387,63189]

theorem envBound49642 : H12AffineFastState.Bounded env49642 := by
  intro p hp
  have h : env49642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49641_49642 : H12AffineEnvironment.transform 21 272512 env49641 = env49642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49641 == env49642) = true)

theorem identity49642 : scanCanonicalize (H12AffineFastState.compose env49642 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound49642 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4160,272512,17,21763,8328,64,97547,115151,17665,262281,119042,329730,257,98815,90203,63189]

theorem envBound49643 : H12AffineFastState.Bounded env49643 := by
  intro p hp
  have h : env49643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49642_49643 : H12AffineEnvironment.transform 20 4160 env49642 = env49643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49642 == env49643) = true)

def env49644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21763,8192,64,97547,115015,17665,262145,119042,329730,257,98679,90203,63069]

theorem envBound49644 : H12AffineFastState.Bounded env49644 := by
  intro p hp
  have h : env49644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49643_49644 : H12AffineEnvironment.transform 6 8 env49643 = env49644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49643 == env49644) = true)

theorem identity49644 : scanCanonicalize (H12AffineFastState.compose env49644 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound49644 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,4160,41340,17,21763,8192,64,97547,115015,17665,35189,119042,98678,257,98679,90203,63069]

theorem envBound49645 : H12AffineFastState.Bounded env49645 := by
  intro p hp
  have h : env49645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49644_49645 : H12AffineEnvironment.transform 17 35188 env49644 = env49645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env49644 == env49645) = true)

theorem identity49645 : scanCanonicalize (H12AffineFastState.compose env49645 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound49645 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env49646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8494,49168,35188,1025,32769,4160,41340,17,21763,8192,64,23589,57449,17665,35189,61484,41048,257,41049,16757,63069]

theorem envBound49646 : H12AffineFastState.Bounded env49646 := by
  intro p hp
  have h : env49646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49645_49646 : H12AffineEnvironment.transform 15 8494 env49645 = env49646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env49645 == env49646) = true)

theorem identity49646 : scanCanonicalize (H12AffineFastState.compose env49646 (packedSelected [0,1,2,5,6,7,10,11,12,15,16,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49646 : packedSelected [0,1,2,5,6,7,10,11,12,15,16,23,24,28] rootPS < 2^1333 := by decide +kernel

def env49647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8494,46157,35188,1025,32769,4160,41340,17,8542,8192,64,10360,37940,12636,35189,33905,41048,257,41049,13608,33280]

theorem envBound49647 : H12AffineFastState.Bounded env49647 := by
  intro p hp
  have h : env49647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49646_49647 : H12AffineEnvironment.transform 13 13405 env49646 = env49647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49646 == env49647) = true)

theorem identity49647 : scanCanonicalize (H12AffineFastState.compose env49647 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound49647 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env49648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5156,32768,343,37940,35188,1025,32769,4160,33029,17,295,121,64,2049,37940,4389,35189,33905,32801,257,32800,5457,33280]

theorem envBound49648 : H12AffineFastState.Bounded env49648 := by
  intro p hp
  have h : env49648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49647_49648 : H12AffineEnvironment.transform 12 121 env49647 = env49648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env49647 == env49648) = true)

def env49649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21763,8193,64,97547,115014,17665,262144,119042,329730,257,98678,90203,63068]

theorem envBound49649 : H12AffineFastState.Bounded env49649 := by
  intro p hp
  have h : env49649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49643_49649 : H12AffineEnvironment.transform 6 9 env49643 = env49649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49643 == env49649) = true)

theorem identity49649 : scanCanonicalize (H12AffineFastState.compose env49649 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49649 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,32,17,21763,8193,64,97547,115014,17665,10281,119042,73771,257,98678,90203,63068]

theorem envBound49650 : H12AffineFastState.Bounded env49650 := by
  intro p hp
  have h : env49650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49649_49650 : H12AffineEnvironment.transform 17 10281 env49649 = env49650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49649 == env49650) = true)

theorem identity49650 : scanCanonicalize (H12AffineFastState.compose env49650 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49650 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env49651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10281,1025,32769,4160,32,17,3,8193,64,75787,103494,4097,10281,99330,73771,257,98678,79195,41820]

theorem envBound49651 : H12AffineFastState.Bounded env49651 := by
  intro p hp
  have h : env49651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49650_49651 : H12AffineEnvironment.transform 13 5376 env49650 = env49651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49650 == env49651) = true)

theorem identity49651 : scanCanonicalize (H12AffineFastState.compose env49651 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49651 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env49652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,38161,2421,1025,32769,4160,32,17,3,349,64,67927,103494,4097,2421,99330,65911,257,98678,70663,33280]

theorem envBound49652 : H12AffineFastState.Bounded env49652 := by
  intro p hp
  have h : env49652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49651_49652 : H12AffineEnvironment.transform 12 348 env49651 = env49652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49651 == env49652) = true)

theorem identity49652 : scanCanonicalize (H12AffineFastState.compose env49652 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound49652 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,342,38161,2421,1025,32769,4160,32,17,3,349,64,2049,38160,4097,2421,34132,33,257,32800,5457,33280]

theorem envBound49653 : H12AffineFastState.Bounded env49653 := by
  intro p hp
  have h : env49653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49652_49653 : H12AffineEnvironment.transform 15 342 env49652 = env49653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env49652 == env49653) = true)

theorem identity49653 : scanCanonicalize (H12AffineFastState.compose env49653 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 2389) := by decide +kernel

theorem selectedBound49653 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env49654 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2389,348,3157,32768,342,35908,2421,1025,32769,2325,32,17,3,349,64,2049,35909,2388,2421,34132,33,257,32800,3076,33280]

theorem envBound49654 : H12AffineFastState.Bounded env49654 := by
  intro p hp
  have h : env49654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49653_49654 : H12AffineEnvironment.transform 11 2389 env49653 = env49654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2389 env49653 == env49654) = true)

theorem identity49654 : scanCanonicalize (H12AffineFastState.compose env49654 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

end H12CloudChart1