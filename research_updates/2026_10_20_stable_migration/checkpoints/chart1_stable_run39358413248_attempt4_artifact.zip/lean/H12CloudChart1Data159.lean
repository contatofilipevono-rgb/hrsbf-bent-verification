import H12CloudChart1Data158

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity40319 : scanCanonicalize (H12AffineFastState.compose env40319 (packedSelected [12,15,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound40319 : packedSelected [12,15,38,41] rootPS < 2^1333 := by decide +kernel

def env40320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,32768,8202,12637,3173,1025,32769,4161,32800,8525,32770,8193,64,36112,13389,5392,44345,1365,9324,257,9325,46092,513]

theorem envBound40320 : H12AffineFastState.Bounded env40320 := by
  intro p hp
  have h : env40320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40319_40320 : H12AffineEnvironment.transform 17 3173 env40319 = env40320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env40319 == env40320) = true)

def env40321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,326921,8524,32906,8328,64,64724,13388,25692,303452,1500,272393,257,21792,46213,513]

theorem envBound40321 : H12AffineFastState.Bounded env40321 := by
  intro p hp
  have h : env40321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40315_40321 : H12AffineEnvironment.transform 16 16401 env40315 = env40321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40315 == env40321) = true)

theorem identity40321 : scanCanonicalize (H12AffineFastState.compose env40321 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40321 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16401,262144,1025,32769,4161,318548,17,32906,469,64,56713,5393,17665,294913,1500,264532,257,21792,38360,513]

theorem envBound40322 : H12AffineFastState.Bounded env40322 := by
  intro p hp
  have h : env40322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40321_40322 : H12AffineEnvironment.transform 12 349 env40321 = env40322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40321 == env40322) = true)

theorem identity40322 : scanCanonicalize (H12AffineFastState.compose env40322 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound40322 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16401,56572,1025,32769,4161,168,17,32906,469,64,56713,5393,17665,23805,1500,54696,257,21792,38360,513]

theorem envBound40323 : H12AffineFastState.Bounded env40323 := by
  intro p hp
  have h : env40323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40322_40323 : H12AffineEnvironment.transform 17 56572 env40322 = env40323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env40322 == env40323) = true)

theorem identity40323 : scanCanonicalize (H12AffineFastState.compose env40323 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40323 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env40324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,16401,56436,1025,32769,4161,32,17,32770,349,64,56577,5393,17665,23669,1364,54560,257,21792,38224,513]

theorem envBound40324 : H12AffineFastState.Bounded env40324 := by
  intro p hp
  have h : env40324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40323_40324 : H12AffineEnvironment.transform 6 8 env40323 = env40324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40323 == env40324) = true)

theorem identity40324 : scanCanonicalize (H12AffineFastState.compose env40324 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound40324 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16401,2420,1025,21761,4161,32,17,21762,349,64,2049,5393,17665,23669,1364,32,257,21792,16464,513]

theorem envBound40325 : H12AffineFastState.Bounded env40325 := by
  intro p hp
  have h : env40325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40324_40325 : H12AffineEnvironment.transform 14 21760 env40324 = env40325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env40324 == env40325) = true)

theorem identity40325 : scanCanonicalize (H12AffineFastState.compose env40325 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound40325 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,81,343,5440,2420,1025,80,4161,32,17,83,349,64,2049,5393,4176,2340,1364,32,257,113,5377,513]

theorem envBound40326 : H12AffineFastState.Bounded env40326 := by
  intro p hp
  have h : env40326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40325_40326 : H12AffineEnvironment.transform 13 5457 env40325 = env40326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env40325 == env40326) = true)

theorem identity40326 : scanCanonicalize (H12AffineFastState.compose env40326 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1339) := by decide +kernel

theorem selectedBound40326 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env40327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1339,349,106,81,343,123,2420,1025,80,1402,32,17,83,349,64,2049,42,1387,2340,1364,32,257,113,58,513]

theorem envBound40327 : H12AffineFastState.Bounded env40327 := by
  intro p hp
  have h : env40327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40326_40327 : H12AffineEnvironment.transform 11 1339 env40326 = env40327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1339 env40326 == env40327) = true)

theorem identity40327 : scanCanonicalize (H12AffineFastState.compose env40327 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound40327 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env40328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,270,1339,349,106,81,343,123,122,1025,80,1402,32,17,83,349,64,271,42,1387,42,1364,32,257,113,58,513]

theorem envBound40328 : H12AffineFastState.Bounded env40328 := by
  intro p hp
  have h : env40328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40327_40328 : H12AffineEnvironment.transform 10 270 env40327 = env40328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env40327 == env40328) = true)

theorem identity40328 : scanCanonicalize (H12AffineFastState.compose env40328 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound40328 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env40329 : List Nat := [2,4,8,16,32,64,8,256,512,116,270,335,349,106,81,343,123,122,117,80,270,32,17,83,349,64,271,42,287,42,288,32,257,113,58,513]

theorem envBound40329 : H12AffineFastState.Bounded env40329 := by
  intro p hp
  have h : env40329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40328_40329 : H12AffineEnvironment.transform 9 116 env40328 = env40329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env40328 == env40329) = true)

theorem identity40329 : scanCanonicalize (H12AffineFastState.compose env40329 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound40329 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40330 : List Nat := [2,4,8,16,32,64,8,110,512,116,96,33,51,106,81,57,123,122,117,80,96,32,17,83,51,64,97,42,113,42,78,32,111,113,58,513]

theorem envBound40330 : H12AffineFastState.Bounded env40330 := by
  intro p hp
  have h : env40330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40329_40330 : H12AffineEnvironment.transform 7 110 env40329 = env40330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env40329 == env40330) = true)

theorem identity40330 : scanCanonicalize (H12AffineFastState.compose env40330 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40330 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env40331 : List Nat := [2,4,8,16,32,17,8,63,512,37,49,33,51,59,0,57,42,43,36,1,49,32,17,2,51,17,48,42,32,42,31,32,62,32,58,513]

theorem envBound40331 : H12AffineFastState.Bounded env40331 := by
  intro p hp
  have h : env40331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40330_40331 : H12AffineEnvironment.transform 5 17 env40330 = env40331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40330 == env40331) = true)

theorem identity40331 : scanCanonicalize (H12AffineFastState.compose env40331 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40332 : List Nat := [2,4,8,11,32,10,8,36,512,37,42,33,40,32,0,34,42,43,36,1,42,32,10,2,40,10,43,42,32,42,4,32,37,32,33,513]

theorem envBound40332 : H12AffineFastState.Bounded env40332 := by
  intro p hp
  have h : env40332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40331_40332 : H12AffineEnvironment.transform 3 11 env40331 = env40332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40331 == env40332) = true)

theorem identity40332 : scanCanonicalize (H12AffineFastState.compose env40332 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound40332 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40333 : List Nat := [2,4,8,11,4,10,8,0,512,1,14,5,12,4,0,6,14,15,0,1,14,4,10,2,12,10,15,14,4,14,4,4,1,4,5,513]

theorem envBound40333 : H12AffineFastState.Bounded env40333 := by
  intro p hp
  have h : env40333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40332_40333 : H12AffineEnvironment.transform 4 4 env40332 = env40333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env40332 == env40333) = true)

theorem identity40333 : scanCanonicalize (H12AffineFastState.compose env40333 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40333 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40334 : List Nat := [2,1,8,11,1,10,8,0,512,1,11,0,9,1,0,3,11,10,0,1,11,1,10,2,9,10,10,11,1,11,1,1,1,1,0,513]

theorem envBound40334 : H12AffineFastState.Bounded env40334 := by
  intro p hp
  have h : env40334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40333_40334 : H12AffineEnvironment.transform 1 1 env40333 = env40334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40333 == env40334) = true)

def env40335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257180,254097,8328,64,2157716,2253852,140365,2404637,2102685,2373705,257,21792,46213,2175562]

theorem envBound40335 : H12AffineFastState.Bounded env40335 := by
  intro p hp
  have h : env40335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40286_40335 : H12AffineEnvironment.transform 21 441625 env40286 = env40335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env40286 == env40335) = true)

def env40336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,254097,8328,64,64724,160860,140365,303453,1501,272393,257,21792,46213,74250]

theorem envBound40336 : H12AffineFastState.Bounded env40336 := by
  intro p hp
  have h : env40336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40335_40336 : H12AffineEnvironment.transform 20 4160 env40335 = env40336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40335 == env40336) = true)

theorem identity40336 : scanCanonicalize (H12AffineFastState.compose env40336 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound40336 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,441625,155996,144463,8328,64,64724,160860,140365,303453,1501,272393,257,21792,46213,63188]

theorem envBound40337 : H12AffineFastState.Bounded env40337 := by
  intro p hp
  have h : env40337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40336_40337 : H12AffineEnvironment.transform 15 54494 env40336 = env40337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env40336 == env40337) = true)

def env40338 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4112,441625,155916,144415,8328,16,64644,160780,140317,303373,1421,272393,257,21792,46213,63108]

theorem envBound40338 : H12AffineFastState.Bounded env40338 := by
  intro p hp
  have h : env40338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40337_40338 : H12AffineEnvironment.transform 5 16 env40337 = env40338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40337 == env40338) = true)

theorem identity40338 : scanCanonicalize (H12AffineFastState.compose env40338 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound40338 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env40339 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,171060,1025,32769,4112,8493,155916,144415,8328,16,64644,160780,140317,146745,1421,177213,257,21792,46213,63108]

theorem envBound40339 : H12AffineFastState.Bounded env40339 := by
  intro p hp
  have h : env40339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40338_40339 : H12AffineEnvironment.transform 17 171060 env40338 = env40339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env40338 == env40339) = true)

theorem identity40339 : scanCanonicalize (H12AffineFastState.compose env40339 (packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound40339 : packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env40340 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,13461,43169,1025,32769,4112,8493,21913,138,8328,16,64644,16537,4232,2476,1421,32936,257,21792,46213,63108]

theorem envBound40340 : H12AffineFastState.Bounded env40340 := by
  intro p hp
  have h : env40340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40339_40340 : H12AffineEnvironment.transform 16 13461 env40339 = env40340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env40339 == env40340) = true)

theorem identity40340 : scanCanonicalize (H12AffineFastState.compose env40340 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40340 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env40341 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,13341,43049,1025,32769,4112,8493,21777,2,8192,16,64524,16401,4096,2340,1285,32800,257,21792,46093,62988]

theorem envBound40341 : H12AffineFastState.Bounded env40341 := by
  intro p hp
  have h : env40341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40340_40341 : H12AffineEnvironment.transform 6 8 env40340 = env40341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40340 == env40341) = true)

theorem identity40341 : scanCanonicalize (H12AffineFastState.compose env40341 (packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40341 : packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env40342 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33031,13341,43049,1025,32769,4112,8493,16,2,8192,16,43277,5392,4096,2340,1285,32800,257,33,46093,41741]

theorem envBound40342 : H12AffineFastState.Bounded env40342 := by
  intro p hp
  have h : env40342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40341_40342 : H12AffineEnvironment.transform 13 5377 env40341 = env40342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40341 == env40342) = true)

def env40343 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4113,441625,155917,144414,8328,17,64645,160781,140316,303372,1420,272393,257,21792,46213,63109]

theorem envBound40343 : H12AffineFastState.Bounded env40343 := by
  intro p hp
  have h : env40343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40337_40343 : H12AffineEnvironment.transform 5 17 env40337 = env40343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40337 == env40343) = true)

theorem identity40343 : scanCanonicalize (H12AffineFastState.compose env40343 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 157872) := by decide +kernel

theorem selectedBound40343 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env40344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,157872,1025,32769,4113,54697,155917,144414,8328,17,64645,160781,140316,182716,1420,147641,257,21792,46213,63109]

theorem envBound40344 : H12AffineFastState.Bounded env40344 := by
  intro p hp
  have h : env40344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40343_40344 : H12AffineEnvironment.transform 17 157872 env40343 = env40344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env40343 == env40344) = true)

theorem identity40344 : scanCanonicalize (H12AffineFastState.compose env40344 (packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound40344 : packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40345 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,5528,32040,1025,32769,4113,54697,29845,8582,8328,17,64645,24981,12676,56356,1420,21793,257,21792,46213,63109]

theorem envBound40345 : H12AffineFastState.Bounded env40345 := by
  intro p hp
  have h : env40345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40344_40345 : H12AffineEnvironment.transform 16 5528 env40344 = env40345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env40344 == env40345) = true)

theorem identity40345 : scanCanonicalize (H12AffineFastState.compose env40345 (packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound40345 : packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40346 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,40970,5528,2477,1025,32769,4113,41260,16,8582,8328,17,34816,5392,12676,43169,1420,8612,257,8613,46213,33280]

theorem envBound40346 : H12AffineFastState.Bounded env40346 := by
  intro p hp
  have h : env40346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40345_40346 : H12AffineEnvironment.transform 13 13445 env40345 = env40346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env40345 == env40346) = true)

theorem identity40346 : scanCanonicalize (H12AffineFastState.compose env40346 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound40346 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40347 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,32768,33166,5528,2477,1025,32769,4113,32936,16,2,268,17,34816,5392,4096,35109,1420,32,257,33,38145,33280]

theorem envBound40347 : H12AffineFastState.Bounded env40347 := by
  intro p hp
  have h : env40347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40346_40347 : H12AffineEnvironment.transform 12 388 env40346 = env40347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env40346 == env40347) = true)

theorem identity40347 : scanCanonicalize (H12AffineFastState.compose env40347 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound40347 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,137,263,5528,2477,1025,136,4113,33,16,2,268,17,2185,5392,4096,2476,1420,32,257,33,5512,649]

theorem envBound40348 : H12AffineFastState.Bounded env40348 := by
  intro p hp
  have h : env40348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40347_40348 : H12AffineEnvironment.transform 14 137 env40347 = env40348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env40347 == env40348) = true)

theorem identity40348 : scanCanonicalize (H12AffineFastState.compose env40348 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40348 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env40349 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,160,5157,137,35,5308,2185,1025,136,4113,33,16,2,40,17,2185,5172,4096,2184,1192,32,37,33,5292,649]

theorem envBound40349 : H12AffineFastState.Bounded env40349 := by
  intro p hp
  have h : env40349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40348_40349 : H12AffineEnvironment.transform 7 36 env40348 = env40349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40348 == env40349) = true)

theorem identity40349 : scanCanonicalize (H12AffineFastState.compose env40349 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40349 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env40350 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,1,35,5172,2049,1025,0,4113,33,16,2,40,17,2049,5172,4096,2048,1056,32,37,33,5156,513]

theorem envBound40350 : H12AffineFastState.Bounded env40350 := by
  intro p hp
  have h : env40350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40349_40350 : H12AffineEnvironment.transform 6 8 env40349 = env40350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40349 == env40350) = true)

theorem identity40350 : scanCanonicalize (H12AffineFastState.compose env40350 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40351 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,40,4112,1,35,4097,2049,52,0,4113,33,16,2,40,17,2049,4097,4096,2048,21,32,37,33,4113,513]

theorem envBound40351 : H12AffineFastState.Bounded env40351 := by
  intro p hp
  have h : env40351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40350_40351 : H12AffineEnvironment.transform 9 53 env40350 = env40351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40350 == env40351) = true)

theorem identity40351 : scanCanonicalize (H12AffineFastState.compose env40351 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound40351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40352 : List Nat := [2,4,8,16,32,17,8,36,512,53,48,4096,40,4112,1,35,4097,49,52,0,4113,33,16,2,40,17,49,4097,4096,48,21,32,37,33,4113,513]

theorem envBound40352 : H12AffineFastState.Bounded env40352 := by
  intro p hp
  have h : env40352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40351_40352 : H12AffineEnvironment.transform 10 48 env40351 = env40352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env40351 == env40352) = true)

theorem identity40352 : scanCanonicalize (H12AffineFastState.compose env40352 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound40352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40353 : List Nat := [2,4,8,16,32,17,8,36,512,53,48,528,40,512,1,35,529,49,52,0,513,33,16,2,40,17,49,529,528,48,21,32,37,33,513,513]

theorem envBound40353 : H12AffineFastState.Bounded env40353 := by
  intro p hp
  have h : env40353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40352_40353 : H12AffineEnvironment.transform 11 528 env40352 = env40353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env40352 == env40353) = true)

theorem identity40353 : scanCanonicalize (H12AffineFastState.compose env40353 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound40353 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40354 : List Nat := [2,4,8,16,32,17,8,36,49,53,48,33,40,49,1,35,32,49,52,0,48,33,16,2,40,17,49,32,33,48,21,32,37,33,48,48]

theorem envBound40354 : H12AffineFastState.Bounded env40354 := by
  intro p hp
  have h : env40354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40353_40354 : H12AffineEnvironment.transform 8 49 env40353 = env40354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40353 == env40354) = true)

def env40355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,254097,8328,64,64725,160861,140365,303452,1500,272392,257,21792,46213,74251]

theorem envBound40355 : H12AffineFastState.Bounded env40355 := by
  intro p hp
  have h : env40355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40335_40355 : H12AffineEnvironment.transform 20 4161 env40335 = env40355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40335 == env40355) = true)

theorem identity40355 : scanCanonicalize (H12AffineFastState.compose env40355 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound40355 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4161,392287,73755,41431,8328,64,64725,79131,91403,303452,1500,272392,257,21792,46213,74251]

theorem envBound40356 : H12AffineFastState.Bounded env40356 := by
  intro p hp
  have h : env40356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40355_40356 : H12AffineEnvironment.transform 16 82246 env40355 = env40356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env40355 == env40356) = true)

def env40357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10400,1025,32769,4161,120063,73755,41431,8328,64,64725,79131,91403,35324,1500,168,257,21792,46213,74251]

theorem envBound40357 : H12AffineFastState.Bounded env40357 := by
  intro p hp
  have h : env40357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40356_40357 : H12AffineEnvironment.transform 17 10400 env40356 = env40357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env40356 == env40357) = true)

theorem identity40357 : scanCanonicalize (H12AffineFastState.compose env40357 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21757) := by decide +kernel

theorem selectedBound40357 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env40358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21757,65536,82246,10400,1025,21756,4161,65538,73755,29994,8328,64,10280,79131,91403,23809,1500,168,257,21792,24696,74251]

theorem envBound40358 : H12AffineFastState.Bounded env40358 := by
  intro p hp
  have h : env40358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40357_40358 : H12AffineEnvironment.transform 14 21757 env40357 = env40358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21757 env40357 == env40358) = true)

theorem identity40358 : scanCanonicalize (H12AffineFastState.compose env40358 (packedSelected [0,1,4,5,7,10,12,15,17,18,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound40358 : packedSelected [0,1,4,5,7,10,12,15,17,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env40359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21757,263,16449,10400,1025,21756,4161,261,8476,29994,8328,64,10280,13340,25612,23809,1500,168,257,21792,24696,8972]

theorem envBound40359 : H12AffineFastState.Bounded env40359 := by
  intro p hp
  have h : env40359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40358_40359 : H12AffineEnvironment.transform 15 263 env40358 = env40359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env40358 == env40359) = true)

theorem identity40359 : scanCanonicalize (H12AffineFastState.compose env40359 (packedSelected [0,2,3,6,7,10,11,17,18,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40359 : packedSelected [0,2,3,6,7,10,11,17,18,20,24,26] rootPS < 2^1333 := by decide +kernel

def env40360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21757,263,16449,2477,1025,21756,4161,261,17,21543,389,64,2341,5393,17665,23809,1500,168,257,21792,16757,513]

theorem envBound40360 : H12AffineFastState.Bounded env40360 := by
  intro p hp
  have h : env40360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40359_40360 : H12AffineEnvironment.transform 12 269 env40359 = env40360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40359 == env40360) = true)

theorem identity40360 : scanCanonicalize (H12AffineFastState.compose env40360 (packedSelected [4,9,10,11,15,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound40360 : packedSelected [4,9,10,11,15,17,19] rootPS < 2^1333 := by decide +kernel

def env40361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3244,269,16384,18513,263,16449,2477,1025,18512,3309,261,17,18571,389,64,2341,2493,17665,16813,1500,168,257,18828,16757,513]

theorem envBound40361 : H12AffineFastState.Bounded env40361 := by
  intro p hp
  have h : env40361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40360_40361 : H12AffineEnvironment.transform 11 3244 env40360 = env40361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env40360 == env40361) = true)

theorem identity40361 : scanCanonicalize (H12AffineFastState.compose env40361 (packedSelected [0,1,4,7,8,9,10,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound40361 : packedSelected [0,1,4,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env40362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1296,444,269,16384,17729,263,16449,1213,1025,17728,509,261,17,17819,389,64,1077,1197,17665,16813,1500,168,257,17564,16757,513]

theorem envBound40362 : H12AffineFastState.Bounded env40362 := by
  intro p hp
  have h : env40362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40361_40362 : H12AffineEnvironment.transform 10 1296 env40361 = env40362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env40361 == env40362) = true)

theorem identity40362 : scanCanonicalize (H12AffineFastState.compose env40362 (packedSelected [0,2,4,6,7,9,12,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound40362 : packedSelected [0,2,4,6,7,9,12,14,17] rootPS < 2^1333 := by decide +kernel

def env40363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1296,444,269,1297,80,263,1360,1213,1025,81,509,261,17,138,389,64,1077,1197,16,1212,1500,168,257,397,1124,513]

theorem envBound40363 : H12AffineFastState.Bounded env40363 := by
  intro p hp
  have h : env40363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40362_40363 : H12AffineEnvironment.transform 13 1297 env40362 = env40363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40362 == env40363) = true)

theorem identity40363 : scanCanonicalize (H12AffineFastState.compose env40363 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound40363 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40364 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1213,17,160,1212,80,170,1277,1213,1025,81,80,168,17,138,40,64,1077,1197,16,1212,1137,168,172,32,1124,513]

theorem envBound40364 : H12AffineFastState.Bounded env40364 := by
  intro p hp
  have h : env40364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40363_40364 : H12AffineEnvironment.transform 7 173 env40363 = env40364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env40363 == env40364) = true)

theorem identity40364 : scanCanonicalize (H12AffineFastState.compose env40364 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound40364 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40365 : List Nat := [2,4,8,16,32,64,88,117,512,1024,1125,17,120,1124,80,114,1061,1125,1025,81,80,112,17,82,40,64,1077,1141,16,1124,1137,112,116,32,1124,513]

theorem envBound40365 : H12AffineFastState.Bounded env40365 := by
  intro p hp
  have h : env40365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40364_40365 : H12AffineEnvironment.transform 6 88 env40364 = env40365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env40364 == env40365) = true)

theorem identity40365 : scanCanonicalize (H12AffineFastState.compose env40365 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40365 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40366 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1076,17,41,1077,1,35,1061,1076,1025,0,1,33,17,3,40,17,1077,1060,16,1077,1056,33,37,32,1077,513]

theorem envBound40366 : H12AffineFastState.Bounded env40366 := by
  intro p hp
  have h : env40366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40365_40366 : H12AffineEnvironment.transform 5 17 env40365 = env40366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40365 == env40366) = true)

def env40367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10401,1025,32769,4161,120062,73755,41431,8328,64,64725,79131,91403,35325,1500,169,257,21792,46213,74251]

theorem envBound40367 : H12AffineFastState.Bounded env40367 := by
  intro p hp
  have h : env40367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40356_40367 : H12AffineEnvironment.transform 17 10401 env40356 = env40367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env40356 == env40367) = true)

theorem identity40367 : scanCanonicalize (H12AffineFastState.compose env40367 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40367 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env40368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,82246,2557,1025,32769,4161,120062,65863,32907,468,64,56713,70727,83031,35325,1500,169,257,21792,38361,66391]

theorem envBound40368 : H12AffineFastState.Bounded env40368 := by
  intro p hp
  have h : env40368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40367_40368 : H12AffineEnvironment.transform 12 348 env40367 = env40368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40367 == env40368) = true)

theorem identity40368 : scanCanonicalize (H12AffineFastState.compose env40368 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound40368 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env40369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,342,16400,2557,1025,32769,4161,54696,17,32907,468,64,56713,5393,17665,35325,1500,169,257,21792,38361,513]

theorem envBound40369 : H12AffineFastState.Bounded env40369 := by
  intro p hp
  have h : env40369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40368_40369 : H12AffineEnvironment.transform 15 342 env40368 = env40369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env40368 == env40369) = true)

theorem identity40369 : scanCanonicalize (H12AffineFastState.compose env40369 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound40369 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env40370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,32768,342,5528,2557,1025,32769,4161,32800,17,32907,468,64,34817,5393,4233,35325,1500,169,257,168,38361,513]

theorem envBound40370 : H12AffineFastState.Bounded env40370 := by
  intro p hp
  have h : env40370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40369_40370 : H12AffineEnvironment.transform 13 5512 env40369 = env40370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env40369 == env40370) = true)

theorem identity40370 : scanCanonicalize (H12AffineFastState.compose env40370 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound40370 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,137,342,5528,2557,1025,136,4161,169,17,2,468,64,2184,5393,4233,2420,1500,169,257,168,5456,513]

theorem envBound40371 : H12AffineFastState.Bounded env40371 := by
  intro p hp
  have h : env40371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40370_40371 : H12AffineEnvironment.transform 14 137 env40370 = env40371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env40370 == env40371) = true)

theorem identity40371 : scanCanonicalize (H12AffineFastState.compose env40371 (packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound40371 : packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env40372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,292,4096,348,5512,137,342,5528,217,1025,136,4161,169,17,2,468,64,428,5393,4233,80,1500,169,257,168,5456,513]

theorem envBound40372 : H12AffineFastState.Bounded env40372 := by
  intro p hp
  have h : env40372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40371_40372 : H12AffineEnvironment.transform 10 292 env40371 = env40372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env40371 == env40372) = true)

theorem identity40372 : scanCanonicalize (H12AffineFastState.compose env40372 (packedSelected [0,3,4,7,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound40372 : packedSelected [0,3,4,7,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env40373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,292,201,348,1345,137,342,1361,217,1025,136,136,169,17,2,468,64,428,1496,64,80,1500,169,257,168,1433,513]

theorem envBound40373 : H12AffineFastState.Bounded env40373 := by
  intro p hp
  have h : env40373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40372_40373 : H12AffineEnvironment.transform 11 201 env40372 = env40373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env40372 == env40373) = true)

theorem identity40373 : scanCanonicalize (H12AffineFastState.compose env40373 (packedSelected [4,9,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound40373 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env40374 : List Nat := [2,4,8,16,32,64,89,256,512,1024,292,16,348,1345,80,342,1361,0,1025,81,81,112,17,2,269,64,373,1281,64,80,1285,112,257,113,1344,513]

theorem envBound40374 : H12AffineFastState.Bounded env40374 := by
  intro p hp
  have h : env40374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40373_40374 : H12AffineEnvironment.transform 6 89 env40373 = env40374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env40373 == env40374) = true)

theorem identity40374 : scanCanonicalize (H12AffineFastState.compose env40374 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40374 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40375 : List Nat := [2,4,8,16,32,64,89,256,512,273,292,16,348,80,80,342,64,0,272,81,81,112,17,2,269,64,373,16,64,80,20,112,257,113,81,513]

theorem envBound40375 : H12AffineFastState.Bounded env40375 := by
  intro p hp
  have h : env40375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40374_40375 : H12AffineEnvironment.transform 9 273 env40374 = env40375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40374 == env40375) = true)

theorem identity40375 : scanCanonicalize (H12AffineFastState.compose env40375 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40375 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40376 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,16,268,0,0,262,16,0,272,1,1,32,17,2,269,16,293,16,16,0,20,32,257,33,1,513]

theorem envBound40376 : H12AffineFastState.Bounded env40376 := by
  intro p hp
  have h : env40376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40375_40376 : H12AffineEnvironment.transform 5 16 env40375 = env40376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40375 == env40376) = true)

theorem identity40376 : scanCanonicalize (H12AffineFastState.compose env40376 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40377 : List Nat := [2,4,8,16,32,16,9,37,512,52,1,16,41,0,0,35,16,0,53,1,1,32,17,2,40,16,0,16,16,0,20,32,36,33,1,513]

theorem envBound40377 : H12AffineFastState.Bounded env40377 := by
  intro p hp
  have h : env40377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40376_40377 : H12AffineEnvironment.transform 7 37 env40376 = env40377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40376 == env40377) = true)

theorem identity40377 : scanCanonicalize (H12AffineFastState.compose env40377 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound40377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40378 : List Nat := [2,4,8,16,32,16,9,37,32,52,1,16,41,0,0,35,16,0,53,1,1,32,17,2,40,16,0,16,16,0,20,32,36,33,1,33]

theorem envBound40378 : H12AffineFastState.Bounded env40378 := by
  intro p hp
  have h : env40378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40377_40378 : H12AffineEnvironment.transform 8 32 env40377 = env40378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env40377 == env40378) = true)

def env40379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257181,254097,8328,64,6705548,2253852,140364,2404636,2102684,6456656,257,21793,46212,2175563]

theorem envBound40379 : H12AffineFastState.Bounded env40379 := by
  intro p hp
  have h : env40379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40285_40379 : H12AffineEnvironment.transform 22 2257181 env40285 = env40379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257181 env40285 == env40379) = true)

def env40380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257181,254097,8328,64,2157716,2253852,140364,2404636,2102684,2373704,257,21793,46212,2175563]

theorem envBound40380 : H12AffineFastState.Bounded env40380 := by
  intro p hp
  have h : env40380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40379_40380 : H12AffineEnvironment.transform 21 441624 env40379 = env40380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env40379 == env40380) = true)

def env40381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,254097,8328,64,64724,160860,140364,303452,1500,272392,257,21793,46212,74251]

theorem envBound40381 : H12AffineFastState.Bounded env40381 := by
  intro p hp
  have h : env40381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40380_40381 : H12AffineEnvironment.transform 20 4160 env40380 = env40381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40380 == env40381) = true)

theorem identity40381 : scanCanonicalize (H12AffineFastState.compose env40381 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound40381 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,98781,8328,64,64724,5392,17664,303452,1500,272392,257,21793,46212,74251]

theorem envBound40382 : H12AffineFastState.Bounded env40382 := by
  intro p hp
  have h : env40382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40381_40382 : H12AffineEnvironment.transform 16 24908 env40381 = env40382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env40381 == env40382) = true)

def env40383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,98645,8192,64,64604,5392,17664,303452,1364,272392,257,21793,46092,74251]

theorem envBound40383 : H12AffineFastState.Bounded env40383 := by
  intro p hp
  have h : env40383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40382_40383 : H12AffineEnvironment.transform 6 8 env40382 = env40383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40382 == env40383) = true)

theorem identity40383 : scanCanonicalize (H12AffineFastState.compose env40383 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40383 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1025,32769,4160,62589,17,98645,8192,64,64604,5392,17664,35189,1364,33,257,21793,46092,74251]

theorem envBound40384 : H12AffineFastState.Bounded env40384 := by
  intro p hp
  have h : env40384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40383_40384 : H12AffineEnvironment.transform 17 10281 env40383 = env40384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40383 == env40384) = true)

theorem identity40384 : scanCanonicalize (H12AffineFastState.compose env40384 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound40384 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24908,10281,1025,32769,4160,62589,17,29791,8192,64,64604,5392,17664,35189,1364,33,257,21793,46092,55041]

theorem envBound40385 : H12AffineFastState.Bounded env40385 := by
  intro p hp
  have h : env40385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40384_40385 : H12AffineEnvironment.transform 15 62730 env40384 = env40385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env40384 == env40385) = true)

theorem identity40385 : scanCanonicalize (H12AffineFastState.compose env40385 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40385 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env40386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,33111,5393,10281,1025,32769,4160,32800,17,2,8192,64,34817,5392,12637,35189,1364,33,257,8572,46092,41820]

theorem envBound40386 : H12AffineFastState.Bounded env40386 := by
  intro p hp
  have h : env40386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40385_40386 : H12AffineEnvironment.transform 13 13405 env40385 = env40386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40385 == env40386) = true)

theorem identity40386 : scanCanonicalize (H12AffineFastState.compose env40386 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40386 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,33111,5393,2421,1025,32769,4160,32800,17,2,348,64,34817,5392,4097,35189,1364,33,257,32,38224,33280]

theorem envBound40387 : H12AffineFastState.Bounded env40387 := by
  intro p hp
  have h : env40387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40386_40387 : H12AffineEnvironment.transform 12 348 env40386 = env40387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40386 == env40387) = true)

theorem identity40387 : scanCanonicalize (H12AffineFastState.compose env40387 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40387 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env40388 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,32768,33030,5393,2340,1025,32769,4113,32800,17,2,269,17,34817,5392,4097,35108,1285,33,257,32,38145,33280]

theorem envBound40388 : H12AffineFastState.Bounded env40388 := by
  intro p hp
  have h : env40388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40387_40388 : H12AffineEnvironment.transform 5 17 env40387 = env40388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40387 == env40388) = true)

theorem identity40388 : scanCanonicalize (H12AffineFastState.compose env40388 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 4389) := by decide +kernel

theorem selectedBound40388 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40389 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,4389,4131,5393,2340,1025,4388,4113,4357,17,2,269,17,6436,5392,4097,6145,1285,33,257,32,1060,4901]

theorem envBound40389 : H12AffineFastState.Bounded env40389 := by
  intro p hp
  have h : env40389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40388_40389 : H12AffineEnvironment.transform 14 4389 env40388 = env40389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4389 env40388 == env40389) = true)

theorem identity40389 : scanCanonicalize (H12AffineFastState.compose env40389 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound40389 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env40390 : List Nat := [2,4,8,16,32,17,8,256,512,816,2048,4096,269,4657,4389,4131,4641,2340,817,4388,4113,4357,17,2,269,17,6436,4640,4097,6145,565,33,257,32,788,4901]

theorem envBound40390 : H12AffineFastState.Bounded env40390 := by
  intro p hp
  have h : env40390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40389_40390 : H12AffineEnvironment.transform 9 816 env40389 = env40390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env40389 == env40390) = true)

theorem identity40390 : scanCanonicalize (H12AffineFastState.compose env40390 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound40390 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env40391 : List Nat := [2,4,8,16,32,17,8,256,512,816,2048,261,269,820,32,294,804,2340,817,33,276,0,17,2,269,17,2081,805,260,2308,565,33,257,32,788,544]

theorem envBound40391 : H12AffineFastState.Bounded env40391 := by
  intro p hp
  have h : env40391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40390_40391 : H12AffineEnvironment.transform 11 261 env40390 = env40391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env40390 == env40391) = true)

theorem identity40391 : scanCanonicalize (H12AffineFastState.compose env40391 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40391 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env40392 : List Nat := [2,4,8,16,32,17,8,256,17,289,2048,261,269,293,32,294,309,2340,288,33,276,0,17,2,269,17,2081,308,260,2308,36,33,257,32,261,49]

theorem envBound40392 : H12AffineFastState.Bounded env40392 := by
  intro p hp
  have h : env40392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40391_40392 : H12AffineEnvironment.transform 8 17 env40391 = env40392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40391 == env40392) = true)

theorem identity40392 : scanCanonicalize (H12AffineFastState.compose env40392 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound40392 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env40393 : List Nat := [2,4,8,16,32,17,8,256,17,289,17,261,269,293,32,294,309,309,288,33,276,0,17,2,269,17,48,308,260,277,36,33,257,32,261,49]

theorem envBound40393 : H12AffineFastState.Bounded env40393 := by
  intro p hp
  have h : env40393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40392_40393 : H12AffineEnvironment.transform 10 17 env40392 = env40393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env40392 == env40393) = true)

theorem identity40393 : scanCanonicalize (H12AffineFastState.compose env40393 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40393 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env40394 : List Nat := [2,4,8,16,32,17,8,52,17,21,17,49,57,17,32,18,1,1,20,33,32,0,17,2,57,17,48,0,48,33,36,33,53,32,49,49]

theorem envBound40394 : H12AffineFastState.Bounded env40394 := by
  intro p hp
  have h : env40394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40393_40394 : H12AffineEnvironment.transform 7 52 env40393 = env40394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40393 == env40394) = true)

def env40395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,98644,8193,64,64605,5392,17664,303452,1365,272392,257,21793,46093,74251]

theorem envBound40395 : H12AffineFastState.Bounded env40395 := by
  intro p hp
  have h : env40395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40382_40395 : H12AffineEnvironment.transform 6 9 env40382 = env40395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40382 == env40395) = true)

theorem identity40395 : scanCanonicalize (H12AffineFastState.compose env40395 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound40395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1025,32769,4160,21792,17,98644,8193,64,64605,5392,17664,10280,1365,41340,257,21793,46093,74251]

theorem envBound40396 : H12AffineFastState.Bounded env40396 := by
  intro p hp
  have h : env40396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40395_40396 : H12AffineEnvironment.transform 17 35188 env40395 = env40396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env40395 == env40396) = true)

theorem identity40396 : scanCanonicalize (H12AffineFastState.compose env40396 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound40396 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,65536,24908,10361,1025,8460,4160,21792,17,73817,8193,64,23888,5392,17664,10280,1365,113,257,21793,5376,74251]

theorem envBound40397 : H12AffineFastState.Bounded env40397 := by
  intro p hp
  have h : env40397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40396_40397 : H12AffineEnvironment.transform 14 8461 env40396 = env40397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env40396 == env40397) = true)

theorem identity40397 : scanCanonicalize (H12AffineFastState.compose env40397 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40397 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8203,24908,10361,1025,8460,4160,21792,17,82,8193,64,23888,5392,17664,10280,1365,113,257,21793,5376,512]

theorem envBound40398 : H12AffineFastState.Bounded env40398 := by
  intro p hp
  have h : env40398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40397_40398 : H12AffineEnvironment.transform 15 8203 env40397 = env40398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40397 == env40398) = true)

theorem identity40398 : scanCanonicalize (H12AffineFastState.compose env40398 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40398 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,293,35,16740,2129,1025,292,4160,21792,17,82,41,64,23888,5392,17664,2048,1365,113,257,21793,5376,512]

theorem envBound40399 : H12AffineFastState.Bounded env40399 := by
  intro p hp
  have h : env40399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40398_40399 : H12AffineEnvironment.transform 12 40 env40398 = env40399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40398 == env40399) = true)

theorem identity40399 : scanCanonicalize (H12AffineFastState.compose env40399 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40399 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env40400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,293,35,5221,2129,1025,292,4160,33,17,82,41,64,2129,5392,4097,2048,1365,113,257,32,5376,512]

theorem envBound40400 : H12AffineFastState.Bounded env40400 := by
  intro p hp
  have h : env40400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40399_40400 : H12AffineEnvironment.transform 13 5377 env40399 = env40400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40399 == env40400) = true)

theorem identity40400 : scanCanonicalize (H12AffineFastState.compose env40400 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound40400 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40401 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,40,5205,113,35,5221,2129,1025,112,4160,33,17,82,41,64,2129,5188,4097,2048,1025,113,85,32,5204,512]

theorem envBound40401 : H12AffineFastState.Bounded env40401 := by
  intro p hp
  have h : env40401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40400_40401 : H12AffineEnvironment.transform 7 84 env40400 = env40401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env40400 == env40401) = true)

theorem identity40401 : scanCanonicalize (H12AffineFastState.compose env40401 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40401 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40402 : List Nat := [2,4,8,16,32,64,9,84,512,52,2048,4096,40,4193,113,35,4177,2129,53,112,4160,33,17,82,41,64,2129,4208,4097,2048,53,113,85,32,4192,512]

theorem envBound40402 : H12AffineFastState.Bounded env40402 := by
  intro p hp
  have h : env40402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40401_40402 : H12AffineEnvironment.transform 9 52 env40401 = env40402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40401 == env40402) = true)

theorem identity40402 : scanCanonicalize (H12AffineFastState.compose env40402 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40402 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env40403 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,4096,40,4145,33,35,4097,2049,53,32,4112,33,17,2,41,16,2049,4128,4097,2048,53,33,5,32,4144,512]

theorem envBound40403 : H12AffineFastState.Bounded env40403 := by
  intro p hp
  have h : env40403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40402_40403 : H12AffineEnvironment.transform 5 16 env40402 = env40403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40402 == env40403) = true)

theorem identity40403 : scanCanonicalize (H12AffineFastState.compose env40403 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40403 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env40404 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,4096,8,4113,1,3,4097,2049,21,0,4112,1,17,2,9,16,2049,4096,4097,2048,21,1,5,0,4112,512]

theorem envBound40404 : H12AffineFastState.Bounded env40404 := by
  intro p hp
  have h : env40404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40403_40404 : H12AffineEnvironment.transform 4 0 env40403 = env40404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40403 == env40404) = true)

theorem identity40404 : scanCanonicalize (H12AffineFastState.compose env40404 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound40404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40405 : List Nat := [2,4,8,16,0,16,9,4,512,20,512,4096,8,4113,1,3,4097,513,21,0,4112,1,17,2,9,16,513,4096,4097,512,21,1,5,0,4112,512]

theorem envBound40405 : H12AffineFastState.Bounded env40405 := by
  intro p hp
  have h : env40405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40404_40405 : H12AffineEnvironment.transform 10 512 env40404 = env40405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env40404 == env40405) = true)

theorem identity40405 : scanCanonicalize (H12AffineFastState.compose env40405 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 543) := by decide +kernel

theorem selectedBound40405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40406 : List Nat := [2,4,8,16,0,16,9,4,512,20,512,543,8,526,1,3,542,513,21,0,527,1,17,2,9,16,513,543,542,512,21,1,5,0,527,512]

theorem envBound40406 : H12AffineFastState.Bounded env40406 := by
  intro p hp
  have h : env40406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40405_40406 : H12AffineEnvironment.transform 11 543 env40405 = env40406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 543 env40405 == env40406) = true)

theorem identity40406 : scanCanonicalize (H12AffineFastState.compose env40406 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound40406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40407 : List Nat := [2,4,8,16,0,16,9,4,30,20,30,1,8,16,1,3,0,31,21,0,17,1,17,2,9,16,31,1,0,30,21,1,5,0,17,30]

theorem envBound40407 : H12AffineFastState.Bounded env40407 := by
  intro p hp
  have h : env40407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40406_40407 : H12AffineEnvironment.transform 8 30 env40406 = env40407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env40406 == env40407) = true)

theorem identity40407 : scanCanonicalize (H12AffineFastState.compose env40407 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound40407 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40408 : List Nat := [2,4,8,14,0,14,9,4,0,10,0,1,8,14,1,3,0,1,11,0,15,1,15,2,9,14,1,1,0,0,11,1,5,0,15,0]

theorem envBound40408 : H12AffineFastState.Bounded env40408 := by
  intro p hp
  have h : env40408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40407_40408 : H12AffineEnvironment.transform 3 14 env40407 = env40408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env40407 == env40408) = true)

theorem identity40408 : scanCanonicalize (H12AffineFastState.compose env40408 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound40408 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40409 : List Nat := [2,4,7,1,0,1,6,4,0,5,0,1,7,1,1,3,0,1,4,0,0,1,0,2,6,1,1,1,0,0,4,1,5,0,0,0]

theorem envBound40409 : H12AffineFastState.Bounded env40409 := by
  intro p hp
  have h : env40409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40408_40409 : H12AffineEnvironment.transform 2 7 env40408 = env40409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env40408 == env40409) = true)

def env40410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,254097,8328,64,64725,160861,140364,303453,1501,272393,257,21793,46212,74250]

theorem envBound40410 : H12AffineFastState.Bounded env40410 := by
  intro p hp
  have h : env40410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40380_40410 : H12AffineEnvironment.transform 20 4161 env40380 = env40410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40380 == env40410) = true)

theorem identity40410 : scanCanonicalize (H12AffineFastState.compose env40410 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40410 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,412108,155996,201797,8328,64,2049,160861,140364,284041,1501,272393,257,21793,16464,74250]

theorem envBound40411 : H12AffineFastState.Bounded env40411 := by
  intro p hp
  have h : env40411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40410_40411 : H12AffineEnvironment.transform 14 29908 env40410 = env40411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40410 == env40411) = true)

def env40412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,411972,155996,201797,8192,64,2049,160861,140364,283905,1365,272393,257,21793,16464,74250]

theorem envBound40412 : H12AffineFastState.Bounded env40412 := by
  intro p hp
  have h : env40412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40411_40412 : H12AffineEnvironment.transform 6 8 env40411 = env40412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40411 == env40412) = true)

theorem identity40412 : scanCanonicalize (H12AffineFastState.compose env40412 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound40412 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env40413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,157801,1025,29789,4161,8493,155996,201797,8192,64,2049,160861,140364,146792,1365,147552,257,21793,16464,74250]

theorem envBound40413 : H12AffineFastState.Bounded env40413 := by
  intro p hp
  have h : env40413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40412_40413 : H12AffineEnvironment.transform 17 157801 env40412 = env40413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env40412 == env40413) = true)

theorem identity40413 : scanCanonicalize (H12AffineFastState.compose env40413 (packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound40413 : packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS < 2^1333 := by decide +kernel

def env40414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,79130,89459,1025,29789,4161,8493,87110,8543,8192,64,2049,82247,69974,67698,1365,95610,257,21793,16464,74250]

theorem envBound40414 : H12AffineFastState.Bounded env40414 := by
  intro p hp
  have h : env40414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40413_40414 : H12AffineEnvironment.transform 16 79130 env40413 = env40414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env40413 == env40414) = true)

theorem identity40414 : scanCanonicalize (H12AffineFastState.compose env40414 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40414 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env40415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,5393,32120,1025,29789,4161,8493,29773,8543,8192,64,2049,24908,12637,10361,1365,21873,257,21793,16464,513]

theorem envBound40415 : H12AffineFastState.Bounded env40415 := by
  intro p hp
  have h : env40415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40414_40415 : H12AffineEnvironment.transform 15 8203 env40414 = env40415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40414 == env40415) = true)

theorem identity40415 : scanCanonicalize (H12AffineFastState.compose env40415 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40415 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,10361,1025,8540,4161,8493,8524,8543,8192,64,2049,13389,12637,10361,1365,112,257,32,5457,513]

theorem envBound40416 : H12AffineFastState.Bounded env40416 := by
  intro p hp
  have h : env40416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40415_40416 : H12AffineEnvironment.transform 13 5377 env40415 = env40416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40415 == env40416) = true)

theorem identity40416 : scanCanonicalize (H12AffineFastState.compose env40416 (packedSelected [0,4,7,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 317) := by decide +kernel

theorem selectedBound40416 : packedSelected [0,4,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,317,5377,96,310,5393,2372,1025,97,4161,16,113,98,317,64,2049,5488,4192,2372,1365,112,257,32,5457,513]

theorem envBound40417 : H12AffineFastState.Bounded env40417 := by
  intro p hp
  have h : env40417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40416_40417 : H12AffineEnvironment.transform 12 317 env40416 = env40417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 317 env40416 == env40417) = true)

theorem identity40417 : scanCanonicalize (H12AffineFastState.compose env40417 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40417 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40418 : List Nat := [2,4,8,16,17,64,8,256,512,1024,2048,4096,268,5377,81,263,5393,2372,1025,80,4161,16,64,83,268,64,2049,5441,4177,2372,1365,65,257,17,5457,513]

theorem envBound40418 : H12AffineFastState.Bounded env40418 := by
  intro p hp
  have h : env40418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40417_40418 : H12AffineEnvironment.transform 4 17 env40417 = env40418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40417 == env40418) = true)

theorem identity40418 : scanCanonicalize (H12AffineFastState.compose env40418 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound40418 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40419 : List Nat := [2,4,8,16,17,64,8,256,512,1024,11,4096,268,5377,81,263,5393,335,1025,80,4161,16,64,83,268,64,10,5441,4177,335,1365,65,257,17,5457,513]

theorem envBound40419 : H12AffineFastState.Bounded env40419 := by
  intro p hp
  have h : env40419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40418_40419 : H12AffineEnvironment.transform 10 11 env40418 = env40419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env40418 == env40419) = true)

theorem identity40419 : scanCanonicalize (H12AffineFastState.compose env40419 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound40419 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env40420 : List Nat := [2,4,8,16,17,64,8,79,512,1024,11,4096,67,5198,81,72,5214,0,1025,80,4161,16,64,83,67,64,10,5134,4177,0,1050,65,78,17,5150,513]

theorem envBound40420 : H12AffineFastState.Bounded env40420 := by
  intro p hp
  have h : env40420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40419_40420 : H12AffineEnvironment.transform 7 79 env40419 = env40420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env40419 == env40420) = true)

theorem identity40420 : scanCanonicalize (H12AffineFastState.compose env40420 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1103) := by decide +kernel

theorem selectedBound40420 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40421 : List Nat := [2,4,8,16,17,64,8,79,512,1024,11,1103,67,1,81,72,17,0,1025,80,1038,16,64,83,67,64,10,65,1054,0,1050,65,78,17,81,513]

theorem envBound40421 : H12AffineFastState.Bounded env40421 := by
  intro p hp
  have h : env40421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40420_40421 : H12AffineEnvironment.transform 11 1103 env40420 = env40421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1103 env40420 == env40421) = true)

theorem identity40421 : scanCanonicalize (H12AffineFastState.compose env40421 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40422 : List Nat := [2,4,8,0,1,64,8,79,512,1024,11,1103,67,1,65,72,1,0,1025,64,1038,0,64,67,67,64,10,65,1038,0,1034,65,78,1,65,513]

theorem envBound40422 : H12AffineFastState.Bounded env40422 := by
  intro p hp
  have h : env40422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40421_40422 : H12AffineEnvironment.transform 3 0 env40421 = env40422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40421 == env40422) = true)

theorem identity40422 : scanCanonicalize (H12AffineFastState.compose env40422 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound40422 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40423 : List Nat := [2,4,8,0,1,10,8,5,512,1024,11,1029,9,1,11,2,1,0,1025,10,1038,0,10,9,9,10,10,11,1038,0,1034,11,4,1,11,513]

theorem envBound40423 : H12AffineFastState.Bounded env40423 := by
  intro p hp
  have h : env40423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40422_40423 : H12AffineEnvironment.transform 5 10 env40422 = env40423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env40422 == env40423) = true)

theorem identity40423 : scanCanonicalize (H12AffineFastState.compose env40423 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound40423 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env40424 : List Nat := [2,4,7,0,1,5,7,5,512,1024,4,1029,6,1,4,2,1,0,1025,5,1025,0,5,6,6,5,5,4,1025,0,1029,4,4,1,4,513]

theorem envBound40424 : H12AffineFastState.Bounded env40424 := by
  intro p hp
  have h : env40424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40423_40424 : H12AffineEnvironment.transform 2 7 env40423 = env40424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env40423 == env40424) = true)

def env40425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,411973,155996,201797,8193,64,2049,160861,140364,283904,1364,272393,257,21793,16464,74250]

theorem envBound40425 : H12AffineFastState.Bounded env40425 := by
  intro p hp
  have h : env40425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40411_40425 : H12AffineEnvironment.transform 6 9 env40411 = env40425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40411 == env40425) = true)

theorem identity40425 : scanCanonicalize (H12AffineFastState.compose env40425 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound40425 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env40426 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,215090,1025,29788,4161,65911,155996,201797,8193,64,2049,160861,140364,204082,1364,221243,257,21793,16464,74250]

theorem envBound40426 : H12AffineFastState.Bounded env40426 := by
  intro p hp
  have h : env40426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40425_40426 : H12AffineEnvironment.transform 17 215090 env40425 = env40426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env40425 == env40426) = true)

theorem identity40426 : scanCanonicalize (H12AffineFastState.compose env40426 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40426 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,16401,67619,1025,29788,4161,65911,8525,87124,8193,64,2049,13388,25693,89379,1364,73770,257,21793,16464,74250]

theorem envBound40427 : H12AffineFastState.Bounded env40427 := by
  intro p hp
  have h : env40427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40426_40427 : H12AffineEnvironment.transform 16 16401 env40426 = env40427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40426 == env40427) = true)

theorem identity40427 : scanCanonicalize (H12AffineFastState.compose env40427 (packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40427 : packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env40428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,65536,16401,67619,1025,21761,4161,65911,16,87124,348,64,2049,5393,17664,89379,1364,65911,257,21793,16464,66391]

theorem envBound40428 : H12AffineFastState.Bounded env40428 := by
  intro p hp
  have h : env40428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40427_40428 : H12AffineEnvironment.transform 12 349 env40427 = env40428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40427 == env40428) = true)

theorem identity40428 : scanCanonicalize (H12AffineFastState.compose env40428 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound40428 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env40429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21591,16401,23668,1025,21761,4161,21792,16,3,348,64,2049,5393,17664,2420,1364,21792,257,21793,16464,22272]

theorem envBound40429 : H12AffineFastState.Bounded env40429 := by
  intro p hp
  have h : env40429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40428_40429 : H12AffineEnvironment.transform 15 21591 env40428 = env40429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env40428 == env40429) = true)

theorem identity40429 : scanCanonicalize (H12AffineFastState.compose env40429 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40429 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env40430 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,21540,21591,16401,23668,1025,21541,4161,21508,16,3,120,64,2049,5173,17444,2128,1136,21508,37,21509,16464,22052]

theorem envBound40430 : H12AffineFastState.Bounded env40430 := by
  intro p hp
  have h : env40430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40429_40430 : H12AffineEnvironment.transform 7 36 env40429 = env40430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40429 == env40430) = true)

theorem identity40430 : scanCanonicalize (H12AffineFastState.compose env40430 (packedSelected [0,1,6,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound40430 : packedSelected [0,1,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env40431 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,121,16384,18433,18546,16401,16465,1025,18432,3172,18465,16,3,120,64,2049,2064,17444,2128,1136,18465,37,18464,16464,18945]

theorem envBound40431 : H12AffineFastState.Bounded env40431 := by
  intro p hp
  have h : env40431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40430_40431 : H12AffineEnvironment.transform 11 3109 env40430 = env40431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env40430 == env40431) = true)

theorem identity40431 : scanCanonicalize (H12AffineFastState.compose env40431 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound40431 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env40432 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,121,2129,80,35,2112,2048,1025,81,3172,112,16,3,120,64,2049,2064,3189,2128,1136,112,37,113,2049,592]

theorem envBound40432 : H12AffineFastState.Bounded env40432 := by
  intro p hp
  have h : env40432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40431_40432 : H12AffineEnvironment.transform 13 2129 env40431 = env40432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env40431 == env40432) = true)

theorem identity40432 : scanCanonicalize (H12AffineFastState.compose env40432 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40432 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env40433 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2065,121,2129,80,35,2112,2048,53,81,2128,112,16,3,120,64,2049,2064,2113,2128,68,112,37,113,2049,592]

theorem envBound40433 : H12AffineFastState.Bounded env40433 := by
  intro p hp
  have h : env40433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40432_40433 : H12AffineEnvironment.transform 9 52 env40432 = env40433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40432 == env40433) = true)

theorem identity40433 : scanCanonicalize (H12AffineFastState.compose env40433 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound40433 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env40434 : List Nat := [2,4,8,16,32,64,9,36,512,52,64,81,121,17,80,35,0,64,53,81,16,112,16,3,120,64,65,80,1,16,68,112,37,113,65,592]

theorem envBound40434 : H12AffineFastState.Bounded env40434 := by
  intro p hp
  have h : env40434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40433_40434 : H12AffineEnvironment.transform 10 64 env40433 = env40434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env40433 == env40434) = true)

theorem identity40434 : scanCanonicalize (H12AffineFastState.compose env40434 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40434 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env40435 : List Nat := [2,4,8,16,32,17,9,36,512,52,17,0,40,17,1,35,0,17,53,0,16,33,16,3,41,17,16,1,1,16,21,33,37,32,16,513]

theorem envBound40435 : H12AffineFastState.Bounded env40435 := by
  intro p hp
  have h : env40435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40434_40435 : H12AffineEnvironment.transform 5 17 env40434 = env40435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40434 == env40435) = true)

def env40436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257181,254097,8328,64,2157717,2253852,140364,2404636,2102684,2373705,257,21793,46212,2175563]

theorem envBound40436 : H12AffineFastState.Bounded env40436 := by
  intro p hp
  have h : env40436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40379_40436 : H12AffineEnvironment.transform 21 441625 env40379 = env40436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env40379 == env40436) = true)

def env40437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,254097,8328,64,64725,160860,140364,303452,1500,272393,257,21793,46212,74251]

theorem envBound40437 : H12AffineFastState.Bounded env40437 := by
  intro p hp
  have h : env40437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40436_40437 : H12AffineEnvironment.transform 20 4160 env40436 = env40437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40436 == env40437) = true)

def env40438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169265,155997,254097,8328,64,64725,160860,140364,35188,1500,33,257,21793,46212,74251]

theorem envBound40438 : H12AffineFastState.Bounded env40438 := by
  intro p hp
  have h : env40438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40437_40438 : H12AffineEnvironment.transform 17 10280 env40437 = env40438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40437 == env40438) = true)

def env40439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21793,41293,73857,8328,64,64725,46156,58460,35188,1500,33,257,21793,46212,74251]

theorem envBound40439 : H12AffineFastState.Bounded env40439 := by
  intro p hp
  have h : env40439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40438_40439 : H12AffineEnvironment.transform 16 49168 env40438 = env40439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40438 == env40439) = true)

theorem identity40439 : scanCanonicalize (H12AffineFastState.compose env40439 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound40439 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1025,8660,4160,21793,152,73857,8328,64,23808,5529,17801,10401,1500,33,257,21793,5457,74251]

theorem envBound40440 : H12AffineFastState.Bounded env40440 := by
  intro p hp
  have h : env40440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40439_40440 : H12AffineEnvironment.transform 14 8661 env40439 = env40440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env40439 == env40440) = true)

theorem identity40440 : scanCanonicalize (H12AffineFastState.compose env40440 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound40440 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8661,65536,12756,10280,1025,8660,4160,1328,152,73857,8328,64,3345,5529,5528,10401,1500,33,257,1328,5457,74251]

theorem envBound40441 : H12AffineFastState.Bounded env40441 := by
  intro p hp
  have h : env40441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40440_40441 : H12AffineEnvironment.transform 13 4113 env40440 = env40441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env40440 == env40441) = true)

theorem identity40441 : scanCanonicalize (H12AffineFastState.compose env40441 (packedSelected [4,5,7,9,18,19,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound40441 : packedSelected [4,5,7,9,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8661,8283,12756,10280,1025,8660,4160,1328,152,218,8328,64,3345,5529,5528,10401,1500,33,257,1328,5457,592]

theorem envBound40442 : H12AffineFastState.Bounded env40442 := by
  intro p hp
  have h : env40442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40441_40442 : H12AffineEnvironment.transform 15 8283 env40441 = env40442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env40441 == env40442) = true)

theorem identity40442 : scanCanonicalize (H12AffineFastState.compose env40442 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound40442 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env40443 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4113,8232,8283,12329,10280,1025,8233,4160,1229,152,218,8328,64,3308,5220,5221,10401,1057,33,252,1229,5292,592]

theorem envBound40443 : H12AffineFastState.Bounded env40443 := by
  intro p hp
  have h : env40443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40442_40443 : H12AffineEnvironment.transform 7 253 env40442 = env40443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env40442 == env40443) = true)

theorem identity40443 : scanCanonicalize (H12AffineFastState.compose env40443 (packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40443 : packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS < 2^1333 := by decide +kernel

def env40444 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4113,8232,8283,12329,10280,1025,8233,4160,1093,16,82,8192,64,3172,5220,5221,10281,1057,33,116,1093,5156,592]

theorem envBound40444 : H12AffineFastState.Bounded env40444 := by
  intro p hp
  have h : env40444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40443_40444 : H12AffineEnvironment.transform 6 8 env40443 = env40444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40443 == env40444) = true)

theorem identity40444 : scanCanonicalize (H12AffineFastState.compose env40444 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40444 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env40445 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,41,4113,1,114,4096,2049,1025,0,4160,1093,16,82,41,64,3172,5220,5221,2048,1057,33,116,1093,5156,592]

theorem envBound40445 : H12AffineFastState.Bounded env40445 := by
  intro p hp
  have h : env40445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40444_40445 : H12AffineEnvironment.transform 12 41 env40444 = env40445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40444 == env40445) = true)

theorem identity40445 : scanCanonicalize (H12AffineFastState.compose env40445 (packedSelected [0,2,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 30) := by decide +kernel

theorem selectedBound40445 : packedSelected [0,2,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40446 : List Nat := [2,4,8,16,32,30,8,43,512,1024,2048,4096,41,4113,1,44,4096,2049,1025,0,4126,1051,16,12,41,30,3130,5178,5179,2048,1057,33,42,1051,5156,526]

theorem envBound40446 : H12AffineFastState.Bounded env40446 := by
  intro p hp
  have h : env40446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40445_40446 : H12AffineEnvironment.transform 5 30 env40445 = env40446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 30 env40445 == env40446) = true)

def env40447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21792,41292,73856,8328,64,64725,46157,58461,35188,1500,33,257,21793,46212,74251]

theorem envBound40447 : H12AffineFastState.Bounded env40447 := by
  intro p hp
  have h : env40447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40438_40447 : H12AffineEnvironment.transform 16 49169 env40438 = env40447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40438 == env40447) = true)

theorem identity40447 : scanCanonicalize (H12AffineFastState.compose env40447 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40447 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10280,1025,8541,4160,21792,16,73856,8328,64,23945,5393,17665,10280,1500,33,257,21793,5592,74251]

theorem envBound40448 : H12AffineFastState.Bounded env40448 := by
  intro p hp
  have h : env40448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40447_40448 : H12AffineEnvironment.transform 14 8540 env40447 = env40448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40447 == env40448) = true)

theorem identity40448 : scanCanonicalize (H12AffineFastState.compose env40448 (packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 9447) := by decide +kernel

theorem selectedBound40448 : packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env40449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,9447,24909,10280,1025,8541,4160,21792,16,1127,8328,64,23945,5393,17665,10280,1500,33,257,21793,5592,1772]

theorem envBound40449 : H12AffineFastState.Bounded env40449 := by
  intro p hp
  have h : env40449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40448_40449 : H12AffineEnvironment.transform 15 9447 env40448 = env40449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9447 env40448 == env40449) = true)

theorem identity40449 : scanCanonicalize (H12AffineFastState.compose env40449 (packedSelected [2,4,6,11,16,18,19,22,26] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40449 : packedSelected [2,4,6,11,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env40450 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,9447,24633,10280,1025,8233,4160,21588,16,1127,8328,64,23805,5221,17525,10280,1192,33,117,21589,5292,1772]

theorem envBound40450 : H12AffineFastState.Bounded env40450 := by
  intro p hp
  have h : env40450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40449_40450 : H12AffineEnvironment.transform 7 116 env40449 = env40450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40449 == env40450) = true)

theorem identity40450 : scanCanonicalize (H12AffineFastState.compose env40450 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound40450 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env40451 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,4112,8232,9447,12329,10280,1025,8233,4160,1092,16,1127,8328,64,3309,5221,5221,10280,1192,33,117,1093,5292,1772]

theorem envBound40451 : H12AffineFastState.Bounded env40451 := by
  intro p hp
  have h : env40451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40450_40451 : H12AffineEnvironment.transform 13 4112 env40450 = env40451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env40450 == env40451) = true)

theorem identity40451 : scanCanonicalize (H12AffineFastState.compose env40451 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40451 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env40452 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,4112,8232,9399,12329,10280,1025,8233,4112,1044,16,1079,8328,16,3261,5173,5173,10280,1192,33,37,1045,5292,1724]

theorem envBound40452 : H12AffineFastState.Bounded env40452 := by
  intro p hp
  have h : env40452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40451_40452 : H12AffineEnvironment.transform 5 16 env40451 = env40452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40451 == env40452) = true)

theorem identity40452 : scanCanonicalize (H12AffineFastState.compose env40452 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6321) := by decide +kernel

theorem selectedBound40452 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40453 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,6321,4112,6297,7174,2200,4249,1025,6296,4112,1044,16,1079,6201,16,3261,5173,5173,4249,1192,33,37,1045,5292,1724]

theorem envBound40453 : H12AffineFastState.Bounded env40453 := by
  intro p hp
  have h : env40453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40452_40453 : H12AffineEnvironment.transform 12 6321 env40452 = env40453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6321 env40452 == env40453) = true)

theorem identity40453 : scanCanonicalize (H12AffineFastState.compose env40453 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound40453 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40454 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,1196,3101,1212,3125,2218,2200,1077,1025,3124,1212,1044,16,1079,3221,16,3261,153,153,1077,1192,33,37,1045,0,1724]

theorem envBound40454 : H12AffineFastState.Bounded env40454 := by
  intro p hp
  have h : env40454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40453_40454 : H12AffineEnvironment.transform 11 1196 env40453 = env40454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env40453 == env40454) = true)

theorem identity40454 : scanCanonicalize (H12AffineFastState.compose env40454 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40454 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env40455 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,1060,3101,1076,3125,2082,2064,1077,1025,3124,1076,1044,16,1079,3101,16,3125,17,17,1077,1056,33,37,1045,0,1588]

theorem envBound40455 : H12AffineFastState.Bounded env40455 := by
  intro p hp
  have h : env40455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40454_40455 : H12AffineEnvironment.transform 6 8 env40454 = env40455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40454 == env40455) = true)

theorem identity40455 : scanCanonicalize (H12AffineFastState.compose env40455 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40455 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env40456 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,16,2089,0,2049,2082,2064,1,53,2048,0,32,16,3,2089,16,2049,17,17,1,20,33,37,33,0,512]

theorem envBound40456 : H12AffineFastState.Bounded env40456 := by
  intro p hp
  have h : env40456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40455_40456 : H12AffineEnvironment.transform 9 52 env40455 = env40456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40455 == env40456) = true)

theorem identity40456 : scanCanonicalize (H12AffineFastState.compose env40456 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound40456 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40457 : List Nat := [2,4,8,16,32,16,8,36,512,52,32,16,9,0,33,2,48,1,53,32,0,32,16,3,9,16,33,17,17,1,20,33,37,33,0,512]

theorem envBound40457 : H12AffineFastState.Bounded env40457 := by
  intro p hp
  have h : env40457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40456_40457 : H12AffineEnvironment.transform 10 32 env40456 = env40457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env40456 == env40457) = true)

theorem identity40457 : scanCanonicalize (H12AffineFastState.compose env40457 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40457 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40458 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,0,1,2,16,1,21,0,0,0,16,3,9,16,1,17,17,1,20,1,5,1,0,512]

theorem envBound40458 : H12AffineFastState.Bounded env40458 := by
  intro p hp
  have h : env40458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40457_40458 : H12AffineEnvironment.transform 4 0 env40457 = env40458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40457 == env40458) = true)

theorem identity40458 : scanCanonicalize (H12AffineFastState.compose env40458 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40459 : List Nat := [2,4,8,1,0,1,8,4,512,5,0,1,9,0,1,2,1,1,4,0,0,0,1,3,9,1,1,0,0,1,5,1,5,1,0,512]

theorem envBound40459 : H12AffineFastState.Bounded env40459 := by
  intro p hp
  have h : env40459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40458_40459 : H12AffineEnvironment.transform 3 1 env40458 = env40459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40458 == env40459) = true)

theorem identity40459 : scanCanonicalize (H12AffineFastState.compose env40459 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound40459 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40460 : List Nat := [2,4,8,1,0,1,8,4,14,5,0,1,9,0,1,2,1,1,4,0,0,0,1,3,9,1,1,0,0,1,5,1,5,1,0,14]

theorem envBound40460 : H12AffineFastState.Bounded env40460 := by
  intro p hp
  have h : env40460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40459_40460 : H12AffineEnvironment.transform 8 14 env40459 = env40460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env40459 == env40460) = true)

def env40461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169264,155997,254097,8328,64,64725,160860,140364,35189,1500,32,257,21793,46212,74251]

theorem envBound40461 : H12AffineFastState.Bounded env40461 := by
  intro p hp
  have h : env40461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40437_40461 : H12AffineEnvironment.transform 17 10281 env40437 = env40461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40437 == env40461) = true)

def env40462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21792,41293,73857,8328,64,64725,46156,58460,35189,1500,32,257,21793,46212,74251]

theorem envBound40462 : H12AffineFastState.Bounded env40462 := by
  intro p hp
  have h : env40462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40461_40462 : H12AffineEnvironment.transform 16 49168 env40461 = env40462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40461 == env40462) = true)

theorem identity40462 : scanCanonicalize (H12AffineFastState.compose env40462 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40462 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21792,41293,73737,8192,64,64605,46156,58460,35189,1364,32,257,21793,46092,74251]

theorem envBound40463 : H12AffineFastState.Bounded env40463 := by
  intro p hp
  have h : env40463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40462_40463 : H12AffineEnvironment.transform 6 8 env40462 = env40463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40462 == env40463) = true)

theorem identity40463 : scanCanonicalize (H12AffineFastState.compose env40463 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40463 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40464 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10281,1025,8540,4160,21792,16,73737,8192,64,23808,5393,17665,10280,1364,32,257,21793,5457,74251]

theorem envBound40464 : H12AffineFastState.Bounded env40464 := by
  intro p hp
  have h : env40464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40463_40464 : H12AffineEnvironment.transform 14 8541 env40463 = env40464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40463 == env40464) = true)

theorem identity40464 : scanCanonicalize (H12AffineFastState.compose env40464 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound40464 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,24909,10281,1025,8540,4160,21792,16,8543,8192,64,23808,5393,17665,10280,1364,32,257,21793,5457,9053]

theorem envBound40465 : H12AffineFastState.Bounded env40465 := by
  intro p hp
  have h : env40465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40464_40465 : H12AffineEnvironment.transform 15 342 env40464 = env40465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env40464 == env40465) = true)

theorem identity40465 : scanCanonicalize (H12AffineFastState.compose env40465 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40465 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,342,5393,10281,1025,8540,4160,8572,16,8543,8192,64,10588,5393,12637,10280,1364,32,257,8573,5457,9053]

theorem envBound40466 : H12AffineFastState.Bounded env40466 := by
  intro p hp
  have h : env40466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40465_40466 : H12AffineEnvironment.transform 13 13404 env40465 = env40466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40465 == env40466) = true)

theorem identity40466 : scanCanonicalize (H12AffineFastState.compose env40466 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40466 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5393,2421,1025,0,4160,32,16,3,348,64,2048,5393,4097,2420,1364,32,257,33,5457,513]

theorem envBound40467 : H12AffineFastState.Bounded env40467 := by
  intro p hp
  have h : env40467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40466_40467 : H12AffineEnvironment.transform 12 348 env40466 = env40467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40466 == env40467) = true)

theorem identity40467 : scanCanonicalize (H12AffineFastState.compose env40467 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2927) := by decide +kernel

theorem selectedBound40467 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2927,348,3695,1,342,3710,2421,1025,0,2863,32,16,3,348,64,2048,3710,2926,2420,1364,32,257,33,3646,513]

theorem envBound40468 : H12AffineFastState.Bounded env40468 := by
  intro p hp
  have h : env40468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40467_40468 : H12AffineEnvironment.transform 11 2927 env40467 = env40468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2927 env40467 == env40468) = true)

theorem identity40468 : scanCanonicalize (H12AffineFastState.compose env40468 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40468 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40469 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2879,268,3647,1,262,3630,2341,1025,0,2863,32,16,3,268,16,2048,3630,2878,2340,1284,32,257,33,3646,513]

theorem envBound40469 : H12AffineFastState.Bounded env40469 := by
  intro p hp
  have h : env40469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40468_40469 : H12AffineEnvironment.transform 5 16 env40468 = env40469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40468 == env40469) = true)

theorem identity40469 : scanCanonicalize (H12AffineFastState.compose env40469 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound40469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40470 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1818,1061,268,293,1,262,308,1599,1025,0,1077,32,16,3,268,16,1818,308,1060,1598,1284,32,257,33,292,513]

theorem envBound40470 : H12AffineFastState.Bounded env40470 := by
  intro p hp
  have h : env40470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40469_40470 : H12AffineEnvironment.transform 10 1818 env40469 = env40470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env40469 == env40470) = true)

theorem identity40470 : scanCanonicalize (H12AffineFastState.compose env40470 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound40470 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40471 : List Nat := [2,4,8,16,32,16,8,256,512,543,261,570,268,293,1,262,308,32,542,0,554,32,16,3,268,16,261,308,571,33,795,32,257,33,292,513]

theorem envBound40471 : H12AffineFastState.Bounded env40471 := by
  intro p hp
  have h : env40471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40470_40471 : H12AffineEnvironment.transform 9 543 env40470 = env40471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env40470 == env40471) = true)

theorem identity40471 : scanCanonicalize (H12AffineFastState.compose env40471 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound40471 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40472 : List Nat := [2,4,8,16,32,16,8,256,271,272,261,309,268,293,1,262,308,32,273,0,293,32,16,3,268,16,261,308,308,33,20,32,257,33,292,270]

theorem envBound40472 : H12AffineFastState.Bounded env40472 := by
  intro p hp
  have h : env40472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40471_40472 : H12AffineEnvironment.transform 8 271 env40471 = env40472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env40471 == env40472) = true)

theorem identity40472 : scanCanonicalize (H12AffineFastState.compose env40472 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40472 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40473 : List Nat := [2,4,8,16,0,16,8,256,271,272,261,277,268,261,1,262,276,0,273,0,261,0,16,3,268,16,261,276,276,1,20,0,257,1,260,270]

theorem envBound40473 : H12AffineFastState.Bounded env40473 := by
  intro p hp
  have h : env40473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40472_40473 : H12AffineEnvironment.transform 4 0 env40472 = env40473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40472 == env40473) = true)

theorem identity40473 : scanCanonicalize (H12AffineFastState.compose env40473 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40473 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40474 : List Nat := [2,4,8,16,0,16,8,4,11,20,1,17,8,1,1,2,16,0,21,0,1,0,16,3,8,16,1,16,16,1,20,0,5,1,0,10]

theorem envBound40474 : H12AffineFastState.Bounded env40474 := by
  intro p hp
  have h : env40474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40473_40474 : H12AffineEnvironment.transform 7 4 env40473 = env40474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40473 == env40474) = true)

theorem identity40474 : scanCanonicalize (H12AffineFastState.compose env40474 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound40474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40475 : List Nat := [2,4,6,16,0,16,6,4,5,20,1,17,6,1,1,2,16,0,21,0,1,0,16,3,6,16,1,16,16,1,20,0,5,1,0,4]

theorem envBound40475 : H12AffineFastState.Bounded env40475 := by
  intro p hp
  have h : env40475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40474_40475 : H12AffineEnvironment.transform 2 6 env40474 = env40475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env40474 == env40475) = true)

theorem identity40475 : scanCanonicalize (H12AffineFastState.compose env40475 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound40475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40476 : List Nat := [2,4,6,2,0,2,6,4,5,6,1,3,6,1,1,2,2,0,7,0,1,0,2,3,6,2,1,2,2,1,6,0,5,1,0,4]

theorem envBound40476 : H12AffineFastState.Bounded env40476 := by
  intro p hp
  have h : env40476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40475_40476 : H12AffineEnvironment.transform 3 2 env40475 = env40476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env40475 == env40476) = true)

def env40477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21793,41292,73856,8328,64,64725,46157,58461,35189,1500,32,257,21793,46212,74251]

theorem envBound40477 : H12AffineFastState.Bounded env40477 := by
  intro p hp
  have h : env40477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40461_40477 : H12AffineEnvironment.transform 16 49169 env40461 = env40477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40461 == env40477) = true)

theorem identity40477 : scanCanonicalize (H12AffineFastState.compose env40477 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound40477 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env40478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10281,1025,32769,4160,21793,41292,2,8328,64,64725,46157,58461,35189,1500,32,257,21793,46212,649]

theorem envBound40478 : H12AffineFastState.Bounded env40478 := by
  intro p hp
  have h : env40478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40477_40478 : H12AffineEnvironment.transform 15 8322 env40477 = env40478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env40477 == env40478) = true)

theorem identity40478 : scanCanonicalize (H12AffineFastState.compose env40478 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40478 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env40479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8322,46157,10281,1025,32769,4160,8573,41292,2,8328,64,34953,46157,36865,35189,1500,32,257,8573,46212,649]

theorem envBound40479 : H12AffineFastState.Bounded env40479 := by
  intro p hp
  have h : env40479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40478_40479 : H12AffineEnvironment.transform 13 13404 env40478 = env40479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40478 == env40479) = true)

theorem identity40479 : scanCanonicalize (H12AffineFastState.compose env40479 (packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40479 : packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env40480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5457,32768,399,38208,2340,1025,32769,4160,112,32833,2,389,64,34953,38208,36865,35189,1500,32,257,112,38281,649]

theorem envBound40480 : H12AffineFastState.Bounded env40480 := by
  intro p hp
  have h : env40480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40479_40480 : H12AffineEnvironment.transform 12 269 env40479 = env40480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40479 == env40480) = true)

theorem identity40480 : scanCanonicalize (H12AffineFastState.compose env40480 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound40480 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env40481 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5457,32768,343,38208,2340,1025,32769,4160,112,32833,2,349,64,34897,38208,36865,35189,1284,32,257,112,38225,593]

theorem envBound40481 : H12AffineFastState.Bounded env40481 := by
  intro p hp
  have h : env40481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40480_40481 : H12AffineEnvironment.transform 6 88 env40480 = env40481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env40480 == env40481) = true)

theorem identity40481 : scanCanonicalize (H12AffineFastState.compose env40481 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound40481 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40482 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5457,80,343,5392,2340,1025,81,4160,112,17,2,349,64,2049,5392,4177,2341,1284,32,257,112,5377,593]

theorem envBound40482 : H12AffineFastState.Bounded env40482 := by
  intro p hp
  have h : env40482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40481_40482 : H12AffineEnvironment.transform 14 80 env40481 = env40482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env40481 == env40482) = true)

theorem identity40482 : scanCanonicalize (H12AffineFastState.compose env40482 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound40482 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40483 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1,269,1360,80,343,1297,2340,1025,81,65,112,17,2,349,64,2049,1297,80,2341,1284,32,257,112,1280,593]

theorem envBound40483 : H12AffineFastState.Bounded env40483 := by
  intro p hp
  have h : env40483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40482_40483 : H12AffineEnvironment.transform 11 1 env40482 = env40483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env40482 == env40483) = true)

def env40484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,254097,8328,64,64724,160861,140364,303453,1501,272392,257,21793,46212,74250]

theorem envBound40484 : H12AffineFastState.Bounded env40484 := by
  intro p hp
  have h : env40484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40436_40484 : H12AffineEnvironment.transform 20 4161 env40436 = env40484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40436 == env40484) = true)

theorem identity40484 : scanCanonicalize (H12AffineFastState.compose env40484 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound40484 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,272512,62661,95496,8328,64,64724,57796,45525,303453,1501,272392,257,21793,46212,74250]

theorem envBound40485 : H12AffineFastState.Bounded env40485 := by
  intro p hp
  have h : env40485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40484_40485 : H12AffineEnvironment.transform 16 38297 env40484 = env40485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env40484 == env40485) = true)

theorem identity40485 : scanCanonicalize (H12AffineFastState.compose env40485 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40485 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38297,262144,1025,32769,4161,272512,62661,21763,8328,64,64724,57796,45525,303453,1501,272392,257,21793,46212,513]

theorem envBound40486 : H12AffineFastState.Bounded env40486 := by
  intro p hp
  have h : env40486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40485_40486 : H12AffineEnvironment.transform 15 8203 env40485 = env40486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40485 == env40486) = true)

theorem identity40486 : scanCanonicalize (H12AffineFastState.compose env40486 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 64928) := by decide +kernel

theorem selectedBound40486 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38297,64928,1025,32769,4161,54560,62661,21763,8328,64,64724,57796,45525,23805,1501,54696,257,21793,46212,513]

theorem envBound40487 : H12AffineFastState.Bounded env40487 := by
  intro p hp
  have h : env40487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40486_40487 : H12AffineEnvironment.transform 17 64928 env40486 = env40487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64928 env40486 == env40487) = true)

theorem identity40487 : scanCanonicalize (H12AffineFastState.compose env40487 (packedSelected [2,3,4,5,6,8,9,14,16,28] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound40487 : packedSelected [2,3,4,5,6,8,9,14,16,28] rootPS < 2^1333 := by decide +kernel

def env40488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,8203,5441,32120,1025,217,4161,22008,29725,21763,8328,64,31756,24860,12557,23805,1501,21872,257,21793,13404,513]

theorem envBound40488 : H12AffineFastState.Bounded env40488 := by
  intro p hp
  have h : env40488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40487_40488 : H12AffineEnvironment.transform 14 216 env40487 = env40488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env40487 == env40488) = true)

theorem identity40488 : scanCanonicalize (H12AffineFastState.compose env40488 (packedSelected [0,2,4,6,7,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound40488 : packedSelected [0,2,4,6,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env40489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,216,399,5441,23804,1025,217,4161,22008,21913,21763,268,64,23944,16536,4233,23805,1501,21872,257,21793,5592,513]

theorem envBound40489 : H12AffineFastState.Bounded env40489 := by
  intro p hp
  have h : env40489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40488_40489 : H12AffineEnvironment.transform 12 388 env40488 = env40489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env40488 == env40489) = true)

theorem identity40489 : scanCanonicalize (H12AffineFastState.compose env40489 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound40489 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5456,216,399,5441,2476,1025,217,4161,168,201,83,268,64,2264,5576,4233,2477,1501,32,257,113,5592,513]

theorem envBound40490 : H12AffineFastState.Bounded env40490 := by
  intro p hp
  have h : env40490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40489_40490 : H12AffineEnvironment.transform 13 5456 env40489 = env40490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env40489 == env40490) = true)

theorem identity40490 : scanCanonicalize (H12AffineFastState.compose env40490 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound40490 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40491 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,388,4113,216,399,4096,2476,320,217,4161,168,201,83,268,64,2264,4233,4233,2477,156,32,257,113,4249,513]

theorem envBound40491 : H12AffineFastState.Bounded env40491 := by
  intro p hp
  have h : env40491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40490_40491 : H12AffineEnvironment.transform 9 321 env40490 = env40491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env40490 == env40491) = true)

theorem identity40491 : scanCanonicalize (H12AffineFastState.compose env40491 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40491 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env40492 : List Nat := [2,4,8,16,32,64,128,36,512,101,2048,4096,160,4113,216,171,4096,2184,100,217,4161,168,201,83,40,64,2264,4233,4233,2185,156,32,37,113,4249,513]

theorem envBound40492 : H12AffineFastState.Bounded env40492 := by
  intro p hp
  have h : env40492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40491_40492 : H12AffineEnvironment.transform 7 36 env40491 = env40492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40491 == env40492) = true)

theorem identity40492 : scanCanonicalize (H12AffineFastState.compose env40492 (packedSelected [2,4,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40492 : packedSelected [2,4,7,11] rootPS < 2^1333 := by decide +kernel

def env40493 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,4096,160,4113,137,171,4096,2184,53,136,4112,168,152,2,40,17,2185,4233,4233,2185,156,32,37,32,4249,513]

theorem envBound40493 : H12AffineFastState.Bounded env40493 := by
  intro p hp
  have h : env40493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40492_40493 : H12AffineEnvironment.transform 5 17 env40492 = env40493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40492 == env40493) = true)

theorem identity40493 : scanCanonicalize (H12AffineFastState.compose env40493 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound40493 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40494 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,2065,160,2048,137,171,2065,2184,53,136,2049,168,152,2,40,17,2185,2200,2200,2185,156,32,37,32,2184,513]

theorem envBound40494 : H12AffineFastState.Bounded env40494 := by
  intro p hp
  have h : env40494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40493_40494 : H12AffineEnvironment.transform 11 2065 env40493 = env40494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env40493 == env40494) = true)

theorem identity40494 : scanCanonicalize (H12AffineFastState.compose env40494 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound40494 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40495 : List Nat := [2,4,8,16,32,17,128,36,512,52,137,152,160,137,137,171,152,1,53,136,136,168,152,2,40,17,0,17,17,0,156,32,37,32,1,513]

theorem envBound40495 : H12AffineFastState.Bounded env40495 := by
  intro p hp
  have h : env40495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40494_40495 : H12AffineEnvironment.transform 10 137 env40494 = env40495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env40494 == env40495) = true)

def env40496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound40496 : H12AffineFastState.Bounded env40496 := by
  intro p hp
  have h : env40496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39727_40496 : H12AffineEnvironment.transform 25 65 env39727 = env40496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env39727 == env40496) = true)

def env40497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound40497 : H12AffineFastState.Bounded env40497 := by
  intro p hp
  have h : env40497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40496_40497 : H12AffineEnvironment.transform 26 30393344 env40496 = env40497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env40496 == env40497) = true)

def env40498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound40498 : H12AffineFastState.Bounded env40498 := by
  intro p hp
  have h : env40498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40497_40498 : H12AffineEnvironment.transform 18 1024 env40497 = env40498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env40497 == env40498) = true)

theorem identity40498 : scanCanonicalize (H12AffineFastState.compose env40498 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437745) := by decide +kernel

theorem selectedBound40498 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,8388608,16777216,8328,65,29868032,17246589,8845473,8830977,25265169,21481521,256,25651548,25659641,25207750]

theorem envBound40499 : H12AffineFastState.Bounded env40499 := by
  intro p hp
  have h : env40499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40498_40499 : H12AffineEnvironment.transform 20 437745 env40498 = env40499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env40498 == env40499) = true)

def env40500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,8388608,8862844,8328,65,4258940,8393985,8845473,8830977,440429,12645453,256,21792,46213,499642]

theorem envBound40500 : H12AffineFastState.Bounded env40500 := by
  intro p hp
  have h : env40500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40499_40500 : H12AffineEnvironment.transform 23 8862844 env40499 = env40500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862844 env40499 == env40500) = true)

def env40501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441760,98780,8328,65,4258940,436385,17665,32161,440429,4606445,256,21792,46213,499642]

theorem envBound40501 : H12AffineFastState.Bounded env40501 := by
  intro p hp
  have h : env40501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40500_40501 : H12AffineEnvironment.transform 22 441760 env40500 = env40501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env40500 == env40501) = true)

def env40502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441760,98780,8328,65,316668,436385,17665,32161,440429,156013,256,21792,46213,499642]

theorem envBound40502 : H12AffineFastState.Bounded env40502 := by
  intro p hp
  have h : env40502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40501_40502 : H12AffineEnvironment.transform 21 272512 env40501 = env40502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env40501 == env40502) = true)

theorem identity40502 : scanCanonicalize (H12AffineFastState.compose env40502 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound40502 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416036,272512,412021,95497,8328,65,270377,416884,17665,32161,412856,156013,256,21792,16464,486255]

theorem envBound40503 : H12AffineFastState.Bounded env40503 := by
  intro p hp
  have h : env40503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40502_40503 : H12AffineEnvironment.transform 14 29909 env40502 = env40503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env40502 == env40503) = true)

def env40504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,160132,32,156117,95497,8328,65,2185,160980,17665,32161,156696,156013,256,21792,16464,213967]

theorem envBound40504 : H12AffineFastState.Bounded env40504 := by
  intro p hp
  have h : env40504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40503_40504 : H12AffineEnvironment.transform 17 10400 env40503 = env40504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env40503 == env40504) = true)

theorem identity40504 : scanCanonicalize (H12AffineFastState.compose env40504 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 79079) := by decide +kernel

theorem selectedBound40504 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env40505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79079,10400,1024,29908,83299,32,87346,95497,8328,65,2185,81971,17665,32161,86271,87434,256,21792,16464,30504]

theorem envBound40505 : H12AffineFastState.Bounded env40505 := by
  intro p hp
  have h : env40505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40504_40505 : H12AffineEnvironment.transform 16 79079 env40504 = env40505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79079 env40504 == env40505) = true)

theorem identity40505 : scanCanonicalize (H12AffineFastState.compose env40505 (packedSelected [0,1,2,4,5,6,9,11,15,17,18,19,20,24,26,27,28,31,41] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound40505 : packedSelected [0,1,2,4,5,6,9,11,15,17,18,19,20,24,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env40506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,170,13389,10400,1024,29908,17865,32,21912,30115,8328,65,2185,16537,17665,32161,20565,21792,256,21792,16464,30504]

theorem envBound40506 : H12AffineFastState.Bounded env40506 := by
  intro p hp
  have h : env40506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40505_40506 : H12AffineEnvironment.transform 15 170 env40505 = env40506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env40505 == env40506) = true)

theorem identity40506 : scanCanonicalize (H12AffineFastState.compose env40506 (packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound40506 : packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8353,170,13389,10400,1024,8352,4541,32,492,8663,8328,65,2185,5357,4469,10709,1057,340,256,340,5156,9052]

theorem envBound40507 : H12AffineFastState.Bounded env40507 := by
  intro p hp
  have h : env40507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40506_40507 : H12AffineEnvironment.transform 13 5236 env40506 = env40507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env40506 == env40507) = true)

theorem identity40507 : scanCanonicalize (H12AffineFastState.compose env40507 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40507 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env40508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,137,170,5221,2184,1024,136,4541,32,492,511,160,65,2185,5357,4469,2557,1057,340,256,340,5156,884]

theorem envBound40508 : H12AffineFastState.Bounded env40508 := by
  intro p hp
  have h : env40508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40507_40508 : H12AffineEnvironment.transform 12 40 env40507 = env40508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40507 == env40508) = true)

theorem identity40508 : scanCanonicalize (H12AffineFastState.compose env40508 (packedSelected [0,1,3,5,7,8,12,14,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound40508 : packedSelected [0,1,3,5,7,8,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1140,40,0,137,170,17,2184,1024,136,1481,32,492,511,160,65,2185,153,1281,2557,1057,340,256,340,80,884]

theorem envBound40509 : H12AffineFastState.Bounded env40509 := by
  intro p hp
  have h : env40509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40508_40509 : H12AffineEnvironment.transform 11 1140 env40508 = env40509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env40508 == env40509) = true)

theorem identity40509 : scanCanonicalize (H12AffineFastState.compose env40509 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40509 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env40510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,40,0,0,35,17,2049,1024,1,1344,32,357,374,41,65,2048,16,1281,2420,1057,340,256,340,80,884]

theorem envBound40510 : H12AffineFastState.Bounded env40510 := by
  intro p hp
  have h : env40510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40509_40510 : H12AffineEnvironment.transform 6 9 env40509 = env40510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40509 == env40510) = true)

theorem identity40510 : scanCanonicalize (H12AffineFastState.compose env40510 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40510 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40511 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,40,0,0,35,17,2049,1024,1,1296,32,309,294,41,17,2048,16,1281,2340,1057,260,256,260,0,804]

theorem envBound40511 : H12AffineFastState.Bounded env40511 := by
  intro p hp
  have h : env40511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40510_40511 : H12AffineEnvironment.transform 5 16 env40510 = env40511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40510 == env40511) = true)

theorem identity40511 : scanCanonicalize (H12AffineFastState.compose env40511 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40511 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env40512 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,1060,40,0,0,35,17,2049,1024,1,1044,32,49,34,41,17,2048,16,1029,2080,1057,0,4,0,0,544]

theorem envBound40512 : H12AffineFastState.Bounded env40512 := by
  intro p hp
  have h : env40512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40511_40512 : H12AffineEnvironment.transform 7 4 env40511 = env40512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40511 == env40512) = true)

def env40513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,160133,33,156116,95497,8328,65,2184,160981,17665,32161,156697,156013,256,21792,16464,213966]

theorem envBound40513 : H12AffineFastState.Bounded env40513 := by
  intro p hp
  have h : env40513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40503_40513 : H12AffineEnvironment.transform 17 10401 env40503 = env40513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env40503 == env40513) = true)

theorem identity40513 : scanCanonicalize (H12AffineFastState.compose env40513 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40513 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env40514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,10401,1024,29908,70047,33,65998,95497,8328,65,2184,70863,17665,32161,66563,65911,256,21792,16464,9172]

theorem envBound40514 : H12AffineFastState.Bounded env40514 := by
  intro p hp
  have h : env40514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40513_40514 : H12AffineEnvironment.transform 16 90138 env40513 = env40514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40513 == env40514) = true)

theorem identity40514 : scanCanonicalize (H12AffineFastState.compose env40514 (packedSelected [0,1,3,9,17,18,19,22,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound40514 : packedSelected [0,1,3,9,17,18,19,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21590,13388,10401,1024,29908,17865,33,21912,8543,8328,65,2184,16537,17665,32161,20565,21793,256,21792,16464,9172]

theorem envBound40515 : H12AffineFastState.Bounded env40515 := by
  intro p hp
  have h : env40515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40514_40515 : H12AffineEnvironment.transform 15 21590 env40514 = env40515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env40514 == env40515) = true)

theorem identity40515 : scanCanonicalize (H12AffineFastState.compose env40515 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40515 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env40516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,8203,13388,10401,1024,137,12692,33,8645,8543,8328,65,2184,13508,12636,2556,9224,8572,256,8573,13325,9172]

theorem envBound40516 : H12AffineFastState.Bounded env40516 := by
  intro p hp
  have h : env40516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40515_40516 : H12AffineEnvironment.transform 13 13405 env40515 = env40516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40515 == env40516) = true)

theorem identity40516 : scanCanonicalize (H12AffineFastState.compose env40516 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40516 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env40517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,342,5393,2556,1024,137,4297,33,152,2,469,65,2184,5529,4097,2556,1365,33,256,32,5456,649]

theorem envBound40517 : H12AffineFastState.Bounded env40517 := by
  intro p hp
  have h : env40517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40516_40517 : H12AffineEnvironment.transform 12 349 env40516 = env40517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40516 == env40517) = true)

theorem identity40517 : scanCanonicalize (H12AffineFastState.compose env40517 (packedSelected [11,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40517 : packedSelected [11,14] rootPS < 2^1333 := by decide +kernel

def env40518 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5236,136,34,5221,2184,1024,137,4297,33,152,2,161,65,2184,5357,4097,2184,1057,33,116,32,5156,649]

theorem envBound40518 : H12AffineFastState.Bounded env40518 := by
  intro p hp
  have h : env40518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40517_40518 : H12AffineEnvironment.transform 7 116 env40517 = env40518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40517 == env40518) = true)

theorem identity40518 : scanCanonicalize (H12AffineFastState.compose env40518 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound40518 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40519 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,41,5236,81,34,5221,2129,1024,80,4112,33,65,2,120,65,2129,5172,4097,2129,1057,33,116,32,5156,592]

theorem envBound40519 : H12AffineFastState.Bounded env40519 := by
  intro p hp
  have h : env40519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40518_40519 : H12AffineEnvironment.transform 6 89 env40518 = env40519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env40518 == env40519) = true)

theorem identity40519 : scanCanonicalize (H12AffineFastState.compose env40519 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40520 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,34,5173,2049,1024,0,4112,33,17,2,40,17,2049,5172,4097,2049,1057,33,36,32,5156,512]

theorem envBound40520 : H12AffineFastState.Bounded env40520 := by
  intro p hp
  have h : env40520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40519_40520 : H12AffineEnvironment.transform 5 16 env40519 = env40520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40519 == env40520) = true)

theorem identity40520 : scanCanonicalize (H12AffineFastState.compose env40520 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40520 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40521 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,4096,9,5124,1,2,5141,2049,1024,0,4112,1,17,2,8,17,2049,5140,4097,2049,1025,1,4,0,5124,512]

theorem envBound40521 : H12AffineFastState.Bounded env40521 := by
  intro p hp
  have h : env40521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40520_40521 : H12AffineEnvironment.transform 4 0 env40520 = env40521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40520 == env40521) = true)

theorem identity40521 : scanCanonicalize (H12AffineFastState.compose env40521 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound40521 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40522 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,1028,9,0,1,2,17,2049,1024,0,1044,1,17,2,8,17,2049,16,1029,2049,1025,1,4,0,0,512]

theorem envBound40522 : H12AffineFastState.Bounded env40522 := by
  intro p hp
  have h : env40522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40521_40522 : H12AffineEnvironment.transform 11 1028 env40521 = env40522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env40521 == env40522) = true)

theorem identity40522 : scanCanonicalize (H12AffineFastState.compose env40522 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40523 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1028,9,0,1,2,17,2049,1024,0,1044,1,17,2,8,17,2049,16,1029,2049,1025,1,4,0,0,0]

theorem envBound40523 : H12AffineFastState.Bounded env40523 := by
  intro p hp
  have h : env40523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40522_40523 : H12AffineEnvironment.transform 8 0 env40522 = env40523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40522 == env40523) = true)

theorem identity40523 : scanCanonicalize (H12AffineFastState.compose env40523 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40523 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40524 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1,1028,9,0,1,2,17,0,1024,0,1044,1,17,2,8,17,0,16,1029,0,1025,1,4,0,0,0]

theorem envBound40524 : H12AffineFastState.Bounded env40524 := by
  intro p hp
  have h : env40524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40523_40524 : H12AffineEnvironment.transform 10 1 env40523 = env40524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40523 == env40524) = true)

theorem identity40524 : scanCanonicalize (H12AffineFastState.compose env40524 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound40524 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40525 : List Nat := [2,4,8,16,0,16,9,4,0,20,1,16,9,0,1,2,17,0,20,0,0,1,17,2,8,17,0,16,17,0,21,1,4,0,0,0]

theorem envBound40525 : H12AffineFastState.Bounded env40525 := by
  intro p hp
  have h : env40525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40524_40525 : H12AffineEnvironment.transform 9 20 env40524 = env40525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40524 == env40525) = true)

theorem identity40525 : scanCanonicalize (H12AffineFastState.compose env40525 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound40525 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40526 : List Nat := [2,4,8,4,0,4,9,4,0,0,1,4,9,0,1,2,5,0,0,0,0,1,5,2,8,5,0,4,5,0,1,1,4,0,0,0]

theorem envBound40526 : H12AffineFastState.Bounded env40526 := by
  intro p hp
  have h : env40526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40525_40526 : H12AffineEnvironment.transform 3 4 env40525 = env40526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env40525 == env40526) = true)

def env40527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441760,98780,8328,65,316669,436385,17665,32161,440429,156012,256,21792,46213,499642]

theorem envBound40527 : H12AffineFastState.Bounded env40527 := by
  intro p hp
  have h : env40527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40501_40527 : H12AffineEnvironment.transform 21 272513 env40501 = env40527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env40501 == env40527) = true)

theorem identity40527 : scanCanonicalize (H12AffineFastState.compose env40527 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound40527 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,58516,156132,62661,98780,8328,65,171416,57796,17665,32161,61704,156012,256,21792,46213,120543]

theorem envBound40528 : H12AffineFastState.Bounded env40528 := by
  intro p hp
  have h : env40528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40527_40528 : H12AffineEnvironment.transform 17 149861 env40527 = env40528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env40527 == env40528) = true)

def env40529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,56573,1024,32769,58516,62588,62661,98780,8328,65,2048,57796,17665,32161,61704,62708,256,21792,46213,120543]

theorem envBound40529 : H12AffineFastState.Bounded env40529 := by
  intro p hp
  have h : env40529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40528_40529 : H12AffineEnvironment.transform 16 38296 env40528 = env40529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env40528 == env40529) = true)

def env40530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38296,35325,1024,32769,45460,41340,41413,98780,8328,65,2048,46276,4097,10401,41992,41460,256,32,46213,99295]

theorem envBound40530 : H12AffineFastState.Bounded env40530 := by
  intro p hp
  have h : env40530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40529_40530 : H12AffineEnvironment.transform 13 5376 env40529 = env40530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40529 == env40530) = true)

theorem identity40530 : scanCanonicalize (H12AffineFastState.compose env40530 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40530 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,13508,10401,1024,8541,4296,32,153,73856,8328,65,2048,5528,4097,10401,1364,168,256,32,5593,74371]

theorem envBound40531 : H12AffineFastState.Bounded env40531 := by
  intro p hp
  have h : env40531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40530_40531 : H12AffineEnvironment.transform 14 8540 env40530 = env40531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40530 == env40531) = true)

theorem identity40531 : scanCanonicalize (H12AffineFastState.compose env40531 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound40531 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,13508,10401,1024,8541,4296,32,153,2,8328,65,2048,5528,4097,10401,1364,168,256,32,5593,513]

theorem envBound40532 : H12AffineFastState.Bounded env40532 := by
  intro p hp
  have h : env40532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40531_40532 : H12AffineEnvironment.transform 15 8322 env40531 = env40532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env40531 == env40532) = true)

theorem identity40532 : scanCanonicalize (H12AffineFastState.compose env40532 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40532 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,81,399,5577,2476,1024,80,4296,32,153,2,389,65,2048,5528,4097,2476,1364,168,256,32,5593,513]

theorem envBound40533 : H12AffineFastState.Bounded env40533 := by
  intro p hp
  have h : env40533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40532_40533 : H12AffineEnvironment.transform 12 269 env40532 = env40533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40532 == env40533) = true)

def env40534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38296,35324,1024,32769,45461,41341,41412,98780,8328,65,2048,46277,4096,10400,41993,41461,256,33,46213,99294]

theorem envBound40534 : H12AffineFastState.Bounded env40534 := by
  intro p hp
  have h : env40534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40529_40534 : H12AffineEnvironment.transform 13 5377 env40529 = env40534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40529 == env40534) = true)

theorem identity40534 : scanCanonicalize (H12AffineFastState.compose env40534 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound40534 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,10281,1024,8660,4160,168,17,73737,8328,65,2048,5392,4096,10400,1500,32,256,33,5456,74251]

theorem envBound40535 : H12AffineFastState.Bounded env40535 := by
  intro p hp
  have h : env40535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40534_40535 : H12AffineEnvironment.transform 14 8661 env40534 = env40535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env40534 == env40535) = true)

theorem identity40535 : scanCanonicalize (H12AffineFastState.compose env40535 (packedSelected [0,1,2,3,4,5,7,8,9,10,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40535 : packedSelected [0,1,2,3,4,5,7,8,9,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40536 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,65536,13340,10281,1024,8581,4113,168,17,73737,8328,16,2048,5392,4096,10400,1421,32,256,33,5377,74251]

theorem envBound40536 : H12AffineFastState.Bounded env40536 := by
  intro p hp
  have h : env40536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40535_40536 : H12AffineEnvironment.transform 5 17 env40535 = env40536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40535 == env40536) = true)

theorem identity40536 : scanCanonicalize (H12AffineFastState.compose env40536 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound40536 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env40537 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,8322,13340,10281,1024,8581,4113,168,17,139,8328,16,2048,5392,4096,10400,1421,32,256,33,5377,649]

theorem envBound40537 : H12AffineFastState.Bounded env40537 := by
  intro p hp
  have h : env40537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40536_40537 : H12AffineEnvironment.transform 15 8322 env40536 = env40537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env40536 == env40537) = true)

theorem identity40537 : scanCanonicalize (H12AffineFastState.compose env40537 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound40537 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40538 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,1,263,5529,2476,1024,0,4113,168,17,139,269,16,2048,5392,4096,2341,1421,32,256,33,5377,649]

theorem envBound40538 : H12AffineFastState.Bounded env40538 := by
  intro p hp
  have h : env40538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40537_40538 : H12AffineEnvironment.transform 12 389 env40537 = env40538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env40537 == env40538) = true)

theorem identity40538 : scanCanonicalize (H12AffineFastState.compose env40538 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40538 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40539 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1024,0,4113,32,17,3,269,16,2048,5392,4096,2341,1285,32,256,33,5377,513]

theorem envBound40539 : H12AffineFastState.Bounded env40539 := by
  intro p hp
  have h : env40539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40538_40539 : H12AffineEnvironment.transform 6 8 env40538 = env40539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40538 == env40539) = true)

theorem identity40539 : scanCanonicalize (H12AffineFastState.compose env40539 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound40539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40540 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,308,269,1077,1,263,1061,2340,1024,0,293,32,17,3,269,16,2048,1060,308,2341,1285,32,256,33,1077,513]

theorem envBound40540 : H12AffineFastState.Bounded env40540 := by
  intro p hp
  have h : env40540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40539_40540 : H12AffineEnvironment.transform 11 308 env40539 = env40540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env40539 == env40540) = true)

theorem identity40540 : scanCanonicalize (H12AffineFastState.compose env40540 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound40540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40541 : List Nat := [2,4,8,16,32,17,8,256,512,1024,815,308,269,1077,1,263,1061,523,1024,0,293,32,17,3,269,16,815,1060,308,522,1285,32,256,33,1077,513]

theorem envBound40541 : H12AffineFastState.Bounded env40541 := by
  intro p hp
  have h : env40541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40540_40541 : H12AffineEnvironment.transform 10 815 env40540 = env40541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env40540 == env40541) = true)

theorem identity40541 : scanCanonicalize (H12AffineFastState.compose env40541 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound40541 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40542 : List Nat := [2,4,8,16,32,17,8,256,512,542,815,308,269,555,1,263,571,523,542,0,293,32,17,3,269,16,815,570,308,522,795,32,256,33,555,513]

theorem envBound40542 : H12AffineFastState.Bounded env40542 := by
  intro p hp
  have h : env40542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40541_40542 : H12AffineEnvironment.transform 9 542 env40541 = env40542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env40541 == env40542) = true)

theorem identity40542 : scanCanonicalize (H12AffineFastState.compose env40542 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound40542 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40543 : List Nat := [2,4,8,16,32,17,8,256,302,304,1,308,269,261,1,263,277,293,304,0,293,32,17,3,269,16,1,276,308,292,53,32,256,33,261,303]

theorem envBound40543 : H12AffineFastState.Bounded env40543 := by
  intro p hp
  have h : env40543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40542_40543 : H12AffineEnvironment.transform 8 302 env40542 = env40543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env40542 == env40543) = true)

theorem identity40543 : scanCanonicalize (H12AffineFastState.compose env40543 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40543 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40544 : List Nat := [2,4,8,16,32,17,8,5,43,53,1,49,8,0,1,2,16,32,53,0,32,32,17,3,8,16,1,17,49,33,53,32,5,33,0,42]

theorem envBound40544 : H12AffineFastState.Bounded env40544 := by
  intro p hp
  have h : env40544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40543_40544 : H12AffineEnvironment.transform 7 5 env40543 = env40544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40543 == env40544) = true)

theorem identity40544 : scanCanonicalize (H12AffineFastState.compose env40544 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40544 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40545 : List Nat := [2,4,8,16,1,17,8,5,10,20,1,16,8,0,1,2,16,1,20,0,1,1,17,3,8,16,1,17,16,0,20,1,5,0,0,11]

theorem envBound40545 : H12AffineFastState.Bounded env40545 := by
  intro p hp
  have h : env40545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40544_40545 : H12AffineEnvironment.transform 4 1 env40544 = env40545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40544 == env40545) = true)

theorem identity40545 : scanCanonicalize (H12AffineFastState.compose env40545 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40545 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40546 : List Nat := [2,0,8,16,1,17,8,1,10,16,1,16,8,0,1,2,16,1,16,0,1,1,17,3,8,16,1,17,16,0,16,1,1,0,0,11]

theorem envBound40546 : H12AffineFastState.Bounded env40546 := by
  intro p hp
  have h : env40546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40545_40546 : H12AffineEnvironment.transform 1 0 env40545 = env40546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40545 == env40546) = true)

theorem identity40546 : scanCanonicalize (H12AffineFastState.compose env40546 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40546 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40547 : List Nat := [0,0,8,16,1,17,8,1,8,16,1,16,8,0,1,0,16,1,16,0,1,1,17,1,8,16,1,17,16,0,16,1,1,0,0,9]

theorem envBound40547 : H12AffineFastState.Bounded env40547 := by
  intro p hp
  have h : env40547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40546_40547 : H12AffineEnvironment.transform 0 0 env40546 = env40547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40546 == env40547) = true)

def env40548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,56572,1024,32769,58516,62589,62661,98780,8328,65,2049,57796,17665,32161,61704,62709,256,21792,46213,120543]

theorem envBound40548 : H12AffineFastState.Bounded env40548 := by
  intro p hp
  have h : env40548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40528_40548 : H12AffineEnvironment.transform 16 38297 env40528 = env40548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env40528 == env40548) = true)

def env40549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38297,35324,1024,32769,45460,41341,41413,98780,8328,65,2049,46276,4097,10401,41992,41461,256,32,46213,99295]

theorem envBound40549 : H12AffineFastState.Bounded env40549 := by
  intro p hp
  have h : env40549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40548_40549 : H12AffineEnvironment.transform 13 5376 env40548 = env40549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40548 == env40549) = true)

theorem identity40549 : scanCanonicalize (H12AffineFastState.compose env40549 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40549 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35188,1024,32769,45340,41341,41293,98644,8192,65,2049,46156,4097,10281,41992,41341,256,32,46093,99159]

theorem envBound40550 : H12AffineFastState.Bounded env40550 := by
  intro p hp
  have h : env40550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40549_40550 : H12AffineEnvironment.transform 6 8 env40549 = env40550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40549 == env40550) = true)

theorem identity40550 : scanCanonicalize (H12AffineFastState.compose env40550 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40550 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13388,10281,1024,8540,4161,32,16,73737,8192,65,2049,5393,4097,10281,1365,32,256,32,5456,74250]

theorem envBound40551 : H12AffineFastState.Bounded env40551 := by
  intro p hp
  have h : env40551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40550_40551 : H12AffineEnvironment.transform 14 8541 env40550 = env40551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40550 == env40551) = true)

theorem identity40551 : scanCanonicalize (H12AffineFastState.compose env40551 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound40551 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40552 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,5205,8200,65536,13388,10281,1024,8201,4161,32,16,73737,8192,65,2049,5188,4097,10281,1024,32,85,32,5125,74250]

theorem envBound40552 : H12AffineFastState.Bounded env40552 := by
  intro p hp
  have h : env40552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40551_40552 : H12AffineEnvironment.transform 7 85 env40551 = env40552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env40551 == env40552) = true)

theorem identity40552 : scanCanonicalize (H12AffineFastState.compose env40552 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40552 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40553 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,5205,8200,8203,13388,10281,1024,8201,4161,32,16,2,8192,65,2049,5188,4097,10281,1024,32,85,32,5125,513]

theorem envBound40553 : H12AffineFastState.Bounded env40553 := by
  intro p hp
  have h : env40553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40552_40553 : H12AffineEnvironment.transform 15 8203 env40552 = env40553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40552 == env40553) = true)

theorem identity40553 : scanCanonicalize (H12AffineFastState.compose env40553 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound40553 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40554 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,88,5205,80,83,5140,2161,1024,81,4161,32,16,2,88,65,2049,5188,4097,2161,1024,32,85,32,5125,513]

theorem envBound40554 : H12AffineFastState.Bounded env40554 := by
  intro p hp
  have h : env40554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40553_40554 : H12AffineEnvironment.transform 12 88 env40553 = env40554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env40553 == env40554) = true)

theorem identity40554 : scanCanonicalize (H12AffineFastState.compose env40554 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound40554 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40555 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,1540,88,593,80,83,528,2161,1024,81,1605,32,16,2,88,65,2049,576,1541,2161,1024,32,85,32,513,513]

theorem envBound40555 : H12AffineFastState.Bounded env40555 := by
  intro p hp
  have h : env40555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40554_40555 : H12AffineEnvironment.transform 11 1540 env40554 = env40555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env40554 == env40555) = true)

theorem identity40555 : scanCanonicalize (H12AffineFastState.compose env40555 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound40555 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40556 : List Nat := [2,4,8,16,32,64,8,85,512,1024,64,1540,88,593,80,83,528,49,1024,81,1605,32,16,2,88,65,65,576,1541,49,1024,32,85,32,513,513]

theorem envBound40556 : H12AffineFastState.Bounded env40556 := by
  intro p hp
  have h : env40556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40555_40556 : H12AffineEnvironment.transform 10 64 env40555 = env40556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env40555 == env40556) = true)

theorem identity40556 : scanCanonicalize (H12AffineFastState.compose env40556 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40556 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40557 : List Nat := [2,4,8,16,32,16,8,5,512,1024,16,1540,8,513,0,3,528,49,1024,1,1557,32,16,2,8,17,17,528,1541,49,1024,32,5,32,513,513]

theorem envBound40557 : H12AffineFastState.Bounded env40557 := by
  intro p hp
  have h : env40557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40556_40557 : H12AffineEnvironment.transform 5 16 env40556 = env40557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40556 == env40557) = true)

theorem identity40557 : scanCanonicalize (H12AffineFastState.compose env40557 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40558 : List Nat := [2,4,8,16,32,16,8,5,512,53,16,561,8,513,0,3,528,49,53,1,544,32,16,2,8,17,17,528,560,49,53,32,5,32,513,513]

theorem envBound40558 : H12AffineFastState.Bounded env40558 := by
  intro p hp
  have h : env40558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40557_40558 : H12AffineEnvironment.transform 9 53 env40557 = env40558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40557 == env40558) = true)

theorem identity40558 : scanCanonicalize (H12AffineFastState.compose env40558 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound40558 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40559 : List Nat := [2,4,8,16,26,16,8,5,512,15,16,523,8,513,0,3,528,11,15,1,538,26,16,2,8,17,17,528,522,11,15,26,5,26,513,513]

theorem envBound40559 : H12AffineFastState.Bounded env40559 := by
  intro p hp
  have h : env40559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40558_40559 : H12AffineEnvironment.transform 4 26 env40558 = env40559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env40558 == env40559) = true)

theorem identity40559 : scanCanonicalize (H12AffineFastState.compose env40559 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40559 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40560 : List Nat := [2,4,8,1,11,1,8,5,512,15,1,523,8,513,0,3,513,11,15,1,523,11,1,2,8,0,0,513,522,11,15,11,5,11,513,513]

theorem envBound40560 : H12AffineFastState.Bounded env40560 := by
  intro p hp
  have h : env40560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40559_40560 : H12AffineEnvironment.transform 3 1 env40559 = env40560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40559 == env40560) = true)

theorem identity40560 : scanCanonicalize (H12AffineFastState.compose env40560 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40561 : List Nat := [2,1,8,1,11,1,8,0,512,10,1,523,8,513,0,3,513,11,10,1,523,11,1,2,8,0,0,513,522,11,10,11,0,11,513,513]

theorem envBound40561 : H12AffineFastState.Bounded env40561 := by
  intro p hp
  have h : env40561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40560_40561 : H12AffineEnvironment.transform 1 1 env40560 = env40561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40560 == env40561) = true)

theorem identity40561 : scanCanonicalize (H12AffineFastState.compose env40561 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound40561 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40562 : List Nat := [2,1,8,1,11,1,8,0,10,10,1,1,8,11,0,3,11,11,10,1,1,11,1,2,8,0,0,11,0,11,10,11,0,11,11,11]

theorem envBound40562 : H12AffineFastState.Bounded env40562 := by
  intro p hp
  have h : env40562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40561_40562 : H12AffineEnvironment.transform 8 10 env40561 = env40562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env40561 == env40562) = true)

theorem identity40562 : scanCanonicalize (H12AffineFastState.compose env40562 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound40562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40563 : List Nat := [2,1,0,1,3,1,0,0,2,2,1,1,0,3,0,3,3,3,2,1,1,3,1,2,0,0,0,3,0,3,2,3,0,3,3,3]

theorem envBound40563 : H12AffineFastState.Bounded env40563 := by
  intro p hp
  have h : env40563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40562_40563 : H12AffineEnvironment.transform 2 0 env40562 = env40563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env40562 == env40563) = true)

def env40564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38297,35325,1024,32769,45461,41340,41412,98780,8328,65,2049,46277,4096,10400,41993,41460,256,33,46213,99294]

theorem envBound40564 : H12AffineFastState.Bounded env40564 := by
  intro p hp
  have h : env40564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40548_40564 : H12AffineEnvironment.transform 13 5377 env40548 = env40564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40548 == env40564) = true)

theorem identity40564 : scanCanonicalize (H12AffineFastState.compose env40564 (packedSelected [0,1,4,5,7,8,10,16,18,20,22,23,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound40564 : packedSelected [0,1,4,5,7,8,10,16,18,20,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env40565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8282,38297,35325,1024,32769,45461,41340,41412,41350,8328,65,2049,46277,4096,10400,41993,41460,256,33,46213,41860]

theorem envBound40565 : H12AffineFastState.Bounded env40565 := by
  intro p hp
  have h : env40565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40564_40565 : H12AffineEnvironment.transform 15 8282 env40564 = env40565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env40564 == env40565) = true)

theorem identity40565 : scanCanonicalize (H12AffineFastState.compose env40565 (packedSelected [3,4,7,9,10,18,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound40565 : packedSelected [3,4,7,9,10,18,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8282,13389,10281,1024,8661,4161,168,16,82,8328,65,2049,5393,4096,10400,1501,32,256,33,5457,592]

theorem envBound40566 : H12AffineFastState.Bounded env40566 := by
  intro p hp
  have h : env40566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40565_40566 : H12AffineEnvironment.transform 14 8660 env40565 = env40566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env40565 == env40566) = true)

theorem identity40566 : scanCanonicalize (H12AffineFastState.compose env40566 (packedSelected [2,3,4,5,9,10,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound40566 : packedSelected [2,3,4,5,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env40567 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,8192,5377,8493,8282,13389,10281,1024,8492,4161,81,16,82,8305,65,2049,5393,4096,10329,1316,32,256,33,5457,592]

theorem envBound40567 : H12AffineFastState.Bounded env40567 := by
  intro p hp
  have h : env40567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40566_40567 : H12AffineEnvironment.transform 6 121 env40566 = env40567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env40566 == env40567) = true)

theorem identity40567 : scanCanonicalize (H12AffineFastState.compose env40567 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40567 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40568 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,5377,8493,8203,13340,10281,1024,8492,4112,0,16,3,8224,16,2049,5393,4096,10248,1316,32,256,33,5376,513]

theorem envBound40568 : H12AffineFastState.Bounded env40568 := by
  intro p hp
  have h : env40568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40567_40568 : H12AffineEnvironment.transform 5 17 env40567 = env40568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40567 == env40568) = true)

theorem identity40568 : scanCanonicalize (H12AffineFastState.compose env40568 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40568 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40569 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,13340,10249,1024,8460,4112,0,16,3,8192,16,2049,5393,4096,10248,1284,0,256,1,5376,513]

theorem envBound40569 : H12AffineFastState.Bounded env40569 := by
  intro p hp
  have h : env40569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40568_40569 : H12AffineEnvironment.transform 4 0 env40568 = env40569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40568 == env40569) = true)

theorem identity40569 : scanCanonicalize (H12AffineFastState.compose env40569 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40569 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env40570 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8192,5124,8200,8203,13340,10249,1024,8201,4112,0,16,3,8192,16,2049,5140,4096,10248,1025,0,5,1,5125,513]

theorem envBound40570 : H12AffineFastState.Bounded env40570 := by
  intro p hp
  have h : env40570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40569_40570 : H12AffineEnvironment.transform 7 5 env40569 = env40570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40569 == env40570) = true)

theorem identity40570 : scanCanonicalize (H12AffineFastState.compose env40570 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound40570 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40571 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5124,0,3,5140,2049,1024,1,4112,0,16,3,8,16,2049,5140,4096,2048,1025,0,5,1,5125,513]

theorem envBound40571 : H12AffineFastState.Bounded env40571 := by
  intro p hp
  have h : env40571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40570_40571 : H12AffineEnvironment.transform 12 8 env40570 = env40571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env40570 == env40571) = true)

theorem identity40571 : scanCanonicalize (H12AffineFastState.compose env40571 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound40571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40572 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,1044,8,16,0,3,0,2049,1024,1,1028,0,16,3,8,16,2049,0,1044,2048,1025,0,5,1,17,513]

theorem envBound40572 : H12AffineFastState.Bounded env40572 := by
  intro p hp
  have h : env40572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40571_40572 : H12AffineEnvironment.transform 11 1044 env40571 = env40572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env40571 == env40572) = true)

theorem identity40572 : scanCanonicalize (H12AffineFastState.compose env40572 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound40572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40573 : List Nat := [2,4,8,16,0,17,8,5,512,533,2048,513,8,16,0,3,0,2049,533,1,529,0,16,3,8,16,2049,0,513,2048,532,0,5,1,17,513]

theorem envBound40573 : H12AffineFastState.Bounded env40573 := by
  intro p hp
  have h : env40573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40572_40573 : H12AffineEnvironment.transform 9 533 env40572 = env40573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env40572 == env40573) = true)

theorem identity40573 : scanCanonicalize (H12AffineFastState.compose env40573 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound40573 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40574 : List Nat := [2,4,8,16,0,17,8,5,512,533,17,513,8,16,0,3,0,16,533,1,529,0,16,3,8,16,16,0,513,17,532,0,5,1,17,513]

theorem envBound40574 : H12AffineFastState.Bounded env40574 := by
  intro p hp
  have h : env40574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40573_40574 : H12AffineEnvironment.transform 10 17 env40573 = env40574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env40573 == env40574) = true)

def env40575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441761,98781,8328,65,4258940,436384,17664,32160,440429,4606444,256,21792,46213,499642]

theorem envBound40575 : H12AffineFastState.Bounded env40575 := by
  intro p hp
  have h : env40575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40500_40575 : H12AffineEnvironment.transform 22 441761 env40500 = env40575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env40500 == env40575) = true)

def env40576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441761,98781,8328,65,316668,436384,17664,32160,440429,156012,256,21792,46213,499642]

theorem envBound40576 : H12AffineFastState.Bounded env40576 := by
  intro p hp
  have h : env40576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1