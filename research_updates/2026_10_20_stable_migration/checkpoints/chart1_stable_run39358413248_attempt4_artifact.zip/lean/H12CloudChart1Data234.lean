import H12CloudChart1Data233

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound59354 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59355 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,428,1409,508,1448,1062,217,1093,1025,1448,1448,1416,64,430,1289,17,1228,509,137,372,1057,33,256,1196,217,1]

theorem envBound59355 : H12AffineFastState.Bounded env59355 := by
  intro p hp
  have h : env59355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59354_59355 : H12AffineEnvironment.transform 15 1062 env59354 = env59355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59354 == env59355) = true)

theorem identity59355 : scanCanonicalize (H12AffineFastState.compose env59355 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59355 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59356 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,428,348,508,373,251,217,152,220,373,373,341,64,430,468,17,17,509,137,372,252,33,256,113,217,1]

theorem envBound59356 : H12AffineFastState.Bounded env59356 := by
  intro p hp
  have h : env59356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59355_59356 : H12AffineEnvironment.transform 9 221 env59355 = env59356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59355 == env59356) = true)

theorem identity59356 : scanCanonicalize (H12AffineFastState.compose env59356 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59356 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59357 : List Nat := [2,4,8,16,32,32,128,256,0,189,293,428,316,412,277,155,185,152,188,277,277,309,32,430,436,17,17,413,137,276,156,33,256,17,185,1]

theorem envBound59357 : H12AffineFastState.Bounded env59357 := by
  intro p hp
  have h : env59357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59356_59357 : H12AffineEnvironment.transform 5 32 env59356 = env59357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59356 == env59357) = true)

theorem identity59357 : scanCanonicalize (H12AffineFastState.compose env59357 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 143) := by decide +kernel

theorem selectedBound59357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59358 : List Nat := [2,4,8,16,32,32,128,143,0,189,170,35,179,19,154,155,185,152,188,154,154,186,32,33,59,17,17,18,137,155,156,33,143,17,185,1]

theorem envBound59358 : H12AffineFastState.Bounded env59358 := by
  intro p hp
  have h : env59358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59357_59358 : H12AffineEnvironment.transform 7 143 env59357 = env59358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 143 env59357 == env59358) = true)

theorem identity59358 : scanCanonicalize (H12AffineFastState.compose env59358 (packedSelected [5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59358 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59359 : List Nat := [2,4,8,16,2,2,128,143,0,159,136,1,145,19,154,155,155,152,158,154,154,152,2,3,25,17,17,18,137,155,156,3,143,17,155,1]

theorem envBound59359 : H12AffineFastState.Bounded env59359 := by
  intro p hp
  have h : env59359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59358_59359 : H12AffineEnvironment.transform 4 2 env59358 = env59359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59358 == env59359) = true)

theorem identity59359 : scanCanonicalize (H12AffineFastState.compose env59359 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59359 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env59360 : List Nat := [2,4,8,11,2,2,128,143,0,132,136,1,138,8,129,128,128,131,133,129,129,131,2,3,2,10,10,9,137,128,135,3,143,10,128,1]

theorem envBound59360 : H12AffineFastState.Bounded env59360 := by
  intro p hp
  have h : env59360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59359_59360 : H12AffineEnvironment.transform 3 11 env59359 = env59360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59359 == env59360) = true)

theorem identity59360 : scanCanonicalize (H12AffineFastState.compose env59360 (packedSelected [3,9] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59360 : packedSelected [3,9] rootPS < 2^1333 := by decide +kernel

def env59361 : List Nat := [2,4,0,3,2,2,128,135,0,132,128,1,130,0,129,128,128,131,133,129,129,131,2,3,2,2,2,1,129,128,135,3,135,2,128,1]

theorem envBound59361 : H12AffineFastState.Bounded env59361 := by
  intro p hp
  have h : env59361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59360_59361 : H12AffineEnvironment.transform 2 0 env59360 = env59361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59360 == env59361) = true)

theorem identity59361 : scanCanonicalize (H12AffineFastState.compose env59361 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59361 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59362 : List Nat := [1,4,0,0,1,1,128,132,0,132,128,1,129,0,129,128,128,128,133,129,129,128,1,0,1,1,1,1,129,128,132,0,132,1,128,1]

theorem envBound59362 : H12AffineFastState.Bounded env59362 := by
  intro p hp
  have h : env59362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59361_59362 : H12AffineEnvironment.transform 0 1 env59361 = env59362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59361 == env59362) = true)

theorem identity59362 : scanCanonicalize (H12AffineFastState.compose env59362 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound59362 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59363 : List Nat := [1,4,0,0,1,1,1,5,0,5,1,1,0,0,0,1,1,1,4,0,0,1,1,0,1,1,1,1,0,1,5,0,5,1,1,1]

theorem envBound59363 : H12AffineFastState.Bounded env59363 := by
  intro p hp
  have h : env59363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59362_59363 : H12AffineEnvironment.transform 6 1 env59362 = env59363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env59362 == env59363) = true)

def env59364 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1289,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound59364 : H12AffineFastState.Bounded env59364 := by
  intro p hp
  have h : env59364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59342_59364 : H12AffineEnvironment.transform 8 1 env59342 = env59364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59342 == env59364) = true)

theorem identity59364 : scanCanonicalize (H12AffineFastState.compose env59364 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 6612) := by decide +kernel

theorem selectedBound59364 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59365 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,6612,4176,2129,65536,67846,262144,1025,2129,2097152,1416,7189,3159,1289,7236,2365812,4177,67926,66899,65543,68094,256,65674,67846,7253]

theorem envBound59365 : H12AffineFastState.Bounded env59365 := by
  intro p hp
  have h : env59365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59364_59365 : H12AffineEnvironment.transform 12 6612 env59364 = env59365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6612 env59364 == env59365) = true)

def env59366 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,2097152,1416,65,3159,1289,16,2360608,3077,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59366 : H12AffineFastState.Bounded env59366 := by
  intro p hp
  have h : env59366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59365_59366 : H12AffineEnvironment.transform 11 3156 env59365 = env59366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59365 == env59366) = true)

theorem identity59366 : scanCanonicalize (H12AffineFastState.compose env59366 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66735) := by decide +kernel

theorem selectedBound59366 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59367 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,66735,1416,65,3159,1289,16,328079,3077,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59367 : H12AffineFastState.Bounded env59367 := by
  intro p hp
  have h : env59367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59366_59367 : H12AffineEnvironment.transform 20 66735 env59366 = env59367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66735 env59366 == env59367) = true)

theorem identity59367 : scanCanonicalize (H12AffineFastState.compose env59367 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound59367 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59368 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,65536,67846,68962,1025,2129,66735,1416,65,3159,1289,16,3309,3077,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59368 : H12AffineFastState.Bounded env59368 := by
  intro p hp
  have h : env59368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59367_59368 : H12AffineEnvironment.transform 17 68962 env59367 = env59368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env59367 == env59368) = true)

theorem identity59368 : scanCanonicalize (H12AffineFastState.compose env59368 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59368 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59369 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,2202,412,1528,1025,2129,3125,1416,65,3159,1289,16,3309,3077,460,3529,2205,356,256,2064,412,1]

theorem envBound59369 : H12AffineFastState.Bounded env59369 := by
  intro p hp
  have h : env59369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59368_59369 : H12AffineEnvironment.transform 15 2202 env59368 = env59369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59368 == env59369) = true)

theorem identity59369 : scanCanonicalize (H12AffineFastState.compose env59369 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59369 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59370 : List Nat := [2,4,8,16,32,64,128,256,1,424,2048,2556,40,2476,2129,2202,412,80,425,2129,2461,32,65,2559,161,16,2373,2477,460,2145,2205,356,256,2064,412,1]

theorem envBound59370 : H12AffineFastState.Bounded env59370 := by
  intro p hp
  have h : env59370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59369_59370 : H12AffineEnvironment.transform 9 424 env59369 = env59370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59369 == env59370) = true)

theorem identity59370 : scanCanonicalize (H12AffineFastState.compose env59370 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59370 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59371 : List Nat := [2,4,8,16,32,64,128,69,1,237,2048,2233,40,2281,2129,2202,217,80,236,2129,2264,32,65,2234,161,16,2048,2280,137,2145,2205,33,69,2064,217,1]

theorem envBound59371 : H12AffineFastState.Bounded env59371 := by
  intro p hp
  have h : env59371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59370_59371 : H12AffineEnvironment.transform 7 69 env59370 = env59371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59370 == env59371) = true)

theorem identity59371 : scanCanonicalize (H12AffineFastState.compose env59371 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59372 : List Nat := [2,4,8,16,32,64,115,69,1,30,2048,2122,40,2074,2129,2153,42,80,31,2129,2091,32,65,2121,82,16,2048,2075,122,2145,2158,33,69,2064,42,1]

theorem envBound59372 : H12AffineFastState.Bounded env59372 := by
  intro p hp
  have h : env59372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59371_59372 : H12AffineEnvironment.transform 6 115 env59371 = env59372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59371 == env59372) = true)

def env59373 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3157,1409,3077,2129,65536,67846,262144,1025,2129,2097152,1416,64,3159,1289,17,2360609,3076,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59373 : H12AffineFastState.Bounded env59373 := by
  intro p hp
  have h : env59373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59365_59373 : H12AffineEnvironment.transform 11 3157 env59365 = env59373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env59365 == env59373) = true)

theorem identity59373 : scanCanonicalize (H12AffineFastState.compose env59373 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59373 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59374 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3157,1409,3077,2129,65536,67846,262144,1025,2129,1448,1416,64,3159,1289,17,262281,3076,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59374 : H12AffineFastState.Bounded env59374 := by
  intro p hp
  have h : env59374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59373_59374 : H12AffineEnvironment.transform 20 1448 env59373 = env59374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59373 == env59374) = true)

theorem identity59374 : scanCanonicalize (H12AffineFastState.compose env59374 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59374 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59375 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,428,1409,508,1448,65536,66815,262144,1025,1448,1448,1416,64,430,1289,17,262281,509,66735,66899,65543,66567,256,65674,66815,0]

theorem envBound59375 : H12AffineFastState.Bounded env59375 := by
  intro p hp
  have h : env59375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59374_59375 : H12AffineEnvironment.transform 10 1529 env59374 = env59375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59374 == env59375) = true)

theorem identity59375 : scanCanonicalize (H12AffineFastState.compose env59375 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound59375 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59376 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,428,1409,508,1448,65536,66815,1093,1025,1448,1448,1416,64,430,1289,17,1228,509,66735,66899,65543,66567,256,65674,66815,0]

theorem envBound59376 : H12AffineFastState.Bounded env59376 := by
  intro p hp
  have h : env59376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59375_59376 : H12AffineEnvironment.transform 17 1093 env59375 = env59376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env59375 == env59376) = true)

theorem identity59376 : scanCanonicalize (H12AffineFastState.compose env59376 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59376 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59377 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,428,1409,508,1448,1062,217,1093,1025,1448,1448,1416,64,430,1289,17,1228,509,137,373,1057,33,256,1196,217,0]

theorem envBound59377 : H12AffineFastState.Bounded env59377 := by
  intro p hp
  have h : env59377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59376_59377 : H12AffineEnvironment.transform 15 1062 env59376 = env59377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59376 == env59377) = true)

theorem identity59377 : scanCanonicalize (H12AffineFastState.compose env59377 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59377 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59378 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,428,349,508,372,250,217,153,221,372,372,340,64,430,469,17,16,509,137,373,253,33,256,112,217,0]

theorem envBound59378 : H12AffineFastState.Bounded env59378 := by
  intro p hp
  have h : env59378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59377_59378 : H12AffineEnvironment.transform 9 220 env59377 = env59378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59377 == env59378) = true)

theorem identity59378 : scanCanonicalize (H12AffineFastState.compose env59378 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59378 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59379 : List Nat := [2,4,8,16,1,64,128,256,1,220,260,397,349,477,341,219,217,153,221,341,341,340,64,399,469,17,16,476,137,340,220,0,256,81,217,0]

theorem envBound59379 : H12AffineFastState.Bounded env59379 := by
  intro p hp
  have h : env59379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59378_59379 : H12AffineEnvironment.transform 4 1 env59378 = env59379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59378 == env59379) = true)

theorem identity59379 : scanCanonicalize (H12AffineFastState.compose env59379 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59379 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59380 : List Nat := [2,4,8,16,1,17,128,256,1,141,260,397,268,396,260,138,136,153,140,260,260,261,17,399,388,17,16,397,137,261,141,0,256,0,136,0]

theorem envBound59380 : H12AffineFastState.Bounded env59380 := by
  intro p hp
  have h : env59380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59379_59380 : H12AffineEnvironment.transform 5 17 env59379 = env59380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59379 == env59380) = true)

theorem identity59380 : scanCanonicalize (H12AffineFastState.compose env59380 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59381 : List Nat := [1,4,8,16,1,17,128,256,1,141,260,397,268,396,260,137,136,153,140,260,260,261,17,396,388,17,16,397,137,261,141,0,256,0,136,0]

theorem envBound59381 : H12AffineFastState.Bounded env59381 := by
  intro p hp
  have h : env59381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59380_59381 : H12AffineEnvironment.transform 0 1 env59380 = env59381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59380 == env59381) = true)

theorem identity59381 : scanCanonicalize (H12AffineFastState.compose env59381 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 148) := by decide +kernel

theorem selectedBound59381 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59382 : List Nat := [1,4,8,16,1,17,128,148,1,141,144,25,152,24,144,137,136,153,140,144,144,145,17,24,16,17,16,25,137,145,141,0,148,0,136,0]

theorem envBound59382 : H12AffineFastState.Bounded env59382 := by
  intro p hp
  have h : env59382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59381_59382 : H12AffineEnvironment.transform 7 148 env59381 = env59382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 148 env59381 == env59382) = true)

theorem identity59382 : scanCanonicalize (H12AffineFastState.compose env59382 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound59382 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env59383 : List Nat := [1,4,8,16,1,17,1,21,1,12,17,25,25,24,17,8,9,24,13,17,17,16,17,24,16,17,16,25,8,16,12,0,21,0,9,0]

theorem envBound59383 : H12AffineFastState.Bounded env59383 := by
  intro p hp
  have h : env59383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59382_59383 : H12AffineEnvironment.transform 6 1 env59382 = env59383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env59382 == env59383) = true)

theorem identity59383 : scanCanonicalize (H12AffineFastState.compose env59383 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59384 : List Nat := [1,4,8,1,1,0,1,4,1,12,0,8,8,9,0,8,9,9,13,0,0,1,0,9,1,0,1,8,8,1,12,0,4,0,9,0]

theorem envBound59384 : H12AffineFastState.Bounded env59384 := by
  intro p hp
  have h : env59384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59383_59384 : H12AffineEnvironment.transform 3 1 env59383 = env59384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59383 == env59384) = true)

theorem identity59384 : scanCanonicalize (H12AffineFastState.compose env59384 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59384 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59385 : List Nat := [1,4,0,1,1,0,1,4,1,4,0,0,0,1,0,0,1,1,5,0,0,1,0,1,1,0,1,0,0,1,4,0,4,0,1,0]

theorem envBound59385 : H12AffineFastState.Bounded env59385 := by
  intro p hp
  have h : env59385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59384_59385 : H12AffineEnvironment.transform 2 0 env59384 = env59385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59384 == env59385) = true)

def env59386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399767,8397000,8388689,2366324,4177,77954,67411,8463814,8465982,256,65675,78034,8389185]

theorem envBound59386 : H12AffineFastState.Bounded env59386 := by
  intro p hp
  have h : env59386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59298_59386 : H12AffineEnvironment.transform 21 1417 env59298 = env59386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59298 == env59386) = true)

def env59387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3671,1288,9617,2366324,4177,77954,67411,65542,68606,256,65675,78034,10113]

theorem envBound59387 : H12AffineFastState.Bounded env59387 := by
  intro p hp
  have h : env59387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59386_59387 : H12AffineEnvironment.transform 22 9664 env59386 = env59387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59386 == env59387) = true)

def env59388 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1288,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59388 : H12AffineFastState.Bounded env59388 := by
  intro p hp
  have h : env59388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59387_59388 : H12AffineEnvironment.transform 8 0 env59387 = env59388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59387 == env59388) = true)

theorem identity59388 : scanCanonicalize (H12AffineFastState.compose env59388 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 2264) := by decide +kernel

theorem selectedBound59388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59389 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2264,1417,9664,3159,1288,9617,266668,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59389 : H12AffineFastState.Bounded env59389 := by
  intro p hp
  have h : env59389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59388_59389 : H12AffineEnvironment.transform 20 2264 env59388 = env59389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2264 env59388 == env59389) = true)

def env59390 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,2264,1417,64,3159,1288,17,266668,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound59390 : H12AffineFastState.Bounded env59390 := by
  intro p hp
  have h : env59390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59389_59390 : H12AffineEnvironment.transform 12 1408 env59389 = env59390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59389 == env59390) = true)

theorem identity59390 : scanCanonicalize (H12AffineFastState.compose env59390 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59390 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59391 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,293,1408,373,2128,65536,66679,262144,1025,2128,2264,1417,64,3159,1288,17,262281,372,66599,66899,65542,68094,256,65675,66679,1]

theorem envBound59391 : H12AffineFastState.Bounded env59391 := by
  intro p hp
  have h : env59391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59390_59391 : H12AffineEnvironment.transform 11 293 env59390 = env59391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59390 == env59391) = true)

theorem identity59391 : scanCanonicalize (H12AffineFastState.compose env59391 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59391 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59392 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,293,1408,373,1448,65536,66679,262144,1025,1448,1312,1417,64,431,1288,17,262281,372,66599,66899,65542,66566,256,65675,66679,1]

theorem envBound59392 : H12AffineFastState.Bounded env59392 := by
  intro p hp
  have h : env59392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59391_59392 : H12AffineEnvironment.transform 10 1528 env59391 = env59392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59391 == env59392) = true)

theorem identity59392 : scanCanonicalize (H12AffineFastState.compose env59392 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound59392 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59393 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,293,1408,373,1448,65536,66679,1228,1025,1448,1312,1417,64,431,1288,17,1093,372,66599,66899,65542,66566,256,65675,66679,1]

theorem envBound59393 : H12AffineFastState.Bounded env59393 := by
  intro p hp
  have h : env59393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59392_59393 : H12AffineEnvironment.transform 17 1228 env59392 = env59393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env59392 == env59393) = true)

theorem identity59393 : scanCanonicalize (H12AffineFastState.compose env59393 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59393 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59394 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,293,1408,373,1448,1062,81,1228,1025,1448,1312,1417,64,431,1288,17,1093,372,1,373,1056,32,256,1197,81,1]

theorem envBound59394 : H12AffineFastState.Bounded env59394 := by
  intro p hp
  have h : env59394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59393_59394 : H12AffineEnvironment.transform 15 1062 env59393 = env59394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59393 == env59394) = true)

theorem identity59394 : scanCanonicalize (H12AffineFastState.compose env59394 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59394 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59395 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,293,348,373,372,250,81,16,221,372,508,341,64,431,468,17,153,372,1,373,252,32,256,113,81,1]

theorem envBound59395 : H12AffineFastState.Bounded env59395 := by
  intro p hp
  have h : env59395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59394_59395 : H12AffineEnvironment.transform 9 220 env59394 = env59395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59394 == env59395) = true)

theorem identity59395 : scanCanonicalize (H12AffineFastState.compose env59395 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59395 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59396 : List Nat := [2,4,8,16,32,17,128,256,0,141,292,293,269,292,293,171,0,16,140,293,429,260,17,431,389,17,153,293,1,292,173,32,256,32,0,1]

theorem envBound59396 : H12AffineFastState.Bounded env59396 := by
  intro p hp
  have h : env59396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59395_59396 : H12AffineEnvironment.transform 5 17 env59395 = env59396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59395 == env59396) = true)

theorem identity59396 : scanCanonicalize (H12AffineFastState.compose env59396 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound59396 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59397 : List Nat := [2,4,8,16,19,17,128,256,0,141,279,278,269,279,278,152,0,16,140,278,414,260,17,412,389,17,153,278,1,279,158,19,256,19,0,1]

theorem envBound59397 : H12AffineFastState.Bounded env59397 := by
  intro p hp
  have h : env59397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59396_59397 : H12AffineEnvironment.transform 4 19 env59396 = env59397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env59396 == env59397) = true)

theorem identity59397 : scanCanonicalize (H12AffineFastState.compose env59397 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound59397 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59398 : List Nat := [2,4,8,16,19,17,128,4,0,141,19,18,9,19,18,152,0,16,140,18,154,0,17,152,129,17,153,18,1,19,158,19,4,19,0,1]

theorem envBound59398 : H12AffineFastState.Bounded env59398 := by
  intro p hp
  have h : env59398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59397_59398 : H12AffineEnvironment.transform 7 4 env59397 = env59398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env59397 == env59398) = true)

theorem identity59398 : scanCanonicalize (H12AffineFastState.compose env59398 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59398 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59399 : List Nat := [2,4,8,16,19,17,0,4,0,13,19,18,9,19,18,24,0,16,12,18,26,0,17,24,1,17,25,18,1,19,30,19,4,19,0,1]

theorem envBound59399 : H12AffineFastState.Bounded env59399 := by
  intro p hp
  have h : env59399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59398_59399 : H12AffineEnvironment.transform 6 0 env59398 = env59399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59398 == env59399) = true)

def env59400 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,2264,1417,65,3159,1288,16,266668,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound59400 : H12AffineFastState.Bounded env59400 := by
  intro p hp
  have h : env59400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59389_59400 : H12AffineEnvironment.transform 12 1409 env59389 = env59400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59389 == env59400) = true)

theorem identity59400 : scanCanonicalize (H12AffineFastState.compose env59400 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound59400 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59401 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4131,1392,262144,1025,2128,2264,1417,65,3159,1288,16,266668,4177,1312,5488,4133,6621,256,4264,1392,0]

theorem envBound59401 : H12AffineFastState.Bounded env59401 := by
  intro p hp
  have h : env59401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59400_59401 : H12AffineEnvironment.transform 15 4131 env59400 = env59401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env59400 == env59401) = true)

theorem identity59401 : scanCanonicalize (H12AffineFastState.compose env59401 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound59401 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59402 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4131,1392,276,1025,2128,2264,1417,65,3159,1288,16,4280,4177,1312,5488,4133,6621,256,4264,1392,0]

theorem envBound59402 : H12AffineFastState.Bounded env59402 := by
  intro p hp
  have h : env59402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59401_59402 : H12AffineEnvironment.transform 17 276 env59401 = env59402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env59401 == env59402) = true)

theorem identity59402 : scanCanonicalize (H12AffineFastState.compose env59402 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59402 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59403 : List Nat := [2,4,8,16,32,64,128,256,0,236,2048,4096,365,4176,2128,4131,412,276,237,2128,2264,357,65,2235,484,16,4280,4177,460,4508,4133,6621,256,4264,412,0]

theorem envBound59403 : H12AffineFastState.Bounded env59403 := by
  intro p hp
  have h : env59403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59402_59403 : H12AffineEnvironment.transform 9 236 env59402 = env59403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59402 == env59403) = true)

theorem identity59403 : scanCanonicalize (H12AffineFastState.compose env59403 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59403 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59404 : List Nat := [2,4,8,16,32,64,128,69,0,236,2048,4096,40,4176,2128,4131,217,81,237,2128,2264,32,65,2235,161,16,4280,4177,137,4313,4133,6296,69,4264,217,0]

theorem envBound59404 : H12AffineFastState.Bounded env59404 := by
  intro p hp
  have h : env59404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59403_59404 : H12AffineEnvironment.transform 7 69 env59403 = env59404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59403 == env59404) = true)

theorem identity59404 : scanCanonicalize (H12AffineFastState.compose env59404 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound59404 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59405 : List Nat := [2,4,8,16,32,64,128,69,0,236,2048,2232,40,2280,2128,2203,217,81,237,2128,2264,32,65,2235,161,16,2048,2281,137,2145,2205,32,69,2064,217,0]

theorem envBound59405 : H12AffineFastState.Bounded env59405 := by
  intro p hp
  have h : env59405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59404_59405 : H12AffineEnvironment.transform 11 2232 env59404 = env59405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env59404 == env59405) = true)

theorem identity59405 : scanCanonicalize (H12AffineFastState.compose env59405 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound59405 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59406 : List Nat := [2,4,8,16,32,64,128,69,0,236,195,123,40,43,147,88,217,81,237,147,27,32,65,120,161,16,195,42,137,162,94,32,69,211,217,0]

theorem envBound59406 : H12AffineFastState.Bounded env59406 := by
  intro p hp
  have h : env59406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59405_59406 : H12AffineEnvironment.transform 10 195 env59405 = env59406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env59405 == env59406) = true)

theorem identity59406 : scanCanonicalize (H12AffineFastState.compose env59406 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59406 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59407 : List Nat := [2,4,8,16,32,64,114,69,0,30,49,123,40,43,97,88,43,81,31,97,27,32,65,120,83,16,49,42,123,80,94,32,69,33,43,0]

theorem envBound59407 : H12AffineFastState.Bounded env59407 := by
  intro p hp
  have h : env59407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59406_59407 : H12AffineEnvironment.transform 6 114 env59406 = env59407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59406 == env59407) = true)

def env59408 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1288,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59408 : H12AffineFastState.Bounded env59408 := by
  intro p hp
  have h : env59408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59387_59408 : H12AffineEnvironment.transform 8 1 env59387 = env59408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59387 == env59408) = true)

theorem identity59408 : scanCanonicalize (H12AffineFastState.compose env59408 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 11609) := by decide +kernel

theorem selectedBound59408 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59409 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,11609,1417,9664,3158,1288,9617,275500,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59409 : H12AffineFastState.Bounded env59409 := by
  intro p hp
  have h : env59409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59408_59409 : H12AffineEnvironment.transform 20 11609 env59408 = env59409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11609 env59408 == env59409) = true)

def env59410 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,2265,1417,64,3158,1288,17,266668,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound59410 : H12AffineFastState.Bounded env59410 := by
  intro p hp
  have h : env59410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59409_59410 : H12AffineEnvironment.transform 12 1408 env59409 = env59410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59409 == env59410) = true)

theorem identity59410 : scanCanonicalize (H12AffineFastState.compose env59410 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59410 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59411 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,293,1408,373,2129,65536,66679,262144,1025,2129,2265,1417,64,3158,1288,17,262281,372,66599,66898,65542,68095,256,65675,66679,0]

theorem envBound59411 : H12AffineFastState.Bounded env59411 := by
  intro p hp
  have h : env59411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59410_59411 : H12AffineEnvironment.transform 11 293 env59410 = env59411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59410 == env59411) = true)

theorem identity59411 : scanCanonicalize (H12AffineFastState.compose env59411 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59411 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59412 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,293,1408,373,1448,65536,66679,262144,1025,1448,1312,1417,64,431,1288,17,262281,372,66599,66898,65542,66566,256,65675,66679,0]

theorem envBound59412 : H12AffineFastState.Bounded env59412 := by
  intro p hp
  have h : env59412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59411_59412 : H12AffineEnvironment.transform 10 1529 env59411 = env59412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59411 == env59412) = true)

theorem identity59412 : scanCanonicalize (H12AffineFastState.compose env59412 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound59412 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59413 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,293,1408,373,1448,65536,66679,1228,1025,1448,1312,1417,64,431,1288,17,1093,372,66599,66898,65542,66566,256,65675,66679,0]

theorem envBound59413 : H12AffineFastState.Bounded env59413 := by
  intro p hp
  have h : env59413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59412_59413 : H12AffineEnvironment.transform 17 1228 env59412 = env59413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env59412 == env59413) = true)

theorem identity59413 : scanCanonicalize (H12AffineFastState.compose env59413 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59413 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59414 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,293,1408,373,1448,1062,81,1228,1025,1448,1312,1417,64,431,1288,17,1093,372,1,372,1056,32,256,1197,81,0]

theorem envBound59414 : H12AffineFastState.Bounded env59414 := by
  intro p hp
  have h : env59414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59413_59414 : H12AffineEnvironment.transform 15 1062 env59413 = env59414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59413 == env59414) = true)

theorem identity59414 : scanCanonicalize (H12AffineFastState.compose env59414 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59414 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59415 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,293,349,373,373,251,81,17,220,373,509,340,64,431,469,17,152,372,1,372,253,32,256,112,81,0]

theorem envBound59415 : H12AffineFastState.Bounded env59415 := by
  intro p hp
  have h : env59415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59414_59415 : H12AffineEnvironment.transform 9 221 env59414 = env59415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59414 == env59415) = true)

theorem identity59415 : scanCanonicalize (H12AffineFastState.compose env59415 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59415 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59416 : List Nat := [2,4,8,16,32,64,128,173,1,221,137,136,240,216,216,251,81,17,220,216,80,249,64,2,120,17,152,217,1,217,253,32,173,112,81,0]

theorem envBound59416 : H12AffineFastState.Bounded env59416 := by
  intro p hp
  have h : env59416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59415_59416 : H12AffineEnvironment.transform 7 173 env59415 = env59416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59415 == env59416) = true)

theorem identity59416 : scanCanonicalize (H12AffineFastState.compose env59416 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 107) := by decide +kernel

theorem selectedBound59416 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59417 : List Nat := [2,4,8,16,32,64,107,70,1,54,98,99,27,51,51,16,81,17,55,51,80,18,64,2,120,17,115,50,1,50,22,32,70,112,81,0]

theorem envBound59417 : H12AffineFastState.Bounded env59417 := by
  intro p hp
  have h : env59417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59416_59417 : H12AffineEnvironment.transform 6 107 env59416 = env59417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 107 env59416 == env59417) = true)

theorem identity59417 : scanCanonicalize (H12AffineFastState.compose env59417 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59417 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59418 : List Nat := [2,4,8,3,32,64,107,70,1,37,98,99,8,32,32,3,66,2,36,32,67,1,64,2,107,2,96,33,1,33,5,32,70,99,66,0]

theorem envBound59418 : H12AffineFastState.Bounded env59418 := by
  intro p hp
  have h : env59418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59417_59418 : H12AffineEnvironment.transform 3 3 env59417 = env59418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59417 == env59418) = true)

theorem identity59418 : scanCanonicalize (H12AffineFastState.compose env59418 (packedSelected [0,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 41) := by decide +kernel

theorem selectedBound59418 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env59419 : List Nat := [2,4,8,3,32,41,2,47,1,37,11,10,8,32,32,3,43,2,36,32,42,1,41,2,2,2,9,33,1,33,5,32,47,10,43,0]

theorem envBound59419 : H12AffineFastState.Bounded env59419 := by
  intro p hp
  have h : env59419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59418_59419 : H12AffineEnvironment.transform 5 41 env59418 = env59419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 41 env59418 == env59419) = true)

theorem identity59419 : scanCanonicalize (H12AffineFastState.compose env59419 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59419 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59420 : List Nat := [2,4,8,3,2,11,2,13,1,7,11,10,8,2,2,3,9,2,6,2,8,1,11,2,2,2,9,3,1,3,5,2,13,10,9,0]

theorem envBound59420 : H12AffineFastState.Bounded env59420 := by
  intro p hp
  have h : env59420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59419_59420 : H12AffineEnvironment.transform 4 2 env59419 = env59420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59419 == env59420) = true)

def env59421 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,2264,1417,65,3158,1288,16,266669,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound59421 : H12AffineFastState.Bounded env59421 := by
  intro p hp
  have h : env59421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59409_59421 : H12AffineEnvironment.transform 12 1409 env59409 = env59421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59409 == env59421) = true)

theorem identity59421 : scanCanonicalize (H12AffineFastState.compose env59421 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound59421 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59422 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,2264,1417,65,3158,1288,16,266669,4177,1313,5488,4132,6621,256,4265,1393,1]

theorem envBound59422 : H12AffineFastState.Bounded env59422 := by
  intro p hp
  have h : env59422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59421_59422 : H12AffineEnvironment.transform 15 4130 env59421 = env59422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env59421 == env59422) = true)

theorem identity59422 : scanCanonicalize (H12AffineFastState.compose env59422 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound59422 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59423 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4130,1393,277,1025,2129,2264,1417,65,3158,1288,16,4280,4177,1313,5488,4132,6621,256,4265,1393,1]

theorem envBound59423 : H12AffineFastState.Bounded env59423 := by
  intro p hp
  have h : env59423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59422_59423 : H12AffineEnvironment.transform 17 277 env59422 = env59423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env59422 == env59423) = true)

theorem identity59423 : scanCanonicalize (H12AffineFastState.compose env59423 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59423 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59424 : List Nat := [2,4,8,16,32,64,128,256,1,236,2048,4096,365,4176,2129,4130,413,277,237,2129,2264,357,65,2234,484,16,4280,4177,461,4508,4132,6621,256,4265,413,1]

theorem envBound59424 : H12AffineFastState.Bounded env59424 := by
  intro p hp
  have h : env59424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59423_59424 : H12AffineEnvironment.transform 9 236 env59423 = env59424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59423 == env59424) = true)

theorem identity59424 : scanCanonicalize (H12AffineFastState.compose env59424 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59424 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59425 : List Nat := [2,4,8,16,32,64,128,256,1,236,373,4096,365,4176,292,4130,413,277,237,292,429,357,65,463,484,16,4280,4177,461,4508,4132,4264,256,4265,413,1]

theorem envBound59425 : H12AffineFastState.Bounded env59425 := by
  intro p hp
  have h : env59425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59424_59425 : H12AffineEnvironment.transform 10 373 env59424 = env59425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59424 == env59425) = true)

theorem identity59425 : scanCanonicalize (H12AffineFastState.compose env59425 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59425 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59426 : List Nat := [2,4,8,16,32,64,128,256,1,236,373,461,365,413,292,495,413,277,237,292,429,357,65,463,484,16,373,412,461,81,489,357,256,356,413,1]

theorem envBound59426 : H12AffineFastState.Bounded env59426 := by
  intro p hp
  have h : env59426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59425_59426 : H12AffineEnvironment.transform 11 461 env59425 = env59426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59425 == env59426) = true)

def env59427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3670,1289,9616,2366324,4177,77954,67411,65543,68607,256,65675,78034,10112]

theorem envBound59427 : H12AffineFastState.Bounded env59427 := by
  intro p hp
  have h : env59427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59386_59427 : H12AffineEnvironment.transform 22 9665 env59386 = env59427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59386 == env59427) = true)

def env59428 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1289,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound59428 : H12AffineFastState.Bounded env59428 := by
  intro p hp
  have h : env59428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59427_59428 : H12AffineEnvironment.transform 8 0 env59427 = env59428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59427 == env59428) = true)

theorem identity59428 : scanCanonicalize (H12AffineFastState.compose env59428 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound59428 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59429 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,5385,4176,2128,65536,67035,262144,1025,2128,2097152,1417,4296,3158,1289,4249,2365812,4177,66955,66899,65543,68095,256,65675,67035,4233]

theorem envBound59429 : H12AffineFastState.Bounded env59429 := by
  intro p hp
  have h : env59429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59428_59429 : H12AffineEnvironment.transform 12 5385 env59428 = env59429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env59428 == env59429) = true)

def env59430 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2097152,1417,64,3158,1289,17,2361852,217,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound59430 : H12AffineFastState.Bounded env59430 := by
  intro p hp
  have h : env59430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59429_59430 : H12AffineEnvironment.transform 11 136 env59429 = env59430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59429 == env59430) = true)

theorem identity59430 : scanCanonicalize (H12AffineFastState.compose env59430 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2421) := by decide +kernel

theorem selectedBound59430 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59431 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2421,1417,64,3158,1289,17,262281,217,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound59431 : H12AffineFastState.Bounded env59431 := by
  intro p hp
  have h : env59431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59430_59431 : H12AffineEnvironment.transform 20 2421 env59430 = env59431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2421 env59430 == env59431) = true)

theorem identity59431 : scanCanonicalize (H12AffineFastState.compose env59431 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59431 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59432 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,136,1409,216,1448,65536,67035,262144,1025,1448,1165,1417,64,430,1289,17,262281,217,66955,66899,65543,66567,256,65675,67035,1]

theorem envBound59432 : H12AffineFastState.Bounded env59432 := by
  intro p hp
  have h : env59432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59431_59432 : H12AffineEnvironment.transform 10 1528 env59431 = env59432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59431 == env59432) = true)

theorem identity59432 : scanCanonicalize (H12AffineFastState.compose env59432 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound59432 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59433 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,136,1409,216,1448,65536,67035,1377,1025,1448,1165,1417,64,430,1289,17,1512,217,66955,66899,65543,66567,256,65675,67035,1]

theorem envBound59433 : H12AffineFastState.Bounded env59433 := by
  intro p hp
  have h : env59433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59432_59433 : H12AffineEnvironment.transform 17 1377 env59432 = env59433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env59432 == env59433) = true)

theorem identity59433 : scanCanonicalize (H12AffineFastState.compose env59433 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59433 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59434 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,136,1409,216,1448,1062,509,1377,1025,1448,1165,1417,64,430,1289,17,1512,217,429,373,1057,33,256,1197,509,1]

theorem envBound59434 : H12AffineFastState.Bounded env59434 := by
  intro p hp
  have h : env59434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59433_59434 : H12AffineEnvironment.transform 15 1062 env59433 = env59434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59433 == env59434) = true)

theorem identity59434 : scanCanonicalize (H12AffineFastState.compose env59434 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59434 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59435 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,136,349,216,372,250,509,445,221,372,81,341,64,430,469,17,308,217,429,373,253,33,256,113,509,1]

theorem envBound59435 : H12AffineFastState.Bounded env59435 := by
  intro p hp
  have h : env59435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59434_59435 : H12AffineEnvironment.transform 9 220 env59434 = env59435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59434 == env59435) = true)

theorem identity59435 : scanCanonicalize (H12AffineFastState.compose env59435 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59435 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59436 : List Nat := [2,4,8,16,32,32,128,256,0,188,292,136,317,184,276,154,413,445,189,276,49,309,32,430,437,17,308,185,429,277,157,33,256,17,413,1]

theorem envBound59436 : H12AffineFastState.Bounded env59436 := by
  intro p hp
  have h : env59436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59435_59436 : H12AffineEnvironment.transform 5 32 env59435 = env59436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59435 == env59436) = true)

theorem identity59436 : scanCanonicalize (H12AffineFastState.compose env59436 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59436 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59437 : List Nat := [2,4,8,16,32,32,9,256,0,53,292,1,317,49,276,19,276,308,52,276,49,309,32,295,316,17,308,48,292,277,20,33,256,17,276,1]

theorem envBound59437 : H12AffineFastState.Bounded env59437 := by
  intro p hp
  have h : env59437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59436_59437 : H12AffineEnvironment.transform 6 9 env59436 = env59437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59436 == env59437) = true)

theorem identity59437 : scanCanonicalize (H12AffineFastState.compose env59437 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound59437 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59438 : List Nat := [2,4,8,16,32,32,9,37,0,53,1,1,24,49,49,19,49,17,52,49,49,16,32,2,25,17,17,48,1,48,20,33,37,17,49,1]

theorem envBound59438 : H12AffineFastState.Bounded env59438 := by
  intro p hp
  have h : env59438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59437_59438 : H12AffineEnvironment.transform 7 37 env59437 = env59438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env59437 == env59438) = true)

theorem identity59438 : scanCanonicalize (H12AffineFastState.compose env59438 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59438 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59439 : List Nat := [2,4,8,16,2,2,9,7,0,23,1,1,24,19,19,19,19,17,22,19,19,16,2,2,25,17,17,18,1,18,20,3,7,17,19,1]

theorem envBound59439 : H12AffineFastState.Bounded env59439 := by
  intro p hp
  have h : env59439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59438_59439 : H12AffineEnvironment.transform 4 2 env59438 = env59439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59438 == env59439) = true)

theorem identity59439 : scanCanonicalize (H12AffineFastState.compose env59439 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59439 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59440 : List Nat := [2,4,3,16,2,2,2,7,0,23,1,1,19,19,19,19,19,17,22,19,19,16,2,2,18,17,17,18,1,18,20,3,7,17,19,1]

theorem envBound59440 : H12AffineFastState.Bounded env59440 := by
  intro p hp
  have h : env59440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59439_59440 : H12AffineEnvironment.transform 2 3 env59439 = env59440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59439 == env59440) = true)

theorem identity59440 : scanCanonicalize (H12AffineFastState.compose env59440 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59440 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59441 : List Nat := [2,4,3,1,2,2,2,7,0,6,1,1,2,2,2,2,2,0,7,2,2,1,2,2,3,0,0,3,1,3,5,3,7,0,2,1]

theorem envBound59441 : H12AffineFastState.Bounded env59441 := by
  intro p hp
  have h : env59441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59440_59441 : H12AffineEnvironment.transform 3 1 env59440 = env59441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59440 == env59441) = true)

theorem identity59441 : scanCanonicalize (H12AffineFastState.compose env59441 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59441 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59442 : List Nat := [1,4,0,1,1,1,1,4,0,5,1,1,1,1,1,1,1,0,4,1,1,1,1,1,0,0,0,0,1,0,5,0,4,0,1,1]

theorem envBound59442 : H12AffineFastState.Bounded env59442 := by
  intro p hp
  have h : env59442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59441_59442 : H12AffineEnvironment.transform 0 1 env59441 = env59442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59441 == env59442) = true)

def env59443 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2128,65536,67035,262144,1025,2128,2097152,1417,65,3158,1289,16,2361853,216,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound59443 : H12AffineFastState.Bounded env59443 := by
  intro p hp
  have h : env59443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59429_59443 : H12AffineEnvironment.transform 11 137 env59429 = env59443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59429 == env59443) = true)

theorem identity59443 : scanCanonicalize (H12AffineFastState.compose env59443 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound59443 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59444 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2128,65536,67035,262144,1025,2128,67699,1417,65,3158,1289,16,328078,216,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound59444 : H12AffineFastState.Bounded env59444 := by
  intro p hp
  have h : env59444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59443_59444 : H12AffineEnvironment.transform 20 67699 env59443 = env59444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env59443 == env59444) = true)

theorem identity59444 : scanCanonicalize (H12AffineFastState.compose env59444 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound59444 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59445 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2128,65536,67035,65982,1025,2128,67699,1417,65,3158,1289,16,48,216,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound59445 : H12AffineFastState.Bounded env59445 := by
  intro p hp
  have h : env59445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59444_59445 : H12AffineEnvironment.transform 17 65982 env59444 = env59445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env59444 == env59445) = true)

theorem identity59445 : scanCanonicalize (H12AffineFastState.compose env59445 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound59445 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59446 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1408,217,2128,1095,412,1529,1025,2128,3124,1417,65,3158,1289,16,48,216,460,276,1088,3512,256,1228,412,0]

theorem envBound59446 : H12AffineFastState.Bounded env59446 := by
  intro p hp
  have h : env59446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59445_59446 : H12AffineEnvironment.transform 15 1095 env59445 = env59446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env59445 == env59446) = true)

theorem identity59446 : scanCanonicalize (H12AffineFastState.compose env59446 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59446 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59447 : List Nat := [2,4,8,16,32,64,128,256,0,1024,373,137,1408,217,293,1095,412,1529,1025,293,1345,1417,65,1315,1289,16,48,216,460,276,1088,1229,256,1228,412,0]

theorem envBound59447 : H12AffineFastState.Bounded env59447 := by
  intro p hp
  have h : env59447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59446_59447 : H12AffineEnvironment.transform 10 373 env59446 = env59447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59446 == env59447) = true)

theorem identity59447 : scanCanonicalize (H12AffineFastState.compose env59447 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59447 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59448 : List Nat := [2,4,8,16,32,64,128,69,0,1024,48,137,1221,217,96,1095,217,1212,1025,96,1028,1228,65,1126,1100,16,48,216,137,81,1088,1229,69,1228,217,0]

theorem envBound59448 : H12AffineFastState.Bounded env59448 := by
  intro p hp
  have h : env59448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59447_59448 : H12AffineEnvironment.transform 7 69 env59447 = env59448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59447 == env59448) = true)

def env59449 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound59449 : H12AffineFastState.Bounded env59449 := by
  intro p hp
  have h : env59449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59427_59449 : H12AffineEnvironment.transform 8 1 env59427 = env59449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59427 == env59449) = true)

theorem identity59449 : scanCanonicalize (H12AffineFastState.compose env59449 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59450 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,8192,216,2129,65536,73818,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2361853,217,73738,66898,65543,68094,256,65675,73818,9601]

theorem envBound59450 : H12AffineFastState.Bounded env59450 := by
  intro p hp
  have h : env59450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59449_59450 : H12AffineEnvironment.transform 11 136 env59449 = env59450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59449 == env59450) = true)

def env59451 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2129,65536,67034,262144,1025,2129,2097152,1417,65,3159,1289,16,2361853,217,66954,66898,65543,68094,256,65675,67034,1]

theorem envBound59451 : H12AffineFastState.Bounded env59451 := by
  intro p hp
  have h : env59451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59450_59451 : H12AffineEnvironment.transform 12 1408 env59450 = env59451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59450 == env59451) = true)

theorem identity59451 : scanCanonicalize (H12AffineFastState.compose env59451 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound59451 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59452 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2129,65536,67034,262144,1025,2129,67699,1417,65,3159,1289,16,328078,217,66954,66898,65543,68094,256,65675,67034,1]

theorem envBound59452 : H12AffineFastState.Bounded env59452 := by
  intro p hp
  have h : env59452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59451_59452 : H12AffineEnvironment.transform 20 67699 env59451 = env59452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env59451 == env59452) = true)

theorem identity59452 : scanCanonicalize (H12AffineFastState.compose env59452 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound59452 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59453 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2129,65536,67034,65983,1025,2129,67699,1417,65,3159,1289,16,49,217,66954,66898,65543,68094,256,65675,67034,1]

theorem envBound59453 : H12AffineFastState.Bounded env59453 := by
  intro p hp
  have h : env59453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59452_59453 : H12AffineEnvironment.transform 17 65983 env59452 = env59453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env59452 == env59453) = true)

theorem identity59453 : scanCanonicalize (H12AffineFastState.compose env59453 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound59453 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59454 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1408,216,2129,1095,413,1528,1025,2129,3124,1417,65,3159,1289,16,49,217,461,277,1088,3513,256,1228,413,1]

theorem envBound59454 : H12AffineFastState.Bounded env59454 := by
  intro p hp
  have h : env59454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59453_59454 : H12AffineEnvironment.transform 15 1095 env59453 = env59454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env59453 == env59454) = true)

theorem identity59454 : scanCanonicalize (H12AffineFastState.compose env59454 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59454 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59455 : List Nat := [2,4,8,16,32,64,128,256,1,425,2048,136,41,216,2129,494,413,81,424,2129,2461,32,65,2558,160,16,49,217,461,277,489,2064,256,357,413,1]

theorem envBound59455 : H12AffineFastState.Bounded env59455 := by
  intro p hp
  have h : env59455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59454_59455 : H12AffineEnvironment.transform 9 425 env59454 = env59455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59454 == env59455) = true)

theorem identity59455 : scanCanonicalize (H12AffineFastState.compose env59455 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59455 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59456 : List Nat := [2,4,8,16,32,64,128,256,1,425,49,136,41,216,96,494,413,81,424,96,428,32,65,463,160,16,49,217,461,277,489,33,256,357,413,1]

theorem envBound59456 : H12AffineFastState.Bounded env59456 := by
  intro p hp
  have h : env59456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59455_59456 : H12AffineEnvironment.transform 10 49 env59455 = env59456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59455 == env59456) = true)

theorem identity59456 : scanCanonicalize (H12AffineFastState.compose env59456 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59456 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59457 : List Nat := [2,4,8,16,32,64,115,256,1,346,49,123,41,43,96,285,366,81,347,96,351,32,65,316,83,16,49,42,318,277,282,33,256,357,366,1]

theorem envBound59457 : H12AffineFastState.Bounded env59457 := by
  intro p hp
  have h : env59457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59456_59457 : H12AffineEnvironment.transform 6 115 env59456 = env59457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59456 == env59457) = true)

theorem identity59457 : scanCanonicalize (H12AffineFastState.compose env59457 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59457 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59458 : List Nat := [2,4,8,16,32,64,115,69,1,31,49,123,41,43,96,88,43,81,30,96,26,32,65,121,83,16,49,42,123,80,95,33,69,32,43,1]

theorem envBound59458 : H12AffineFastState.Bounded env59458 := by
  intro p hp
  have h : env59458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59457_59458 : H12AffineEnvironment.transform 7 69 env59457 = env59458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59457 == env59458) = true)

def env59459 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2097152,1417,64,3159,1289,17,2361853,217,66955,66898,65543,68094,256,65675,67035,0]

theorem envBound59459 : H12AffineFastState.Bounded env59459 := by
  intro p hp
  have h : env59459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59450_59459 : H12AffineEnvironment.transform 12 1409 env59450 = env59459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59450 == env59459) = true)

theorem identity59459 : scanCanonicalize (H12AffineFastState.compose env59459 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2420) := by decide +kernel

theorem selectedBound59459 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59460 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2420,1417,64,3159,1289,17,262281,217,66955,66898,65543,68094,256,65675,67035,0]

theorem envBound59460 : H12AffineFastState.Bounded env59460 := by
  intro p hp
  have h : env59460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59459_59460 : H12AffineEnvironment.transform 20 2420 env59459 = env59460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2420 env59459 == env59460) = true)

theorem identity59460 : scanCanonicalize (H12AffineFastState.compose env59460 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59460 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59461 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,136,1409,216,1448,65536,67035,262144,1025,1448,1165,1417,64,430,1289,17,262281,217,66955,66898,65543,66567,256,65675,67035,0]

theorem envBound59461 : H12AffineFastState.Bounded env59461 := by
  intro p hp
  have h : env59461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59460_59461 : H12AffineEnvironment.transform 10 1529 env59460 = env59461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59460 == env59461) = true)

theorem identity59461 : scanCanonicalize (H12AffineFastState.compose env59461 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound59461 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59462 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,136,1409,216,1448,65536,67035,1377,1025,1448,1165,1417,64,430,1289,17,1512,217,66955,66898,65543,66567,256,65675,67035,0]

theorem envBound59462 : H12AffineFastState.Bounded env59462 := by
  intro p hp
  have h : env59462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59461_59462 : H12AffineEnvironment.transform 17 1377 env59461 = env59462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env59461 == env59462) = true)

theorem identity59462 : scanCanonicalize (H12AffineFastState.compose env59462 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59462 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59463 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,136,1409,216,1448,1062,509,1377,1025,1448,1165,1417,64,430,1289,17,1512,217,429,372,1057,33,256,1197,509,0]

theorem envBound59463 : H12AffineFastState.Bounded env59463 := by
  intro p hp
  have h : env59463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59462_59463 : H12AffineEnvironment.transform 15 1062 env59462 = env59463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59462 == env59463) = true)

theorem identity59463 : scanCanonicalize (H12AffineFastState.compose env59463 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59463 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59464 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,136,348,216,373,251,509,444,220,373,80,340,64,430,468,17,309,217,429,372,252,33,256,112,509,0]

theorem envBound59464 : H12AffineFastState.Bounded env59464 := by
  intro p hp
  have h : env59464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59463_59464 : H12AffineEnvironment.transform 9 221 env59463 = env59464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59463 == env59464) = true)

theorem identity59464 : scanCanonicalize (H12AffineFastState.compose env59464 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound59464 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59465 : List Nat := [2,4,8,16,32,64,128,5,1,221,33,136,89,216,112,251,248,185,220,112,80,81,64,171,209,17,48,217,168,113,252,33,5,112,248,0]

theorem envBound59465 : H12AffineFastState.Bounded env59465 := by
  intro p hp
  have h : env59465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59464_59465 : H12AffineEnvironment.transform 7 5 env59464 = env59465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env59464 == env59465) = true)

theorem identity59465 : scanCanonicalize (H12AffineFastState.compose env59465 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59465 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59466 : List Nat := [2,4,8,16,32,17,128,5,1,140,33,136,8,137,33,170,169,185,141,33,1,0,17,171,128,17,48,136,168,32,173,33,5,33,169,0]

theorem envBound59466 : H12AffineFastState.Bounded env59466 := by
  intro p hp
  have h : env59466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59465_59466 : H12AffineEnvironment.transform 5 17 env59465 = env59466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59465 == env59466) = true)

theorem identity59466 : scanCanonicalize (H12AffineFastState.compose env59466 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound59466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59467 : List Nat := [2,4,8,16,3,17,128,5,1,140,2,136,8,137,2,137,138,154,141,2,1,0,17,136,128,17,19,136,139,3,142,2,5,2,138,0]

theorem envBound59467 : H12AffineFastState.Bounded env59467 := by
  intro p hp
  have h : env59467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59466_59467 : H12AffineEnvironment.transform 4 3 env59466 = env59467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env59466 == env59467) = true)

theorem identity59467 : scanCanonicalize (H12AffineFastState.compose env59467 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound59467 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59468 : List Nat := [2,4,8,16,3,17,3,5,1,15,2,11,8,10,2,10,9,25,14,2,1,0,17,11,3,17,19,11,8,3,13,2,5,2,9,0]

theorem envBound59468 : H12AffineFastState.Bounded env59468 := by
  intro p hp
  have h : env59468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59467_59468 : H12AffineEnvironment.transform 6 3 env59467 = env59468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env59467 == env59468) = true)

theorem identity59468 : scanCanonicalize (H12AffineFastState.compose env59468 (packedSelected [3,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59468 : packedSelected [3,5,9] rootPS < 2^1333 := by decide +kernel

def env59469 : List Nat := [2,4,8,2,3,3,3,5,1,15,2,11,8,10,2,10,9,11,14,2,1,0,3,11,3,3,1,11,8,3,13,2,5,2,9,0]

theorem envBound59469 : H12AffineFastState.Bounded env59469 := by
  intro p hp
  have h : env59469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59468_59469 : H12AffineEnvironment.transform 3 2 env59468 = env59469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59468 == env59469) = true)

theorem identity59469 : scanCanonicalize (H12AffineFastState.compose env59469 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59470 : List Nat := [2,4,3,2,3,3,3,5,1,4,2,0,3,1,2,1,2,0,5,2,1,0,3,0,3,3,1,0,3,3,6,2,5,2,2,0]

theorem envBound59470 : H12AffineFastState.Bounded env59470 := by
  intro p hp
  have h : env59470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59469_59470 : H12AffineEnvironment.transform 2 3 env59469 = env59470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59469 == env59470) = true)

theorem identity59470 : scanCanonicalize (H12AffineFastState.compose env59470 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59470 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59471 : List Nat := [0,4,1,0,1,1,1,5,1,4,0,0,1,1,0,1,0,0,5,0,1,0,1,0,1,1,1,0,1,1,4,0,5,0,0,0]

theorem envBound59471 : H12AffineFastState.Bounded env59471 := by
  intro p hp
  have h : env59471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59470_59471 : H12AffineEnvironment.transform 0 0 env59470 = env59471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59470 == env59471) = true)

def env59472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,8397001,8388689,134217728,4177,77954,4260570,8463814,149237955,256,136649727,78034,8389184]

theorem envBound59472 : H12AffineFastState.Bounded env59472 := by
  intro p hp
  have h : env59472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59109_59472 : H12AffineEnvironment.transform 24 8397001 env59109 = env59472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397001 env59109 == env59472) = true)

def env59473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,8397001,8388689,6561532,4177,77954,4260570,8463814,8465983,256,4261123,78034,8389184]

theorem envBound59473 : H12AffineFastState.Bounded env59473 := by
  intro p hp
  have h : env59473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59472_59473 : H12AffineEnvironment.transform 26 6561532 env59472 = env59473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env59472 == env59473) = true)

def env59474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399767,8397001,8388689,2366324,4177,77954,67410,8463814,8465983,256,65675,78034,8389184]

theorem envBound59474 : H12AffineFastState.Bounded env59474 := by
  intro p hp
  have h : env59474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59473_59474 : H12AffineEnvironment.transform 21 1416 env59473 = env59474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59473 == env59474) = true)

def env59475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3671,1289,9617,2366324,4177,77954,67410,65542,68607,256,65675,78034,10112]

theorem envBound59475 : H12AffineFastState.Bounded env59475 := by
  intro p hp
  have h : env59475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59474_59475 : H12AffineEnvironment.transform 22 9664 env59474 = env59475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59474 == env59475) = true)

def env59476 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1289,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59476 : H12AffineFastState.Bounded env59476 := by
  intro p hp
  have h : env59476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59475_59476 : H12AffineEnvironment.transform 8 0 env59475 = env59476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59475 == env59476) = true)

theorem identity59476 : scanCanonicalize (H12AffineFastState.compose env59476 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 75251) := by decide +kernel

theorem selectedBound59476 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59477 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,75251,1416,9664,3159,1289,9617,343175,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound59477 : H12AffineFastState.Bounded env59477 := by
  intro p hp
  have h : env59477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59476_59477 : H12AffineEnvironment.transform 20 75251 env59476 = env59477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75251 env59476 == env59477) = true)

def env59478 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,65651,1416,64,3159,1289,17,334087,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound59478 : H12AffineFastState.Bounded env59478 := by
  intro p hp
  have h : env59478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59477_59478 : H12AffineEnvironment.transform 12 1408 env59477 = env59478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59477 == env59478) = true)

theorem identity59478 : scanCanonicalize (H12AffineFastState.compose env59478 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59478 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59479 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,65651,1416,64,3159,1289,17,328078,2264,69003,66898,65542,68095,256,65675,69083,0]

theorem envBound59479 : H12AffineFastState.Bounded env59479 := by
  intro p hp
  have h : env59479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59478_59479 : H12AffineEnvironment.transform 11 2185 env59478 = env59479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59478 == env59479) = true)

theorem identity59479 : scanCanonicalize (H12AffineFastState.compose env59479 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound59479 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59480 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2128,65536,69083,96,1025,2128,65651,1416,64,3159,1289,17,66030,2264,69003,66898,65542,68095,256,65675,69083,0]

theorem envBound59480 : H12AffineFastState.Bounded env59480 := by
  intro p hp
  have h : env59480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59479_59480 : H12AffineEnvironment.transform 17 96 env59479 = env59480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env59479 == env59480) = true)

theorem identity59480 : scanCanonicalize (H12AffineFastState.compose env59480 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59480 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59481 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1245,1108,1408,1028,1165,65536,65798,96,1025,1165,65651,1416,64,138,1289,17,66030,1029,65878,66898,65542,66850,256,65675,65798,0]

theorem envBound59481 : H12AffineFastState.Bounded env59481 := by
  intro p hp
  have h : env59481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59480_59481 : H12AffineEnvironment.transform 10 1245 env59480 = env59481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59480 == env59481) = true)

theorem identity59481 : scanCanonicalize (H12AffineFastState.compose env59481 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59481 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59482 : List Nat := [2,4,8,16,32,64,128,256,0,409,324,461,25,413,276,65536,65798,96,408,276,65651,17,64,138,144,17,66030,412,65878,65739,65542,65723,256,65675,65798,0]

theorem envBound59482 : H12AffineFastState.Bounded env59482 := by
  intro p hp
  have h : env59482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59481_59482 : H12AffineEnvironment.transform 9 409 env59481 = env59482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59481 == env59482) = true)

theorem identity59482 : scanCanonicalize (H12AffineFastState.compose env59482 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59482 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59483 : List Nat := [2,4,8,16,17,64,128,256,0,409,324,461,25,413,276,65536,65798,81,408,276,65602,17,64,138,144,17,66015,412,65878,65739,65542,65674,256,65675,65798,0]

theorem envBound59483 : H12AffineFastState.Bounded env59483 := by
  intro p hp
  have h : env59483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59482_59483 : H12AffineEnvironment.transform 4 17 env59482 = env59483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59482 == env59483) = true)

theorem identity59483 : scanCanonicalize (H12AffineFastState.compose env59483 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59484 : List Nat := [2,4,8,16,17,64,128,256,0,409,324,461,25,413,276,155,413,81,408,276,217,17,64,138,144,17,324,412,461,80,157,17,256,16,413,0]

theorem envBound59484 : H12AffineFastState.Bounded env59484 := by
  intro p hp
  have h : env59484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59483_59484 : H12AffineEnvironment.transform 15 155 env59483 = env59484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59483 == env59484) = true)

theorem identity59484 : scanCanonicalize (H12AffineFastState.compose env59484 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59484 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59485 : List Nat := [2,4,8,16,17,64,128,215,0,78,147,26,25,74,195,155,74,81,79,195,217,17,64,138,144,17,147,75,26,80,157,17,215,16,74,0]

theorem envBound59485 : H12AffineFastState.Bounded env59485 := by
  intro p hp
  have h : env59485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59484_59485 : H12AffineEnvironment.transform 7 215 env59484 = env59485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59484 == env59485) = true)

def env59486 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,65650,1416,65,3159,1289,16,334086,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound59486 : H12AffineFastState.Bounded env59486 := by
  intro p hp
  have h : env59486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59477_59486 : H12AffineEnvironment.transform 12 1409 env59477 = env59486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59477 == env59486) = true)

theorem identity59486 : scanCanonicalize (H12AffineFastState.compose env59486 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6543) := by decide +kernel

theorem selectedBound59486 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59487 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6543,3292,262144,1025,2128,6653,1416,65,3159,1289,16,262281,4177,3212,7389,6537,4208,256,6404,3292,1]

theorem envBound59487 : H12AffineFastState.Bounded env59487 := by
  intro p hp
  have h : env59487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59486_59487 : H12AffineEnvironment.transform 15 6543 env59486 = env59487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6543 env59486 == env59487) = true)

theorem identity59487 : scanCanonicalize (H12AffineFastState.compose env59487 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59487 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59488 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,5238,293,262144,1025,1449,5124,1416,65,430,1289,16,262281,4177,373,4388,5232,4208,256,5373,293,1]

theorem envBound59488 : H12AffineFastState.Bounded env59488 := by
  intro p hp
  have h : env59488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59487_59488 : H12AffineEnvironment.transform 10 1529 env59487 = env59488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59487 == env59488) = true)

theorem identity59488 : scanCanonicalize (H12AffineFastState.compose env59488 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59488 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59489 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,5238,293,5324,1025,1449,5124,1416,65,430,1289,16,5189,4177,373,4388,5232,4208,256,5373,293,1]

theorem envBound59489 : H12AffineFastState.Bounded env59489 := by
  intro p hp
  have h : env59489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59488_59489 : H12AffineEnvironment.transform 17 5324 env59488 = env59489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59488 == env59489) = true)

theorem identity59489 : scanCanonicalize (H12AffineFastState.compose env59489 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound59489 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59490 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,80,1409,0,1449,1062,293,1180,1025,1449,1108,1416,65,430,1289,16,1045,1,373,372,1056,32,256,1197,293,1]

theorem envBound59490 : H12AffineFastState.Bounded env59490 := by
  intro p hp
  have h : env59490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59489_59490 : H12AffineEnvironment.transform 11 80 env59489 = env59490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env59489 == env59490) = true)

theorem identity59490 : scanCanonicalize (H12AffineFastState.compose env59490 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59490 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59491 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,80,1149,0,1109,1062,217,1180,1025,1109,1108,1140,65,82,1269,16,1045,1,137,136,1056,32,252,1197,217,1]

theorem envBound59491 : H12AffineFastState.Bounded env59491 := by
  intro p hp
  have h : env59491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59490_59491 : H12AffineEnvironment.transform 7 252 env59490 = env59491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59490 == env59491) = true)

theorem identity59491 : scanCanonicalize (H12AffineFastState.compose env59491 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59491 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59492 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1029,0,1069,0,1029,1062,137,1180,1025,1029,1028,1060,17,2,1189,16,1045,1,137,136,1056,32,172,1197,137,1]

theorem envBound59492 : H12AffineFastState.Bounded env59492 := by
  intro p hp
  have h : env59492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59491_59492 : H12AffineEnvironment.transform 5 16 env59491 = env59492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59491 == env59492) = true)

theorem identity59492 : scanCanonicalize (H12AffineFastState.compose env59492 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59493 : List Nat := [2,4,8,3,32,3,128,172,0,1024,1029,0,1069,0,1029,1062,137,1167,1025,1029,1028,1060,2,2,1189,3,1030,1,137,136,1056,32,172,1197,137,1]

theorem envBound59493 : H12AffineFastState.Bounded env59493 := by
  intro p hp
  have h : env59493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59492_59493 : H12AffineEnvironment.transform 3 3 env59492 = env59493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59492 == env59493) = true)

theorem identity59493 : scanCanonicalize (H12AffineFastState.compose env59493 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound59493 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59494 : List Nat := [2,4,8,3,32,3,11,39,0,1024,1029,0,1069,0,1029,1062,2,1028,1025,1029,1028,1060,2,2,1070,3,1030,1,2,3,1056,32,39,1062,2,1]

theorem envBound59494 : H12AffineFastState.Bounded env59494 := by
  intro p hp
  have h : env59494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59493_59494 : H12AffineEnvironment.transform 6 11 env59493 = env59494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env59493 == env59494) = true)

theorem identity59494 : scanCanonicalize (H12AffineFastState.compose env59494 (packedSelected [6,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound59494 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59495 : List Nat := [2,4,8,3,32,3,11,39,0,37,32,0,8,0,32,3,2,33,36,32,33,1,2,2,11,3,35,1,2,3,5,32,39,3,2,1]

theorem envBound59495 : H12AffineFastState.Bounded env59495 := by
  intro p hp
  have h : env59495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59494_59495 : H12AffineEnvironment.transform 9 37 env59494 = env59495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env59494 == env59495) = true)

theorem identity59495 : scanCanonicalize (H12AffineFastState.compose env59495 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound59495 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env59496 : List Nat := [2,4,8,3,9,3,11,14,0,12,9,0,8,0,9,3,2,8,13,9,8,1,2,2,11,3,10,1,2,3,5,9,14,3,2,1]

theorem envBound59496 : H12AffineFastState.Bounded env59496 := by
  intro p hp
  have h : env59496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59495_59496 : H12AffineEnvironment.transform 4 9 env59495 = env59496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env59495 == env59496) = true)

theorem identity59496 : scanCanonicalize (H12AffineFastState.compose env59496 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59496 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59497 : List Nat := [2,4,3,3,2,3,0,5,0,7,2,0,3,0,2,3,2,3,6,2,3,1,2,2,0,3,1,1,2,3,5,2,5,3,2,1]

theorem envBound59497 : H12AffineFastState.Bounded env59497 := by
  intro p hp
  have h : env59497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59496_59497 : H12AffineEnvironment.transform 2 3 env59496 = env59497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59496 == env59497) = true)

theorem identity59497 : scanCanonicalize (H12AffineFastState.compose env59497 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59498 : List Nat := [1,4,0,0,1,0,0,5,0,4,1,0,0,0,1,0,1,0,5,1,0,1,1,1,0,0,1,1,1,0,5,1,5,0,1,1]

theorem envBound59498 : H12AffineFastState.Bounded env59498 := by
  intro p hp
  have h : env59498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59497_59498 : H12AffineEnvironment.transform 0 1 env59497 = env59498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59497 == env59498) = true)

def env59499 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1289,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59499 : H12AffineFastState.Bounded env59499 := by
  intro p hp
  have h : env59499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59475_59499 : H12AffineEnvironment.transform 8 1 env59475 = env59499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59475 == env59499) = true)

theorem identity59499 : scanCanonicalize (H12AffineFastState.compose env59499 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound59499 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59500 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,65650,1416,9664,3158,1289,9617,334087,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound59500 : H12AffineFastState.Bounded env59500 := by
  intro p hp
  have h : env59500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59499_59500 : H12AffineEnvironment.transform 20 65650 env59499 = env59500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env59499 == env59500) = true)

def env59501 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,65650,1416,64,3158,1289,17,334087,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound59501 : H12AffineFastState.Bounded env59501 := by
  intro p hp
  have h : env59501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59500_59501 : H12AffineEnvironment.transform 12 1408 env59500 = env59501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59500 == env59501) = true)

theorem identity59501 : scanCanonicalize (H12AffineFastState.compose env59501 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59501 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59502 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,65650,1416,64,3158,1289,17,328078,2264,69003,66899,65542,68094,256,65675,69083,1]

theorem envBound59502 : H12AffineFastState.Bounded env59502 := by
  intro p hp
  have h : env59502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59501_59502 : H12AffineEnvironment.transform 11 2185 env59501 = env59502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59501 == env59502) = true)

theorem identity59502 : scanCanonicalize (H12AffineFastState.compose env59502 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound59502 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59503 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2129,65536,69083,97,1025,2129,65650,1416,64,3158,1289,17,66031,2264,69003,66899,65542,68094,256,65675,69083,1]

theorem envBound59503 : H12AffineFastState.Bounded env59503 := by
  intro p hp
  have h : env59503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59502_59503 : H12AffineEnvironment.transform 17 97 env59502 = env59503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env59502 == env59503) = true)

theorem identity59503 : scanCanonicalize (H12AffineFastState.compose env59503 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59503 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59504 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1244,1109,1408,1029,1165,65536,65799,97,1025,1165,65650,1416,64,138,1289,17,66031,1028,65879,66899,65542,66850,256,65675,65799,1]

theorem envBound59504 : H12AffineFastState.Bounded env59504 := by
  intro p hp
  have h : env59504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59503_59504 : H12AffineEnvironment.transform 10 1244 env59503 = env59504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59503 == env59504) = true)

theorem identity59504 : scanCanonicalize (H12AffineFastState.compose env59504 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59504 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59505 : List Nat := [2,4,8,16,32,64,128,256,1,409,325,460,25,412,276,65536,65799,97,408,276,65650,17,64,138,144,17,66031,413,65879,65738,65542,65723,256,65675,65799,1]

theorem envBound59505 : H12AffineFastState.Bounded env59505 := by
  intro p hp
  have h : env59505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59504_59505 : H12AffineEnvironment.transform 9 409 env59504 = env59505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59504 == env59505) = true)

theorem identity59505 : scanCanonicalize (H12AffineFastState.compose env59505 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59505 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59506 : List Nat := [2,4,8,16,17,64,128,256,1,409,325,460,25,412,276,65536,65799,80,408,276,65603,17,64,138,144,17,66014,413,65879,65738,65542,65674,256,65675,65799,1]

theorem envBound59506 : H12AffineFastState.Bounded env59506 := by
  intro p hp
  have h : env59506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59505_59506 : H12AffineEnvironment.transform 4 17 env59505 = env59506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59505 == env59506) = true)

theorem identity59506 : scanCanonicalize (H12AffineFastState.compose env59506 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59506 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59507 : List Nat := [2,4,8,16,17,64,128,256,1,409,325,460,25,412,276,155,412,80,408,276,216,17,64,138,144,17,325,413,460,81,157,17,256,16,412,1]

theorem envBound59507 : H12AffineFastState.Bounded env59507 := by
  intro p hp
  have h : env59507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59506_59507 : H12AffineEnvironment.transform 15 155 env59506 = env59507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59506 == env59507) = true)

theorem identity59507 : scanCanonicalize (H12AffineFastState.compose env59507 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59507 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59508 : List Nat := [2,4,8,16,17,64,128,214,1,79,147,26,25,74,194,155,74,80,78,194,216,17,64,138,144,17,147,75,26,81,157,17,214,16,74,1]

theorem envBound59508 : H12AffineFastState.Bounded env59508 := by
  intro p hp
  have h : env59508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59507_59508 : H12AffineEnvironment.transform 7 214 env59507 = env59508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59507 == env59508) = true)

theorem identity59508 : scanCanonicalize (H12AffineFastState.compose env59508 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59508 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59509 : List Nat := [2,4,8,16,17,64,89,15,1,79,74,26,25,74,27,66,74,80,78,27,1,17,64,83,73,17,74,75,26,81,68,17,15,16,74,1]

theorem envBound59509 : H12AffineFastState.Bounded env59509 := by
  intro p hp
  have h : env59509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59508_59509 : H12AffineEnvironment.transform 6 89 env59508 = env59509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59508 == env59509) = true)

theorem identity59509 : scanCanonicalize (H12AffineFastState.compose env59509 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59510 : List Nat := [2,4,8,16,17,16,9,15,1,31,26,26,25,26,27,18,26,0,30,27,1,17,16,3,25,17,26,27,26,1,20,17,15,16,26,1]

theorem envBound59510 : H12AffineFastState.Bounded env59510 := by
  intro p hp
  have h : env59510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59509_59510 : H12AffineEnvironment.transform 5 16 env59509 = env59510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59509 == env59510) = true)

def env59511 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,65650,1416,65,3158,1289,16,334087,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound59511 : H12AffineFastState.Bounded env59511 := by
  intro p hp
  have h : env59511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59500_59511 : H12AffineEnvironment.transform 12 1409 env59500 = env59511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59500 == env59511) = true)

theorem identity59511 : scanCanonicalize (H12AffineFastState.compose env59511 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6542) := by decide +kernel

theorem selectedBound59511 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59512 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6542,3293,262144,1025,2129,6652,1416,65,3158,1289,16,262281,4177,3213,7389,6536,4208,256,6405,3293,0]

theorem envBound59512 : H12AffineFastState.Bounded env59512 := by
  intro p hp
  have h : env59512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59511_59512 : H12AffineEnvironment.transform 15 6542 env59511 = env59512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6542 env59511 == env59512) = true)

theorem identity59512 : scanCanonicalize (H12AffineFastState.compose env59512 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59512 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59513 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,5238,293,262144,1025,1449,5124,1416,65,430,1289,16,262281,4177,373,4389,5232,4208,256,5373,293,0]

theorem envBound59513 : H12AffineFastState.Bounded env59513 := by
  intro p hp
  have h : env59513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59512_59513 : H12AffineEnvironment.transform 10 1528 env59512 = env59513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59512 == env59513) = true)

theorem identity59513 : scanCanonicalize (H12AffineFastState.compose env59513 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59513 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59514 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,5238,293,5324,1025,1449,5124,1416,65,430,1289,16,5189,4177,373,4389,5232,4208,256,5373,293,0]

theorem envBound59514 : H12AffineFastState.Bounded env59514 := by
  intro p hp
  have h : env59514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59513_59514 : H12AffineEnvironment.transform 17 5324 env59513 = env59514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59513 == env59514) = true)

theorem identity59514 : scanCanonicalize (H12AffineFastState.compose env59514 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound59514 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59515 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,80,1409,0,1449,1062,293,1180,1025,1449,1108,1416,65,430,1289,16,1045,1,373,373,1056,32,256,1197,293,0]

theorem envBound59515 : H12AffineFastState.Bounded env59515 := by
  intro p hp
  have h : env59515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59514_59515 : H12AffineEnvironment.transform 11 80 env59514 = env59515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env59514 == env59515) = true)

theorem identity59515 : scanCanonicalize (H12AffineFastState.compose env59515 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59515 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59516 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,80,1148,0,1108,1062,216,1180,1025,1108,1108,1141,65,83,1268,16,1045,1,136,136,1056,32,253,1197,216,0]

theorem envBound59516 : H12AffineFastState.Bounded env59516 := by
  intro p hp
  have h : env59516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59515_59516 : H12AffineEnvironment.transform 7 253 env59515 = env59516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59515 == env59516) = true)

theorem identity59516 : scanCanonicalize (H12AffineFastState.compose env59516 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59516 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59517 : List Nat := [2,4,8,16,32,64,128,253,1,141,136,80,241,0,217,171,216,17,140,217,217,248,65,83,121,16,152,1,136,136,173,32,253,32,216,0]

theorem envBound59517 : H12AffineFastState.Bounded env59517 := by
  intro p hp
  have h : env59517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59516_59517 : H12AffineEnvironment.transform 9 141 env59516 = env59517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59516 == env59517) = true)

theorem identity59517 : scanCanonicalize (H12AffineFastState.compose env59517 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59517 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59518 : List Nat := [2,4,8,16,16,64,128,205,1,141,136,80,193,0,217,155,216,17,140,217,217,200,65,83,73,16,152,1,136,136,157,16,205,16,216,0]

theorem envBound59518 : H12AffineFastState.Bounded env59518 := by
  intro p hp
  have h : env59518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59517_59518 : H12AffineEnvironment.transform 4 16 env59517 = env59518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59517 == env59518) = true)

theorem identity59518 : scanCanonicalize (H12AffineFastState.compose env59518 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 75) := by decide +kernel

theorem selectedBound59518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59519 : List Nat := [2,4,8,16,16,64,75,6,1,70,67,80,10,0,18,80,19,17,71,18,18,3,65,83,73,16,83,1,67,67,86,16,6,16,19,0]

theorem envBound59519 : H12AffineFastState.Bounded env59519 := by
  intro p hp
  have h : env59519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59518_59519 : H12AffineEnvironment.transform 6 75 env59518 = env59519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 75 env59518 == env59519) = true)

theorem identity59519 : scanCanonicalize (H12AffineFastState.compose env59519 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound59519 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59520 : List Nat := [2,4,8,16,16,9,2,6,1,15,10,25,10,0,18,25,19,17,14,18,18,3,8,26,0,16,26,1,10,10,31,16,6,16,19,0]

theorem envBound59520 : H12AffineFastState.Bounded env59520 := by
  intro p hp
  have h : env59520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59519_59520 : H12AffineEnvironment.transform 5 9 env59519 = env59520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env59519 == env59520) = true)

theorem identity59520 : scanCanonicalize (H12AffineFastState.compose env59520 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59520 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59521 : List Nat := [2,4,8,9,9,9,2,6,1,15,10,0,10,0,11,0,10,8,14,11,11,3,8,3,0,9,3,1,10,10,6,9,6,9,10,0]

theorem envBound59521 : H12AffineFastState.Bounded env59521 := by
  intro p hp
  have h : env59521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59520_59521 : H12AffineEnvironment.transform 3 9 env59520 = env59521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59520 == env59521) = true)

theorem identity59521 : scanCanonicalize (H12AffineFastState.compose env59521 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59521 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59522 : List Nat := [2,4,0,1,1,1,2,6,1,7,2,0,2,0,3,0,2,0,6,3,3,3,0,3,0,1,3,1,2,2,6,1,6,1,2,0]

theorem envBound59522 : H12AffineFastState.Bounded env59522 := by
  intro p hp
  have h : env59522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59521_59522 : H12AffineEnvironment.transform 2 0 env59521 = env59522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59521 == env59522) = true)

def env59523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3670,1288,9616,2366324,4177,77954,67410,65543,68606,256,65675,78034,10113]

theorem envBound59523 : H12AffineFastState.Bounded env59523 := by
  intro p hp
  have h : env59523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59474_59523 : H12AffineEnvironment.transform 22 9665 env59474 = env59523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59474 == env59523) = true)

def env59524 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound59524 : H12AffineFastState.Bounded env59524 := by
  intro p hp
  have h : env59524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59523_59524 : H12AffineEnvironment.transform 8 0 env59523 = env59524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59523 == env59524) = true)

theorem identity59524 : scanCanonicalize (H12AffineFastState.compose env59524 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 6178) := by decide +kernel

theorem selectedBound59524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59525 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,6178,10480,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2365812,4177,10400,7536,6181,4572,256,6313,10480,9601]

theorem envBound59525 : H12AffineFastState.Bounded env59525 := by
  intro p hp
  have h : env59525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59524_59525 : H12AffineEnvironment.transform 15 6178 env59524 = env59525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6178 env59524 == env59525) = true)

def env59526 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6178,3440,262144,1025,2128,2097152,1416,65,3158,1288,16,2365812,4177,3360,7536,6181,4572,256,6313,3440,1]

theorem envBound59526 : H12AffineFastState.Bounded env59526 := by
  intro p hp
  have h : env59526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59525_59526 : H12AffineEnvironment.transform 12 1408 env59525 = env59526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59525 == env59526) = true)

theorem identity59526 : scanCanonicalize (H12AffineFastState.compose env59526 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59526 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59527 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6178,3440,262144,1025,2128,6653,1416,65,3158,1288,16,262281,4177,3360,7536,6181,4572,256,6313,3440,1]

theorem envBound59527 : H12AffineFastState.Bounded env59527 := by
  intro p hp
  have h : env59527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59526_59527 : H12AffineEnvironment.transform 20 6653 env59526 = env59527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59526 == env59527) = true)

theorem identity59527 : scanCanonicalize (H12AffineFastState.compose env59527 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59527 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59528 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,5595,137,262144,1025,1449,5124,1416,65,431,1288,16,262281,4177,217,4233,5596,4572,256,5456,137,1]

theorem envBound59528 : H12AffineFastState.Bounded env59528 := by
  intro p hp
  have h : env59528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59527_59528 : H12AffineEnvironment.transform 10 1529 env59527 = env59528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59527 == env59528) = true)

theorem identity59528 : scanCanonicalize (H12AffineFastState.compose env59528 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59528 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59529 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,5595,137,5325,1025,1449,5124,1416,65,431,1288,16,5188,4177,217,4233,5596,4572,256,5456,137,1]

theorem envBound59529 : H12AffineFastState.Bounded env59529 := by
  intro p hp
  have h : env59529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59528_59529 : H12AffineEnvironment.transform 17 5325 env59528 = env59529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59528 == env59529) = true)

theorem identity59529 : scanCanonicalize (H12AffineFastState.compose env59529 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound59529 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59530 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,509,1408,429,1449,1062,137,1328,1025,1449,1529,1416,65,431,1288,16,1465,428,217,372,1057,33,256,1197,137,1]

theorem envBound59530 : H12AffineFastState.Bounded env59530 := by
  intro p hp
  have h : env59530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59529_59530 : H12AffineEnvironment.transform 11 509 env59529 = env59530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env59529 == env59530) = true)

theorem identity59530 : scanCanonicalize (H12AffineFastState.compose env59530 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59530 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59531 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,0,1149,80,1108,1062,137,1229,1025,1108,1028,1141,65,82,1269,16,1092,81,217,137,1057,33,253,1197,137,1]

theorem envBound59531 : H12AffineFastState.Bounded env59531 := by
  intro p hp
  have h : env59531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59530_59531 : H12AffineEnvironment.transform 7 253 env59530 = env59531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59530 == env59531) = true)

theorem identity59531 : scanCanonicalize (H12AffineFastState.compose env59531 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59531 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59532 : List Nat := [2,4,8,16,32,64,128,253,0,140,136,0,241,80,216,170,137,65,141,216,136,249,65,82,121,16,200,81,217,137,173,33,253,33,137,1]

theorem envBound59532 : H12AffineFastState.Bounded env59532 := by
  intro p hp
  have h : env59532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59531_59532 : H12AffineEnvironment.transform 9 140 env59531 = env59532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59531 == env59532) = true)

theorem identity59532 : scanCanonicalize (H12AffineFastState.compose env59532 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound59532 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59533 : List Nat := [2,4,8,16,32,64,25,100,0,21,17,0,104,80,65,51,16,65,20,65,17,96,65,82,121,16,81,81,64,16,52,33,100,33,16,1]

theorem envBound59533 : H12AffineFastState.Bounded env59533 := by
  intro p hp
  have h : env59533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59532_59533 : H12AffineEnvironment.transform 6 25 env59532 = env59533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env59532 == env59533) = true)

def env59534 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,2097152,1416,64,3158,1288,17,2365812,4177,3361,7536,6181,4572,256,6313,3441,0]

theorem envBound59534 : H12AffineFastState.Bounded env59534 := by
  intro p hp
  have h : env59534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59525_59534 : H12AffineEnvironment.transform 12 1409 env59525 = env59534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59525 == env59534) = true)

theorem identity59534 : scanCanonicalize (H12AffineFastState.compose env59534 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 217) := by decide +kernel

theorem selectedBound59534 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59535 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,217,1416,64,3158,1288,17,268717,4177,3361,7536,6181,4572,256,6313,3441,0]

theorem envBound59535 : H12AffineFastState.Bounded env59535 := by
  intro p hp
  have h : env59535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59534_59535 : H12AffineEnvironment.transform 20 217 env59534 = env59535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 217 env59534 == env59535) = true)

theorem identity59535 : scanCanonicalize (H12AffineFastState.compose env59535 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59535 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59536 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,6178,3441,6377,1025,2128,217,1416,64,3158,1288,17,324,4177,3361,7536,6181,4572,256,6313,3441,0]

theorem envBound59536 : H12AffineFastState.Bounded env59536 := by
  intro p hp
  have h : env59536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59535_59536 : H12AffineEnvironment.transform 17 6377 env59535 = env59536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59535 == env59536) = true)

theorem identity59536 : scanCanonicalize (H12AffineFastState.compose env59536 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59536 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59537 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1409,413,2128,2543,3441,2340,1025,2128,217,1416,64,3158,1288,17,324,412,3361,3261,2536,17,256,2404,3441,0]

theorem envBound59537 : H12AffineFastState.Bounded env59537 := by
  intro p hp
  have h : env59537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59536_59537 : H12AffineEnvironment.transform 11 461 env59536 = env59537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59536 == env59537) = true)

theorem identity59537 : scanCanonicalize (H12AffineFastState.compose env59537 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59537 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59538 : List Nat := [2,4,8,16,17,64,128,256,0,1024,2048,461,1409,413,2128,2526,3392,2325,1025,2128,217,1416,64,3158,1288,17,324,412,3344,3212,2521,17,256,2389,3392,0]

theorem envBound59538 : H12AffineFastState.Bounded env59538 := by
  intro p hp
  have h : env59538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59537_59538 : H12AffineEnvironment.transform 4 17 env59537 = env59538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59537 == env59538) = true)

theorem identity59538 : scanCanonicalize (H12AffineFastState.compose env59538 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59538 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59539 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1244,461,1409,413,1164,1282,412,1481,1025,1164,217,1416,64,138,1288,17,324,412,460,80,1285,17,256,1417,412,0]

theorem envBound59539 : H12AffineFastState.Bounded env59539 := by
  intro p hp
  have h : env59539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59538_59539 : H12AffineEnvironment.transform 10 1244 env59538 = env59539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59538 == env59539) = true)

theorem identity59539 : scanCanonicalize (H12AffineFastState.compose env59539 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59539 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59540 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1244,146,1246,194,1164,1117,195,1174,1025,1164,217,1239,64,138,1111,17,27,195,147,80,1114,17,95,1238,195,0]

theorem envBound59540 : H12AffineFastState.Bounded env59540 := by
  intro p hp
  have h : env59540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59539_59540 : H12AffineEnvironment.transform 7 95 env59539 = env59540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59539 == env59540) = true)

theorem identity59540 : scanCanonicalize (H12AffineFastState.compose env59540 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59540 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59541 : List Nat := [2,4,8,16,17,64,128,95,0,198,26,146,24,194,74,155,195,80,199,74,217,17,64,138,145,17,27,195,147,80,156,17,95,16,195,0]

theorem envBound59541 : H12AffineFastState.Bounded env59541 := by
  intro p hp
  have h : env59541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59540_59541 : H12AffineEnvironment.transform 9 198 env59540 = env59541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59540 == env59541) = true)

def env59542 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1288,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound59542 : H12AffineFastState.Bounded env59542 := by
  intro p hp
  have h : env59542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59523_59542 : H12AffineEnvironment.transform 8 1 env59523 = env59542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59523 == env59542) = true)

theorem identity59542 : scanCanonicalize (H12AffineFastState.compose env59542 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 15779) := by decide +kernel

theorem selectedBound59542 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59543 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,15779,3441,262144,1025,2129,2097152,1416,9665,3159,1288,9616,2365813,4177,3361,14576,15780,13404,256,15656,3441,9600]

theorem envBound59543 : H12AffineFastState.Bounded env59543 := by
  intro p hp
  have h : env59543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59542_59543 : H12AffineEnvironment.transform 15 15779 env59542 = env59543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15779 env59542 == env59543) = true)

def env59544 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,2097152,1416,65,3159,1288,16,2365813,4177,3361,7536,6180,4572,256,6312,3441,0]

theorem envBound59544 : H12AffineFastState.Bounded env59544 := by
  intro p hp
  have h : env59544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59543_59544 : H12AffineEnvironment.transform 12 1408 env59543 = env59544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59543 == env59544) = true)

theorem identity59544 : scanCanonicalize (H12AffineFastState.compose env59544 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59544 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59545 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,6652,1416,65,3159,1288,16,262281,4177,3361,7536,6180,4572,256,6312,3441,0]

theorem envBound59545 : H12AffineFastState.Bounded env59545 := by
  intro p hp
  have h : env59545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59544_59545 : H12AffineEnvironment.transform 20 6652 env59544 = env59545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59544 == env59545) = true)

theorem identity59545 : scanCanonicalize (H12AffineFastState.compose env59545 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59545 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59546 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,5595,137,262144,1025,1449,5124,1416,65,431,1288,16,262281,4177,217,4232,5596,4572,256,5456,137,0]

theorem envBound59546 : H12AffineFastState.Bounded env59546 := by
  intro p hp
  have h : env59546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59545_59546 : H12AffineEnvironment.transform 10 1528 env59545 = env59546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59545 == env59546) = true)

theorem identity59546 : scanCanonicalize (H12AffineFastState.compose env59546 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59546 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59547 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,5595,137,5325,1025,1449,5124,1416,65,431,1288,16,5188,4177,217,4232,5596,4572,256,5456,137,0]

theorem envBound59547 : H12AffineFastState.Bounded env59547 := by
  intro p hp
  have h : env59547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59546_59547 : H12AffineEnvironment.transform 17 5325 env59546 = env59547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59546 == env59547) = true)

theorem identity59547 : scanCanonicalize (H12AffineFastState.compose env59547 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound59547 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59548 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,509,1408,429,1449,1062,137,1328,1025,1449,1529,1416,65,431,1288,16,1465,428,217,373,1057,33,256,1197,137,0]

theorem envBound59548 : H12AffineFastState.Bounded env59548 := by
  intro p hp
  have h : env59548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59547_59548 : H12AffineEnvironment.transform 11 509 env59547 = env59548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env59547 == env59548) = true)

theorem identity59548 : scanCanonicalize (H12AffineFastState.compose env59548 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59548 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59549 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,1,1148,81,1109,1062,137,1228,1025,1109,1029,1140,65,83,1268,16,1093,80,217,137,1057,33,252,1197,137,0]

theorem envBound59549 : H12AffineFastState.Bounded env59549 := by
  intro p hp
  have h : env59549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59548_59549 : H12AffineEnvironment.transform 7 252 env59548 = env59549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59548 == env59549) = true)

theorem identity59549 : scanCanonicalize (H12AffineFastState.compose env59549 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59549 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59550 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1028,1,1068,1,1029,1062,137,1180,1025,1029,1029,1060,17,3,1188,16,1045,0,137,137,1057,33,172,1197,137,0]

theorem envBound59550 : H12AffineFastState.Bounded env59550 := by
  intro p hp
  have h : env59550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59549_59550 : H12AffineEnvironment.transform 5 16 env59549 = env59550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59549 == env59550) = true)

theorem identity59550 : scanCanonicalize (H12AffineFastState.compose env59550 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound59550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59551 : List Nat := [2,4,8,16,32,16,26,54,1,1024,1028,1,1068,1,1029,1062,19,1030,1025,1029,1029,1060,17,3,1086,16,1045,0,19,19,1057,33,54,1079,19,0]

theorem envBound59551 : H12AffineFastState.Bounded env59551 := by
  intro p hp
  have h : env59551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59550_59551 : H12AffineEnvironment.transform 6 26 env59550 = env59551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env59550 == env59551) = true)

theorem identity59551 : scanCanonicalize (H12AffineFastState.compose env59551 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59551 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59552 : List Nat := [0,4,8,16,32,16,24,52,1,1024,1028,1,1068,1,1029,1060,17,1028,1025,1029,1029,1060,17,1,1084,16,1045,0,17,17,1057,33,52,1077,17,0]

theorem envBound59552 : H12AffineFastState.Bounded env59552 := by
  intro p hp
  have h : env59552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59551_59552 : H12AffineEnvironment.transform 0 0 env59551 = env59552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59551 == env59552) = true)

theorem identity59552 : scanCanonicalize (H12AffineFastState.compose env59552 (packedSelected [6,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound59552 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59553 : List Nat := [0,4,8,16,32,16,24,52,1,37,33,1,9,1,32,1,17,33,36,32,32,1,17,1,25,16,48,0,17,17,4,33,52,16,17,0]

theorem envBound59553 : H12AffineFastState.Bounded env59553 := by
  intro p hp
  have h : env59553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59552_59553 : H12AffineEnvironment.transform 9 37 env59552 = env59553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env59552 == env59553) = true)

theorem identity59553 : scanCanonicalize (H12AffineFastState.compose env59553 (packedSelected [1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59553 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env59554 : List Nat := [0,4,8,0,32,0,8,36,1,37,33,1,9,1,32,1,1,33,36,32,32,1,1,1,9,0,32,0,1,1,4,33,36,0,1,0]

theorem envBound59554 : H12AffineFastState.Bounded env59554 := by
  intro p hp
  have h : env59554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59553_59554 : H12AffineEnvironment.transform 3 0 env59553 = env59554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59553 == env59554) = true)

theorem identity59554 : scanCanonicalize (H12AffineFastState.compose env59554 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound59554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59555 : List Nat := [0,4,8,0,8,0,8,12,1,13,9,1,9,1,8,1,1,9,12,8,8,1,1,1,9,0,8,0,1,1,4,9,12,0,1,0]

theorem envBound59555 : H12AffineFastState.Bounded env59555 := by
  intro p hp
  have h : env59555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59554_59555 : H12AffineEnvironment.transform 4 8 env59554 = env59555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env59554 == env59555) = true)

theorem identity59555 : scanCanonicalize (H12AffineFastState.compose env59555 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59555 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59556 : List Nat := [0,4,0,0,0,0,0,4,1,5,1,1,1,1,0,1,1,1,4,0,0,1,1,1,1,0,0,0,1,1,4,1,4,0,1,0]

theorem envBound59556 : H12AffineFastState.Bounded env59556 := by
  intro p hp
  have h : env59556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59555_59556 : H12AffineEnvironment.transform 2 0 env59555 = env59556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59555 == env59556) = true)

def env59557 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,2097152,1416,64,3159,1288,17,2365813,4177,3361,7537,6181,4573,256,6313,3441,1]

theorem envBound59557 : H12AffineFastState.Bounded env59557 := by
  intro p hp
  have h : env59557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59543_59557 : H12AffineEnvironment.transform 12 1409 env59543 = env59557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59543 == env59557) = true)

theorem identity59557 : scanCanonicalize (H12AffineFastState.compose env59557 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound59557 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59558 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,216,1416,64,3159,1288,17,268717,4177,3361,7537,6181,4573,256,6313,3441,1]

theorem envBound59558 : H12AffineFastState.Bounded env59558 := by
  intro p hp
  have h : env59558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59557_59558 : H12AffineEnvironment.transform 20 216 env59557 = env59558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env59557 == env59558) = true)

theorem identity59558 : scanCanonicalize (H12AffineFastState.compose env59558 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59558 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59559 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,6178,3441,6376,1025,2129,216,1416,64,3159,1288,17,325,4177,3361,7537,6181,4573,256,6313,3441,1]

theorem envBound59559 : H12AffineFastState.Bounded env59559 := by
  intro p hp
  have h : env59559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59558_59559 : H12AffineEnvironment.transform 17 6376 env59558 = env59559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59558 == env59559) = true)

theorem identity59559 : scanCanonicalize (H12AffineFastState.compose env59559 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59559 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59560 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1409,412,2129,2542,3441,2340,1025,2129,216,1416,64,3159,1288,17,325,413,3361,3261,2537,17,256,2405,3441,1]

theorem envBound59560 : H12AffineFastState.Bounded env59560 := by
  intro p hp
  have h : env59560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59559_59560 : H12AffineEnvironment.transform 11 460 env59559 = env59560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59559 == env59560) = true)

theorem identity59560 : scanCanonicalize (H12AffineFastState.compose env59560 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1260) := by decide +kernel

theorem selectedBound59560 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59561 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1260,460,1409,412,1213,1282,413,1480,1025,1213,216,1416,64,187,1288,17,325,413,461,81,1285,17,256,1417,413,1]

theorem envBound59561 : H12AffineFastState.Bounded env59561 := by
  intro p hp
  have h : env59561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59560_59561 : H12AffineEnvironment.transform 10 1260 env59560 = env59561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1260 env59560 == env59561) = true)

theorem identity59561 : scanCanonicalize (H12AffineFastState.compose env59561 (packedSelected [1,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59561 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env59562 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1245,460,1409,412,1164,1282,413,1480,1025,1164,216,1416,64,138,1288,17,325,413,461,81,1285,17,256,1417,413,1]

theorem envBound59562 : H12AffineFastState.Bounded env59562 := by
  intro p hp
  have h : env59562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59561_59562 : H12AffineEnvironment.transform 4 17 env59561 = env59562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59561 == env59562) = true)

theorem identity59562 : scanCanonicalize (H12AffineFastState.compose env59562 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59562 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59563 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1245,147,1246,195,1164,1117,194,1175,1025,1164,216,1239,64,138,1111,17,26,194,146,81,1114,17,95,1238,194,1]

theorem envBound59563 : H12AffineFastState.Bounded env59563 := by
  intro p hp
  have h : env59563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59562_59563 : H12AffineEnvironment.transform 7 95 env59562 = env59563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59562 == env59563) = true)

theorem identity59563 : scanCanonicalize (H12AffineFastState.compose env59563 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59563 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59564 : List Nat := [2,4,8,16,17,64,128,95,1,198,27,147,24,195,74,155,194,81,199,74,216,17,64,138,145,17,26,194,146,81,156,17,95,16,194,1]

theorem envBound59564 : H12AffineFastState.Bounded env59564 := by
  intro p hp
  have h : env59564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59563_59564 : H12AffineEnvironment.transform 9 198 env59563 = env59564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59563 == env59564) = true)

def env59565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399767,8397001,8388689,2366325,4177,77954,67411,8463814,8465983,256,65674,78034,8389184]

theorem envBound59565 : H12AffineFastState.Bounded env59565 := by
  intro p hp
  have h : env59565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59473_59565 : H12AffineEnvironment.transform 21 1417 env59473 = env59565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59473 == env59565) = true)

def env59566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3671,1289,9617,2366325,4177,77954,67411,65542,68607,256,65674,78034,10112]

theorem envBound59566 : H12AffineFastState.Bounded env59566 := by
  intro p hp
  have h : env59566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59565_59566 : H12AffineEnvironment.transform 22 9664 env59565 = env59566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59565 == env59566) = true)

def env59567 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1289,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59567 : H12AffineFastState.Bounded env59567 := by
  intro p hp
  have h : env59567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59566_59567 : H12AffineEnvironment.transform 8 0 env59566 = env59567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59566 == env59567) = true)

theorem identity59567 : scanCanonicalize (H12AffineFastState.compose env59567 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound59567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59568 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,68782,1417,9664,3159,1289,9617,333275,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59568 : H12AffineFastState.Bounded env59568 := by
  intro p hp
  have h : env59568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59567_59568 : H12AffineEnvironment.transform 20 68782 env59567 = env59568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env59567 == env59568) = true)

def env59569 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,68782,1417,64,3159,1289,17,333275,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound59569 : H12AffineFastState.Bounded env59569 := by
  intro p hp
  have h : env59569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59568_59569 : H12AffineEnvironment.transform 12 1408 env59568 = env59569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59568 == env59569) = true)

theorem identity59569 : scanCanonicalize (H12AffineFastState.compose env59569 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound59569 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59570 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,68782,1417,64,3159,1289,17,328079,1029,65878,66899,65542,68095,256,65674,65798,0]

theorem envBound59570 : H12AffineFastState.Bounded env59570 := by
  intro p hp
  have h : env59570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59569_59570 : H12AffineEnvironment.transform 11 1108 env59569 = env59570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env59569 == env59570) = true)

theorem identity59570 : scanCanonicalize (H12AffineFastState.compose env59570 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound59570 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59571 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2128,65536,65798,3260,1025,2128,68782,1417,64,3159,1289,17,68915,1029,65878,66899,65542,68095,256,65674,65798,0]

theorem envBound59571 : H12AffineFastState.Bounded env59571 := by
  intro p hp
  have h : env59571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59570_59571 : H12AffineEnvironment.transform 17 3260 env59570 = env59571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env59570 == env59571) = true)

theorem identity59571 : scanCanonicalize (H12AffineFastState.compose env59571 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59571 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59572 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1245,1108,1408,1028,1165,65536,65798,97,1025,1165,65651,1417,64,138,1289,17,66030,1029,65878,66899,65542,66850,256,65674,65798,0]

theorem envBound59572 : H12AffineFastState.Bounded env59572 := by
  intro p hp
  have h : env59572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59571_59572 : H12AffineEnvironment.transform 10 1245 env59571 = env59572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59571 == env59572) = true)

theorem identity59572 : scanCanonicalize (H12AffineFastState.compose env59572 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59572 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59573 : List Nat := [2,4,8,16,32,64,128,256,0,408,325,460,24,412,277,65536,65798,97,409,277,65651,17,64,138,145,17,66030,413,65878,65739,65542,65722,256,65674,65798,0]

theorem envBound59573 : H12AffineFastState.Bounded env59573 := by
  intro p hp
  have h : env59573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59572_59573 : H12AffineEnvironment.transform 9 408 env59572 = env59573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59572 == env59573) = true)

theorem identity59573 : scanCanonicalize (H12AffineFastState.compose env59573 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59573 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59574 : List Nat := [2,4,8,16,17,64,128,256,0,408,325,460,24,412,277,65536,65798,80,409,277,65602,17,64,138,145,17,66015,413,65878,65739,65542,65675,256,65674,65798,0]

theorem envBound59574 : H12AffineFastState.Bounded env59574 := by
  intro p hp
  have h : env59574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59573_59574 : H12AffineEnvironment.transform 4 17 env59573 = env59574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59573 == env59574) = true)

theorem identity59574 : scanCanonicalize (H12AffineFastState.compose env59574 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59574 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59575 : List Nat := [2,4,8,16,17,64,128,256,0,408,325,460,24,412,277,154,412,80,409,277,216,17,64,138,145,17,325,413,460,81,156,17,256,16,412,0]

theorem envBound59575 : H12AffineFastState.Bounded env59575 := by
  intro p hp
  have h : env59575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59574_59575 : H12AffineEnvironment.transform 15 154 env59574 = env59575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59574 == env59575) = true)

theorem identity59575 : scanCanonicalize (H12AffineFastState.compose env59575 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59575 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59576 : List Nat := [2,4,8,16,17,64,128,215,0,79,146,27,24,75,194,154,75,80,78,194,216,17,64,138,145,17,146,74,27,81,156,17,215,16,75,0]

theorem envBound59576 : H12AffineFastState.Bounded env59576 := by
  intro p hp
  have h : env59576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59575_59576 : H12AffineEnvironment.transform 7 215 env59575 = env59576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59575 == env59576) = true)

def env59577 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,68782,1417,65,3159,1289,16,333275,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound59577 : H12AffineFastState.Bounded env59577 := by
  intro p hp
  have h : env59577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59568_59577 : H12AffineEnvironment.transform 12 1409 env59568 = env59577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59568 == env59577) = true)

theorem identity59577 : scanCanonicalize (H12AffineFastState.compose env59577 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound59577 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59578 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5458,1,262144,1025,2128,6652,1417,65,3159,1289,16,262281,4177,81,4097,5460,7341,256,5592,1,1]

theorem envBound59578 : H12AffineFastState.Bounded env59578 := by
  intro p hp
  have h : env59578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59577_59578 : H12AffineEnvironment.transform 15 5458 env59577 = env59578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env59577 == env59578) = true)

theorem identity59578 : scanCanonicalize (H12AffineFastState.compose env59578 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59578 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59579 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,5458,1,262144,1025,1449,5125,1417,65,430,1289,16,262281,4177,81,4097,5460,4436,256,5592,1,1]

theorem envBound59579 : H12AffineFastState.Bounded env59579 := by
  intro p hp
  have h : env59579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59578_59579 : H12AffineEnvironment.transform 10 1529 env59578 = env59579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59578 == env59579) = true)

theorem identity59579 : scanCanonicalize (H12AffineFastState.compose env59579 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59579 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59580 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,5458,1,5324,1025,1449,5125,1417,65,430,1289,16,5189,4177,81,4097,5460,4436,256,5592,1,1]

theorem envBound59580 : H12AffineFastState.Bounded env59580 := by
  intro p hp
  have h : env59580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59579_59580 : H12AffineEnvironment.transform 17 5324 env59579 = env59580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59579 == env59580) = true)

theorem identity59580 : scanCanonicalize (H12AffineFastState.compose env59580 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound59580 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59581 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,372,1409,292,1449,1062,1,1464,1025,1449,1393,1417,65,430,1289,16,1329,293,81,373,1056,32,256,1196,1,1]

theorem envBound59581 : H12AffineFastState.Bounded env59581 := by
  intro p hp
  have h : env59581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59580_59581 : H12AffineEnvironment.transform 11 372 env59580 = env59581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env59580 == env59581) = true)

theorem identity59581 : scanCanonicalize (H12AffineFastState.compose env59581 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59581 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59582 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,136,1149,216,1109,1062,1,1092,1025,1109,1165,1141,65,82,1269,16,1229,217,81,137,1056,32,252,1196,1,1]

theorem envBound59582 : H12AffineFastState.Bounded env59582 := by
  intro p hp
  have h : env59582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59581_59582 : H12AffineEnvironment.transform 7 252 env59581 = env59582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59581 == env59582) = true)

theorem identity59582 : scanCanonicalize (H12AffineFastState.compose env59582 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59582 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59583 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1029,136,1069,136,1029,1062,1,1044,1025,1029,1165,1061,17,2,1189,16,1181,137,1,137,1056,32,172,1196,1,1]

theorem envBound59583 : H12AffineFastState.Bounded env59583 := by
  intro p hp
  have h : env59583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59582_59583 : H12AffineEnvironment.transform 5 16 env59582 = env59583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59582 == env59583) = true)

theorem identity59583 : scanCanonicalize (H12AffineFastState.compose env59583 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59584 : List Nat := [2,4,8,2,32,2,128,172,0,1024,1029,136,1069,136,1029,1062,1,1030,1025,1029,1165,1061,3,2,1189,2,1167,137,1,137,1056,32,172,1196,1,1]

theorem envBound59584 : H12AffineFastState.Bounded env59584 := by
  intro p hp
  have h : env59584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59583_59584 : H12AffineEnvironment.transform 3 2 env59583 = env59584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59583 == env59584) = true)

theorem identity59584 : scanCanonicalize (H12AffineFastState.compose env59584 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59584 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59585 : List Nat := [2,4,8,2,32,2,128,172,0,140,137,136,161,136,137,170,1,138,141,137,1,169,3,2,41,2,3,137,1,137,172,32,172,32,1,1]

theorem envBound59585 : H12AffineFastState.Bounded env59585 := by
  intro p hp
  have h : env59585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59584_59585 : H12AffineEnvironment.transform 9 140 env59584 = env59585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59584 == env59585) = true)

theorem identity59585 : scanCanonicalize (H12AffineFastState.compose env59585 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound59585 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59586 : List Nat := [2,4,8,2,32,2,43,7,0,39,34,35,10,35,34,1,1,33,38,34,1,2,3,2,41,2,3,34,1,34,7,32,7,32,1,1]

theorem envBound59586 : H12AffineFastState.Bounded env59586 := by
  intro p hp
  have h : env59586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59585_59586 : H12AffineEnvironment.transform 6 43 env59585 = env59586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env59585 == env59586) = true)

theorem identity59586 : scanCanonicalize (H12AffineFastState.compose env59586 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59586 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env59587 : List Nat := [2,4,1,2,32,2,34,7,0,39,34,35,3,35,34,1,1,33,38,34,1,2,3,2,32,2,3,34,1,34,7,32,7,32,1,1]

theorem envBound59587 : H12AffineFastState.Bounded env59587 := by
  intro p hp
  have h : env59587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59586_59587 : H12AffineEnvironment.transform 2 1 env59586 = env59587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59586 == env59587) = true)

theorem identity59587 : scanCanonicalize (H12AffineFastState.compose env59587 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59588 : List Nat := [2,4,1,2,2,2,0,7,0,5,0,1,3,1,0,1,1,3,4,0,1,2,3,2,2,2,3,0,1,0,7,2,7,2,1,1]

theorem envBound59588 : H12AffineFastState.Bounded env59588 := by
  intro p hp
  have h : env59588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59587_59588 : H12AffineEnvironment.transform 4 2 env59587 = env59588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59587 == env59588) = true)

theorem identity59588 : scanCanonicalize (H12AffineFastState.compose env59588 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59589 : List Nat := [0,4,1,0,0,0,0,5,0,5,0,1,1,1,0,1,1,1,4,0,1,0,1,0,0,0,1,0,1,0,5,0,5,0,1,1]

theorem envBound59589 : H12AffineFastState.Bounded env59589 := by
  intro p hp
  have h : env59589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59588_59589 : H12AffineEnvironment.transform 0 0 env59588 = env59589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59588 == env59589) = true)

def env59590 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1289,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59590 : H12AffineFastState.Bounded env59590 := by
  intro p hp
  have h : env59590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59566_59590 : H12AffineEnvironment.transform 8 1 env59566 = env59590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59566 == env59590) = true)

theorem identity59590 : scanCanonicalize (H12AffineFastState.compose env59590 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 76078) := by decide +kernel

theorem selectedBound59590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59591 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,76078,1417,9664,3158,1289,9617,340058,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59591 : H12AffineFastState.Bounded env59591 := by
  intro p hp
  have h : env59591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59590_59591 : H12AffineEnvironment.transform 20 76078 env59590 = env59591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 76078 env59590 == env59591) = true)

def env59592 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,68782,1417,64,3158,1289,17,333274,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound59592 : H12AffineFastState.Bounded env59592 := by
  intro p hp
  have h : env59592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59591_59592 : H12AffineEnvironment.transform 12 1408 env59591 = env59592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59591 == env59592) = true)

theorem identity59592 : scanCanonicalize (H12AffineFastState.compose env59592 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound59592 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59593 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1408,1029,2129,65536,65799,262144,1025,2129,68782,1417,64,3158,1289,17,328079,1028,65879,66898,65542,68094,256,65674,65799,1]

theorem envBound59593 : H12AffineFastState.Bounded env59593 := by
  intro p hp
  have h : env59593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59592_59593 : H12AffineEnvironment.transform 11 1109 env59592 = env59593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env59592 == env59593) = true)

theorem identity59593 : scanCanonicalize (H12AffineFastState.compose env59593 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound59593 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59594 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1408,1029,2129,65536,65799,3260,1025,2129,68782,1417,64,3158,1289,17,68915,1028,65879,66898,65542,68094,256,65674,65799,1]

theorem envBound59594 : H12AffineFastState.Bounded env59594 := by
  intro p hp
  have h : env59594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59593_59594 : H12AffineEnvironment.transform 17 3260 env59593 = env59594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env59593 == env59594) = true)

theorem identity59594 : scanCanonicalize (H12AffineFastState.compose env59594 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59594 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59595 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1244,1109,1408,1029,1165,65536,65799,96,1025,1165,65650,1417,64,138,1289,17,66031,1028,65879,66898,65542,66850,256,65674,65799,1]

theorem envBound59595 : H12AffineFastState.Bounded env59595 := by
  intro p hp
  have h : env59595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59594_59595 : H12AffineEnvironment.transform 10 1244 env59594 = env59595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59594 == env59595) = true)

theorem identity59595 : scanCanonicalize (H12AffineFastState.compose env59595 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59595 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59596 : List Nat := [2,4,8,16,32,64,128,256,1,408,324,461,24,413,277,65536,65799,96,409,277,65650,17,64,138,145,17,66031,412,65879,65738,65542,65722,256,65674,65799,1]

theorem envBound59596 : H12AffineFastState.Bounded env59596 := by
  intro p hp
  have h : env59596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59595_59596 : H12AffineEnvironment.transform 9 408 env59595 = env59596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59595 == env59596) = true)

theorem identity59596 : scanCanonicalize (H12AffineFastState.compose env59596 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59596 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59597 : List Nat := [2,4,8,16,17,64,128,256,1,408,324,461,24,413,277,65536,65799,81,409,277,65603,17,64,138,145,17,66014,412,65879,65738,65542,65675,256,65674,65799,1]

theorem envBound59597 : H12AffineFastState.Bounded env59597 := by
  intro p hp
  have h : env59597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59596_59597 : H12AffineEnvironment.transform 4 17 env59596 = env59597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59596 == env59597) = true)

theorem identity59597 : scanCanonicalize (H12AffineFastState.compose env59597 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59597 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59598 : List Nat := [2,4,8,16,17,64,128,256,1,408,324,461,24,413,277,154,413,81,409,277,217,17,64,138,145,17,324,412,461,80,156,17,256,16,413,1]

theorem envBound59598 : H12AffineFastState.Bounded env59598 := by
  intro p hp
  have h : env59598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59597_59598 : H12AffineEnvironment.transform 15 154 env59597 = env59598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59597 == env59598) = true)

theorem identity59598 : scanCanonicalize (H12AffineFastState.compose env59598 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59598 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59599 : List Nat := [2,4,8,16,17,64,128,214,1,78,146,27,24,75,195,154,75,81,79,195,217,17,64,138,145,17,146,74,27,80,156,17,214,16,75,1]

theorem envBound59599 : H12AffineFastState.Bounded env59599 := by
  intro p hp
  have h : env59599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59598_59599 : H12AffineEnvironment.transform 7 214 env59598 = env59599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59598 == env59599) = true)

theorem identity59599 : scanCanonicalize (H12AffineFastState.compose env59599 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59599 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59600 : List Nat := [2,4,8,16,17,64,89,15,1,78,75,27,24,75,26,67,75,81,79,26,0,17,64,83,72,17,75,74,27,80,69,17,15,16,75,1]

theorem envBound59600 : H12AffineFastState.Bounded env59600 := by
  intro p hp
  have h : env59600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59599_59600 : H12AffineEnvironment.transform 6 89 env59599 = env59600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59599 == env59600) = true)

theorem identity59600 : scanCanonicalize (H12AffineFastState.compose env59600 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59601 : List Nat := [2,4,8,16,17,17,8,15,1,31,26,27,24,26,26,18,26,0,30,26,0,17,17,2,25,17,26,27,27,1,20,17,15,16,26,1]

theorem envBound59601 : H12AffineFastState.Bounded env59601 := by
  intro p hp
  have h : env59601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59600_59601 : H12AffineEnvironment.transform 5 17 env59600 = env59601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59600 == env59601) = true)

def env59602 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,68783,1417,65,3158,1289,16,333275,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound59602 : H12AffineFastState.Bounded env59602 := by
  intro p hp
  have h : env59602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59591_59602 : H12AffineEnvironment.transform 12 1409 env59591 = env59602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59591 == env59602) = true)

theorem identity59602 : scanCanonicalize (H12AffineFastState.compose env59602 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound59602 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59603 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5458,1,262144,1025,2129,6653,1417,65,3158,1289,16,262281,4177,81,4096,5460,7340,256,5592,1,0]

theorem envBound59603 : H12AffineFastState.Bounded env59603 := by
  intro p hp
  have h : env59603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59602_59603 : H12AffineEnvironment.transform 15 5458 env59602 = env59603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env59602 == env59603) = true)

theorem identity59603 : scanCanonicalize (H12AffineFastState.compose env59603 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59603 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59604 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,5458,1,262144,1025,1449,5125,1417,65,430,1289,16,262281,4177,81,4096,5460,4436,256,5592,1,0]

theorem envBound59604 : H12AffineFastState.Bounded env59604 := by
  intro p hp
  have h : env59604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59603_59604 : H12AffineEnvironment.transform 10 1528 env59603 = env59604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59603 == env59604) = true)

theorem identity59604 : scanCanonicalize (H12AffineFastState.compose env59604 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59604 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59605 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,5458,1,5324,1025,1449,5125,1417,65,430,1289,16,5189,4177,81,4096,5460,4436,256,5592,1,0]

theorem envBound59605 : H12AffineFastState.Bounded env59605 := by
  intro p hp
  have h : env59605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59604_59605 : H12AffineEnvironment.transform 17 5324 env59604 = env59605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59604 == env59605) = true)

theorem identity59605 : scanCanonicalize (H12AffineFastState.compose env59605 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound59605 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59606 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,372,1409,292,1449,1062,1,1464,1025,1449,1393,1417,65,430,1289,16,1329,293,81,372,1056,32,256,1196,1,0]

theorem envBound59606 : H12AffineFastState.Bounded env59606 := by
  intro p hp
  have h : env59606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59605_59606 : H12AffineEnvironment.transform 11 372 env59605 = env59606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env59605 == env59606) = true)

theorem identity59606 : scanCanonicalize (H12AffineFastState.compose env59606 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59606 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59607 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,137,1148,217,1108,1062,1,1093,1025,1108,1164,1140,65,83,1268,16,1228,216,81,137,1056,32,253,1196,1,0]

theorem envBound59607 : H12AffineFastState.Bounded env59607 := by
  intro p hp
  have h : env59607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59606_59607 : H12AffineEnvironment.transform 7 253 env59606 = env59607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59606 == env59607) = true)

theorem identity59607 : scanCanonicalize (H12AffineFastState.compose env59607 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59607 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59608 : List Nat := [2,4,8,16,32,64,128,253,1,140,137,137,240,217,216,170,1,201,141,216,0,248,65,83,120,16,64,216,81,137,172,32,253,32,1,0]

theorem envBound59608 : H12AffineFastState.Bounded env59608 := by
  intro p hp
  have h : env59608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59607_59608 : H12AffineEnvironment.transform 9 140 env59607 = env59608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59607 == env59608) = true)

theorem identity59608 : scanCanonicalize (H12AffineFastState.compose env59608 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound59608 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59609 : List Nat := [2,4,8,16,32,49,128,140,1,140,137,137,129,168,169,170,1,184,141,169,0,137,48,34,9,16,49,169,32,137,172,32,140,32,1,0]

theorem envBound59609 : H12AffineFastState.Bounded env59609 := by
  intro p hp
  have h : env59609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59608_59609 : H12AffineEnvironment.transform 5 49 env59608 = env59609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env59608 == env59609) = true)

theorem identity59609 : scanCanonicalize (H12AffineFastState.compose env59609 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound59609 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59610 : List Nat := [2,4,8,16,25,8,128,140,1,140,137,137,129,145,144,147,1,129,141,144,0,137,9,27,9,16,8,144,25,137,149,25,140,25,1,0]

theorem envBound59610 : H12AffineFastState.Bounded env59610 := by
  intro p hp
  have h : env59610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59609_59610 : H12AffineEnvironment.transform 4 25 env59609 = env59610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env59609 == env59610) = true)

theorem identity59610 : scanCanonicalize (H12AffineFastState.compose env59610 (packedSelected [1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound59610 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59611 : List Nat := [2,4,8,16,25,8,19,31,1,31,26,26,18,2,3,0,1,18,30,3,0,26,9,27,9,16,8,3,25,26,6,25,31,25,1,0]

theorem envBound59611 : H12AffineFastState.Bounded env59611 := by
  intro p hp
  have h : env59611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59610_59611 : H12AffineEnvironment.transform 6 19 env59610 = env59611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env59610 == env59611) = true)

theorem identity59611 : scanCanonicalize (H12AffineFastState.compose env59611 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59611 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1