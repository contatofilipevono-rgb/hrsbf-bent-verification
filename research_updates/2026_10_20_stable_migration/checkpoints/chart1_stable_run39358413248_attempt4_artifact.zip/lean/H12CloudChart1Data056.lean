import H12CloudChart1Data055

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env14070 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,6248,2129,81,6242,2113,2129,52,80,4160,32,6144,2,6248,65,2128,2113,4096,4112,21,6193,116,6193,2048,513]

theorem envBound14070 : H12AffineFastState.Bounded env14070 := by
  intro p hp
  have h : env14070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14069_14070 : H12AffineEnvironment.transform 12 6248 env14069 = env14070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env14069 == env14070) = true)

theorem identity14070 : scanCanonicalize (H12AffineFastState.compose env14070 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14070 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env14071 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,4096,4201,80,81,4195,64,80,52,80,4160,32,4097,2,4201,65,81,64,4096,4112,21,4144,116,4144,1,513]

theorem envBound14071 : H12AffineFastState.Bounded env14071 := by
  intro p hp
  have h : env14071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14070_14071 : H12AffineEnvironment.transform 10 1 env14070 = env14071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14070 == env14071) = true)

theorem identity14071 : scanCanonicalize (H12AffineFastState.compose env14071 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound14071 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env14072 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,16,121,80,81,115,64,80,52,80,80,32,17,2,121,65,81,64,16,0,21,32,116,32,1,513]

theorem envBound14072 : H12AffineFastState.Bounded env14072 := by
  intro p hp
  have h : env14072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14071_14072 : H12AffineEnvironment.transform 11 16 env14071 = env14072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14071 == env14072) = true)

theorem identity14072 : scanCanonicalize (H12AffineFastState.compose env14072 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14073 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,0,1,35,16,0,52,0,0,32,17,2,41,17,1,16,16,0,21,32,36,32,1,513]

theorem envBound14073 : H12AffineFastState.Bounded env14073 := by
  intro p hp
  have h : env14073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14072_14073 : H12AffineEnvironment.transform 5 16 env14072 = env14073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14072 == env14073) = true)

theorem identity14073 : scanCanonicalize (H12AffineFastState.compose env14073 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14074 : List Nat := [2,4,8,16,32,16,8,37,32,53,1,16,41,0,1,35,16,0,52,0,0,32,17,2,41,17,1,16,16,0,21,32,36,32,1,33]

theorem envBound14074 : H12AffineFastState.Bounded env14074 := by
  intro p hp
  have h : env14074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14073_14074 : H12AffineEnvironment.transform 8 32 env14073 = env14074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14073 == env14074) = true)

theorem identity14074 : scanCanonicalize (H12AffineFastState.compose env14074 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14075 : List Nat := [2,4,8,16,1,16,8,4,1,20,1,16,8,0,1,2,16,0,21,0,0,1,17,2,8,17,1,16,16,0,21,1,5,1,1,0]

theorem envBound14075 : H12AffineFastState.Bounded env14075 := by
  intro p hp
  have h : env14075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14074_14075 : H12AffineEnvironment.transform 4 1 env14074 = env14075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14074 == env14075) = true)

def env14076 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,33,318565,293982,8193,65,262144,313360,301056,23669,1056,272392,117,21588,46093,513]

theorem envBound14076 : H12AffineFastState.Bounded env14076 := by
  intro p hp
  have h : env14076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14064_14076 : H12AffineEnvironment.transform 6 9 env14064 = env14076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14064 == env14076) = true)

theorem identity14076 : scanCanonicalize (H12AffineFastState.compose env14076 (packedSelected [2,4,6,9,11,14,17,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound14076 : packedSelected [2,4,6,9,11,14,17,20,23] rootPS < 2^1333 := by decide +kernel

def env14077 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,8202,16400,262144,1025,29788,4160,33,272440,293982,8193,65,262144,277581,289885,23669,1056,272392,117,21588,16464,513]

theorem envBound14077 : H12AffineFastState.Bounded env14077 := by
  intro p hp
  have h : env14077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14076_14077 : H12AffineEnvironment.transform 14 29789 env14076 = env14077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env14076 == env14077) = true)

theorem identity14077 : scanCanonicalize (H12AffineFastState.compose env14077 (packedSelected [0,14,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14077 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env14078 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,29709,8202,16400,262144,1025,29708,4112,33,272440,293902,8193,17,262144,277533,289805,23589,1056,272392,37,21508,16384,513]

theorem envBound14078 : H12AffineFastState.Bounded env14078 := by
  intro p hp
  have h : env14078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14077_14078 : H12AffineEnvironment.transform 5 16 env14077 = env14078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14077 == env14078) = true)

theorem identity14078 : scanCanonicalize (H12AffineFastState.compose env14078 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14078 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14079 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21541,34,16400,262144,1025,21540,4112,33,264208,285734,41,17,262144,269365,281637,23589,1056,264224,37,21508,16384,513]

theorem envBound14079 : H12AffineFastState.Bounded env14079 := by
  intro p hp
  have h : env14079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14078_14079 : H12AffineEnvironment.transform 12 40 env14078 = env14079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14078 == env14079) = true)

theorem identity14079 : scanCanonicalize (H12AffineFastState.compose env14079 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(17+1) ^^^ 2560) := by decide +kernel

theorem selectedBound14079 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env14080 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21541,34,16400,2560,1025,21540,4112,33,528,22054,41,17,2560,5685,17957,23589,1056,544,37,21508,16384,513]

theorem envBound14080 : H12AffineFastState.Bounded env14080 := by
  intro p hp
  have h : env14080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14079_14080 : H12AffineEnvironment.transform 17 2560 env14079 = env14080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2560 env14079 == env14080) = true)

theorem identity14080 : scanCanonicalize (H12AffineFastState.compose env14080 (packedSelected [0,1,2,4,5,6,7,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 1061) := by decide +kernel

theorem selectedBound14080 : packedSelected [0,1,2,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env14081 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,1061,4096,34,1077,2560,1025,4097,4112,33,528,4611,41,17,2560,5685,512,6144,1056,544,37,4129,1061,513]

theorem envBound14081 : H12AffineFastState.Bounded env14081 := by
  intro p hp
  have h : env14081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14080_14081 : H12AffineEnvironment.transform 13 1061 env14080 = env14081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1061 env14080 == env14081) = true)

theorem identity14081 : scanCanonicalize (H12AffineFastState.compose env14081 (packedSelected [0,2,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14081 : packedSelected [0,2,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env14082 : List Nat := [2,4,8,16,32,16,9,36,0,1024,2048,4096,40,1061,4096,34,1077,2048,1025,4097,4112,33,16,4099,41,17,2048,5173,0,6144,1056,32,37,4129,1061,1]

theorem envBound14082 : H12AffineFastState.Bounded env14082 := by
  intro p hp
  have h : env14082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14081_14082 : H12AffineEnvironment.transform 8 0 env14081 = env14082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14081 == env14082) = true)

def env14083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4161,169,318700,351521,8328,65,262517,313837,301564,23805,1500,272393,257,21792,46212,74250]

theorem envBound14083 : H12AffineFastState.Bounded env14083 := by
  intro p hp
  have h : env14083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14036_14083 : H12AffineEnvironment.transform 16 16401 env14036 = env14083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14036 == env14083) = true)

theorem identity14083 : scanCanonicalize (H12AffineFastState.compose env14083 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound14083 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,4161,169,62660,95497,8328,65,10589,57797,45524,23805,1500,33,257,21792,46212,74250]

theorem envBound14084 : H12AffineFastState.Bounded env14084 := by
  intro p hp
  have h : env14084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14083_14084 : H12AffineEnvironment.transform 17 10280 env14083 = env14084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14083 == env14084) = true)

theorem identity14084 : scanCanonicalize (H12AffineFastState.compose env14084 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14084 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,4161,169,62660,21762,8328,65,10589,57797,45524,23805,1500,33,257,21792,46212,513]

theorem envBound14085 : H12AffineFastState.Bounded env14085 := by
  intro p hp
  have h : env14085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14084_14085 : H12AffineEnvironment.transform 15 8203 env14084 = env14085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14084 == env14085) = true)

theorem identity14085 : scanCanonicalize (H12AffineFastState.compose env14085 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14085 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16401,10280,1025,29908,4161,169,17,21762,8328,65,10589,5392,17665,23805,1500,33,257,21792,16465,513]

theorem envBound14086 : H12AffineFastState.Bounded env14086 := by
  intro p hp
  have h : env14086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14085_14086 : H12AffineEnvironment.transform 14 29909 env14085 = env14086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14085 == env14086) = true)

theorem identity14086 : scanCanonicalize (H12AffineFastState.compose env14086 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound14086 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env14087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,8203,13509,10280,1025,0,4161,169,17,8662,8328,65,10589,5392,12757,10281,1500,33,257,8692,13445,513]

theorem envBound14087 : H12AffineFastState.Bounded env14087 := by
  intro p hp
  have h : env14087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14086_14087 : H12AffineEnvironment.transform 13 13524 env14086 = env14087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env14086 == env14087) = true)

theorem identity14087 : scanCanonicalize (H12AffineFastState.compose env14087 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14087 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env14088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,479,5393,2556,1025,0,4161,169,17,2,348,65,2185,5392,4097,2557,1500,33,257,32,5457,513]

theorem envBound14088 : H12AffineFastState.Bounded env14088 := by
  intro p hp
  have h : env14088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14087_14088 : H12AffineEnvironment.transform 12 468 env14087 = env14088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14087 == env14088) = true)

theorem identity14088 : scanCanonicalize (H12AffineFastState.compose env14088 (packedSelected [5,8,11,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound14088 : packedSelected [5,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,665,4096,468,5376,1,479,5393,869,1025,0,4161,169,17,2,348,65,528,5392,4097,868,1500,33,257,32,5457,513]

theorem envBound14089 : H12AffineFastState.Bounded env14089 := by
  intro p hp
  have h : env14089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14088_14089 : H12AffineEnvironment.transform 10 665 env14088 = env14089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env14088 == env14089) = true)

theorem identity14089 : scanCanonicalize (H12AffineFastState.compose env14089 (packedSelected [0,1,3,5,7,8,11,12,23] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound14089 : packedSelected [0,1,3,5,7,8,11,12,23] rootPS < 2^1333 := by decide +kernel

def env14090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,665,869,468,1637,1,479,1652,869,1025,0,804,169,17,2,348,65,528,1653,868,868,1500,33,257,32,1588,513]

theorem envBound14090 : H12AffineFastState.Bounded env14090 := by
  intro p hp
  have h : env14090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14089_14090 : H12AffineEnvironment.transform 11 869 env14089 = env14090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env14089 == env14090) = true)

theorem identity14090 : scanCanonicalize (H12AffineFastState.compose env14090 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14090 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env14091 : List Nat := [2,4,8,16,32,64,88,256,512,1024,577,869,268,1637,1,263,1652,869,1025,0,804,113,17,2,348,65,528,1653,868,868,1284,33,257,32,1588,513]

theorem envBound14091 : H12AffineFastState.Bounded env14091 := by
  intro p hp
  have h : env14091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14090_14091 : H12AffineEnvironment.transform 6 88 env14090 = env14091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14090 == env14091) = true)

theorem identity14091 : scanCanonicalize (H12AffineFastState.compose env14091 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound14091 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14092 : List Nat := [2,4,8,16,32,64,88,256,512,36,577,869,268,577,1,263,592,869,37,0,804,113,17,2,348,65,528,593,868,868,288,33,257,32,528,513]

theorem envBound14092 : H12AffineFastState.Bounded env14092 := by
  intro p hp
  have h : env14092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14091_14092 : H12AffineEnvironment.transform 9 36 env14091 = env14092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env14091 == env14092) = true)

theorem identity14092 : scanCanonicalize (H12AffineFastState.compose env14092 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound14092 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env14093 : List Nat := [2,4,8,16,32,64,88,256,292,36,357,65,268,357,1,263,372,65,37,0,0,113,17,2,348,65,308,373,64,64,288,33,257,32,308,293]

theorem envBound14093 : H12AffineFastState.Bounded env14093 := by
  intro p hp
  have h : env14093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14092_14093 : H12AffineEnvironment.transform 8 292 env14092 = env14093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env14092 == env14093) = true)

def env14094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,147641,318700,466224,8328,65,409957,313837,449005,138476,148941,419865,257,21792,46212,221723]

theorem envBound14094 : H12AffineFastState.Bounded env14094 := by
  intro p hp
  have h : env14094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14035_14094 : H12AffineEnvironment.transform 21 147641 env14035 = env14094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147641 env14035 == env14094) = true)

def env14095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,169,318700,351520,8328,65,262517,313837,301565,23804,1501,272393,257,21792,46212,74251]

theorem envBound14095 : H12AffineFastState.Bounded env14095 := by
  intro p hp
  have h : env14095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14094_14095 : H12AffineEnvironment.transform 16 16400 env14094 = env14095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14094 == env14095) = true)

theorem identity14095 : scanCanonicalize (H12AffineFastState.compose env14095 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound14095 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,56573,1025,32769,4160,169,17,98781,8328,65,56712,5392,17664,23804,1501,62708,257,21792,46212,74251]

theorem envBound14096 : H12AffineFastState.Bounded env14096 := by
  intro p hp
  have h : env14096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14095_14096 : H12AffineEnvironment.transform 17 56573 env14095 = env14096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env14095 == env14096) = true)

theorem identity14096 : scanCanonicalize (H12AffineFastState.compose env14096 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14096 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env14097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,56573,1025,32769,4160,169,17,41431,8328,65,56712,5392,17664,23804,1501,62708,257,21792,46212,513]

theorem envBound14097 : H12AffineFastState.Bounded env14097 := by
  intro p hp
  have h : env14097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14096_14097 : H12AffineEnvironment.transform 15 8202 env14096 = env14097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14096 == env14097) = true)

theorem identity14097 : scanCanonicalize (H12AffineFastState.compose env14097 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound14097 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env14098 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,16400,56356,1025,32769,4160,112,17,41230,8273,65,56657,5392,17664,23589,1284,62509,257,21792,46173,513]

theorem envBound14098 : H12AffineFastState.Bounded env14098 := by
  intro p hp
  have h : env14098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14097_14098 : H12AffineEnvironment.transform 6 89 env14097 = env14098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env14097 == env14098) = true)

theorem identity14098 : scanCanonicalize (H12AffineFastState.compose env14098 (packedSelected [2,6,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound14098 : packedSelected [2,6,17,18,23] rootPS < 2^1333 := by decide +kernel

def env14099 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29708,8202,16400,10280,1025,29709,4160,112,17,21762,8273,65,10589,5392,17664,23589,1284,33,257,21792,16465,513]

theorem envBound14099 : H12AffineFastState.Bounded env14099 := by
  intro p hp
  have h : env14099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14098_14099 : H12AffineEnvironment.transform 14 29708 env14098 = env14099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env14098 == env14099) = true)

theorem identity14099 : scanCanonicalize (H12AffineFastState.compose env14099 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14099 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env14100 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13324,0,8202,13340,10280,1025,1,4160,112,17,8462,8273,65,10589,5392,12556,10281,1284,33,257,8492,13405,513]

theorem envBound14100 : H12AffineFastState.Bounded env14100 := by
  intro p hp
  have h : env14100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14099_14100 : H12AffineEnvironment.transform 13 13324 env14099 = env14100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14099 == env14100) = true)

theorem identity14100 : scanCanonicalize (H12AffineFastState.compose env14100 (packedSelected [0,5,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound14100 : packedSelected [0,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env14101 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2577,8192,11805,0,8202,11789,10280,1025,1,2641,112,17,8462,8273,65,10589,3841,11037,10281,1284,33,257,8492,11852,513]

theorem envBound14101 : H12AffineFastState.Bounded env14101 := by
  intro p hp
  have h : env14101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14100_14101 : H12AffineEnvironment.transform 11 2577 env14100 = env14101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env14100 == env14101) = true)

theorem identity14101 : scanCanonicalize (H12AffineFastState.compose env14101 (packedSelected [3,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound14101 : packedSelected [3,8,12,14] rootPS < 2^1333 := by decide +kernel

def env14102 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2577,2105,1572,0,2099,1588,17,1025,1,2641,112,17,2359,2152,65,356,3841,804,16,1284,33,257,2325,1653,513]

theorem envBound14102 : H12AffineFastState.Bounded env14102 := by
  intro p hp
  have h : env14102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14101_14102 : H12AffineEnvironment.transform 12 2105 env14101 = env14102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env14101 == env14102) = true)

theorem identity14102 : scanCanonicalize (H12AffineFastState.compose env14102 (packedSelected [5,6,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound14102 : packedSelected [5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env14103 : List Nat := [2,4,8,16,32,64,89,256,512,1024,325,852,380,1572,0,374,1588,17,1025,1,788,112,17,114,301,65,356,1604,804,16,1284,33,257,80,1653,513]

theorem envBound14103 : H12AffineFastState.Bounded env14103 := by
  intro p hp
  have h : env14103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14102_14103 : H12AffineEnvironment.transform 10 325 env14102 = env14103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env14102 == env14103) = true)

theorem identity14103 : scanCanonicalize (H12AffineFastState.compose env14103 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14103 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env14104 : List Nat := [2,4,8,16,32,16,9,256,512,1024,277,772,300,1572,0,294,1588,17,1025,1,788,32,17,34,301,17,308,1556,804,16,1284,33,257,0,1573,513]

theorem envBound14104 : H12AffineFastState.Bounded env14104 := by
  intro p hp
  have h : env14104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14103_14104 : H12AffineEnvironment.transform 5 16 env14103 = env14104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14103 == env14104) = true)

def env14105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4161,168,318700,351521,8328,65,262516,313837,301564,23805,1500,272392,257,21792,46212,74250]

theorem envBound14105 : H12AffineFastState.Bounded env14105 := by
  intro p hp
  have h : env14105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14094_14105 : H12AffineEnvironment.transform 16 16401 env14094 = env14105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14094 == env14105) = true)

theorem identity14105 : scanCanonicalize (H12AffineFastState.compose env14105 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14105 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16401,262144,1025,29908,4161,168,272441,351521,8328,65,262516,277816,290089,23805,1500,272392,257,21792,16465,74250]

theorem envBound14106 : H12AffineFastState.Bounded env14106 := by
  intro p hp
  have h : env14106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14105_14106 : H12AffineEnvironment.transform 14 29909 env14105 = env14106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14105 == env14106) = true)

def env14107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16401,32160,1025,29908,4161,168,21913,73857,8328,65,31956,16536,4233,23805,1500,21928,257,21792,16465,74250]

theorem envBound14107 : H12AffineFastState.Bounded env14107 := by
  intro p hp
  have h : env14107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14106_14107 : H12AffineEnvironment.transform 17 32160 env14106 = env14107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env14106 == env14107) = true)

theorem identity14107 : scanCanonicalize (H12AffineFastState.compose env14107 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound14107 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30083,16401,32160,1025,29908,4161,168,21913,21762,8328,65,31956,16536,4233,23805,1500,21928,257,21792,16465,22409]

theorem envBound14108 : H12AffineFastState.Bounded env14108 := by
  intro p hp
  have h : env14108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14107_14108 : H12AffineEnvironment.transform 15 30083 env14107 = env14108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env14107 == env14108) = true)

theorem identity14108 : scanCanonicalize (H12AffineFastState.compose env14108 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound14108 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,5529,10280,1025,8540,4161,168,17,138,8328,65,10588,5392,4233,2421,1500,32,257,168,5593,513]

theorem envBound14109 : H12AffineFastState.Bounded env14109 := by
  intro p hp
  have h : env14109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14108_14109 : H12AffineEnvironment.transform 13 5512 env14108 = env14109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env14108 == env14109) = true)

theorem identity14109 : scanCanonicalize (H12AffineFastState.compose env14109 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14109 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10280,1025,8540,4161,32,17,2,8192,65,10588,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound14110 : H12AffineFastState.Bounded env14110 := by
  intro p hp
  have h : env14110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14109_14110 : H12AffineEnvironment.transform 6 8 env14109 = env14110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14109 == env14110) = true)

theorem identity14110 : scanCanonicalize (H12AffineFastState.compose env14110 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound14110 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,341,3,5393,2080,1025,340,4161,32,17,2,8,65,2388,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound14111 : H12AffineFastState.Bounded env14111 := by
  intro p hp
  have h : env14111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14110_14111 : H12AffineEnvironment.transform 12 8 env14110 = env14111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env14110 == env14111) = true)

theorem identity14111 : scanCanonicalize (H12AffineFastState.compose env14111 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound14111 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env14112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1109,8,341,341,3,324,2080,1025,340,1044,32,17,2,8,65,2388,325,1108,2421,1364,32,257,32,260,513]

theorem envBound14112 : H12AffineFastState.Bounded env14112 := by
  intro p hp
  have h : env14112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14111_14112 : H12AffineEnvironment.transform 11 1109 env14111 = env14112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env14111 == env14112) = true)

theorem identity14112 : scanCanonicalize (H12AffineFastState.compose env14112 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound14112 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,1109,8,341,341,3,324,340,1025,340,1044,32,17,2,8,65,32,325,1108,1,1364,32,257,32,260,513]

theorem envBound14113 : H12AffineFastState.Bounded env14113 := by
  intro p hp
  have h : env14113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14112_14113 : H12AffineEnvironment.transform 10 372 env14112 = env14113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env14112 == env14113) = true)

theorem identity14113 : scanCanonicalize (H12AffineFastState.compose env14113 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound14113 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env14114 : List Nat := [2,4,8,16,32,64,8,256,512,100,372,49,8,341,341,3,324,340,101,340,112,32,17,2,8,65,32,325,48,1,304,32,257,32,260,513]

theorem envBound14114 : H12AffineFastState.Bounded env14114 := by
  intro p hp
  have h : env14114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14113_14114 : H12AffineEnvironment.transform 9 100 env14113 = env14114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env14113 == env14114) = true)

theorem identity14114 : scanCanonicalize (H12AffineFastState.compose env14114 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14114 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env14115 : List Nat := [2,4,8,16,0,64,8,256,512,68,340,17,8,341,341,3,324,340,69,340,80,0,17,2,8,65,0,325,16,1,272,0,257,0,260,513]

theorem envBound14115 : H12AffineFastState.Bounded env14115 := by
  intro p hp
  have h : env14115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14114_14115 : H12AffineEnvironment.transform 4 0 env14114 = env14115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14114 == env14115) = true)

theorem identity14115 : scanCanonicalize (H12AffineFastState.compose env14115 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound14115 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14116 : List Nat := [2,4,8,16,0,64,8,256,277,68,340,17,8,341,341,3,324,340,69,340,80,0,17,2,8,65,0,325,16,1,272,0,257,0,260,276]

theorem envBound14116 : H12AffineFastState.Bounded env14116 := by
  intro p hp
  have h : env14116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14115_14116 : H12AffineEnvironment.transform 8 277 env14115 = env14116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env14115 == env14116) = true)

theorem identity14116 : scanCanonicalize (H12AffineFastState.compose env14116 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound14116 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env14117 : List Nat := [2,4,8,16,0,1,8,256,277,5,277,17,8,276,276,3,261,277,4,277,17,0,17,2,8,0,0,260,16,1,272,0,257,0,260,276]

theorem envBound14117 : H12AffineFastState.Bounded env14117 := by
  intro p hp
  have h : env14117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14116_14117 : H12AffineEnvironment.transform 5 1 env14116 = env14117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env14116 == env14117) = true)

theorem identity14117 : scanCanonicalize (H12AffineFastState.compose env14117 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14117 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14118 : List Nat := [2,4,8,16,0,1,8,21,0,5,0,17,8,1,1,3,16,0,4,0,17,0,17,2,8,0,0,17,16,1,5,0,20,0,17,1]

theorem envBound14118 : H12AffineFastState.Bounded env14118 := by
  intro p hp
  have h : env14118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14117_14118 : H12AffineEnvironment.transform 7 21 env14117 = env14118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14117 == env14118) = true)

theorem identity14118 : scanCanonicalize (H12AffineFastState.compose env14118 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14119 : List Nat := [2,4,2,16,0,1,2,21,0,5,0,17,2,1,1,3,16,0,4,0,17,0,17,2,2,0,0,17,16,1,5,0,20,0,17,1]

theorem envBound14119 : H12AffineFastState.Bounded env14119 := by
  intro p hp
  have h : env14119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14118_14119 : H12AffineEnvironment.transform 2 2 env14118 = env14119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14118 == env14119) = true)

theorem identity14119 : scanCanonicalize (H12AffineFastState.compose env14119 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14119 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14120 : List Nat := [2,4,2,0,0,1,2,5,0,5,0,1,2,1,1,3,0,0,4,0,1,0,1,2,2,0,0,1,0,1,5,0,4,0,1,1]

theorem envBound14120 : H12AffineFastState.Bounded env14120 := by
  intro p hp
  have h : env14120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14119_14120 : H12AffineEnvironment.transform 3 0 env14119 = env14120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14119 == env14120) = true)

def env14121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16401,32161,1025,29908,4161,168,21912,73856,8328,65,31957,16537,4232,23805,1500,21929,257,21792,16465,74250]

theorem envBound14121 : H12AffineFastState.Bounded env14121 := by
  intro p hp
  have h : env14121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14106_14121 : H12AffineEnvironment.transform 17 32161 env14106 = env14121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env14106 == env14121) = true)

theorem identity14121 : scanCanonicalize (H12AffineFastState.compose env14121 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14121 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29963,16401,32161,1025,29908,4161,168,21912,21899,8328,65,31957,16537,4232,23805,1500,21929,257,21792,16465,22273]

theorem envBound14122 : H12AffineFastState.Bounded env14122 := by
  intro p hp
  have h : env14122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14121_14122 : H12AffineEnvironment.transform 15 29963 env14121 = env14122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14121 == env14122) = true)

theorem identity14122 : scanCanonicalize (H12AffineFastState.compose env14122 (packedSelected [1,8,9,10,11,15,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14122 : packedSelected [1,8,9,10,11,15,20,22] rootPS < 2^1333 := by decide +kernel

def env14123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8581,8283,5441,10481,1025,8580,4161,168,200,219,8328,65,10629,5577,4232,2477,1500,249,257,112,5377,593]

theorem envBound14123 : H12AffineFastState.Bounded env14123 := by
  intro p hp
  have h : env14123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14122_14123 : H12AffineEnvironment.transform 13 5456 env14122 = env14123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env14122 == env14123) = true)

theorem identity14123 : scanCanonicalize (H12AffineFastState.compose env14123 (packedSelected [11,12,15,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14123 : packedSelected [11,12,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env14124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5456,1,479,5441,2421,1025,0,4161,168,200,219,268,65,2049,5577,4232,2477,1500,249,257,112,5377,593]

theorem envBound14124 : H12AffineFastState.Bounded env14124 := by
  intro p hp
  have h : env14124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14123_14124 : H12AffineEnvironment.transform 12 388 env14123 = env14124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14123 == env14124) = true)

theorem identity14124 : scanCanonicalize (H12AffineFastState.compose env14124 (packedSelected [0,3,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14124 : packedSelected [0,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env14125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,342,5441,2421,1025,0,4161,33,65,82,268,65,2049,5440,4097,2340,1365,112,257,112,5377,593]

theorem envBound14125 : H12AffineFastState.Bounded env14125 := by
  intro p hp
  have h : env14125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14124_14125 : H12AffineEnvironment.transform 6 9 env14124 = env14125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14124 == env14125) = true)

theorem identity14125 : scanCanonicalize (H12AffineFastState.compose env14125 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2820) := by decide +kernel

theorem selectedBound14125 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2820,269,3668,1,342,3653,2421,1025,0,2885,33,65,82,268,65,2049,3652,2821,2340,1365,112,257,112,3589,593]

theorem envBound14126 : H12AffineFastState.Bounded env14126 := by
  intro p hp
  have h : env14126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14125_14126 : H12AffineEnvironment.transform 11 2820 env14125 = env14126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2820 env14125 == env14126) = true)

theorem identity14126 : scanCanonicalize (H12AffineFastState.compose env14126 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound14126 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env14127 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2820,269,2609,1,342,2592,2421,100,0,2885,33,65,82,268,65,2049,2593,2821,2340,304,112,257,112,2656,593]

theorem envBound14127 : H12AffineFastState.Bounded env14127 := by
  intro p hp
  have h : env14127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14126_14127 : H12AffineEnvironment.transform 9 101 env14126 = env14127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env14126 == env14127) = true)

theorem identity14127 : scanCanonicalize (H12AffineFastState.compose env14127 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14127 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env14128 : List Nat := [2,4,8,16,32,64,9,5,512,101,2048,2561,8,2609,1,83,2592,2160,100,0,2624,33,65,82,9,65,2049,2593,2560,2081,53,112,4,112,2656,593]

theorem envBound14128 : H12AffineFastState.Bounded env14128 := by
  intro p hp
  have h : env14128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14127_14128 : H12AffineEnvironment.transform 7 5 env14127 = env14128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14127 == env14128) = true)

theorem identity14128 : scanCanonicalize (H12AffineFastState.compose env14128 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound14128 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14129 : List Nat := [2,4,8,16,32,64,9,5,64,101,2048,2113,8,2161,1,83,2144,2160,100,0,2048,33,65,82,9,65,2049,2145,2112,2081,53,112,4,112,2080,17]

theorem envBound14129 : H12AffineFastState.Bounded env14129 := by
  intro p hp
  have h : env14129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14128_14129 : H12AffineEnvironment.transform 8 64 env14128 = env14129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env14128 == env14129) = true)

theorem identity14129 : scanCanonicalize (H12AffineFastState.compose env14129 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound14129 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14130 : List Nat := [2,4,8,16,32,64,9,5,64,101,32,97,8,81,1,83,64,80,100,0,32,33,65,82,9,65,33,65,96,1,53,112,4,112,0,17]

theorem envBound14130 : H12AffineFastState.Bounded env14130 := by
  intro p hp
  have h : env14130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14129_14130 : H12AffineEnvironment.transform 10 32 env14129 = env14130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env14129 == env14130) = true)

theorem identity14130 : scanCanonicalize (H12AffineFastState.compose env14130 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound14130 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14131 : List Nat := [2,4,8,16,16,64,9,5,64,85,16,81,8,81,1,83,64,80,84,0,16,17,65,82,9,65,17,65,80,1,5,64,4,64,0,17]

theorem envBound14131 : H12AffineFastState.Bounded env14131 := by
  intro p hp
  have h : env14131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14130_14131 : H12AffineEnvironment.transform 4 16 env14130 = env14131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env14130 == env14131) = true)

theorem identity14131 : scanCanonicalize (H12AffineFastState.compose env14131 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14131 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14132 : List Nat := [2,4,8,1,1,64,9,5,64,68,1,64,8,64,1,66,64,65,69,0,1,0,65,67,9,65,0,65,65,1,5,64,4,64,0,0]

theorem envBound14132 : H12AffineFastState.Bounded env14132 := by
  intro p hp
  have h : env14132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14131_14132 : H12AffineEnvironment.transform 3 1 env14131 = env14132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14131 == env14132) = true)

theorem identity14132 : scanCanonicalize (H12AffineFastState.compose env14132 (packedSelected [9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound14132 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env14133 : List Nat := [2,4,8,1,1,1,9,5,1,5,1,1,8,1,1,3,1,0,4,0,1,0,0,2,9,0,0,0,0,1,5,1,4,1,0,0]

theorem envBound14133 : H12AffineFastState.Bounded env14133 := by
  intro p hp
  have h : env14133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14132_14133 : H12AffineEnvironment.transform 5 1 env14132 = env14133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env14132 == env14133) = true)

def env14134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318700,466225,8328,65,4456925,313837,449004,138476,148940,4466848,257,21792,46212,221722]

theorem envBound14134 : H12AffineFastState.Bounded env14134 := by
  intro p hp
  have h : env14134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14034_14134 : H12AffineEnvironment.transform 20 151633 env14034 = env14134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env14034 == env14134) = true)

theorem identity14134 : scanCanonicalize (H12AffineFastState.compose env14134 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14134 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318565,466225,8193,65,4456788,313700,448869,138341,148805,4466729,257,21792,46093,221722]

theorem envBound14135 : H12AffineFastState.Bounded env14135 := by
  intro p hp
  have h : env14135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14134_14135 : H12AffineEnvironment.transform 6 9 env14134 = env14135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14134 == env14135) = true)

def env14136 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,262144,273,32769,151633,4194304,317813,464929,8193,65,4456788,313700,448869,137589,147541,4466729,257,20528,45341,221722]

theorem envBound14136 : H12AffineFastState.Bounded env14136 := by
  intro p hp
  have h : env14136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14135_14136 : H12AffineEnvironment.transform 9 272 env14135 = env14136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14135 == env14136) = true)

theorem identity14136 : scanCanonicalize (H12AffineFastState.compose env14136 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 235555) := by decide +kernel

theorem selectedBound14136 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env14137 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,235555,273,32769,151633,4194304,213334,32770,8193,65,4430199,217415,82246,137589,147541,4435978,257,20528,45341,221722]

theorem envBound14137 : H12AffineFastState.Bounded env14137 := by
  intro p hp
  have h : env14137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14136_14137 : H12AffineEnvironment.transform 17 235555 env14136 = env14137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 235555 env14136 == env14137) = true)

def env14138 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,235555,273,32769,151633,180320,213334,32770,8193,65,88343,217415,82246,137589,147541,94314,257,20528,45341,221722]

theorem envBound14138 : H12AffineFastState.Bounded env14138 := by
  intro p hp
  have h : env14138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14137_14138 : H12AffineEnvironment.transform 21 180320 env14137 = env14138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180320 env14137 == env14138) = true)

theorem identity14138 : scanCanonicalize (H12AffineFastState.compose env14138 (packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound14138 : packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env14139 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12573,32768,65536,131072,235555,273,32769,139596,176509,208971,32770,8193,65,75786,204890,77915,137589,143688,65911,257,8493,45341,201479]

theorem envBound14139 : H12AffineFastState.Bounded env14139 := by
  intro p hp
  have h : env14139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14138_14139 : H12AffineEnvironment.transform 13 12573 env14138 = env14139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env14138 == env14139) = true)

theorem identity14139 : scanCanonicalize (H12AffineFastState.compose env14139 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound14139 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env14140 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12573,32768,65536,69894,35109,273,32769,77898,106619,8525,32770,8193,65,75786,12636,77915,67699,73806,65911,257,8493,45341,513]

theorem envBound14140 : H12AffineFastState.Bounded env14140 := by
  intro p hp
  have h : env14140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14139_14140 : H12AffineEnvironment.transform 16 69894 env14139 = env14140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env14139 == env14140) = true)

theorem identity14140 : scanCanonicalize (H12AffineFastState.compose env14140 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14140 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14141 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4161,32768,65536,69894,35109,273,32769,69910,98599,17,32770,349,65,67926,4096,69895,67699,65810,65911,257,113,36929,513]

theorem envBound14141 : H12AffineFastState.Bounded env14141 := by
  intro p hp
  have h : env14141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14140_14141 : H12AffineEnvironment.transform 12 348 env14140 = env14141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14140 == env14141) = true)

theorem identity14141 : scanCanonicalize (H12AffineFastState.compose env14141 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound14141 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14142 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4161,32768,33030,36864,35109,273,32769,36880,33,17,32770,349,65,34896,4096,36865,35189,32788,32881,257,113,36929,513]

theorem envBound14142 : H12AffineFastState.Bounded env14142 := by
  intro p hp
  have h : env14142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14141_14142 : H12AffineEnvironment.transform 15 33030 env14141 = env14142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env14141 == env14142) = true)

def env14143 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,235555,273,32769,151633,180321,213334,32770,8193,65,88342,217415,82246,137589,147541,94315,257,20528,45341,221722]

theorem envBound14143 : H12AffineFastState.Bounded env14143 := by
  intro p hp
  have h : env14143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14137_14143 : H12AffineEnvironment.transform 21 180321 env14137 = env14143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180321 env14137 == env14143) = true)

theorem identity14143 : scanCanonicalize (H12AffineFastState.compose env14143 (packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound14143 : packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env14144 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,32768,65536,131072,235555,273,32769,139549,176429,208922,32770,8193,65,75866,204811,77834,137589,143641,65831,257,8572,45341,201558]

theorem envBound14144 : H12AffineFastState.Bounded env14144 := by
  intro p hp
  have h : env14144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14143_14144 : H12AffineEnvironment.transform 13 12620 env14143 = env14144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env14143 == env14144) = true)

theorem identity14144 : scanCanonicalize (H12AffineFastState.compose env14144 (packedSelected [0,1,8,9,18,22,23,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 77915) := by decide +kernel

theorem selectedBound14144 : packedSelected [0,1,8,9,18,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env14145 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,32768,65536,77915,43128,273,32769,69958,98678,65,32770,8193,65,75866,4176,77834,76078,65858,65831,257,8572,45341,8973]

theorem envBound14145 : H12AffineFastState.Bounded env14145 := by
  intro p hp
  have h : env14145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14144_14145 : H12AffineEnvironment.transform 16 77915 env14144 = env14145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 77915 env14144 == env14145) = true)

theorem identity14145 : scanCanonicalize (H12AffineFastState.compose env14145 (packedSelected [0,2,4,6,7,9,12,14,15,16,17,18,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound14145 : packedSelected [0,2,4,6,7,9,12,14,15,16,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env14146 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,81,65536,77915,10281,273,80,69958,65831,65,83,8193,65,75866,4176,77834,76078,65858,65831,257,8572,12620,8973]

theorem envBound14146 : H12AffineFastState.Bounded env14146 := by
  intro p hp
  have h : env14146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14145_14146 : H12AffineEnvironment.transform 14 81 env14145 = env14146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env14145 == env14146) = true)

theorem identity14146 : scanCanonicalize (H12AffineFastState.compose env14146 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14146 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14147 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,81,262,12637,10281,273,80,4160,33,65,83,8193,65,10588,4176,12556,10280,68,33,257,8572,12620,8973]

theorem envBound14147 : H12AffineFastState.Bounded env14147 := by
  intro p hp
  have h : env14147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14146_14147 : H12AffineEnvironment.transform 15 262 env14146 = env14147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14146 == env14147) = true)

theorem identity14147 : scanCanonicalize (H12AffineFastState.compose env14147 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14147 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14148 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,81,262,4097,2421,273,80,4160,33,65,83,349,65,2048,4176,4176,2420,68,33,257,32,4112,593]

theorem envBound14148 : H12AffineFastState.Bounded env14148 := by
  intro p hp
  have h : env14148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14147_14148 : H12AffineEnvironment.transform 12 348 env14147 = env14148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14147 == env14148) = true)

theorem identity14148 : scanCanonicalize (H12AffineFastState.compose env14148 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2421) := by decide +kernel

theorem selectedBound14148 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14149 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2421,348,2405,81,262,2420,2421,273,80,2357,33,65,83,349,65,2048,2341,2341,2420,68,33,257,32,2405,593]

theorem envBound14149 : H12AffineFastState.Bounded env14149 := by
  intro p hp
  have h : env14149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14148_14149 : H12AffineEnvironment.transform 11 2421 env14148 = env14149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2421 env14148 == env14149) = true)

theorem identity14149 : scanCanonicalize (H12AffineFastState.compose env14149 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound14149 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env14150 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,80,348,64,81,262,81,80,273,80,16,33,65,83,349,65,293,0,0,81,68,33,257,32,64,593]

theorem envBound14150 : H12AffineFastState.Bounded env14150 := by
  intro p hp
  have h : env14150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14149_14150 : H12AffineEnvironment.transform 10 293 env14149 = env14150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env14149 == env14150) = true)

theorem identity14150 : scanCanonicalize (H12AffineFastState.compose env14150 (packedSelected [3,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 127) := by decide +kernel

theorem selectedBound14150 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env14151 : List Nat := [2,4,8,16,32,64,9,127,512,111,90,80,35,64,81,121,81,80,110,80,16,33,65,83,34,65,90,0,0,81,68,33,126,32,64,593]

theorem envBound14151 : H12AffineFastState.Bounded env14151 := by
  intro p hp
  have h : env14151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14150_14151 : H12AffineEnvironment.transform 7 127 env14150 = env14151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 127 env14150 == env14151) = true)

theorem identity14151 : scanCanonicalize (H12AffineFastState.compose env14151 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound14151 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env14152 : List Nat := [2,4,8,16,32,59,9,4,512,20,33,43,35,59,42,2,42,43,21,43,16,33,58,40,34,58,33,0,0,42,63,33,5,32,59,554]

theorem envBound14152 : H12AffineFastState.Bounded env14152 := by
  intro p hp
  have h : env14152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14151_14152 : H12AffineEnvironment.transform 5 59 env14151 = env14152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env14151 == env14152) = true)

theorem identity14152 : scanCanonicalize (H12AffineFastState.compose env14152 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14152 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14153 : List Nat := [2,4,8,0,32,43,9,4,512,4,33,43,35,43,42,2,42,43,5,43,0,33,42,40,34,42,33,0,0,42,47,33,5,32,43,554]

theorem envBound14153 : H12AffineFastState.Bounded env14153 := by
  intro p hp
  have h : env14153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14152_14153 : H12AffineEnvironment.transform 3 0 env14152 = env14153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14152 == env14153) = true)

theorem identity14153 : scanCanonicalize (H12AffineFastState.compose env14153 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14153 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14154 : List Nat := [2,4,8,0,1,10,9,4,512,4,0,10,2,10,11,2,11,10,5,10,0,0,11,9,3,11,0,0,0,11,14,0,5,1,10,523]

theorem envBound14154 : H12AffineFastState.Bounded env14154 := by
  intro p hp
  have h : env14154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14153_14154 : H12AffineEnvironment.transform 4 1 env14153 = env14154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14153 == env14154) = true)

theorem identity14154 : scanCanonicalize (H12AffineFastState.compose env14154 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14154 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14155 : List Nat := [2,4,2,0,1,0,3,4,512,4,0,0,2,0,1,2,1,0,5,0,0,0,1,3,3,1,0,0,0,1,4,0,5,1,0,513]

theorem envBound14155 : H12AffineFastState.Bounded env14155 := by
  intro p hp
  have h : env14155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14154_14155 : H12AffineEnvironment.transform 2 2 env14154 = env14155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14154 == env14155) = true)

theorem identity14155 : scanCanonicalize (H12AffineFastState.compose env14155 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound14155 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14156 : List Nat := [2,4,2,0,1,0,3,4,5,4,0,0,2,0,1,2,1,0,5,0,0,0,1,3,3,1,0,0,0,1,4,0,5,1,0,4]

theorem envBound14156 : H12AffineFastState.Bounded env14156 := by
  intro p hp
  have h : env14156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14155_14156 : H12AffineEnvironment.transform 8 5 env14155 = env14156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env14155 == env14156) = true)

theorem identity14156 : scanCanonicalize (H12AffineFastState.compose env14156 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound14156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14157 : List Nat := [2,3,2,0,1,0,3,3,2,3,0,0,2,0,1,2,1,0,2,0,0,0,1,3,3,1,0,0,0,1,3,0,2,1,0,3]

theorem envBound14157 : H12AffineFastState.Bounded env14157 := by
  intro p hp
  have h : env14157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14156_14157 : H12AffineEnvironment.transform 1 3 env14156 = env14157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env14156 == env14157) = true)

theorem identity14157 : scanCanonicalize (H12AffineFastState.compose env14157 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14157 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14158 : List Nat := [1,0,1,0,1,0,0,0,1,0,0,0,1,0,1,1,1,0,1,0,0,0,1,0,0,1,0,0,0,1,0,0,1,1,0,0]

theorem envBound14158 : H12AffineFastState.Bounded env14158 := by
  intro p hp
  have h : env14158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14157_14158 : H12AffineEnvironment.transform 0 1 env14157 = env14158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14157 == env14158) = true)

def env14159 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,32768,65536,131072,262144,272,32769,151633,4194304,317812,464928,8193,65,4456788,313700,448869,137588,147540,4466729,257,20529,45340,221722]

theorem envBound14159 : H12AffineFastState.Bounded env14159 := by
  intro p hp
  have h : env14159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14135_14159 : H12AffineEnvironment.transform 9 273 env14135 = env14159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14135 == env14159) = true)

theorem identity14159 : scanCanonicalize (H12AffineFastState.compose env14159 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 110602) := by decide +kernel

theorem selectedBound14159 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env14160 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,32768,65536,110602,262144,272,32769,122971,4194304,317812,305194,8193,65,4456788,313700,354671,108926,127070,4466729,257,20529,45340,53776]

theorem envBound14160 : H12AffineFastState.Bounded env14160 := by
  intro p hp
  have h : env14160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14159_14160 : H12AffineEnvironment.transform 16 110602 env14159 = env14160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110602 env14159 == env14160) = true)

def env14161 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,65536,110602,262144,272,32769,122891,4194304,317732,305194,8193,17,4456708,313652,354623,108846,126990,4466729,257,20529,45340,53776]

theorem envBound14161 : H12AffineFastState.Bounded env14161 := by
  intro p hp
  have h : env14161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14160_14161 : H12AffineEnvironment.transform 5 16 env14160 = env14161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14160 == env14161) = true)

theorem identity14161 : scanCanonicalize (H12AffineFastState.compose env14161 (packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound14161 : packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env14162 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,65536,110602,262144,272,32769,122891,65830,317732,305194,8193,17,327714,313652,354623,108846,126990,338191,257,20529,45340,53776]

theorem envBound14162 : H12AffineFastState.Bounded env14162 := by
  intro p hp
  have h : env14162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14161_14162 : H12AffineEnvironment.transform 21 65830 env14161 = env14162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env14161 == env14162) = true)

theorem identity14162 : scanCanonicalize (H12AffineFastState.compose env14162 (packedSelected [0,2,5,6,7,17,20,21,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 22836) := by decide +kernel

theorem selectedBound14162 : packedSelected [0,2,5,6,7,17,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env14163 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,65536,110602,22836,272,32769,122891,65830,32784,61726,8193,17,88342,36864,77835,108846,126990,94267,257,20529,45340,53776]

theorem envBound14163 : H12AffineFastState.Bounded env14163 := by
  intro p hp
  have h : env14163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14162_14163 : H12AffineEnvironment.transform 17 22836 env14162 = env14163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22836 env14162 == env14163) = true)

theorem identity14163 : scanCanonicalize (H12AffineFastState.compose env14163 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14163 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env14164 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,262,45324,22836,272,32769,57613,32,32784,61726,8193,17,22544,36864,12557,43048,61704,28989,257,20529,45340,53776]

theorem envBound14164 : H12AffineFastState.Bounded env14164 := by
  intro p hp
  have h : env14164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14163_14164 : H12AffineEnvironment.transform 15 262 env14163 = env14164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14163 == env14164) = true)

theorem identity14164 : scanCanonicalize (H12AffineFastState.compose env14164 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound14164 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14165 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,8461,262,4097,22836,272,8460,16384,32,8477,20499,8193,17,22544,12557,12557,2341,20485,28989,257,20529,4113,29469]

theorem envBound14165 : H12AffineFastState.Bounded env14165 := by
  intro p hp
  have h : env14165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14164_14165 : H12AffineEnvironment.transform 14 8461 env14164 = env14165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env14164 == env14165) = true)

theorem identity14165 : scanCanonicalize (H12AffineFastState.compose env14165 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound14165 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env14166 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2367,8192,16384,8461,262,2366,16395,272,8460,16384,32,8477,18732,8193,17,16687,10290,10290,2341,18746,26626,257,18702,2350,27170]

theorem envBound14166 : H12AffineFastState.Bounded env14166 := by
  intro p hp
  have h : env14166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14165_14166 : H12AffineEnvironment.transform 11 2367 env14165 = env14166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env14165 == env14166) = true)

theorem identity14166 : scanCanonicalize (H12AffineFastState.compose env14166 (packedSelected [0,1,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14166 : packedSelected [0,1,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14167 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2367,269,16384,0,262,2366,16395,272,1,16384,32,16,18732,268,17,16687,2367,2367,2341,18746,18703,257,18702,2350,19247]

theorem envBound14167 : H12AffineFastState.Bounded env14167 := by
  intro p hp
  have h : env14167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14166_14167 : H12AffineEnvironment.transform 12 269 env14166 = env14167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14166 == env14167) = true)

theorem identity14167 : scanCanonicalize (H12AffineFastState.compose env14167 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound14167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14168 : List Nat := [2,4,8,16,32,16,9,53,512,36,2048,2058,56,16384,0,51,2059,16395,37,1,16384,32,16,18457,57,17,16410,2058,2058,2064,18447,18490,52,18491,2075,18970]

theorem envBound14168 : H12AffineFastState.Bounded env14168 := by
  intro p hp
  have h : env14168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14167_14168 : H12AffineEnvironment.transform 7 53 env14167 = env14168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env14167 == env14168) = true)

theorem identity14168 : scanCanonicalize (H12AffineFastState.compose env14168 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 2065) := by decide +kernel

theorem selectedBound14168 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env14169 : List Nat := [2,4,8,16,32,16,9,53,512,36,2048,2058,56,2065,0,51,2059,2074,37,1,2065,32,16,8,57,17,2059,2058,2058,2064,30,43,52,42,2075,523]

theorem envBound14169 : H12AffineFastState.Bounded env14169 := by
  intro p hp
  have h : env14169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14168_14169 : H12AffineEnvironment.transform 13 2065 env14168 = env14169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2065 env14168 == env14169) = true)

theorem identity14169 : scanCanonicalize (H12AffineFastState.compose env14169 (packedSelected [1,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound14169 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env14170 : List Nat := [2,4,8,16,32,16,9,53,512,36,43,33,56,58,0,51,32,49,37,1,58,32,16,8,57,17,32,33,33,59,30,43,52,42,48,523]

theorem envBound14170 : H12AffineFastState.Bounded env14170 := by
  intro p hp
  have h : env14170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14169_14170 : H12AffineEnvironment.transform 10 43 env14169 = env14170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env14169 == env14170) = true)

theorem identity14170 : scanCanonicalize (H12AffineFastState.compose env14170 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14170 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14171 : List Nat := [2,4,8,1,32,1,9,36,512,36,43,33,41,43,0,34,32,32,37,1,43,32,1,8,40,0,32,33,33,42,15,43,37,42,33,523]

theorem envBound14171 : H12AffineFastState.Bounded env14171 := by
  intro p hp
  have h : env14171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14170_14171 : H12AffineEnvironment.transform 3 1 env14170 = env14171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14170 == env14171) = true)

theorem identity14171 : scanCanonicalize (H12AffineFastState.compose env14171 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound14171 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14172 : List Nat := [2,4,8,1,32,1,9,36,14,36,43,33,41,43,0,34,32,32,37,1,43,32,1,8,40,0,32,33,33,42,15,43,37,42,33,5]

theorem envBound14172 : H12AffineFastState.Bounded env14172 := by
  intro p hp
  have h : env14172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14171_14172 : H12AffineEnvironment.transform 8 14 env14171 = env14172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env14171 == env14172) = true)

theorem identity14172 : scanCanonicalize (H12AffineFastState.compose env14172 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14172 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14173 : List Nat := [1,4,8,1,32,1,9,36,13,36,40,33,41,40,0,33,32,32,37,1,40,32,1,8,40,0,32,33,33,41,12,40,37,41,33,5]

theorem envBound14173 : H12AffineFastState.Bounded env14173 := by
  intro p hp
  have h : env14173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14172_14173 : H12AffineEnvironment.transform 0 1 env14172 = env14173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14172 == env14173) = true)

def env14174 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,32768,65536,110602,262144,272,32769,122890,4194304,317733,305194,8193,16,4456709,313653,354622,108847,126991,4466729,257,20529,45340,53776]

theorem envBound14174 : H12AffineFastState.Bounded env14174 := by
  intro p hp
  have h : env14174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14160_14174 : H12AffineEnvironment.transform 5 17 env14160 = env14174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14160 == env14174) = true)

theorem identity14174 : scanCanonicalize (H12AffineFastState.compose env14174 (packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 22836) := by decide +kernel

theorem selectedBound14174 : packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env14175 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,32768,65536,110602,22836,272,32769,122890,4194304,32785,61726,8193,16,4216881,36865,77834,108847,126991,4223261,257,20529,45340,53776]

theorem envBound14175 : H12AffineFastState.Bounded env14175 := by
  intro p hp
  have h : env14175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14174_14175 : H12AffineEnvironment.transform 17 22836 env14174 = env14175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22836 env14174 == env14175) = true)

theorem identity14175 : scanCanonicalize (H12AffineFastState.compose env14175 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,16,20,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound14175 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,16,20,21,26] rootPS < 2^1333 := by decide +kernel

def env14176 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,32768,65536,110602,10280,272,32769,102678,4194304,32785,32770,8193,16,4204845,36865,77834,108847,98579,4194305,257,8493,45340,41740]

theorem envBound14176 : H12AffineFastState.Bounded env14176 := by
  intro p hp
  have h : env14176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14175_14176 : H12AffineEnvironment.transform 13 12572 env14175 = env14176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env14175 == env14176) = true)

theorem identity14176 : scanCanonicalize (H12AffineFastState.compose env14176 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound14176 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14177 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,8461,65536,69895,10280,272,8460,77851,4194304,8476,8463,8193,16,4204845,12556,77834,67618,73758,4194305,257,8493,4113,513]

theorem envBound14177 : H12AffineFastState.Bounded env14177 := by
  intro p hp
  have h : env14177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14176_14177 : H12AffineEnvironment.transform 14 8461 env14176 = env14177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env14176 == env14177) = true)

theorem identity14177 : scanCanonicalize (H12AffineFastState.compose env14177 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14177 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14178 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,0,65536,69895,2341,272,1,69910,4194304,17,2,268,16,4196384,4097,69895,67618,65811,4194305,257,32,4113,513]

theorem envBound14178 : H12AffineFastState.Bounded env14178 := by
  intro p hp
  have h : env14178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14177_14178 : H12AffineEnvironment.transform 12 269 env14177 = env14178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14177 == env14178) = true)

theorem identity14178 : scanCanonicalize (H12AffineFastState.compose env14178 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound14178 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14179 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,0,263,4096,2341,272,1,4113,4194304,17,2,268,16,4196384,4097,4096,2341,20,4194305,257,32,4113,513]

theorem envBound14179 : H12AffineFastState.Bounded env14179 := by
  intro p hp
  have h : env14179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14178_14179 : H12AffineEnvironment.transform 15 263 env14178 = env14179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env14178 == env14179) = true)

theorem identity14179 : scanCanonicalize (H12AffineFastState.compose env14179 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound14179 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14180 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,0,263,4096,2341,272,1,4113,32,17,2,268,16,2048,4097,4096,2341,20,33,257,32,4113,513]

theorem envBound14180 : H12AffineFastState.Bounded env14180 := by
  intro p hp
  have h : env14180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14179_14180 : H12AffineEnvironment.transform 21 32 env14179 = env14180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env14179 == env14180) = true)

theorem identity14180 : scanCanonicalize (H12AffineFastState.compose env14180 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound14180 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14181 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,261,269,276,0,263,261,2341,272,1,276,32,17,2,268,16,2048,260,261,2341,20,33,257,32,276,513]

theorem envBound14181 : H12AffineFastState.Bounded env14181 := by
  intro p hp
  have h : env14181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14180_14181 : H12AffineEnvironment.transform 11 261 env14180 = env14181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env14180 == env14181) = true)

theorem identity14181 : scanCanonicalize (H12AffineFastState.compose env14181 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound14181 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14182 : List Nat := [2,4,8,16,32,17,9,256,512,273,10,261,269,276,0,263,261,303,272,1,276,32,17,2,268,16,10,260,261,303,20,33,257,32,276,513]

theorem envBound14182 : H12AffineFastState.Bounded env14182 := by
  intro p hp
  have h : env14182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14181_14182 : H12AffineEnvironment.transform 10 10 env14181 = env14182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env14181 == env14182) = true)

theorem identity14182 : scanCanonicalize (H12AffineFastState.compose env14182 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound14182 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14183 : List Nat := [2,4,8,16,32,17,9,256,309,273,10,261,269,276,0,263,261,303,272,1,276,32,17,2,268,16,10,260,261,303,20,33,257,32,276,308]

theorem envBound14183 : H12AffineFastState.Bounded env14183 := by
  intro p hp
  have h : env14183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14182_14183 : H12AffineEnvironment.transform 8 309 env14182 = env14183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env14182 == env14183) = true)

theorem identity14183 : scanCanonicalize (H12AffineFastState.compose env14183 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14183 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14184 : List Nat := [2,4,2,16,32,17,3,256,309,273,0,261,263,276,0,263,261,293,272,1,276,32,17,2,262,16,0,260,261,293,20,33,257,32,276,308]

theorem envBound14184 : H12AffineFastState.Bounded env14184 := by
  intro p hp
  have h : env14184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14183_14184 : H12AffineEnvironment.transform 2 2 env14183 = env14184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14183 == env14184) = true)

theorem identity14184 : scanCanonicalize (H12AffineFastState.compose env14184 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound14184 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14185 : List Nat := [2,4,2,16,32,17,3,51,6,34,0,54,52,39,0,52,54,22,35,1,39,32,17,2,53,16,0,55,54,22,20,33,50,32,39,7]

theorem envBound14185 : H12AffineFastState.Bounded env14185 := by
  intro p hp
  have h : env14185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14184_14185 : H12AffineEnvironment.transform 7 51 env14184 = env14185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env14184 == env14185) = true)

theorem identity14185 : scanCanonicalize (H12AffineFastState.compose env14185 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14185 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14186 : List Nat := [2,4,2,16,1,17,3,18,6,3,0,23,21,6,0,21,23,22,2,1,6,1,17,2,20,16,0,22,23,22,20,0,19,1,6,7]

theorem envBound14186 : H12AffineFastState.Bounded env14186 := by
  intro p hp
  have h : env14186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14185_14186 : H12AffineEnvironment.transform 4 1 env14185 = env14186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14185 == env14186) = true)

def env14187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318701,2444640,8328,65,6705549,313837,2394556,138477,2102684,4466848,257,21793,46213,2175562]

theorem envBound14187 : H12AffineFastState.Bounded env14187 := by
  intro p hp
  have h : env14187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14033_14187 : H12AffineEnvironment.transform 22 318701 env14033 = env14187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318701 env14033 == env14187) = true)

def env14188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318701,466224,8328,65,4456925,313837,449004,138477,148940,4466848,257,21793,46213,221722]

theorem envBound14188 : H12AffineFastState.Bounded env14188 := by
  intro p hp
  have h : env14188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14187_14188 : H12AffineEnvironment.transform 20 151632 env14187 = env14188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env14187 == env14188) = true)

theorem identity14188 : scanCanonicalize (H12AffineFastState.compose env14188 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90258) := by decide +kernel

theorem selectedBound14188 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90258,262144,1025,32769,78018,4194304,318701,294306,8328,65,4456925,313837,375166,97407,75102,4466848,257,21793,46213,648]

theorem envBound14189 : H12AffineFastState.Bounded env14189 := by
  intro p hp
  have h : env14189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14188_14189 : H12AffineEnvironment.transform 16 90258 env14188 = env14189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90258 env14188 == env14189) = true)

def env14190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77898,4194304,318565,294186,8192,65,4456789,313701,375166,97407,75102,4466728,257,21793,46093,512]

theorem envBound14190 : H12AffineFastState.Bounded env14190 := by
  intro p hp
  have h : env14190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14189_14190 : H12AffineEnvironment.transform 6 8 env14189 = env14190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14189 == env14190) = true)

theorem identity14190 : scanCanonicalize (H12AffineFastState.compose env14190 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 130314) := by decide +kernel

theorem selectedBound14190 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,130314,1025,32769,77898,4194304,74095,98336,8192,65,4324447,78959,17524,97407,75102,4314402,257,21793,46093,512]

theorem envBound14191 : H12AffineFastState.Bounded env14191 := by
  intro p hp
  have h : env14191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14190_14191 : H12AffineEnvironment.transform 17 130314 env14190 = env14191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130314 env14190 == env14191) = true)

theorem identity14191 : scanCanonicalize (H12AffineFastState.compose env14191 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14191 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5392,34816,1025,32769,17728,4194304,21605,62762,8192,65,4229461,16741,17524,2421,20564,4235304,257,21793,46093,512]

theorem envBound14192 : H12AffineFastState.Bounded env14192 := by
  intro p hp
  have h : env14192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14191_14192 : H12AffineEnvironment.transform 15 29962 env14191 = env14192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14191 == env14192) = true)

theorem identity14192 : scanCanonicalize (H12AffineFastState.compose env14192 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 21761) := by decide +kernel

theorem selectedBound14192 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5392,34816,1025,32769,17728,21761,21605,62762,8192,65,56404,16741,17524,2421,20564,62761,257,21793,46093,512]

theorem envBound14193 : H12AffineFastState.Bounded env14193 := by
  intro p hp
  have h : env14193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14192_14193 : H12AffineEnvironment.transform 21 21761 env14192 = env14193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21761 env14192 == env14193) = true)

theorem identity14193 : scanCanonicalize (H12AffineFastState.compose env14193 (packedSelected [9,14,22] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound14193 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env14194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8201,29962,5392,10249,1025,8200,17728,21761,21605,21795,8192,65,31837,16741,17524,2421,20564,21792,257,21793,5124,512]

theorem envBound14194 : H12AffineFastState.Bounded env14194 := by
  intro p hp
  have h : env14194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14193_14194 : H12AffineEnvironment.transform 14 8201 env14193 = env14194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env14193 == env14194) = true)

theorem identity14194 : scanCanonicalize (H12AffineFastState.compose env14194 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound14194 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env14195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8201,8575,5392,10249,1025,8200,4405,372,16,342,8192,65,10280,5392,4097,2421,1057,341,257,340,5124,512]

theorem envBound14195 : H12AffineFastState.Bounded env14195 := by
  intro p hp
  have h : env14195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14194_14195 : H12AffineEnvironment.transform 13 5237 env14194 = env14195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env14194 == env14195) = true)

theorem identity14195 : scanCanonicalize (H12AffineFastState.compose env14195 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound14195 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5237,113,263,5392,2161,1025,112,4405,372,16,342,120,65,2128,5392,4097,2421,1057,341,257,340,5124,512]

theorem envBound14196 : H12AffineFastState.Bounded env14196 := by
  intro p hp
  have h : env14196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14195_14196 : H12AffineEnvironment.transform 12 120 env14195 = env14196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env14195 == env14196) = true)

theorem identity14196 : scanCanonicalize (H12AffineFastState.compose env14196 (packedSelected [0,1,2,4,8,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound14196 : packedSelected [0,1,2,4,8,11,14] rootPS < 2^1333 := by decide +kernel

def env14197 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,120,5237,113,82,5189,2161,1025,112,4192,33,16,3,120,65,2128,5189,4097,2080,1057,0,84,1,5124,512]

theorem envBound14197 : H12AffineFastState.Bounded env14197 := by
  intro p hp
  have h : env14197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14196_14197 : H12AffineEnvironment.transform 7 85 env14196 = env14197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env14196 == env14197) = true)

theorem identity14197 : scanCanonicalize (H12AffineFastState.compose env14197 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14197 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env14198 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,89,5204,80,82,5189,2128,1025,81,4161,0,16,3,89,65,2128,5189,4097,2049,1024,0,84,1,5124,512]

theorem envBound14198 : H12AffineFastState.Bounded env14198 := by
  intro p hp
  have h : env14198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14197_14198 : H12AffineEnvironment.transform 4 1 env14197 = env14198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14197 == env14198) = true)

theorem identity14198 : scanCanonicalize (H12AffineFastState.compose env14198 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound14198 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14199 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,2138,89,3086,80,82,3103,2128,1025,81,2075,0,16,3,89,65,2128,3103,2139,2049,1024,0,84,1,3166,512]

theorem envBound14199 : H12AffineFastState.Bounded env14199 := by
  intro p hp
  have h : env14199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14198_14199 : H12AffineEnvironment.transform 11 2138 env14198 = env14199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env14198 == env14199) = true)

theorem identity14199 : scanCanonicalize (H12AffineFastState.compose env14199 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound14199 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14200 : List Nat := [2,4,8,16,1,64,8,85,512,20,2048,2138,89,2074,80,82,2059,2128,21,81,2075,0,16,3,89,65,2128,2059,2139,2049,20,0,84,1,2122,512]

theorem envBound14200 : H12AffineFastState.Bounded env14200 := by
  intro p hp
  have h : env14200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14199_14200 : H12AffineEnvironment.transform 9 20 env14199 = env14200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14199 == env14200) = true)

theorem identity14200 : scanCanonicalize (H12AffineFastState.compose env14200 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound14200 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14201 : List Nat := [2,0,8,16,1,64,8,81,512,16,2048,2138,89,2074,80,82,2059,2128,17,81,2075,0,16,3,89,65,2128,2059,2139,2049,16,0,80,1,2122,512]

theorem envBound14201 : H12AffineFastState.Bounded env14201 := by
  intro p hp
  have h : env14201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14200_14201 : H12AffineEnvironment.transform 1 0 env14200 = env14201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env14200 == env14201) = true)

theorem identity14201 : scanCanonicalize (H12AffineFastState.compose env14201 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound14201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14202 : List Nat := [2,0,8,16,1,1,8,16,512,16,2048,2075,24,2074,17,19,2059,2065,17,16,2075,0,16,3,24,0,2065,2059,2074,2049,16,0,17,1,2059,512]

theorem envBound14202 : H12AffineFastState.Bounded env14202 := by
  intro p hp
  have h : env14202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14201_14202 : H12AffineEnvironment.transform 5 1 env14201 = env14202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env14201 == env14202) = true)

def env14203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77899,4194304,318564,294187,8193,65,4456788,313700,375166,97407,75102,4466729,257,21793,46092,513]

theorem envBound14203 : H12AffineFastState.Bounded env14203 := by
  intro p hp
  have h : env14203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14189_14203 : H12AffineEnvironment.transform 6 9 env14189 = env14203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14189 == env14203) = true)

theorem identity14203 : scanCanonicalize (H12AffineFastState.compose env14203 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound14203 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56437,1025,32769,77899,4194304,17,41310,8193,65,4250913,5393,91403,97407,75102,4256860,257,21793,46092,513]

theorem envBound14204 : H12AffineFastState.Bounded env14204 := by
  intro p hp
  have h : env14204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14203_14204 : H12AffineEnvironment.transform 17 56437 env14203 = env14204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env14203 == env14204) = true)

theorem identity14204 : scanCanonicalize (H12AffineFastState.compose env14204 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14204 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79130,35188,1025,32769,77899,4194304,17,41310,8193,65,4229152,5393,77834,76158,75102,4235613,257,32,46092,513]

theorem envBound14205 : H12AffineFastState.Bounded env14205 := by
  intro p hp
  have h : env14205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14204_14205 : H12AffineEnvironment.transform 13 5377 env14204 = env14205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14204 == env14205) = true)

theorem identity14205 : scanCanonicalize (H12AffineFastState.compose env14205 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14205 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env14206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,10280,1025,8541,77899,4194304,17,2,8193,65,4204924,5393,77834,76158,75102,4194305,257,32,5456,513]

theorem envBound14206 : H12AffineFastState.Bounded env14206 := by
  intro p hp
  have h : env14206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14205_14206 : H12AffineEnvironment.transform 14 8540 env14205 = env14206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14205 == env14206) = true)

theorem identity14206 : scanCanonicalize (H12AffineFastState.compose env14206 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14206 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,65536,70726,2420,1025,1,69911,4194304,17,2,349,65,4196384,5393,69974,67618,66562,4194305,257,32,5456,513]

theorem envBound14207 : H12AffineFastState.Bounded env14207 := by
  intro p hp
  have h : env14207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14206_14207 : H12AffineEnvironment.transform 12 348 env14206 = env14207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14206 == env14207) = true)

theorem identity14207 : scanCanonicalize (H12AffineFastState.compose env14207 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound14207 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1025,1,4161,4194304,17,2,349,65,4196384,5393,4096,2420,1364,4194305,257,32,5456,513]

theorem envBound14208 : H12AffineFastState.Bounded env14208 := by
  intro p hp
  have h : env14208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14207_14208 : H12AffineEnvironment.transform 15 342 env14207 = env14208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env14207 == env14208) = true)

theorem identity14208 : scanCanonicalize (H12AffineFastState.compose env14208 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound14208 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1025,1,4161,113,17,2,349,65,2129,5393,4096,2420,1364,112,257,32,5456,513]

theorem envBound14209 : H12AffineFastState.Bounded env14209 := by
  intro p hp
  have h : env14209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14208_14209 : H12AffineEnvironment.transform 21 113 env14208 = env14209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env14208 == env14209) = true)

def env14210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318701,466225,8328,65,4456924,313837,449005,138477,148941,4466848,257,21793,46213,221723]

theorem envBound14210 : H12AffineFastState.Bounded env14210 := by
  intro p hp
  have h : env14210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14187_14210 : H12AffineEnvironment.transform 20 151633 env14187 = env14210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env14187 == env14210) = true)

theorem identity14210 : scanCanonicalize (H12AffineFastState.compose env14210 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound14210 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77899,4194304,318701,294187,8328,65,4456924,313837,375287,97527,75223,4466848,257,21793,46213,513]

theorem envBound14211 : H12AffineFastState.Bounded env14211 := by
  intro p hp
  have h : env14211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14210_14211 : H12AffineEnvironment.transform 16 90138 env14210 = env14211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env14210 == env14211) = true)

def env14212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,77899,4194304,272441,294187,8328,65,4456924,277817,347427,97527,75223,4466848,257,21793,16465,513]

theorem envBound14212 : H12AffineFastState.Bounded env14212 := by
  intro p hp
  have h : env14212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14211_14212 : H12AffineEnvironment.transform 14 29908 env14211 = env14212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env14211 == env14212) = true)

def env14213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,77899,272512,272441,294187,8328,65,10588,277817,347427,97527,75223,32,257,21793,16465,513]

theorem envBound14213 : H12AffineFastState.Bounded env14213 := by
  intro p hp
  have h : env14213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14212_14213 : H12AffineEnvironment.transform 21 272512 env14212 = env14213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env14212 == env14213) = true)

theorem identity14213 : scanCanonicalize (H12AffineFastState.compose env14213 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound14213 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,10280,1025,29909,77899,168,17,21763,8328,65,10588,5393,91403,97527,75223,32,257,21793,16465,513]

theorem envBound14214 : H12AffineFastState.Bounded env14214 := by
  intro p hp
  have h : env14214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14213_14214 : H12AffineEnvironment.transform 17 10280 env14213 = env14214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14213 == env14214) = true)

theorem identity14214 : scanCanonicalize (H12AffineFastState.compose env14214 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14214 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env14215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,65536,82246,2420,1025,21897,69911,168,17,21763,468,65,2048,5393,83031,89515,66699,32,257,21793,16465,513]

theorem envBound14215 : H12AffineFastState.Bounded env14215 := by
  intro p hp
  have h : env14215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14214_14215 : H12AffineEnvironment.transform 12 348 env14214 = env14215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14214 == env14215) = true)

theorem identity14215 : scanCanonicalize (H12AffineFastState.compose env14215 (packedSelected [0,2,4,6,9,20,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound14215 : packedSelected [0,2,4,6,9,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env14216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,0,65536,70862,2420,1025,1,69911,168,17,139,468,65,2048,5393,70111,67619,66699,32,257,169,5593,513]

theorem envBound14216 : H12AffineFastState.Bounded env14216 := by
  intro p hp
  have h : env14216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14215_14216 : H12AffineEnvironment.transform 13 5512 env14215 = env14216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env14215 == env14216) = true)

theorem identity14216 : scanCanonicalize (H12AffineFastState.compose env14216 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14216 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,65536,70727,2420,1025,1,69911,33,17,2,349,65,2048,5393,69974,67619,66562,32,257,32,5456,513]

theorem envBound14217 : H12AffineFastState.Bounded env14217 := by
  intro p hp
  have h : env14217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14216_14217 : H12AffineEnvironment.transform 6 9 env14216 = env14217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14216 == env14217) = true)

theorem identity14217 : scanCanonicalize (H12AffineFastState.compose env14217 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound14217 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5392,2420,1025,1,4160,33,17,2,349,65,2048,5393,4097,2420,1365,32,257,32,5456,513]

theorem envBound14218 : H12AffineFastState.Bounded env14218 := by
  intro p hp
  have h : env14218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14217_14218 : H12AffineEnvironment.transform 15 343 env14217 = env14218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env14217 == env14218) = true)

theorem identity14218 : scanCanonicalize (H12AffineFastState.compose env14218 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound14218 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14219 : List Nat := [2,4,8,16,32,64,9,256,512,613,2048,4096,348,4964,0,343,4981,2420,612,1,4160,33,17,2,349,65,2048,4980,4097,2420,816,32,257,32,4917,513]

theorem envBound14219 : H12AffineFastState.Bounded env14219 := by
  intro p hp
  have h : env14219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14218_14219 : H12AffineEnvironment.transform 9 613 env14218 = env14219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env14218 == env14219) = true)

def env14220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,77899,272513,272441,294187,8328,65,10589,277817,347427,97527,75223,33,257,21793,16465,513]

theorem envBound14220 : H12AffineFastState.Bounded env14220 := by
  intro p hp
  have h : env14220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14212_14220 : H12AffineEnvironment.transform 21 272513 env14212 = env14220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env14212 == env14220) = true)

def env14221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,32160,1025,29909,77899,21793,21913,139,8328,65,10589,16537,77955,97527,75223,33,257,21793,16465,513]

theorem envBound14221 : H12AffineFastState.Bounded env14221 := by
  intro p hp
  have h : env14221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14220_14221 : H12AffineEnvironment.transform 17 32160 env14220 = env14221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env14220 == env14221) = true)

theorem identity14221 : scanCanonicalize (H12AffineFastState.compose env14221 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14221 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79131,10401,1025,8660,77899,32,152,139,8328,65,10589,5528,77955,76278,75223,33,257,32,5456,513]

theorem envBound14222 : H12AffineFastState.Bounded env14222 := by
  intro p hp
  have h : env14222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14221_14222 : H12AffineEnvironment.transform 13 5377 env14221 = env14222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14221 == env14222) = true)

theorem identity14222 : scanCanonicalize (H12AffineFastState.compose env14222 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14222 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env14223 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,65536,79131,10401,1025,8581,77850,32,152,139,8328,16,10508,5528,77955,76199,75142,33,257,32,5377,513]

theorem envBound14223 : H12AffineFastState.Bounded env14223 := by
  intro p hp
  have h : env14223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14222_14223 : H12AffineEnvironment.transform 5 17 env14222 = env14223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14222 == env14223) = true)

theorem identity14223 : scanCanonicalize (H12AffineFastState.compose env14223 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14223 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14224 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,136,65536,70679,2477,1025,137,69910,32,152,139,388,16,2048,5528,70031,67755,66698,33,257,32,5377,513]

theorem envBound14224 : H12AffineFastState.Bounded env14224 := by
  intro p hp
  have h : env14224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14223_14224 : H12AffineEnvironment.transform 12 268 env14223 = env14224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14223 == env14224) = true)

theorem identity14224 : scanCanonicalize (H12AffineFastState.compose env14224 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(15+1) ^^^ 1183) := by decide +kernel

theorem selectedBound14224 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env14225 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,136,1183,4232,2477,1025,137,5513,32,152,139,388,16,2048,5528,5392,3124,21,33,257,32,5377,513]

theorem envBound14225 : H12AffineFastState.Bounded env14225 := by
  intro p hp
  have h : env14225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14224_14225 : H12AffineEnvironment.transform 15 1183 env14224 = env14225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1183 env14224 == env14225) = true)

theorem identity14225 : scanCanonicalize (H12AffineFastState.compose env14225 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14225 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14226 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,268,4112,136,398,4232,2477,272,137,4248,32,152,139,388,16,2048,4233,4097,2341,21,33,257,32,4112,513]

theorem envBound14226 : H12AffineFastState.Bounded env14226 := by
  intro p hp
  have h : env14226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14225_14226 : H12AffineEnvironment.transform 9 273 env14225 = env14226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14225 == env14226) = true)

theorem identity14226 : scanCanonicalize (H12AffineFastState.compose env14226 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14226 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14227 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,1,263,4097,2340,272,0,4113,32,17,2,269,16,2048,4096,4097,2341,21,33,257,32,4112,513]

theorem envBound14227 : H12AffineFastState.Bounded env14227 := by
  intro p hp
  have h : env14227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14226_14227 : H12AffineEnvironment.transform 6 9 env14226 = env14227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14226 == env14227) = true)

theorem identity14227 : scanCanonicalize (H12AffineFastState.compose env14227 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound14227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14228 : List Nat := [2,4,8,16,32,17,9,52,512,37,2048,4096,56,4112,1,51,4097,2064,36,0,4113,32,17,2,57,16,2048,4096,4097,2065,21,33,53,32,4112,513]

theorem envBound14228 : H12AffineFastState.Bounded env14228 := by
  intro p hp
  have h : env14228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14227_14228 : H12AffineEnvironment.transform 7 52 env14227 = env14228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env14227 == env14228) = true)

theorem identity14228 : scanCanonicalize (H12AffineFastState.compose env14228 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound14228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14229 : List Nat := [2,4,8,16,32,17,9,52,512,37,2048,554,56,570,1,51,555,2064,36,0,571,32,17,2,57,16,2048,554,555,2065,21,33,53,32,570,513]

theorem envBound14229 : H12AffineFastState.Bounded env14229 := by
  intro p hp
  have h : env14229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14228_14229 : H12AffineEnvironment.transform 11 554 env14228 = env14229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env14228 == env14229) = true)

theorem identity14229 : scanCanonicalize (H12AffineFastState.compose env14229 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound14229 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14230 : List Nat := [2,4,8,16,11,17,9,31,512,14,2048,513,19,529,1,24,512,2064,15,0,528,11,17,2,18,16,2048,513,512,2065,21,10,30,11,529,513]

theorem envBound14230 : H12AffineFastState.Bounded env14230 := by
  intro p hp
  have h : env14230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14229_14230 : H12AffineEnvironment.transform 4 11 env14229 = env14230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env14229 == env14230) = true)

theorem identity14230 : scanCanonicalize (H12AffineFastState.compose env14230 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14230 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14231 : List Nat := [2,4,8,16,11,17,9,31,512,14,1,513,19,529,1,24,512,17,15,0,528,11,17,2,18,16,1,513,512,16,21,10,30,11,529,513]

theorem envBound14231 : H12AffineFastState.Bounded env14231 := by
  intro p hp
  have h : env14231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14230_14231 : H12AffineEnvironment.transform 10 1 env14230 = env14231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14230 == env14231) = true)

def env14232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,32161,1025,29909,77899,21792,21912,138,8328,65,10589,16536,77954,97527,75223,33,257,21793,16465,513]

theorem envBound14232 : H12AffineFastState.Bounded env14232 := by
  intro p hp
  have h : env14232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14220_14232 : H12AffineEnvironment.transform 17 32161 env14220 = env14232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env14220 == env14232) = true)

theorem identity14232 : scanCanonicalize (H12AffineFastState.compose env14232 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound14232 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,79251,10280,1025,8540,77899,169,17,138,8328,65,10589,5393,77954,76158,75223,33,257,168,5592,513]

theorem envBound14233 : H12AffineFastState.Bounded env14233 := by
  intro p hp
  have h : env14233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14232_14233 : H12AffineEnvironment.transform 13 5513 env14232 = env14233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env14232 == env14233) = true)

theorem identity14233 : scanCanonicalize (H12AffineFastState.compose env14233 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound14233 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,478,13389,10280,1025,8540,12693,169,17,138,8328,65,10589,5393,12636,10400,9225,33,257,168,5592,513]

theorem envBound14234 : H12AffineFastState.Bounded env14234 := by
  intro p hp
  have h : env14234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14233_14234 : H12AffineEnvironment.transform 15 478 env14233 = env14234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env14233 == env14234) = true)

theorem identity14234 : scanCanonicalize (H12AffineFastState.compose env14234 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14234 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env14235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,478,5529,2556,1025,136,4161,169,17,138,348,65,2185,5393,4232,2420,1501,33,257,168,5592,513]

theorem envBound14235 : H12AffineFastState.Bounded env14235 := by
  intro p hp
  have h : env14235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14234_14235 : H12AffineEnvironment.transform 12 468 env14234 = env14235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14234 == env14235) = true)

theorem identity14235 : scanCanonicalize (H12AffineFastState.compose env14235 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14235 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14236 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,137,398,5529,2476,1025,136,4113,169,17,138,268,17,2185,5393,4232,2340,1421,33,257,168,5512,513]

theorem envBound14236 : H12AffineFastState.Bounded env14236 := by
  intro p hp
  have h : env14236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14235_14236 : H12AffineEnvironment.transform 5 16 env14235 = env14236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14235 == env14236) = true)

theorem identity14236 : scanCanonicalize (H12AffineFastState.compose env14236 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1165) := by decide +kernel

theorem selectedBound14236 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14237 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1165,388,260,137,398,276,2476,1025,136,1180,169,17,138,268,17,2185,412,1029,2340,1421,33,257,168,261,513]

theorem envBound14237 : H12AffineFastState.Bounded env14237 := by
  intro p hp
  have h : env14237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14236_14237 : H12AffineEnvironment.transform 11 1165 env14236 = env14237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1165 env14236 == env14237) = true)

theorem identity14237 : scanCanonicalize (H12AffineFastState.compose env14237 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound14237 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14238 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1181,1165,388,260,137,398,276,1329,1025,136,1180,169,17,138,268,17,1044,412,1029,1465,1421,33,257,168,261,513]

theorem envBound14238 : H12AffineFastState.Bounded env14238 := by
  intro p hp
  have h : env14238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14237_14238 : H12AffineEnvironment.transform 10 1181 env14237 = env14238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env14237 == env14238) = true)

theorem identity14238 : scanCanonicalize (H12AffineFastState.compose env14238 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound14238 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env14239 : List Nat := [2,4,8,16,32,16,128,256,512,517,664,648,388,260,137,398,276,820,516,136,665,169,17,138,268,17,529,412,512,956,904,33,257,168,261,513]

theorem envBound14239 : H12AffineFastState.Bounded env14239 := by
  intro p hp
  have h : env14239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14238_14239 : H12AffineEnvironment.transform 9 517 env14238 = env14239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env14238 == env14239) = true)

theorem identity14239 : scanCanonicalize (H12AffineFastState.compose env14239 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14239 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env14240 : List Nat := [2,4,8,16,32,16,128,37,512,517,664,648,161,33,137,171,49,529,516,136,665,169,17,138,41,17,529,185,512,665,685,33,36,168,32,513]

theorem envBound14240 : H12AffineFastState.Bounded env14240 := by
  intro p hp
  have h : env14240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14239_14240 : H12AffineEnvironment.transform 7 37 env14239 = env14240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14239 == env14240) = true)

theorem identity14240 : scanCanonicalize (H12AffineFastState.compose env14240 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14241 : List Nat := [2,4,8,16,1,16,128,4,512,517,664,648,128,0,137,138,16,529,516,136,665,136,17,138,8,17,529,152,512,665,652,0,5,137,1,513]

theorem envBound14241 : H12AffineFastState.Bounded env14241 := by
  intro p hp
  have h : env14241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14240_14241 : H12AffineEnvironment.transform 4 1 env14240 = env14241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14240 == env14241) = true)

theorem identity14241 : scanCanonicalize (H12AffineFastState.compose env14241 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14242 : List Nat := [2,4,8,16,1,16,128,4,0,5,152,136,128,0,137,138,16,17,4,136,153,136,17,138,8,17,17,152,0,153,140,0,5,137,1,1]

theorem envBound14242 : H12AffineFastState.Bounded env14242 := by
  intro p hp
  have h : env14242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14241_14242 : H12AffineEnvironment.transform 8 0 env14241 = env14242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14241 == env14242) = true)

def env14243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,77899,4194304,272440,294187,8328,65,4456924,277816,347426,97527,75223,4466848,257,21793,16464,513]

theorem envBound14243 : H12AffineFastState.Bounded env14243 := by
  intro p hp
  have h : env14243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14211_14243 : H12AffineEnvironment.transform 14 29909 env14211 = env14243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14211 == env14243) = true)

def env14244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,77899,272512,272440,294187,8328,65,10588,277816,347426,97527,75223,32,257,21793,16464,513]

theorem envBound14244 : H12AffineFastState.Bounded env14244 := by
  intro p hp
  have h : env14244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14243_14244 : H12AffineEnvironment.transform 21 272512 env14243 = env14244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env14243 == env14244) = true)

theorem identity14244 : scanCanonicalize (H12AffineFastState.compose env14244 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14244 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,16400,262144,1025,29908,4161,272512,272440,294187,8328,65,10588,277816,290088,23805,1501,32,257,21793,16464,513]

theorem envBound14245 : H12AffineFastState.Bounded env14245 := by
  intro p hp
  have h : env14245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14244_14245 : H12AffineEnvironment.transform 15 8202 env14244 = env14245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14244 == env14245) = true)

theorem identity14245 : scanCanonicalize (H12AffineFastState.compose env14245 (packedSelected [7,11,14,18,20,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound14245 : packedSelected [7,11,14,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env14246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8580,8202,5441,262144,1025,8581,4161,272512,272440,272506,8328,65,10588,277816,276601,2476,1501,32,257,112,5377,513]

theorem envBound14246 : H12AffineFastState.Bounded env14246 := by
  intro p hp
  have h : env14246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14245_14246 : H12AffineEnvironment.transform 13 5457 env14245 = env14246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env14245 == env14246) = true)

theorem identity14246 : scanCanonicalize (H12AffineFastState.compose env14246 (packedSelected [1,2,4,5,6,8,9,14,15,17,18,20,23,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14246 : packedSelected [1,2,4,5,6,8,9,14,15,17,18,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env14247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5457,216,342,5441,262144,1025,217,4161,264668,264548,264486,468,65,2048,269412,268581,2476,1501,32,257,112,5377,513]

theorem envBound14247 : H12AffineFastState.Bounded env14247 := by
  intro p hp
  have h : env14247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14246_14247 : H12AffineEnvironment.transform 12 348 env14246 = env14247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14246 == env14247) = true)

theorem identity14247 : scanCanonicalize (H12AffineFastState.compose env14247 (packedSelected [0,4,6,10,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound14247 : packedSelected [0,4,6,10,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env14248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2357,348,3172,216,342,3188,262144,1025,217,2420,264668,264548,264486,468,65,2048,263505,262160,2476,1501,32,257,112,3124,513]

theorem envBound14248 : H12AffineFastState.Bounded env14248 := by
  intro p hp
  have h : env14248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14247_14248 : H12AffineEnvironment.transform 11 2357 env14247 = env14248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env14247 == env14248) = true)

theorem identity14248 : scanCanonicalize (H12AffineFastState.compose env14248 (packedSelected [0,1,2,7,8,11,12,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 372) := by decide +kernel

theorem selectedBound14248 : packedSelected [0,1,2,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env14249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2357,348,3172,216,342,3188,372,1025,217,2420,2216,2064,2130,468,65,2048,1061,356,2476,1501,32,257,112,3124,513]

theorem envBound14249 : H12AffineFastState.Bounded env14249 := by
  intro p hp
  have h : env14249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14248_14249 : H12AffineEnvironment.transform 17 372 env14248 = env14249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 372 env14248 == env14249) = true)

theorem identity14249 : scanCanonicalize (H12AffineFastState.compose env14249 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound14249 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env14250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,200,348,1433,216,342,1417,372,1025,217,137,341,493,431,468,65,509,1061,356,81,1501,32,257,112,1481,513]

theorem envBound14250 : H12AffineFastState.Bounded env14250 := by
  intro p hp
  have h : env14250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14249_14250 : H12AffineEnvironment.transform 10 509 env14249 = env14250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env14249 == env14250) = true)

def env14251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,77899,272513,272440,294187,8328,65,10589,277816,347426,97527,75223,33,257,21793,16464,513]

theorem envBound14251 : H12AffineFastState.Bounded env14251 := by
  intro p hp
  have h : env14251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14243_14251 : H12AffineEnvironment.transform 21 272513 env14243 = env14251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env14243 == env14251) = true)

theorem identity14251 : scanCanonicalize (H12AffineFastState.compose env14251 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound14251 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,67619,1025,29908,77899,73890,73755,95496,8328,65,10589,79131,17665,97527,75223,33,257,21793,16464,513]

theorem envBound14252 : H12AffineFastState.Bounded env14252 := by
  intro p hp
  have h : env14252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14251_14252 : H12AffineEnvironment.transform 17 67619 env14251 = env14252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env14251 == env14252) = true)

def env14253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,67619,1025,29788,77899,73770,73755,95496,8192,65,10589,79131,17665,97407,75103,33,257,21793,16464,513]

theorem envBound14253 : H12AffineFastState.Bounded env14253 := by
  intro p hp
  have h : env14253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14252_14253 : H12AffineEnvironment.transform 6 8 env14252 = env14253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14252 == env14253) = true)

theorem identity14253 : scanCanonicalize (H12AffineFastState.compose env14253 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14253 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,32041,1025,29788,17729,21792,21777,2,8192,65,10589,16401,17665,2421,20565,33,257,21793,16464,513]

theorem envBound14254 : H12AffineFastState.Bounded env14254 := by
  intro p hp
  have h : env14254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14253_14254 : H12AffineEnvironment.transform 15 29962 env14253 = env14254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14253 == env14254) = true)

theorem identity14254 : scanCanonicalize (H12AffineFastState.compose env14254 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14254 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8282,5392,10361,1025,8460,4113,112,65,2,8192,65,10589,5441,4177,2421,1285,33,257,113,5376,513]

theorem envBound14255 : H12AffineFastState.Bounded env14255 := by
  intro p hp
  have h : env14255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14254_14255 : H12AffineEnvironment.transform 13 5456 env14254 = env14255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env14254 == env14255) = true)

theorem identity14255 : scanCanonicalize (H12AffineFastState.compose env14255 (packedSelected [0,1,4,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound14255 : packedSelected [0,1,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env14256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,8192,3345,8461,8282,3409,10361,1025,8460,2128,112,65,2,8192,65,10589,3328,2064,2421,1285,33,257,113,3393,513]

theorem envBound14256 : H12AffineFastState.Bounded env14256 := by
  intro p hp
  have h : env14256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14255_14256 : H12AffineEnvironment.transform 11 2113 env14255 = env14256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env14255 == env14256) = true)

theorem identity14256 : scanCanonicalize (H12AffineFastState.compose env14256 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14256 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env14257 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2113,8192,2340,8461,8282,2404,10361,52,8460,2128,112,65,2,8192,65,10589,2357,2064,2421,304,33,257,113,2420,513]

theorem envBound14257 : H12AffineFastState.Bounded env14257 := by
  intro p hp
  have h : env14257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14256_14257 : H12AffineEnvironment.transform 9 53 env14256 = env14257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14256 == env14257) = true)

theorem identity14257 : scanCanonicalize (H12AffineFastState.compose env14257 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound14257 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env14258 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2113,120,2340,373,34,2404,2049,52,372,2128,112,65,2,120,65,2341,2357,2064,2421,304,33,257,113,2420,513]

theorem envBound14258 : H12AffineFastState.Bounded env14258 := by
  intro p hp
  have h : env14258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14257_14258 : H12AffineEnvironment.transform 12 120 env14257 = env14258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env14257 == env14258) = true)

theorem identity14258 : scanCanonicalize (H12AffineFastState.compose env14258 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound14258 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14259 : List Nat := [2,4,8,16,32,64,8,256,512,53,293,356,120,1,373,34,65,292,52,372,373,112,65,2,120,65,0,16,309,80,304,33,257,113,81,513]

theorem envBound14259 : H12AffineFastState.Bounded env14259 := by
  intro p hp
  have h : env14259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14258_14259 : H12AffineEnvironment.transform 10 293 env14258 = env14259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env14258 == env14259) = true)

theorem identity14259 : scanCanonicalize (H12AffineFastState.compose env14259 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14259 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14260 : List Nat := [2,4,8,16,32,17,8,256,512,53,293,309,41,1,292,34,16,292,52,293,292,33,16,2,41,16,0,16,309,1,304,33,257,32,0,513]

theorem envBound14260 : H12AffineFastState.Bounded env14260 := by
  intro p hp
  have h : env14260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14259_14260 : H12AffineEnvironment.transform 5 17 env14259 = env14260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14259 == env14260) = true)

theorem identity14260 : scanCanonicalize (H12AffineFastState.compose env14260 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14260 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14261 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,41,1,1,34,16,1,52,0,1,33,16,2,41,16,0,16,16,1,21,33,36,32,0,513]

theorem envBound14261 : H12AffineFastState.Bounded env14261 := by
  intro p hp
  have h : env14261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14260_14261 : H12AffineEnvironment.transform 7 37 env14260 = env14261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14260 == env14261) = true)

theorem identity14261 : scanCanonicalize (H12AffineFastState.compose env14261 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14262 : List Nat := [2,4,8,16,32,17,8,37,1,53,0,16,41,1,1,34,16,1,52,0,1,33,16,2,41,16,0,16,16,1,21,33,36,32,0,0]

theorem envBound14262 : H12AffineFastState.Bounded env14262 := by
  intro p hp
  have h : env14262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14261_14262 : H12AffineEnvironment.transform 8 1 env14261 = env14262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14261 == env14262) = true)

theorem identity14262 : scanCanonicalize (H12AffineFastState.compose env14262 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound14262 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14263 : List Nat := [2,4,8,16,27,17,8,30,1,14,0,16,18,1,1,25,16,1,15,0,1,26,16,2,18,16,0,16,16,1,21,26,31,27,0,0]

theorem envBound14263 : H12AffineFastState.Bounded env14263 := by
  intro p hp
  have h : env14263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14262_14263 : H12AffineEnvironment.transform 4 27 env14262 = env14263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env14262 == env14263) = true)

def env14264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,67619,1025,29789,77899,73771,73755,95496,8193,65,10589,79131,17665,97406,75102,33,257,21793,16464,513]

theorem envBound14264 : H12AffineFastState.Bounded env14264 := by
  intro p hp
  have h : env14264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14252_14264 : H12AffineEnvironment.transform 6 9 env14252 = env14264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14252 == env14264) = true)

theorem identity14264 : scanCanonicalize (H12AffineFastState.compose env14264 (packedSelected [2,6,7,14,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14264 : packedSelected [2,6,7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env14265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,65536,82198,67619,1025,21841,69959,65831,65815,87044,269,65,2129,70679,17665,89458,66642,33,257,21793,16464,513]

theorem envBound14265 : H12AffineFastState.Bounded env14265 := by
  intro p hp
  have h : env14265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14264_14265 : H12AffineEnvironment.transform 12 268 env14264 = env14265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14264 == env14265) = true)

theorem identity14265 : scanCanonicalize (H12AffineFastState.compose env14265 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14265 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,262,16400,2341,1025,21841,4161,33,17,21762,269,65,2129,5393,17665,23668,1364,33,257,21793,16464,513]

theorem envBound14266 : H12AffineFastState.Bounded env14266 := by
  intro p hp
  have h : env14266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14265_14266 : H12AffineEnvironment.transform 15 262 env14265 = env14266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14265 == env14266) = true)

theorem identity14266 : scanCanonicalize (H12AffineFastState.compose env14266 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14266 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14267 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,268,16384,20545,262,16400,2341,272,20544,4161,33,17,20499,269,65,2129,4096,16400,22885,69,33,257,20528,16464,513]

theorem envBound14267 : H12AffineFastState.Bounded env14267 := by
  intro p hp
  have h : env14267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14266_14267 : H12AffineEnvironment.transform 9 273 env14266 = env14267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14266 == env14267) = true)

theorem identity14267 : scanCanonicalize (H12AffineFastState.compose env14267 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound14267 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env14268 : List Nat := [2,4,8,16,32,64,9,256,512,273,788,4096,268,16384,20545,262,16400,561,272,20544,4161,33,17,20499,269,65,837,4096,16400,21105,69,33,257,20528,16464,513]

theorem envBound14268 : H12AffineFastState.Bounded env14268 := by
  intro p hp
  have h : env14268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14267_14268 : H12AffineEnvironment.transform 10 788 env14267 = env14268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env14267 == env14268) = true)

theorem identity14268 : scanCanonicalize (H12AffineFastState.compose env14268 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14268 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14269 : List Nat := [2,4,8,16,32,64,9,117,512,100,609,4096,121,16384,20545,115,16400,561,101,20544,4161,33,17,20499,120,65,560,4096,16400,21105,69,33,116,20528,16464,513]

theorem envBound14269 : H12AffineFastState.Bounded env14269 := by
  intro p hp
  have h : env14269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14268_14269 : H12AffineEnvironment.transform 7 117 env14268 = env14269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14268 == env14269) = true)

theorem identity14269 : scanCanonicalize (H12AffineFastState.compose env14269 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4193) := by decide +kernel

theorem selectedBound14269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14270 : List Nat := [2,4,8,16,32,64,9,117,512,100,609,4096,121,4193,32,115,4209,561,101,33,4161,33,17,114,120,65,560,4096,4209,528,69,33,116,81,4145,513]

theorem envBound14270 : H12AffineFastState.Bounded env14270 := by
  intro p hp
  have h : env14270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14269_14270 : H12AffineEnvironment.transform 13 4193 env14269 = env14270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4193 env14269 == env14270) = true)

theorem identity14270 : scanCanonicalize (H12AffineFastState.compose env14270 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14270 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env14271 : List Nat := [2,4,8,16,32,17,9,36,512,53,560,4096,40,4144,32,34,4128,561,52,33,4112,33,17,35,41,16,560,4096,4128,528,20,33,37,0,4145,513]

theorem envBound14271 : H12AffineFastState.Bounded env14271 := by
  intro p hp
  have h : env14271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14270_14271 : H12AffineEnvironment.transform 5 17 env14270 = env14271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14270 == env14271) = true)

theorem identity14271 : scanCanonicalize (H12AffineFastState.compose env14271 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound14271 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env14272 : List Nat := [2,4,8,16,32,17,9,36,512,53,560,561,40,513,32,34,529,561,52,33,545,33,17,35,41,16,560,561,529,528,20,33,37,0,512,513]

theorem envBound14272 : H12AffineFastState.Bounded env14272 := by
  intro p hp
  have h : env14272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14271_14272 : H12AffineEnvironment.transform 11 561 env14271 = env14272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env14271 == env14272) = true)

theorem identity14272 : scanCanonicalize (H12AffineFastState.compose env14272 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14272 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14273 : List Nat := [2,4,8,16,0,17,9,4,512,21,528,529,8,513,0,2,529,529,20,1,513,1,17,3,9,16,528,529,529,528,20,1,5,0,512,513]

theorem envBound14273 : H12AffineFastState.Bounded env14273 := by
  intro p hp
  have h : env14273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14272_14273 : H12AffineEnvironment.transform 4 0 env14272 = env14273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14272 == env14273) = true)

theorem identity14273 : scanCanonicalize (H12AffineFastState.compose env14273 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14273 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14274 : List Nat := [2,4,8,16,0,17,9,4,0,21,16,17,8,1,0,2,17,17,20,1,1,1,17,3,9,16,16,17,17,16,20,1,5,0,0,1]

theorem envBound14274 : H12AffineFastState.Bounded env14274 := by
  intro p hp
  have h : env14274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14273_14274 : H12AffineEnvironment.transform 8 0 env14273 = env14274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14273 == env14274) = true)

theorem identity14274 : scanCanonicalize (H12AffineFastState.compose env14274 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14274 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14275 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,1,8,1,0,2,1,1,4,1,1,1,1,3,9,0,0,1,1,0,4,1,5,0,0,1]

theorem envBound14275 : H12AffineFastState.Bounded env14275 := by
  intro p hp
  have h : env14275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14274_14275 : H12AffineEnvironment.transform 3 0 env14274 = env14275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14274 == env14275) = true)

def env14276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound14276 : H12AffineFastState.Bounded env14276 := by
  intro p hp
  have h : env14276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12741_14276 : H12AffineEnvironment.transform 29 155254785 env12741 = env14276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env12741 == env14276) = true)

def env14277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound14277 : H12AffineFastState.Bounded env14277 := by
  intro p hp
  have h : env14277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14276_14277 : H12AffineEnvironment.transform 25 64 env14276 = env14277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env14276 == env14277) = true)

def env14278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound14278 : H12AffineFastState.Bounded env14278 := by
  intro p hp
  have h : env14278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14277_14278 : H12AffineEnvironment.transform 26 30393344 env14277 = env14278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env14277 == env14278) = true)

def env14279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound14279 : H12AffineFastState.Bounded env14279 := by
  intro p hp
  have h : env14279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14278_14279 : H12AffineEnvironment.transform 18 1024 env14278 = env14279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14278 == env14279) = true)

theorem identity14279 : scanCanonicalize (H12AffineFastState.compose env14279 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound14279 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8328,64,21479440,18973836,2118976,442385,16876544,23160257,256,18990268,18949400,16819158]

theorem envBound14280 : H12AffineFastState.Bounded env14280 := by
  intro p hp
  have h : env14280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14279_14280 : H12AffineEnvironment.transform 22 16 env14279 = env14280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14279 == env14280) = true)

def env14281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479440,18973700,2118976,442385,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound14281 : H12AffineFastState.Bounded env14281 := by
  intro p hp
  have h : env14281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14280_14281 : H12AffineEnvironment.transform 6 8 env14280 = env14281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14280 == env14281) = true)

theorem identity14281 : scanCanonicalize (H12AffineFastState.compose env14281 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound14281 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,2,8192,64,4702226,2196486,2118976,442385,99330,6382923,256,2212918,2172186,41820]

theorem envBound14282 : H12AffineFastState.Bounded env14282 := by
  intro p hp
  have h : env14282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14281_14282 : H12AffineEnvironment.transform 23 2 env14281 = env14282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env14281 == env14282) = true)

def env14283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,2,8192,64,4554754,2196486,2118976,294913,99330,6382923,256,2212918,2172186,41820]

theorem envBound14283 : H12AffineFastState.Bounded env14283 := by
  intro p hp
  have h : env14283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14282_14283 : H12AffineEnvironment.transform 16 16400 env14282 = env14283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14282 == env14283) = true)

theorem identity14283 : scanCanonicalize (H12AffineFastState.compose env14283 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound14283 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env14284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,41340,16,2,8192,64,336254,2196486,2118976,294913,99330,2212919,256,2212918,2172186,41820]

theorem envBound14284 : H12AffineFastState.Bounded env14284 := by
  intro p hp
  have h : env14284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14283_14284 : H12AffineEnvironment.transform 21 41340 env14283 = env14284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env14283 == env14284) = true)

theorem identity14284 : scanCanonicalize (H12AffineFastState.compose env14284 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound14284 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1024,32769,2097152,41340,16,2,8192,64,108555,2196486,2118976,2420,99330,2212919,256,2212918,2172186,41820]

theorem envBound14285 : H12AffineFastState.Bounded env14285 := by
  intro p hp
  have h : env14285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14284_14285 : H12AffineEnvironment.transform 17 35189 env14284 = env14285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env14284 == env14285) = true)

theorem identity14285 : scanCanonicalize (H12AffineFastState.compose env14285 (packedSelected [1,2,3,4,5,6,7,8,10,12,14,15,17,18,19,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54642) := by decide +kernel

theorem selectedBound14285 : packedSelected [1,2,3,4,5,6,7,8,10,12,14,15,17,18,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env14286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54642,16400,35189,1024,32769,2097152,41340,16,2,8192,64,32121,2118004,2118976,2420,20848,2101573,256,2101572,2158696,41820]

theorem envBound14286 : H12AffineFastState.Bounded env14286 := by
  intro p hp
  have h : env14286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14285_14286 : H12AffineEnvironment.transform 15 54642 env14285 = env14286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54642 env14285 == env14286) = true)

theorem identity14286 : scanCanonicalize (H12AffineFastState.compose env14286 (packedSelected [2,3,5,6,9,10,14,18,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound14286 : packedSelected [2,3,5,6,9,10,14,18,22,23] rootPS < 2^1333 := by decide +kernel

def env14287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54642,16400,35189,1024,32769,50448,41340,16,2,8192,64,32121,37988,36944,2420,20848,54357,256,54356,13688,41820]

theorem envBound14287 : H12AffineFastState.Bounded env14287 := by
  intro p hp
  have h : env14287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14286_14287 : H12AffineEnvironment.transform 20 50448 env14286 = env14287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env14286 == env14287) = true)

theorem identity14287 : scanCanonicalize (H12AffineFastState.compose env14287 (packedSelected [4,9,10,12,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14287 : packedSelected [4,9,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env14288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29742,16400,10281,1024,8541,25676,32,16,2,8192,64,32121,13624,12556,2420,20848,29961,256,29960,13688,512]

theorem envBound14288 : H12AffineFastState.Bounded env14288 := by
  intro p hp
  have h : env14288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14287_14288 : H12AffineEnvironment.transform 14 8540 env14287 = env14288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14287 == env14288) = true)

theorem identity14288 : scanCanonicalize (H12AffineFastState.compose env14288 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound14288 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14289 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,16384,8200,29742,16400,10281,1024,8201,25676,32,16,2,8192,64,31789,13420,12376,2080,20516,29789,84,29788,13356,512]

theorem envBound14289 : H12AffineFastState.Bounded env14289 := by
  intro p hp
  have h : env14289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14288_14289 : H12AffineEnvironment.transform 7 84 env14288 = env14289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env14288 == env14289) = true)

theorem identity14289 : scanCanonicalize (H12AffineFastState.compose env14289 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound14289 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14290 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,8192,16384,8200,29742,16400,10281,1024,8201,25660,32,16,2,8192,48,31789,13340,12328,2080,20516,29741,36,29740,13356,512]

theorem envBound14290 : H12AffineFastState.Bounded env14290 := by
  intro p hp
  have h : env14290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14289_14290 : H12AffineEnvironment.transform 5 48 env14289 = env14290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env14289 == env14290) = true)

theorem identity14290 : scanCanonicalize (H12AffineFastState.compose env14290 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14290 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14291 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,40,16384,32,21510,16400,2049,1024,33,17428,32,16,2,40,48,23557,5172,4096,2080,20516,21509,36,21508,5124,512]

theorem envBound14291 : H12AffineFastState.Bounded env14291 := by
  intro p hp
  have h : env14291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14290_14291 : H12AffineEnvironment.transform 12 40 env14290 = env14291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14290 == env14291) = true)

theorem identity14291 : scanCanonicalize (H12AffineFastState.compose env14291 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound14291 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14292 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,40,5156,32,34,5172,2049,1024,33,4144,32,16,2,40,48,2081,5172,4096,2080,1024,33,36,32,5124,512]

theorem envBound14292 : H12AffineFastState.Bounded env14292 := by
  intro p hp
  have h : env14292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14291_14292 : H12AffineEnvironment.transform 13 5156 env14291 = env14292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env14291 == env14292) = true)

theorem identity14292 : scanCanonicalize (H12AffineFastState.compose env14292 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14292 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14293 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,0,2,5140,2049,1024,1,4112,0,16,2,8,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound14293 : H12AffineFastState.Bounded env14293 := by
  intro p hp
  have h : env14293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14292_14293 : H12AffineEnvironment.transform 4 0 env14292 = env14293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14292 == env14293) = true)

def env14294 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1044,0,2,1028,2049,1024,1,0,0,16,2,8,16,2049,1028,16,2048,1024,1,4,0,1044,512]

theorem envBound14294 : H12AffineFastState.Bounded env14294 := by
  intro p hp
  have h : env14294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14293_14294 : H12AffineEnvironment.transform 11 16 env14293 = env14294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14293 == env14294) = true)

theorem identity14294 : scanCanonicalize (H12AffineFastState.compose env14294 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound14294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14295 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,16,8,1044,0,2,1028,1044,1024,1,0,0,16,2,8,16,1044,1028,16,1045,1024,1,4,0,1044,512]

theorem envBound14295 : H12AffineFastState.Bounded env14295 := by
  intro p hp
  have h : env14295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14294_14295 : H12AffineEnvironment.transform 10 1045 env14294 = env14295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env14294 == env14295) = true)

def env14296 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,8,0,0,2,16,0,20,1,0,0,16,2,8,16,0,16,16,1,20,1,4,0,0,512]

theorem envBound14296 : H12AffineFastState.Bounded env14296 := by
  intro p hp
  have h : env14296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14295_14296 : H12AffineEnvironment.transform 9 20 env14295 = env14296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14295 == env14296) = true)

theorem identity14296 : scanCanonicalize (H12AffineFastState.compose env14296 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14297 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,8,0,0,2,4,0,0,1,0,0,4,2,8,4,0,4,4,1,0,1,4,0,0,512]

theorem envBound14297 : H12AffineFastState.Bounded env14297 := by
  intro p hp
  have h : env14297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14296_14297 : H12AffineEnvironment.transform 3 4 env14296 = env14297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14296 == env14297) = true)

def leafEnv14297 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,8,0,0,2,4,0,0,1,0,0,4,2,0,8,1,4,0,4,4,1,0,1,4,0,4,2,0,512,1,0,0]

def active14297 : List Nat := [0,1,2,8]

def tree14297 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14297 : H12WitnessSearch.Good tree14297 := H12GlobalWitnessIndex.good

theorem leafIdentity14297 : H12AffineFastState.composeSystem env14297 rootObs = leafEnv14297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14297 rootObs == leafEnv14297) = true)

theorem terminalChecked14297 : H12PackedTerminal.terminalCheckFast leafEnv14297 active14297 tree14297 = true := by decide +kernel

def env14298 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,1,0,2,17,1,21,1,0,0,16,2,8,16,1,17,16,0,21,1,4,0,1,512]

theorem envBound14298 : H12AffineFastState.Bounded env14298 := by
  intro p hp
  have h : env14298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14295_14298 : H12AffineEnvironment.transform 9 21 env14295 = env14298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14295 == env14298) = true)

theorem identity14298 : scanCanonicalize (H12AffineFastState.compose env14298 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound14298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14299 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,16,8,1,0,2,17,1,21,1,0,0,16,2,8,16,1,17,16,0,21,1,4,0,1,30]

theorem envBound14299 : H12AffineFastState.Bounded env14299 := by
  intro p hp
  have h : env14299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14298_14299 : H12AffineEnvironment.transform 8 30 env14298 = env14299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env14298 == env14299) = true)

def leafEnv14299 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,16,8,1,0,2,17,1,21,1,0,0,16,2,21,8,1,16,1,17,16,0,21,1,4,0,4,2,1,30,1,0,0]

def active14299 : List Nat := [0,1,2,3]

def tree14299 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14299 : H12WitnessSearch.Good tree14299 := H12GlobalWitnessIndex.good

theorem leafIdentity14299 : H12AffineFastState.composeSystem env14299 rootObs = leafEnv14299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14299 rootObs == leafEnv14299) = true)

theorem terminalChecked14299 : H12PackedTerminal.terminalCheckFast leafEnv14299 active14299 tree14299 = true := by decide +kernel

def env14300 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1045,0,2,1029,2049,1024,1,1,0,16,2,8,16,2049,1029,17,2048,1024,1,4,0,1045,512]

theorem envBound14300 : H12AffineFastState.Bounded env14300 := by
  intro p hp
  have h : env14300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14293_14300 : H12AffineEnvironment.transform 11 17 env14293 = env14300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14293 == env14300) = true)

theorem identity14300 : scanCanonicalize (H12AffineFastState.compose env14300 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14301 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,8,1045,0,2,1029,1,1024,1,1,0,16,2,8,16,1,1029,17,0,1024,1,4,0,1045,512]

theorem envBound14301 : H12AffineFastState.Bounded env14301 := by
  intro p hp
  have h : env14301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14300_14301 : H12AffineEnvironment.transform 10 0 env14300 = env14301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14300 == env14301) = true)

def env14302 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,8,1,0,2,17,1,20,1,1,0,16,2,8,16,1,17,17,0,20,1,4,0,1,512]

theorem envBound14302 : H12AffineFastState.Bounded env14302 := by
  intro p hp
  have h : env14302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14301_14302 : H12AffineEnvironment.transform 9 20 env14301 = env14302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14301 == env14302) = true)

theorem identity14302 : scanCanonicalize (H12AffineFastState.compose env14302 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14303 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,0,2,5,1,0,1,1,0,4,2,8,4,1,5,5,0,0,1,4,0,1,512]

theorem envBound14303 : H12AffineFastState.Bounded env14303 := by
  intro p hp
  have h : env14303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14302_14303 : H12AffineEnvironment.transform 3 4 env14302 = env14303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14302 == env14303) = true)

def leafEnv14303 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,0,2,5,1,0,1,1,0,4,2,0,8,1,4,1,5,5,0,0,1,4,0,4,2,1,512,1,1,0]

def active14303 : List Nat := [0,1,2,8]

def tree14303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14303 : H12WitnessSearch.Good tree14303 := H12GlobalWitnessIndex.good

theorem leafIdentity14303 : H12AffineFastState.composeSystem env14303 rootObs = leafEnv14303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14303 rootObs == leafEnv14303) = true)

theorem terminalChecked14303 : H12PackedTerminal.terminalCheckFast leafEnv14303 active14303 tree14303 = true := by decide +kernel

def env14304 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,0,0,2,16,1,21,1,1,0,16,2,8,16,1,16,17,0,21,1,4,0,0,512]

theorem envBound14304 : H12AffineFastState.Bounded env14304 := by
  intro p hp
  have h : env14304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14301_14304 : H12AffineEnvironment.transform 9 21 env14301 = env14304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14301 == env14304) = true)

theorem identity14304 : scanCanonicalize (H12AffineFastState.compose env14304 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound14304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14305 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,8,0,0,2,16,1,21,1,1,0,16,2,8,16,1,16,17,0,21,1,4,0,0,30]

theorem envBound14305 : H12AffineFastState.Bounded env14305 := by
  intro p hp
  have h : env14305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14304_14305 : H12AffineEnvironment.transform 8 30 env14304 = env14305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env14304 == env14305) = true)

def leafEnv14305 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,8,0,0,2,16,1,21,1,1,0,16,2,21,8,1,16,1,16,17,0,21,1,4,0,4,2,0,30,1,1,0]

def active14305 : List Nat := [0,1,2,3]

def tree14305 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14305 : H12WitnessSearch.Good tree14305 := H12GlobalWitnessIndex.good

theorem leafIdentity14305 : H12AffineFastState.composeSystem env14305 rootObs = leafEnv14305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14305 rootObs == leafEnv14305) = true)

theorem terminalChecked14305 : H12PackedTerminal.terminalCheckFast leafEnv14305 active14305 tree14305 = true := by decide +kernel

def env14306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,2,8192,64,4554755,2196486,2118976,294912,99330,6382923,256,2212918,2172186,41820]

theorem envBound14306 : H12AffineFastState.Bounded env14306 := by
  intro p hp
  have h : env14306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14282_14306 : H12AffineEnvironment.transform 16 16401 env14282 = env14306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14282 == env14306) = true)

theorem identity14306 : scanCanonicalize (H12AffineFastState.compose env14306 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound14306 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env14307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,2097152,4194304,16,2,8192,64,4530526,2172251,2118976,270685,75103,6382923,256,2188651,2172186,513]

theorem envBound14307 : H12AffineFastState.Bounded env14307 := by
  intro p hp
  have h : env14307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14306_14307 : H12AffineEnvironment.transform 14 8541 env14306 = env14307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env14306 == env14307) = true)

theorem identity14307 : scanCanonicalize (H12AffineFastState.compose env14307 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14307 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,5456,4194304,16,2,8192,64,4530526,77835,16400,270685,75103,4288539,256,94267,77898,513]

theorem envBound14308 : H12AffineFastState.Bounded env14308 := by
  intro p hp
  have h : env14308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14307_14308 : H12AffineEnvironment.transform 20 5456 env14307 = env14308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env14307 == env14308) = true)

theorem identity14308 : scanCanonicalize (H12AffineFastState.compose env14308 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14308 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env14309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1024,8540,5456,4194304,16,2,8192,64,4456788,4097,16400,270685,1365,4214801,256,20529,4160,513]

theorem envBound14309 : H12AffineFastState.Bounded env14309 := by
  intro p hp
  have h : env14309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14308_14309 : H12AffineEnvironment.transform 15 8202 env14308 = env14309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14308 == env14309) = true)

theorem identity14309 : scanCanonicalize (H12AffineFastState.compose env14309 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 292936) := by decide +kernel

theorem selectedBound14309 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env14310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1024,8540,5456,292936,16,2,8192,64,31004,4097,16400,270685,1365,272473,256,20529,4160,513]

theorem envBound14310 : H12AffineFastState.Bounded env14310 := by
  intro p hp
  have h : env14310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14309_14310 : H12AffineEnvironment.transform 21 292936 env14309 = env14310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292936 env14309 == env14310) = true)

theorem identity14310 : scanCanonicalize (H12AffineFastState.compose env14310 (packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS)) = affineNative (2^(17+1) ^^^ 30776) := by decide +kernel

theorem selectedBound14310 : packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS < 2^1333 := by decide +kernel

def env14311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,30776,1024,8540,5456,112,16,2,8192,64,31004,4097,16400,22885,1365,20577,256,20529,4160,513]

theorem envBound14311 : H12AffineFastState.Bounded env14311 := by
  intro p hp
  have h : env14311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14310_14311 : H12AffineEnvironment.transform 17 30776 env14310 = env14311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30776 env14310 == env14311) = true)

theorem identity14311 : scanCanonicalize (H12AffineFastState.compose env14311 (packedSelected [2,6,15,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14311 : packedSelected [2,6,15,38] rootPS < 2^1333 := by decide +kernel

def env14312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,80,263,16401,22837,1024,81,5456,112,16,2,269,64,22545,4097,16400,22885,1365,20577,256,20529,4160,513]

theorem envBound14312 : H12AffineFastState.Bounded env14312 := by
  intro p hp
  have h : env14312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14311_14312 : H12AffineEnvironment.transform 12 269 env14311 = env14312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14311 == env14312) = true)

theorem identity14312 : scanCanonicalize (H12AffineFastState.compose env14312 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound14312 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,4161,80,263,4176,2420,1024,81,5456,112,16,2,269,64,2128,4097,4177,2340,1365,32,256,112,4160,513]

theorem envBound14313 : H12AffineFastState.Bounded env14313 := by
  intro p hp
  have h : env14313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14312_14313 : H12AffineEnvironment.transform 13 4161 env14312 = env14313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env14312 == env14313) = true)

theorem identity14313 : scanCanonicalize (H12AffineFastState.compose env14313 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14313 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14314 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,269,4161,80,263,4176,2420,53,81,4453,112,16,2,269,64,2128,4097,4177,2340,352,32,256,112,4160,513]

theorem envBound14314 : H12AffineFastState.Bounded env14314 := by
  intro p hp
  have h : env14314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14313_14314 : H12AffineEnvironment.transform 9 53 env14313 = env14314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14313 == env14314) = true)

def env14315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21479440,18973701,2118976,442385,16876544,23160136,256,18990133,18949400,16819039]

theorem envBound14315 : H12AffineFastState.Bounded env14315 := by
  intro p hp
  have h : env14315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14280_14315 : H12AffineEnvironment.transform 6 9 env14280 = env14315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14280 == env14315) = true)

theorem identity14315 : scanCanonicalize (H12AffineFastState.compose env14315 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound14315 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8193,64,4677966,2172251,2118976,442385,75102,6407190,256,2188651,2196550,513]

theorem envBound14316 : H12AffineFastState.Bounded env14316 := by
  intro p hp
  have h : env14316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14315_14316 : H12AffineEnvironment.transform 23 41310 env14315 = env14316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env14315 == env14316) = true)

def env14317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8193,64,4677966,115015,45404,442385,75102,4268042,256,98679,90202,513]

theorem envBound14317 : H12AffineFastState.Bounded env14317 := by
  intro p hp
  have h : env14317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14316_14317 : H12AffineEnvironment.transform 20 58396 env14316 = env14317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env14316 == env14317) = true)

def env14318 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8193,16,4677918,114967,45324,442385,75022,4268042,256,98599,90122,513]

theorem envBound14318 : H12AffineFastState.Bounded env14318 := by
  intro p hp
  have h : env14318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14317_14318 : H12AffineEnvironment.transform 5 16 env14317 = env14318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14317 == env14318) = true)

def env14319 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8193,16,4409654,114967,45324,190521,75022,4268042,256,98599,90122,513]

theorem envBound14319 : H12AffineFastState.Bounded env14319 := by
  intro p hp
  have h : env14319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14318_14319 : H12AffineEnvironment.transform 17 10280 env14318 = env14319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14318 == env14319) = true)

theorem identity14319 : scanCanonicalize (H12AffineFastState.compose env14319 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118034) := by decide +kernel

theorem selectedBound14319 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env14320 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,118034,16,41230,8193,16,164900,114967,45324,190521,75022,60696,256,98599,90122,513]

theorem envBound14320 : H12AffineFastState.Bounded env14320 := by
  intro p hp
  have h : env14320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14319_14320 : H12AffineEnvironment.transform 21 118034 env14319 = env14320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118034 env14319 == env14320) = true)

theorem identity14320 : scanCanonicalize (H12AffineFastState.compose env14320 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14320 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env14321 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,118034,16,41230,8193,16,123967,114967,45324,100386,75022,60696,256,98599,90122,513]

theorem envBound14321 : H12AffineFastState.Bounded env14321 := by
  intro p hp
  have h : env14321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14320_14321 : H12AffineEnvironment.transform 16 90139 env14320 = env14321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14320 == env14321) = true)

theorem identity14321 : scanCanonicalize (H12AffineFastState.compose env14321 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11293) := by decide +kernel

theorem selectedBound14321 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env14322 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11293,65536,90139,10280,1024,11292,18433,90383,16,3347,8193,16,84002,93450,7441,74815,75022,16645,256,77114,90122,513]

theorem envBound14322 : H12AffineFastState.Bounded env14322 := by
  intro p hp
  have h : env14322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14321_14322 : H12AffineEnvironment.transform 14 11293 env14321 = env14322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11293 env14321 == env14322) = true)

theorem identity14322 : scanCanonicalize (H12AffineFastState.compose env14322 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14322 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14323 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11293,8203,16400,10280,1024,11292,18433,16644,16,3347,8193,16,26665,19713,7441,1076,1285,16645,256,3377,16385,513]

theorem envBound14323 : H12AffineFastState.Bounded env14323 := by
  intro p hp
  have h : env14323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14322_14323 : H12AffineEnvironment.transform 15 8203 env14322 = env14323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14322 == env14323) = true)

end H12CloudChart1