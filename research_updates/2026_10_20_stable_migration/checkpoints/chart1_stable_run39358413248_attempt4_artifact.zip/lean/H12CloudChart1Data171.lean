import H12CloudChart1Data170

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env43352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,1297,1095,5392,3172,1025,1296,4160,1328,1280,1299,1100,64,2049,4096,5392,3172,1365,32,257,33,5456,513]

theorem envBound43352 : H12AffineFastState.Bounded env43352 := by
  intro p hp
  have h : env43352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43351_43352 : H12AffineEnvironment.transform 14 1297 env43351 = env43352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env43351 == env43352) = true)

theorem identity43352 : scanCanonicalize (H12AffineFastState.compose env43352 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound43352 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env43353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,1100,2420,1297,1095,2405,3172,1025,1296,3125,1328,1280,1299,1100,64,2049,3189,2405,3172,1365,32,257,33,2341,513]

theorem envBound43353 : H12AffineFastState.Bounded env43353 := by
  intro p hp
  have h : env43353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43352_43353 : H12AffineEnvironment.transform 11 3189 env43352 = env43353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env43352 == env43353) = true)

theorem identity43353 : scanCanonicalize (H12AffineFastState.compose env43353 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 868) := by decide +kernel

theorem selectedBound43353 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env43354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,868,1809,1100,528,1297,1095,513,1792,1025,1296,1873,1328,1280,1299,1100,64,869,1809,513,1792,1365,32,257,33,577,513]

theorem envBound43354 : H12AffineFastState.Bounded env43354 := by
  intro p hp
  have h : env43354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43353_43354 : H12AffineEnvironment.transform 10 868 env43353 = env43354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 868 env43353 == env43354) = true)

theorem identity43354 : scanCanonicalize (H12AffineFastState.compose env43354 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound43354 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43355 : List Nat := [2,4,8,16,32,64,8,256,512,827,868,42,887,528,554,892,513,59,826,555,106,523,571,552,887,64,869,42,513,59,622,32,257,33,577,513]

theorem envBound43355 : H12AffineFastState.Bounded env43355 := by
  intro p hp
  have h : env43355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43354_43355 : H12AffineEnvironment.transform 9 827 env43354 = env43355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env43354 == env43355) = true)

theorem identity43355 : scanCanonicalize (H12AffineFastState.compose env43355 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43355 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env43356 : List Nat := [2,4,8,16,32,64,8,37,512,542,577,42,594,528,554,601,513,59,543,555,106,523,571,552,594,64,576,42,513,59,622,32,36,33,577,513]

theorem envBound43356 : H12AffineFastState.Bounded env43356 := by
  intro p hp
  have h : env43356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43355_43356 : H12AffineEnvironment.transform 7 37 env43355 = env43356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43355 == env43356) = true)

def env43357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,326921,8525,32770,8193,64,64605,13389,25692,303452,1364,272392,257,21792,46092,513]

theorem envBound43357 : H12AffineFastState.Bounded env43357 := by
  intro p hp
  have h : env43357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43347_43357 : H12AffineEnvironment.transform 6 9 env43347 = env43357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43347 == env43357) = true)

def env43358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,253976,8328,64,64604,160980,140484,303572,1500,272393,257,21792,46213,74251]

theorem envBound43358 : H12AffineFastState.Bounded env43358 := by
  intro p hp
  have h : env43358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43330_43358 : H12AffineEnvironment.transform 20 4161 env43330 = env43358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43330 == env43358) = true)

theorem identity43358 : scanCanonicalize (H12AffineFastState.compose env43358 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound43358 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,4161,329867,120014,21762,8328,64,64604,115150,102878,303572,1500,272393,257,21792,46213,74251]

theorem envBound43359 : H12AffineFastState.Bounded env43359 := by
  intro p hp
  have h : env43359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43358_43359 : H12AffineEnvironment.transform 16 111898 env43358 = env43359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env43358 == env43359) = true)

def env43360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10400,1025,32769,4161,73771,120014,21762,8328,64,64604,115150,102878,35188,1500,169,257,21792,46213,74251]

theorem envBound43360 : H12AffineFastState.Bounded env43360 := by
  intro p hp
  have h : env43360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43359_43360 : H12AffineEnvironment.transform 17 10400 env43359 = env43360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env43359 == env43360) = true)

def env43361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4161,73771,119878,21762,8192,64,64604,115014,102742,35188,1364,33,257,21792,46093,74251]

theorem envBound43361 : H12AffineFastState.Bounded env43361 := by
  intro p hp
  have h : env43361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43360_43361 : H12AffineEnvironment.transform 6 8 env43360 = env43361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43360 == env43361) = true)

theorem identity43361 : scanCanonicalize (H12AffineFastState.compose env43361 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43361 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,70726,10280,1025,8541,4161,73771,95514,21762,8192,64,23808,90138,77834,10280,1364,33,257,21792,5457,74251]

theorem envBound43362 : H12AffineFastState.Bounded env43362 := by
  intro p hp
  have h : env43362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43361_43362 : H12AffineEnvironment.transform 14 8540 env43361 = env43362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43361 == env43362) = true)

theorem identity43362 : scanCanonicalize (H12AffineFastState.compose env43362 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43362 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,70726,10280,1025,8541,4161,73771,73755,3,8192,64,2049,79131,77834,10280,1364,33,257,33,5457,74251]

theorem envBound43363 : H12AffineFastState.Bounded env43363 := by
  intro p hp
  have h : env43363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43362_43363 : H12AffineEnvironment.transform 13 5377 env43362 = env43363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43362 == env43363) = true)

theorem identity43363 : scanCanonicalize (H12AffineFastState.compose env43363 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound43363 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43364 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4452,8540,65536,69667,10280,100,8541,4161,73771,73755,3,8192,64,2049,78206,77834,10280,305,33,257,33,4404,74251]

theorem envBound43364 : H12AffineFastState.Bounded env43364 := by
  intro p hp
  have h : env43364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43363_43364 : H12AffineEnvironment.transform 9 101 env43363 = env43364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env43363 == env43364) = true)

theorem identity43364 : scanCanonicalize (H12AffineFastState.compose env43364 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound43364 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env43365 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4452,8540,8283,12408,10280,100,8541,4161,112,64,3,8192,64,2049,4389,4177,10280,305,33,257,33,4404,592]

theorem envBound43365 : H12AffineFastState.Bounded env43365 := by
  intro p hp
  have h : env43365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43364_43365 : H12AffineEnvironment.transform 15 8283 env43364 = env43365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env43364 == env43365) = true)

theorem identity43365 : scanCanonicalize (H12AffineFastState.compose env43365 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43365 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43366 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,348,4452,0,263,4388,2420,100,1,4161,112,64,3,348,64,2049,4389,4177,2420,305,33,257,33,4404,592]

theorem envBound43366 : H12AffineFastState.Bounded env43366 := by
  intro p hp
  have h : env43366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43365_43366 : H12AffineEnvironment.transform 12 348 env43365 = env43366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43365 == env43366) = true)

theorem identity43366 : scanCanonicalize (H12AffineFastState.compose env43366 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound43366 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43367 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2404,348,2048,0,263,2112,2420,100,1,2341,112,64,3,348,64,2049,2113,2357,2420,305,33,257,33,2128,592]

theorem envBound43367 : H12AffineFastState.Bounded env43367 := by
  intro p hp
  have h : env43367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43366_43367 : H12AffineEnvironment.transform 11 2404 env43366 = env43367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env43366 == env43367) = true)

theorem identity43367 : scanCanonicalize (H12AffineFastState.compose env43367 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound43367 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env43368 : List Nat := [2,4,8,16,32,64,8,256,512,101,261,97,348,261,0,263,325,113,100,1,32,112,64,3,348,64,260,324,48,113,305,33,257,33,341,592]

theorem envBound43368 : H12AffineFastState.Bounded env43368 := by
  intro p hp
  have h : env43368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43367_43368 : H12AffineEnvironment.transform 10 261 env43367 = env43368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env43367 == env43368) = true)

theorem identity43368 : scanCanonicalize (H12AffineFastState.compose env43368 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43368 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43369 : List Nat := [2,4,8,16,0,64,8,256,512,69,261,65,348,261,0,263,325,81,68,1,0,80,64,3,348,64,260,324,16,81,273,1,257,1,341,592]

theorem envBound43369 : H12AffineFastState.Bounded env43369 := by
  intro p hp
  have h : env43369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43368_43369 : H12AffineEnvironment.transform 4 0 env43368 = env43369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43368 == env43369) = true)

theorem identity43369 : scanCanonicalize (H12AffineFastState.compose env43369 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43369 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43370 : List Nat := [2,4,8,16,0,17,8,256,512,20,261,16,269,261,0,263,276,0,21,1,0,1,17,3,269,17,260,277,16,0,273,1,257,1,260,513]

theorem envBound43370 : H12AffineFastState.Bounded env43370 := by
  intro p hp
  have h : env43370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43369_43370 : H12AffineEnvironment.transform 5 17 env43369 = env43370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43369 == env43370) = true)

theorem identity43370 : scanCanonicalize (H12AffineFastState.compose env43370 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound43370 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43371 : List Nat := [2,4,8,16,0,17,8,256,271,20,261,16,269,261,0,263,276,0,21,1,0,1,17,3,269,17,260,277,16,0,273,1,257,1,260,270]

theorem envBound43371 : H12AffineFastState.Bounded env43371 := by
  intro p hp
  have h : env43371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43370_43371 : H12AffineEnvironment.transform 8 271 env43370 = env43371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env43370 == env43371) = true)

def env43372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4161,73771,119879,21762,8193,64,64604,115015,102743,35188,1365,32,257,21792,46092,74251]

theorem envBound43372 : H12AffineFastState.Bounded env43372 := by
  intro p hp
  have h : env43372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43360_43372 : H12AffineEnvironment.transform 6 9 env43360 = env43372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43360 == env43372) = true)

theorem identity43372 : scanCanonicalize (H12AffineFastState.compose env43372 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound43372 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,16401,10281,1025,32769,4161,54560,8524,21762,8193,64,64604,13388,25692,35188,1365,32,257,21792,46092,55040]

theorem envBound43373 : H12AffineFastState.Bounded env43373 := by
  intro p hp
  have h : env43373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43372_43373 : H12AffineEnvironment.transform 15 62731 env43372 = env43373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env43372 == env43373) = true)

theorem identity43373 : scanCanonicalize (H12AffineFastState.compose env43373 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound43373 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,16401,10281,1025,21760,4161,33,8524,21762,8193,64,10589,13388,25692,23669,1365,32,257,21792,24845,513]

theorem envBound43374 : H12AffineFastState.Bounded env43374 := by
  intro p hp
  have h : env43374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43373_43374 : H12AffineEnvironment.transform 14 21761 env43373 = env43374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env43373 == env43374) = true)

theorem identity43374 : scanCanonicalize (H12AffineFastState.compose env43374 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43374 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,16401,2421,1025,21760,4161,33,16,21762,349,64,2049,5392,17664,23669,1365,32,257,21792,16465,513]

theorem envBound43375 : H12AffineFastState.Bounded env43375 := by
  intro p hp
  have h : env43375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43374_43375 : H12AffineEnvironment.transform 12 348 env43374 = env43375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43374 == env43375) = true)

def env43376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10401,1025,32769,4161,73770,120014,21762,8328,64,64604,115150,102878,35189,1500,168,257,21792,46213,74251]

theorem envBound43376 : H12AffineFastState.Bounded env43376 := by
  intro p hp
  have h : env43376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43359_43376 : H12AffineEnvironment.transform 17 10401 env43359 = env43376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env43359 == env43376) = true)

def env43377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4161,73770,119878,21762,8192,64,64604,115014,102742,35189,1364,32,257,21792,46093,74251]

theorem envBound43377 : H12AffineFastState.Bounded env43377 := by
  intro p hp
  have h : env43377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43376_43377 : H12AffineEnvironment.transform 6 8 env43376 = env43377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43376 == env43377) = true)

theorem identity43377 : scanCanonicalize (H12AffineFastState.compose env43377 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound43377 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49168,10281,1025,32769,4161,21792,41292,21762,8192,64,64604,46156,58460,35189,1364,32,257,21792,46093,22273]

theorem envBound43378 : H12AffineFastState.Bounded env43378 := by
  intro p hp
  have h : env43378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43377_43378 : H12AffineEnvironment.transform 15 29962 env43377 = env43378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env43377 == env43378) = true)

theorem identity43378 : scanCanonicalize (H12AffineFastState.compose env43378 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound43378 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,29962,13625,10281,1025,29992,4161,21792,21605,21762,8192,64,2421,16741,4469,31836,1364,32,257,21792,16676,22273]

theorem envBound43379 : H12AffineFastState.Bounded env43379 := by
  intro p hp
  have h : env43379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43378_43379 : H12AffineEnvironment.transform 14 29993 env43378 = env43379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env43378 == env43379) = true)

theorem identity43379 : scanCanonicalize (H12AffineFastState.compose env43379 (packedSelected [0,4,6,7,9,12,15,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43379 : packedSelected [0,4,6,7,9,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env43380 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29993,29962,13625,10281,1025,29992,4113,21792,21557,21762,8192,16,2341,16693,4389,31756,1284,32,257,21792,16676,22273]

theorem envBound43380 : H12AffineFastState.Bounded env43380 := by
  intro p hp
  have h : env43380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43379_43380 : H12AffineEnvironment.transform 5 16 env43379 = env43380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43379 == env43380) = true)

theorem identity43380 : scanCanonicalize (H12AffineFastState.compose env43380 (packedSelected [1,3,5,6,8,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound43380 : packedSelected [1,3,5,6,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43381 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,8192,16384,26892,26927,10524,10281,1025,26893,3124,18693,18448,18727,8192,16,2341,16693,3328,24617,1284,32,257,18693,16676,19236]

theorem envBound43381 : H12AffineFastState.Bounded env43381 := by
  intro p hp
  have h : env43381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43380_43381 : H12AffineEnvironment.transform 11 3109 env43380 = env43381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env43380 == env43381) = true)

def env43382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4161,73770,119879,21762,8193,64,64604,115015,102743,35189,1365,33,257,21792,46092,74251]

theorem envBound43382 : H12AffineFastState.Bounded env43382 := by
  intro p hp
  have h : env43382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43376_43382 : H12AffineEnvironment.transform 6 9 env43376 = env43382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43376 == env43382) = true)

theorem identity43382 : scanCanonicalize (H12AffineFastState.compose env43382 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound43382 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,10280,1025,32769,4161,62589,16,21762,8193,64,64604,5392,17664,35189,1365,33,257,21792,46092,63068]

theorem envBound43383 : H12AffineFastState.Bounded env43383 := by
  intro p hp
  have h : env43383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43382_43383 : H12AffineEnvironment.transform 15 54359 env43382 = env43383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env43382 == env43383) = true)

theorem identity43383 : scanCanonicalize (H12AffineFastState.compose env43383 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound43383 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1296,20807,24909,10280,1025,1297,4161,29037,16,21762,8193,64,31052,5392,17664,3173,1365,33,257,21792,12572,29516]

theorem envBound43384 : H12AffineFastState.Bounded env43384 := by
  intro p hp
  have h : env43384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43383_43384 : H12AffineEnvironment.transform 14 1296 env43383 = env43384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env43383 == env43384) = true)

theorem identity43384 : scanCanonicalize (H12AffineFastState.compose env43384 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43384 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1296,20807,16400,2421,1025,1297,4161,20528,16,21762,348,64,22545,5392,17664,3173,1365,33,257,21792,4161,21009]

theorem envBound43385 : H12AffineFastState.Bounded env43385 := by
  intro p hp
  have h : env43385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43384_43385 : H12AffineEnvironment.transform 12 349 env43384 = env43385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43384 == env43385) = true)

theorem identity43385 : scanCanonicalize (H12AffineFastState.compose env43385 (packedSelected [1,8,11,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43385 : packedSelected [1,8,11,18,19] rootPS < 2^1333 := by decide +kernel

def env43386 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,16384,1077,20578,16400,2128,1025,1076,4161,20528,16,21543,121,64,22545,5173,17445,3173,1136,33,36,21509,4161,21009]

theorem envBound43386 : H12AffineFastState.Bounded env43386 := by
  intro p hp
  have h : env43386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43385_43386 : H12AffineEnvironment.transform 7 37 env43385 = env43386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43385 == env43386) = true)

def env43387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound43387 : H12AffineFastState.Bounded env43387 := by
  intro p hp
  have h : env43387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42971_43387 : H12AffineEnvironment.transform 26 30393345 env42971 = env43387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env42971 == env43387) = true)

def env43388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound43388 : H12AffineFastState.Bounded env43388 := by
  intro p hp
  have h : env43388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43387_43388 : H12AffineEnvironment.transform 18 1024 env43387 = env43388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env43387 == env43388) = true)

theorem identity43388 : scanCanonicalize (H12AffineFastState.compose env43388 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577240) := by decide +kernel

theorem selectedBound43388 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577240,8328,64,6727001,8446420,10507601,8830976,2154824,12583064,256,41461,16464,2213534]

theorem envBound43389 : H12AffineFastState.Bounded env43389 := by
  intro p hp
  have h : env43389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43388_43389 : H12AffineEnvironment.transform 23 10577240 env43388 = env43389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577240 env43388 == env43389) = true)

def env43390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,4194304,8388608,10577240,8328,64,6705549,8393984,10507601,8795348,2102684,12583064,256,21793,16464,2175562]

theorem envBound43390 : H12AffineFastState.Bounded env43390 := by
  intro p hp
  have h : env43390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43389_43390 : H12AffineEnvironment.transform 14 29908 env43389 = env43390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env43389 == env43390) = true)

def env43391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272512,8388608,10577240,8328,64,2259213,8393984,10507601,8795348,2102684,8661016,256,21793,16464,2175562]

theorem envBound43391 : H12AffineFastState.Bounded env43391 := by
  intro p hp
  have h : env43391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43390_43391 : H12AffineEnvironment.transform 21 272512 env43390 = env43391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env43390 == env43391) = true)

theorem identity43391 : scanCanonicalize (H12AffineFastState.compose env43391 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound43391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,77899,272512,8388608,8410387,8328,64,215366,8393984,8480026,8795348,75223,8661016,256,21793,16464,513]

theorem envBound43392 : H12AffineFastState.Bounded env43392 := by
  intro p hp
  have h : env43392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43391_43392 : H12AffineEnvironment.transform 20 77899 env43391 = env43392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env43391 == env43392) = true)

def env43393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77899,272392,8388608,8410387,8192,64,215366,8393984,8480026,8795228,75103,8661016,256,21793,16464,513]

theorem envBound43393 : H12AffineFastState.Bounded env43393 := by
  intro p hp
  have h : env43393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43392_43393 : H12AffineEnvironment.transform 6 8 env43392 = env43393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43392 == env43393) = true)

theorem identity43393 : scanCanonicalize (H12AffineFastState.compose env43393 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound43393 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,77899,272392,8388608,8410387,8192,64,10588,8393984,8480026,8737862,75103,8661016,256,21793,16464,513]

theorem envBound43394 : H12AffineFastState.Bounded env43394 := by
  intro p hp
  have h : env43394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43393_43394 : H12AffineEnvironment.transform 16 90138 env43393 = env43394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env43393 == env43394) = true)

def env43395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,77899,272392,16,21763,8192,64,10588,5392,91402,349270,75103,272392,256,21793,16464,513]

theorem envBound43395 : H12AffineFastState.Bounded env43395 := by
  intro p hp
  have h : env43395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43394_43395 : H12AffineEnvironment.transform 22 16 env43394 = env43395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env43394 == env43395) = true)

theorem identity43395 : scanCanonicalize (H12AffineFastState.compose env43395 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,262144,1024,8540,77899,272392,16,2,8192,64,10588,5392,77835,328023,75103,272392,256,32,5457,513]

theorem envBound43396 : H12AffineFastState.Bounded env43396 := by
  intro p hp
  have h : env43396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43395_43396 : H12AffineEnvironment.transform 13 5377 env43395 = env43396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43395 == env43396) = true)

theorem identity43396 : scanCanonicalize (H12AffineFastState.compose env43396 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound43396 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9499,4096,262144,1024,8540,5456,272392,16,2,8192,64,10588,5392,5392,271436,68,272392,256,32,5457,513]

theorem envBound43397 : H12AffineFastState.Bounded env43397 := by
  intro p hp
  have h : env43397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43396_43397 : H12AffineEnvironment.transform 15 9499 env43396 = env43397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env43396 == env43397) = true)

theorem identity43397 : scanCanonicalize (H12AffineFastState.compose env43397 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 11577) := by decide +kernel

theorem selectedBound43397 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env43398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9499,4096,11577,1024,8540,5456,1329,16,2,8192,64,10588,5392,5392,2421,68,1329,256,32,5457,513]

theorem envBound43398 : H12AffineFastState.Bounded env43398 := by
  intro p hp
  have h : env43398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43397_43398 : H12AffineEnvironment.transform 17 11577 env43397 = env43398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11577 env43397 == env43398) = true)

theorem identity43398 : scanCanonicalize (H12AffineFastState.compose env43398 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound43398 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env43399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5377,1124,34,4096,2048,1024,1125,5456,1329,16,2,1337,64,3173,5392,5392,2421,68,1329,256,32,5457,513]

theorem envBound43399 : H12AffineFastState.Bounded env43399 := by
  intro p hp
  have h : env43399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43398_43399 : H12AffineEnvironment.transform 12 1337 env43398 = env43399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env43398 == env43399) = true)

theorem identity43399 : scanCanonicalize (H12AffineFastState.compose env43399 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound43399 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env43400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,1337,5377,1124,34,4096,1296,1024,1125,5456,1329,16,2,1337,64,373,5392,5392,1125,68,1329,256,32,5457,513]

theorem envBound43400 : H12AffineFastState.Bounded env43400 := by
  intro p hp
  have h : env43400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43399_43400 : H12AffineEnvironment.transform 10 1296 env43399 = env43400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env43399 == env43400) = true)

theorem identity43400 : scanCanonicalize (H12AffineFastState.compose env43400 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound43400 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env43401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1140,1337,373,1124,34,1140,1296,1024,1125,292,1329,16,2,1337,64,373,356,356,1125,68,1329,256,32,293,513]

theorem envBound43401 : H12AffineFastState.Bounded env43401 := by
  intro p hp
  have h : env43401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43400_43401 : H12AffineEnvironment.transform 11 1140 env43400 = env43401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env43400 == env43401) = true)

theorem identity43401 : scanCanonicalize (H12AffineFastState.compose env43401 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound43401 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env43402 : List Nat := [2,4,8,16,32,64,8,256,293,1024,1296,1140,1337,373,1124,34,1140,1296,1024,1125,292,1329,16,2,1337,64,373,356,356,1125,68,1329,256,32,293,292]

theorem envBound43402 : H12AffineFastState.Bounded env43402 := by
  intro p hp
  have h : env43402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43401_43402 : H12AffineEnvironment.transform 8 293 env43401 = env43402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env43401 == env43402) = true)

theorem identity43402 : scanCanonicalize (H12AffineFastState.compose env43402 (packedSelected [0,1,5] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43402 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env43403 : List Nat := [2,4,8,16,32,64,8,68,97,1024,1108,1140,1149,49,1124,34,1140,1108,1024,1125,96,1141,16,2,1149,64,49,32,32,1125,68,1141,68,32,97,96]

theorem envBound43403 : H12AffineFastState.Bounded env43403 := by
  intro p hp
  have h : env43403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43402_43403 : H12AffineEnvironment.transform 7 68 env43402 = env43403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43402 == env43403) = true)

theorem identity43403 : scanCanonicalize (H12AffineFastState.compose env43403 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound43403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43404 : List Nat := [2,4,8,16,32,64,8,68,97,117,33,1,8,49,17,34,1,33,117,16,96,0,16,2,8,64,49,32,32,16,68,0,68,32,97,96]

theorem envBound43404 : H12AffineFastState.Bounded env43404 := by
  intro p hp
  have h : env43404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43403_43404 : H12AffineEnvironment.transform 9 117 env43403 = env43404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env43403 == env43404) = true)

theorem identity43404 : scanCanonicalize (H12AffineFastState.compose env43404 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43405 : List Nat := [2,4,8,1,32,64,8,68,97,100,33,1,8,32,0,34,1,33,100,1,96,0,1,2,8,64,32,32,32,1,68,0,68,32,97,96]

theorem envBound43405 : H12AffineFastState.Bounded env43405 := by
  intro p hp
  have h : env43405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43404_43405 : H12AffineEnvironment.transform 3 1 env43404 = env43405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43404 == env43405) = true)

theorem identity43405 : scanCanonicalize (H12AffineFastState.compose env43405 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound43405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43406 : List Nat := [2,4,8,1,32,33,8,37,0,5,33,1,8,32,0,34,1,33,5,1,1,0,1,2,8,33,32,32,32,1,37,0,37,32,0,1]

theorem envBound43406 : H12AffineFastState.Bounded env43406 := by
  intro p hp
  have h : env43406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43405_43406 : H12AffineEnvironment.transform 5 33 env43405 = env43406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env43405 == env43406) = true)

def env43407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,77899,272392,17,21762,8192,64,10588,5393,91403,349271,75103,272393,256,21793,16464,513]

theorem envBound43407 : H12AffineFastState.Bounded env43407 := by
  intro p hp
  have h : env43407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43394_43407 : H12AffineEnvironment.transform 22 17 env43394 = env43407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43394 == env43407) = true)

theorem identity43407 : scanCanonicalize (H12AffineFastState.compose env43407 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound43407 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,32041,1024,29789,77899,21793,17,21762,8192,64,10588,5393,91403,76158,75103,21792,256,21793,16464,513]

theorem envBound43408 : H12AffineFastState.Bounded env43408 := by
  intro p hp
  have h : env43408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43407_43408 : H12AffineEnvironment.transform 17 32041 env43407 = env43408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env43407 == env43408) = true)

theorem identity43408 : scanCanonicalize (H12AffineFastState.compose env43408 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43408 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43409 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,29005,65536,90138,30776,273,29004,77899,20528,17,20499,8192,64,10588,4096,90138,76158,73806,20529,256,20528,16464,513]

theorem envBound43409 : H12AffineFastState.Bounded env43409 := by
  intro p hp
  have h : env43409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43408_43409 : H12AffineEnvironment.transform 9 273 env43408 = env43409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43408 == env43409) = true)

theorem identity43409 : scanCanonicalize (H12AffineFastState.compose env43409 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound43409 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env43410 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,29005,28699,4097,30776,273,29004,16464,20528,17,20499,8192,64,10588,4096,4097,22885,20565,20529,256,20528,16464,513]

theorem envBound43410 : H12AffineFastState.Bounded env43410 := by
  intro p hp
  have h : env43410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43409_43410 : H12AffineEnvironment.transform 15 28699 env43409 = env43410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env43409 == env43410) = true)

def env43411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77899,272393,8388608,8410387,8193,64,215366,8393984,8480026,8795229,75102,8661016,256,21793,16464,513]

theorem envBound43411 : H12AffineFastState.Bounded env43411 := by
  intro p hp
  have h : env43411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43392_43411 : H12AffineEnvironment.transform 6 9 env43392 = env43411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43392 == env43411) = true)

def env43412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77899,272393,16,21763,8193,64,215366,5392,91402,406605,75102,272392,256,21793,16464,513]

theorem envBound43412 : H12AffineFastState.Bounded env43412 := by
  intro p hp
  have h : env43412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43411_43412 : H12AffineEnvironment.transform 22 16 env43411 = env43412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env43411 == env43412) = true)

def env43413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,77899,272393,16,3,8193,64,203846,5392,77834,406605,75102,272392,256,33,5456,513]

theorem envBound43413 : H12AffineFastState.Bounded env43413 := by
  intro p hp
  have h : env43413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43412_43413 : H12AffineEnvironment.transform 13 5376 env43412 = env43413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43412 == env43413) = true)

theorem identity43413 : scanCanonicalize (H12AffineFastState.compose env43413 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound43413 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79130,262144,1024,8540,77899,272393,16,3,8193,64,10588,5392,77834,328023,75102,272392,256,33,5456,513]

theorem envBound43414 : H12AffineFastState.Bounded env43414 := by
  intro p hp
  have h : env43414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43413_43414 : H12AffineEnvironment.transform 16 79130 env43413 = env43414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env43413 == env43414) = true)

def env43415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,272393,16,2,8193,64,203847,5392,77835,406605,75102,272392,256,32,5457,513]

theorem envBound43415 : H12AffineFastState.Bounded env43415 := by
  intro p hp
  have h : env43415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43412_43415 : H12AffineEnvironment.transform 13 5377 env43412 = env43415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43412 == env43415) = true)

theorem identity43415 : scanCanonicalize (H12AffineFastState.compose env43415 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43415 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env43416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,131072,262144,1024,0,69910,264532,16,2,348,64,203847,5392,69974,398608,66563,264533,256,32,5457,513]

theorem envBound43416 : H12AffineFastState.Bounded env43416 := by
  intro p hp
  have h : env43416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43415_43416 : H12AffineEnvironment.transform 12 349 env43415 = env43416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43415 == env43416) = true)

theorem identity43416 : scanCanonicalize (H12AffineFastState.compose env43416 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound43416 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,131072,138341,1024,0,69910,136497,16,2,348,64,203847,5392,69974,2421,66563,136496,256,32,5457,513]

theorem envBound43417 : H12AffineFastState.Bounded env43417 := by
  intro p hp
  have h : env43417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43416_43417 : H12AffineEnvironment.transform 17 138341 env43416 = env43417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env43416 == env43417) = true)

theorem identity43417 : scanCanonicalize (H12AffineFastState.compose env43417 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound43417 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env43418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,5393,2420,1024,0,69910,32,16,2,348,64,67926,5392,69974,2421,66563,33,256,32,5457,513]

theorem envBound43418 : H12AffineFastState.Bounded env43418 := by
  intro p hp
  have h : env43418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43417_43418 : H12AffineEnvironment.transform 16 5393 env43417 = env43418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env43417 == env43418) = true)

theorem identity43418 : scanCanonicalize (H12AffineFastState.compose env43418 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound43418 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5393,2420,1024,0,4161,32,16,2,348,64,2049,5392,4097,2421,1364,33,256,32,5457,513]

theorem envBound43419 : H12AffineFastState.Bounded env43419 := by
  intro p hp
  have h : env43419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43418_43419 : H12AffineEnvironment.transform 15 343 env43418 = env43419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env43418 == env43419) = true)

theorem identity43419 : scanCanonicalize (H12AffineFastState.compose env43419 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound43419 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43420 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,349,4405,1,343,4389,2420,52,0,4161,32,16,2,348,64,2049,4388,4097,2421,352,33,256,32,4453,513]

theorem envBound43420 : H12AffineFastState.Bounded env43420 := by
  intro p hp
  have h : env43420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43419_43420 : H12AffineEnvironment.transform 9 52 env43419 = env43420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43419 == env43420) = true)

theorem identity43420 : scanCanonicalize (H12AffineFastState.compose env43420 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43420 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43421 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,1,262,4389,2341,52,0,4112,32,16,2,269,17,2049,4388,4097,2340,305,33,256,32,4404,513]

theorem envBound43421 : H12AffineFastState.Bounded env43421 := by
  intro p hp
  have h : env43421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43420_43421 : H12AffineEnvironment.transform 5 17 env43420 = env43421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43420 == env43421) = true)

theorem identity43421 : scanCanonicalize (H12AffineFastState.compose env43421 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43422 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,9,4144,1,3,4128,2080,52,0,4112,32,16,2,8,17,2049,4129,4097,2081,52,33,5,32,4145,513]

theorem envBound43422 : H12AffineFastState.Bounded env43422 := by
  intro p hp
  have h : env43422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43421_43422 : H12AffineEnvironment.transform 7 5 env43421 = env43422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43421 == env43422) = true)

theorem identity43422 : scanCanonicalize (H12AffineFastState.compose env43422 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound43422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43423 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2609,9,2561,1,3,2577,2080,52,0,2593,32,16,2,8,17,2049,2576,2608,2081,52,33,5,32,2560,513]

theorem envBound43423 : H12AffineFastState.Bounded env43423 := by
  intro p hp
  have h : env43423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43422_43423 : H12AffineEnvironment.transform 11 2609 env43422 = env43423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env43422 == env43423) = true)

theorem identity43423 : scanCanonicalize (H12AffineFastState.compose env43423 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound43423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43424 : List Nat := [2,4,8,16,32,17,9,5,512,52,545,16,9,32,1,3,48,513,52,0,0,32,16,2,8,17,544,49,17,512,52,33,5,32,33,513]

theorem envBound43424 : H12AffineFastState.Bounded env43424 := by
  intro p hp
  have h : env43424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43423_43424 : H12AffineEnvironment.transform 10 545 env43423 = env43424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env43423 == env43424) = true)

theorem identity43424 : scanCanonicalize (H12AffineFastState.compose env43424 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound43424 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43425 : List Nat := [2,4,8,16,32,17,9,5,16,52,49,16,9,32,1,3,48,17,52,0,0,32,16,2,8,17,48,49,17,16,52,33,5,32,33,17]

theorem envBound43425 : H12AffineFastState.Bounded env43425 := by
  intro p hp
  have h : env43425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43424_43425 : H12AffineEnvironment.transform 8 16 env43424 = env43425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43424 == env43425) = true)

theorem identity43425 : scanCanonicalize (H12AffineFastState.compose env43425 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43425 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43426 : List Nat := [2,4,8,16,1,17,9,5,16,21,16,16,9,1,1,3,17,17,21,0,0,1,16,2,8,17,17,16,17,16,21,0,5,1,0,17]

theorem envBound43426 : H12AffineFastState.Bounded env43426 := by
  intro p hp
  have h : env43426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43425_43426 : H12AffineEnvironment.transform 4 1 env43425 = env43426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43425 == env43426) = true)

theorem identity43426 : scanCanonicalize (H12AffineFastState.compose env43426 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43426 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43427 : List Nat := [2,4,8,10,1,11,9,5,10,15,10,10,9,1,1,3,11,11,15,0,0,1,10,2,8,11,11,10,11,10,15,0,5,1,0,11]

theorem envBound43427 : H12AffineFastState.Bounded env43427 := by
  intro p hp
  have h : env43427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43426_43427 : H12AffineEnvironment.transform 3 10 env43426 = env43427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43426 == env43427) = true)

def env43428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77899,272393,17,21762,8193,64,215366,5393,91403,406604,75102,272393,256,21793,16464,513]

theorem envBound43428 : H12AffineFastState.Bounded env43428 := by
  intro p hp
  have h : env43428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43411_43428 : H12AffineEnvironment.transform 22 17 env43411 = env43428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43411 == env43428) = true)

theorem identity43428 : scanCanonicalize (H12AffineFastState.compose env43428 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound43428 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,77899,272393,17,21762,8193,64,10588,5393,91403,349270,75102,272393,256,21793,16464,513]

theorem envBound43429 : H12AffineFastState.Bounded env43429 := by
  intro p hp
  have h : env43429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43428_43429 : H12AffineEnvironment.transform 16 90138 env43428 = env43429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env43428 == env43429) = true)

theorem identity43429 : scanCanonicalize (H12AffineFastState.compose env43429 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43429 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10281,1024,29788,77899,32,17,21762,8193,64,10588,5393,91403,97407,75102,32,256,21793,16464,513]

theorem envBound43430 : H12AffineFastState.Bounded env43430 := by
  intro p hp
  have h : env43430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43429_43430 : H12AffineEnvironment.transform 17 10281 env43429 = env43430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43429 == env43430) = true)

theorem identity43430 : scanCanonicalize (H12AffineFastState.compose env43430 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound43430 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,5393,10281,1024,29788,17728,32,17,21762,8193,64,10588,5393,4096,2420,20565,32,256,21793,16464,513]

theorem envBound43431 : H12AffineFastState.Bounded env43431 := by
  intro p hp
  have h : env43431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43430_43431 : H12AffineEnvironment.transform 15 29963 env43430 = env43431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env43430 == env43431) = true)

theorem identity43431 : scanCanonicalize (H12AffineFastState.compose env43431 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43431 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43432 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,29963,5393,10281,1024,29709,17681,32,17,21762,8193,17,10509,5393,4096,2341,20484,32,256,21793,16385,513]

theorem envBound43432 : H12AffineFastState.Bounded env43432 := by
  intro p hp
  have h : env43432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43431_43432 : H12AffineEnvironment.transform 5 17 env43431 = env43432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43431 == env43432) = true)

theorem identity43432 : scanCanonicalize (H12AffineFastState.compose env43432 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43432 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env43433 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,5393,10281,1024,8461,4113,32,17,2,8193,17,10509,5393,4096,2341,1284,32,256,33,5377,513]

theorem envBound43433 : H12AffineFastState.Bounded env43433 := by
  intro p hp
  have h : env43433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43432_43433 : H12AffineEnvironment.transform 13 5376 env43432 = env43433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43432 == env43433) = true)

theorem identity43433 : scanCanonicalize (H12AffineFastState.compose env43433 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound43433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43434 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,4153,5376,4405,4146,5393,6160,1024,4404,4113,32,17,2,4152,17,6452,5393,4096,2341,1284,32,256,33,5377,513]

theorem envBound43434 : H12AffineFastState.Bounded env43434 := by
  intro p hp
  have h : env43434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43433_43434 : H12AffineEnvironment.transform 12 4153 env43433 = env43434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env43433 == env43434) = true)

theorem identity43434 : scanCanonicalize (H12AffineFastState.compose env43434 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound43434 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43435 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,268,1077,0,263,1060,2341,1024,1,292,32,17,2,269,17,2049,1060,309,2341,1284,32,256,33,1076,513]

theorem envBound43435 : H12AffineFastState.Bounded env43435 := by
  intro p hp
  have h : env43435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43434_43435 : H12AffineEnvironment.transform 11 309 env43434 = env43435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env43434 == env43435) = true)

theorem identity43435 : scanCanonicalize (H12AffineFastState.compose env43435 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43435 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43436 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,309,268,292,0,263,309,2341,273,1,292,32,17,2,269,17,2049,309,309,2341,21,32,256,33,293,513]

theorem envBound43436 : H12AffineFastState.Bounded env43436 := by
  intro p hp
  have h : env43436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43435_43436 : H12AffineEnvironment.transform 9 273 env43435 = env43436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43435 == env43436) = true)

theorem identity43436 : scanCanonicalize (H12AffineFastState.compose env43436 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43436 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43437 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,41,1,0,34,16,2048,52,1,1,32,17,2,40,17,2049,16,16,2048,21,32,37,33,0,513]

theorem envBound43437 : H12AffineFastState.Bounded env43437 := by
  intro p hp
  have h : env43437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43436_43437 : H12AffineEnvironment.transform 7 37 env43436 = env43437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43436 == env43437) = true)

theorem identity43437 : scanCanonicalize (H12AffineFastState.compose env43437 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43438 : List Nat := [2,4,8,16,32,17,9,37,512,52,0,16,41,1,0,34,16,0,52,1,1,32,17,2,40,17,1,16,16,0,21,32,37,33,0,513]

theorem envBound43438 : H12AffineFastState.Bounded env43438 := by
  intro p hp
  have h : env43438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43437_43438 : H12AffineEnvironment.transform 10 0 env43437 = env43438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43437 == env43438) = true)

theorem identity43438 : scanCanonicalize (H12AffineFastState.compose env43438 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43439 : List Nat := [2,4,2,16,32,17,3,37,512,52,0,16,35,1,0,34,16,0,52,1,1,32,17,2,34,17,1,16,16,0,21,32,37,33,0,513]

theorem envBound43439 : H12AffineFastState.Bounded env43439 := by
  intro p hp
  have h : env43439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43438_43439 : H12AffineEnvironment.transform 2 2 env43438 = env43439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43438 == env43439) = true)

def env43440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,8388608,10577240,8328,64,2259212,8393984,10507601,8795348,2102684,8661017,256,21793,16464,2175562]

theorem envBound43440 : H12AffineFastState.Bounded env43440 := by
  intro p hp
  have h : env43440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43390_43440 : H12AffineEnvironment.transform 21 272513 env43390 = env43440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env43390 == env43440) = true)

theorem identity43440 : scanCanonicalize (H12AffineFastState.compose env43440 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 2175067) := by decide +kernel

theorem selectedBound43440 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,2175067,21763,8328,64,2259212,2172251,91402,2557071,2102684,2431042,256,21793,16464,2175562]

theorem envBound43441 : H12AffineFastState.Bounded env43441 := by
  intro p hp
  have h : env43441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43440_43441 : H12AffineEnvironment.transform 22 2175067 env43440 = env43441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175067 env43440 == env43441) = true)

def env43442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,2097152,33,2175067,21763,8328,64,2259212,2172251,91402,2305071,2102684,2175202,256,21793,16464,2175562]

theorem envBound43442 : H12AffineFastState.Bounded env43442 := by
  intro p hp
  have h : env43442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43441_43442 : H12AffineEnvironment.transform 17 10400 env43441 = env43442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env43441 == env43442) = true)

def env43443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,2097152,33,2175067,3,8328,64,2239500,2172251,77834,2305071,2102684,2175202,256,33,5456,2175562]

theorem envBound43443 : H12AffineFastState.Bounded env43443 := by
  intro p hp
  have h : env43443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43442_43443 : H12AffineEnvironment.transform 13 5376 env43442 = env43443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43442 == env43443) = true)

theorem identity43443 : scanCanonicalize (H12AffineFastState.compose env43443 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43443 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,2097152,33,2175067,3,8193,64,2239500,2172251,77834,2305071,2102549,2175083,256,33,5456,2175562]

theorem envBound43444 : H12AffineFastState.Bounded env43444 := by
  intro p hp
  have h : env43444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43443_43444 : H12AffineEnvironment.transform 6 9 env43443 = env43444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43443 == env43444) = true)

theorem identity43444 : scanCanonicalize (H12AffineFastState.compose env43444 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 12620) := by decide +kernel

theorem selectedBound43444 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,12620,33,65815,3,8193,64,138560,70679,77834,204131,9305,65831,256,33,5456,66310]

theorem envBound43445 : H12AffineFastState.Bounded env43445 := by
  intro p hp
  have h : env43445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43444_43445 : H12AffineEnvironment.transform 20 12620 env43444 = env43445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12620 env43444 == env43445) = true)

theorem identity43445 : scanCanonicalize (H12AffineFastState.compose env43445 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound43445 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env43446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13389,10281,1024,8540,12620,33,65815,3,8193,64,10509,70679,77834,76078,9305,65831,256,33,5456,66310]

theorem envBound43446 : H12AffineFastState.Bounded env43446 := by
  intro p hp
  have h : env43446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43445_43446 : H12AffineEnvironment.transform 16 13389 env43445 = env43446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env43445 == env43446) = true)

theorem identity43446 : scanCanonicalize (H12AffineFastState.compose env43446 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43446 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env43447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13389,10281,1024,8540,12620,33,8477,3,8193,64,10509,13341,4096,2340,9305,8493,256,33,5456,8972]

theorem envBound43447 : H12AffineFastState.Bounded env43447 := by
  intro p hp
  have h : env43447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43446_43447 : H12AffineEnvironment.transform 15 8202 env43446 = env43447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43446 == env43447) = true)

theorem identity43447 : scanCanonicalize (H12AffineFastState.compose env43447 (packedSelected [0,3,4,5,6,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43447 : packedSelected [0,3,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env43448 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5156,8313,8202,13389,10281,1024,8312,12392,33,8249,3,8193,64,10281,13341,4096,2048,9305,8201,36,33,5236,8744]

theorem envBound43448 : H12AffineFastState.Bounded env43448 := by
  intro p hp
  have h : env43448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43447_43448 : H12AffineEnvironment.transform 7 36 env43447 = env43448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43447 == env43448) = true)

theorem identity43448 : scanCanonicalize (H12AffineFastState.compose env43448 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43448 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43449 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,5156,8233,8202,13341,10281,1024,8232,12344,33,8249,3,8193,16,10281,13341,4096,2048,9225,8201,36,33,5156,8744]

theorem envBound43449 : H12AffineFastState.Bounded env43449 := by
  intro p hp
  have h : env43449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43448_43449 : H12AffineEnvironment.transform 5 16 env43448 = env43449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43448 == env43449) = true)

def env43450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1024,8660,2097152,33,2175067,2,8328,64,2239501,2172251,77835,2305071,2102684,2175202,256,32,5457,2175562]

theorem envBound43450 : H12AffineFastState.Bounded env43450 := by
  intro p hp
  have h : env43450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43442_43450 : H12AffineEnvironment.transform 13 5377 env43442 = env43450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43442 == env43450) = true)

theorem identity43450 : scanCanonicalize (H12AffineFastState.compose env43450 (packedSelected [0,3,4,5,7,8,10,12,15,16,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound43450 : packedSelected [0,3,4,5,7,8,10,12,15,16,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env43451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1024,8660,77899,33,16,2,8328,64,203846,5392,77835,138340,75223,169,256,32,5457,513]

theorem envBound43451 : H12AffineFastState.Bounded env43451 := by
  intro p hp
  have h : env43451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43450_43451 : H12AffineEnvironment.transform 20 77899 env43450 = env43451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env43450 == env43451) = true)

theorem identity43451 : scanCanonicalize (H12AffineFastState.compose env43451 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound43451 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,131072,10400,1024,8660,4297,33,16,2,8328,64,146628,5392,4233,138340,1365,169,256,32,5457,513]

theorem envBound43452 : H12AffineFastState.Bounded env43452 := by
  intro p hp
  have h : env43452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43451_43452 : H12AffineEnvironment.transform 15 8322 env43451 = env43452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env43451 == env43452) = true)

theorem identity43452 : scanCanonicalize (H12AffineFastState.compose env43452 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43452 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,478,131072,2556,1024,136,4297,33,16,2,468,64,138648,5392,4233,138340,1365,169,256,32,5457,513]

theorem envBound43453 : H12AffineFastState.Bounded env43453 := by
  intro p hp
  have h : env43453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43452_43453 : H12AffineEnvironment.transform 12 348 env43452 = env43453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43452 == env43453) = true)

theorem identity43453 : scanCanonicalize (H12AffineFastState.compose env43453 (packedSelected [2,4,6,9,10,12,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound43453 : packedSelected [2,4,6,9,10,12,19,23] rootPS < 2^1333 := by decide +kernel

def env43454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,478,5529,2556,1024,136,4297,33,16,2,468,64,2049,5392,4233,2557,1365,169,256,32,5457,513]

theorem envBound43454 : H12AffineFastState.Bounded env43454 := by
  intro p hp
  have h : env43454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43453_43454 : H12AffineEnvironment.transform 16 5529 env43453 = env43454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env43453 == env43454) = true)

theorem identity43454 : scanCanonicalize (H12AffineFastState.compose env43454 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43454 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env43455 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,137,399,5529,2477,1024,136,4248,33,16,2,389,17,2049,5392,4233,2476,1284,169,256,32,5376,513]

theorem envBound43455 : H12AffineFastState.Bounded env43455 := by
  intro p hp
  have h : env43455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43454_43455 : H12AffineEnvironment.transform 5 17 env43454 = env43455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43454 == env43455) = true)

theorem identity43455 : scanCanonicalize (H12AffineFastState.compose env43455 (packedSelected [0,1,4,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound43455 : packedSelected [0,1,4,5,10] rootPS < 2^1333 := by decide +kernel

def env43456 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3244,269,2477,137,399,2357,2477,1024,136,3124,33,16,2,389,17,2049,2492,3109,2476,1284,169,256,32,2476,513]

theorem envBound43456 : H12AffineFastState.Bounded env43456 := by
  intro p hp
  have h : env43456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43455_43456 : H12AffineEnvironment.transform 11 3244 env43455 = env43456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env43455 == env43456) = true)

theorem identity43456 : scanCanonicalize (H12AffineFastState.compose env43456 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound43456 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env43457 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,2200,269,2477,137,399,2357,2477,52,136,2048,33,16,2,389,17,2049,2492,2065,2476,304,169,256,32,2476,513]

theorem envBound43457 : H12AffineFastState.Bounded env43457 := by
  intro p hp
  have h : env43457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43456_43457 : H12AffineEnvironment.transform 9 52 env43456 = env43457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43456 == env43457) = true)

theorem identity43457 : scanCanonicalize (H12AffineFastState.compose env43457 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43457 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43458 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,269,2341,1,263,2357,2341,52,0,2048,33,16,2,269,17,2049,2356,2065,2340,304,33,256,32,2340,513]

theorem envBound43458 : H12AffineFastState.Bounded env43458 := by
  intro p hp
  have h : env43458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43457_43458 : H12AffineEnvironment.transform 6 8 env43457 = env43458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43457 == env43458) = true)

theorem identity43458 : scanCanonicalize (H12AffineFastState.compose env43458 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43459 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2064,40,2048,1,34,2064,2048,52,0,2048,33,16,2,40,17,2049,2065,2065,2049,21,33,37,32,2049,513]

theorem envBound43459 : H12AffineFastState.Bounded env43459 := by
  intro p hp
  have h : env43459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43458_43459 : H12AffineEnvironment.transform 7 37 env43458 = env43459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43458 == env43459) = true)

theorem identity43459 : scanCanonicalize (H12AffineFastState.compose env43459 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound43459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43460 : List Nat := [2,4,8,16,32,17,8,37,32,52,2048,2064,40,2048,1,34,2064,2048,52,0,2048,33,16,2,40,17,2049,2065,2065,2049,21,33,37,32,2049,33]

theorem envBound43460 : H12AffineFastState.Bounded env43460 := by
  intro p hp
  have h : env43460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43459_43460 : H12AffineEnvironment.transform 8 32 env43459 = env43460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env43459 == env43460) = true)

theorem identity43460 : scanCanonicalize (H12AffineFastState.compose env43460 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43461 : List Nat := [2,4,8,16,1,17,8,4,1,21,2048,2064,9,2048,1,3,2064,2048,21,0,2048,0,16,2,9,17,2049,2065,2065,2049,21,0,4,1,2049,0]

theorem envBound43461 : H12AffineFastState.Bounded env43461 := by
  intro p hp
  have h : env43461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43460_43461 : H12AffineEnvironment.transform 4 1 env43460 = env43461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43460 == env43461) = true)

def env43462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,2097152,32,2175067,21763,8328,64,2259212,2172251,91402,2305070,2102684,2175203,256,21793,16464,2175562]

theorem envBound43462 : H12AffineFastState.Bounded env43462 := by
  intro p hp
  have h : env43462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43441_43462 : H12AffineEnvironment.transform 17 10401 env43441 = env43462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env43441 == env43462) = true)

theorem identity43462 : scanCanonicalize (H12AffineFastState.compose env43462 (packedSelected [1,11,17,18,19,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 17864) := by decide +kernel

theorem selectedBound43462 : packedSelected [1,11,17,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env43463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,17864,32,95635,21763,8328,64,146628,90259,91402,223718,20564,95531,256,21793,16464,96130]

theorem envBound43463 : H12AffineFastState.Bounded env43463 := by
  intro p hp
  have h : env43463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43462_43463 : H12AffineEnvironment.transform 20 17864 env43462 = env43463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env43462 == env43463) = true)

theorem identity43463 : scanCanonicalize (H12AffineFastState.compose env43463 (packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43463 : packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env43464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,10401,1024,29909,17864,32,21913,21763,8328,64,146628,16537,17664,149996,20564,21793,256,21793,16464,22408]

theorem envBound43464 : H12AffineFastState.Bounded env43464 := by
  intro p hp
  have h : env43464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43463_43464 : H12AffineEnvironment.transform 15 8202 env43463 = env43464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43463 == env43464) = true)

theorem identity43464 : scanCanonicalize (H12AffineFastState.compose env43464 (packedSelected [0,1,2,3,5,7,8,9,10,11,17,18,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16877) := by decide +kernel

theorem selectedBound43464 : packedSelected [0,1,2,3,5,7,8,9,10,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env43465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,16877,10401,1024,29909,17864,32,21913,21763,8328,64,32041,16537,17664,2049,20564,21793,256,21793,16464,22408]

theorem envBound43465 : H12AffineFastState.Bounded env43465 := by
  intro p hp
  have h : env43465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43464_43465 : H12AffineEnvironment.transform 16 16877 env43464 = env43465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16877 env43464 == env43465) = true)

theorem identity43465 : scanCanonicalize (H12AffineFastState.compose env43465 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound43465 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env43466 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,29908,8202,16400,10401,1024,29909,17461,32,21604,21758,8328,64,31956,16537,17661,2049,20564,21724,253,21724,16464,22133]

theorem envBound43466 : H12AffineFastState.Bounded env43466 := by
  intro p hp
  have h : env43466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43465_43466 : H12AffineEnvironment.transform 7 253 env43465 = env43466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env43465 == env43466) = true)

theorem identity43466 : scanCanonicalize (H12AffineFastState.compose env43466 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound43466 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env43467 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5236,8352,8202,5220,10401,1024,8353,4161,32,16,138,8328,64,10400,5357,4233,2049,1056,168,253,168,5156,513]

theorem envBound43467 : H12AffineFastState.Bounded env43467 := by
  intro p hp
  have h : env43467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43466_43467 : H12AffineEnvironment.transform 13 5236 env43466 = env43467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env43466 == env43467) = true)

theorem identity43467 : scanCanonicalize (H12AffineFastState.compose env43467 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43467 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43468 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5156,8352,8202,5172,10401,1024,8353,4113,32,16,138,8328,16,10400,5309,4233,2049,1056,168,173,168,5156,513]

theorem envBound43468 : H12AffineFastState.Bounded env43468 := by
  intro p hp
  have h : env43468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43467_43468 : H12AffineEnvironment.transform 5 16 env43467 = env43468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43467 == env43468) = true)

theorem identity43468 : scanCanonicalize (H12AffineFastState.compose env43468 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43468 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43469 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,5156,8232,8202,5172,10281,1024,8233,4113,32,16,2,8192,16,10280,5173,4097,2049,1056,32,37,32,5156,513]

theorem envBound43469 : H12AffineFastState.Bounded env43469 := by
  intro p hp
  have h : env43469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43468_43469 : H12AffineEnvironment.transform 6 8 env43468 = env43469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43468 == env43469) = true)

theorem identity43469 : scanCanonicalize (H12AffineFastState.compose env43469 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43469 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43470 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,8192,4113,8232,8202,4097,10281,53,8233,4113,32,16,2,8192,16,10280,4096,4097,2049,21,32,37,32,4113,513]

theorem envBound43470 : H12AffineFastState.Bounded env43470 := by
  intro p hp
  have h : env43470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43469_43470 : H12AffineEnvironment.transform 9 53 env43469 = env43470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43469 == env43470) = true)

theorem identity43470 : scanCanonicalize (H12AffineFastState.compose env43470 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound43470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43471 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,553,4113,513,547,4097,2560,53,512,4113,32,16,2,553,16,2561,4096,4097,2049,21,32,37,32,4113,513]

theorem envBound43471 : H12AffineFastState.Bounded env43471 := by
  intro p hp
  have h : env43471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43470_43471 : H12AffineEnvironment.transform 12 553 env43470 = env43471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env43470 == env43471) = true)

theorem identity43471 : scanCanonicalize (H12AffineFastState.compose env43471 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound43471 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43472 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2107,553,2090,513,547,2106,2560,53,512,2090,32,16,2,553,16,2561,2107,2106,2049,21,32,37,32,2090,513]

theorem envBound43472 : H12AffineFastState.Bounded env43472 := by
  intro p hp
  have h : env43472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43471_43472 : H12AffineEnvironment.transform 11 2107 env43471 = env43472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env43471 == env43472) = true)

theorem identity43472 : scanCanonicalize (H12AffineFastState.compose env43472 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43472 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env43473 : List Nat := [2,4,8,16,32,16,8,37,0,53,2048,2107,41,2090,1,35,2106,2048,53,0,2090,32,16,2,41,16,2049,2107,2106,2049,21,32,37,32,2090,1]

theorem envBound43473 : H12AffineFastState.Bounded env43473 := by
  intro p hp
  have h : env43473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43472_43473 : H12AffineEnvironment.transform 8 0 env43472 = env43473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43472 == env43473) = true)

theorem identity43473 : scanCanonicalize (H12AffineFastState.compose env43473 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound43473 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43474 : List Nat := [2,4,8,16,32,16,8,37,0,53,43,16,41,1,1,35,17,43,53,0,1,32,16,2,41,16,42,16,17,42,21,32,37,32,1,1]

theorem envBound43474 : H12AffineFastState.Bounded env43474 := by
  intro p hp
  have h : env43474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43473_43474 : H12AffineEnvironment.transform 10 43 env43473 = env43474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env43473 == env43474) = true)

theorem identity43474 : scanCanonicalize (H12AffineFastState.compose env43474 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43474 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43475 : List Nat := [2,4,8,16,11,16,8,14,0,30,0,16,2,1,1,8,17,0,30,0,1,11,16,2,2,16,1,16,17,1,21,11,14,11,1,1]

theorem envBound43475 : H12AffineFastState.Bounded env43475 := by
  intro p hp
  have h : env43475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43474_43475 : H12AffineEnvironment.transform 4 11 env43474 = env43475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43474 == env43475) = true)

def env43476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,4194304,8388608,10577240,8328,64,6705548,8393985,10507601,8795349,2102685,12583064,256,21792,16464,2175563]

theorem envBound43476 : H12AffineFastState.Bounded env43476 := by
  intro p hp
  have h : env43476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43389_43476 : H12AffineEnvironment.transform 14 29909 env43389 = env43476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env43389 == env43476) = true)

def env43477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272512,8388608,10577240,8328,64,2259212,8393985,10507601,8795349,2102685,8661016,256,21792,16464,2175563]

theorem envBound43477 : H12AffineFastState.Bounded env43477 := by
  intro p hp
  have h : env43477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43476_43477 : H12AffineEnvironment.transform 21 272512 env43476 = env43477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env43476 == env43477) = true)

def env43478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,272512,8388608,10563672,8328,64,2239500,8393985,10485841,8795349,2102685,8661016,256,32,5456,2175563]

theorem envBound43478 : H12AffineFastState.Bounded env43478 := by
  intro p hp
  have h : env43478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43477_43478 : H12AffineEnvironment.transform 13 5376 env43477 = env43478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43477 == env43478) = true)

def env43479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,2097152,32,8388608,10563672,8328,64,2239500,8393985,10485841,8526965,2102685,8388792,256,32,5456,2175563]

theorem envBound43479 : H12AffineFastState.Bounded env43479 := by
  intro p hp
  have h : env43479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43478_43479 : H12AffineEnvironment.transform 17 10400 env43478 = env43479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env43478 == env43479) = true)

def env43480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,2097152,32,136448,2303320,8328,64,2239500,131073,2233681,2421,2102685,136632,256,32,5456,2175563]

theorem envBound43480 : H12AffineFastState.Bounded env43480 := by
  intro p hp
  have h : env43480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43479_43480 : H12AffineEnvironment.transform 22 136448 env43479 = env43480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env43479 == env43480) = true)

theorem identity43480 : scanCanonicalize (H12AffineFastState.compose env43480 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound43480 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,77898,32,136448,136466,8328,64,203846,131073,206107,2421,75223,136632,256,32,5456,513]

theorem envBound43481 : H12AffineFastState.Bounded env43481 := by
  intro p hp
  have h : env43481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43480_43481 : H12AffineEnvironment.transform 20 77898 env43480 = env43481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env43480 == env43481) = true)

theorem identity43481 : scanCanonicalize (H12AffineFastState.compose env43481 (packedSelected [1,3,4,5,7,8,9,12,14,16,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound43481 : packedSelected [1,3,4,5,7,8,9,12,14,16,18,27] rootPS < 2^1333 := by decide +kernel

def env43482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5576,10400,1024,8660,77898,32,200,218,8328,64,67982,5577,78035,2421,75223,112,256,32,5456,513]

theorem envBound43482 : H12AffineFastState.Bounded env43482 := by
  intro p hp
  have h : env43482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43481_43482 : H12AffineEnvironment.transform 16 5576 env43481 = env43482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env43481 == env43482) = true)

theorem identity43482 : scanCanonicalize (H12AffineFastState.compose env43482 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43482 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43483 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,65536,5529,10400,1024,8581,77851,32,153,139,8328,17,67982,5528,77954,2340,75142,33,256,32,5377,513]

theorem envBound43483 : H12AffineFastState.Bounded env43483 := by
  intro p hp
  have h : env43483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43482_43483 : H12AffineEnvironment.transform 5 17 env43482 = env43483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43482 == env43483) = true)

theorem identity43483 : scanCanonicalize (H12AffineFastState.compose env43483 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound43483 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43484 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,65536,5529,2341,1024,0,70046,32,153,139,269,17,67982,5528,69895,2340,66563,33,256,32,5377,513]

theorem envBound43484 : H12AffineFastState.Bounded env43484 := by
  intro p hp
  have h : env43484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43483_43484 : H12AffineEnvironment.transform 12 389 env43483 = env43484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env43483 == env43484) = true)

theorem identity43484 : scanCanonicalize (H12AffineFastState.compose env43484 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound43484 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43485 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,399,5529,2341,1024,0,4113,32,153,139,269,17,2049,5528,4232,2340,1420,33,256,32,5377,513]

theorem envBound43485 : H12AffineFastState.Bounded env43485 := by
  intro p hp
  have h : env43485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43484_43485 : H12AffineEnvironment.transform 15 399 env43484 = env43485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env43484 == env43485) = true)

theorem identity43485 : scanCanonicalize (H12AffineFastState.compose env43485 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43485 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43486 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,389,4112,1,399,4233,2341,272,0,4113,32,153,139,269,17,2049,4232,4232,2340,156,33,256,32,4113,513]

theorem envBound43486 : H12AffineFastState.Bounded env43486 := by
  intro p hp
  have h : env43486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43485_43486 : H12AffineEnvironment.transform 9 272 env43485 = env43486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43485 == env43486) = true)

theorem identity43486 : scanCanonicalize (H12AffineFastState.compose env43486 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43486 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43487 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,4096,161,4112,1,171,4233,2049,52,0,4113,32,153,139,41,17,2049,4232,4232,2048,156,33,36,32,4113,513]

theorem envBound43487 : H12AffineFastState.Bounded env43487 := by
  intro p hp
  have h : env43487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43486_43487 : H12AffineEnvironment.transform 7 36 env43486 = env43487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43486 == env43487) = true)

theorem identity43487 : scanCanonicalize (H12AffineFastState.compose env43487 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43488 : List Nat := [2,4,8,16,0,17,128,4,512,20,2048,4096,129,4112,1,139,4233,2049,20,0,4113,0,153,139,9,17,2049,4232,4232,2048,156,1,4,0,4113,513]

theorem envBound43488 : H12AffineFastState.Bounded env43488 := by
  intro p hp
  have h : env43488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43487_43488 : H12AffineEnvironment.transform 4 0 env43487 = env43488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43487 == env43488) = true)

def env43489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,2097152,32,136449,2303321,8328,64,2239500,131072,2233680,2420,2102685,136633,256,32,5456,2175563]

theorem envBound43489 : H12AffineFastState.Bounded env43489 := by
  intro p hp
  have h : env43489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43479_43489 : H12AffineEnvironment.transform 22 136449 env43479 = env43489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env43479 == env43489) = true)

def env43490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,2097152,32,136449,2303321,8192,64,2239500,131072,2233680,2420,2102549,136497,256,32,5456,2175563]

theorem envBound43490 : H12AffineFastState.Bounded env43490 := by
  intro p hp
  have h : env43490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43489_43490 : H12AffineEnvironment.transform 6 8 env43489 = env43490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43489 == env43490) = true)

theorem identity43490 : scanCanonicalize (H12AffineFastState.compose env43490 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(20+1) ^^^ 139548) := by decide +kernel

theorem selectedBound43490 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env43491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,139548,32,136449,66629,8192,64,3344,131072,13388,2420,144393,136497,256,32,5456,201559]

theorem envBound43491 : H12AffineFastState.Bounded env43491 := by
  intro p hp
  have h : env43491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43490_43491 : H12AffineEnvironment.transform 20 139548 env43490 = env43491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 139548 env43490 == env43491) = true)

theorem identity43491 : scanCanonicalize (H12AffineFastState.compose env43491 (packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound43491 : packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS < 2^1333 := by decide +kernel

def env43492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5376,1077,65536,131072,3392,1024,1076,132212,32,136449,66629,1384,64,3344,131072,4388,2420,135521,136497,256,32,5456,201559]

theorem envBound43492 : H12AffineFastState.Bounded env43492 := by
  intro p hp
  have h : env43492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43491_43492 : H12AffineEnvironment.transform 12 1384 env43491 = env43492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env43491 == env43492) = true)

theorem identity43492 : scanCanonicalize (H12AffineFastState.compose env43492 (packedSelected [3,7,10,14,16,18,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 4176) := by decide +kernel

theorem selectedBound43492 : packedSelected [3,7,10,14,16,18,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env43493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5376,1077,65536,4176,3392,1024,1076,5156,32,1361,66629,1384,64,3344,4176,4388,2420,305,1377,256,32,5456,66311]

theorem envBound43493 : H12AffineFastState.Bounded env43493 := by
  intro p hp
  have h : env43493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43492_43493 : H12AffineEnvironment.transform 16 4176 env43492 = env43493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4176 env43492 == env43493) = true)

theorem identity43493 : scanCanonicalize (H12AffineFastState.compose env43493 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43493 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env43494 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,121,4113,292,65536,4176,2129,273,293,4405,32,64,65876,121,64,2049,4176,4388,2420,305,112,256,32,4161,66311]

theorem envBound43494 : H12AffineFastState.Bounded env43494 := by
  intro p hp
  have h : env43494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43493_43494 : H12AffineEnvironment.transform 9 273 env43493 = env43494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43493 == env43494) = true)

theorem identity43494 : scanCanonicalize (H12AffineFastState.compose env43494 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound43494 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43495 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,121,4113,292,342,4176,2129,273,293,4405,32,64,2,121,64,2049,4176,4388,2420,305,112,256,32,4161,593]

theorem envBound43495 : H12AffineFastState.Bounded env43495 := by
  intro p hp
  have h : env43495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43494_43495 : H12AffineEnvironment.transform 15 342 env43494 = env43495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env43494 == env43495) = true)

theorem identity43495 : scanCanonicalize (H12AffineFastState.compose env43495 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound43495 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43496 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2113,121,2128,292,342,2065,2129,273,293,2420,32,64,2,121,64,2049,2065,2405,2420,305,112,256,32,2048,593]

theorem envBound43496 : H12AffineFastState.Bounded env43496 := by
  intro p hp
  have h : env43496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43495_43496 : H12AffineEnvironment.transform 11 2113 env43495 = env43496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env43495 == env43496) = true)

theorem identity43496 : scanCanonicalize (H12AffineFastState.compose env43496 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound43496 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43497 : List Nat := [2,4,8,16,32,64,8,256,512,273,372,309,121,292,292,342,357,293,273,293,0,32,64,2,121,64,373,357,17,0,305,112,256,32,372,593]

theorem envBound43497 : H12AffineFastState.Bounded env43497 := by
  intro p hp
  have h : env43497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43496_43497 : H12AffineEnvironment.transform 10 372 env43496 = env43497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env43496 == env43497) = true)

theorem identity43497 : scanCanonicalize (H12AffineFastState.compose env43497 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43497 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43498 : List Nat := [2,4,8,16,32,16,8,256,512,273,292,309,41,292,292,262,309,293,273,293,0,32,16,2,41,16,293,309,17,0,305,32,256,32,292,513]

theorem envBound43498 : H12AffineFastState.Bounded env43498 := by
  intro p hp
  have h : env43498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43497_43498 : H12AffineEnvironment.transform 5 16 env43497 = env43498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43497 == env43498) = true)

def env43499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,2097152,32,136449,2303321,8193,64,2239500,131072,2233680,2420,2102548,136496,256,32,5456,2175563]

theorem envBound43499 : H12AffineFastState.Bounded env43499 := by
  intro p hp
  have h : env43499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43489_43499 : H12AffineEnvironment.transform 6 9 env43489 = env43499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43489 == env43499) = true)

theorem identity43499 : scanCanonicalize (H12AffineFastState.compose env43499 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(20+1) ^^^ 132433) := by decide +kernel

theorem selectedBound43499 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env43500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,132433,32,136449,73736,8193,64,10589,131072,4097,2420,135237,136496,256,32,5456,210714]

theorem envBound43500 : H12AffineFastState.Bounded env43500 := by
  intro p hp
  have h : env43500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43499_43500 : H12AffineEnvironment.transform 20 132433 env43499 = env43500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132433 env43499 == env43500) = true)

theorem identity43500 : scanCanonicalize (H12AffineFastState.compose env43500 (packedSelected [1,8,19] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound43500 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env43501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,70727,10281,1024,8541,69910,32,65862,73736,8193,64,10589,70727,4097,2420,66562,65911,256,32,5456,9053]

theorem envBound43501 : H12AffineFastState.Bounded env43501 := by
  intro p hp
  have h : env43501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43500_43501 : H12AffineEnvironment.transform 16 70727 env43500 = env43501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env43500 == env43501) = true)

theorem identity43501 : scanCanonicalize (H12AffineFastState.compose env43501 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43501 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,65536,70727,2420,1024,0,69910,32,65862,65877,348,64,2048,70727,4097,2420,66562,65911,256,32,5456,512]

theorem envBound43502 : H12AffineFastState.Bounded env43502 := by
  intro p hp
  have h : env43502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43501_43502 : H12AffineEnvironment.transform 12 349 env43501 = env43502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43501 == env43502) = true)

theorem identity43502 : scanCanonicalize (H12AffineFastState.compose env43502 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43502 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43503 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5376,1,65536,70727,2388,1024,0,69910,0,65862,65877,348,64,2048,70727,4097,2388,66562,65879,256,0,5456,512]

theorem envBound43503 : H12AffineFastState.Bounded env43503 := by
  intro p hp
  have h : env43503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43502_43503 : H12AffineEnvironment.transform 4 0 env43502 = env43503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43502 == env43503) = true)

theorem identity43503 : scanCanonicalize (H12AffineFastState.compose env43503 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(15+1) ^^^ 2649) := by decide +kernel

theorem selectedBound43503 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env43504 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5376,1,2649,7710,2388,1024,0,6991,0,2847,2828,348,64,2048,7710,4097,2388,3675,2830,256,0,5456,512]

theorem envBound43504 : H12AffineFastState.Bounded env43504 := by
  intro p hp
  have h : env43504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43503_43504 : H12AffineEnvironment.transform 15 2649 env43503 = env43504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2649 env43503 == env43504) = true)

theorem identity43504 : scanCanonicalize (H12AffineFastState.compose env43504 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3157) := by decide +kernel

theorem selectedBound43504 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env43505 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,3157,349,2389,1,2649,587,2388,1024,0,1818,0,2847,2828,348,64,2048,587,3156,2388,3675,2830,256,0,2309,512]

theorem envBound43505 : H12AffineFastState.Bounded env43505 := by
  intro p hp
  have h : env43505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43504_43505 : H12AffineEnvironment.transform 11 3157 env43504 = env43505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env43504 == env43505) = true)

theorem identity43505 : scanCanonicalize (H12AffineFastState.compose env43505 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(10+1) ^^^ 1867) := by decide +kernel

theorem selectedBound43505 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env43506 : List Nat := [2,4,8,16,0,64,9,256,512,1024,1867,798,349,1566,1,1298,587,1567,1024,0,1818,0,1108,1095,348,64,1867,587,799,1567,272,1093,256,0,1614,512]

theorem envBound43506 : H12AffineFastState.Bounded env43506 := by
  intro p hp
  have h : env43506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43505_43506 : H12AffineEnvironment.transform 10 1867 env43505 = env43506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1867 env43505 == env43506) = true)

theorem identity43506 : scanCanonicalize (H12AffineFastState.compose env43506 (packedSelected [0,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 351) := by decide +kernel

theorem selectedBound43506 : packedSelected [0,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43507 : List Nat := [2,4,8,16,0,64,9,256,351,1024,1044,65,349,1345,1,1298,276,1344,1024,0,1093,0,1108,1095,348,64,1044,276,64,1344,272,1093,256,0,1297,351]

theorem envBound43507 : H12AffineFastState.Bounded env43507 := by
  intro p hp
  have h : env43507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43506_43507 : H12AffineEnvironment.transform 8 351 env43506 = env43507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 351 env43506 == env43507) = true)

theorem identity43507 : scanCanonicalize (H12AffineFastState.compose env43507 (packedSelected [0,2,7,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43507 : packedSelected [0,2,7,15] rootPS < 2^1333 := by decide +kernel

def env43508 : List Nat := [2,4,8,16,0,64,9,256,351,272,260,65,349,81,1,2,276,80,272,0,341,0,324,343,348,64,260,276,64,80,272,341,256,0,1,351]

theorem envBound43508 : H12AffineFastState.Bounded env43508 := by
  intro p hp
  have h : env43508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43507_43508 : H12AffineEnvironment.transform 9 272 env43507 = env43508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43507 == env43508) = true)

theorem identity43508 : scanCanonicalize (H12AffineFastState.compose env43508 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound43508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43509 : List Nat := [2,4,8,16,0,64,9,85,10,69,81,65,8,81,1,2,65,80,69,0,0,0,17,2,9,64,81,65,64,80,69,0,85,0,1,10]

theorem envBound43509 : H12AffineFastState.Bounded env43509 := by
  intro p hp
  have h : env43509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43508_43509 : H12AffineEnvironment.transform 7 85 env43508 = env43509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env43508 == env43509) = true)

theorem identity43509 : scanCanonicalize (H12AffineFastState.compose env43509 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound43509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43510 : List Nat := [2,4,8,4,0,64,9,65,10,69,69,65,8,69,1,2,65,68,69,0,0,0,5,2,9,64,69,65,64,68,69,0,65,0,1,10]

theorem envBound43510 : H12AffineFastState.Bounded env43510 := by
  intro p hp
  have h : env43510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43509_43510 : H12AffineEnvironment.transform 3 4 env43509 = env43510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env43509 == env43510) = true)

theorem identity43510 : scanCanonicalize (H12AffineFastState.compose env43510 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43510 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43511 : List Nat := [2,4,4,4,0,64,5,65,6,69,69,65,4,69,1,2,65,68,69,0,0,0,5,2,5,64,69,65,64,68,69,0,65,0,1,6]

theorem envBound43511 : H12AffineFastState.Bounded env43511 := by
  intro p hp
  have h : env43511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43510_43511 : H12AffineEnvironment.transform 2 4 env43510 = env43511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43510 == env43511) = true)

theorem identity43511 : scanCanonicalize (H12AffineFastState.compose env43511 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound43511 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43512 : List Nat := [2,4,4,4,0,2,5,3,6,7,7,3,4,7,1,2,3,6,7,0,0,0,5,2,5,2,7,3,2,6,7,0,3,0,1,6]

theorem envBound43512 : H12AffineFastState.Bounded env43512 := by
  intro p hp
  have h : env43512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43511_43512 : H12AffineEnvironment.transform 5 2 env43511 = env43512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env43511 == env43512) = true)

theorem identity43512 : scanCanonicalize (H12AffineFastState.compose env43512 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43512 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43513 : List Nat := [0,4,4,4,0,0,5,1,4,5,5,1,4,5,1,0,1,4,5,0,0,0,5,0,5,0,5,1,0,4,5,0,1,0,1,4]

theorem envBound43513 : H12AffineFastState.Bounded env43513 := by
  intro p hp
  have h : env43513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43512_43513 : H12AffineEnvironment.transform 0 0 env43512 = env43513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43512 == env43513) = true)

theorem identity43513 : scanCanonicalize (H12AffineFastState.compose env43513 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43513 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43514 : List Nat := [0,1,1,1,0,0,0,1,1,0,0,1,1,0,1,0,1,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,1,1]

theorem envBound43514 : H12AffineFastState.Bounded env43514 := by
  intro p hp
  have h : env43514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43513_43514 : H12AffineEnvironment.transform 1 1 env43513 = env43514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43513 == env43514) = true)

def env43515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,2097152,33,8388608,10563672,8328,64,2239500,8393985,10485841,8526964,2102685,8388793,256,32,5456,2175563]

theorem envBound43515 : H12AffineFastState.Bounded env43515 := by
  intro p hp
  have h : env43515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43478_43515 : H12AffineEnvironment.transform 17 10401 env43478 = env43515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env43478 == env43515) = true)

theorem identity43515 : scanCanonicalize (H12AffineFastState.compose env43515 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound43515 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,2097152,33,16,2175048,8328,64,2239500,5393,2097217,138340,2102685,169,256,32,5456,2175563]

theorem envBound43516 : H12AffineFastState.Bounded env43516 := by
  intro p hp
  have h : env43516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43515_43516 : H12AffineEnvironment.transform 22 16 env43515 = env43516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env43515 == env43516) = true)

theorem identity43516 : scanCanonicalize (H12AffineFastState.compose env43516 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 206170) := by decide +kernel

theorem selectedBound43516 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env43517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,206170,33,16,136466,8328,64,67926,5393,206107,138340,209095,169,256,32,5456,136977]

theorem envBound43517 : H12AffineFastState.Bounded env43517 := by
  intro p hp
  have h : env43517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43516_43517 : H12AffineEnvironment.transform 20 206170 env43516 = env43517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206170 env43516 == env43517) = true)

theorem identity43517 : scanCanonicalize (H12AffineFastState.compose env43517 (packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound43517 : packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env43518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8323,131072,10401,1024,8660,132569,33,16,136466,8328,64,10709,5393,132504,138340,135236,169,256,32,5456,136977]

theorem envBound43518 : H12AffineFastState.Bounded env43518 := by
  intro p hp
  have h : env43518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43517_43518 : H12AffineEnvironment.transform 15 8323 env43517 = env43518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env43517 == env43518) = true)

theorem identity43518 : scanCanonicalize (H12AffineFastState.compose env43518 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound43518 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8323,5529,10401,1024,8660,4160,33,16,139,8328,64,10709,5393,4097,2557,1501,169,256,32,5456,648]

theorem envBound43519 : H12AffineFastState.Bounded env43519 := by
  intro p hp
  have h : env43519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43518_43519 : H12AffineEnvironment.transform 16 5529 env43518 = env43519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env43518 == env43519) = true)

theorem identity43519 : scanCanonicalize (H12AffineFastState.compose env43519 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound43519 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,381,5376,168,510,5529,2524,1024,169,4160,33,16,139,501,64,2216,5393,4097,2557,1501,169,256,32,5456,648]

theorem envBound43520 : H12AffineFastState.Bounded env43520 := by
  intro p hp
  have h : env43520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43519_43520 : H12AffineEnvironment.transform 12 381 env43519 = env43520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env43519 == env43520) = true)

theorem identity43520 : scanCanonicalize (H12AffineFastState.compose env43520 (packedSelected [0,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound43520 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env43521 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,381,5376,0,342,5425,2420,1024,1,4160,33,16,35,349,64,2048,5393,4097,2389,1397,1,256,32,5456,544]

theorem envBound43521 : H12AffineFastState.Bounded env43521 := by
  intro p hp
  have h : env43521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43520_43521 : H12AffineEnvironment.transform 6 40 env43520 = env43521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env43520 == env43521) = true)

theorem identity43521 : scanCanonicalize (H12AffineFastState.compose env43521 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound43521 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env43522 : List Nat := [2,4,8,16,32,64,40,256,512,1024,293,4096,381,5376,0,342,5425,81,1024,1,4160,33,16,35,349,64,293,5393,4097,112,1397,1,256,32,5456,544]

theorem envBound43522 : H12AffineFastState.Bounded env43522 := by
  intro p hp
  have h : env43522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43521_43522 : H12AffineEnvironment.transform 10 293 env43521 = env43522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env43521 == env43522) = true)

theorem identity43522 : scanCanonicalize (H12AffineFastState.compose env43522 (packedSelected [0,3,5,6,7,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43522 : packedSelected [0,3,5,6,7,10,14] rootPS < 2^1333 := by decide +kernel

def env43523 : List Nat := [2,4,8,16,32,64,40,36,512,1024,1,4096,89,5156,0,114,5141,81,1024,1,4160,33,16,35,121,64,1,5173,4097,112,1105,1,36,32,5236,544]

theorem envBound43523 : H12AffineFastState.Bounded env43523 := by
  intro p hp
  have h : env43523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43522_43523 : H12AffineEnvironment.transform 7 36 env43522 = env43523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43522 == env43523) = true)

theorem identity43523 : scanCanonicalize (H12AffineFastState.compose env43523 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43523 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env43524 : List Nat := [2,4,8,16,32,16,40,36,512,1024,1,4096,9,5156,0,34,5141,1,1024,1,4112,33,16,35,41,16,1,5173,4097,32,1025,1,36,32,5156,544]

theorem envBound43524 : H12AffineFastState.Bounded env43524 := by
  intro p hp
  have h : env43524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43523_43524 : H12AffineEnvironment.transform 5 16 env43523 = env43524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43523 == env43524) = true)

theorem identity43524 : scanCanonicalize (H12AffineFastState.compose env43524 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43524 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43525 : List Nat := [2,4,8,16,1,16,9,5,512,1024,1,4096,9,5125,0,3,5141,1,1024,1,4112,0,16,2,8,16,1,5140,4097,1,1025,1,5,1,5125,513]

theorem envBound43525 : H12AffineFastState.Bounded env43525 := by
  intro p hp
  have h : env43525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43524_43525 : H12AffineEnvironment.transform 4 1 env43524 = env43525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43524 == env43525) = true)

theorem identity43525 : scanCanonicalize (H12AffineFastState.compose env43525 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43526 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,4096,9,4112,0,3,4096,1,21,1,4112,0,16,2,8,16,1,4097,4097,1,20,1,5,1,4112,513]

theorem envBound43526 : H12AffineFastState.Bounded env43526 := by
  intro p hp
  have h : env43526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43525_43526 : H12AffineEnvironment.transform 9 21 env43525 = env43526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43525 == env43526) = true)

theorem identity43526 : scanCanonicalize (H12AffineFastState.compose env43526 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound43526 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43527 : List Nat := [2,4,8,16,1,16,9,5,16,21,1,4096,9,4112,0,3,4096,1,21,1,4112,0,16,2,8,16,1,4097,4097,1,20,1,5,1,4112,17]

theorem envBound43527 : H12AffineFastState.Bounded env43527 := by
  intro p hp
  have h : env43527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43526_43527 : H12AffineEnvironment.transform 8 16 env43526 = env43527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43526 == env43527) = true)

theorem identity43527 : scanCanonicalize (H12AffineFastState.compose env43527 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43528 : List Nat := [2,4,8,16,1,16,9,5,16,21,1,1,9,17,0,3,1,1,21,1,17,0,16,2,8,16,1,0,0,1,20,1,5,1,17,17]

theorem envBound43528 : H12AffineFastState.Bounded env43528 := by
  intro p hp
  have h : env43528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43527_43528 : H12AffineEnvironment.transform 11 1 env43527 = env43528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43527 == env43528) = true)

theorem identity43528 : scanCanonicalize (H12AffineFastState.compose env43528 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43528 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43529 : List Nat := [2,4,8,0,1,0,9,5,0,5,1,1,9,1,0,3,1,1,5,1,1,0,0,2,8,0,1,0,0,1,4,1,5,1,1,1]

theorem envBound43529 : H12AffineFastState.Bounded env43529 := by
  intro p hp
  have h : env43529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43528_43529 : H12AffineEnvironment.transform 3 0 env43528 = env43529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43528 == env43529) = true)

def env43530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,272512,8388608,10563673,8328,64,2239501,8393985,10485840,8795349,2102685,8661016,256,33,5457,2175563]

theorem envBound43530 : H12AffineFastState.Bounded env43530 := by
  intro p hp
  have h : env43530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43477_43530 : H12AffineEnvironment.transform 13 5377 env43477 = env43530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43477 == env43530) = true)

def env43531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1024,8661,2097152,32,8388608,10563673,8328,64,2239501,8393985,10485840,8526965,2102685,8388792,256,33,5457,2175563]

theorem envBound43531 : H12AffineFastState.Bounded env43531 := by
  intro p hp
  have h : env43531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43530_43531 : H12AffineEnvironment.transform 17 10400 env43530 = env43531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env43530 == env43531) = true)

theorem identity43531 : scanCanonicalize (H12AffineFastState.compose env43531 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43531 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,2097152,32,8388608,10563673,8193,64,2239501,8393985,10485840,8526965,2102548,8388657,256,33,5457,2175563]

theorem envBound43532 : H12AffineFastState.Bounded env43532 := by
  intro p hp
  have h : env43532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43531_43532 : H12AffineEnvironment.transform 6 9 env43531 = env43532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43531 == env43532) = true)

theorem identity43532 : scanCanonicalize (H12AffineFastState.compose env43532 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound43532 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env43533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77898,32,8388608,8388627,8193,64,203847,8393985,8466458,8526965,75102,8388657,256,33,5457,513]

theorem envBound43533 : H12AffineFastState.Bounded env43533 := by
  intro p hp
  have h : env43533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43532_43533 : H12AffineEnvironment.transform 20 77898 env43532 = env43533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env43532 == env43533) = true)

theorem identity43533 : scanCanonicalize (H12AffineFastState.compose env43533 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(22+1) ^^^ 210267) := by decide +kernel

theorem selectedBound43533 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env43534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77898,32,210267,210248,8193,64,203847,204890,132417,76078,75102,210282,256,33,5457,513]

theorem envBound43534 : H12AffineFastState.Bounded env43534 := by
  intro p hp
  have h : env43534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43533_43534 : H12AffineEnvironment.transform 22 210267 env43533 = env43534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 210267 env43533 == env43534) = true)

theorem identity43534 : scanCanonicalize (H12AffineFastState.compose env43534 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound43534 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,263,131072,10281,1024,8540,12621,32,144476,144463,8193,64,138560,139613,132417,10281,9305,144493,256,33,5457,513]

theorem envBound43535 : H12AffineFastState.Bounded env43535 := by
  intro p hp
  have h : env43535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43534_43535 : H12AffineEnvironment.transform 15 263 env43534 = env43535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env43534 == env43535) = true)

theorem identity43535 : scanCanonicalize (H12AffineFastState.compose env43535 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43535 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43536 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,263,131072,10281,1024,8461,12572,32,144397,144414,8193,17,138513,139532,132368,10281,9224,144444,256,33,5376,513]

theorem envBound43536 : H12AffineFastState.Bounded env43536 := by
  intro p hp
  have h : env43536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43535_43536 : H12AffineEnvironment.transform 5 17 env43535 = env43536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43535 == env43536) = true)

theorem identity43536 : scanCanonicalize (H12AffineFastState.compose env43536 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound43536 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43537 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,263,5392,10281,1024,8461,12572,32,8477,8462,8193,17,2049,13340,4096,10281,9224,8492,256,33,5376,513]

theorem envBound43537 : H12AffineFastState.Bounded env43537 := by
  intro p hp
  have h : env43537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43536_43537 : H12AffineEnvironment.transform 16 5392 env43536 = env43537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env43536 == env43537) = true)

theorem identity43537 : scanCanonicalize (H12AffineFastState.compose env43537 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43537 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43538 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,263,5392,2341,1024,1,4112,32,17,2,269,17,2049,5392,4096,2341,1284,32,256,33,5376,513]

theorem envBound43538 : H12AffineFastState.Bounded env43538 := by
  intro p hp
  have h : env43538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43537_43538 : H12AffineEnvironment.transform 12 268 env43537 = env43538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43537 == env43538) = true)

theorem identity43538 : scanCanonicalize (H12AffineFastState.compose env43538 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound43538 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43539 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,308,268,1077,0,263,1060,2341,1024,1,292,32,17,2,269,17,2049,1060,308,2341,1284,32,256,33,1076,513]

theorem envBound43539 : H12AffineFastState.Bounded env43539 := by
  intro p hp
  have h : env43539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43538_43539 : H12AffineEnvironment.transform 11 308 env43538 = env43539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env43538 == env43539) = true)

theorem identity43539 : scanCanonicalize (H12AffineFastState.compose env43539 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43539 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43540 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,308,268,292,0,263,309,2341,273,1,292,32,17,2,269,17,2049,309,308,2341,21,32,256,33,293,513]

theorem envBound43540 : H12AffineFastState.Bounded env43540 := by
  intro p hp
  have h : env43540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43539_43540 : H12AffineEnvironment.transform 9 273 env43539 = env43540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43539 == env43540) = true)

theorem identity43540 : scanCanonicalize (H12AffineFastState.compose env43540 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43540 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43541 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,16,40,0,0,35,17,2049,53,1,0,32,17,2,41,17,2049,17,16,2049,21,32,36,33,1,513]

theorem envBound43541 : H12AffineFastState.Bounded env43541 := by
  intro p hp
  have h : env43541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43540_43541 : H12AffineEnvironment.transform 7 36 env43540 = env43541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43540 == env43541) = true)

theorem identity43541 : scanCanonicalize (H12AffineFastState.compose env43541 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound43541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43542 : List Nat := [2,4,8,16,32,17,9,36,48,53,2048,16,40,0,0,35,17,2049,53,1,0,32,17,2,41,17,2049,17,16,2049,21,32,36,33,1,49]

theorem envBound43542 : H12AffineFastState.Bounded env43542 := by
  intro p hp
  have h : env43542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43541_43542 : H12AffineEnvironment.transform 8 48 env43541 = env43542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env43541 == env43542) = true)

theorem identity43542 : scanCanonicalize (H12AffineFastState.compose env43542 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound43542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43543 : List Nat := [2,4,8,16,32,17,9,36,48,53,48,16,40,0,0,35,17,49,53,1,0,32,17,2,41,17,49,17,16,49,21,32,36,33,1,49]

theorem envBound43543 : H12AffineFastState.Bounded env43543 := by
  intro p hp
  have h : env43543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43542_43543 : H12AffineEnvironment.transform 10 48 env43542 = env43543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env43542 == env43543) = true)

theorem identity43543 : scanCanonicalize (H12AffineFastState.compose env43543 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43543 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43544 : List Nat := [2,4,8,16,17,17,9,21,1,4,1,16,25,0,0,18,17,0,4,1,0,17,17,2,24,17,0,17,16,0,21,17,21,16,1,0]

theorem envBound43544 : H12AffineFastState.Bounded env43544 := by
  intro p hp
  have h : env43544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43543_43544 : H12AffineEnvironment.transform 4 17 env43543 = env43544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43543 == env43544) = true)

def env43545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1024,8661,2097152,33,8388608,10563673,8328,64,2239501,8393985,10485840,8526964,2102685,8388793,256,33,5457,2175563]

theorem envBound43545 : H12AffineFastState.Bounded env43545 := by
  intro p hp
  have h : env43545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43530_43545 : H12AffineEnvironment.transform 17 10401 env43530 = env43545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env43530 == env43545) = true)

theorem identity43545 : scanCanonicalize (H12AffineFastState.compose env43545 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 153) := by decide +kernel

theorem selectedBound43545 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1024,8661,2097152,33,153,2175168,8328,64,2239501,5528,2097353,138477,2102685,32,256,33,5457,2175563]

theorem envBound43546 : H12AffineFastState.Bounded env43546 := by
  intro p hp
  have h : env43546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43545_43546 : H12AffineEnvironment.transform 22 153 env43545 = env43546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 153 env43545 == env43546) = true)

theorem identity43546 : scanCanonicalize (H12AffineFastState.compose env43546 (packedSelected [0,1,4,7,11,16,18,19,20,22,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound43546 : packedSelected [0,1,4,7,11,16,18,19,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env43547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1024,8661,4296,33,153,73736,8328,64,146629,5528,4097,138477,1365,32,256,33,5457,74371]

theorem envBound43547 : H12AffineFastState.Bounded env43547 := by
  intro p hp
  have h : env43547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43546_43547 : H12AffineEnvironment.transform 20 4296 env43546 = env43547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env43546 == env43547) = true)

theorem identity43547 : scanCanonicalize (H12AffineFastState.compose env43547 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound43547 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8323,131072,10401,1024,8661,4296,33,153,139,8328,64,146629,5528,4097,138477,1365,32,256,33,5457,512]

theorem envBound43548 : H12AffineFastState.Bounded env43548 := by
  intro p hp
  have h : env43548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43547_43548 : H12AffineEnvironment.transform 15 8323 env43547 = env43548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env43547 == env43548) = true)

theorem identity43548 : scanCanonicalize (H12AffineFastState.compose env43548 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound43548 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5377,113,294,131072,2308,1024,112,4296,33,153,139,301,64,138592,5528,4097,138477,1365,32,256,33,5457,512]

theorem envBound43549 : H12AffineFastState.Bounded env43549 := by
  intro p hp
  have h : env43549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43548_43549 : H12AffineEnvironment.transform 12 421 env43548 = env43549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env43548 == env43549) = true)

theorem identity43549 : scanCanonicalize (H12AffineFastState.compose env43549 (packedSelected [2,4,9,12,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound43549 : packedSelected [2,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5377,113,294,5393,2308,1024,112,4296,33,153,139,301,64,2161,5528,4097,2556,1365,32,256,33,5457,512]

theorem envBound43550 : H12AffineFastState.Bounded env43550 := by
  intro p hp
  have h : env43550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43549_43550 : H12AffineEnvironment.transform 16 5393 env43549 = env43550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env43549 == env43550) = true)

theorem identity43550 : scanCanonicalize (H12AffineFastState.compose env43550 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound43550 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env43551 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,121,5341,113,250,5325,2264,1024,112,4296,33,153,139,241,64,2161,5188,4097,2080,1161,32,220,33,5261,512]

theorem envBound43551 : H12AffineFastState.Bounded env43551 := by
  intro p hp
  have h : env43551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43550_43551 : H12AffineEnvironment.transform 7 220 env43550 = env43551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env43550 == env43551) = true)

theorem identity43551 : scanCanonicalize (H12AffineFastState.compose env43551 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43551 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43552 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,88,5341,80,219,5325,2264,1024,81,4296,0,153,139,208,64,2128,5188,4097,2049,1161,1,220,0,5261,512]

theorem envBound43552 : H12AffineFastState.Bounded env43552 := by
  intro p hp
  have h : env43552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43551_43552 : H12AffineEnvironment.transform 4 1 env43551 = env43552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43551 == env43552) = true)

theorem identity43552 : scanCanonicalize (H12AffineFastState.compose env43552 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound43552 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env43553 : List Nat := [2,4,8,16,1,64,128,220,512,156,2048,4096,88,4161,80,219,4177,2264,156,81,4296,0,153,139,208,64,2128,4312,4097,2049,21,1,220,0,4113,512]

theorem envBound43553 : H12AffineFastState.Bounded env43553 := by
  intro p hp
  have h : env43553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43552_43553 : H12AffineEnvironment.transform 9 156 env43552 = env43553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env43552 == env43553) = true)

theorem identity43553 : scanCanonicalize (H12AffineFastState.compose env43553 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43553 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43554 : List Nat := [2,4,8,16,1,64,9,85,512,21,2048,4096,88,4161,80,82,4177,2129,21,81,4161,0,16,2,89,64,2128,4177,4097,2049,21,1,85,0,4113,512]

theorem envBound43554 : H12AffineFastState.Bounded env43554 := by
  intro p hp
  have h : env43554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43553_43554 : H12AffineEnvironment.transform 6 9 env43553 = env43554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43553 == env43554) = true)

theorem identity43554 : scanCanonicalize (H12AffineFastState.compose env43554 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 21) := by decide +kernel

theorem selectedBound43554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43555 : List Nat := [2,4,8,16,1,21,9,0,512,21,2048,4096,13,4116,5,7,4100,2052,21,4,4116,0,16,2,12,21,2053,4100,4097,2049,21,1,0,0,4113,512]

theorem envBound43555 : H12AffineFastState.Bounded env43555 := by
  intro p hp
  have h : env43555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43554_43555 : H12AffineEnvironment.transform 5 21 env43554 = env43555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env43554 == env43555) = true)

theorem identity43555 : scanCanonicalize (H12AffineFastState.compose env43555 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43555 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43556 : List Nat := [2,4,8,16,1,21,9,0,512,21,2048,0,13,20,5,7,4,2052,21,4,20,0,16,2,12,21,2053,4,1,2049,21,1,0,0,17,512]

theorem envBound43556 : H12AffineFastState.Bounded env43556 := by
  intro p hp
  have h : env43556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43555_43556 : H12AffineEnvironment.transform 11 0 env43555 = env43556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43555 == env43556) = true)

theorem identity43556 : scanCanonicalize (H12AffineFastState.compose env43556 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound43556 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43557 : List Nat := [2,4,8,16,1,21,9,0,512,21,14,0,13,20,5,7,4,10,21,4,20,0,16,2,12,21,11,4,1,15,21,1,0,0,17,512]

theorem envBound43557 : H12AffineFastState.Bounded env43557 := by
  intro p hp
  have h : env43557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43556_43557 : H12AffineEnvironment.transform 10 14 env43556 = env43557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env43556 == env43557) = true)

theorem identity43557 : scanCanonicalize (H12AffineFastState.compose env43557 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound43557 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env43558 : List Nat := [2,4,8,16,1,21,9,0,5,21,14,0,13,20,5,7,4,10,21,4,20,0,16,2,12,21,11,4,1,15,21,1,0,0,17,5]

theorem envBound43558 : H12AffineFastState.Bounded env43558 := by
  intro p hp
  have h : env43558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43557_43558 : H12AffineEnvironment.transform 8 5 env43557 = env43558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env43557 == env43558) = true)

theorem identity43558 : scanCanonicalize (H12AffineFastState.compose env43558 (packedSelected [1,4,8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43558 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env43559 : List Nat := [2,1,8,16,1,16,9,0,0,16,11,0,8,17,0,2,1,10,16,1,17,0,16,2,9,16,11,1,1,10,16,1,0,0,17,0]

theorem envBound43559 : H12AffineFastState.Bounded env43559 := by
  intro p hp
  have h : env43559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43558_43559 : H12AffineEnvironment.transform 1 1 env43558 = env43559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43558 == env43559) = true)

theorem identity43559 : scanCanonicalize (H12AffineFastState.compose env43559 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound43559 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43560 : List Nat := [2,1,8,9,1,9,9,0,0,9,11,0,8,8,0,2,1,10,9,1,8,0,9,2,9,9,11,1,1,10,9,1,0,0,8,0]

theorem envBound43560 : H12AffineFastState.Bounded env43560 := by
  intro p hp
  have h : env43560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43559_43560 : H12AffineEnvironment.transform 3 9 env43559 = env43560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env43559 == env43560) = true)

theorem identity43560 : scanCanonicalize (H12AffineFastState.compose env43560 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43560 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43561 : List Nat := [1,1,8,9,1,9,9,0,0,9,8,0,8,8,0,1,1,9,9,1,8,0,9,1,9,9,8,1,1,9,9,1,0,0,8,0]

theorem envBound43561 : H12AffineFastState.Bounded env43561 := by
  intro p hp
  have h : env43561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43560_43561 : H12AffineEnvironment.transform 0 1 env43560 = env43561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43560 == env43561) = true)

def env43562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,8388608,10577240,8328,64,2259213,8393985,10507601,8795349,2102685,8661017,256,21792,16464,2175563]

theorem envBound43562 : H12AffineFastState.Bounded env43562 := by
  intro p hp
  have h : env43562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43476_43562 : H12AffineEnvironment.transform 21 272513 env43476 = env43562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env43476 == env43562) = true)

theorem identity43562 : scanCanonicalize (H12AffineFastState.compose env43562 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound43562 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,16,2188616,8328,64,2259213,5393,2118977,406725,2102685,272393,256,21792,16464,2175563]

theorem envBound43563 : H12AffineFastState.Bounded env43563 := by
  intro p hp
  have h : env43563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43562_43563 : H12AffineEnvironment.transform 22 16 env43562 = env43563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env43562 == env43563) = true)

def env43564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,272513,16,2175048,8328,64,2239501,5393,2097217,406725,2102685,272393,256,32,5456,2175563]

theorem envBound43564 : H12AffineFastState.Bounded env43564 := by
  intro p hp
  have h : env43564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43563_43564 : H12AffineEnvironment.transform 13 5376 env43563 = env43564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43563 == env43564) = true)

def env43565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,262144,1024,8660,2097152,272513,16,2175048,8328,64,2111773,5393,2097217,270805,2102685,272393,256,32,5456,2175563]

theorem envBound43565 : H12AffineFastState.Bounded env43565 := by
  intro p hp
  have h : env43565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43564_43565 : H12AffineEnvironment.transform 16 5392 env43564 = env43565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env43564 == env43565) = true)

theorem identity43565 : scanCanonicalize (H12AffineFastState.compose env43565 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound43565 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env43566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,262144,1024,8660,77898,272513,16,2,8328,64,67927,5393,77835,270805,75223,272393,256,32,5456,513]

theorem envBound43566 : H12AffineFastState.Bounded env43566 := by
  intro p hp
  have h : env43566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43565_43566 : H12AffineEnvironment.transform 20 77898 env43565 = env43566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env43565 == env43566) = true)

def env43567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,10280,1024,8660,77898,169,16,2,8328,64,67927,5393,77835,2557,75223,33,256,32,5456,513]

theorem envBound43567 : H12AffineFastState.Bounded env43567 := by
  intro p hp
  have h : env43567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43566_43567 : H12AffineEnvironment.transform 17 10280 env43566 = env43567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43566 == env43567) = true)

theorem identity43567 : scanCanonicalize (H12AffineFastState.compose env43567 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound43567 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5376,508,65536,5392,2049,1024,509,69731,169,16,2,161,64,67927,5393,69666,2557,67070,33,256,32,5456,513]

theorem envBound43568 : H12AffineFastState.Bounded env43568 := by
  intro p hp
  have h : env43568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43567_43568 : H12AffineEnvironment.transform 12 41 env43567 = env43568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env43567 == env43568) = true)

theorem identity43568 : scanCanonicalize (H12AffineFastState.compose env43568 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound43568 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5376,508,35,5392,2049,1024,509,4160,169,16,2,161,64,2420,5393,4097,2557,1501,33,256,32,5456,513]

theorem envBound43569 : H12AffineFastState.Bounded env43569 := by
  intro p hp
  have h : env43569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43568_43569 : H12AffineEnvironment.transform 15 35 env43568 = env43569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env43568 == env43569) = true)

theorem identity43569 : scanCanonicalize (H12AffineFastState.compose env43569 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43569 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43570 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,41,4112,508,35,4096,2049,272,509,4160,169,16,2,161,64,2420,4097,4097,2557,205,33,256,32,4160,513]

theorem envBound43570 : H12AffineFastState.Bounded env43570 := by
  intro p hp
  have h : env43570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43569_43570 : H12AffineEnvironment.transform 9 272 env43569 = env43570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43569 == env43570) = true)

theorem identity43570 : scanCanonicalize (H12AffineFastState.compose env43570 (packedSelected [11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43570 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env43571 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,41,4112,429,35,4096,2049,272,428,4113,169,16,2,161,17,2341,4097,4097,2476,156,33,256,32,4113,513]

theorem envBound43571 : H12AffineFastState.Bounded env43571 := by
  intro p hp
  have h : env43571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43570_43571 : H12AffineEnvironment.transform 5 17 env43570 = env43571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43570 == env43571) = true)

theorem identity43571 : scanCanonicalize (H12AffineFastState.compose env43571 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43571 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43572 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4112,292,35,4096,2049,272,293,4113,32,16,2,40,17,2341,4097,4097,2341,21,33,256,32,4113,513]

theorem envBound43572 : H12AffineFastState.Bounded env43572 := by
  intro p hp
  have h : env43572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43571_43572 : H12AffineEnvironment.transform 6 9 env43571 = env43572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43571 == env43572) = true)

theorem identity43572 : scanCanonicalize (H12AffineFastState.compose env43572 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43573 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4112,0,35,4096,2049,52,1,4113,32,16,2,40,17,2049,4097,4097,2049,21,33,36,32,4113,513]

theorem envBound43573 : H12AffineFastState.Bounded env43573 := by
  intro p hp
  have h : env43573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43572_43573 : H12AffineEnvironment.transform 7 36 env43572 = env43573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43572 == env43573) = true)

theorem identity43573 : scanCanonicalize (H12AffineFastState.compose env43573 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound43573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43574 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,545,41,561,0,35,545,2049,52,1,560,32,16,2,40,17,2049,544,544,2049,21,33,36,32,560,513]

theorem envBound43574 : H12AffineFastState.Bounded env43574 := by
  intro p hp
  have h : env43574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43573_43574 : H12AffineEnvironment.transform 11 545 env43573 = env43574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env43573 == env43574) = true)

theorem identity43574 : scanCanonicalize (H12AffineFastState.compose env43574 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound43574 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43575 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,545,41,561,0,35,545,528,52,1,560,32,16,2,40,17,528,544,544,528,21,33,36,32,560,513]

theorem envBound43575 : H12AffineFastState.Bounded env43575 := by
  intro p hp
  have h : env43575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43574_43575 : H12AffineEnvironment.transform 10 529 env43574 = env43575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env43574 == env43575) = true)

theorem identity43575 : scanCanonicalize (H12AffineFastState.compose env43575 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound43575 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43576 : List Nat := [2,4,8,16,32,17,9,36,49,52,32,16,41,0,0,35,16,33,52,1,1,32,16,2,40,17,33,17,17,33,21,33,36,32,1,48]

theorem envBound43576 : H12AffineFastState.Bounded env43576 := by
  intro p hp
  have h : env43576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43575_43576 : H12AffineEnvironment.transform 8 49 env43575 = env43576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env43575 == env43576) = true)

def env43577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,10281,1024,8660,77898,168,16,2,8328,64,67927,5393,77835,2556,75223,32,256,32,5456,513]

theorem envBound43577 : H12AffineFastState.Bounded env43577 := by
  intro p hp
  have h : env43577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43566_43577 : H12AffineEnvironment.transform 17 10281 env43566 = env43577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43566 == env43577) = true)

theorem identity43577 : scanCanonicalize (H12AffineFastState.compose env43577 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound43577 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,65536,5392,2556,1024,1,70047,168,16,2,349,64,67927,5393,70110,2556,66562,32,256,32,5456,513]

theorem envBound43578 : H12AffineFastState.Bounded env43578 := by
  intro p hp
  have h : env43578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43577_43578 : H12AffineEnvironment.transform 12 469 env43577 = env43578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env43577 == env43578) = true)

theorem identity43578 : scanCanonicalize (H12AffineFastState.compose env43578 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound43578 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env43579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,343,5392,2556,1024,1,4296,168,16,2,349,64,2048,5393,4233,2556,1365,32,256,32,5456,513]

theorem envBound43579 : H12AffineFastState.Bounded env43579 := by
  intro p hp
  have h : env43579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43578_43579 : H12AffineEnvironment.transform 15 343 env43578 = env43579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env43578 == env43579) = true)

theorem identity43579 : scanCanonicalize (H12AffineFastState.compose env43579 (packedSelected [4,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound43579 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env43580 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,469,4588,0,343,4604,2556,236,1,4296,168,16,2,349,64,2048,4605,4233,2556,441,32,256,32,4540,513]

theorem envBound43580 : H12AffineFastState.Bounded env43580 := by
  intro p hp
  have h : env43580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43579_43580 : H12AffineEnvironment.transform 9 236 env43579 = env43580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env43579 == env43580) = true)

theorem identity43580 : scanCanonicalize (H12AffineFastState.compose env43580 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound43580 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env43581 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,2065,469,2557,0,343,2541,2556,236,1,2265,168,16,2,349,64,2048,2540,2200,2556,441,32,256,32,2477,513]

theorem envBound43581 : H12AffineFastState.Bounded env43581 := by
  intro p hp
  have h : env43581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43580_43581 : H12AffineEnvironment.transform 11 2065 env43580 = env43581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env43580 == env43581) = true)

def env43582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5393,262144,1024,8660,2097152,272513,16,2175048,8328,64,2111772,5393,2097217,270804,2102685,272393,256,32,5456,2175563]

theorem envBound43582 : H12AffineFastState.Bounded env43582 := by
  intro p hp
  have h : env43582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43564_43582 : H12AffineEnvironment.transform 16 5393 env43564 = env43582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env43564 == env43582) = true)

def env43583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5393,262144,1024,8660,4160,272513,16,73736,8328,64,10588,5393,4097,270804,1501,272393,256,32,5456,74251]

theorem envBound43583 : H12AffineFastState.Bounded env43583 := by
  intro p hp
  have h : env43583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43582_43583 : H12AffineEnvironment.transform 20 4160 env43582 = env43583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43582 == env43583) = true)

theorem identity43583 : scanCanonicalize (H12AffineFastState.compose env43583 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43583 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5393,10281,1024,8660,4160,168,16,73736,8328,64,10588,5393,4097,2557,1501,32,256,32,5456,74251]

theorem envBound43584 : H12AffineFastState.Bounded env43584 := by
  intro p hp
  have h : env43584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43583_43584 : H12AffineEnvironment.transform 17 10281 env43583 = env43584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43583 == env43584) = true)

theorem identity43584 : scanCanonicalize (H12AffineFastState.compose env43584 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound43584 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8574,5393,10281,1024,8660,4160,168,16,374,8328,64,10588,5393,4097,2557,1501,32,256,32,5456,885]

theorem envBound43585 : H12AffineFastState.Bounded env43585 := by
  intro p hp
  have h : env43585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43584_43585 : H12AffineEnvironment.transform 15 8574 env43584 = env43585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env43584 == env43585) = true)

theorem identity43585 : scanCanonicalize (H12AffineFastState.compose env43585 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound43585 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env43586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,171,5393,2556,1024,1,4160,168,16,374,349,64,2185,5393,4097,2557,1501,32,256,32,5456,885]

theorem envBound43586 : H12AffineFastState.Bounded env43586 := by
  intro p hp
  have h : env43586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43585_43586 : H12AffineEnvironment.transform 12 469 env43585 = env43586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env43585 == env43586) = true)

def env43587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5393,262144,1024,8660,4161,272513,16,73737,8328,64,10589,5393,4096,270804,1500,272393,256,32,5456,74250]

theorem envBound43587 : H12AffineFastState.Bounded env43587 := by
  intro p hp
  have h : env43587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43582_43587 : H12AffineEnvironment.transform 20 4161 env43582 = env43587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43582 == env43587) = true)

theorem identity43587 : scanCanonicalize (H12AffineFastState.compose env43587 (packedSelected [0,2,4,7,9,11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound43587 : packedSelected [0,2,4,7,9,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env43588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,139,5393,262144,1024,8660,4161,272513,16,8322,8328,64,10589,5393,4096,270804,1500,272393,256,32,5456,8833]

theorem envBound43588 : H12AffineFastState.Bounded env43588 := by
  intro p hp
  have h : env43588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43587_43588 : H12AffineEnvironment.transform 15 139 env43587 = env43588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env43587 == env43588) = true)

theorem identity43588 : scanCanonicalize (H12AffineFastState.compose env43588 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2217) := by decide +kernel

theorem selectedBound43588 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env43589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,139,5393,2217,1024,8660,4161,8232,16,8322,8328,64,10589,5393,4096,10621,1500,8352,256,32,5456,8833]

theorem envBound43589 : H12AffineFastState.Bounded env43589 := by
  intro p hp
  have h : env43589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43588_43589 : H12AffineEnvironment.transform 17 2217 env43588 = env43589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2217 env43588 == env43589) = true)

theorem identity43589 : scanCanonicalize (H12AffineFastState.compose env43589 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43589 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,2,5393,2080,1024,8541,4161,8232,16,8203,8193,64,10589,5393,4096,10621,1365,8233,256,32,5456,8712]

theorem envBound43590 : H12AffineFastState.Bounded env43590 := by
  intro p hp
  have h : env43590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43589_43590 : H12AffineEnvironment.transform 6 9 env43589 = env43590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43589 == env43590) = true)

theorem identity43590 : scanCanonicalize (H12AffineFastState.compose env43590 (packedSelected [1,3,5,6,8,11,12,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound43590 : packedSelected [1,3,5,6,8,11,12,20] rootPS < 2^1333 := by decide +kernel

def env43591 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,5205,8201,2,5188,2080,1024,8200,4161,8232,16,8203,8193,64,10248,5188,4096,10280,1024,8233,85,32,5125,8712]

theorem envBound43591 : H12AffineFastState.Bounded env43591 := by
  intro p hp
  have h : env43591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43590_43591 : H12AffineEnvironment.transform 7 85 env43590 = env43591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env43590 == env43591) = true)

theorem identity43591 : scanCanonicalize (H12AffineFastState.compose env43591 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43591 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env43592 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,8201,2,5141,2080,1024,8200,4112,8232,16,8203,8193,17,10248,5141,4096,10280,1024,8233,4,32,5125,8712]

theorem envBound43592 : H12AffineFastState.Bounded env43592 := by
  intro p hp
  have h : env43592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43591_43592 : H12AffineEnvironment.transform 5 17 env43591 = env43592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43591 == env43592) = true)

theorem identity43592 : scanCanonicalize (H12AffineFastState.compose env43592 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 7213) := by decide +kernel

theorem selectedBound43592 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43593 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,7213,5124,7204,2,5141,2080,1024,7205,4112,7173,16,7206,7212,17,5157,5141,4096,5125,1024,7172,4,32,5125,7717]

theorem envBound43593 : H12AffineFastState.Bounded env43593 := by
  intro p hp
  have h : env43593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43592_43593 : H12AffineEnvironment.transform 12 7213 env43592 = env43593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7213 env43592 == env43593) = true)

theorem identity43593 : scanCanonicalize (H12AffineFastState.compose env43593 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound43593 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43594 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,3109,8,2081,1,2,2096,2080,1024,0,3125,32,16,3,9,17,2048,2096,3109,2080,1024,33,4,32,2080,512]

theorem envBound43594 : H12AffineFastState.Bounded env43594 := by
  intro p hp
  have h : env43594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43593_43594 : H12AffineEnvironment.transform 11 3109 env43593 = env43594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env43593 == env43594) = true)

theorem identity43594 : scanCanonicalize (H12AffineFastState.compose env43594 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43594 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43595 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,3077,8,2049,1,2,2064,2048,1024,0,3093,0,16,3,9,17,2048,2064,3077,2048,1024,1,4,0,2048,512]

theorem envBound43595 : H12AffineFastState.Bounded env43595 := by
  intro p hp
  have h : env43595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43594_43595 : H12AffineEnvironment.transform 4 0 env43594 = env43595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43594 == env43595) = true)

theorem identity43595 : scanCanonicalize (H12AffineFastState.compose env43595 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43595 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43596 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,2064,8,2049,1,2,2064,2048,21,0,2048,0,16,3,9,17,2048,2064,2064,2048,21,1,4,0,2048,512]

theorem envBound43596 : H12AffineFastState.Bounded env43596 := by
  intro p hp
  have h : env43596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43595_43596 : H12AffineEnvironment.transform 9 21 env43595 = env43596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43595 == env43596) = true)

theorem identity43596 : scanCanonicalize (H12AffineFastState.compose env43596 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43597 : List Nat := [2,4,8,16,0,17,9,4,0,21,2048,2064,8,2049,1,2,2064,2048,21,0,2048,0,16,3,9,17,2048,2064,2064,2048,21,1,4,0,2048,0]

theorem envBound43597 : H12AffineFastState.Bounded env43597 := by
  intro p hp
  have h : env43597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43596_43597 : H12AffineEnvironment.transform 8 0 env43596 = env43597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43596 == env43597) = true)

theorem identity43597 : scanCanonicalize (H12AffineFastState.compose env43597 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound43597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43598 : List Nat := [2,4,8,4,0,5,9,4,0,1,2048,2052,8,2049,1,2,2052,2048,1,0,2048,0,4,3,9,5,2048,2052,2052,2048,1,1,4,0,2048,0]

theorem envBound43598 : H12AffineFastState.Bounded env43598 := by
  intro p hp
  have h : env43598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43597_43598 : H12AffineEnvironment.transform 3 4 env43597 = env43598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env43597 == env43598) = true)

def leafEnv43598 : List Nat := [2,4,8,4,0,5,9,4,0,1,2048,2052,8,2049,1,2,2052,2048,1,0,2048,0,4,3,1,9,1,5,2048,2052,2052,2048,1,1,4,0,4,3,2048,0,1,2049,0]

def active43598 : List Nat := [0,1,2,10]

def tree43598 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43598 : H12WitnessSearch.Good tree43598 := H12GlobalWitnessIndex.good

theorem leafIdentity43598 : H12AffineFastState.composeSystem env43598 rootObs = leafEnv43598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43598 rootObs == leafEnv43598) = true)

theorem terminalChecked43598 : H12PackedTerminal.terminalCheckFast leafEnv43598 active43598 tree43598 = true := by decide +kernel

def env43599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,272513,16,2175049,8328,64,2239500,5393,2097216,406725,2102685,272393,256,33,5457,2175563]

theorem envBound43599 : H12AffineFastState.Bounded env43599 := by
  intro p hp
  have h : env43599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43563_43599 : H12AffineEnvironment.transform 13 5377 env43563 = env43599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43563 == env43599) = true)

theorem identity43599 : scanCanonicalize (H12AffineFastState.compose env43599 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43599 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,2097152,272392,16,2175049,8193,64,2239500,5393,2097216,406604,2102548,272393,256,33,5457,2175563]

theorem envBound43600 : H12AffineFastState.Bounded env43600 := by
  intro p hp
  have h : env43600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43599_43600 : H12AffineEnvironment.transform 6 9 env43599 = env43600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43599 == env43600) = true)

theorem identity43600 : scanCanonicalize (H12AffineFastState.compose env43600 (packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound43600 : packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env43601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,272392,16,3,8193,64,203846,5393,77834,406604,75102,272393,256,33,5457,513]

theorem envBound43601 : H12AffineFastState.Bounded env43601 := by
  intro p hp
  have h : env43601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43600_43601 : H12AffineEnvironment.transform 20 77898 env43600 = env43601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env43600 == env43601) = true)

theorem identity43601 : scanCanonicalize (H12AffineFastState.compose env43601 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound43601 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79131,262144,1024,8540,77898,272392,16,3,8193,64,10589,5393,77834,328023,75102,272393,256,33,5457,513]

theorem envBound43602 : H12AffineFastState.Bounded env43602 := by
  intro p hp
  have h : env43602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43601_43602 : H12AffineEnvironment.transform 16 79131 env43601 = env43602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env43601 == env43602) = true)

theorem identity43602 : scanCanonicalize (H12AffineFastState.compose env43602 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43602 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env43603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5393,262144,1024,8540,4160,272392,16,3,8193,64,10589,5393,4096,270685,1364,272393,256,33,5457,513]

theorem envBound43603 : H12AffineFastState.Bounded env43603 := by
  intro p hp
  have h : env43603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43602_43603 : H12AffineEnvironment.transform 15 8202 env43602 = env43603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43602 == env43603) = true)

theorem identity43603 : scanCanonicalize (H12AffineFastState.compose env43603 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43603 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43604 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,5393,262144,1024,8460,4112,272392,16,3,8193,16,10509,5393,4096,270605,1284,272393,256,33,5377,513]

theorem envBound43604 : H12AffineFastState.Bounded env43604 := by
  intro p hp
  have h : env43604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43603_43604 : H12AffineEnvironment.transform 5 16 env43603 = env43604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43603 == env43604) = true)

theorem identity43604 : scanCanonicalize (H12AffineFastState.compose env43604 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43605 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8232,8202,5172,262144,1024,8233,4112,272392,16,3,8193,16,10280,5172,4096,270376,1057,272393,37,33,5156,513]

theorem envBound43605 : H12AffineFastState.Bounded env43605 := by
  intro p hp
  have h : env43605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43604_43605 : H12AffineEnvironment.transform 7 37 env43604 = env43605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43604 == env43605) = true)

theorem identity43605 : scanCanonicalize (H12AffineFastState.compose env43605 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43605 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43606 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,262144,1024,1,4112,264224,16,3,41,16,2048,5172,4096,262144,1057,264225,37,33,5156,513]

theorem envBound43606 : H12AffineFastState.Bounded env43606 := by
  intro p hp
  have h : env43606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43605_43606 : H12AffineEnvironment.transform 12 40 env43605 = env43606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43605 == env43606) = true)

theorem identity43606 : scanCanonicalize (H12AffineFastState.compose env43606 (packedSelected [10] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound43606 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env43607 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4112,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound43607 : H12AffineFastState.Bounded env43607 := by
  intro p hp
  have h : env43607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43606_43607 : H12AffineEnvironment.transform 17 2049 env43606 = env43607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env43606 == env43607) = true)

def env43608 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,0,34,1028,2049,1024,1,32,33,16,3,41,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound43608 : H12AffineFastState.Bounded env43608 := by
  intro p hp
  have h : env43608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43607_43608 : H12AffineEnvironment.transform 11 48 env43607 = env43608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43607 == env43608) = true)

theorem identity43608 : scanCanonicalize (H12AffineFastState.compose env43608 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43609 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,40,33,0,34,49,2049,53,1,32,33,16,3,41,16,2048,49,48,2049,20,32,37,33,33,513]

theorem envBound43609 : H12AffineFastState.Bounded env43609 := by
  intro p hp
  have h : env43609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43608_43609 : H12AffineEnvironment.transform 9 53 env43608 = env43609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43608 == env43609) = true)

end H12CloudChart1