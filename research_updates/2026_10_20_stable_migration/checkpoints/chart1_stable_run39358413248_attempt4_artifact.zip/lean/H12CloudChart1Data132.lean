import H12CloudChart1Data131

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound33494 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33495 : List Nat := [2,4,8,16,1,64,8,85,90,1024,1044,4096,8,5204,0,3,5188,1044,1024,1,4160,1,16,3,8,64,1045,5188,4097,1045,1024,0,85,0,5124,90]

theorem envBound33495 : H12AffineFastState.Bounded env33495 := by
  intro p hp
  have h : env33495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33494_33495 : H12AffineEnvironment.transform 8 90 env33494 = env33495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env33494 == env33495) = true)

theorem identity33495 : scanCanonicalize (H12AffineFastState.compose env33495 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 7) := by decide +kernel

theorem selectedBound33495 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33496 : List Nat := [2,4,8,16,1,64,8,85,90,1024,1044,7,8,1107,0,3,1091,1044,1024,1,71,1,16,3,8,64,1045,1091,6,1045,1024,0,85,0,1027,90]

theorem envBound33496 : H12AffineFastState.Bounded env33496 := by
  intro p hp
  have h : env33496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33495_33496 : H12AffineEnvironment.transform 11 7 env33495 = env33496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 7 env33495 == env33496) = true)

theorem identity33496 : scanCanonicalize (H12AffineFastState.compose env33496 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33496 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env33497 : List Nat := [2,4,8,16,1,64,8,85,90,4,16,7,8,87,0,3,71,16,4,1,71,1,16,3,8,64,17,71,6,17,4,0,85,0,7,90]

theorem envBound33497 : H12AffineFastState.Bounded env33497 := by
  intro p hp
  have h : env33497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33496_33497 : H12AffineEnvironment.transform 9 4 env33496 = env33497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33496 == env33497) = true)

def env33498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,16777216,8193,64,21039477,18949464,2118976,2420,16852317,23160137,256,18965865,18949401,16777730]

theorem envBound33498 : H12AffineFastState.Bounded env33498 := by
  intro p hp
  have h : env33498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33484_33498 : H12AffineEnvironment.transform 6 9 env33484 = env33498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33484 == env33498) = true)

theorem identity33498 : scanCanonicalize (H12AffineFastState.compose env33498 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33498 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,2097152,4194304,16,16777216,8193,64,20982142,18875731,2118976,2420,16778582,23086402,256,18892130,18875666,16777730]

theorem envBound33499 : H12AffineFastState.Bounded env33499 := by
  intro p hp
  have h : env33499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33498_33499 : H12AffineEnvironment.transform 15 8203 env33498 = env33499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33498 == env33499) = true)

theorem identity33499 : scanCanonicalize (H12AffineFastState.compose env33499 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound33499 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env33500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,2097152,32,16,16777216,8193,64,16787806,18875731,2118976,2420,16778582,18892130,256,18892130,18875666,16777730]

theorem envBound33500 : H12AffineFastState.Bounded env33500 := by
  intro p hp
  have h : env33500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33499_33500 : H12AffineEnvironment.transform 21 32 env33499 = env33500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env33499 == env33500) = true)

theorem identity33500 : scanCanonicalize (H12AffineFastState.compose env33500 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 13689) := by decide +kernel

theorem selectedBound33500 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env33501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,13689,32,16,16777216,8193,64,16787806,16789546,24633,2420,16778582,16805915,256,16805915,16789611,16777730]

theorem envBound33501 : H12AffineFastState.Bounded env33501 := by
  intro p hp
  have h : env33501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33500_33501 : H12AffineEnvironment.transform 20 13689 env33500 = env33501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13689 env33500 == env33501) = true)

theorem identity33501 : scanCanonicalize (H12AffineFastState.compose env33501 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33501 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env33502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4096,10280,1024,8540,13689,32,16,16777216,8193,64,16787806,16789546,12329,2420,16778582,16785419,256,16785419,16789611,16777730]

theorem envBound33502 : H12AffineFastState.Bounded env33502 := by
  intro p hp
  have h : env33502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33501_33502 : H12AffineEnvironment.transform 13 4112 env33501 = env33502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33501 == env33502) = true)

theorem identity33502 : scanCanonicalize (H12AffineFastState.compose env33502 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33502 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4112,372,34,4096,2049,1024,373,5456,32,16,16777216,40,64,16779639,16781315,4096,2420,16778582,16777250,256,16777250,16781378,16777730]

theorem envBound33503 : H12AffineFastState.Bounded env33503 := by
  intro p hp
  have h : env33503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33502_33503 : H12AffineEnvironment.transform 12 41 env33502 = env33503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33502 == env33503) = true)

theorem identity33503 : scanCanonicalize (H12AffineFastState.compose env33503 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound33503 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33504 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,4096,41,4112,372,34,4096,2049,69,373,4373,32,16,16777216,40,64,16779639,16781315,4096,2420,16777491,16777250,256,16777250,16781378,16777730]

theorem envBound33504 : H12AffineFastState.Bounded env33504 := by
  intro p hp
  have h : env33504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33503_33504 : H12AffineEnvironment.transform 9 69 env33503 = env33504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env33503 == env33504) = true)

def env33505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,147457,16777216,8328,64,21307740,18949585,2233681,270685,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound33505 : H12AffineFastState.Bounded env33505 := by
  intro p hp
  have h : env33505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33426_33505 : H12AffineEnvironment.transform 22 147457 env33426 = env33505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env33426 == env33505) = true)

theorem identity33505 : scanCanonicalize (H12AffineFastState.compose env33505 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147611) := by decide +kernel

theorem selectedBound33505 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,147457,147611,8328,64,4678087,2319690,2233681,270685,75223,6497627,256,2188650,2172307,513]

theorem envBound33506 : H12AffineFastState.Bounded env33506 := by
  intro p hp
  have h : env33506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33505_33506 : H12AffineEnvironment.transform 23 147611 env33505 = env33506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147611 env33505 == env33506) = true)

def env33507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147457,147611,8328,64,4409703,2319690,2233681,2557,75223,6497627,256,2188650,2172307,513]

theorem envBound33507 : H12AffineFastState.Bounded env33507 := by
  intro p hp
  have h : env33507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33506_33507 : H12AffineEnvironment.transform 17 10400 env33506 = env33507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33506 == env33507) = true)

def env33508 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,4194304,147457,147611,8328,16,4409655,2319642,2233601,2477,75143,6497547,256,2188602,2172307,513]

theorem envBound33508 : H12AffineFastState.Bounded env33508 := by
  intro p hp
  have h : env33508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33507_33508 : H12AffineEnvironment.transform 5 16 env33507 = env33508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33507 == env33508) = true)

theorem identity33508 : scanCanonicalize (H12AffineFastState.compose env33508 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 155964) := by decide +kernel

theorem selectedBound33508 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env33509 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,155964,147457,147611,8328,16,75787,2319642,2233601,2477,75143,2180151,256,2188602,2172307,513]

theorem envBound33509 : H12AffineFastState.Bounded env33509 := by
  intro p hp
  have h : env33509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33508_33509 : H12AffineEnvironment.transform 21 155964 env33508 = env33509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155964 env33508 == env33509) = true)

theorem identity33509 : scanCanonicalize (H12AffineFastState.compose env33509 (packedSelected [2,3,4,5,6,11,14,15,16,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound33509 : packedSelected [2,3,4,5,6,11,14,15,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env33510 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,398,131072,10400,1024,8460,2097152,155964,147457,147611,8328,16,10629,2253972,2233601,2477,9225,2115001,256,2122932,2106397,513]

theorem envBound33510 : H12AffineFastState.Bounded env33510 := by
  intro p hp
  have h : env33510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33509_33510 : H12AffineEnvironment.transform 15 398 env33509 = env33510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env33509 == env33510) = true)

theorem identity33510 : scanCanonicalize (H12AffineFastState.compose env33510 (packedSelected [10,11,14,15,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 140421) := by decide +kernel

theorem selectedBound33510 : packedSelected [10,11,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env33511 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,398,131072,10400,1024,8460,140421,155964,147457,147611,8328,16,10629,16401,12676,2477,9225,155964,256,147505,131224,513]

theorem envBound33511 : H12AffineFastState.Bounded env33511 := by
  intro p hp
  have h : env33511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33510_33511 : H12AffineEnvironment.transform 20 140421 env33510 = env33511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140421 env33510 == env33511) = true)

theorem identity33511 : scanCanonicalize (H12AffineFastState.compose env33511 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound33511 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env33512 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,398,16537,10400,1024,8460,25628,8613,152,2,8328,16,10629,16401,12676,2477,9225,8613,256,168,16385,513]

theorem envBound33512 : H12AffineFastState.Bounded env33512 := by
  intro p hp
  have h : env33512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33511_33512 : H12AffineEnvironment.transform 16 16537 env33511 = env33512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env33511 == env33512) = true)

theorem identity33512 : scanCanonicalize (H12AffineFastState.compose env33512 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33512 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33513 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,137,398,16537,2340,1024,136,17816,33,152,2,268,16,2049,16401,4096,2477,1421,33,256,168,16385,513]

theorem envBound33513 : H12AffineFastState.Bounded env33513 := by
  intro p hp
  have h : env33513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33512_33513 : H12AffineEnvironment.transform 12 388 env33512 = env33513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33512 == env33513) = true)

theorem identity33513 : scanCanonicalize (H12AffineFastState.compose env33513 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33513 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33514 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,262,16401,2340,1024,0,17680,33,16,2,268,16,2049,16401,4096,2341,1285,33,256,32,16385,513]

theorem envBound33514 : H12AffineFastState.Bounded env33514 := by
  intro p hp
  have h : env33514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33513_33514 : H12AffineEnvironment.transform 6 8 env33513 = env33514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33513 == env33514) = true)

theorem identity33514 : scanCanonicalize (H12AffineFastState.compose env33514 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33514 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33515 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,268,16384,1,262,16401,2340,273,0,16385,33,16,2,268,16,2049,16401,4096,2341,20,33,256,32,16385,513]

theorem envBound33515 : H12AffineFastState.Bounded env33515 := by
  intro p hp
  have h : env33515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33514_33515 : H12AffineEnvironment.transform 9 273 env33514 = env33515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33514 == env33515) = true)

theorem identity33515 : scanCanonicalize (H12AffineFastState.compose env33515 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound33515 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33516 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2064,268,16384,1,262,16401,2340,273,0,16385,33,16,2,268,16,2049,16401,2064,2341,20,33,256,32,16385,513]

theorem envBound33516 : H12AffineFastState.Bounded env33516 := by
  intro p hp
  have h : env33516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33515_33516 : H12AffineEnvironment.transform 11 2064 env33515 = env33516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env33515 == env33516) = true)

theorem identity33516 : scanCanonicalize (H12AffineFastState.compose env33516 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33516 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33517 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,41,16384,1,35,16401,2049,52,0,16385,33,16,2,41,16,2049,16401,2064,2048,20,33,37,32,16385,513]

theorem envBound33517 : H12AffineFastState.Bounded env33517 := by
  intro p hp
  have h : env33517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33516_33517 : H12AffineEnvironment.transform 7 37 env33516 = env33517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33516 == env33517) = true)

theorem identity33517 : scanCanonicalize (H12AffineFastState.compose env33517 (packedSelected [10] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound33517 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env33518 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,41,2049,1,35,2064,2049,52,0,2048,33,16,2,41,16,2049,2064,2064,2048,20,33,37,32,2048,513]

theorem envBound33518 : H12AffineFastState.Bounded env33518 := by
  intro p hp
  have h : env33518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33517_33518 : H12AffineEnvironment.transform 13 2049 env33517 = env33518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env33517 == env33518) = true)

theorem identity33518 : scanCanonicalize (H12AffineFastState.compose env33518 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33519 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,41,48,1,35,33,48,52,0,49,33,16,2,41,16,48,33,33,49,20,33,37,32,49,513]

theorem envBound33519 : H12AffineFastState.Bounded env33519 := by
  intro p hp
  have h : env33519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33518_33519 : H12AffineEnvironment.transform 10 49 env33518 = env33519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33518 == env33519) = true)

def leafEnv33519 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,41,48,1,35,33,48,52,0,49,33,16,2,20,41,1,16,48,33,33,49,20,33,37,32,4,35,49,513,1,48,0]

def active33519 : List Nat := [0,1,2,3,4,8]

def tree33519 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33519 : H12WitnessSearch.Good tree33519 := H12GlobalWitnessIndex.good

theorem leafIdentity33519 : H12AffineFastState.composeSystem env33519 rootObs = leafEnv33519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33519 rootObs == leafEnv33519) = true)

theorem terminalChecked33519 : H12PackedTerminal.terminalCheckFast leafEnv33519 active33519 tree33519 = true := by decide +kernel

def env33520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,4194304,147457,147611,8328,17,4409654,2319643,2233600,2476,75142,6497546,256,2188603,2172307,513]

theorem envBound33520 : H12AffineFastState.Bounded env33520 := by
  intro p hp
  have h : env33520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33507_33520 : H12AffineEnvironment.transform 5 17 env33507 = env33520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33507 == env33520) = true)

theorem identity33520 : scanCanonicalize (H12AffineFastState.compose env33520 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 2294822) := by decide +kernel

theorem selectedBound33520 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env33521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,2294822,147457,147611,8328,17,2116880,2319643,2233600,2476,75142,8492,256,2188603,2172307,513]

theorem envBound33521 : H12AffineFastState.Bounded env33521 := by
  intro p hp
  have h : env33521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33520_33521 : H12AffineEnvironment.transform 21 2294822 env33520 = env33521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2294822 env33520 == env33521) = true)

theorem identity33521 : scanCanonicalize (H12AffineFastState.compose env33521 (packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound33521 : packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env33522 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,65536,131072,2341,1024,136,2097152,2294822,147457,147611,269,17,2116880,2311326,2233600,2476,66563,169,256,2180286,2163734,513]

theorem envBound33522 : H12AffineFastState.Bounded env33522 := by
  intro p hp
  have h : env33522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33521_33522 : H12AffineEnvironment.transform 12 389 env33521 = env33522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env33521 == env33522) = true)

theorem identity33522 : scanCanonicalize (H12AffineFastState.compose env33522 (packedSelected [0,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound33522 : packedSelected [0,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env33523 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,65536,16536,2341,1024,136,2097152,2180286,153,3,269,17,2116880,2163718,2119064,2476,66563,169,256,2180286,2163734,513]

theorem envBound33523 : H12AffineFastState.Bounded env33523 := by
  intro p hp
  have h : env33523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33522_33523 : H12AffineEnvironment.transform 16 16536 env33522 = env33523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env33522 == env33523) = true)

theorem identity33523 : scanCanonicalize (H12AffineFastState.compose env33523 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(20+1) ^^^ 17817) := by decide +kernel

theorem selectedBound33523 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env33524 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,65536,16536,2341,1024,136,17817,65831,153,3,269,17,2185,82335,4097,2476,66563,169,256,65831,82319,513]

theorem envBound33524 : H12AffineFastState.Bounded env33524 := by
  intro p hp
  have h : env33524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33523_33524 : H12AffineEnvironment.transform 20 17817 env33523 = env33524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17817 env33523 == env33524) = true)

theorem identity33524 : scanCanonicalize (H12AffineFastState.compose env33524 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound33524 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env33525 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,262,16536,2341,1024,136,17817,33,153,3,269,17,2185,16537,4097,2476,1285,169,256,33,16521,513]

theorem envBound33525 : H12AffineFastState.Bounded env33525 := by
  intro p hp
  have h : env33525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33524_33525 : H12AffineEnvironment.transform 15 262 env33524 = env33525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env33524 == env33525) = true)

theorem identity33525 : scanCanonicalize (H12AffineFastState.compose env33525 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33526 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,16401,2341,1024,1,17680,33,16,3,269,17,2048,16400,4097,2341,1285,32,256,33,16384,513]

theorem envBound33526 : H12AffineFastState.Bounded env33526 := by
  intro p hp
  have h : env33526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33525_33526 : H12AffineEnvironment.transform 6 9 env33525 = env33526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33525 == env33526) = true)

theorem identity33526 : scanCanonicalize (H12AffineFastState.compose env33526 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound33526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33527 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5157,0,262,5172,2341,1024,1,4405,33,16,3,269,17,2048,5173,4097,2341,1285,32,256,33,5157,513]

theorem envBound33527 : H12AffineFastState.Bounded env33527 := by
  intro p hp
  have h : env33527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33526_33527 : H12AffineEnvironment.transform 13 5157 env33526 = env33527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env33526 == env33527) = true)

def env33528 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2837,0,262,2820,2341,1024,1,3589,33,16,3,269,17,2048,2821,3889,2341,1285,32,256,33,2837,513]

theorem envBound33528 : H12AffineFastState.Bounded env33528 := by
  intro p hp
  have h : env33528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33527_33528 : H12AffineEnvironment.transform 11 3888 env33527 = env33528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env33527 == env33528) = true)

def env33529 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1045,0,262,1028,1573,1024,1,261,33,16,3,269,17,1792,1029,49,1573,1285,32,256,33,1045,513]

theorem envBound33529 : H12AffineFastState.Bounded env33529 := by
  intro p hp
  have h : env33529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33528_33529 : H12AffineEnvironment.transform 10 1792 env33528 = env33529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env33528 == env33529) = true)

theorem identity33529 : scanCanonicalize (H12AffineFastState.compose env33529 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33530 : List Nat := [2,4,8,16,32,17,9,256,512,273,529,48,268,260,0,262,277,820,273,1,261,33,16,3,269,17,529,276,49,820,20,32,256,33,260,513]

theorem envBound33530 : H12AffineFastState.Bounded env33530 := by
  intro p hp
  have h : env33530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33529_33530 : H12AffineEnvironment.transform 9 273 env33529 = env33530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33529 == env33530) = true)

def env33531 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,32,0,34,49,528,53,1,33,33,16,3,41,17,529,48,49,528,20,32,36,33,32,513]

theorem envBound33531 : H12AffineFastState.Bounded env33531 := by
  intro p hp
  have h : env33531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33530_33531 : H12AffineEnvironment.transform 7 36 env33530 = env33531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33530 == env33531) = true)

theorem identity33531 : scanCanonicalize (H12AffineFastState.compose env33531 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound33531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33532 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,48,40,32,0,34,49,59,53,1,33,33,16,3,41,17,58,48,49,59,20,32,36,33,32,42]

theorem envBound33532 : H12AffineFastState.Bounded env33532 := by
  intro p hp
  have h : env33532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33531_33532 : H12AffineEnvironment.transform 8 43 env33531 = env33532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env33531 == env33532) = true)

def leafEnv33532 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,48,40,32,0,34,49,59,53,1,33,33,16,3,20,41,1,17,58,48,49,59,20,32,36,33,4,35,32,42,1,33,0]

def active33532 : List Nat := [0,1,2,3,4]

def tree33532 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33532 : H12WitnessSearch.Good tree33532 := H12GlobalWitnessIndex.good

theorem leafIdentity33532 : H12AffineFastState.composeSystem env33532 rootObs = leafEnv33532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33532 rootObs == leafEnv33532) = true)

theorem terminalChecked33532 : H12PackedTerminal.terminalCheckFast leafEnv33532 active33532 tree33532 = true := by decide +kernel

def env33533 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,48,41,33,0,35,48,529,52,1,32,33,16,3,40,17,529,49,49,529,20,32,37,33,33,513]

theorem envBound33533 : H12AffineFastState.Bounded env33533 := by
  intro p hp
  have h : env33533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33530_33533 : H12AffineEnvironment.transform 7 37 env33530 = env33533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33530 == env33533) = true)

def env33534 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1044,0,262,1029,1572,1024,1,260,33,16,3,269,17,1793,1028,48,1572,1285,32,256,33,1044,513]

theorem envBound33534 : H12AffineFastState.Bounded env33534 := by
  intro p hp
  have h : env33534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33528_33534 : H12AffineEnvironment.transform 10 1793 env33528 = env33534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env33528 == env33534) = true)

def env33535 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,49,268,32,0,262,49,528,52,1,260,33,16,3,269,17,821,48,48,528,305,32,256,33,32,513]

theorem envBound33535 : H12AffineFastState.Bounded env33535 := by
  intro p hp
  have h : env33535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33534_33535 : H12AffineEnvironment.transform 9 52 env33534 = env33535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33534 == env33535) = true)

def env33536 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,49,268,33,0,262,48,529,53,1,260,33,16,3,269,17,820,49,48,529,304,32,256,33,33,513]

theorem envBound33536 : H12AffineFastState.Bounded env33536 := by
  intro p hp
  have h : env33536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33534_33536 : H12AffineEnvironment.transform 9 53 env33534 = env33536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33534 == env33536) = true)

theorem identity33536 : scanCanonicalize (H12AffineFastState.compose env33536 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound33536 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33537 : List Nat := [2,4,8,16,32,17,9,256,270,53,58,49,268,33,0,262,48,287,53,1,260,33,16,3,269,17,58,49,48,287,304,32,256,33,33,271]

theorem envBound33537 : H12AffineFastState.Bounded env33537 := by
  intro p hp
  have h : env33537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33536_33537 : H12AffineEnvironment.transform 8 270 env33536 = env33537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env33536 == env33537) = true)

def leafEnv33537 : List Nat := [2,4,8,16,32,17,9,256,270,53,58,49,268,33,0,262,48,287,53,1,260,33,16,3,304,269,1,17,58,49,48,287,304,32,256,33,4,263,33,271,1,260,0]

def active33537 : List Nat := [0,1,2,3,4,7]

def tree33537 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33537 : H12WitnessSearch.Good tree33537 := H12GlobalWitnessIndex.good

theorem leafIdentity33537 : H12AffineFastState.composeSystem env33537 rootObs = leafEnv33537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33537 rootObs == leafEnv33537) = true)

theorem terminalChecked33537 : H12PackedTerminal.terminalCheckFast leafEnv33537 active33537 tree33537 = true := by decide +kernel

def env33538 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2836,0,262,2821,2341,1024,1,3588,33,16,3,269,17,2048,2820,3888,2341,1285,32,256,33,2836,513]

theorem envBound33538 : H12AffineFastState.Bounded env33538 := by
  intro p hp
  have h : env33538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33527_33538 : H12AffineEnvironment.transform 11 3889 env33527 = env33538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env33527 == env33538) = true)

def env33539 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1044,0,262,1029,1573,1024,1,260,33,16,3,269,17,1792,1028,48,1573,1285,32,256,33,1044,513]

theorem envBound33539 : H12AffineFastState.Bounded env33539 := by
  intro p hp
  have h : env33539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33538_33539 : H12AffineEnvironment.transform 10 1792 env33538 = env33539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env33538 == env33539) = true)

theorem identity33539 : scanCanonicalize (H12AffineFastState.compose env33539 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33540 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,49,40,1044,0,34,1029,1573,1024,1,32,33,16,3,41,17,1572,1028,48,1573,1057,32,36,33,1044,513]

theorem envBound33540 : H12AffineFastState.Bounded env33540 := by
  intro p hp
  have h : env33540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33539_33540 : H12AffineEnvironment.transform 7 36 env33539 = env33540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33539 == env33540) = true)

def env33541 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,32,0,34,49,529,52,1,32,33,16,3,41,17,528,48,48,529,21,32,36,33,32,513]

theorem envBound33541 : H12AffineFastState.Bounded env33541 := by
  intro p hp
  have h : env33541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33540_33541 : H12AffineEnvironment.transform 9 52 env33540 = env33541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33540 == env33541) = true)

def env33542 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,40,33,0,34,48,528,53,1,32,33,16,3,41,17,529,49,48,528,20,32,36,33,33,513]

theorem envBound33542 : H12AffineFastState.Bounded env33542 := by
  intro p hp
  have h : env33542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33540_33542 : H12AffineEnvironment.transform 9 53 env33540 = env33542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33540 == env33542) = true)

theorem identity33542 : scanCanonicalize (H12AffineFastState.compose env33542 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33543 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,49,40,33,0,34,48,58,53,1,32,33,16,3,41,17,59,49,48,58,20,32,36,33,33,43]

theorem envBound33543 : H12AffineFastState.Bounded env33543 := by
  intro p hp
  have h : env33543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33542_33543 : H12AffineEnvironment.transform 8 42 env33542 = env33543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33542 == env33543) = true)

def leafEnv33543 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,49,40,33,0,34,48,58,53,1,32,33,16,3,20,41,1,17,59,49,48,58,20,32,36,33,4,35,33,43,1,32,0]

def active33543 : List Nat := [0,1,2,3,4]

def tree33543 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33543 : H12WitnessSearch.Good tree33543 := H12GlobalWitnessIndex.good

theorem leafIdentity33543 : H12AffineFastState.composeSystem env33543 rootObs = leafEnv33543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33543 rootObs == leafEnv33543) = true)

theorem terminalChecked33543 : H12PackedTerminal.terminalCheckFast leafEnv33543 active33543 tree33543 = true := by decide +kernel

def env33544 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1045,0,262,1028,1572,1024,1,261,33,16,3,269,17,1793,1029,49,1572,1285,32,256,33,1045,513]

theorem envBound33544 : H12AffineFastState.Bounded env33544 := by
  intro p hp
  have h : env33544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33538_33544 : H12AffineEnvironment.transform 10 1793 env33538 = env33544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env33538 == env33544) = true)

theorem identity33544 : scanCanonicalize (H12AffineFastState.compose env33544 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33545 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,48,268,32,0,262,49,529,53,1,261,33,16,3,269,17,820,48,49,529,304,32,256,33,32,513]

theorem envBound33545 : H12AffineFastState.Bounded env33545 := by
  intro p hp
  have h : env33545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33544_33545 : H12AffineEnvironment.transform 9 53 env33544 = env33545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33544 == env33545) = true)

theorem identity33545 : scanCanonicalize (H12AffineFastState.compose env33545 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound33545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33546 : List Nat := [2,4,8,16,32,17,9,256,271,53,59,48,268,32,0,262,49,286,53,1,261,33,16,3,269,17,59,48,49,286,304,32,256,33,32,270]

theorem envBound33546 : H12AffineFastState.Bounded env33546 := by
  intro p hp
  have h : env33546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33545_33546 : H12AffineEnvironment.transform 8 271 env33545 = env33546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env33545 == env33546) = true)

def leafEnv33546 : List Nat := [2,4,8,16,32,17,9,256,271,53,59,48,268,32,0,262,49,286,53,1,261,33,16,3,304,269,1,17,59,48,49,286,304,32,256,33,4,263,32,270,1,261,0]

def active33546 : List Nat := [0,1,2,3,4,7]

def tree33546 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33546 : H12WitnessSearch.Good tree33546 := H12GlobalWitnessIndex.good

theorem leafIdentity33546 : H12AffineFastState.composeSystem env33546 rootObs = leafEnv33546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33546 rootObs == leafEnv33546) = true)

theorem terminalChecked33546 : H12PackedTerminal.terminalCheckFast leafEnv33546 active33546 tree33546 = true := by decide +kernel

def env33547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147457,147611,8328,64,4409702,2319690,2233681,2556,75223,6497627,256,2188650,2172307,513]

theorem envBound33547 : H12AffineFastState.Bounded env33547 := by
  intro p hp
  have h : env33547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33506_33547 : H12AffineEnvironment.transform 17 10401 env33506 = env33547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33506 == env33547) = true)

theorem identity33547 : scanCanonicalize (H12AffineFastState.compose env33547 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound33547 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env33548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10401,1024,8540,2097152,4194304,16,138,8328,64,4262263,2172251,2118976,2556,75223,6382922,256,2188650,2172307,513]

theorem envBound33548 : H12AffineFastState.Bounded env33548 := by
  intro p hp
  have h : env33548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33547_33548 : H12AffineEnvironment.transform 16 16401 env33547 = env33548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env33547 == env33548) = true)

theorem identity33548 : scanCanonicalize (H12AffineFastState.compose env33548 (packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33548 : packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10401,1024,8540,2097152,4194304,16,138,8328,64,4204925,2098513,2118976,2556,1501,6309184,256,2114912,2098585,513]

theorem envBound33549 : H12AffineFastState.Bounded env33549 := by
  intro p hp
  have h : env33549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33548_33549 : H12AffineEnvironment.transform 15 8202 env33548 = env33549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33548 == env33549) = true)

theorem identity33549 : scanCanonicalize (H12AffineFastState.compose env33549 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 5593) := by decide +kernel

theorem selectedBound33549 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10401,1024,8540,5593,4194304,16,138,8328,64,4204925,4232,16537,2556,1501,4214937,256,20665,4160,513]

theorem envBound33550 : H12AffineFastState.Bounded env33550 := by
  intro p hp
  have h : env33550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33549_33550 : H12AffineEnvironment.transform 20 5593 env33549 = env33550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5593 env33549 == env33550) = true)

theorem identity33550 : scanCanonicalize (H12AffineFastState.compose env33550 (packedSelected [0,3,5,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 20713) := by decide +kernel

theorem selectedBound33550 : packedSelected [0,3,5,10,14,27] rootPS < 2^1333 := by decide +kernel

def env33551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10401,1024,8540,5593,20713,16,138,8328,64,31124,4232,16537,2556,1501,112,256,20665,4160,513]

theorem envBound33551 : H12AffineFastState.Bounded env33551 := by
  intro p hp
  have h : env33551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33550_33551 : H12AffineEnvironment.transform 21 20713 env33550 = env33551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20713 env33550 == env33551) = true)

theorem identity33551 : scanCanonicalize (H12AffineFastState.compose env33551 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 11625) := by decide +kernel

theorem selectedBound33551 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env33552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11625,8541,8202,11640,10401,1024,8540,5593,15744,16,138,8328,64,5373,4232,11760,2556,1501,112,256,15824,4160,513]

theorem envBound33552 : H12AffineFastState.Bounded env33552 := by
  intro p hp
  have h : env33552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33551_33552 : H12AffineEnvironment.transform 13 11625 env33551 = env33552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11625 env33551 == env33552) = true)

theorem identity33552 : scanCanonicalize (H12AffineFastState.compose env33552 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound33552 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2209,1480,2556,2219,1497,0,1024,2557,5593,5409,16,138,2089,64,5373,4232,1361,2556,1501,112,256,5489,4160,513]

theorem envBound33553 : H12AffineFastState.Bounded env33553 := by
  intro p hp
  have h : env33553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33552_33553 : H12AffineEnvironment.transform 12 2209 env33552 = env33553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env33552 == env33553) = true)

theorem identity33553 : scanCanonicalize (H12AffineFastState.compose env33553 (packedSelected [1,8,10,11,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound33553 : packedSelected [1,8,10,11,15,23] rootPS < 2^1333 := by decide +kernel

def env33554 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,2209,429,2556,2219,444,0,101,2557,4540,4420,16,138,2089,64,4248,4232,308,2556,440,112,256,4372,4160,513]

theorem envBound33554 : H12AffineFastState.Bounded env33554 := by
  intro p hp
  have h : env33554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33553_33554 : H12AffineEnvironment.transform 9 101 env33553 = env33554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env33553 == env33554) = true)

theorem identity33554 : scanCanonicalize (H12AffineFastState.compose env33554 (packedSelected [2,3,6,8,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound33554 : packedSelected [2,3,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env33555 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,493,2209,429,2556,2219,444,0,101,2557,81,169,16,138,2089,64,373,357,308,2556,440,112,256,249,429,513]

theorem envBound33555 : H12AffineFastState.Bounded env33555 := by
  intro p hp
  have h : env33555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33554_33555 : H12AffineEnvironment.transform 11 493 env33554 = env33555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env33554 == env33555) = true)

theorem identity33555 : scanCanonicalize (H12AffineFastState.compose env33555 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound33555 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env33556 : List Nat := [2,4,8,16,32,64,128,256,512,101,509,493,348,429,1,342,444,0,101,0,81,169,16,138,468,64,373,357,308,1,440,112,256,249,429,513]

theorem envBound33556 : H12AffineFastState.Bounded env33556 := by
  intro p hp
  have h : env33556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33555_33556 : H12AffineEnvironment.transform 10 509 env33555 = env33556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env33555 == env33556) = true)

theorem identity33556 : scanCanonicalize (H12AffineFastState.compose env33556 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33556 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33557 : List Nat := [2,4,8,16,32,64,128,117,512,101,136,152,41,216,1,35,201,0,101,0,81,169,16,138,161,64,0,16,65,1,205,112,117,249,216,513]

theorem envBound33557 : H12AffineFastState.Bounded env33557 := by
  intro p hp
  have h : env33557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33556_33557 : H12AffineEnvironment.transform 7 117 env33556 = env33557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33556 == env33557) = true)

theorem identity33557 : scanCanonicalize (H12AffineFastState.compose env33557 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33557 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env33558 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,16,41,80,1,35,65,0,101,0,81,33,16,2,41,64,0,16,65,1,69,112,117,113,80,513]

theorem envBound33558 : H12AffineFastState.Bounded env33558 := by
  intro p hp
  have h : env33558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33557_33558 : H12AffineEnvironment.transform 6 8 env33557 = env33558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33557 == env33558) = true)

theorem identity33558 : scanCanonicalize (H12AffineFastState.compose env33558 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33559 : List Nat := [2,4,8,16,0,64,8,85,512,69,0,16,9,80,1,3,65,0,69,0,81,1,16,2,9,64,0,16,65,1,69,80,85,81,80,513]

theorem envBound33559 : H12AffineFastState.Bounded env33559 := by
  intro p hp
  have h : env33559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33558_33559 : H12AffineEnvironment.transform 4 0 env33558 = env33559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33558 == env33559) = true)

theorem identity33559 : scanCanonicalize (H12AffineFastState.compose env33559 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33559 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33560 : List Nat := [2,4,8,16,0,16,8,5,512,21,0,16,9,0,1,3,17,0,21,0,1,1,16,2,9,16,0,16,17,1,21,0,5,1,0,513]

theorem envBound33560 : H12AffineFastState.Bounded env33560 := by
  intro p hp
  have h : env33560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33559_33560 : H12AffineEnvironment.transform 5 16 env33559 = env33560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33559 == env33560) = true)

theorem identity33560 : scanCanonicalize (H12AffineFastState.compose env33560 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33561 : List Nat := [2,4,8,0,0,0,8,5,512,5,0,0,9,0,1,3,1,0,5,0,1,1,0,2,9,0,0,0,1,1,5,0,5,1,0,513]

theorem envBound33561 : H12AffineFastState.Bounded env33561 := by
  intro p hp
  have h : env33561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33560_33561 : H12AffineEnvironment.transform 3 0 env33560 = env33561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33560 == env33561) = true)

theorem identity33561 : scanCanonicalize (H12AffineFastState.compose env33561 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound33561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33562 : List Nat := [2,4,8,0,0,0,8,5,11,5,0,0,9,0,1,3,1,0,5,0,1,1,0,2,9,0,0,0,1,1,5,0,5,1,0,10]

theorem envBound33562 : H12AffineFastState.Bounded env33562 := by
  intro p hp
  have h : env33562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33561_33562 : H12AffineEnvironment.transform 8 11 env33561 = env33562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env33561 == env33562) = true)

theorem identity33562 : scanCanonicalize (H12AffineFastState.compose env33562 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33562 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33563 : List Nat := [2,4,2,0,0,0,2,5,1,5,0,0,3,0,1,3,1,0,5,0,1,1,0,2,3,0,0,0,1,1,5,0,5,1,0,0]

theorem envBound33563 : H12AffineFastState.Bounded env33563 := by
  intro p hp
  have h : env33563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33562_33563 : H12AffineEnvironment.transform 2 2 env33562 = env33563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33562 == env33563) = true)

def env33564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound33564 : H12AffineFastState.Bounded env33564 := by
  intro p hp
  have h : env33564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33424_33564 : H12AffineEnvironment.transform 18 1025 env33424 = env33564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env33424 == env33564) = true)

theorem identity33564 : scanCanonicalize (H12AffineFastState.compose env33564 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8602076) := by decide +kernel

theorem selectedBound33564 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8602076,8328,64,4489693,10667345,10507600,8830976,181708,14820380,257,2262384,2254037,254491]

theorem envBound33565 : H12AffineFastState.Bounded env33565 := by
  intro p hp
  have h : env33565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33564_33565 : H12AffineEnvironment.transform 23 8602076 env33564 = env33565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8602076 env33564 == env33565) = true)

def env33566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,8388608,8602076,8328,64,4489693,8393985,8553728,8830976,181708,12645452,257,21792,46213,254491]

theorem envBound33566 : H12AffineFastState.Bounded env33566 := by
  intro p hp
  have h : env33566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33565_33566 : H12AffineEnvironment.transform 20 184400 env33565 = env33566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env33565 == env33566) = true)

def env33567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,98780,8328,64,4489693,185601,17664,262144,181708,4338764,257,21792,46213,254491]

theorem envBound33567 : H12AffineFastState.Bounded env33567 := by
  intro p hp
  have h : env33567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33566_33567 : H12AffineEnvironment.transform 22 180224 env33566 = env33567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env33566 == env33567) = true)

def env33568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,98780,8328,64,43357,185601,17664,262144,181708,400588,257,21792,46213,254491]

theorem envBound33568 : H12AffineFastState.Bounded env33568 := by
  intro p hp
  have h : env33568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33567_33568 : H12AffineEnvironment.transform 21 272512 env33567 = env33568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33567 == env33568) = true)

theorem identity33568 : scanCanonicalize (H12AffineFastState.compose env33568 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound33568 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,115871,272512,120015,98780,8328,64,43357,115150,17664,262144,119043,329731,257,21792,46213,63188]

theorem envBound33569 : H12AffineFastState.Bounded env33569 := by
  intro p hp
  have h : env33569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33568_33569 : H12AffineEnvironment.transform 16 70863 env33568 = env33569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env33568 == env33569) = true)

theorem identity33569 : scanCanonicalize (H12AffineFastState.compose env33569 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound33569 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env33570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,70863,262144,1025,32769,110666,272512,106522,98780,8328,64,43357,111899,12757,262144,107990,329731,257,8693,46213,33281]

theorem envBound33570 : H12AffineFastState.Bounded env33570 := by
  intro p hp
  have h : env33570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33569_33570 : H12AffineEnvironment.transform 13 13525 env33569 = env33570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env33569 == env33570) = true)

theorem identity33570 : scanCanonicalize (H12AffineFastState.compose env33570 (packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33570 : packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env33571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,13508,262144,1025,32769,36929,272512,32785,41431,8328,64,43357,38160,12757,262144,34269,272392,257,8693,46213,33281]

theorem envBound33571 : H12AffineFastState.Bounded env33571 := by
  intro p hp
  have h : env33571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33570_33571 : H12AffineEnvironment.transform 15 8203 env33570 = env33571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33570 == env33571) = true)

def env33572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,32768,8203,13460,262144,1025,32769,36881,272512,32785,41351,8328,16,43277,38160,12677,262144,34189,272392,257,8613,46213,33281]

theorem envBound33572 : H12AffineFastState.Bounded env33572 := by
  intro p hp
  have h : env33572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33571_33572 : H12AffineEnvironment.transform 5 16 env33571 = env33572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33571 == env33572) = true)

theorem identity33572 : scanCanonicalize (H12AffineFastState.compose env33572 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound33572 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33573 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,32768,263,5528,262144,1025,32769,36881,264588,32785,32907,388,16,34817,38160,4233,262144,34189,264452,257,169,38281,33281]

theorem envBound33573 : H12AffineFastState.Bounded env33573 := by
  intro p hp
  have h : env33573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33572_33573 : H12AffineEnvironment.transform 12 268 env33572 = env33573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env33572 == env33573) = true)

theorem identity33573 : scanCanonicalize (H12AffineFastState.compose env33573 (packedSelected [0,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33573 : packedSelected [0,7,14,16] rootPS < 2^1333 := by decide +kernel

def env33574 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,41,5292,32768,34,5309,262144,1025,32769,36881,264361,32785,32907,161,16,34817,37941,4233,262144,33960,264225,36,169,38060,33281]

theorem envBound33574 : H12AffineFastState.Bounded env33574 := by
  intro p hp
  have h : env33574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33573_33574 : H12AffineEnvironment.transform 7 37 env33573 = env33574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33573 == env33574) = true)

theorem identity33574 : scanCanonicalize (H12AffineFastState.compose env33574 (packedSelected [0,2,6,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33574 : packedSelected [0,2,6,9,10] rootPS < 2^1333 := by decide +kernel

def env33575 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,32768,34,5172,262144,1025,32769,36881,264224,32785,32770,40,16,34817,37941,4096,262144,33825,264225,36,32,37925,33281]

theorem envBound33575 : H12AffineFastState.Bounded env33575 := by
  intro p hp
  have h : env33575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33574_33575 : H12AffineEnvironment.transform 6 9 env33574 = env33575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33574 == env33575) = true)

def env33576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,32768,8203,13461,262144,1025,32769,36880,272512,32785,41350,8328,17,43276,38160,12676,262144,34188,272392,257,8612,46213,33281]

theorem envBound33576 : H12AffineFastState.Bounded env33576 := by
  intro p hp
  have h : env33576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33571_33576 : H12AffineEnvironment.transform 5 17 env33571 = env33576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33571 == env33576) = true)

theorem identity33576 : scanCanonicalize (H12AffineFastState.compose env33576 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound33576 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,8580,8203,13461,262144,1025,8581,12692,272512,8597,2,8328,17,2184,13460,12676,262144,9224,272392,257,8612,5377,9093]

theorem envBound33577 : H12AffineFastState.Bounded env33577 := by
  intro p hp
  have h : env33577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33576_33577 : H12AffineEnvironment.transform 14 8580 env33576 = env33577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env33576 == env33577) = true)

theorem identity33577 : scanCanonicalize (H12AffineFastState.compose env33577 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33577 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env33578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,0,399,5393,262144,1025,1,4112,264452,17,2,268,17,2184,5392,4096,262144,1420,264588,257,32,5377,513]

theorem envBound33578 : H12AffineFastState.Bounded env33578 := by
  intro p hp
  have h : env33578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33577_33578 : H12AffineEnvironment.transform 12 388 env33577 = env33578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33577 == env33578) = true)

theorem identity33578 : scanCanonicalize (H12AffineFastState.compose env33578 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound33578 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,643,4096,388,5376,0,399,5393,262144,1025,1,4112,263047,17,2,268,17,523,5392,4096,262144,1420,262927,257,32,5377,513]

theorem envBound33579 : H12AffineFastState.Bounded env33579 := by
  intro p hp
  have h : env33579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33578_33579 : H12AffineEnvironment.transform 10 643 env33578 = env33579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env33578 == env33579) = true)

theorem identity33579 : scanCanonicalize (H12AffineFastState.compose env33579 (packedSelected [14] rootPS)) = affineNative (2^(17+1) ^^^ 522) := by decide +kernel

theorem selectedBound33579 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env33580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,643,4096,388,5376,0,399,5393,522,1025,1,4112,397,17,2,268,17,523,5392,4096,522,1420,261,257,32,5377,513]

theorem envBound33580 : H12AffineFastState.Bounded env33580 := by
  intro p hp
  have h : env33580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33579_33580 : H12AffineEnvironment.transform 17 522 env33579 = env33580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 522 env33579 == env33580) = true)

theorem identity33580 : scanCanonicalize (H12AffineFastState.compose env33580 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33580 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env33581 : List Nat := [2,4,8,16,32,17,128,4,512,1024,643,4096,128,5124,0,139,5141,522,1025,1,4112,137,17,2,8,17,523,5140,4096,522,1160,1,5,32,5125,513]

theorem envBound33581 : H12AffineFastState.Bounded env33581 := by
  intro p hp
  have h : env33581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33580_33581 : H12AffineEnvironment.transform 7 4 env33580 = env33581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33580 == env33581) = true)

theorem identity33581 : scanCanonicalize (H12AffineFastState.compose env33581 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33581 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env33582 : List Nat := [2,4,8,16,1,17,128,4,512,1024,643,4096,128,5124,0,139,5141,522,1025,1,4112,137,17,2,8,17,523,5140,4096,522,1160,1,5,1,5125,513]

theorem envBound33582 : H12AffineFastState.Bounded env33582 := by
  intro p hp
  have h : env33582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33581_33582 : H12AffineEnvironment.transform 4 1 env33581 = env33582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33581 == env33582) = true)

theorem identity33582 : scanCanonicalize (H12AffineFastState.compose env33582 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33582 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33583 : List Nat := [2,4,8,16,1,17,9,4,512,1024,522,4096,9,5124,0,2,5141,522,1025,1,4112,0,17,2,8,17,523,5140,4096,522,1025,1,5,1,5125,513]

theorem envBound33583 : H12AffineFastState.Bounded env33583 := by
  intro p hp
  have h : env33583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33582_33583 : H12AffineEnvironment.transform 6 9 env33582 = env33583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33582 == env33583) = true)

theorem identity33583 : scanCanonicalize (H12AffineFastState.compose env33583 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33584 : List Nat := [2,4,8,16,1,17,9,4,512,21,522,4096,9,4113,0,2,4096,522,20,1,4112,0,17,2,8,17,523,4097,4096,522,20,1,5,1,4112,513]

theorem envBound33584 : H12AffineFastState.Bounded env33584 := by
  intro p hp
  have h : env33584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33583_33584 : H12AffineEnvironment.transform 9 21 env33583 = env33584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33583 == env33584) = true)

theorem identity33584 : scanCanonicalize (H12AffineFastState.compose env33584 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound33584 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33585 : List Nat := [2,4,8,16,1,17,9,4,31,21,21,4096,9,4113,0,2,4096,21,20,1,4112,0,17,2,8,17,20,4097,4096,21,20,1,5,1,4112,30]

theorem envBound33585 : H12AffineFastState.Bounded env33585 := by
  intro p hp
  have h : env33585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33584_33585 : H12AffineEnvironment.transform 8 31 env33584 = env33585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env33584 == env33585) = true)

theorem identity33585 : scanCanonicalize (H12AffineFastState.compose env33585 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33586 : List Nat := [0,4,8,16,1,17,9,4,29,21,21,4096,9,4113,0,0,4096,21,20,1,4112,0,17,0,8,17,20,4097,4096,21,20,1,5,1,4112,28]

theorem envBound33586 : H12AffineFastState.Bounded env33586 := by
  intro p hp
  have h : env33586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33585_33586 : H12AffineEnvironment.transform 0 0 env33585 = env33586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33585 == env33586) = true)

theorem identity33586 : scanCanonicalize (H12AffineFastState.compose env33586 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound33586 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33587 : List Nat := [0,4,8,16,1,17,9,4,29,21,21,17,9,0,0,0,17,21,20,1,1,0,17,0,8,17,20,16,17,21,20,1,5,1,1,28]

theorem envBound33587 : H12AffineFastState.Bounded env33587 := by
  intro p hp
  have h : env33587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33586_33587 : H12AffineEnvironment.transform 11 17 env33586 = env33587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33586 == env33587) = true)

def env33588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,98780,8328,64,43356,185601,17664,262144,181708,400589,257,21792,46213,254491]

theorem envBound33588 : H12AffineFastState.Bounded env33588 := by
  intro p hp
  have h : env33588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33567_33588 : H12AffineEnvironment.transform 21 272513 env33567 = env33588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33567 == env33588) = true)

theorem identity33588 : scanCanonicalize (H12AffineFastState.compose env33588 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound33588 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184400,272513,180224,21762,8328,64,43356,185601,17664,262144,181708,400589,257,21792,46213,145093]

theorem envBound33589 : H12AffineFastState.Bounded env33589 := by
  intro p hp
  have h : env33589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33588_33589 : H12AffineEnvironment.transform 15 54494 env33588 = env33589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env33588 == env33589) = true)

def env33590 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,184320,272513,180224,21762,8328,16,43276,185601,17664,262144,181660,400541,257,21792,46213,145045]

theorem envBound33590 : H12AffineFastState.Bounded env33590 := by
  intro p hp
  have h : env33590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33589_33590 : H12AffineEnvironment.transform 5 16 env33589 = env33590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33589 == env33590) = true)

theorem identity33590 : scanCanonicalize (H12AffineFastState.compose env33590 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound33590 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env33591 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,179632,1025,32769,184320,169265,180224,21762,8328,16,43276,185601,17664,179632,181660,41261,257,21792,46213,145045]

theorem envBound33591 : H12AffineFastState.Bounded env33591 := by
  intro p hp
  have h : env33591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33590_33591 : H12AffineEnvironment.transform 17 179632 env33590 = env33591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env33590 == env33591) = true)

theorem identity33591 : scanCanonicalize (H12AffineFastState.compose env33591 (packedSelected [0,1,4,7,22,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound33591 : packedSelected [0,1,4,7,22,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33592 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,262,131072,157752,1025,21897,132488,147641,136584,21762,8328,16,31876,131209,17664,157752,135188,29861,257,21792,24845,145045]

theorem envBound33592 : H12AffineFastState.Bounded env33592 := by
  intro p hp
  have h : env33592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33591_33592 : H12AffineEnvironment.transform 14 21896 env33591 = env33592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env33591 == env33592) = true)

theorem identity33592 : scanCanonicalize (H12AffineFastState.compose env33592 (packedSelected [0,9,16,17,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound33592 : packedSelected [0,9,16,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env33593 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,262,13460,23724,1025,21897,12572,29741,8476,21762,8328,16,31876,13341,17664,23724,9344,29861,257,21792,24845,513]

theorem envBound33593 : H12AffineFastState.Bounded env33593 := by
  intro p hp
  have h : env33593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33592_33593 : H12AffineEnvironment.transform 16 13460 env33592 = env33593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env33592 == env33593) = true)

theorem identity33593 : scanCanonicalize (H12AffineFastState.compose env33593 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33593 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env33594 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,137,262,13460,2477,1025,136,12572,8492,8476,3,8328,16,10629,13341,4097,2477,9344,8612,257,33,13324,513]

theorem envBound33594 : H12AffineFastState.Bounded env33594 := by
  intro p hp
  have h : env33594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33593_33594 : H12AffineEnvironment.transform 13 5377 env33593 = env33594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33593 == env33594) = true)

theorem identity33594 : scanCanonicalize (H12AffineFastState.compose env33594 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33594 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33595 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5377,137,262,5392,2477,1025,136,4248,168,152,3,268,16,2049,5529,4097,2477,1284,32,257,33,5512,513]

theorem envBound33595 : H12AffineFastState.Bounded env33595 := by
  intro p hp
  have h : env33595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33594_33595 : H12AffineEnvironment.transform 12 388 env33594 = env33595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33594 == env33595) = true)

def env33596 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,184321,272513,180224,21762,8328,17,43277,185601,17664,262144,181661,400540,257,21792,46213,145044]

theorem envBound33596 : H12AffineFastState.Bounded env33596 := by
  intro p hp
  have h : env33596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33589_33596 : H12AffineEnvironment.transform 5 17 env33589 = env33596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33589 == env33596) = true)

theorem identity33596 : scanCanonicalize (H12AffineFastState.compose env33596 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound33596 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env33597 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,24860,262144,1025,32769,45341,272513,41244,21762,8328,17,43277,46109,17664,262144,42113,294272,257,21792,46213,22408]

theorem envBound33597 : H12AffineFastState.Bounded env33597 := by
  intro p hp
  have h : env33597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33596_33597 : H12AffineEnvironment.transform 16 24860 env33596 = env33597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env33596 == env33597) = true)

theorem identity33597 : scanCanonicalize (H12AffineFastState.compose env33597 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound33597 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env33598 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,40970,5529,262144,1025,32769,45341,272513,41244,8583,8328,17,43277,46109,12677,262144,42113,264453,257,8613,46213,8973]

theorem envBound33598 : H12AffineFastState.Bounded env33598 := by
  intro p hp
  have h : env33598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33597_33598 : H12AffineEnvironment.transform 13 13445 env33597 = env33598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env33597 == env33598) = true)

theorem identity33598 : scanCanonicalize (H12AffineFastState.compose env33598 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound33598 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env33599 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,40970,5529,43049,1025,32769,45341,32936,41244,8583,8328,17,43277,46109,12677,43049,42113,41260,257,8613,46213,8973]

theorem envBound33599 : H12AffineFastState.Bounded env33599 := by
  intro p hp
  have h : env33599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33598_33599 : H12AffineEnvironment.transform 17 43049 env33598 = env33599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env33598 == env33599) = true)

theorem identity33599 : scanCanonicalize (H12AffineFastState.compose env33599 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound33599 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env33600 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,32768,33167,5529,35244,1025,32769,37016,32936,32921,2,269,17,34952,38296,4096,35244,34052,32937,257,32,38144,648]

theorem envBound33600 : H12AffineFastState.Bounded env33600 := by
  intro p hp
  have h : env33600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33599_33600 : H12AffineEnvironment.transform 12 389 env33599 = env33600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env33599 == env33600) = true)

theorem identity33600 : scanCanonicalize (H12AffineFastState.compose env33600 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound33600 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33601 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,428,35,5529,2048,1025,429,4404,260,309,2,269,17,2340,5172,4096,2048,1192,261,257,32,5292,648]

theorem envBound33601 : H12AffineFastState.Bounded env33601 := by
  intro p hp
  have h : env33601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33600_33601 : H12AffineEnvironment.transform 14 428 env33600 = env33601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env33600 == env33601) = true)

theorem identity33601 : scanCanonicalize (H12AffineFastState.compose env33601 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound33601 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33602 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,4096,389,4541,428,35,4388,2048,188,429,4404,260,309,2,269,17,2340,4233,4096,2048,21,261,257,32,4113,648]

theorem envBound33602 : H12AffineFastState.Bounded env33602 := by
  intro p hp
  have h : env33602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33601_33602 : H12AffineEnvironment.transform 9 189 env33601 = env33602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env33601 == env33602) = true)

theorem identity33602 : scanCanonicalize (H12AffineFastState.compose env33602 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound33602 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env33603 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,4096,41,4113,0,35,4232,2048,188,1,4248,168,153,2,161,17,2184,4233,4096,2048,21,169,173,32,4113,648]

theorem envBound33603 : H12AffineFastState.Bounded env33603 := by
  intro p hp
  have h : env33603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33602_33603 : H12AffineEnvironment.transform 7 172 env33602 = env33603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33602 == env33603) = true)

theorem identity33603 : scanCanonicalize (H12AffineFastState.compose env33603 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound33603 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33604 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,48,41,33,0,35,184,2048,188,1,168,168,153,2,161,17,2184,185,48,2048,21,169,173,32,33,648]

theorem envBound33604 : H12AffineFastState.Bounded env33604 := by
  intro p hp
  have h : env33604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33603_33604 : H12AffineEnvironment.transform 11 48 env33603 = env33604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33603 == env33604) = true)

theorem identity33604 : scanCanonicalize (H12AffineFastState.compose env33604 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 141) := by decide +kernel

theorem selectedBound33604 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env33605 : List Nat := [2,4,8,16,32,17,128,172,512,189,141,48,41,33,0,35,184,141,188,1,168,168,153,2,161,17,5,185,48,141,21,169,173,32,33,648]

theorem envBound33605 : H12AffineFastState.Bounded env33605 := by
  intro p hp
  have h : env33605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33604_33605 : H12AffineEnvironment.transform 10 141 env33604 = env33605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 141 env33604 == env33605) = true)

theorem identity33605 : scanCanonicalize (H12AffineFastState.compose env33605 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 154) := by decide +kernel

theorem selectedBound33605 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env33606 : List Nat := [2,4,8,16,32,17,128,172,154,189,141,48,41,33,0,35,184,141,188,1,168,168,153,2,161,17,5,185,48,141,21,169,173,32,33,18]

theorem envBound33606 : H12AffineFastState.Bounded env33606 := by
  intro p hp
  have h : env33606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33605_33606 : H12AffineEnvironment.transform 8 154 env33605 = env33606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 154 env33605 == env33606) = true)

theorem identity33606 : scanCanonicalize (H12AffineFastState.compose env33606 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 44) := by decide +kernel

theorem selectedBound33606 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env33607 : List Nat := [2,4,8,16,32,17,44,0,54,17,33,48,41,33,0,35,20,33,16,1,4,4,53,2,13,17,5,21,48,33,21,5,1,32,33,18]

theorem envBound33607 : H12AffineFastState.Bounded env33607 := by
  intro p hp
  have h : env33607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33606_33607 : H12AffineEnvironment.transform 6 44 env33606 = env33607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env33606 == env33607) = true)

def env33608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,98781,8328,64,4489693,185600,17665,262145,181708,4338765,257,21792,46213,254491]

theorem envBound33608 : H12AffineFastState.Bounded env33608 := by
  intro p hp
  have h : env33608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33566_33608 : H12AffineEnvironment.transform 22 180225 env33566 = env33608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env33566 == env33608) = true)

def env33609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,98781,8328,64,43357,185600,17665,262145,181708,400589,257,21792,46213,254491]

theorem envBound33609 : H12AffineFastState.Bounded env33609 := by
  intro p hp
  have h : env33609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33608_33609 : H12AffineEnvironment.transform 21 272512 env33608 = env33609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33608 == env33609) = true)

theorem identity33609 : scanCanonicalize (H12AffineFastState.compose env33609 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound33609 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272512,73755,98781,8328,64,43357,79130,17665,262145,75222,392407,257,21792,46213,513]

theorem envBound33610 : H12AffineFastState.Bounded env33610 := by
  intro p hp
  have h : env33610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33609_33610 : H12AffineEnvironment.transform 16 122906 env33609 = env33610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env33609 == env33610) = true)

theorem identity33610 : scanCanonicalize (H12AffineFastState.compose env33610 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound33610 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env33611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1025,32769,77898,73891,73755,98781,8328,64,43357,79130,17665,67618,75222,62708,257,21792,46213,513]

theorem envBound33611 : H12AffineFastState.Bounded env33611 := by
  intro p hp
  have h : env33611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33610_33611 : H12AffineEnvironment.transform 17 67619 env33610 = env33611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env33610 == env33611) = true)

theorem identity33611 : scanCanonicalize (H12AffineFastState.compose env33611 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33611 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env33612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90139,67619,1025,0,77898,73891,73755,66012,8328,64,10588,79130,17665,67618,75222,29941,257,21792,13444,513]

theorem envBound33612 : H12AffineFastState.Bounded env33612 := by
  intro p hp
  have h : env33612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33611_33612 : H12AffineEnvironment.transform 14 1 env33611 = env33612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33611 == env33612) = true)

def env33613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90139,67619,1025,0,77898,73771,73755,65876,8192,64,10588,79130,17665,67618,75102,29821,257,21792,13324,513]

theorem envBound33613 : H12AffineFastState.Bounded env33613 := by
  intro p hp
  have h : env33613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33612_33613 : H12AffineEnvironment.transform 6 8 env33612 = env33613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33612 == env33613) = true)

theorem identity33613 : scanCanonicalize (H12AffineFastState.compose env33613 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33613 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16400,10280,1025,0,4161,32,16,8543,8192,64,10588,5393,17665,10281,1365,29821,257,21792,13324,513]

theorem envBound33614 : H12AffineFastState.Bounded env33614 := by
  intro p hp
  have h : env33614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33613_33614 : H12AffineEnvironment.transform 15 8203 env33613 = env33614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33613 == env33614) = true)

theorem identity33614 : scanCanonicalize (H12AffineFastState.compose env33614 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound33614 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1,1094,16400,3173,1025,0,4161,32,16,1298,1101,64,3345,5393,17665,3172,1365,20528,257,21792,4161,513]

theorem envBound33615 : H12AffineFastState.Bounded env33615 := by
  intro p hp
  have h : env33615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33614_33615 : H12AffineEnvironment.transform 12 1101 env33614 = env33615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env33614 == env33615) = true)

theorem identity33615 : scanCanonicalize (H12AffineFastState.compose env33615 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33615 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33616 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,16384,1,34,16400,2049,101,0,4161,32,16,374,41,64,2421,4469,16741,2048,305,20528,257,20804,4161,513]

theorem envBound33616 : H12AffineFastState.Bounded env33616 := by
  intro p hp
  have h : env33616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33615_33616 : H12AffineEnvironment.transform 9 100 env33615 = env33616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33615 == env33616) = true)

theorem identity33616 : scanCanonicalize (H12AffineFastState.compose env33616 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound33616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33617 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4405,1,34,4389,2049,101,0,4161,32,16,374,41,64,2421,4469,4176,2048,305,261,257,113,4161,513]

theorem envBound33617 : H12AffineFastState.Bounded env33617 := by
  intro p hp
  have h : env33617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33616_33617 : H12AffineEnvironment.transform 13 4405 env33616 = env33617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env33616 == env33617) = true)

theorem identity33617 : scanCanonicalize (H12AffineFastState.compose env33617 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound33617 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env33618 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,4096,41,4405,1,34,4389,292,101,0,4161,32,16,374,41,64,80,4469,4176,293,305,261,257,113,4161,513]

theorem envBound33618 : H12AffineFastState.Bounded env33618 := by
  intro p hp
  have h : env33618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33617_33618 : H12AffineEnvironment.transform 10 293 env33617 = env33618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env33617 == env33618) = true)

theorem identity33618 : scanCanonicalize (H12AffineFastState.compose env33618 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound33618 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33619 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,64,41,373,1,34,357,292,101,0,1,32,16,374,41,64,80,309,16,293,305,261,257,113,1,513]

theorem envBound33619 : H12AffineFastState.Bounded env33619 := by
  intro p hp
  have h : env33619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33618_33619 : H12AffineEnvironment.transform 11 64 env33618 = env33619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env33618 == env33619) = true)

theorem identity33619 : scanCanonicalize (H12AffineFastState.compose env33619 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33619 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33620 : List Nat := [2,4,8,16,32,16,8,256,512,52,293,16,41,293,1,34,309,292,53,0,1,32,16,294,41,16,0,309,16,293,305,261,257,33,1,513]

theorem envBound33620 : H12AffineFastState.Bounded env33620 := by
  intro p hp
  have h : env33620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33619_33620 : H12AffineEnvironment.transform 5 16 env33619 = env33620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33619 == env33620) = true)

theorem identity33620 : scanCanonicalize (H12AffineFastState.compose env33620 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33620 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33621 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,41,0,1,34,16,1,53,0,1,32,16,3,41,16,0,16,16,0,20,32,36,33,1,513]

theorem envBound33621 : H12AffineFastState.Bounded env33621 := by
  intro p hp
  have h : env33621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33620_33621 : H12AffineEnvironment.transform 7 37 env33620 = env33621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33620 == env33621) = true)

theorem identity33621 : scanCanonicalize (H12AffineFastState.compose env33621 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound33621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33622 : List Nat := [2,4,8,16,32,16,8,37,17,52,0,16,41,0,1,34,16,1,53,0,1,32,16,3,41,16,0,16,16,0,20,32,36,33,1,16]

theorem envBound33622 : H12AffineFastState.Bounded env33622 := by
  intro p hp
  have h : env33622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33621_33622 : H12AffineEnvironment.transform 8 17 env33621 = env33622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env33621 == env33622) = true)

theorem identity33622 : scanCanonicalize (H12AffineFastState.compose env33622 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound33622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33623 : List Nat := [2,4,8,16,26,16,8,31,17,14,0,16,19,0,1,24,16,1,15,0,1,26,16,3,19,16,0,16,16,0,20,26,30,27,1,16]

theorem envBound33623 : H12AffineFastState.Bounded env33623 := by
  intro p hp
  have h : env33623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33622_33623 : H12AffineEnvironment.transform 4 26 env33622 = env33623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env33622 == env33623) = true)

def env33624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,67619,1025,0,77898,73770,73755,65877,8193,64,10588,79130,17665,67618,75103,29820,257,21792,13325,513]

theorem envBound33624 : H12AffineFastState.Bounded env33624 := by
  intro p hp
  have h : env33624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33612_33624 : H12AffineEnvironment.transform 6 9 env33612 = env33624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33612 == env33624) = true)

theorem identity33624 : scanCanonicalize (H12AffineFastState.compose env33624 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33624 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,342,24909,2421,1025,0,12572,8572,8525,3,8193,64,10588,13388,17665,2420,9225,29820,257,21792,13325,513]

theorem envBound33625 : H12AffineFastState.Bounded env33625 := by
  intro p hp
  have h : env33625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33624_33625 : H12AffineEnvironment.transform 15 342 env33624 = env33625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33624 == env33625) = true)

theorem identity33625 : scanCanonicalize (H12AffineFastState.compose env33625 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound33625 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env33626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12392,1,342,4389,2421,1025,0,12572,8572,8525,3,8193,64,10588,13388,13673,2420,9225,1044,257,9544,13325,513]

theorem envBound33626 : H12AffineFastState.Bounded env33626 := by
  intro p hp
  have h : env33626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33625_33626 : H12AffineEnvironment.transform 13 12392 env33625 = env33626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env33625 == env33626) = true)

theorem identity33626 : scanCanonicalize (H12AffineFastState.compose env33626 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound33626 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,8192,11625,1,342,3108,2421,1025,0,11293,8572,8525,3,8193,64,10588,10573,10344,2420,9225,1044,257,9544,10508,513]

theorem envBound33627 : H12AffineFastState.Bounded env33627 := by
  intro p hp
  have h : env33627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33626_33627 : H12AffineEnvironment.transform 11 3329 env33626 = env33627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env33626 == env33627) = true)

theorem identity33627 : scanCanonicalize (H12AffineFastState.compose env33627 (packedSelected [0,1,7,8,10,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33627 : packedSelected [0,1,7,8,10,18] rootPS < 2^1333 := by decide +kernel

def env33628 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,8192,11340,1,115,3108,2128,1025,0,11293,8281,8296,3,8193,64,10361,10344,10344,2129,9225,1044,36,9325,10281,513]

theorem envBound33628 : H12AffineFastState.Bounded env33628 := by
  intro p hp
  have h : env33628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33627_33628 : H12AffineEnvironment.transform 7 37 env33627 = env33628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33627 == env33628) = true)

theorem identity33628 : scanCanonicalize (H12AffineFastState.compose env33628 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33628 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33629 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,120,3124,1,115,3108,2128,1025,0,3173,33,16,3,121,64,2049,2064,2064,2129,1137,1044,36,1045,2129,513]

theorem envBound33629 : H12AffineFastState.Bounded env33629 := by
  intro p hp
  have h : env33629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33628_33629 : H12AffineEnvironment.transform 12 120 env33628 = env33629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33628 == env33629) = true)

theorem identity33629 : scanCanonicalize (H12AffineFastState.compose env33629 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33629 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33630 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,120,2049,1,115,2065,2128,52,0,2128,33,16,3,121,64,2049,2064,2064,2129,68,33,36,32,2129,513]

theorem envBound33630 : H12AffineFastState.Bounded env33630 := by
  intro p hp
  have h : env33630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33629_33630 : H12AffineEnvironment.transform 9 53 env33629 = env33630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33629 == env33630) = true)

def env33631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,98781,8328,64,43356,185600,17665,262145,181708,400588,257,21792,46213,254491]

theorem envBound33631 : H12AffineFastState.Bounded env33631 := by
  intro p hp
  have h : env33631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33608_33631 : H12AffineEnvironment.transform 21 272513 env33608 = env33631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33608 == env33631) = true)

theorem identity33631 : scanCanonicalize (H12AffineFastState.compose env33631 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33631 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272513,180225,41431,8328,64,43356,185600,17665,262145,181708,400588,257,21792,46213,180753]

theorem envBound33632 : H12AffineFastState.Bounded env33632 := by
  intro p hp
  have h : env33632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33631_33632 : H12AffineEnvironment.transform 15 8202 env33631 = env33632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33631 == env33632) = true)

theorem identity33632 : scanCanonicalize (H12AffineFastState.compose env33632 (packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound33632 : packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env33633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190640,1025,32769,184400,180273,180225,41431,8328,64,43356,185600,17665,190641,181708,62588,257,21792,46213,180753]

theorem envBound33633 : H12AffineFastState.Bounded env33633 := by
  intro p hp
  have h : env33633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33632_33633 : H12AffineEnvironment.transform 17 190640 env33632 = env33633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env33632 == env33633) = true)

theorem identity33633 : scanCanonicalize (H12AffineFastState.compose env33633 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound33633 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,131072,157872,1025,1,151632,147505,147457,8663,8328,64,10588,152832,17665,157873,148940,29820,257,21792,13445,147985]

theorem envBound33634 : H12AffineFastState.Bounded env33634 := by
  intro p hp
  have h : env33634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33633_33634 : H12AffineEnvironment.transform 14 0 env33633 = env33634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env33633 == env33634) = true)

theorem identity33634 : scanCanonicalize (H12AffineFastState.compose env33634 (packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound33634 : packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS < 2^1333 := by decide +kernel

def env33635 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,0,8202,131072,157872,321,1,151632,147505,147457,8663,8328,64,10588,151616,16449,157873,147596,28988,257,20576,12741,147985]

theorem envBound33635 : H12AffineFastState.Bounded env33635 := by
  intro p hp
  have h : env33635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33634_33635 : H12AffineEnvironment.transform 9 320 env33634 = env33635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33634 == env33635) = true)

theorem identity33635 : scanCanonicalize (H12AffineFastState.compose env33635 (packedSelected [1,2,4,6,8,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound33635 : packedSelected [1,2,4,6,8,20,22,26] rootPS < 2^1333 := by decide +kernel

def env33636 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,0,8202,16536,10280,321,1,4296,169,153,8663,8328,64,10588,4312,16449,10281,20,28988,257,20576,12741,649]

theorem envBound33636 : H12AffineFastState.Bounded env33636 := by
  intro p hp
  have h : env33636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33635_33636 : H12AffineEnvironment.transform 16 16536 env33635 = env33636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env33635 == env33636) = true)

theorem identity33636 : scanCanonicalize (H12AffineFastState.compose env33636 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33636 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env33637 : List Nat := [2,4,8,16,32,64,128,256,512,320,1,4096,8192,16384,0,8202,16536,8233,321,1,4296,169,153,8663,8328,64,8541,4312,16449,8232,20,28988,257,20576,12741,649]

theorem envBound33637 : H12AffineFastState.Bounded env33637 := by
  intro p hp
  have h : env33637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33636_33637 : H12AffineEnvironment.transform 10 1 env33636 = env33637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33636 == env33637) = true)

theorem identity33637 : scanCanonicalize (H12AffineFastState.compose env33637 (packedSelected [1,2,4,8,9,10,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33637 : packedSelected [1,2,4,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env33638 : List Nat := [2,4,8,16,32,64,128,256,512,320,1,4096,8192,4112,0,8202,4232,8233,321,1,4296,169,153,8663,8328,64,8541,4312,4177,8232,20,8492,257,112,12741,649]

theorem envBound33638 : H12AffineFastState.Bounded env33638 := by
  intro p hp
  have h : env33638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33637_33638 : H12AffineEnvironment.transform 13 4112 env33637 = env33638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33637 == env33638) = true)

theorem identity33638 : scanCanonicalize (H12AffineFastState.compose env33638 (packedSelected [2,3,4,5,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound33638 : packedSelected [2,3,4,5,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33639 : List Nat := [2,4,8,16,32,64,128,256,512,320,1,153,8192,137,0,8202,17,8233,321,1,81,169,153,8663,8328,64,8541,65,200,8232,20,8492,257,112,8540,649]

theorem envBound33639 : H12AffineFastState.Bounded env33639 := by
  intro p hp
  have h : env33639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33638_33639 : H12AffineEnvironment.transform 11 153 env33638 = env33639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env33638 == env33639) = true)

theorem identity33639 : scanCanonicalize (H12AffineFastState.compose env33639 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33639 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33640 : List Nat := [2,4,8,16,32,64,128,4,512,68,1,153,8192,137,0,8202,17,8233,69,1,81,169,153,8403,8328,64,8281,65,200,8232,20,8232,5,112,8280,649]

theorem envBound33640 : H12AffineFastState.Bounded env33640 := by
  intro p hp
  have h : env33640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33639_33640 : H12AffineEnvironment.transform 7 4 env33639 = env33640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33639 == env33640) = true)

theorem identity33640 : scanCanonicalize (H12AffineFastState.compose env33640 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33640 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env33641 : List Nat := [2,4,8,16,32,64,8,4,512,68,1,17,8192,1,0,8202,17,8233,69,1,81,33,17,8283,8192,64,8281,65,64,8232,20,8232,5,112,8280,513]

theorem envBound33641 : H12AffineFastState.Bounded env33641 := by
  intro p hp
  have h : env33641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33640_33641 : H12AffineEnvironment.transform 6 8 env33640 = env33641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33640 == env33641) = true)

theorem identity33641 : scanCanonicalize (H12AffineFastState.compose env33641 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33641 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33642 : List Nat := [2,4,8,16,32,0,8,4,512,4,1,17,8192,1,0,8202,17,8233,5,1,17,33,17,8219,8192,0,8217,1,0,8232,20,8232,5,48,8216,513]

theorem envBound33642 : H12AffineFastState.Bounded env33642 := by
  intro p hp
  have h : env33642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33641_33642 : H12AffineEnvironment.transform 5 0 env33641 = env33642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33641 == env33642) = true)

theorem identity33642 : scanCanonicalize (H12AffineFastState.compose env33642 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound33642 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env33643 : List Nat := [2,4,8,16,26,0,8,4,512,4,1,17,8192,1,0,8202,17,8211,5,1,17,27,17,8219,8192,0,8217,1,0,8210,20,8210,5,10,8216,513]

theorem envBound33643 : H12AffineFastState.Bounded env33643 := by
  intro p hp
  have h : env33643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33642_33643 : H12AffineEnvironment.transform 4 26 env33642 = env33643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env33642 == env33643) = true)

theorem identity33643 : scanCanonicalize (H12AffineFastState.compose env33643 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33643 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env33644 : List Nat := [2,4,8,1,11,0,8,4,512,4,1,0,8192,1,0,8202,0,8194,5,1,0,10,0,8202,8192,0,8200,1,0,8195,5,8195,5,10,8201,513]

theorem envBound33644 : H12AffineFastState.Bounded env33644 := by
  intro p hp
  have h : env33644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33643_33644 : H12AffineEnvironment.transform 3 1 env33643 = env33644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33643 == env33644) = true)

def env33645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,8388608,8602076,8328,64,4489693,8393984,8553729,8830976,181708,12645453,257,21793,46212,254491]

theorem envBound33645 : H12AffineFastState.Bounded env33645 := by
  intro p hp
  have h : env33645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33565_33645 : H12AffineEnvironment.transform 20 184401 env33565 = env33645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env33565 == env33645) = true)

def env33646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,98780,8328,64,4489693,185600,17665,262144,181708,4338765,257,21793,46212,254491]

theorem envBound33646 : H12AffineFastState.Bounded env33646 := by
  intro p hp
  have h : env33646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33645_33646 : H12AffineEnvironment.transform 22 180224 env33645 = env33646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env33645 == env33646) = true)

def env33647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,98780,8328,64,43357,185600,17665,262144,181708,400589,257,21793,46212,254491]

theorem envBound33647 : H12AffineFastState.Bounded env33647 := by
  intro p hp
  have h : env33647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33646_33647 : H12AffineEnvironment.transform 21 272512 env33646 = env33647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33646 == env33647) = true)

theorem identity33647 : scanCanonicalize (H12AffineFastState.compose env33647 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound33647 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140421,272512,144596,95496,8328,64,23945,139732,17665,262144,143640,400589,257,21793,16464,202447]

theorem envBound33648 : H12AffineFastState.Bounded env33648 := by
  intro p hp
  have h : env33648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33647_33648 : H12AffineEnvironment.transform 14 29908 env33647 = env33648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env33647 == env33648) = true)

theorem identity33648 : scanCanonicalize (H12AffineFastState.compose env33648 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound33648 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env33649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,83103,272512,87246,95496,8328,64,23945,82382,17665,262144,86274,359639,257,21793,16464,30421]

theorem envBound33649 : H12AffineFastState.Bounded env33649 := by
  intro p hp
  have h : env33649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33648_33649 : H12AffineEnvironment.transform 16 90138 env33648 = env33649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env33648 == env33649) = true)

theorem identity33649 : scanCanonicalize (H12AffineFastState.compose env33649 (packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33649 : packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env33650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16401,262144,1025,29909,25748,272512,29893,21763,8328,64,23945,25029,17665,262144,28937,285916,257,21793,16464,30421]

theorem envBound33650 : H12AffineFastState.Bounded env33650 := by
  intro p hp
  have h : env33650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33649_33650 : H12AffineEnvironment.transform 15 8203 env33649 = env33650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33649 == env33650) = true)

def env33651 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8203,16401,262144,1025,29829,25748,272512,29845,21763,8328,16,23945,24981,17665,262144,28937,285836,257,21793,16384,30341]

theorem envBound33651 : H12AffineFastState.Bounded env33651 := by
  intro p hp
  have h : env33651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33650_33651 : H12AffineEnvironment.transform 5 16 env33650 = env33651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33650 == env33651) = true)

theorem identity33651 : scanCanonicalize (H12AffineFastState.compose env33651 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound33651 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env33652 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8203,16401,32041,1025,29829,25748,21929,29845,21763,8328,16,23945,24981,17665,32041,28937,8613,257,21793,16384,30341]

theorem envBound33652 : H12AffineFastState.Bounded env33652 := by
  intro p hp
  have h : env33652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33651_33652 : H12AffineEnvironment.transform 17 32041 env33651 = env33652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env33651 == env33652) = true)

theorem identity33652 : scanCanonicalize (H12AffineFastState.compose env33652 (packedSelected [3,4,5,7,10,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound33652 : packedSelected [3,4,5,7,10,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env33653 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,4096,8192,16384,29828,8203,16401,29960,1025,29829,25748,21929,29845,21763,8328,16,21928,24981,17665,29960,28937,8613,257,21793,16384,30341]

theorem envBound33653 : H12AffineFastState.Bounded env33653 := by
  intro p hp
  have h : env33653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33652_33653 : H12AffineEnvironment.transform 10 33 env33652 = env33653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env33652 == env33653) = true)

theorem identity33653 : scanCanonicalize (H12AffineFastState.compose env33653 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33653 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33654 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,4096,388,16384,21760,399,16401,21644,1025,21761,17680,21929,21777,21763,268,16,21928,16401,17665,21644,20621,33,257,21793,16384,22273]

theorem envBound33654 : H12AffineFastState.Bounded env33654 := by
  intro p hp
  have h : env33654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33653_33654 : H12AffineEnvironment.transform 12 388 env33653 = env33654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33653 == env33654) = true)

theorem identity33654 : scanCanonicalize (H12AffineFastState.compose env33654 (packedSelected [0,1,2,3,4,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound33654 : packedSelected [0,1,2,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env33655 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,49,388,16384,17713,399,16401,17597,1025,17712,17680,17816,17696,17714,268,16,17817,16401,17665,17597,16572,33,257,17680,16384,18224]

theorem envBound33655 : H12AffineFastState.Bounded env33655 := by
  intro p hp
  have h : env33655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33654_33655 : H12AffineEnvironment.transform 11 49 env33654 = env33655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33654 == env33655) = true)

theorem identity33655 : scanCanonicalize (H12AffineFastState.compose env33655 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1045) := by decide +kernel

theorem selectedBound33655 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33656 : List Nat := [2,4,8,16,32,16,128,256,512,1024,33,49,388,1045,292,399,1028,168,1025,293,261,397,309,295,268,16,396,1028,276,168,1193,33,257,261,1045,805]

theorem envBound33656 : H12AffineFastState.Bounded env33656 := by
  intro p hp
  have h : env33656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33655_33656 : H12AffineEnvironment.transform 13 1045 env33655 = env33656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1045 env33655 == env33656) = true)

def env33657 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8203,16401,262144,1025,29828,25748,272512,29844,21763,8328,17,23945,24980,17665,262144,28937,285837,257,21793,16385,30340]

theorem envBound33657 : H12AffineFastState.Bounded env33657 := by
  intro p hp
  have h : env33657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33650_33657 : H12AffineEnvironment.transform 5 17 env33650 = env33657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33650 == env33657) = true)

theorem identity33657 : scanCanonicalize (H12AffineFastState.compose env33657 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound33657 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env33658 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8203,16401,2341,1025,29828,25748,8613,29844,21763,8328,17,23945,24980,17665,2341,28937,21928,257,21793,16385,30340]

theorem envBound33658 : H12AffineFastState.Bounded env33658 := by
  intro p hp
  have h : env33658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33657_33658 : H12AffineEnvironment.transform 17 2341 env33657 = env33658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env33657 == env33658) = true)

theorem identity33658 : scanCanonicalize (H12AffineFastState.compose env33658 (packedSelected [0,1,2,4,8,12,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound33658 : packedSelected [0,1,2,4,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env33659 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,8203,13341,2341,1025,136,4248,8613,152,8463,8328,17,10629,5528,12557,2341,1285,8612,257,8493,13325,648]

theorem envBound33659 : H12AffineFastState.Bounded env33659 := by
  intro p hp
  have h : env33659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33658_33659 : H12AffineEnvironment.transform 13 13324 env33658 = env33659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env33658 == env33659) = true)

theorem identity33659 : scanCanonicalize (H12AffineFastState.compose env33659 (packedSelected [1,2,3,5,6,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3496) := by decide +kernel

theorem selectedBound33659 : packedSelected [1,2,3,5,6,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33660 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3496,8192,10660,137,8203,10677,2341,1025,136,3376,8613,152,8463,8328,17,10629,2096,11429,2341,1285,8612,257,8493,10661,648]

theorem envBound33660 : H12AffineFastState.Bounded env33660 := by
  intro p hp
  have h : env33660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33659_33660 : H12AffineEnvironment.transform 11 3496 env33659 = env33660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3496 env33659 == env33660) = true)

theorem identity33660 : scanCanonicalize (H12AffineFastState.compose env33660 (packedSelected [1,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound33660 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env33661 : List Nat := [2,4,8,16,32,17,128,256,512,157,2048,2357,8192,10660,137,8203,10677,2341,156,136,2477,8613,152,8463,8328,17,10629,2096,10296,2341,408,8612,257,8493,10661,648]

theorem envBound33661 : H12AffineFastState.Bounded env33661 := by
  intro p hp
  have h : env33661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33660_33661 : H12AffineEnvironment.transform 9 157 env33660 = env33661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env33660 == env33661) = true)

theorem identity33661 : scanCanonicalize (H12AffineFastState.compose env33661 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33661 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env33662 : List Nat := [2,4,8,16,32,17,128,256,512,157,2048,2357,269,2217,137,262,2232,2341,156,136,2477,168,152,2,389,17,2184,2096,2357,2341,408,169,257,32,2216,648]

theorem envBound33662 : H12AffineFastState.Bounded env33662 := by
  intro p hp
  have h : env33662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33661_33662 : H12AffineEnvironment.transform 12 269 env33661 = env33662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33661 == env33662) = true)

theorem identity33662 : scanCanonicalize (H12AffineFastState.compose env33662 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound33662 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env33663 : List Nat := [2,4,8,16,32,17,41,256,512,52,2048,2357,269,2048,32,262,2065,2341,53,33,2308,1,49,2,300,17,2081,2096,2357,2341,305,0,257,32,2049,545]

theorem envBound33663 : H12AffineFastState.Bounded env33663 := by
  intro p hp
  have h : env33663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33662_33663 : H12AffineEnvironment.transform 6 41 env33662 = env33663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env33662 == env33663) = true)

theorem identity33663 : scanCanonicalize (H12AffineFastState.compose env33663 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33663 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33664 : List Nat := [2,4,8,16,32,17,41,37,512,52,2048,2064,40,2048,32,35,2065,2048,53,33,2081,1,49,2,9,17,2081,2096,2064,2048,20,0,36,32,2049,545]

theorem envBound33664 : H12AffineFastState.Bounded env33664 := by
  intro p hp
  have h : env33664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33663_33664 : H12AffineEnvironment.transform 7 37 env33663 = env33664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33663 == env33664) = true)

theorem identity33664 : scanCanonicalize (H12AffineFastState.compose env33664 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33665 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,9,2048,1,2,2065,2048,20,0,2048,1,16,2,9,17,2048,2065,2064,2048,20,0,5,1,2049,512]

theorem envBound33665 : H12AffineFastState.Bounded env33665 := by
  intro p hp
  have h : env33665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33664_33665 : H12AffineEnvironment.transform 4 1 env33664 = env33665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33664 == env33665) = true)

theorem identity33665 : scanCanonicalize (H12AffineFastState.compose env33665 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound33665 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33666 : List Nat := [2,4,8,16,1,17,8,4,512,21,5,21,9,5,1,2,20,5,20,0,5,1,16,2,9,17,5,20,21,5,20,0,5,1,4,512]

theorem envBound33666 : H12AffineFastState.Bounded env33666 := by
  intro p hp
  have h : env33666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33665_33666 : H12AffineEnvironment.transform 10 5 env33665 = env33666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env33665 == env33666) = true)

def env33667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,98780,8328,64,43356,185600,17665,262144,181708,400588,257,21793,46212,254491]

theorem envBound33667 : H12AffineFastState.Bounded env33667 := by
  intro p hp
  have h : env33667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33646_33667 : H12AffineEnvironment.transform 21 272513 env33646 = env33667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33646 == env33667) = true)

theorem identity33667 : scanCanonicalize (H12AffineFastState.compose env33667 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound33667 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58516,272513,62661,98780,8328,64,43356,57797,17665,262144,61705,272393,257,21793,46212,120542]

theorem envBound33668 : H12AffineFastState.Bounded env33668 := by
  intro p hp
  have h : env33668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33667_33668 : H12AffineEnvironment.transform 16 13509 env33667 = env33668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env33667 == env33668) = true)

def env33669 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58516,272513,62613,98700,8328,16,43276,57749,17665,262144,61705,272393,257,21793,46212,120462]

theorem envBound33669 : H12AffineFastState.Bounded env33669 := by
  intro p hp
  have h : env33669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33668_33669 : H12AffineEnvironment.transform 5 16 env33668 = env33669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33668 == env33669) = true)

theorem identity33669 : scanCanonicalize (H12AffineFastState.compose env33669 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound33669 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env33670 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,65536,13461,262144,1025,8580,17681,272513,21776,73737,8328,16,2185,16400,17665,262144,20620,272393,257,21793,5377,96011]

theorem envBound33670 : H12AffineFastState.Bounded env33670 := by
  intro p hp
  have h : env33670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33669_33670 : H12AffineEnvironment.transform 14 8581 env33669 = env33670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env33669 == env33670) = true)

theorem identity33670 : scanCanonicalize (H12AffineFastState.compose env33670 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound33670 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33671 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,65536,13461,76199,1025,8580,17681,65830,21776,73737,8328,16,2185,16400,17665,76199,20620,65966,257,21793,5377,96011]

theorem envBound33671 : H12AffineFastState.Bounded env33671 := by
  intro p hp
  have h : env33671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33670_33671 : H12AffineEnvironment.transform 17 76199 env33670 = env33671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env33670 == env33671) = true)

theorem identity33671 : scanCanonicalize (H12AffineFastState.compose env33671 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound33671 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env33672 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8581,65536,13461,76199,1025,8580,12573,65830,8476,73737,8328,16,2185,13340,12557,76199,9344,65966,257,8493,5377,66311]

theorem envBound33672 : H12AffineFastState.Bounded env33672 := by
  intro p hp
  have h : env33672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33671_33672 : H12AffineEnvironment.transform 13 13324 env33671 = env33672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env33671 == env33672) = true)

theorem identity33672 : scanCanonicalize (H12AffineFastState.compose env33672 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33672 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env33673 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,136,65536,5528,67754,1025,137,4112,65830,17,65796,389,16,2185,5393,4096,67754,1421,65966,257,32,5377,66311]

theorem envBound33673 : H12AffineFastState.Bounded env33673 := by
  intro p hp
  have h : env33673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33672_33673 : H12AffineEnvironment.transform 12 269 env33672 = env33673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33672 == env33673) = true)

theorem identity33673 : scanCanonicalize (H12AffineFastState.compose env33673 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33673 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33674 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,9,5125,136,65536,5276,67754,1025,137,4112,65570,17,65536,129,16,2185,5141,4096,67754,1161,65706,5,32,5125,66051]

theorem envBound33674 : H12AffineFastState.Bounded env33674 := by
  intro p hp
  have h : env33674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33673_33674 : H12AffineEnvironment.transform 7 4 env33673 = env33674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33673 == env33674) = true)

theorem identity33674 : scanCanonicalize (H12AffineFastState.compose env33674 (packedSelected [0,7,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound33674 : packedSelected [0,7,12,14] rootPS < 2^1333 := by decide +kernel

def env33675 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,3108,9,2081,136,65536,2232,67754,1025,137,3124,65570,17,65536,129,16,2185,2097,3108,67754,1161,65706,5,32,2081,66051]

theorem envBound33675 : H12AffineFastState.Bounded env33675 := by
  intro p hp
  have h : env33675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33674_33675 : H12AffineEnvironment.transform 11 3108 env33674 = env33675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env33674 == env33675) = true)

theorem identity33675 : scanCanonicalize (H12AffineFastState.compose env33675 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound33675 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33676 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,3108,9,2081,136,138,2232,2080,1025,137,3124,168,17,138,129,16,2185,2097,3108,2080,1161,32,5,32,2081,649]

theorem envBound33676 : H12AffineFastState.Bounded env33676 := by
  intro p hp
  have h : env33676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33675_33676 : H12AffineEnvironment.transform 15 138 env33675 = env33676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env33675 == env33676) = true)

theorem identity33676 : scanCanonicalize (H12AffineFastState.compose env33676 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound33676 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env33677 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1213,153,9,1180,136,138,1029,1181,1025,137,137,168,17,138,129,16,1076,1164,153,1181,1161,32,5,32,1180,649]

theorem envBound33677 : H12AffineFastState.Bounded env33677 := by
  intro p hp
  have h : env33677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33676_33677 : H12AffineEnvironment.transform 10 1213 env33676 = env33677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env33676 == env33677) = true)

theorem identity33677 : scanCanonicalize (H12AffineFastState.compose env33677 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33677 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33678 : List Nat := [2,4,8,16,32,16,128,4,512,53,136,153,9,169,136,138,48,168,52,137,137,168,17,138,129,16,1,185,153,168,188,32,5,32,169,649]

theorem envBound33678 : H12AffineFastState.Bounded env33678 := by
  intro p hp
  have h : env33678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33677_33678 : H12AffineEnvironment.transform 9 53 env33677 = env33678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33677 == env33678) = true)

theorem identity33678 : scanCanonicalize (H12AffineFastState.compose env33678 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33678 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33679 : List Nat := [2,4,8,16,32,16,8,4,512,53,0,17,9,33,0,2,48,32,52,1,1,32,17,2,9,16,1,49,17,32,52,32,5,32,33,513]

theorem envBound33679 : H12AffineFastState.Bounded env33679 := by
  intro p hp
  have h : env33679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33678_33679 : H12AffineEnvironment.transform 6 8 env33678 = env33679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33678 == env33679) = true)

def env33680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58516,272513,62612,98701,8328,17,43277,57748,17665,262144,61705,272393,257,21793,46212,120463]

theorem envBound33680 : H12AffineFastState.Bounded env33680 := by
  intro p hp
  have h : env33680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33668_33680 : H12AffineEnvironment.transform 5 17 env33668 = env33680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33668 == env33680) = true)

theorem identity33680 : scanCanonicalize (H12AffineFastState.compose env33680 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound33680 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env33681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,262144,1025,32769,45340,272513,41244,98701,8328,17,43277,46108,4233,262144,42113,272393,257,169,46212,99079]

theorem envBound33681 : H12AffineFastState.Bounded env33681 := by
  intro p hp
  have h : env33681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33680_33681 : H12AffineEnvironment.transform 13 5512 env33680 = env33681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env33680 == env33681) = true)

theorem identity33681 : scanCanonicalize (H12AffineFastState.compose env33681 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 108847) := by decide +kernel

theorem selectedBound33681 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env33682 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,108847,1025,32769,45340,98734,41244,98701,8328,17,43277,46108,4233,108847,42113,98598,257,169,46212,99079]

theorem envBound33682 : H12AffineFastState.Bounded env33682 := by
  intro p hp
  have h : env33682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33681_33682 : H12AffineEnvironment.transform 17 108847 env33681 = env33682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108847 env33681 == env33682) = true)

theorem identity33682 : scanCanonicalize (H12AffineFastState.compose env33682 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound33682 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,19,23] rootPS < 2^1333 := by decide +kernel

def env33683 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33167,13460,10400,1025,32769,45340,33,41244,2,8328,17,43277,46108,4233,10400,42113,169,257,169,46212,648]

theorem envBound33683 : H12AffineFastState.Bounded env33683 := by
  intro p hp
  have h : env33683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33682_33683 : H12AffineEnvironment.transform 15 33167 env33682 = env33683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env33682 == env33683) = true)

theorem identity33683 : scanCanonicalize (H12AffineFastState.compose env33683 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33683 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env33684 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,1076,1467,13460,10400,1025,1077,13608,33,9512,2,8328,17,11577,12328,4233,10400,8373,169,257,169,12464,648]

theorem envBound33684 : H12AffineFastState.Bounded env33684 := by
  intro p hp
  have h : env33684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33683_33684 : H12AffineEnvironment.transform 14 1076 env33683 = env33684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env33683 == env33684) = true)

theorem identity33684 : scanCanonicalize (H12AffineFastState.compose env33684 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound33684 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env33685 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,4113,429,34,12557,10400,408,428,12465,33,8369,2,8328,17,10400,12328,4233,10400,8373,169,257,169,12464,648]

theorem envBound33685 : H12AffineFastState.Bounded env33685 := by
  intro p hp
  have h : env33685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33684_33685 : H12AffineEnvironment.transform 9 409 env33684 = env33685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env33684 == env33685) = true)

theorem identity33685 : scanCanonicalize (H12AffineFastState.compose env33685 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound33685 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33686 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,389,4113,429,34,4232,2341,408,428,4404,33,308,2,269,17,2341,4525,4233,2341,304,169,257,169,4405,648]

theorem envBound33686 : H12AffineFastState.Bounded env33686 := by
  intro p hp
  have h : env33686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33685_33686 : H12AffineEnvironment.transform 12 389 env33685 = env33686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env33685 == env33686) = true)

theorem identity33686 : scanCanonicalize (H12AffineFastState.compose env33686 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound33686 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env33687 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,2356,389,2341,429,34,2492,2341,408,428,2048,33,308,2,269,17,2341,2201,2493,2341,304,169,257,169,2049,648]

theorem envBound33687 : H12AffineFastState.Bounded env33687 := by
  intro p hp
  have h : env33687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33686_33687 : H12AffineEnvironment.transform 11 2356 env33686 = env33687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env33686 == env33687) = true)

theorem identity33687 : scanCanonicalize (H12AffineFastState.compose env33687 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound33687 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33688 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,2201,40,2184,0,34,2065,2184,53,1,2048,33,153,2,160,17,2184,2201,2064,2184,157,169,172,169,2049,648]

theorem envBound33688 : H12AffineFastState.Bounded env33688 := by
  intro p hp
  have h : env33688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33687_33688 : H12AffineEnvironment.transform 7 173 env33687 = env33688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33687 == env33688) = true)

theorem identity33688 : scanCanonicalize (H12AffineFastState.compose env33688 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 150) := by decide +kernel

theorem selectedBound33688 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env33689 : List Nat := [2,4,8,16,32,17,128,173,512,52,150,15,40,30,0,34,135,30,53,1,150,33,153,2,160,17,30,15,134,30,157,169,172,169,151,648]

theorem envBound33689 : H12AffineFastState.Bounded env33689 := by
  intro p hp
  have h : env33689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33688_33689 : H12AffineEnvironment.transform 10 150 env33688 = env33689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 150 env33688 == env33689) = true)

theorem identity33689 : scanCanonicalize (H12AffineFastState.compose env33689 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound33689 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env33690 : List Nat := [2,4,8,16,31,17,128,146,512,11,150,15,23,30,0,29,135,30,10,1,150,30,153,2,159,17,30,15,134,30,157,150,147,150,151,648]

theorem envBound33690 : H12AffineFastState.Bounded env33690 := by
  intro p hp
  have h : env33690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33689_33690 : H12AffineEnvironment.transform 4 31 env33689 = env33690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env33689 == env33690) = true)

def env33691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,98781,8328,64,4489693,185601,17664,262145,181708,4338764,257,21793,46212,254491]

theorem envBound33691 : H12AffineFastState.Bounded env33691 := by
  intro p hp
  have h : env33691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33645_33691 : H12AffineEnvironment.transform 22 180225 env33645 = env33691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env33645 == env33691) = true)

def env33692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,98781,8328,64,43357,185601,17664,262145,181708,400588,257,21793,46212,254491]

theorem envBound33692 : H12AffineFastState.Bounded env33692 := by
  intro p hp
  have h : env33692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33691_33692 : H12AffineEnvironment.transform 21 272512 env33691 = env33692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33691 == env33692) = true)

def env33693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180225,98645,8192,64,43357,185601,17664,262145,181572,400452,257,21793,46092,254491]

theorem envBound33693 : H12AffineFastState.Bounded env33693 := by
  intro p hp
  have h : env33693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33692_33693 : H12AffineEnvironment.transform 6 8 env33692 = env33693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33692 == env33693) = true)

def env33694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,98645,8192,64,43357,5393,17664,262145,1364,318548,257,21793,46092,74251]

theorem envBound33694 : H12AffineFastState.Bounded env33694 := by
  intro p hp
  have h : env33694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33693_33694 : H12AffineEnvironment.transform 16 49168 env33693 = env33694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33693 == env33694) = true)

theorem identity33694 : scanCanonicalize (H12AffineFastState.compose env33694 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33694 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,33,17,98645,8192,64,43357,5393,17664,10280,1364,62589,257,21793,46092,74251]

theorem envBound33695 : H12AffineFastState.Bounded env33695 := by
  intro p hp
  have h : env33695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33694_33695 : H12AffineEnvironment.transform 17 10281 env33694 = env33695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33694 == env33695) = true)

theorem identity33695 : scanCanonicalize (H12AffineFastState.compose env33695 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound33695 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10281,1025,32769,4161,33,17,8542,8192,64,43357,5393,17664,10280,1364,62589,257,21793,46092,33280]

theorem envBound33696 : H12AffineFastState.Bounded env33696 := by
  intro p hp
  have h : env33696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33695_33696 : H12AffineEnvironment.transform 15 40971 env33695 = env33696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env33695 == env33696) = true)

theorem identity33696 : scanCanonicalize (H12AffineFastState.compose env33696 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound33696 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env33697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,13389,10281,1025,29788,4161,33,17,8542,8192,64,23808,5393,17664,10280,1364,32,257,21793,16465,30301]

theorem envBound33697 : H12AffineFastState.Bounded env33697 := by
  intro p hp
  have h : env33697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33696_33697 : H12AffineEnvironment.transform 14 29789 env33696 = env33697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env33696 == env33697) = true)

theorem identity33697 : scanCanonicalize (H12AffineFastState.compose env33697 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33697 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,343,13389,10281,1025,8541,4161,33,17,8542,8192,64,2049,5393,4097,10280,1364,32,257,32,5456,9052]

theorem envBound33698 : H12AffineFastState.Bounded env33698 := by
  intro p hp
  have h : env33698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33697_33698 : H12AffineEnvironment.transform 13 5377 env33697 = env33698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33697 == env33698) = true)

theorem identity33698 : scanCanonicalize (H12AffineFastState.compose env33698 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33698 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33699 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8540,343,12637,10281,273,8541,4161,33,17,8542,8192,64,2049,4097,4097,10280,68,32,257,32,4160,9052]

theorem envBound33699 : H12AffineFastState.Bounded env33699 := by
  intro p hp
  have h : env33699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33698_33699 : H12AffineEnvironment.transform 9 272 env33698 = env33699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33698 == env33699) = true)

theorem identity33699 : scanCanonicalize (H12AffineFastState.compose env33699 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound33699 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env33700 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,4096,8192,4113,8201,2,12296,10281,68,8200,4161,33,17,8203,8192,64,2049,4097,4097,10280,68,32,84,32,4160,8713]

theorem envBound33700 : H12AffineFastState.Bounded env33700 := by
  intro p hp
  have h : env33700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33699_33700 : H12AffineEnvironment.transform 7 85 env33699 = env33700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env33699 == env33700) = true)

theorem identity33700 : scanCanonicalize (H12AffineFastState.compose env33700 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 4201) := by decide +kernel

theorem selectedBound33700 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env33701 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,4096,4201,4113,4192,2,97,6208,68,4193,4161,33,17,4194,4201,64,2049,4097,4097,6209,68,32,84,32,4160,4704]

theorem envBound33701 : H12AffineFastState.Bounded env33701 := by
  intro p hp
  have h : env33701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33700_33701 : H12AffineEnvironment.transform 12 4201 env33700 = env33701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4201 env33700 == env33701) = true)

theorem identity33701 : scanCanonicalize (H12AffineFastState.compose env33701 (packedSelected [2,14] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound33701 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env33702 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,96,9,113,0,2,97,2080,68,1,33,33,17,2,9,64,2049,97,97,2081,68,32,84,32,32,512]

theorem envBound33702 : H12AffineFastState.Bounded env33702 := by
  intro p hp
  have h : env33702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33701_33702 : H12AffineEnvironment.transform 11 96 env33701 = env33702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env33701 == env33702) = true)

def env33703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,16,98645,8192,64,43357,5392,17664,262145,1365,318549,257,21793,46092,74250]

theorem envBound33703 : H12AffineFastState.Bounded env33703 := by
  intro p hp
  have h : env33703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33693_33703 : H12AffineEnvironment.transform 16 49169 env33693 = env33703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env33693 == env33703) = true)

theorem identity33703 : scanCanonicalize (H12AffineFastState.compose env33703 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound33703 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130095,1025,32769,4160,119847,16,98645,8192,64,43357,5392,17664,130094,1365,73850,257,21793,46092,74250]

theorem envBound33704 : H12AffineFastState.Bounded env33704 := by
  intro p hp
  have h : env33704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33703_33704 : H12AffineEnvironment.transform 17 130095 env33703 = env33704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env33703 == env33704) = true)

theorem identity33704 : scanCanonicalize (H12AffineFastState.compose env33704 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound33704 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,65536,46108,100386,1025,32769,4160,106538,16,98645,8192,64,43357,5392,12557,100387,1365,73850,257,8492,46092,74250]

theorem envBound33705 : H12AffineFastState.Bounded env33705 := by
  intro p hp
  have h : env33705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33704_33705 : H12AffineEnvironment.transform 13 13325 env33704 = env33705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env33704 == env33705) = true)

theorem identity33705 : scanCanonicalize (H12AffineFastState.compose env33705 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33705 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env33706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,8203,46108,43049,1025,32769,4160,32801,16,41310,8192,64,43357,5392,12557,43048,1365,113,257,8492,46092,513]

theorem envBound33706 : H12AffineFastState.Bounded env33706 := by
  intro p hp
  have h : env33706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33705_33706 : H12AffineEnvironment.transform 15 8203 env33705 = env33706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33705 == env33706) = true)

theorem identity33706 : scanCanonicalize (H12AffineFastState.compose env33706 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33706 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,32768,342,38209,35188,1025,32769,4160,32801,16,32771,349,64,34816,5392,4176,35189,1365,113,257,113,38225,513]

theorem envBound33707 : H12AffineFastState.Bounded env33707 := by
  intro p hp
  have h : env33707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33706_33707 : H12AffineEnvironment.transform 12 349 env33706 = env33707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33706 == env33707) = true)

theorem identity33707 : scanCanonicalize (H12AffineFastState.compose env33707 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33707 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env33708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1076,4096,349,5456,32768,342,38209,34112,1025,32769,4160,32801,16,32771,349,64,33844,5392,4176,34113,1365,113,257,113,38225,513]

theorem envBound33708 : H12AffineFastState.Bounded env33708 := by
  intro p hp
  have h : env33708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33707_33708 : H12AffineEnvironment.transform 10 1076 env33707 = env33708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env33707 == env33708) = true)

theorem identity33708 : scanCanonicalize (H12AffineFastState.compose env33708 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33708 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env33709 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,5237,32768,115,37988,33893,1025,32769,4160,32801,16,32771,120,64,33844,5173,4176,33892,1136,113,36,113,38004,513]

theorem envBound33709 : H12AffineFastState.Bounded env33709 := by
  intro p hp
  have h : env33709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33708_33709 : H12AffineEnvironment.transform 7 37 env33708 = env33709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33708 == env33709) = true)

theorem identity33709 : scanCanonicalize (H12AffineFastState.compose env33709 (packedSelected [0,2,7] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound33709 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33710 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,5237,80,115,5172,1077,1025,81,4160,113,16,83,120,64,1124,5173,4176,1076,1136,113,36,113,5156,513]

theorem envBound33710 : H12AffineFastState.Bounded env33710 := by
  intro p hp
  have h : env33710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33709_33710 : H12AffineEnvironment.transform 14 80 env33709 = env33710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env33709 == env33710) = true)

theorem identity33710 : scanCanonicalize (H12AffineFastState.compose env33710 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33710 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33711 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,4096,41,5156,1,34,5172,1077,1025,0,4113,32,16,2,41,17,1077,5173,4097,1076,1057,32,36,32,5156,513]

theorem envBound33711 : H12AffineFastState.Bounded env33711 := by
  intro p hp
  have h : env33711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33710_33711 : H12AffineEnvironment.transform 5 17 env33710 = env33711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33710 == env33711) = true)

def env33712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180225,98644,8193,64,43357,185601,17664,262145,181573,400453,257,21793,46093,254491]

theorem envBound33712 : H12AffineFastState.Bounded env33712 := by
  intro p hp
  have h : env33712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33692_33712 : H12AffineEnvironment.transform 6 9 env33692 = env33712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33692 == env33712) = true)

theorem identity33712 : scanCanonicalize (H12AffineFastState.compose env33712 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound33712 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env33713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,262144,1025,32769,184401,272393,180225,8542,8193,64,43357,185601,17664,262145,181573,400453,257,21793,46093,147985]

theorem envBound33713 : H12AffineFastState.Bounded env33713 := by
  intro p hp
  have h : env33713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33712_33713 : H12AffineEnvironment.transform 15 40970 env33712 = env33713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env33712 == env33713) = true)

theorem identity33713 : scanCanonicalize (H12AffineFastState.compose env33713 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound33713 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env33714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,2421,1025,32769,184401,8572,180225,8542,8193,64,43357,185601,17664,2420,181573,136496,257,21793,46093,147985]

theorem envBound33714 : H12AffineFastState.Bounded env33714 := by
  intro p hp
  have h : env33714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33713_33714 : H12AffineEnvironment.transform 17 2421 env33713 = env33714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env33713 == env33714) = true)

theorem identity33714 : scanCanonicalize (H12AffineFastState.compose env33714 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound33714 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57676,2421,1025,32769,12573,8572,8525,8542,8193,64,43357,13389,17664,2420,9225,62588,257,21793,46093,41821]

theorem envBound33715 : H12AffineFastState.Bounded env33715 := by
  intro p hp
  have h : env33715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33714_33715 : H12AffineEnvironment.transform 16 57676 env33714 = env33715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env33714 == env33715) = true)

theorem identity33715 : scanCanonicalize (H12AffineFastState.compose env33715 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,24909,2421,1025,0,12573,8572,8525,8542,8193,64,10588,13389,17664,2420,9225,29821,257,21793,13324,9052]

theorem envBound33716 : H12AffineFastState.Bounded env33716 := by
  intro p hp
  have h : env33716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33715_33716 : H12AffineEnvironment.transform 14 1 env33715 = env33716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33715 == env33716) = true)

theorem identity33716 : scanCanonicalize (H12AffineFastState.compose env33716 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33716 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33717 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,1,8203,24681,2129,1025,0,12345,8280,8297,8314,8193,64,10360,13389,17444,2128,9225,29821,37,21509,13324,8824]

theorem envBound33717 : H12AffineFastState.Bounded env33717 := by
  intro p hp
  have h : env33717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33716_33717 : H12AffineEnvironment.transform 7 36 env33716 = env33717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33716 == env33717) = true)

theorem identity33717 : scanCanonicalize (H12AffineFastState.compose env33717 (packedSelected [1,2,8,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound33717 : packedSelected [1,2,8,14,19] rootPS < 2^1333 := by decide +kernel

def env33718 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,1,114,16400,2129,1025,0,4160,33,16,3,120,64,2049,5172,17444,2128,1136,21508,37,21509,5237,513]

theorem envBound33718 : H12AffineFastState.Bounded env33718 := by
  intro p hp
  have h : env33718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33717_33718 : H12AffineEnvironment.transform 12 121 env33717 = env33718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env33717 == env33718) = true)

theorem identity33718 : scanCanonicalize (H12AffineFastState.compose env33718 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound33718 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33719 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5237,1,114,5221,2129,1025,0,4160,33,16,3,120,64,2049,5172,4177,2128,1136,113,37,112,5237,513]

theorem envBound33719 : H12AffineFastState.Bounded env33719 := by
  intro p hp
  have h : env33719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33718_33719 : H12AffineEnvironment.transform 13 5237 env33718 = env33719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env33718 == env33719) = true)

theorem identity33719 : scanCanonicalize (H12AffineFastState.compose env33719 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33719 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33720 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,1,34,5173,2049,1025,0,4112,33,16,3,40,16,2049,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound33720 : H12AffineFastState.Bounded env33720 := by
  intro p hp
  have h : env33720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33719_33720 : H12AffineEnvironment.transform 5 16 env33719 = env33720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33719 == env33720) = true)

theorem identity33720 : scanCanonicalize (H12AffineFastState.compose env33720 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound33720 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33721 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,4096,41,5157,1,34,5173,1076,1025,0,4112,33,16,3,40,16,1076,5172,4097,1077,1056,33,37,32,5157,513]

theorem envBound33721 : H12AffineFastState.Bounded env33721 := by
  intro p hp
  have h : env33721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33720_33721 : H12AffineEnvironment.transform 10 1077 env33720 = env33721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env33720 == env33721) = true)

theorem identity33721 : scanCanonicalize (H12AffineFastState.compose env33721 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound33721 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33722 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,1060,41,1,1,34,17,1076,1025,0,1076,33,16,3,40,16,1076,16,1061,1077,1056,33,37,32,1,513]

theorem envBound33722 : H12AffineFastState.Bounded env33722 := by
  intro p hp
  have h : env33722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33721_33722 : H12AffineEnvironment.transform 11 1060 env33721 = env33722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env33721 == env33722) = true)

theorem identity33722 : scanCanonicalize (H12AffineFastState.compose env33722 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33722 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33723 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,17,41,1,1,34,17,1,52,0,1,33,16,3,40,16,1,16,16,0,21,33,37,32,1,513]

theorem envBound33723 : H12AffineFastState.Bounded env33723 := by
  intro p hp
  have h : env33723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33722_33723 : H12AffineEnvironment.transform 9 53 env33722 = env33723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33722 == env33723) = true)

theorem identity33723 : scanCanonicalize (H12AffineFastState.compose env33723 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound33723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33724 : List Nat := [2,4,8,16,32,16,9,36,17,53,0,17,41,1,1,34,17,1,52,0,1,33,16,3,40,16,1,16,16,0,21,33,37,32,1,16]

theorem envBound33724 : H12AffineFastState.Bounded env33724 := by
  intro p hp
  have h : env33724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33723_33724 : H12AffineEnvironment.transform 8 17 env33723 = env33724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env33723 == env33724) = true)

theorem identity33724 : scanCanonicalize (H12AffineFastState.compose env33724 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound33724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33725 : List Nat := [2,4,8,16,26,16,9,30,17,15,0,17,19,1,1,24,17,1,14,0,1,27,16,3,18,16,1,16,16,0,21,27,31,26,1,16]

theorem envBound33725 : H12AffineFastState.Bounded env33725 := by
  intro p hp
  have h : env33725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33724_33725 : H12AffineEnvironment.transform 4 26 env33724 = env33725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env33724 == env33725) = true)

def env33726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,98781,8328,64,43356,185601,17664,262145,181708,400589,257,21793,46212,254491]

theorem envBound33726 : H12AffineFastState.Bounded env33726 := by
  intro p hp
  have h : env33726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33691_33726 : H12AffineEnvironment.transform 21 272513 env33691 = env33726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33691 == env33726) = true)

theorem identity33726 : scanCanonicalize (H12AffineFastState.compose env33726 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound33726 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272513,17,98781,8328,64,43356,5393,17664,262145,1500,318685,257,21793,46212,74251]

theorem envBound33727 : H12AffineFastState.Bounded env33727 := by
  intro p hp
  have h : env33727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33726_33727 : H12AffineEnvironment.transform 16 49168 env33726 = env33727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33726 == env33727) = true)

theorem identity33727 : scanCanonicalize (H12AffineFastState.compose env33727 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33727 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272513,17,41431,8328,64,43356,5393,17664,262145,1500,318685,257,21793,46212,513]

theorem envBound33728 : H12AffineFastState.Bounded env33728 := by
  intro p hp
  have h : env33728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33727_33728 : H12AffineEnvironment.transform 15 8202 env33727 = env33728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33727 == env33728) = true)

theorem identity33728 : scanCanonicalize (H12AffineFastState.compose env33728 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound33728 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env33729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10400,1025,32769,4161,33,17,41431,8328,64,43356,5393,17664,10401,1500,62589,257,21793,46212,513]

theorem envBound33729 : H12AffineFastState.Bounded env33729 := by
  intro p hp
  have h : env33729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33728_33729 : H12AffineEnvironment.transform 17 10400 env33728 = env33729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33728 == env33729) = true)

theorem identity33729 : scanCanonicalize (H12AffineFastState.compose env33729 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33729 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env33730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16401,10400,1025,0,4161,33,17,8662,8328,64,10589,5393,17664,10401,1500,29820,257,21793,13445,513]

theorem envBound33730 : H12AffineFastState.Bounded env33730 := by
  intro p hp
  have h : env33730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33729_33730 : H12AffineEnvironment.transform 14 1 env33729 = env33730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33729 == env33730) = true)

theorem identity33730 : scanCanonicalize (H12AffineFastState.compose env33730 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound33730 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env33731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,1,1230,16401,3172,1025,0,4161,33,17,1298,1100,64,3481,5393,17664,3173,1500,20664,257,21793,4161,513]

theorem envBound33731 : H12AffineFastState.Bounded env33731 := by
  intro p hp
  have h : env33731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33730_33731 : H12AffineEnvironment.transform 12 1220 env33730 = env33731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env33730 == env33731) = true)

theorem identity33731 : scanCanonicalize (H12AffineFastState.compose env33731 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound33731 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env33732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,1212,1,1230,1197,3172,1025,0,4161,33,17,1298,1100,64,3481,5393,444,3173,1500,5124,257,4509,4161,513]

theorem envBound33732 : H12AffineFastState.Bounded env33732 := by
  intro p hp
  have h : env33732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33731_33732 : H12AffineEnvironment.transform 13 1212 env33731 = env33732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env33731 == env33732) = true)

theorem identity33732 : scanCanonicalize (H12AffineFastState.compose env33732 (packedSelected [0,1,3,4,5,8,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound33732 : packedSelected [0,1,3,4,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env33733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,65,1220,1212,1,1230,1197,3172,1025,0,0,33,17,1298,1100,64,3481,1360,444,3173,1500,1093,257,476,0,513]

theorem envBound33733 : H12AffineFastState.Bounded env33733 := by
  intro p hp
  have h : env33733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33732_33733 : H12AffineEnvironment.transform 11 65 env33732 = env33733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env33732 == env33733) = true)

theorem identity33733 : scanCanonicalize (H12AffineFastState.compose env33733 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound33733 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env33734 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,65,388,508,1,398,493,2340,321,0,0,33,17,82,268,64,2265,16,444,2341,156,261,257,476,0,513]

theorem envBound33734 : H12AffineFastState.Bounded env33734 := by
  intro p hp
  have h : env33734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33733_33734 : H12AffineEnvironment.transform 9 320 env33733 = env33734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33733 == env33734) = true)

theorem identity33734 : scanCanonicalize (H12AffineFastState.compose env33734 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound33734 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env33735 : List Nat := [2,4,8,16,32,64,128,256,512,320,81,65,388,508,1,398,493,373,321,0,0,33,17,82,268,64,136,16,444,372,156,261,257,476,0,513]

theorem envBound33735 : H12AffineFastState.Bounded env33735 := by
  intro p hp
  have h : env33735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33734_33735 : H12AffineEnvironment.transform 10 81 env33734 = env33735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env33734 == env33735) = true)

def env33736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound33736 : H12AffineFastState.Bounded env33736 := by
  intro p hp
  have h : env33736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33423_33736 : H12AffineEnvironment.transform 26 30393345 env33423 = env33736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env33423 == env33736) = true)

def env33737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound33737 : H12AffineFastState.Bounded env33737 := by
  intro p hp
  have h : env33737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33736_33737 : H12AffineEnvironment.transform 18 1024 env33736 = env33737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env33736 == env33737) = true)

theorem identity33737 : scanCanonicalize (H12AffineFastState.compose env33737 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2213020) := by decide +kernel

theorem selectedBound33737 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2213020,8328,64,15074461,16400,10507600,8830976,10502284,4235613,256,8388656,8446357,10577754]

theorem envBound33738 : H12AffineFastState.Bounded env33738 := by
  intro p hp
  have h : env33738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33737_33738 : H12AffineEnvironment.transform 23 2213020 env33737 = env33738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2213020 env33737 == env33738) = true)

def env33739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21776,2213020,8328,64,6705549,16400,2097216,431376,2102684,4235613,256,21792,46213,2175562]

theorem envBound33739 : H12AffineFastState.Bounded env33739 := by
  intro p hp
  have h : env33739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33738_33739 : H12AffineEnvironment.transform 22 21776 env33738 = env33739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21776 env33738 == env33739) = true)

def env33740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21776,98644,8328,64,4592709,16400,17800,431376,20564,4235613,256,21792,46213,96130]

theorem envBound33740 : H12AffineFastState.Bounded env33740 := by
  intro p hp
  have h : env33740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33739_33740 : H12AffineEnvironment.transform 20 17864 env33739 = env33740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env33739 == env33740) = true)

def env33741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,16,98644,8328,64,4592709,5392,4232,431376,1364,4235613,256,32,46213,74370]

theorem envBound33741 : H12AffineFastState.Bounded env33741 := by
  intro p hp
  have h : env33741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33740_33741 : H12AffineEnvironment.transform 13 5376 env33740 = env33741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33740 == env33741) = true)

theorem identity33741 : scanCanonicalize (H12AffineFastState.compose env33741 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33741 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,4194304,16,98644,8192,64,4592709,5392,4096,431376,1364,4235613,256,32,46093,74250]

theorem envBound33742 : H12AffineFastState.Bounded env33742 := by
  intro p hp
  have h : env33742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33741_33742 : H12AffineEnvironment.transform 6 8 env33741 = env33742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33741 == env33742) = true)

theorem identity33742 : scanCanonicalize (H12AffineFastState.compose env33742 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33742 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env33743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,4194304,16,41311,8192,64,4592709,5392,4096,431376,1364,4235613,256,32,46093,513]

theorem envBound33743 : H12AffineFastState.Bounded env33743 := by
  intro p hp
  have h : env33743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33742_33743 : H12AffineEnvironment.transform 15 8203 env33742 = env33743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33742 == env33743) = true)

theorem identity33743 : scanCanonicalize (H12AffineFastState.compose env33743 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33743 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env33744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,4194304,16,2,8192,64,4592709,5392,4096,406605,1364,4194304,256,32,5456,513]

theorem envBound33744 : H12AffineFastState.Bounded env33744 := by
  intro p hp
  have h : env33744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33743_33744 : H12AffineEnvironment.transform 14 8541 env33743 = env33744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33743 == env33744) = true)

theorem identity33744 : scanCanonicalize (H12AffineFastState.compose env33744 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound33744 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10361,1024,8540,4160,4194304,16,2,8192,64,4340796,5392,4096,138292,1364,4194304,256,32,5456,513]

theorem envBound33745 : H12AffineFastState.Bounded env33745 := by
  intro p hp
  have h : env33745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33744_33745 : H12AffineEnvironment.transform 17 10361 env33744 = env33745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env33744 == env33745) = true)

theorem identity33745 : scanCanonicalize (H12AffineFastState.compose env33745 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound33745 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env33746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10361,1024,8540,4160,33,16,2,8192,64,146461,5392,4096,138292,1364,33,256,32,5456,513]

theorem envBound33746 : H12AffineFastState.Bounded env33746 := by
  intro p hp
  have h : env33746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33745_33746 : H12AffineEnvironment.transform 21 33 env33745 = env33746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env33745 == env33746) = true)

theorem identity33746 : scanCanonicalize (H12AffineFastState.compose env33746 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound33746 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10361,1024,8540,4160,33,16,2,8192,64,2128,5392,4096,10361,1364,33,256,32,5456,513]

theorem envBound33747 : H12AffineFastState.Bounded env33747 := by
  intro p hp
  have h : env33747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33746_33747 : H12AffineEnvironment.transform 16 13389 env33746 = env33747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env33746 == env33747) = true)

theorem identity33747 : scanCanonicalize (H12AffineFastState.compose env33747 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33747 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33748 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8203,13341,10281,1024,8460,4112,33,16,2,8192,16,2048,5392,4096,10281,1284,33,256,32,5376,513]

theorem envBound33748 : H12AffineFastState.Bounded env33748 := by
  intro p hp
  have h : env33748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33747_33748 : H12AffineEnvironment.transform 5 16 env33747 = env33748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33747 == env33748) = true)

theorem identity33748 : scanCanonicalize (H12AffineFastState.compose env33748 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33748 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33749 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1024,1,4112,33,16,2,269,16,2048,5392,4096,2340,1284,33,256,32,5376,513]

theorem envBound33749 : H12AffineFastState.Bounded env33749 := by
  intro p hp
  have h : env33749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33748_33749 : H12AffineEnvironment.transform 12 269 env33748 = env33749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33748 == env33749) = true)

end H12CloudChart1