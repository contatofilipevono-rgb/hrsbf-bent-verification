import H12CloudChart1Data042

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans10739_10740 : H12AffineEnvironment.transform 8 14 env10739 = env10740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env10739 == env10740) = true)

def env10741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4160,4194304,16,21762,8193,65,4258940,5393,17665,32040,1365,4256861,256,21792,46092,63069]

theorem envBound10741 : H12AffineFastState.Bounded env10741 := by
  intro p hp
  have h : env10741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10726_10741 : H12AffineEnvironment.transform 6 9 env10726 = env10741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10726 == env10741) = true)

theorem identity10741 : scanCanonicalize (H12AffineFastState.compose env10741 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound10741 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24908,56436,1024,32769,4160,4194304,16,21762,8193,65,4258940,5393,17665,32040,1365,4256861,256,21792,46092,63069]

theorem envBound10742 : H12AffineFastState.Bounded env10742 := by
  intro p hp
  have h : env10742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10741_10742 : H12AffineEnvironment.transform 16 24908 env10741 = env10742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env10741 == env10742) = true)

theorem identity10742 : scanCanonicalize (H12AffineFastState.compose env10742 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound10742 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env10743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,24908,10280,1024,29789,4160,4194304,16,21762,8193,65,4196384,5393,17665,32040,1365,4194305,256,21792,16464,513]

theorem envBound10743 : H12AffineFastState.Bounded env10743 := by
  intro p hp
  have h : env10743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10742_10743 : H12AffineEnvironment.transform 14 29788 env10742 = env10743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env10742 == env10743) = true)

theorem identity10743 : scanCanonicalize (H12AffineFastState.compose env10743 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound10743 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,24908,10280,1024,29789,4160,8493,16,21762,8193,65,10509,5393,17665,32040,1365,8492,256,21792,16464,513]

theorem envBound10744 : H12AffineFastState.Bounded env10744 := by
  intro p hp
  have h : env10744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10743_10744 : H12AffineEnvironment.transform 21 8493 env10743 = env10744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env10743 == env10744) = true)

def env10745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,17,98781,8328,65,4259060,5392,17665,32041,1501,4256860,256,21792,46213,74250]

theorem envBound10745 : H12AffineFastState.Bounded env10745 := by
  intro p hp
  have h : env10745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10724_10745 : H12AffineEnvironment.transform 20 4161 env10724 = env10745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10724 == env10745) = true)

theorem identity10745 : scanCanonicalize (H12AffineFastState.compose env10745 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213350) := by decide +kernel

theorem selectedBound10745 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,213350,17,98781,8328,65,245138,5392,17665,32041,1501,243002,256,21792,46213,74250]

theorem envBound10746 : H12AffineFastState.Bounded env10746 := by
  intro p hp
  have h : env10746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10745_10746 : H12AffineEnvironment.transform 21 213350 env10745 = env10746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213350 env10745 == env10746) = true)

def env10747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,213350,17,98645,8192,65,245018,5392,17665,32041,1365,243002,256,21792,46093,74250]

theorem envBound10747 : H12AffineFastState.Bounded env10747 := by
  intro p hp
  have h : env10747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10746_10747 : H12AffineEnvironment.transform 6 8 env10746 = env10747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10746 == env10747) = true)

theorem identity10747 : scanCanonicalize (H12AffineFastState.compose env10747 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound10747 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,179512,1024,32769,4161,180273,17,2,8192,65,146509,5392,17665,32041,1365,144493,256,21792,46093,41821]

theorem envBound10748 : H12AffineFastState.Bounded env10748 := by
  intro p hp
  have h : env10748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10747_10748 : H12AffineEnvironment.transform 15 33111 env10747 = env10748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env10747 == env10748) = true)

theorem identity10748 : scanCanonicalize (H12AffineFastState.compose env10748 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10748 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,33111,131072,171061,1024,32769,4161,180273,17,2,269,65,138560,5392,17665,23588,1365,136544,256,21792,38144,33360]

theorem envBound10749 : H12AffineFastState.Bounded env10749 := by
  intro p hp
  have h : env10749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10748_10749 : H12AffineEnvironment.transform 12 269 env10748 = env10749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10748 == env10749) = true)

theorem identity10749 : scanCanonicalize (H12AffineFastState.compose env10749 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10749 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env10750 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,16384,32768,32883,131072,171061,1024,32769,4161,180273,17,2,41,65,138340,5172,17445,23588,1137,136260,36,21508,37924,33360]

theorem envBound10750 : H12AffineFastState.Bounded env10750 := by
  intro p hp
  have h : env10750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10749_10750 : H12AffineEnvironment.transform 7 36 env10749 = env10750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10749 == env10750) = true)

theorem identity10750 : scanCanonicalize (H12AffineFastState.compose env10750 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10750 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10751 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,16384,32768,32883,16401,56356,1024,32769,4161,32800,17,2,41,65,23669,5172,17445,23588,1137,21589,36,21508,37924,33360]

theorem envBound10751 : H12AffineFastState.Bounded env10751 := by
  intro p hp
  have h : env10751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10750_10751 : H12AffineEnvironment.transform 16 16401 env10750 = env10751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10750 == env10751) = true)

theorem identity10751 : scanCanonicalize (H12AffineFastState.compose env10751 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound10751 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env10752 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,16384,21541,21590,16401,2049,1024,21540,4161,21509,17,2,41,65,23669,5172,17445,23588,1137,21589,36,21508,16385,22133]

theorem envBound10752 : H12AffineFastState.Bounded env10752 := by
  intro p hp
  have h : env10752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10751_10752 : H12AffineEnvironment.transform 14 21541 env10751 = env10752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env10751 == env10752) = true)

theorem identity10752 : scanCanonicalize (H12AffineFastState.compose env10752 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10752 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10753 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21541,21511,16401,2049,1024,21540,4112,21509,17,2,41,16,23588,5172,17445,23588,1056,21508,36,21508,16385,22052]

theorem envBound10753 : H12AffineFastState.Bounded env10753 := by
  intro p hp
  have h : env10753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10752_10753 : H12AffineEnvironment.transform 5 17 env10752 = env10753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10752 == env10753) = true)

theorem identity10753 : scanCanonicalize (H12AffineFastState.compose env10753 (packedSelected [1,8] rootPS)) = affineNative (2^(13+1) ^^^ 3109) := by decide +kernel

theorem selectedBound10753 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10754 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,3109,6144,6178,3124,2049,1024,6145,4112,6176,17,2,41,16,4097,5172,2048,4097,1056,6177,36,6177,3108,6657]

theorem envBound10754 : H12AffineFastState.Bounded env10754 := by
  intro p hp
  have h : env10754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10753_10754 : H12AffineEnvironment.transform 13 3109 env10753 = env10754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3109 env10753 == env10754) = true)

theorem identity10754 : scanCanonicalize (H12AffineFastState.compose env10754 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound10754 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env10755 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1589,4096,41,528,5685,5655,513,1588,1024,5684,4112,5653,17,2,41,16,4097,5172,1589,4097,1056,5652,36,5652,529,5172]

theorem envBound10755 : H12AffineFastState.Bounded env10755 := by
  intro p hp
  have h : env10755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10754_10755 : H12AffineEnvironment.transform 10 1589 env10754 = env10755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env10754 == env10755) = true)

theorem identity10755 : scanCanonicalize (H12AffineFastState.compose env10755 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound10755 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env10756 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1589,1572,41,528,17,51,513,1588,1024,16,1588,49,17,2,41,16,1573,528,1589,1573,1056,48,36,48,529,528]

theorem envBound10756 : H12AffineFastState.Bounded env10756 := by
  intro p hp
  have h : env10756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10755_10756 : H12AffineEnvironment.transform 11 1572 env10755 = env10756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env10755 == env10756) = true)

theorem identity10756 : scanCanonicalize (H12AffineFastState.compose env10756 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10757 : List Nat := [2,4,8,16,32,17,8,36,512,20,545,560,41,528,17,51,513,544,20,16,544,49,17,2,41,16,561,528,545,561,52,48,36,48,529,528]

theorem envBound10757 : H12AffineFastState.Bounded env10757 := by
  intro p hp
  have h : env10757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10756_10757 : H12AffineEnvironment.transform 9 20 env10756 = env10757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10756 == env10757) = true)

theorem identity10757 : scanCanonicalize (H12AffineFastState.compose env10757 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10757 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10758 : List Nat := [2,4,8,16,17,17,8,21,512,20,528,513,24,528,17,2,513,529,20,16,529,0,17,2,24,16,512,528,528,512,5,1,21,1,529,528]

theorem envBound10758 : H12AffineFastState.Bounded env10758 := by
  intro p hp
  have h : env10758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10757_10758 : H12AffineEnvironment.transform 4 17 env10757 = env10758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10757 == env10758) = true)

theorem identity10758 : scanCanonicalize (H12AffineFastState.compose env10758 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10758 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10759 : List Nat := [2,4,8,1,0,0,8,4,512,5,513,513,9,513,0,2,513,512,5,1,512,0,0,2,9,1,512,513,513,512,5,1,4,1,512,513]

theorem envBound10759 : H12AffineFastState.Bounded env10759 := by
  intro p hp
  have h : env10759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10758_10759 : H12AffineEnvironment.transform 3 1 env10758 = env10759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10758 == env10759) = true)

theorem identity10759 : scanCanonicalize (H12AffineFastState.compose env10759 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10760 : List Nat := [2,4,8,1,0,0,8,4,1,5,0,0,9,0,0,2,0,1,5,1,1,0,0,2,9,1,1,0,0,1,5,1,4,1,1,0]

theorem envBound10760 : H12AffineFastState.Bounded env10760 := by
  intro p hp
  have h : env10760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10759_10760 : H12AffineEnvironment.transform 8 1 env10759 = env10760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10759 == env10760) = true)

theorem identity10760 : scanCanonicalize (H12AffineFastState.compose env10760 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10761 : List Nat := [2,4,3,1,0,0,3,4,1,5,0,0,2,0,0,2,0,1,5,1,1,0,0,2,2,1,1,0,0,1,5,1,4,1,1,0]

theorem envBound10761 : H12AffineFastState.Bounded env10761 := by
  intro p hp
  have h : env10761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10760_10761 : H12AffineEnvironment.transform 2 3 env10760 = env10761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10760 == env10761) = true)

def env10762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,213350,17,98644,8193,65,245019,5392,17665,32041,1364,243002,256,21792,46092,74250]

theorem envBound10762 : H12AffineFastState.Bounded env10762 := by
  intro p hp
  have h : env10762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10746_10762 : H12AffineEnvironment.transform 6 9 env10746 = env10762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10746 == env10762) = true)

theorem identity10762 : scanCanonicalize (H12AffineFastState.compose env10762 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10762 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,156013,17,41311,8193,65,171280,5392,17665,32041,1364,169265,256,21792,46092,513]

theorem envBound10763 : H12AffineFastState.Bounded env10763 := by
  intro p hp
  have h : env10763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10762_10763 : H12AffineEnvironment.transform 15 8203 env10762 = env10763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10762 == env10763) = true)

theorem identity10763 : scanCanonicalize (H12AffineFastState.compose env10763 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10763 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64809,1024,32769,4161,8572,17,41311,8193,65,56577,5392,17665,32041,1364,54560,256,21792,46092,513]

theorem envBound10764 : H12AffineFastState.Bounded env10764 := by
  intro p hp
  have h : env10764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10763_10764 : H12AffineEnvironment.transform 16 16401 env10763 = env10764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10763 == env10764) = true)

theorem identity10764 : scanCanonicalize (H12AffineFastState.compose env10764 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10764 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,23669,1024,8541,4161,8572,17,3,8193,65,31837,5392,17665,32041,1364,29820,256,21792,5456,513]

theorem envBound10765 : H12AffineFastState.Bounded env10765 := by
  intro p hp
  have h : env10765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10764_10765 : H12AffineEnvironment.transform 14 8540 env10764 = env10765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10764 == env10765) = true)

theorem identity10765 : scanCanonicalize (H12AffineFastState.compose env10765 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10765 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10766 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16401,23588,1024,8460,4112,8493,17,3,8193,16,31756,5392,17665,32041,1285,29741,256,21792,5377,513]

theorem envBound10766 : H12AffineFastState.Bounded env10766 := by
  intro p hp
  have h : env10766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10765_10766 : H12AffineEnvironment.transform 5 17 env10765 = env10766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10765 == env10766) = true)

theorem identity10766 : scanCanonicalize (H12AffineFastState.compose env10766 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15133) := by decide +kernel

theorem selectedBound10766 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10767 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,15133,8461,8203,15116,10041,1024,8460,4112,8493,17,3,8193,16,1809,5392,15900,1588,1285,3888,256,11837,5377,513]

theorem envBound10767 : H12AffineFastState.Bounded env10767 := by
  intro p hp
  have h : env10767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10766_10767 : H12AffineEnvironment.transform 13 15133 env10766 = env10767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15133 env10766 == env10767) = true)

theorem identity10767 : scanCanonicalize (H12AffineFastState.compose env10767 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound10767 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10768 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1808,4096,8192,13325,8461,8203,13340,10041,1024,8460,4112,8493,17,3,8193,16,1809,5392,12556,1588,1285,32,256,8493,5377,513]

theorem envBound10768 : H12AffineFastState.Bounded env10768 := by
  intro p hp
  have h : env10768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10767_10768 : H12AffineEnvironment.transform 10 1808 env10767 = env10768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env10767 == env10768) = true)

theorem identity10768 : scanCanonicalize (H12AffineFastState.compose env10768 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound10768 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env10769 : List Nat := [2,4,8,16,32,17,9,256,512,36,820,4096,8192,12329,8461,8203,12344,8989,36,8460,4112,8493,17,3,8193,16,821,4404,12556,528,289,32,256,8493,4389,513]

theorem envBound10769 : H12AffineFastState.Bounded env10769 := by
  intro p hp
  have h : env10769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10768_10769 : H12AffineEnvironment.transform 9 36 env10768 = env10769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env10768 == env10769) = true)

theorem identity10769 : scanCanonicalize (H12AffineFastState.compose env10769 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound10769 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10770 : List Nat := [2,4,8,16,32,17,9,52,512,36,512,4096,8192,12329,8249,8203,12344,8745,36,8248,4112,8217,17,3,8193,16,513,4096,12344,528,21,32,52,8217,4113,513]

theorem envBound10770 : H12AffineFastState.Bounded env10770 := by
  intro p hp
  have h : env10770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10769_10770 : H12AffineEnvironment.transform 7 52 env10769 = env10770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env10769 == env10770) = true)

theorem identity10770 : scanCanonicalize (H12AffineFastState.compose env10770 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound10770 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env10771 : List Nat := [2,4,8,16,32,17,9,52,512,36,512,4096,57,4112,0,50,4097,528,36,1,4112,32,17,3,56,16,513,4096,4097,528,21,32,52,32,4113,513]

theorem envBound10771 : H12AffineFastState.Bounded env10771 := by
  intro p hp
  have h : env10771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10770_10771 : H12AffineEnvironment.transform 12 57 env10770 = env10771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env10770 == env10771) = true)

theorem identity10771 : scanCanonicalize (H12AffineFastState.compose env10771 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound10771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10772 : List Nat := [2,4,8,16,32,17,9,52,33,36,33,4096,57,4112,0,50,4097,49,36,1,4112,32,17,3,56,16,32,4096,4097,49,21,32,52,32,4113,32]

theorem envBound10772 : H12AffineFastState.Bounded env10772 := by
  intro p hp
  have h : env10772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10771_10772 : H12AffineEnvironment.transform 8 33 env10771 = env10772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10771 == env10772) = true)

theorem identity10772 : scanCanonicalize (H12AffineFastState.compose env10772 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10773 : List Nat := [2,4,8,16,17,17,9,5,16,21,16,4096,8,4112,0,3,4097,0,21,1,4112,17,17,3,9,16,17,4096,4097,0,21,17,5,17,4113,17]

theorem envBound10773 : H12AffineFastState.Bounded env10773 := by
  intro p hp
  have h : env10773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10772_10773 : H12AffineEnvironment.transform 4 17 env10772 = env10773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10772 == env10773) = true)

theorem identity10773 : scanCanonicalize (H12AffineFastState.compose env10773 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10774 : List Nat := [2,4,8,0,1,1,9,5,0,5,0,4096,8,4096,0,3,4097,0,5,1,4096,1,1,3,9,0,1,4096,4097,0,5,1,5,1,4097,1]

theorem envBound10774 : H12AffineFastState.Bounded env10774 := by
  intro p hp
  have h : env10774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10773_10774 : H12AffineEnvironment.transform 3 0 env10773 = env10774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10773 == env10774) = true)

theorem identity10774 : scanCanonicalize (H12AffineFastState.compose env10774 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound10774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10775 : List Nat := [2,4,8,0,1,1,9,5,0,5,0,1,8,1,0,3,0,0,5,1,1,1,1,3,9,0,1,1,0,0,5,1,5,1,0,1]

theorem envBound10775 : H12AffineFastState.Bounded env10775 := by
  intro p hp
  have h : env10775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10774_10775 : H12AffineEnvironment.transform 11 1 env10774 = env10775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env10774 == env10775) = true)

def env10776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101329,98780,8328,65,6352052,2098512,17664,2125160,2102684,6349852,256,21792,46213,2175563]

theorem envBound10776 : H12AffineFastState.Bounded env10776 := by
  intro p hp
  have h : env10776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10723_10776 : H12AffineEnvironment.transform 17 179513 env10723 = env10776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env10723 == env10776) = true)

def env10777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,17,98780,8328,65,4259060,5392,17664,32040,1500,4256860,256,21792,46213,74251]

theorem envBound10777 : H12AffineFastState.Bounded env10777 := by
  intro p hp
  have h : env10777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10776_10777 : H12AffineEnvironment.transform 20 4160 env10776 = env10777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10776 == env10777) = true)

theorem identity10777 : scanCanonicalize (H12AffineFastState.compose env10777 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243123) := by decide +kernel

theorem selectedBound10777 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,243123,17,98780,8328,65,215367,5392,17664,32040,1500,213487,256,21792,46213,74251]

theorem envBound10778 : H12AffineFastState.Bounded env10778 := by
  intro p hp
  have h : env10778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10777_10778 : H12AffineEnvironment.transform 21 243123 env10777 = env10778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243123 env10777 == env10778) = true)

def env10779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,243003,17,98644,8192,65,215367,5392,17664,32040,1364,213351,256,21792,46093,74251]

theorem envBound10779 : H12AffineFastState.Bounded env10779 := by
  intro p hp
  have h : env10779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10778_10779 : H12AffineEnvironment.transform 6 8 env10778 = env10779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10778 == env10779) = true)

theorem identity10779 : scanCanonicalize (H12AffineFastState.compose env10779 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound10779 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,179513,1024,32769,4160,144493,17,2,8192,65,182289,5392,17664,32040,1364,180273,256,21792,46093,41821]

theorem envBound10780 : H12AffineFastState.Bounded env10780 := by
  intro p hp
  have h : env10780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10779_10780 : H12AffineEnvironment.transform 15 33110 env10779 = env10780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env10779 == env10780) = true)

theorem identity10780 : scanCanonicalize (H12AffineFastState.compose env10780 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound10780 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env10781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,5392,43049,1024,32769,4160,8573,17,2,8192,65,56577,5392,17664,32040,1364,54561,256,21792,46093,41821]

theorem envBound10781 : H12AffineFastState.Bounded env10781 := by
  intro p hp
  have h : env10781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10780_10781 : H12AffineEnvironment.transform 16 5392 env10780 = env10781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env10780 == env10781) = true)

theorem identity10781 : scanCanonicalize (H12AffineFastState.compose env10781 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound10781 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env10782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,23669,1024,29789,4160,8573,17,2,8192,65,10589,5392,17664,32040,1364,8573,256,21792,16465,22273]

theorem envBound10782 : H12AffineFastState.Bounded env10782 := by
  intro p hp
  have h : env10782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10781_10782 : H12AffineEnvironment.transform 14 29788 env10781 = env10782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env10781 == env10782) = true)

theorem identity10782 : scanCanonicalize (H12AffineFastState.compose env10782 (packedSelected [0,4,7,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound10782 : packedSelected [0,4,7,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env10783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,372,34,5392,10589,1024,373,4160,8573,17,2,8192,65,10589,5392,12328,2048,1364,8573,256,8200,13689,8745]

theorem envBound10783 : H12AffineFastState.Bounded env10783 := by
  intro p hp
  have h : env10783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10782_10783 : H12AffineEnvironment.transform 13 13608 env10782 = env10783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env10782 == env10783) = true)

theorem identity10783 : scanCanonicalize (H12AffineFastState.compose env10783 (packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound10783 : packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS < 2^1333 := by decide +kernel

def env10784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,372,34,5392,2421,1024,373,4160,341,17,2,40,65,2421,5392,4096,2048,1364,341,256,32,5457,513]

theorem envBound10784 : H12AffineFastState.Bounded env10784 := by
  intro p hp
  have h : env10784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10783_10784 : H12AffineEnvironment.transform 12 40 env10783 = env10784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env10783 == env10784) = true)

theorem identity10784 : scanCanonicalize (H12AffineFastState.compose env10784 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10784 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10785 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,0,34,5220,2049,1024,1,4160,33,17,2,40,65,2049,5220,4096,2048,1056,33,116,32,5157,513]

theorem envBound10785 : H12AffineFastState.Bounded env10785 := by
  intro p hp
  have h : env10785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10784_10785 : H12AffineEnvironment.transform 7 116 env10784 = env10785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10784 == env10785) = true)

theorem identity10785 : scanCanonicalize (H12AffineFastState.compose env10785 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10785 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10786 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4112,33,17,2,40,17,2049,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound10786 : H12AffineFastState.Bounded env10786 := by
  intro p hp
  have h : env10786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10785_10786 : H12AffineEnvironment.transform 5 16 env10785 = env10786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10785 == env10786) = true)

theorem identity10786 : scanCanonicalize (H12AffineFastState.compose env10786 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound10786 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10787 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,40,2048,0,34,2064,2049,1024,1,3124,33,17,2,40,17,2049,2064,3108,2048,1056,33,36,32,2049,513]

theorem envBound10787 : H12AffineFastState.Bounded env10787 := by
  intro p hp
  have h : env10787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10786_10787 : H12AffineEnvironment.transform 11 3108 env10786 = env10787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env10786 == env10787) = true)

theorem identity10787 : scanCanonicalize (H12AffineFastState.compose env10787 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10787 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10788 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,40,2048,0,34,2064,2049,52,1,2048,33,17,2,40,17,2049,2064,2064,2048,20,33,36,32,2049,513]

theorem envBound10788 : H12AffineFastState.Bounded env10788 := by
  intro p hp
  have h : env10788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10787_10788 : H12AffineEnvironment.transform 9 52 env10787 = env10788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10787 == env10788) = true)

def env10789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,243002,17,98645,8193,65,215367,5392,17664,32040,1365,213350,256,21792,46092,74251]

theorem envBound10789 : H12AffineFastState.Bounded env10789 := by
  intro p hp
  have h : env10789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10778_10789 : H12AffineEnvironment.transform 6 9 env10778 = env10789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10778 == env10789) = true)

theorem identity10789 : scanCanonicalize (H12AffineFastState.compose env10789 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10789 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4160,169264,17,41311,8193,65,158029,5392,17664,32040,1365,156012,256,21792,46092,513]

theorem envBound10790 : H12AffineFastState.Bounded env10790 := by
  intro p hp
  have h : env10790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10789_10790 : H12AffineEnvironment.transform 15 8202 env10789 = env10790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10789 == env10790) = true)

theorem identity10790 : scanCanonicalize (H12AffineFastState.compose env10790 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound10790 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64809,1024,32769,4160,54560,17,41311,8193,65,10589,5392,17664,32040,1365,8572,256,21792,46092,513]

theorem envBound10791 : H12AffineFastState.Bounded env10791 := by
  intro p hp
  have h : env10791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10790_10791 : H12AffineEnvironment.transform 16 16400 env10790 = env10791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10790 == env10791) = true)

theorem identity10791 : scanCanonicalize (H12AffineFastState.compose env10791 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound10791 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,23668,1024,8540,4160,29821,17,2,8193,65,10589,5392,17664,32040,1365,8572,256,21792,5457,513]

theorem envBound10792 : H12AffineFastState.Bounded env10792 := by
  intro p hp
  have h : env10792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10791_10792 : H12AffineEnvironment.transform 14 8541 env10791 = env10792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env10791 == env10792) = true)

theorem identity10792 : scanCanonicalize (H12AffineFastState.compose env10792 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound10792 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8541,8202,13672,10508,1024,8540,4160,261,17,2,8193,65,10589,5392,12408,2128,1365,8572,256,8280,5457,513]

theorem envBound10793 : H12AffineFastState.Bounded env10793 := by
  intro p hp
  have h : env10793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10792_10793 : H12AffineEnvironment.transform 13 13688 env10792 = env10793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env10792 == env10793) = true)

theorem identity10793 : scanCanonicalize (H12AffineFastState.compose env10793 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound10793 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4113,1076,1379,4097,3173,1024,1077,4160,261,17,2,1384,65,3124,5392,5393,2128,1365,1045,256,1329,5457,513]

theorem envBound10794 : H12AffineFastState.Bounded env10794 := by
  intro p hp
  have h : env10794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10793_10794 : H12AffineEnvironment.transform 12 1385 env10793 = env10794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env10793 == env10794) = true)

theorem identity10794 : scanCanonicalize (H12AffineFastState.compose env10794 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound10794 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env10795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,1385,2129,1076,1379,2113,3173,1024,1077,2048,261,17,2,1384,65,3124,3408,3409,2128,1365,1045,256,1329,3345,513]

theorem envBound10795 : H12AffineFastState.Bounded env10795 := by
  intro p hp
  have h : env10795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10794_10795 : H12AffineEnvironment.transform 11 2112 env10794 = env10795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env10794 == env10795) = true)

theorem identity10795 : scanCanonicalize (H12AffineFastState.compose env10795 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10795 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env10796 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2112,1053,2129,1076,1047,2113,3173,1024,1077,2048,113,17,2,1052,65,3124,3108,3109,2128,1057,1045,116,1093,3173,513]

theorem envBound10796 : H12AffineFastState.Bounded env10796 := by
  intro p hp
  have h : env10796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10795_10796 : H12AffineEnvironment.transform 7 116 env10795 = env10796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10795 == env10796) = true)

theorem identity10796 : scanCanonicalize (H12AffineFastState.compose env10796 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10797 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,2112,40,2129,1,34,2113,2128,53,0,2048,113,17,2,41,65,2049,2065,2064,2128,20,32,116,112,2128,513]

theorem envBound10797 : H12AffineFastState.Bounded env10797 := by
  intro p hp
  have h : env10797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10796_10797 : H12AffineEnvironment.transform 9 53 env10796 = env10797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10796 == env10797) = true)

theorem identity10797 : scanCanonicalize (H12AffineFastState.compose env10797 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10797 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10798 : List Nat := [2,4,8,16,32,64,9,116,512,53,0,64,40,81,1,34,65,80,53,0,0,113,17,2,41,65,1,17,16,80,20,32,116,112,80,513]

theorem envBound10798 : H12AffineFastState.Bounded env10798 := by
  intro p hp
  have h : env10798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10797_10798 : H12AffineEnvironment.transform 10 0 env10797 = env10798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10797 == env10798) = true)

def env10799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98780,8328,65,4259061,5393,17664,32041,1501,4256861,256,21792,46213,74250]

theorem envBound10799 : H12AffineFastState.Bounded env10799 := by
  intro p hp
  have h : env10799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10776_10799 : H12AffineEnvironment.transform 20 4161 env10776 = env10799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10776 == env10799) = true)

theorem identity10799 : scanCanonicalize (H12AffineFastState.compose env10799 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10799 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,4194304,16,41431,8328,65,4259061,5393,17664,32041,1501,4256861,256,21792,46213,513]

theorem envBound10800 : H12AffineFastState.Bounded env10800 := by
  intro p hp
  have h : env10800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10799_10800 : H12AffineEnvironment.transform 15 8203 env10799 = env10800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10799 == env10800) = true)

theorem identity10800 : scanCanonicalize (H12AffineFastState.compose env10800 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound10800 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env10801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,169401,16,41431,8328,65,158028,5393,17664,32041,1501,156132,256,21792,46213,513]

theorem envBound10801 : H12AffineFastState.Bounded env10801 := by
  intro p hp
  have h : env10801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10800_10801 : H12AffineEnvironment.transform 21 169401 env10800 = env10801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env10800 == env10801) = true)

theorem identity10801 : scanCanonicalize (H12AffineFastState.compose env10801 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10801 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env10802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,169264,16,41310,8193,65,158028,5393,17664,32041,1364,156013,256,21792,46092,513]

theorem envBound10802 : H12AffineFastState.Bounded env10802 := by
  intro p hp
  have h : env10802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10801_10802 : H12AffineEnvironment.transform 6 9 env10801 = env10802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10801 == env10802) = true)

theorem identity10802 : scanCanonicalize (H12AffineFastState.compose env10802 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound10802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10280,1024,32769,4161,33,16,41310,8193,65,64605,5393,17664,32041,1364,62588,256,21792,46092,513]

theorem envBound10803 : H12AffineFastState.Bounded env10803 := by
  intro p hp
  have h : env10803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10802_10803 : H12AffineEnvironment.transform 16 38161 env10802 = env10803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env10802 == env10803) = true)

theorem identity10803 : scanCanonicalize (H12AffineFastState.compose env10803 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10803 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,5392,10280,1024,0,4161,33,16,8543,8193,65,31836,5393,17664,32041,1364,29821,256,21792,13325,513]

theorem envBound10804 : H12AffineFastState.Bounded env10804 := by
  intro p hp
  have h : env10804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10803_10804 : H12AffineEnvironment.transform 14 1 env10803 = env10804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10803 == env10804) = true)

theorem identity10804 : scanCanonicalize (H12AffineFastState.compose env10804 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10804 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,5392,10280,1024,0,4161,33,16,8543,8193,65,2048,5393,12636,2421,1364,33,256,8572,13325,513]

theorem envBound10805 : H12AffineFastState.Bounded env10805 := by
  intro p hp
  have h : env10805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10804_10805 : H12AffineEnvironment.transform 13 13404 env10804 = env10805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10804 == env10805) = true)

theorem identity10805 : scanCanonicalize (H12AffineFastState.compose env10805 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10805 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env10806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1024,0,4161,33,16,2,348,65,2048,5393,4097,2421,1364,33,256,33,5456,513]

theorem envBound10806 : H12AffineFastState.Bounded env10806 := by
  intro p hp
  have h : env10806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10805_10806 : H12AffineEnvironment.transform 12 349 env10805 = env10806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10805 == env10806) = true)

theorem identity10806 : scanCanonicalize (H12AffineFastState.compose env10806 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10806 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10807 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4113,1,342,4096,2421,272,0,4161,33,16,2,348,65,2048,4097,4097,2421,68,33,256,33,4160,513]

theorem envBound10807 : H12AffineFastState.Bounded env10807 := by
  intro p hp
  have h : env10807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10806_10807 : H12AffineEnvironment.transform 9 272 env10806 = env10807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10806 == env10807) = true)

theorem identity10807 : scanCanonicalize (H12AffineFastState.compose env10807 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound10807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10808 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,49,349,32,1,342,49,2421,272,0,112,33,16,2,348,65,2048,48,48,2421,68,33,256,33,113,513]

theorem envBound10808 : H12AffineFastState.Bounded env10808 := by
  intro p hp
  have h : env10808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10807_10808 : H12AffineEnvironment.transform 11 49 env10807 = env10808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env10807 == env10808) = true)

theorem identity10808 : scanCanonicalize (H12AffineFastState.compose env10808 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10808 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10809 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,49,41,32,1,34,49,2049,100,0,112,33,16,2,40,65,2048,48,48,2049,68,33,116,33,113,513]

theorem envBound10809 : H12AffineFastState.Bounded env10809 := by
  intro p hp
  have h : env10809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10808_10809 : H12AffineEnvironment.transform 7 116 env10808 = env10809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10808 == env10809) = true)

theorem identity10809 : scanCanonicalize (H12AffineFastState.compose env10809 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10809 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10810 : List Nat := [2,4,8,16,32,64,9,116,1,100,2048,49,41,32,1,34,49,2049,100,0,112,33,16,2,40,65,2048,48,48,2049,68,33,116,33,113,0]

theorem envBound10810 : H12AffineFastState.Bounded env10810 := by
  intro p hp
  have h : env10810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10809_10810 : H12AffineEnvironment.transform 8 1 env10809 = env10810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10809 == env10810) = true)

theorem identity10810 : scanCanonicalize (H12AffineFastState.compose env10810 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10810 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10811 : List Nat := [2,4,8,16,0,64,9,84,1,68,2048,17,9,0,1,2,17,2049,68,0,80,1,16,2,8,65,2048,16,16,2049,68,1,84,1,81,0]

theorem envBound10811 : H12AffineFastState.Bounded env10811 := by
  intro p hp
  have h : env10811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10810_10811 : H12AffineEnvironment.transform 4 0 env10810 = env10811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10810 == env10811) = true)

def env10812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound10812 : H12AffineFastState.Bounded env10812 := by
  intro p hp
  have h : env10812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10629_10812 : H12AffineEnvironment.transform 18 1025 env10629 = env10812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10629 == env10812) = true)

theorem identity10812 : scanCanonicalize (H12AffineFastState.compose env10812 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444776) := by decide +kernel

theorem selectedBound10812 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444776,8328,65,14847465,313701,10507601,8830977,10799609,4466728,257,8685892,8677600,10874415]

theorem envBound10813 : H12AffineFastState.Bounded env10813 := by
  intro p hp
  have h : env10813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10812_10813 : H12AffineEnvironment.transform 23 2444776 env10812 = env10813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444776 env10812 == env10813) = true)

def env10814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444776,8328,65,6705549,313701,2394421,138341,2102685,4466728,257,21792,46212,2175563]

theorem envBound10814 : H12AffineFastState.Bounded env10814 := by
  intro p hp
  have h : env10814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10813_10814 : H12AffineEnvironment.transform 22 318564 env10813 = env10814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318564 env10813 == env10814) = true)

def env10815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444640,8192,65,6705413,313701,2394421,138341,2102549,4466728,257,21792,46092,2175563]

theorem envBound10815 : H12AffineFastState.Bounded env10815 := by
  intro p hp
  have h : env10815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10814_10815 : H12AffineEnvironment.transform 6 8 env10814 = env10815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10814 == env10815) = true)

def env10816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318564,2444640,8192,65,158029,313701,2394421,138341,2102549,2101344,257,21792,46092,2175563]

theorem envBound10816 : H12AffineFastState.Bounded env10816 := by
  intro p hp
  have h : env10816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10815_10816 : H12AffineEnvironment.transform 21 2373704 env10815 = env10816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env10815 == env10816) = true)

theorem identity10816 : scanCanonicalize (H12AffineFastState.compose env10816 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound10816 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,329730,318564,294186,8192,65,158029,313701,375167,138341,75103,73770,257,21792,46092,513]

theorem envBound10817 : H12AffineFastState.Bounded env10817 := by
  intro p hp
  have h : env10817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10816_10817 : H12AffineEnvironment.transform 20 77898 env10816 = env10817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env10816 == env10817) = true)

def env10818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77898,73770,62540,21762,8192,65,158029,57677,102743,138341,75103,73770,257,21792,46092,513]

theorem envBound10818 : H12AffineFastState.Bounded env10818 := by
  intro p hp
  have h : env10818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10817_10818 : H12AffineEnvironment.transform 17 10280 env10817 = env10818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10817 == env10818) = true)

def env10819 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77850,73770,62492,21762,8192,17,157981,57629,102663,138293,75023,73770,257,21792,46092,513]

theorem envBound10819 : H12AffineFastState.Bounded env10819 := by
  intro p hp
  have h : env10819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10818_10819 : H12AffineEnvironment.transform 5 16 env10818 = env10819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10818 == env10819) = true)

theorem identity10819 : scanCanonicalize (H12AffineFastState.compose env10819 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound10819 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env10820 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,103446,10280,1025,32769,77850,73770,62492,21762,8192,17,130315,57629,102663,100387,75023,73770,257,21792,46092,513]

theorem envBound10820 : H12AffineFastState.Bounded env10820 := by
  intro p hp
  have h : env10820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10819_10820 : H12AffineEnvironment.transform 16 103446 env10819 = env10820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env10819 == env10820) = true)

theorem identity10820 : scanCanonicalize (H12AffineFastState.compose env10820 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10820 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env10821 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,65536,70678,10280,1025,1,77850,73770,29724,21762,8192,17,97547,24861,69895,67619,75023,73770,257,21792,13324,513]

theorem envBound10821 : H12AffineFastState.Bounded env10821 := by
  intro p hp
  have h : env10821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10820_10821 : H12AffineEnvironment.transform 14 0 env10820 = env10821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10820 == env10821) = true)

theorem identity10821 : scanCanonicalize (H12AffineFastState.compose env10821 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound10821 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10822 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,263,5393,10280,1025,1,12573,8493,29724,21762,8192,17,31756,24861,4096,2340,9224,8493,257,21792,13324,513]

theorem envBound10822 : H12AffineFastState.Bounded env10822 := by
  intro p hp
  have h : env10822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10821_10822 : H12AffineEnvironment.transform 15 263 env10821 = env10822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env10821 == env10822) = true)

theorem identity10822 : scanCanonicalize (H12AffineFastState.compose env10822 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10822 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10823 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,5393,2340,1025,1,4113,33,21776,21762,268,17,23808,16401,4096,2340,1284,33,257,21792,5376,513]

theorem envBound10823 : H12AffineFastState.Bounded env10823 := by
  intro p hp
  have h : env10823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10822_10823 : H12AffineEnvironment.transform 12 268 env10822 = env10823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10822 == env10823) = true)

theorem identity10823 : scanCanonicalize (H12AffineFastState.compose env10823 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10823 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10824 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1025,1,4113,33,17,3,268,17,2049,5392,4096,2340,1284,33,257,33,5376,513]

theorem envBound10824 : H12AffineFastState.Bounded env10824 := by
  intro p hp
  have h : env10824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10823_10824 : H12AffineEnvironment.transform 13 5377 env10823 = env10824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10823 == env10824) = true)

theorem identity10824 : scanCanonicalize (H12AffineFastState.compose env10824 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10824 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10825 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1296,268,17,0,263,1,2340,1025,1,1281,33,17,3,268,17,2049,0,1296,2340,1284,33,257,33,16,513]

theorem envBound10825 : H12AffineFastState.Bounded env10825 := by
  intro p hp
  have h : env10825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10824_10825 : H12AffineEnvironment.transform 11 1296 env10824 = env10825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10824 == env10825) = true)

theorem identity10825 : scanCanonicalize (H12AffineFastState.compose env10825 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1290) := by decide +kernel

theorem selectedBound10825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10826 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1290,1296,268,17,0,263,1,1070,1025,1,1281,33,17,3,268,17,1291,0,1296,1070,1284,33,257,33,16,513]

theorem envBound10826 : H12AffineFastState.Bounded env10826 := by
  intro p hp
  have h : env10826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10825_10826 : H12AffineEnvironment.transform 10 1290 env10825 = env10826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1290 env10825 == env10826) = true)

theorem identity10826 : scanCanonicalize (H12AffineFastState.compose env10826 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10826 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10827 : List Nat := [2,4,8,16,32,16,8,5,512,1024,1039,1045,9,17,0,2,1,1070,1025,1,1028,33,17,3,9,17,1038,0,1045,1070,1025,33,4,33,16,513]

theorem envBound10827 : H12AffineFastState.Bounded env10827 := by
  intro p hp
  have h : env10827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10826_10827 : H12AffineEnvironment.transform 7 5 env10826 = env10827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10826 == env10827) = true)

theorem identity10827 : scanCanonicalize (H12AffineFastState.compose env10827 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10827 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10828 : List Nat := [2,4,8,1,32,1,8,5,512,1024,1039,1028,9,0,0,2,1,1070,1025,1,1028,33,0,3,9,0,1038,0,1028,1070,1025,33,4,33,1,513]

theorem envBound10828 : H12AffineFastState.Bounded env10828 := by
  intro p hp
  have h : env10828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10827_10828 : H12AffineEnvironment.transform 3 1 env10827 = env10828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10827 == env10828) = true)

theorem identity10828 : scanCanonicalize (H12AffineFastState.compose env10828 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10828 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10829 : List Nat := [2,4,3,1,32,1,3,5,512,1024,1028,1028,2,0,0,2,1,1061,1025,1,1028,33,0,3,2,0,1029,0,1028,1061,1025,33,4,33,1,513]

theorem envBound10829 : H12AffineFastState.Bounded env10829 := by
  intro p hp
  have h : env10829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10828_10829 : H12AffineEnvironment.transform 2 3 env10828 = env10829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10828 == env10829) = true)

theorem identity10829 : scanCanonicalize (H12AffineFastState.compose env10829 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10829 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10830 : List Nat := [2,4,3,1,1,1,3,5,512,1024,1028,1028,2,0,0,2,1,1028,1025,1,1028,0,0,3,2,0,1029,0,1028,1028,1025,0,4,0,1,513]

theorem envBound10830 : H12AffineFastState.Bounded env10830 := by
  intro p hp
  have h : env10830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10829_10830 : H12AffineEnvironment.transform 4 1 env10829 = env10830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10829 == env10830) = true)

theorem identity10830 : scanCanonicalize (H12AffineFastState.compose env10830 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 512) := by decide +kernel

theorem selectedBound10830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10831 : List Nat := [2,4,3,1,1,1,3,5,512,512,516,516,2,0,0,2,1,516,513,1,516,0,0,3,2,0,517,0,516,516,513,0,4,0,1,513]

theorem envBound10831 : H12AffineFastState.Bounded env10831 := by
  intro p hp
  have h : env10831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10830_10831 : H12AffineEnvironment.transform 9 512 env10830 = env10831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 512 env10830 == env10831) = true)

def env10832 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77851,73770,62493,21762,8192,16,157980,57628,102662,138292,75022,73770,257,21792,46092,513]

theorem envBound10832 : H12AffineFastState.Bounded env10832 := by
  intro p hp
  have h : env10832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10818_10832 : H12AffineEnvironment.transform 5 17 env10818 = env10832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10818 == env10832) = true)

theorem identity10832 : scanCanonicalize (H12AffineFastState.compose env10832 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound10832 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env10833 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,32768,65536,131072,10280,1025,32769,77851,73770,32784,8463,8192,16,138513,38161,102662,138292,75022,73770,257,8493,46092,513]

theorem envBound10833 : H12AffineFastState.Bounded env10833 := by
  intro p hp
  have h : env10833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10832_10833 : H12AffineEnvironment.transform 13 13325 env10832 = env10833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env10832 == env10833) = true)

theorem identity10833 : scanCanonicalize (H12AffineFastState.compose env10833 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10833 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env10834 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,65536,131072,2340,1025,32769,69911,65830,32784,3,268,16,138513,38161,102662,138292,66562,65830,257,33,38144,513]

theorem envBound10834 : H12AffineFastState.Bounded env10834 := by
  intro p hp
  have h : env10834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10833_10834 : H12AffineEnvironment.transform 12 268 env10833 = env10834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10833 == env10834) = true)

theorem identity10834 : scanCanonicalize (H12AffineFastState.compose env10834 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound10834 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10835 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,65536,103446,2340,1025,32769,69911,65830,32784,3,268,16,100615,38161,102662,100386,66562,65830,257,33,38144,513]

theorem envBound10835 : H12AffineFastState.Bounded env10835 := by
  intro p hp
  have h : env10835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10834_10835 : H12AffineEnvironment.transform 16 103446 env10834 = env10835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env10834 == env10835) = true)

theorem identity10835 : scanCanonicalize (H12AffineFastState.compose env10835 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10835 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10836 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,262,38160,2340,1025,32769,4113,32,32784,3,268,16,34817,38161,36864,35108,1284,32,257,33,38144,513]

theorem envBound10836 : H12AffineFastState.Bounded env10836 := by
  intro p hp
  have h : env10836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10835_10836 : H12AffineEnvironment.transform 15 262 env10835 = env10836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10835 == env10836) = true)

theorem identity10836 : scanCanonicalize (H12AffineFastState.compose env10836 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 1060) := by decide +kernel

theorem selectedBound10836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10837 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1060,262,4404,2340,1025,1061,4113,32,1076,3,268,16,3109,4405,5156,3328,1284,32,257,33,4388,513]

theorem envBound10837 : H12AffineFastState.Bounded env10837 := by
  intro p hp
  have h : env10837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10836_10837 : H12AffineEnvironment.transform 14 1060 env10836 = env10837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1060 env10836 == env10837) = true)

theorem identity10837 : scanCanonicalize (H12AffineFastState.compose env10837 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound10837 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10838 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,268,4389,0,262,4404,2340,37,1,4113,32,16,3,268,16,2049,4405,4096,2340,288,32,257,33,4388,513]

theorem envBound10838 : H12AffineFastState.Bounded env10838 := by
  intro p hp
  have h : env10838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10837_10838 : H12AffineEnvironment.transform 9 36 env10837 = env10838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env10837 == env10838) = true)

theorem identity10838 : scanCanonicalize (H12AffineFastState.compose env10838 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound10838 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10839 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,2059,268,2350,0,262,2367,2340,37,1,2074,32,16,3,268,16,2049,2366,2059,2340,288,32,257,33,2351,513]

theorem envBound10839 : H12AffineFastState.Bounded env10839 := by
  intro p hp
  have h : env10839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10838_10839 : H12AffineEnvironment.transform 11 2059 env10838 = env10839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env10838 == env10839) = true)

theorem identity10839 : scanCanonicalize (H12AffineFastState.compose env10839 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10839 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10840 : List Nat := [2,4,8,16,17,17,8,256,512,21,2048,2059,268,2335,0,262,2318,2325,20,1,2074,17,16,3,268,16,2049,2319,2059,2325,273,17,257,16,2334,513]

theorem envBound10840 : H12AffineFastState.Bounded env10840 := by
  intro p hp
  have h : env10840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10839_10840 : H12AffineEnvironment.transform 4 17 env10839 = env10840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10839 == env10840) = true)

theorem identity10840 : scanCanonicalize (H12AffineFastState.compose env10840 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound10840 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10841 : List Nat := [2,4,8,16,17,17,8,31,512,21,2048,2059,19,2048,0,25,2065,2058,20,1,2074,17,16,3,19,16,2049,2064,2059,2058,14,17,30,16,2049,513]

theorem envBound10841 : H12AffineFastState.Bounded env10841 := by
  intro p hp
  have h : env10841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10840_10841 : H12AffineEnvironment.transform 7 31 env10840 = env10841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env10840 == env10841) = true)

theorem identity10841 : scanCanonicalize (H12AffineFastState.compose env10841 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10841 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10842 : List Nat := [2,4,3,16,17,17,3,20,512,21,2048,2048,19,2048,0,18,2065,2049,20,1,2065,17,16,3,19,16,2049,2064,2048,2049,5,17,21,16,2049,513]

theorem envBound10842 : H12AffineFastState.Bounded env10842 := by
  intro p hp
  have h : env10842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10841_10842 : H12AffineEnvironment.transform 2 3 env10841 = env10842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10841 == env10842) = true)

def env10843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77898,73771,62541,21763,8192,65,158029,57676,102742,138341,75103,73770,257,21792,46092,513]

theorem envBound10843 : H12AffineFastState.Bounded env10843 := by
  intro p hp
  have h : env10843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10817_10843 : H12AffineEnvironment.transform 17 10281 env10817 = env10843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10817 == env10843) = true)

theorem identity10843 : scanCanonicalize (H12AffineFastState.compose env10843 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,4161,32,62541,21763,8192,65,158029,57676,45405,138341,1364,33,257,21792,46092,513]

theorem envBound10844 : H12AffineFastState.Bounded env10844 := by
  intro p hp
  have h : env10844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10843_10844 : H12AffineEnvironment.transform 15 8203 env10843 = env10844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10843 == env10844) = true)

theorem identity10844 : scanCanonicalize (H12AffineFastState.compose env10844 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound10844 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env10845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,8203,131072,10281,1025,30073,4161,32,309,21763,8192,65,158029,5172,17445,138341,1364,33,257,21792,16756,513]

theorem envBound10845 : H12AffineFastState.Bounded env10845 := by
  intro p hp
  have h : env10845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10844_10845 : H12AffineEnvironment.transform 14 30072 env10844 = env10845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env10844 == env10845) = true)

theorem identity10845 : scanCanonicalize (H12AffineFastState.compose env10845 (packedSelected [4,6,9,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound10845 : packedSelected [4,6,9,14,18] rootPS < 2^1333 := by decide +kernel

def env10846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,16384,23809,2162,131072,80,1025,23808,4161,32,309,21763,2169,65,147764,5172,17445,138341,1364,33,257,21792,16756,513]

theorem envBound10846 : H12AffineFastState.Bounded env10846 := by
  intro p hp
  have h : env10846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10845_10846 : H12AffineEnvironment.transform 12 2169 env10845 = env10846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env10845 == env10846) = true)

theorem identity10846 : scanCanonicalize (H12AffineFastState.compose env10846 (packedSelected [21] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10846 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10847 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,2169,16384,23589,2162,131072,80,1025,23588,4161,32,17,21543,2169,65,147472,5172,17445,138341,1136,33,37,21508,16464,513]

theorem envBound10847 : H12AffineFastState.Bounded env10847 := by
  intro p hp
  have h : env10847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10846_10847 : H12AffineEnvironment.transform 7 36 env10846 = env10847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10846 == env10847) = true)

theorem identity10847 : scanCanonicalize (H12AffineFastState.compose env10847 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 2064) := by decide +kernel

theorem selectedBound10847 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10848 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,2169,16384,23589,2162,2064,80,1025,23588,4161,32,17,21543,2169,65,18432,5172,17445,5237,1136,33,37,21508,16464,513]

theorem envBound10848 : H12AffineFastState.Bounded env10848 := by
  intro p hp
  have h : env10848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10847_10848 : H12AffineEnvironment.transform 16 2064 env10847 = env10848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2064 env10847 == env10848) = true)

theorem identity10848 : scanCanonicalize (H12AffineFastState.compose env10848 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound10848 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10849 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,2169,16384,18512,2162,2064,80,1025,18513,1076,32,17,16466,2169,65,18432,65,17445,0,1136,33,37,16497,16464,513]

theorem envBound10849 : H12AffineFastState.Bounded env10849 := by
  intro p hp
  have h : env10849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10848_10849 : H12AffineEnvironment.transform 11 1141 env10848 = env10849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env10848 == env10849) = true)

theorem identity10849 : scanCanonicalize (H12AffineFastState.compose env10849 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound10849 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env10850 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,2169,3125,1125,2162,2064,80,1025,1124,1076,32,17,3175,2169,65,1077,65,2064,0,1136,33,37,3140,3173,513]

theorem envBound10850 : H12AffineFastState.Bounded env10850 := by
  intro p hp
  have h : env10850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10849_10850 : H12AffineEnvironment.transform 13 3125 env10849 = env10850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env10849 == env10850) = true)

theorem identity10850 : scanCanonicalize (H12AffineFastState.compose env10850 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound10850 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env10851 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1125,1141,1052,80,1125,1047,1141,80,1025,1124,1076,32,17,2,1052,65,1077,65,1141,0,1136,33,37,33,0,513]

theorem envBound10851 : H12AffineFastState.Bounded env10851 := by
  intro p hp
  have h : env10851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10850_10851 : H12AffineEnvironment.transform 10 1125 env10850 = env10851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env10850 == env10851) = true)

theorem identity10851 : scanCanonicalize (H12AffineFastState.compose env10851 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10851 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env10852 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,1061,1052,0,1077,1047,1061,0,1025,1076,1076,32,17,2,1052,17,1077,17,1061,0,1056,33,37,33,0,513]

theorem envBound10852 : H12AffineFastState.Bounded env10852 := by
  intro p hp
  have h : env10852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10851_10852 : H12AffineEnvironment.transform 5 16 env10851 = env10852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10851 == env10852) = true)

theorem identity10852 : scanCanonicalize (H12AffineFastState.compose env10852 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10852 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10853 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,40,0,1,35,17,0,53,0,0,32,17,2,40,17,1,17,17,0,20,33,37,33,0,513]

theorem envBound10853 : H12AffineFastState.Bounded env10853 := by
  intro p hp
  have h : env10853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10852_10853 : H12AffineEnvironment.transform 9 52 env10852 = env10853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10852 == env10853) = true)

theorem identity10853 : scanCanonicalize (H12AffineFastState.compose env10853 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound10853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10854 : List Nat := [2,4,8,16,32,16,8,36,32,52,1,17,40,0,1,35,17,0,53,0,0,32,17,2,40,17,1,17,17,0,20,33,37,33,0,33]

theorem envBound10854 : H12AffineFastState.Bounded env10854 := by
  intro p hp
  have h : env10854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10853_10854 : H12AffineEnvironment.transform 8 32 env10853 = env10854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env10853 == env10854) = true)

theorem identity10854 : scanCanonicalize (H12AffineFastState.compose env10854 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10854 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10855 : List Nat := [2,4,8,16,17,16,8,21,17,5,1,17,25,0,1,18,17,0,4,0,0,17,17,2,25,17,1,17,17,0,20,16,20,16,0,16]

theorem envBound10855 : H12AffineFastState.Bounded env10855 := by
  intro p hp
  have h : env10855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10854_10855 : H12AffineEnvironment.transform 4 17 env10854 = env10855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10854 == env10855) = true)

def env10856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318564,2444640,8192,65,158028,313701,2394421,138341,2102549,2101345,257,21792,46092,2175563]

theorem envBound10856 : H12AffineFastState.Bounded env10856 := by
  intro p hp
  have h : env10856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10815_10856 : H12AffineEnvironment.transform 21 2373705 env10815 = env10856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env10815 == env10856) = true)

def env10857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318564,351520,8192,65,158028,313701,301429,138341,1365,33,257,21792,46092,74251]

theorem envBound10857 : H12AffineFastState.Bounded env10857 := by
  intro p hp
  have h : env10857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10856_10857 : H12AffineEnvironment.transform 20 4160 env10856 = env10857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10856 == env10857) = true)

theorem identity10857 : scanCanonicalize (H12AffineFastState.compose env10857 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound10857 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,4160,272393,318564,297335,8192,65,158028,313701,301429,138341,1365,33,257,21792,46092,63068]

theorem envBound10858 : H12AffineFastState.Bounded env10858 := by
  intro p hp
  have h : env10858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10857_10858 : H12AffineEnvironment.transform 15 54359 env10857 = env10858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env10857 == env10858) = true)

theorem identity10858 : scanCanonicalize (H12AffineFastState.compose env10858 (packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound10858 : packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env10859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,262144,1025,29788,4160,272393,272441,294186,8192,65,158028,277816,290088,138341,1365,33,257,21792,16465,513]

theorem envBound10859 : H12AffineFastState.Bounded env10859 := by
  intro p hp
  have h : env10859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10858_10859 : H12AffineEnvironment.transform 14 29789 env10858 = env10859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10858 == env10859) = true)

theorem identity10859 : scanCanonicalize (H12AffineFastState.compose env10859 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10859 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,10280,1025,29788,4160,33,17,21762,8192,65,158028,5392,17664,138341,1365,33,257,21792,16465,513]

theorem envBound10860 : H12AffineFastState.Bounded env10860 := by
  intro p hp
  have h : env10860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10859_10860 : H12AffineEnvironment.transform 17 10280 env10859 = env10860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10859 == env10860) = true)

theorem identity10860 : scanCanonicalize (H12AffineFastState.compose env10860 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound10860 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,8202,131072,10280,1025,80,4160,33,17,8462,8192,65,138560,5392,12556,138341,1365,33,257,8492,13405,513]

theorem envBound10861 : H12AffineFastState.Bounded env10861 := by
  intro p hp
  have h : env10861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10860_10861 : H12AffineEnvironment.transform 13 13324 env10860 = env10861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env10860 == env10861) = true)

def env10862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318564,351521,8192,65,158028,313701,301428,138341,1364,32,257,21792,46092,74250]

theorem envBound10862 : H12AffineFastState.Bounded env10862 := by
  intro p hp
  have h : env10862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10856_10862 : H12AffineEnvironment.transform 20 4161 env10856 = env10862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10856 == env10862) = true)

theorem identity10862 : scanCanonicalize (H12AffineFastState.compose env10862 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound10862 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130174,1025,32769,4161,119926,73754,41311,8192,65,158028,79131,91402,138341,1364,32,257,21792,46092,74250]

theorem envBound10863 : H12AffineFastState.Bounded env10863 := by
  intro p hp
  have h : env10863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10862_10863 : H12AffineEnvironment.transform 17 130174 env10862 = env10863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env10862 == env10863) = true)

def env10864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67618,1025,29789,4161,73770,73754,21763,8192,65,158028,79131,91402,138341,1364,32,257,21792,16464,74250]

theorem envBound10864 : H12AffineFastState.Bounded env10864 := by
  intro p hp
  have h : env10864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10863_10864 : H12AffineEnvironment.transform 14 29788 env10863 = env10864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env10863 == env10864) = true)

theorem identity10864 : scanCanonicalize (H12AffineFastState.compose env10864 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10864 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4161,33,17,21763,8192,65,158028,5392,17665,138341,1364,32,257,21792,16464,513]

theorem envBound10865 : H12AffineFastState.Bounded env10865 := by
  intro p hp
  have h : env10865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10864_10865 : H12AffineEnvironment.transform 15 8203 env10864 = env10865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10864 == env10865) = true)

theorem identity10865 : scanCanonicalize (H12AffineFastState.compose env10865 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10865 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8461,5457,8203,131072,10281,1025,5456,4161,33,17,13326,8192,65,133185,5392,9228,138341,1364,32,257,13357,8541,513]

theorem envBound10866 : H12AffineFastState.Bounded env10866 := by
  intro p hp
  have h : env10866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10865_10866 : H12AffineEnvironment.transform 13 8461 env10865 = env10866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8461 env10865 == env10866) = true)

theorem identity10866 : scanCanonicalize (H12AffineFastState.compose env10866 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 5213) := by decide +kernel

theorem selectedBound10866 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5213,5456,5457,5206,131072,7284,1025,5456,4161,33,17,83,5213,65,133185,5392,4177,138341,1364,32,257,112,5376,513]

theorem envBound10867 : H12AffineFastState.Bounded env10867 := by
  intro p hp
  have h : env10867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10866_10867 : H12AffineEnvironment.transform 12 5213 env10866 = env10867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5213 env10866 == env10867) = true)

theorem identity10867 : scanCanonicalize (H12AffineFastState.compose env10867 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound10867 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env10868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,3149,3392,3393,3142,131072,1124,1025,3392,2129,33,17,83,3149,65,133185,3328,2113,132213,1364,32,257,112,3344,513]

theorem envBound10868 : H12AffineFastState.Bounded env10868 := by
  intro p hp
  have h : env10868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10867_10868 : H12AffineEnvironment.transform 11 2064 env10867 = env10868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env10867 == env10868) = true)

theorem identity10868 : scanCanonicalize (H12AffineFastState.compose env10868 (packedSelected [4,9,18] rootPS)) = affineNative (2^(16+1) ^^^ 1061) := by decide +kernel

theorem selectedBound10868 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env10869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,3149,3392,3393,3142,1061,1124,1025,3392,2129,33,17,83,3149,65,3172,3328,2113,80,1364,32,257,112,3344,513]

theorem envBound10869 : H12AffineFastState.Bounded env10869 := by
  intro p hp
  have h : env10869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10868_10869 : H12AffineEnvironment.transform 16 1061 env10868 = env10869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1061 env10868 == env10869) = true)

def env10870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67619,1025,29788,4161,73771,73754,21762,8192,65,158028,79131,91402,138341,1364,32,257,21792,16465,74250]

theorem envBound10870 : H12AffineFastState.Bounded env10870 := by
  intro p hp
  have h : env10870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10863_10870 : H12AffineEnvironment.transform 14 29789 env10863 = env10870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10863 == env10870) = true)

theorem identity10870 : scanCanonicalize (H12AffineFastState.compose env10870 (packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound10870 : packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env10871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13340,67619,1025,29788,4161,73771,73754,21762,8192,65,23888,79131,91402,10361,1364,32,257,21792,16465,74250]

theorem envBound10871 : H12AffineFastState.Bounded env10871 := by
  intro p hp
  have h : env10871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10870_10871 : H12AffineEnvironment.transform 16 13340 env10870 = env10871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env10870 == env10871) = true)

theorem identity10871 : scanCanonicalize (H12AffineFastState.compose env10871 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10871 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env10872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,13340,10280,1025,29788,4161,32,17,21762,8192,65,23888,5392,17665,10361,1364,32,257,21792,16465,513]

theorem envBound10872 : H12AffineFastState.Bounded env10872 := by
  intro p hp
  have h : env10872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10871_10872 : H12AffineEnvironment.transform 15 8203 env10871 = env10872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10871 == env10872) = true)

theorem identity10872 : scanCanonicalize (H12AffineFastState.compose env10872 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10872 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10873 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,8203,13340,10280,1025,29709,4112,32,17,21762,8192,16,23809,5392,17665,10280,1285,32,257,21792,16384,513]

theorem envBound10873 : H12AffineFastState.Bounded env10873 := by
  intro p hp
  have h : env10873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10872_10873 : H12AffineEnvironment.transform 5 17 env10872 = env10873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10872 == env10873) = true)

theorem identity10873 : scanCanonicalize (H12AffineFastState.compose env10873 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10873 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10874 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,13340,10280,1025,8460,4112,32,17,3,8192,16,2048,5392,4096,10280,1285,32,257,33,5377,513]

theorem envBound10874 : H12AffineFastState.Bounded env10874 := by
  intro p hp
  have h : env10874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10873_10874 : H12AffineEnvironment.transform 13 5377 env10873 = env10874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10873 == env10874) = true)

theorem identity10874 : scanCanonicalize (H12AffineFastState.compose env10874 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound10874 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10875 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,5377,33,295,5424,2308,1025,32,4112,32,17,3,300,16,2048,5392,4096,2308,1285,32,257,33,5377,513]

theorem envBound10875 : H12AffineFastState.Bounded env10875 := by
  intro p hp
  have h : env10875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10874_10875 : H12AffineEnvironment.transform 12 300 env10874 = env10875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env10874 == env10875) = true)

theorem identity10875 : scanCanonicalize (H12AffineFastState.compose env10875 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound10875 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10876 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,300,4145,33,295,4096,2308,305,32,4112,32,17,3,300,16,2048,4128,4096,2308,53,32,257,33,4145,513]

theorem envBound10876 : H12AffineFastState.Bounded env10876 := by
  intro p hp
  have h : env10876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10875_10876 : H12AffineEnvironment.transform 9 304 env10875 = env10876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env10875 == env10876) = true)

theorem identity10876 : scanCanonicalize (H12AffineFastState.compose env10876 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10876 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env10877 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,268,4113,1,263,4096,2308,273,0,4112,0,17,3,268,16,2048,4096,4096,2308,21,0,257,1,4113,513]

theorem envBound10877 : H12AffineFastState.Bounded env10877 := by
  intro p hp
  have h : env10877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10876_10877 : H12AffineEnvironment.transform 4 0 env10876 = env10877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10876 == env10877) = true)

theorem identity10877 : scanCanonicalize (H12AffineFastState.compose env10877 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10878 : List Nat := [2,4,8,16,0,17,8,4,512,20,2048,4096,8,4113,1,3,4096,2048,21,0,4112,0,17,3,8,16,2048,4096,4096,2048,21,0,5,1,4113,513]

theorem envBound10878 : H12AffineFastState.Bounded env10878 := by
  intro p hp
  have h : env10878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10877_10878 : H12AffineEnvironment.transform 7 4 env10877 = env10878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10877 == env10878) = true)

theorem identity10878 : scanCanonicalize (H12AffineFastState.compose env10878 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10879 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,4096,8,4113,1,3,4096,0,21,0,4112,0,17,3,8,16,0,4096,4096,0,21,0,5,1,4113,513]

theorem envBound10879 : H12AffineFastState.Bounded env10879 := by
  intro p hp
  have h : env10879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10878_10879 : H12AffineEnvironment.transform 10 0 env10878 = env10879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10878 == env10879) = true)

def env10880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444641,8193,65,6705412,313701,2394421,138341,2102548,4466728,257,21792,46093,2175563]

theorem envBound10880 : H12AffineFastState.Bounded env10880 := by
  intro p hp
  have h : env10880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10814_10880 : H12AffineEnvironment.transform 6 9 env10814 = env10880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10814 == env10880) = true)

theorem identity10880 : scanCanonicalize (H12AffineFastState.compose env10880 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound10880 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env10881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,4194304,318564,294187,8193,65,4677966,313701,375167,138341,75102,4466728,257,21792,46093,513]

theorem envBound10881 : H12AffineFastState.Bounded env10881 := by
  intro p hp
  have h : env10881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10880_10881 : H12AffineEnvironment.transform 20 77898 env10880 = env10881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env10880 == env10881) = true)

theorem identity10881 : scanCanonicalize (H12AffineFastState.compose env10881 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10881 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77898,4194304,318564,294187,8193,65,4456788,313701,375167,97407,75102,4466728,257,21792,46093,513]

theorem envBound10882 : H12AffineFastState.Bounded env10882 := by
  intro p hp
  have h : env10882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10881_10882 : H12AffineEnvironment.transform 16 90138 env10881 = env10882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10881 == env10882) = true)

def env10883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77898,4194304,62540,21763,8193,65,4204924,57677,102743,97407,75102,4194304,257,21792,46093,513]

theorem envBound10883 : H12AffineFastState.Bounded env10883 := by
  intro p hp
  have h : env10883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10882_10883 : H12AffineEnvironment.transform 17 10280 env10882 = env10883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10882 == env10883) = true)

theorem identity10883 : scanCanonicalize (H12AffineFastState.compose env10883 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound10883 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env10884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46156,10280,1025,32769,58396,4194304,62540,21763,8193,65,4204924,57677,17665,43049,61704,4194304,257,21792,46093,513]

theorem envBound10884 : H12AffineFastState.Bounded env10884 := by
  intro p hp
  have h : env10884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10883_10884 : H12AffineEnvironment.transform 15 54358 env10883 = env10884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env10883 == env10884) = true)

theorem identity10884 : scanCanonicalize (H12AffineFastState.compose env10884 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10884 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env10885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,46156,10280,1025,32769,45340,4194304,41292,3,8193,65,4204924,46157,4097,43049,41992,4194304,257,32,46093,513]

theorem envBound10885 : H12AffineFastState.Bounded env10885 := by
  intro p hp
  have h : env10885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10884_10885 : H12AffineEnvironment.transform 13 5376 env10884 = env10885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10884 == env10885) = true)

theorem identity10885 : scanCanonicalize (H12AffineFastState.compose env10885 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10885 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10886 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33030,46108,10280,1025,32769,45340,4194304,41244,3,8193,17,4204844,46109,4097,43049,41992,4194304,257,32,46093,513]

theorem envBound10886 : H12AffineFastState.Bounded env10886 := by
  intro p hp
  have h : env10886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10885_10886 : H12AffineEnvironment.transform 5 16 env10885 = env10886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10885 == env10886) = true)

theorem identity10886 : scanCanonicalize (H12AffineFastState.compose env10886 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 7172) := by decide +kernel

theorem selectedBound10886 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env10887 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33030,46108,10280,1025,32769,45340,7172,41244,3,8193,17,13608,46109,4097,43049,41992,7172,257,32,46093,513]

theorem envBound10887 : H12AffineFastState.Bounded env10887 := by
  intro p hp
  have h : env10887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10886_10887 : H12AffineEnvironment.transform 21 7172 env10886 = env10887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7172 env10886 == env10887) = true)

theorem identity10887 : scanCanonicalize (H12AffineFastState.compose env10887 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound10887 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env10888 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5416,5376,32768,33030,33076,7424,1025,32769,33844,7172,37940,3,5417,17,0,33077,4097,40193,37152,7172,257,32,33061,513]

theorem envBound10888 : H12AffineFastState.Bounded env10888 := by
  intro p hp
  have h : env10888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10887_10888 : H12AffineEnvironment.transform 12 5416 env10887 = env10888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env10887 == env10888) = true)

theorem identity10888 : scanCanonicalize (H12AffineFastState.compose env10888 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10888 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10889 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5416,5376,0,262,308,7424,1025,1,1076,7172,5172,3,5417,17,0,309,4097,7425,4384,7172,257,32,293,513]

theorem envBound10889 : H12AffineFastState.Bounded env10889 := by
  intro p hp
  have h : env10889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10888_10889 : H12AffineEnvironment.transform 14 0 env10888 = env10889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10888 == env10889) = true)

theorem identity10889 : scanCanonicalize (H12AffineFastState.compose env10889 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound10889 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10890 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,4096,5416,5376,0,262,308,5156,1025,1,1076,5408,5172,3,5417,17,0,309,4097,5157,4384,5408,257,32,293,513]

theorem envBound10890 : H12AffineFastState.Bounded env10890 := by
  intro p hp
  have h : env10890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10889_10890 : H12AffineEnvironment.transform 10 292 env10889 = env10890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env10889 == env10890) = true)

theorem identity10890 : scanCanonicalize (H12AffineFastState.compose env10890 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10890 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env10891 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,4096,4153,4113,0,262,308,4405,272,1,293,4145,4389,3,4152,17,0,309,4097,4404,4384,4145,257,32,293,513]

theorem envBound10891 : H12AffineFastState.Bounded env10891 := by
  intro p hp
  have h : env10891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10890_10891 : H12AffineEnvironment.transform 9 273 env10890 = env10891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10890 == env10891) = true)

theorem identity10891 : scanCanonicalize (H12AffineFastState.compose env10891 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound10891 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env10892 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,17,40,0,0,262,308,292,272,1,293,32,308,3,41,17,0,309,16,293,305,32,257,32,293,513]

theorem envBound10892 : H12AffineFastState.Bounded env10892 := by
  intro p hp
  have h : env10892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10891_10892 : H12AffineEnvironment.transform 11 17 env10891 = env10892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env10891 == env10892) = true)

theorem identity10892 : scanCanonicalize (H12AffineFastState.compose env10892 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound10892 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env10893 : List Nat := [2,4,8,16,32,16,9,256,260,273,292,17,40,0,0,262,308,292,272,1,293,32,308,3,41,17,0,309,16,293,305,32,257,32,293,261]

theorem envBound10893 : H12AffineFastState.Bounded env10893 := by
  intro p hp
  have h : env10893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10892_10893 : H12AffineEnvironment.transform 8 260 env10892 = env10893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env10892 == env10893) = true)

theorem identity10893 : scanCanonicalize (H12AffineFastState.compose env10893 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10893 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10894 : List Nat := [2,4,8,16,32,16,9,37,33,52,1,17,40,0,0,35,17,1,53,1,0,32,17,3,41,17,0,16,16,0,20,32,36,32,0,32]

theorem envBound10894 : H12AffineFastState.Bounded env10894 := by
  intro p hp
  have h : env10894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10893_10894 : H12AffineEnvironment.transform 7 37 env10893 = env10894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10893 == env10894) = true)

theorem identity10894 : scanCanonicalize (H12AffineFastState.compose env10894 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10895 : List Nat := [2,4,8,16,17,16,9,20,16,5,1,17,25,0,0,18,17,1,4,1,0,17,17,3,24,17,0,16,16,0,20,17,21,17,0,17]

theorem envBound10895 : H12AffineFastState.Bounded env10895 := by
  intro p hp
  have h : env10895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10894_10895 : H12AffineEnvironment.transform 4 17 env10894 = env10895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10894 == env10895) = true)

def env10896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,77898,4194304,62541,21762,8193,65,4204925,57676,102742,97407,75102,4194305,257,21792,46093,513]

theorem envBound10896 : H12AffineFastState.Bounded env10896 := by
  intro p hp
  have h : env10896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10882_10896 : H12AffineEnvironment.transform 17 10281 env10882 = env10896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10882 == env10896) = true)

theorem identity10896 : scanCanonicalize (H12AffineFastState.compose env10896 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 53575) := by decide +kernel

theorem selectedBound10896 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env10897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53575,45405,10281,1025,32769,57613,4194304,62541,21762,8193,65,4204925,57676,16401,44344,62489,4194305,257,21792,46093,513]

theorem envBound10897 : H12AffineFastState.Bounded env10897 := by
  intro p hp
  have h : env10897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10896_10897 : H12AffineEnvironment.transform 15 53575 env10896 = env10897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53575 env10896 == env10897) = true)

theorem identity10897 : scanCanonicalize (H12AffineFastState.compose env10897 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound10897 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env10898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10281,1025,8540,16464,4194304,21776,21762,8193,65,4204925,16401,16401,3173,21828,4194305,257,21792,5456,513]

theorem envBound10898 : H12AffineFastState.Bounded env10898 := by
  intro p hp
  have h : env10898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10897_10898 : H12AffineEnvironment.transform 14 8541 env10897 = env10898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env10897 == env10898) = true)

theorem identity10898 : scanCanonicalize (H12AffineFastState.compose env10898 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10898 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env10899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,20759,4096,2340,1025,81,16464,4194304,21776,21762,268,65,4196464,16401,16401,3173,21828,4194305,257,21792,5456,513]

theorem envBound10899 : H12AffineFastState.Bounded env10899 := by
  intro p hp
  have h : env10899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10898_10899 : H12AffineEnvironment.transform 12 269 env10898 = env10899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10898 == env10899) = true)

theorem identity10899 : scanCanonicalize (H12AffineFastState.compose env10899 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(21+1) ^^^ 20805) := by decide +kernel

theorem selectedBound10899 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env10900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,20759,4096,2340,1025,81,16464,20805,21776,21762,268,65,22837,16401,16401,3173,21828,20804,257,21792,5456,513]

theorem envBound10900 : H12AffineFastState.Bounded env10900 := by
  intro p hp
  have h : env10900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10899_10900 : H12AffineEnvironment.transform 21 20805 env10899 = env10900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20805 env10899 == env10900) = true)

theorem identity10900 : scanCanonicalize (H12AffineFastState.compose env10900 (packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound10900 : packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env10901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,2048,80,6423,4096,2340,1025,81,2128,6469,7440,7426,268,65,4405,2065,2065,3173,7492,6468,257,7456,5456,513]

theorem envBound10901 : H12AffineFastState.Bounded env10901 := by
  intro p hp
  have h : env10901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10900_10901 : H12AffineEnvironment.transform 13 2048 env10900 = env10901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env10900 == env10901) = true)

theorem identity10901 : scanCanonicalize (H12AffineFastState.compose env10901 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound10901 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env10902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,269,2048,80,1378,3189,2340,1025,81,2128,1328,357,375,268,65,3392,2065,2065,3173,305,1329,257,341,2341,513]

theorem envBound10902 : H12AffineFastState.Bounded env10902 := by
  intro p hp
  have h : env10902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10901_10902 : H12AffineEnvironment.transform 11 3189 env10901 = env10902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env10901 == env10902) = true)

theorem identity10902 : scanCanonicalize (H12AffineFastState.compose env10902 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10902 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env10903 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3189,120,2048,80,1047,3189,2129,1025,81,2128,1093,16,2,121,65,3125,2065,2065,3173,68,1092,116,32,2128,513]

theorem envBound10903 : H12AffineFastState.Bounded env10903 := by
  intro p hp
  have h : env10903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10902_10903 : H12AffineEnvironment.transform 7 117 env10902 = env10903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10902 == env10903) = true)

theorem identity10903 : scanCanonicalize (H12AffineFastState.compose env10903 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound10903 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env10904 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,1061,120,80,80,1047,1061,1,1025,81,0,1093,16,2,121,65,1125,65,65,1077,68,1092,116,32,0,513]

theorem envBound10904 : H12AffineFastState.Bounded env10904 := by
  intro p hp
  have h : env10904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10903_10904 : H12AffineEnvironment.transform 10 80 env10903 = env10904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env10903 == env10904) = true)

theorem identity10904 : scanCanonicalize (H12AffineFastState.compose env10904 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10904 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env10905 : List Nat := [2,4,8,11,32,64,9,110,512,1024,75,1061,99,75,75,1036,1061,1,1025,74,0,1093,11,2,98,65,1125,65,65,1070,68,1092,111,32,0,513]

theorem envBound10905 : H12AffineFastState.Bounded env10905 := by
  intro p hp
  have h : env10905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10904_10905 : H12AffineEnvironment.transform 3 11 env10904 = env10905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10904 == env10905) = true)

theorem identity10905 : scanCanonicalize (H12AffineFastState.compose env10905 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound10905 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env10906 : List Nat := [2,4,8,11,32,11,9,37,512,1024,0,1061,40,0,0,1036,1061,1,1025,1,0,1038,11,2,41,10,1070,10,10,1070,15,1039,36,32,0,513]

theorem envBound10906 : H12AffineFastState.Bounded env10906 := by
  intro p hp
  have h : env10906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10905_10906 : H12AffineEnvironment.transform 5 11 env10905 = env10906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env10905 == env10906) = true)

theorem identity10906 : scanCanonicalize (H12AffineFastState.compose env10906 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound10906 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10907 : List Nat := [2,4,8,11,32,11,9,37,512,47,0,10,40,0,0,35,10,1,46,1,0,33,11,2,41,10,1,10,10,1,15,32,36,32,0,513]

theorem envBound10907 : H12AffineFastState.Bounded env10907 := by
  intro p hp
  have h : env10907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10906_10907 : H12AffineEnvironment.transform 9 47 env10906 = env10907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env10906 == env10907) = true)

theorem identity10907 : scanCanonicalize (H12AffineFastState.compose env10907 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound10907 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10908 : List Nat := [2,4,8,11,32,11,9,37,11,47,0,10,40,0,0,35,10,1,46,1,0,33,11,2,41,10,1,10,10,1,15,32,36,32,0,10]

theorem envBound10908 : H12AffineFastState.Bounded env10908 := by
  intro p hp
  have h : env10908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10907_10908 : H12AffineEnvironment.transform 8 11 env10907 = env10908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env10907 == env10908) = true)

theorem identity10908 : scanCanonicalize (H12AffineFastState.compose env10908 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10908 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10909 : List Nat := [2,4,3,0,32,0,2,37,0,36,0,1,35,0,0,35,1,1,37,1,0,33,0,2,34,1,1,1,1,1,4,32,36,32,0,1]

theorem envBound10909 : H12AffineFastState.Bounded env10909 := by
  intro p hp
  have h : env10909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10908_10909 : H12AffineEnvironment.transform 2 3 env10908 = env10909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10908 == env10909) = true)

def env10910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444776,8328,65,6705548,313701,2394420,138340,2102684,4466728,257,21793,46213,2175562]

theorem envBound10910 : H12AffineFastState.Bounded env10910 := by
  intro p hp
  have h : env10910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10813_10910 : H12AffineEnvironment.transform 22 318565 env10813 = env10910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318565 env10813 == env10910) = true)

def env10911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444640,8192,65,6705412,313701,2394420,138340,2102548,4466728,257,21793,46093,2175562]

theorem envBound10911 : H12AffineFastState.Bounded env10911 := by
  intro p hp
  have h : env10911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10910_10911 : H12AffineEnvironment.transform 6 8 env10910 = env10911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10910 == env10911) = true)

theorem identity10911 : scanCanonicalize (H12AffineFastState.compose env10911 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound10911 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env10912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,4194304,318565,294187,8192,65,4677967,313701,375167,138340,75103,4466728,257,21793,46093,513]

theorem envBound10912 : H12AffineFastState.Bounded env10912 := by
  intro p hp
  have h : env10912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10911_10912 : H12AffineEnvironment.transform 20 77899 env10911 = env10912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env10911 == env10912) = true)

def env10913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77899,4194304,62541,21763,8192,65,4409703,57677,102743,138340,75103,4194304,257,21793,46093,513]

theorem envBound10913 : H12AffineFastState.Bounded env10913 := by
  intro p hp
  have h : env10913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10912_10913 : H12AffineEnvironment.transform 17 10280 env10912 = env10913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10912 == env10913) = true)

def env10914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,4194304,17,21763,8192,65,4409703,5393,91403,138340,75103,4194304,257,21793,16465,513]

theorem envBound10914 : H12AffineFastState.Bounded env10914 := by
  intro p hp
  have h : env10914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10913_10914 : H12AffineEnvironment.transform 14 29788 env10913 = env10914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env10913 == env10914) = true)

def env10915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,21792,17,21763,8192,65,203847,5393,91403,138340,75103,21792,257,21793,16465,513]

theorem envBound10915 : H12AffineFastState.Bounded env10915 := by
  intro p hp
  have h : env10915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10914_10915 : H12AffineEnvironment.transform 21 21792 env10914 = env10915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env10914 == env10915) = true)

theorem identity10915 : scanCanonicalize (H12AffineFastState.compose env10915 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound10915 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env10916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,65536,131072,10280,1025,81,77899,8492,17,8463,8192,65,203847,5393,69895,138340,75103,8492,257,8493,13405,513]

theorem envBound10916 : H12AffineFastState.Bounded env10916 := by
  intro p hp
  have h : env10916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10915_10916 : H12AffineEnvironment.transform 13 13324 env10915 = env10916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env10915 == env10916) = true)

theorem identity10916 : scanCanonicalize (H12AffineFastState.compose env10916 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10916 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10917 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,1,65536,131072,10280,1025,0,77850,8492,17,8463,8192,16,203798,5393,69895,138293,75022,8492,257,8493,13324,513]

theorem envBound10917 : H12AffineFastState.Bounded env10917 := by
  intro p hp
  have h : env10917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10916_10917 : H12AffineEnvironment.transform 5 17 env10916 = env10917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10916 == env10917) = true)

theorem identity10917 : scanCanonicalize (H12AffineFastState.compose env10917 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10917 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10918 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,65536,131072,2340,1025,0,69910,32,17,3,268,16,203798,5393,69895,138293,66562,32,257,33,5376,513]

theorem envBound10918 : H12AffineFastState.Bounded env10918 := by
  intro p hp
  have h : env10918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10917_10918 : H12AffineEnvironment.transform 12 268 env10917 = env10918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10917 == env10918) = true)

theorem identity10918 : scanCanonicalize (H12AffineFastState.compose env10918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound10918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10919 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,65536,70678,2340,1025,0,69910,32,17,3,268,16,2048,5393,69895,67619,66562,32,257,33,5376,513]

theorem envBound10919 : H12AffineFastState.Bounded env10919 := by
  intro p hp
  have h : env10919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10918_10919 : H12AffineEnvironment.transform 16 70678 env10918 = env10919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env10918 == env10919) = true)

theorem identity10919 : scanCanonicalize (H12AffineFastState.compose env10919 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound10919 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10920 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,5426,292,2340,1025,0,1060,32,17,3,268,16,2048,5393,1077,7441,4400,32,257,33,5376,513]

theorem envBound10920 : H12AffineFastState.Bounded env10920 := by
  intro p hp
  have h : env10920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10919_10920 : H12AffineEnvironment.transform 15 5426 env10919 = env10920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env10919 == env10920) = true)

theorem identity10920 : scanCanonicalize (H12AffineFastState.compose env10920 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound10920 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env10921 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,512,268,1792,1,1842,292,2340,1025,0,1060,32,17,3,268,16,2048,1809,1077,3857,816,32,257,33,1792,513]

theorem envBound10921 : H12AffineFastState.Bounded env10921 := by
  intro p hp
  have h : env10921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10920_10921 : H12AffineEnvironment.transform 11 512 env10920 = env10921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env10920 == env10921) = true)

theorem identity10921 : scanCanonicalize (H12AffineFastState.compose env10921 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10921 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env10922 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,512,268,529,1,547,292,2340,272,0,309,32,17,3,268,16,2048,512,292,2560,816,32,257,33,529,513]

theorem envBound10922 : H12AffineFastState.Bounded env10922 := by
  intro p hp
  have h : env10922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10921_10922 : H12AffineEnvironment.transform 9 273 env10921 = env10922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10921 == env10922) = true)

theorem identity10922 : scanCanonicalize (H12AffineFastState.compose env10922 (packedSelected [0,1,4,5,14] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound10922 : packedSelected [0,1,4,5,14] rootPS < 2^1333 := by decide +kernel

def env10923 : List Nat := [2,4,8,16,32,17,8,256,293,273,2048,293,268,308,1,262,292,2340,272,0,309,32,17,3,268,16,2048,293,292,2341,21,32,257,33,308,292]

theorem envBound10923 : H12AffineFastState.Bounded env10923 := by
  intro p hp
  have h : env10923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10922_10923 : H12AffineEnvironment.transform 8 293 env10922 = env10923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env10922 == env10923) = true)

theorem identity10923 : scanCanonicalize (H12AffineFastState.compose env10923 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound10923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10924 : List Nat := [2,4,8,16,32,17,8,53,16,36,2048,16,57,1,1,51,17,2065,37,0,0,32,17,3,57,16,2048,16,17,2064,21,32,52,33,1,17]

theorem envBound10924 : H12AffineFastState.Bounded env10924 := by
  intro p hp
  have h : env10924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10923_10924 : H12AffineEnvironment.transform 7 53 env10923 = env10924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env10923 == env10924) = true)

theorem identity10924 : scanCanonicalize (H12AffineFastState.compose env10924 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound10924 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10925 : List Nat := [2,4,8,16,27,17,8,14,16,31,2048,16,2,1,1,8,17,2065,30,0,0,27,17,3,2,16,2048,16,17,2064,21,27,15,26,1,17]

theorem envBound10925 : H12AffineFastState.Bounded env10925 := by
  intro p hp
  have h : env10925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10924_10925 : H12AffineEnvironment.transform 4 27 env10924 = env10925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env10924 == env10925) = true)

def env10926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,21793,17,21763,8192,65,203846,5393,91403,138340,75103,21793,257,21793,16465,513]

theorem envBound10926 : H12AffineFastState.Bounded env10926 := by
  intro p hp
  have h : env10926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10914_10926 : H12AffineEnvironment.transform 21 21793 env10914 = env10926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env10914 == env10926) = true)

theorem identity10926 : scanCanonicalize (H12AffineFastState.compose env10926 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10926 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env10927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,131072,10280,1025,1,77899,8573,17,8543,8192,65,203846,5393,69975,138340,75103,8573,257,8573,13325,513]

theorem envBound10927 : H12AffineFastState.Bounded env10927 := by
  intro p hp
  have h : env10927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10926_10927 : H12AffineEnvironment.transform 13 13404 env10926 = env10927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10926 == env10927) = true)

theorem identity10927 : scanCanonicalize (H12AffineFastState.compose env10927 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10927 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env10928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,65536,131072,2340,1025,1,69959,113,17,83,268,65,203846,5393,69975,138340,66643,113,257,113,5377,513]

theorem envBound10928 : H12AffineFastState.Bounded env10928 := by
  intro p hp
  have h : env10928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10927_10928 : H12AffineEnvironment.transform 12 268 env10927 = env10928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10927 == env10928) = true)

theorem identity10928 : scanCanonicalize (H12AffineFastState.compose env10928 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound10928 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,65536,5392,2340,1025,1,69959,113,17,83,268,65,67926,5393,69975,2420,66643,113,257,113,5377,513]

theorem envBound10929 : H12AffineFastState.Bounded env10929 := by
  intro p hp
  have h : env10929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10928_10929 : H12AffineEnvironment.transform 16 5392 env10928 = env10929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env10928 == env10929) = true)

theorem identity10929 : scanCanonicalize (H12AffineFastState.compose env10929 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound10929 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,343,5392,2340,1025,1,4112,113,17,83,268,65,2049,5393,4096,2420,1284,113,257,113,5377,513]

theorem envBound10930 : H12AffineFastState.Bounded env10930 := by
  intro p hp
  have h : env10930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10929_10930 : H12AffineEnvironment.transform 15 343 env10929 = env10930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env10929 == env10930) = true)

theorem identity10930 : scanCanonicalize (H12AffineFastState.compose env10930 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound10930 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env10931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,268,3345,0,343,3409,2340,1025,1,2129,113,17,83,268,65,2049,3408,2113,2420,1284,113,257,113,3392,513]

theorem envBound10931 : H12AffineFastState.Bounded env10931 := by
  intro p hp
  have h : env10931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10930_10931 : H12AffineEnvironment.transform 11 2113 env10930 = env10931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env10930 == env10931) = true)

theorem identity10931 : scanCanonicalize (H12AffineFastState.compose env10931 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound10931 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env10932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1280,268,80,0,343,16,1125,1025,1,1296,113,17,83,268,65,1344,17,1280,1077,1284,113,257,113,1,513]

theorem envBound10932 : H12AffineFastState.Bounded env10932 := by
  intro p hp
  have h : env10932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10931_10932 : H12AffineEnvironment.transform 10 1345 env10931 = env10932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env10931 == env10932) = true)

theorem identity10932 : scanCanonicalize (H12AffineFastState.compose env10932 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10932 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env10933 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1076,1141,121,80,0,34,16,1125,1025,1,1125,113,17,83,121,65,1077,17,1141,1077,1137,113,116,113,1,513]

theorem envBound10933 : H12AffineFastState.Bounded env10933 := by
  intro p hp
  have h : env10933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10932_10933 : H12AffineEnvironment.transform 7 117 env10932 = env10933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10932 == env10933) = true)

theorem identity10933 : scanCanonicalize (H12AffineFastState.compose env10933 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10933 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env10934 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1076,1061,41,0,0,34,16,1077,1025,1,1077,33,17,3,41,17,1077,17,1061,1077,1057,33,36,33,1,513]

theorem envBound10934 : H12AffineFastState.Bounded env10934 := by
  intro p hp
  have h : env10934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10933_10934 : H12AffineEnvironment.transform 5 16 env10933 = env10934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10933 == env10934) = true)

theorem identity10934 : scanCanonicalize (H12AffineFastState.compose env10934 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10935 : List Nat := [2,4,8,0,32,0,8,37,512,1024,1060,1061,41,0,0,34,0,1061,1025,1,1061,33,1,3,41,1,1061,1,1061,1061,1057,33,36,33,1,513]

theorem envBound10935 : H12AffineFastState.Bounded env10935 := by
  intro p hp
  have h : env10935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10934_10935 : H12AffineEnvironment.transform 3 0 env10934 = env10935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10934 == env10935) = true)

theorem identity10935 : scanCanonicalize (H12AffineFastState.compose env10935 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10935 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10936 : List Nat := [2,4,3,0,32,0,3,37,512,1024,1060,1061,34,0,0,34,0,1061,1025,1,1061,33,1,3,34,1,1061,1,1061,1061,1057,33,36,33,1,513]

theorem envBound10936 : H12AffineFastState.Bounded env10936 := by
  intro p hp
  have h : env10936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10935_10936 : H12AffineEnvironment.transform 2 3 env10935 = env10936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10935 == env10936) = true)

theorem identity10936 : scanCanonicalize (H12AffineFastState.compose env10936 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10936 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10937 : List Nat := [2,4,3,0,1,0,3,4,512,1024,1029,1028,3,0,0,3,0,1028,1025,1,1028,0,1,3,3,1,1028,1,1028,1028,1024,0,5,0,1,513]

theorem envBound10937 : H12AffineFastState.Bounded env10937 := by
  intro p hp
  have h : env10937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10936_10937 : H12AffineEnvironment.transform 4 1 env10936 = env10937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10936 == env10937) = true)

theorem identity10937 : scanCanonicalize (H12AffineFastState.compose env10937 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound10937 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10938 : List Nat := [2,4,3,0,1,0,3,4,512,0,5,4,3,0,0,3,0,4,1,1,4,0,1,3,3,1,4,1,4,4,0,0,5,0,1,513]

theorem envBound10938 : H12AffineFastState.Bounded env10938 := by
  intro p hp
  have h : env10938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10937_10938 : H12AffineEnvironment.transform 9 0 env10937 = env10938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env10937 == env10938) = true)

def env10939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,4194304,16,21763,8192,65,4409703,5392,91402,138340,75103,4194304,257,21793,16464,513]

theorem envBound10939 : H12AffineFastState.Bounded env10939 := by
  intro p hp
  have h : env10939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10913_10939 : H12AffineEnvironment.transform 14 29789 env10913 = env10939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10913 == env10939) = true)

theorem identity10939 : scanCanonicalize (H12AffineFastState.compose env10939 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10939 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10280,1025,29788,77899,4194304,16,21763,8192,65,4204925,5392,91402,97406,75103,4194304,257,21793,16464,513]

theorem envBound10940 : H12AffineFastState.Bounded env10940 := by
  intro p hp
  have h : env10940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10939_10940 : H12AffineEnvironment.transform 16 90138 env10939 = env10940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10939 == env10940) = true)

theorem identity10940 : scanCanonicalize (H12AffineFastState.compose env10940 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound10940 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10280,1025,29788,77899,73771,16,21763,8192,65,67926,5392,91402,97406,75103,73771,257,21793,16464,513]

theorem envBound10941 : H12AffineFastState.Bounded env10941 := by
  intro p hp
  have h : env10941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10940_10941 : H12AffineEnvironment.transform 21 73771 env10940 = env10941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env10940 == env10941) = true)

theorem identity10941 : scanCanonicalize (H12AffineFastState.compose env10941 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10941 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16400,10280,1025,29788,4161,33,16,21763,8192,65,10588,5392,17664,23668,1365,33,257,21793,16464,513]

theorem envBound10942 : H12AffineFastState.Bounded env10942 := by
  intro p hp
  have h : env10942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10941_10942 : H12AffineEnvironment.transform 15 8202 env10941 = env10942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10941 == env10942) = true)

theorem identity10942 : scanCanonicalize (H12AffineFastState.compose env10942 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound10942 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8202,5441,10280,1025,8461,4161,33,16,82,8192,65,10588,5392,4177,2341,1365,33,257,112,5377,513]

theorem envBound10943 : H12AffineFastState.Bounded env10943 := by
  intro p hp
  have h : env10943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10942_10943 : H12AffineEnvironment.transform 13 5457 env10942 = env10943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env10942 == env10943) = true)

theorem identity10943 : scanCanonicalize (H12AffineFastState.compose env10943 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound10943 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1061,8192,372,8460,8202,356,10280,1025,8461,1124,33,16,82,8192,65,10588,309,1140,2341,1365,33,257,112,292,513]

theorem envBound10944 : H12AffineFastState.Bounded env10944 := by
  intro p hp
  have h : env10944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10943_10944 : H12AffineEnvironment.transform 11 1061 env10943 = env10944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env10943 == env10944) = true)

theorem identity10944 : scanCanonicalize (H12AffineFastState.compose env10944 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1108) := by decide +kernel

theorem selectedBound10944 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env10945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1108,1061,8192,372,8460,8202,356,9340,1025,8461,1124,33,16,82,8192,65,9480,309,1140,1393,1365,33,257,112,292,513]

theorem envBound10945 : H12AffineFastState.Bounded env10945 := by
  intro p hp
  have h : env10945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10944_10945 : H12AffineEnvironment.transform 10 1108 env10944 = env10945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1108 env10944 == env10945) = true)

theorem identity10945 : scanCanonicalize (H12AffineFastState.compose env10945 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10945 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env10946 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1029,1061,8192,293,8460,8202,309,9261,1025,8461,1077,33,16,3,8192,16,9480,309,1061,1312,1284,33,257,33,292,513]

theorem envBound10946 : H12AffineFastState.Bounded env10946 := by
  intro p hp
  have h : env10946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10945_10946 : H12AffineEnvironment.transform 5 17 env10945 = env10946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10945 == env10946) = true)

theorem identity10946 : scanCanonicalize (H12AffineFastState.compose env10946 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10947 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1029,1061,8192,32,8201,8202,48,9261,1025,8200,1077,33,16,3,8192,16,9229,48,1061,1061,1025,33,4,33,33,513]

theorem envBound10947 : H12AffineFastState.Bounded env10947 := by
  intro p hp
  have h : env10947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10946_10947 : H12AffineEnvironment.transform 7 5 env10946 = env10947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10946 == env10947) = true)

theorem identity10947 : scanCanonicalize (H12AffineFastState.compose env10947 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound10947 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10948 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1029,1061,8,32,1,2,48,1061,1025,0,1077,33,16,3,8,16,1029,48,1061,1061,1025,33,4,33,33,513]

theorem envBound10948 : H12AffineFastState.Bounded env10948 := by
  intro p hp
  have h : env10948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10947_10948 : H12AffineEnvironment.transform 12 8 env10947 = env10948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env10947 == env10948) = true)

theorem identity10948 : scanCanonicalize (H12AffineFastState.compose env10948 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10948 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10949 : List Nat := [2,4,8,16,32,17,8,5,512,53,48,16,8,32,1,2,48,16,52,0,0,33,16,3,8,16,48,48,16,16,52,33,4,33,33,513]

theorem envBound10949 : H12AffineFastState.Bounded env10949 := by
  intro p hp
  have h : env10949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10948_10949 : H12AffineEnvironment.transform 9 53 env10948 = env10949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10948 == env10949) = true)

theorem identity10949 : scanCanonicalize (H12AffineFastState.compose env10949 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound10949 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10950 : List Nat := [2,4,8,16,32,17,8,5,32,53,48,16,8,32,1,2,48,16,52,0,0,33,16,3,8,16,48,48,16,16,52,33,4,33,33,33]

theorem envBound10950 : H12AffineFastState.Bounded env10950 := by
  intro p hp
  have h : env10950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10949_10950 : H12AffineEnvironment.transform 8 32 env10949 = env10950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env10949 == env10950) = true)

theorem identity10950 : scanCanonicalize (H12AffineFastState.compose env10950 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10950 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10951 : List Nat := [2,4,8,1,32,0,8,5,32,36,33,1,8,32,1,2,33,1,37,0,0,33,1,3,8,1,33,33,1,1,37,33,4,33,33,33]

theorem envBound10951 : H12AffineFastState.Bounded env10951 := by
  intro p hp
  have h : env10951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10950_10951 : H12AffineEnvironment.transform 3 1 env10950 = env10951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10950 == env10951) = true)

theorem identity10951 : scanCanonicalize (H12AffineFastState.compose env10951 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10952 : List Nat := [2,4,8,1,0,0,8,5,0,4,1,1,8,0,1,2,1,1,5,0,0,1,1,3,8,1,1,1,1,1,5,1,4,1,1,1]

theorem envBound10952 : H12AffineFastState.Bounded env10952 := by
  intro p hp
  have h : env10952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10951_10952 : H12AffineEnvironment.transform 4 0 env10951 = env10952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10951 == env10952) = true)

theorem identity10952 : scanCanonicalize (H12AffineFastState.compose env10952 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10953 : List Nat := [2,4,3,1,0,0,3,5,0,4,1,1,3,0,1,2,1,1,5,0,0,1,1,3,3,1,1,1,1,1,5,1,4,1,1,1]

theorem envBound10953 : H12AffineFastState.Bounded env10953 := by
  intro p hp
  have h : env10953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10952_10953 : H12AffineEnvironment.transform 2 3 env10952 = env10953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10952 == env10953) = true)

def env10954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77899,4194304,62540,21762,8192,65,4409702,57676,102742,138340,75103,4194305,257,21793,46093,513]

theorem envBound10954 : H12AffineFastState.Bounded env10954 := by
  intro p hp
  have h : env10954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10912_10954 : H12AffineEnvironment.transform 17 10281 env10912 = env10954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10912 == env10954) = true)

theorem identity10954 : scanCanonicalize (H12AffineFastState.compose env10954 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound10954 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,77899,4194304,17,21762,8192,65,4409702,5393,91403,138340,75103,4194305,257,21793,16464,513]

theorem envBound10955 : H12AffineFastState.Bounded env10955 := by
  intro p hp
  have h : env10955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10954_10955 : H12AffineEnvironment.transform 14 29789 env10954 = env10955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10954 == env10955) = true)

theorem identity10955 : scanCanonicalize (H12AffineFastState.compose env10955 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10955 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,4194304,17,21762,8192,65,4352365,5393,17664,138340,1364,4194305,257,21793,16464,513]

theorem envBound10956 : H12AffineFastState.Bounded env10956 := by
  intro p hp
  have h : env10956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10955_10956 : H12AffineEnvironment.transform 15 8203 env10955 = env10956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10955 == env10956) = true)

theorem identity10956 : scanCanonicalize (H12AffineFastState.compose env10956 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound10956 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env10957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,29741,17,21762,8192,65,138560,5393,17664,138340,1364,29740,257,21793,16464,513]

theorem envBound10957 : H12AffineFastState.Bounded env10957 := by
  intro p hp
  have h : env10957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10956_10957 : H12AffineEnvironment.transform 21 29741 env10956 = env10957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env10956 == env10957) = true)

theorem identity10957 : scanCanonicalize (H12AffineFastState.compose env10957 (packedSelected [1,4,8,9,10,12,18] rootPS)) = affineNative (2^(16+1) ^^^ 10296) := by decide +kernel

theorem selectedBound10957 : packedSelected [1,4,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env10958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,10296,10281,1025,29788,4160,29741,17,21762,8192,65,13688,5393,17664,13404,1364,29740,257,21793,16464,513]

theorem envBound10958 : H12AffineFastState.Bounded env10958 := by
  intro p hp
  have h : env10958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10957_10958 : H12AffineEnvironment.transform 16 10296 env10957 = env10958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10296 env10957 == env10958) = true)

theorem identity10958 : scanCanonicalize (H12AffineFastState.compose env10958 (packedSelected [0,4,7,9,11,20] rootPS)) = affineNative (2^(13+1) ^^^ 15453) := by decide +kernel

theorem selectedBound10958 : packedSelected [0,4,7,9,11,20] rootPS < 2^1333 := by decide +kernel

def env10959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15453,2048,8203,10296,10281,1025,2049,4160,2160,17,10591,8192,65,13688,5393,14685,13404,1364,2161,257,10620,15373,513]

theorem envBound10959 : H12AffineFastState.Bounded env10959 := by
  intro p hp
  have h : env10959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10958_10959 : H12AffineEnvironment.transform 13 15453 env10958 = env10959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15453 env10958 == env10959) = true)

theorem identity10959 : scanCanonicalize (H12AffineFastState.compose env10959 (packedSelected [1,2,5,6,8,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 3149) := by decide +kernel

theorem selectedBound10959 : packedSelected [1,2,5,6,8,12,15,24] rootPS < 2^1333 := by decide +kernel

def env10960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3149,4112,2048,3142,1141,1124,1025,2049,4160,2160,17,1298,3149,65,6453,5393,5392,6161,1364,2161,257,1329,4160,513]

theorem envBound10960 : H12AffineFastState.Bounded env10960 := by
  intro p hp
  have h : env10960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10959_10960 : H12AffineEnvironment.transform 12 3149 env10959 = env10960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3149 env10959 == env10960) = true)

theorem identity10960 : scanCanonicalize (H12AffineFastState.compose env10960 (packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound10960 : packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS < 2^1333 := by decide +kernel

def env10961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1140,3149,1124,2048,3142,1141,1124,1025,2049,1076,2160,17,1298,3149,65,3393,357,356,3173,1364,2161,257,1329,1076,513]

theorem envBound10961 : H12AffineFastState.Bounded env10961 := by
  intro p hp
  have h : env10961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10960_10961 : H12AffineEnvironment.transform 11 1140 env10960 = env10961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env10960 == env10961) = true)

theorem identity10961 : scanCanonicalize (H12AffineFastState.compose env10961 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10961 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10962 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,357,2396,373,2048,2391,356,373,272,2049,293,2160,17,3,2396,65,2128,357,356,2420,69,2161,257,32,293,513]

theorem envBound10962 : H12AffineFastState.Bounded env10962 := by
  intro p hp
  have h : env10962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10961_10962 : H12AffineEnvironment.transform 9 273 env10961 = env10962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10961 == env10962) = true)

theorem identity10962 : scanCanonicalize (H12AffineFastState.compose env10962 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound10962 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10963 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,357,268,373,80,263,356,373,272,81,293,32,17,3,268,65,0,357,356,292,69,33,257,32,293,513]

theorem envBound10963 : H12AffineFastState.Bounded env10963 := by
  intro p hp
  have h : env10963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10962_10963 : H12AffineEnvironment.transform 10 80 env10962 = env10963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env10962 == env10963) = true)

def env10964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444641,8193,65,6705413,313701,2394420,138340,2102549,4466728,257,21793,46092,2175562]

theorem envBound10964 : H12AffineFastState.Bounded env10964 := by
  intro p hp
  have h : env10964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10910_10964 : H12AffineEnvironment.transform 6 9 env10910 = env10964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10910 == env10964) = true)

def env10965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318565,2444641,8193,65,158029,313701,2394420,138340,2102549,2101344,257,21793,46092,2175562]

theorem envBound10965 : H12AffineFastState.Bounded env10965 := by
  intro p hp
  have h : env10965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10964_10965 : H12AffineEnvironment.transform 21 2373704 env10964 = env10965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env10964 == env10965) = true)

theorem identity10965 : scanCanonicalize (H12AffineFastState.compose env10965 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound10965 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,329731,318565,294186,8193,65,158029,313701,375167,138340,75102,73771,257,21793,46092,513]

theorem envBound10966 : H12AffineFastState.Bounded env10966 := by
  intro p hp
  have h : env10966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10965_10966 : H12AffineEnvironment.transform 20 77899 env10965 = env10966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env10965 == env10966) = true)

theorem identity10966 : scanCanonicalize (H12AffineFastState.compose env10966 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10966 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77899,329731,318565,294186,8193,65,67927,313701,375167,97406,75102,73771,257,21793,46092,513]

theorem envBound10967 : H12AffineFastState.Bounded env10967 := by
  intro p hp
  have h : env10967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10966_10967 : H12AffineEnvironment.transform 16 90138 env10966 = env10967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10966 == env10967) = true)

theorem identity10967 : scanCanonicalize (H12AffineFastState.compose env10967 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound10967 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env10968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,130175,1025,32769,77899,62588,73754,98645,8193,65,67927,79130,17664,97406,75102,73771,257,21793,46092,513]

theorem envBound10968 : H12AffineFastState.Bounded env10968 := by
  intro p hp
  have h : env10968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10967_10968 : H12AffineEnvironment.transform 17 130175 env10967 = env10968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env10967 == env10968) = true)

theorem identity10968 : scanCanonicalize (H12AffineFastState.compose env10968 (packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound10968 : packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env10969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,263,24861,64888,1025,32769,12620,62588,8477,32850,8193,65,2128,13341,17664,32121,9305,8492,257,21793,46092,513]

theorem envBound10969 : H12AffineFastState.Bounded env10969 := by
  intro p hp
  have h : env10969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10968_10969 : H12AffineEnvironment.transform 15 263 env10968 = env10969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env10968 == env10969) = true)

theorem identity10969 : scanCanonicalize (H12AffineFastState.compose env10969 (packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound10969 : packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env10970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,32768,263,16741,56576,1025,32769,4404,54276,357,32850,121,65,2128,5221,17664,23809,1057,340,257,21793,38004,513]

theorem envBound10970 : H12AffineFastState.Bounded env10970 := by
  intro p hp
  have h : env10970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10969_10970 : H12AffineEnvironment.transform 12 120 env10969 = env10970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env10969 == env10970) = true)

theorem identity10970 : scanCanonicalize (H12AffineFastState.compose env10970 (packedSelected [0,2,7,11,14,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound10970 : packedSelected [0,2,7,11,14,17,18,20] rootPS < 2^1333 := by decide +kernel

def env10971 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,4452,32768,263,4097,35940,1025,32769,4404,34144,357,32850,121,65,2128,5221,5220,3173,1057,340,257,1093,38004,513]

theorem envBound10971 : H12AffineFastState.Bounded env10971 := by
  intro p hp
  have h : env10971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10970_10971 : H12AffineEnvironment.transform 13 4452 env10970 = env10971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env10970 == env10971) = true)

theorem identity10971 : scanCanonicalize (H12AffineFastState.compose env10971 (packedSelected [1,2,3,5,7,8,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound10971 : packedSelected [1,2,3,5,7,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env10972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2357,120,2129,32768,263,2356,35940,1025,32769,2049,34144,357,32850,121,65,2128,3408,3409,3173,1057,340,257,1093,36161,513]

theorem envBound10972 : H12AffineFastState.Bounded env10972 := by
  intro p hp
  have h : env10972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10971_10972 : H12AffineEnvironment.transform 11 2357 env10971 = env10972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env10971 == env10972) = true)

theorem identity10972 : scanCanonicalize (H12AffineFastState.compose env10972 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound10972 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env10973 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2357,120,2129,1344,263,2356,2340,1025,1345,2049,32,357,1298,121,65,2128,3408,3409,3173,1057,340,257,1093,2049,513]

theorem envBound10973 : H12AffineFastState.Bounded env10973 := by
  intro p hp
  have h : env10973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10972_10973 : H12AffineEnvironment.transform 14 1344 env10972 = env10973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env10972 == env10973) = true)

theorem identity10973 : scanCanonicalize (H12AffineFastState.compose env10973 (packedSelected [3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10973 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env10974 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,40,2049,1296,263,2356,2340,1025,1297,2049,32,309,1298,41,17,2048,3328,3329,3125,1057,260,257,1045,2049,513]

theorem envBound10974 : H12AffineFastState.Bounded env10974 := by
  intro p hp
  have h : env10974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10973_10974 : H12AffineEnvironment.transform 5 16 env10973 = env10974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10973 == env10974) = true)

theorem identity10974 : scanCanonicalize (H12AffineFastState.compose env10974 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10974 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env10975 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2064,40,2049,1077,34,2065,2049,1025,1076,2049,32,16,1079,41,17,2048,3109,3108,3125,1057,33,36,1045,2049,513]

theorem envBound10975 : H12AffineFastState.Bounded env10975 := by
  intro p hp
  have h : env10975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10974_10975 : H12AffineEnvironment.transform 7 37 env10974 = env10975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10974 == env10975) = true)

theorem identity10975 : scanCanonicalize (H12AffineFastState.compose env10975 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound10975 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10976 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1076,1060,40,1077,1077,34,1061,1077,1025,1076,1077,32,16,1079,41,17,1076,17,16,1,1057,33,36,1045,1077,513]

theorem envBound10976 : H12AffineFastState.Bounded env10976 := by
  intro p hp
  have h : env10976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10975_10976 : H12AffineEnvironment.transform 10 1076 env10975 = env10976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env10975 == env10976) = true)

def env10977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318565,2444641,8193,65,158028,313701,2394420,138340,2102549,2101345,257,21793,46092,2175562]

theorem envBound10977 : H12AffineFastState.Bounded env10977 := by
  intro p hp
  have h : env10977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10964_10977 : H12AffineEnvironment.transform 21 2373705 env10964 = env10977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env10964 == env10977) = true)

def env10978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318565,351521,8193,65,158028,313701,301428,138340,1365,33,257,21793,46092,74250]

theorem envBound10978 : H12AffineFastState.Bounded env10978 := by
  intro p hp
  have h : env10978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10977_10978 : H12AffineEnvironment.transform 20 4160 env10977 = env10978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10977 == env10978) = true)

theorem identity10978 : scanCanonicalize (H12AffineFastState.compose env10978 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound10978 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21792,41292,73736,8193,65,158028,46156,58461,138340,1365,33,257,21793,46092,74250]

theorem envBound10979 : H12AffineFastState.Bounded env10979 := by
  intro p hp
  have h : env10979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10978_10979 : H12AffineEnvironment.transform 17 32041 env10978 = env10979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env10978 == env10979) = true)

theorem identity10979 : scanCanonicalize (H12AffineFastState.compose env10979 (packedSelected [1,5,8,16,19,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound10979 : packedSelected [1,5,8,16,19,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env10980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,79131,32041,1025,32769,4160,21792,41292,73736,8193,65,89175,46156,58461,76159,1365,33,257,21793,46092,74250]

theorem envBound10980 : H12AffineFastState.Bounded env10980 := by
  intro p hp
  have h : env10980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10979_10980 : H12AffineEnvironment.transform 16 79131 env10979 = env10980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env10979 == env10980) = true)

theorem identity10980 : scanCanonicalize (H12AffineFastState.compose env10980 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10980 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,10280,1025,32769,4160,33,41292,73736,8193,65,67926,46156,45404,76159,1365,33,257,32,46092,74250]

theorem envBound10981 : H12AffineFastState.Bounded env10981 := by
  intro p hp
  have h : env10981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10980_10981 : H12AffineEnvironment.transform 13 5377 env10980 = env10981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10980 == env10981) = true)

theorem identity10981 : scanCanonicalize (H12AffineFastState.compose env10981 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10981 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,5392,10280,1025,32769,4160,33,41292,3,8193,65,10589,46156,45404,2420,1365,33,257,32,46092,513]

theorem envBound10982 : H12AffineFastState.Bounded env10982 := by
  intro p hp
  have h : env10982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10981_10982 : H12AffineEnvironment.transform 15 8203 env10981 = env10982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10981 == env10982) = true)

theorem identity10982 : scanCanonicalize (H12AffineFastState.compose env10982 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound10982 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,112,8203,5392,10280,1025,113,4160,33,8508,3,8193,65,10589,13372,12588,2420,1365,33,257,32,13436,513]

theorem envBound10983 : H12AffineFastState.Bounded env10983 := by
  intro p hp
  have h : env10983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10982_10983 : H12AffineEnvironment.transform 14 112 env10982 = env10983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env10982 == env10983) = true)

theorem identity10983 : scanCanonicalize (H12AffineFastState.compose env10983 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound10983 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5377,112,294,5392,2309,1025,113,4160,33,17,3,300,65,2160,5393,4097,2420,1365,33,257,32,5457,513]

theorem envBound10984 : H12AffineFastState.Bounded env10984 := by
  intro p hp
  have h : env10984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10983_10984 : H12AffineEnvironment.transform 12 301 env10983 = env10984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env10983 == env10984) = true)

theorem identity10984 : scanCanonicalize (H12AffineFastState.compose env10984 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10985 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,301,5377,32,294,5392,2309,1025,33,4112,33,17,3,300,17,2080,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound10985 : H12AffineFastState.Bounded env10985 := by
  intro p hp
  have h : env10985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10984_10985 : H12AffineEnvironment.transform 5 16 env10984 = env10985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10984 == env10985) = true)

theorem identity10985 : scanCanonicalize (H12AffineFastState.compose env10985 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10986 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,301,4404,32,294,4389,2309,52,33,4112,33,17,3,300,17,2080,4388,4097,2340,304,33,257,32,4404,513]

theorem envBound10986 : H12AffineFastState.Bounded env10986 := by
  intro p hp
  have h : env10986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10985_10986 : H12AffineEnvironment.transform 9 53 env10985 = env10986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10985 == env10986) = true)

theorem identity10986 : scanCanonicalize (H12AffineFastState.compose env10986 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound10986 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env10987 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2356,301,2048,32,294,2065,2309,52,33,2340,33,17,3,300,17,2080,2064,2357,2340,304,33,257,32,2048,513]

theorem envBound10987 : H12AffineFastState.Bounded env10987 := by
  intro p hp
  have h : env10987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10986_10987 : H12AffineEnvironment.transform 11 2356 env10986 = env10987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env10986 == env10987) = true)

theorem identity10987 : scanCanonicalize (H12AffineFastState.compose env10987 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound10987 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env10988 : List Nat := [2,4,8,16,32,16,9,256,276,53,2048,2356,301,2048,32,294,2065,2309,52,33,2340,33,17,3,300,17,2080,2064,2357,2340,304,33,257,32,2048,277]

theorem envBound10988 : H12AffineFastState.Bounded env10988 := by
  intro p hp
  have h : env10988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10987_10988 : H12AffineEnvironment.transform 8 276 env10987 = env10988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env10987 == env10988) = true)

theorem identity10988 : scanCanonicalize (H12AffineFastState.compose env10988 (packedSelected [1,3,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound10988 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env10989 : List Nat := [2,4,8,16,32,16,9,256,276,53,1,309,301,1,32,294,16,260,52,33,293,33,17,3,300,17,33,17,308,293,304,33,257,32,1,277]

theorem envBound10989 : H12AffineFastState.Bounded env10989 := by
  intro p hp
  have h : env10989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10988_10989 : H12AffineEnvironment.transform 10 1 env10988 = env10989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10988 == env10989) = true)

theorem identity10989 : scanCanonicalize (H12AffineFastState.compose env10989 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound10989 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10990 : List Nat := [2,4,8,16,32,16,9,20,0,53,1,33,57,1,32,50,16,16,52,33,49,33,17,3,56,17,33,17,32,49,36,33,21,32,1,1]

theorem envBound10990 : H12AffineFastState.Bounded env10990 := by
  intro p hp
  have h : env10990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10989_10990 : H12AffineEnvironment.transform 7 20 env10989 = env10990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env10989 == env10990) = true)

def env10991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318565,351520,8193,65,158028,313701,301429,138340,1364,32,257,21793,46092,74251]

theorem envBound10991 : H12AffineFastState.Bounded env10991 := by
  intro p hp
  have h : env10991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10977_10991 : H12AffineEnvironment.transform 20 4161 env10977 = env10991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10977 == env10991) = true)

theorem identity10991 : scanCanonicalize (H12AffineFastState.compose env10991 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10991 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,4161,272392,297317,329760,8193,65,146508,302181,301429,138340,1364,32,257,33,46092,74251]

theorem envBound10992 : H12AffineFastState.Bounded env10992 := by
  intro p hp
  have h : env10992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10991_10992 : H12AffineEnvironment.transform 13 5376 env10991 = env10992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10991 == env10992) = true)

theorem identity10992 : scanCanonicalize (H12AffineFastState.compose env10992 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound10992 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env10993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67619,1025,32769,4161,73771,98630,3,8193,65,146508,103494,102742,138340,1364,32,257,33,46092,74251]

theorem envBound10993 : H12AffineFastState.Bounded env10993 := by
  intro p hp
  have h : env10993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10992_10993 : H12AffineEnvironment.transform 17 67619 env10992 = env10993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env10992 == env10993) = true)

theorem identity10993 : scanCanonicalize (H12AffineFastState.compose env10993 (packedSelected [0,1,6,7,8,10,15,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound10993 : packedSelected [0,1,6,7,8,10,15,21,23] rootPS < 2^1333 := by decide +kernel

def env10994 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32,65536,131072,67619,1025,33,4161,73771,65894,3,8193,65,146508,70758,70006,138340,1364,32,257,33,13356,74251]

theorem envBound10994 : H12AffineFastState.Bounded env10994 := by
  intro p hp
  have h : env10994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10993_10994 : H12AffineEnvironment.transform 14 32 env10993 = env10994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env10993 == env10994) = true)

theorem identity10994 : scanCanonicalize (H12AffineFastState.compose env10994 (packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10994 : packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env10995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32,65536,131072,67619,1025,33,4161,65910,65894,3,348,65,138513,70758,70006,138340,1364,32,257,33,5489,66390]

theorem envBound10995 : H12AffineFastState.Bounded env10995 := by
  intro p hp
  have h : env10995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10994_10995 : H12AffineEnvironment.transform 12 349 env10994 = env10995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10994 == env10995) = true)

end H12CloudChart1