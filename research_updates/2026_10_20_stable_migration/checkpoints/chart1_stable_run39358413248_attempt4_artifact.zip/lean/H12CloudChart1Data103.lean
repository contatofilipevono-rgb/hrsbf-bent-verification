import H12CloudChart1Data102

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans26089_26090 : H12AffineEnvironment.transform 2 3 env26089 = env26090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26089 == env26090) = true)

theorem identity26090 : scanCanonicalize (H12AffineFastState.compose env26090 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26090 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26091 : List Nat := [2,4,3,1,0,1,2,5,1,4,0,0,2,0,1,2,1,0,5,0,1,1,0,3,3,0,0,0,1,1,4,1,4,0,0,0]

theorem envBound26091 : H12AffineFastState.Bounded env26091 := by
  intro p hp
  have h : env26091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26090_26091 : H12AffineEnvironment.transform 4 0 env26090 = env26091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26090 == env26091) = true)

def env26092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,4194304,8388608,95496,8328,65,12754345,79131,8491470,8579232,8450329,4314199,257,8484155,8492191,8509135]

theorem envBound26092 : H12AffineFastState.Bounded env26092 := by
  intro p hp
  have h : env26092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26037_26092 : H12AffineEnvironment.transform 17 10401 env26037 = env26092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26037 == env26092) = true)

def env26093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,32,8388608,95496,8328,65,8560009,79131,8491470,8579232,8450329,119927,257,8484155,8492191,8509135]

theorem envBound26093 : H12AffineFastState.Bounded env26093 := by
  intro p hp
  have h : env26093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26092_26093 : H12AffineEnvironment.transform 21 32 env26092 = env26093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26092 == env26093) = true)

theorem identity26093 : scanCanonicalize (H12AffineFastState.compose env26093 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound26093 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,32,120014,95496,8328,65,215367,79131,17664,212078,75223,119927,257,41461,16465,513]

theorem envBound26094 : H12AffineFastState.Bounded env26094 := by
  intro p hp
  have h : env26094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26093_26094 : H12AffineEnvironment.transform 22 120014 env26093 = env26094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env26093 == env26094) = true)

def env26095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,32,119878,95496,8192,65,215367,79131,17664,212078,75103,119927,257,41341,16465,513]

theorem envBound26095 : H12AffineFastState.Bounded env26095 := by
  intro p hp
  have h : env26095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26094_26095 : H12AffineEnvironment.transform 6 8 env26094 = env26095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26094 == env26095) = true)

theorem identity26095 : scanCanonicalize (H12AffineFastState.compose env26095 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound26095 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env26096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57629,10281,1025,32769,115735,32,119878,95496,8192,65,108634,79131,17664,122227,75103,119927,257,41341,16465,513]

theorem envBound26096 : H12AffineFastState.Bounded env26096 := by
  intro p hp
  have h : env26096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26095_26096 : H12AffineEnvironment.transform 16 57629 env26095 = env26096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env26095 == env26096) = true)

theorem identity26096 : scanCanonicalize (H12AffineFastState.compose env26096 (packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound26096 : packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41051,57629,10281,1025,32769,25676,32,29725,54611,8192,65,2049,38208,17664,32040,34052,29740,257,41341,16465,513]

theorem envBound26097 : H12AffineFastState.Bounded env26097 := by
  intro p hp
  have h : env26097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26096_26097 : H12AffineEnvironment.transform 15 41051 env26096 = env26097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env26096 == env26097) = true)

theorem identity26097 : scanCanonicalize (H12AffineFastState.compose env26097 (packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26097 : packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS < 2^1333 := by decide +kernel

def env26098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,343,16401,10281,1025,8461,25676,32,29725,29791,8192,65,2049,13388,17664,32040,9224,29740,257,113,16465,513]

theorem envBound26098 : H12AffineFastState.Bounded env26098 := by
  intro p hp
  have h : env26098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26097_26098 : H12AffineEnvironment.transform 14 8460 env26097 = env26098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26097 == env26098) = true)

theorem identity26098 : scanCanonicalize (H12AffineFastState.compose env26098 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26098 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env26099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,343,16401,2420,1025,80,17681,32,21824,21762,349,65,2049,5393,17664,23669,1365,21873,257,113,16465,513]

theorem envBound26099 : H12AffineFastState.Bounded env26099 := by
  intro p hp
  have h : env26099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26098_26099 : H12AffineEnvironment.transform 12 349 env26098 = env26099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26098 == env26099) = true)

theorem identity26099 : scanCanonicalize (H12AffineFastState.compose env26099 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound26099 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,81,343,5440,2420,1025,80,4160,32,17,83,349,65,2049,5393,4177,2340,1365,32,257,113,5376,513]

theorem envBound26100 : H12AffineFastState.Bounded env26100 := by
  intro p hp
  have h : env26100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26099_26100 : H12AffineEnvironment.transform 13 5457 env26099 = env26100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env26099 == env26100) = true)

theorem identity26100 : scanCanonicalize (H12AffineFastState.compose env26100 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3636) := by decide +kernel

theorem selectedBound26100 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env26101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3636,349,2917,81,343,2932,2420,1025,80,3700,32,17,83,349,65,2049,2853,3685,2340,1365,32,257,113,2868,513]

theorem envBound26101 : H12AffineFastState.Bounded env26101 := by
  intro p hp
  have h : env26101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26100_26101 : H12AffineEnvironment.transform 11 3636 env26100 = env26101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3636 env26100 == env26101) = true)

theorem identity26101 : scanCanonicalize (H12AffineFastState.compose env26101 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound26101 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env26102 : List Nat := [2,4,8,16,32,64,8,256,292,1024,2048,3344,349,2113,81,343,2128,2420,1025,80,3408,32,17,83,349,65,2049,2049,3393,2340,1365,32,257,113,2064,293]

theorem envBound26102 : H12AffineFastState.Bounded env26102 := by
  intro p hp
  have h : env26102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26101_26102 : H12AffineEnvironment.transform 8 292 env26101 = env26102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env26101 == env26102) = true)

theorem identity26102 : scanCanonicalize (H12AffineFastState.compose env26102 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound26102 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env26103 : List Nat := [2,4,8,16,32,64,8,101,65,1024,2048,3189,56,2113,81,50,2128,2065,1025,80,3125,32,17,83,56,65,2049,2049,3108,2113,1072,32,100,113,2064,64]

theorem envBound26103 : H12AffineFastState.Bounded env26103 := by
  intro p hp
  have h : env26103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26102_26103 : H12AffineEnvironment.transform 7 101 env26102 = env26103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env26102 == env26103) = true)

theorem identity26103 : scanCanonicalize (H12AffineFastState.compose env26103 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound26103 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26104 : List Nat := [2,4,8,16,32,64,8,101,65,36,2048,2129,56,2113,81,50,2128,2065,37,80,2065,32,17,83,56,65,2049,2049,2048,2113,20,32,100,113,2064,64]

theorem envBound26104 : H12AffineFastState.Bounded env26104 := by
  intro p hp
  have h : env26104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26103_26104 : H12AffineEnvironment.transform 9 36 env26103 = env26104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env26103 == env26104) = true)

theorem identity26104 : scanCanonicalize (H12AffineFastState.compose env26104 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound26104 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26105 : List Nat := [2,4,8,16,32,64,8,101,65,36,17,64,56,80,81,50,65,0,37,80,0,32,17,83,56,65,16,16,17,80,20,32,100,113,1,64]

theorem envBound26105 : H12AffineFastState.Bounded env26105 := by
  intro p hp
  have h : env26105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26104_26105 : H12AffineEnvironment.transform 10 17 env26104 = env26105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env26104 == env26105) = true)

def env26106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,32,119879,95496,8193,65,215367,79131,17664,212078,75102,119927,257,41340,16465,513]

theorem envBound26106 : H12AffineFastState.Bounded env26106 := by
  intro p hp
  have h : env26106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26094_26106 : H12AffineEnvironment.transform 6 9 env26094 = env26106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26094 == env26106) = true)

theorem identity26106 : scanCanonicalize (H12AffineFastState.compose env26106 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26106 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1025,8540,91467,32,95514,95496,8193,65,215367,79131,17664,212078,75102,95530,257,33,16465,513]

theorem envBound26107 : H12AffineFastState.Bounded env26107 := by
  intro p hp
  have h : env26107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26106_26107 : H12AffineEnvironment.transform 14 8541 env26106 = env26107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26106 == env26107) = true)

theorem identity26107 : scanCanonicalize (H12AffineFastState.compose env26107 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 89110) := by decide +kernel

theorem selectedBound26107 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env26108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,89110,10280,1025,8540,91467,32,95514,95496,8193,65,5457,79131,17664,24696,75102,95530,257,33,16465,513]

theorem envBound26108 : H12AffineFastState.Bounded env26108 := by
  intro p hp
  have h : env26108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26107_26108 : H12AffineEnvironment.transform 16 89110 env26107 = env26108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 89110 env26107 == env26108) = true)

theorem identity26108 : scanCanonicalize (H12AffineFastState.compose env26108 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound26108 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7504,65536,89110,5157,1025,7505,88390,32,84247,84229,7180,65,5457,67862,17664,23669,72019,84263,257,33,16465,513]

theorem envBound26109 : H12AffineFastState.Bounded env26109 := by
  intro p hp
  have h : env26109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26108_26109 : H12AffineEnvironment.transform 12 7181 env26108 = env26109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env26108 == env26109) = true)

theorem identity26109 : scanCanonicalize (H12AffineFastState.compose env26109 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1379) := by decide +kernel

theorem selectedBound26109 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env26110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7504,1379,22901,5157,1025,7505,23589,32,19572,19558,7180,65,5457,3189,17664,23669,7216,19524,257,33,16465,513]

theorem envBound26110 : H12AffineFastState.Bounded env26110 := by
  intro p hp
  have h : env26110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26109_26110 : H12AffineEnvironment.transform 15 1379 env26109 = env26110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1379 env26109 == env26110) = true)

theorem identity26110 : scanCanonicalize (H12AffineFastState.compose env26110 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26110 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env26111 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,6200,16384,6501,342,22901,4112,52,6500,22544,32,18497,18515,6201,65,4452,2112,16693,22592,6149,18545,257,33,16465,513]

theorem envBound26111 : H12AffineFastState.Bounded env26111 := by
  intro p hp
  have h : env26111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26110_26111 : H12AffineEnvironment.transform 9 53 env26110 = env26111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26110 == env26111) = true)

theorem identity26111 : scanCanonicalize (H12AffineFastState.compose env26111 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26111 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env26112 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,6200,16384,6453,262,22821,4112,52,6452,22544,32,18449,18435,6201,17,4404,2064,16693,22544,6149,18465,257,33,16385,513]

theorem envBound26112 : H12AffineFastState.Bounded env26112 := by
  intro p hp
  have h : env26112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26111_26112 : H12AffineEnvironment.transform 5 16 env26111 = env26112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26111 == env26112) = true)

theorem identity26112 : scanCanonicalize (H12AffineFastState.compose env26112 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound26112 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26113 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,6200,2048,6453,262,4389,4112,52,6452,4112,32,17,3,6201,17,4404,2064,2357,4112,6149,33,257,33,2049,513]

theorem envBound26113 : H12AffineFastState.Bounded env26113 := by
  intro p hp
  have h : env26113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26112_26113 : H12AffineEnvironment.transform 13 2048 env26112 = env26113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env26112 == env26113) = true)

theorem identity26113 : scanCanonicalize (H12AffineFastState.compose env26113 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound26113 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26114 : List Nat := [2,4,8,16,32,16,9,256,308,53,2048,4096,6200,2048,6453,262,4389,4112,52,6452,4112,32,17,3,6201,17,4404,2064,2357,4112,6149,33,257,33,2049,309]

theorem envBound26114 : H12AffineFastState.Bounded env26114 := by
  intro p hp
  have h : env26114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26113_26114 : H12AffineEnvironment.transform 8 308 env26113 = env26114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env26113 == env26114) = true)

theorem identity26114 : scanCanonicalize (H12AffineFastState.compose env26114 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound26114 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env26115 : List Nat := [2,4,8,16,32,16,9,256,308,53,308,4096,4364,308,4097,262,4389,4112,52,4096,4112,32,17,3,4365,17,4404,292,1,4112,4401,33,257,33,309,309]

theorem envBound26115 : H12AffineFastState.Bounded env26115 := by
  intro p hp
  have h : env26115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26114_26115 : H12AffineEnvironment.transform 10 308 env26114 = env26115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env26114 == env26115) = true)

theorem identity26115 : scanCanonicalize (H12AffineFastState.compose env26115 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26115 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26116 : List Nat := [2,4,8,16,32,16,9,37,17,53,17,4096,4137,17,4097,35,4096,4112,52,4096,4112,32,17,3,4136,17,4113,1,1,4112,4116,33,36,33,16,16]

theorem envBound26116 : H12AffineFastState.Bounded env26116 := by
  intro p hp
  have h : env26116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26115_26116 : H12AffineEnvironment.transform 7 37 env26115 = env26116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26115 == env26116) = true)

theorem identity26116 : scanCanonicalize (H12AffineFastState.compose env26116 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26117 : List Nat := [2,4,8,16,1,16,9,4,17,20,17,4096,4104,17,4097,2,4096,4112,21,4096,4112,1,17,3,4105,17,4113,1,1,4112,4116,0,5,0,16,16]

theorem envBound26117 : H12AffineFastState.Bounded env26117 := by
  intro p hp
  have h : env26117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26116_26117 : H12AffineEnvironment.transform 4 1 env26116 = env26117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26116 == env26117) = true)

theorem identity26117 : scanCanonicalize (H12AffineFastState.compose env26117 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26117 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env26118 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,4096,4104,0,4097,2,4096,4097,4,4096,4097,1,0,3,4105,0,4096,1,1,4097,4101,0,5,0,1,1]

theorem envBound26118 : H12AffineFastState.Bounded env26118 := by
  intro p hp
  have h : env26118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26117_26118 : H12AffineEnvironment.transform 3 1 env26117 = env26118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26117 == env26118) = true)

theorem identity26118 : scanCanonicalize (H12AffineFastState.compose env26118 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound26118 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26119 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,1,9,0,0,2,1,0,4,1,0,1,0,3,8,0,1,1,1,0,4,0,5,0,1,1]

theorem envBound26119 : H12AffineFastState.Bounded env26119 := by
  intro p hp
  have h : env26119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26118_26119 : H12AffineEnvironment.transform 11 1 env26118 = env26119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env26118 == env26119) = true)

def env26120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,33,8388608,95496,8328,65,8560008,79131,8491470,8579232,8450329,119926,257,8484155,8492191,8509135]

theorem envBound26120 : H12AffineFastState.Bounded env26120 := by
  intro p hp
  have h : env26120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26092_26120 : H12AffineEnvironment.transform 21 33 env26092 = env26120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26092 == env26120) = true)

theorem identity26120 : scanCanonicalize (H12AffineFastState.compose env26120 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound26120 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10401,1025,32769,4160,33,8388608,41431,8328,65,8560008,57796,8406289,8579232,8450329,169,257,8430052,8405056,8389136]

theorem envBound26121 : H12AffineFastState.Bounded env26121 := by
  intro p hp
  have h : env26121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26120_26121 : H12AffineEnvironment.transform 15 54495 env26120 = env26121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env26120 == env26121) = true)

theorem identity26121 : scanCanonicalize (H12AffineFastState.compose env26121 (packedSelected [3,10,11,17,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound26121 : packedSelected [3,10,11,17,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env26122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10401,1025,32769,4160,33,17,41431,8328,65,171417,57796,17664,190641,61704,169,257,41461,16465,513]

theorem envBound26122 : H12AffineFastState.Bounded env26122 := by
  intro p hp
  have h : env26122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26121_26122 : H12AffineEnvironment.transform 22 17 env26121 = env26122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env26121 == env26122) = true)

def env26123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4160,33,17,41311,8192,65,171281,57676,17664,190521,61704,33,257,41341,16465,513]

theorem envBound26123 : H12AffineFastState.Bounded env26123 := by
  intro p hp
  have h : env26123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26122_26123 : H12AffineEnvironment.transform 6 8 env26122 = env26123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26122 == env26123) = true)

theorem identity26123 : scanCanonicalize (H12AffineFastState.compose env26123 (packedSelected [0,4,7,9,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26123 : packedSelected [0,4,7,9,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env26124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,5393,10281,1025,32769,4160,33,17,41311,8192,65,34816,57676,17664,64808,61704,33,257,41341,16465,513]

theorem envBound26124 : H12AffineFastState.Bounded env26124 := by
  intro p hp
  have h : env26124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26123_26124 : H12AffineEnvironment.transform 16 5393 env26123 = env26124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26123 == env26124) = true)

theorem identity26124 : scanCanonicalize (H12AffineFastState.compose env26124 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26124 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env26125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40971,5393,10281,1025,32769,4160,33,17,41311,8192,65,34816,38160,12636,35188,34132,33,257,41341,13325,513]

theorem envBound26125 : H12AffineFastState.Bounded env26125 := by
  intro p hp
  have h : env26125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26124_26125 : H12AffineEnvironment.transform 13 13404 env26124 = env26125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26124 == env26125) = true)

theorem identity26125 : scanCanonicalize (H12AffineFastState.compose env26125 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26125 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,342,5393,10281,1025,8540,4160,33,17,2,8192,65,10589,13389,12636,10281,9225,33,257,32,13325,513]

theorem envBound26126 : H12AffineFastState.Bounded env26126 := by
  intro p hp
  have h : env26126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26125_26126 : H12AffineEnvironment.transform 14 8541 env26125 = env26126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26125 == env26126) = true)

theorem identity26126 : scanCanonicalize (H12AffineFastState.compose env26126 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26126 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env26127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,80,342,5393,2340,1025,81,4160,33,17,2,269,65,2128,5440,4177,2340,1284,33,257,32,5376,513]

theorem envBound26127 : H12AffineFastState.Bounded env26127 := by
  intro p hp
  have h : env26127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26126_26127 : H12AffineEnvironment.transform 12 269 env26126 = env26127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26126 == env26127) = true)

theorem identity26127 : scanCanonicalize (H12AffineFastState.compose env26127 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26127 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26128 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4112,33,17,2,269,17,2048,5392,4097,2340,1284,33,257,32,5376,513]

theorem envBound26128 : H12AffineFastState.Bounded env26128 := by
  intro p hp
  have h : env26128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26127_26128 : H12AffineEnvironment.transform 5 16 env26127 = env26128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26127 == env26128) = true)

theorem identity26128 : scanCanonicalize (H12AffineFastState.compose env26128 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26129 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,35,5172,2049,1025,1,4112,33,17,2,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound26129 : H12AffineFastState.Bounded env26129 := by
  intro p hp
  have h : env26129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26128_26129 : H12AffineEnvironment.transform 7 37 env26128 = env26129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26128 == env26129) = true)

theorem identity26129 : scanCanonicalize (H12AffineFastState.compose env26129 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound26129 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26130 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,16,40,1076,0,35,1060,2049,1025,1,0,33,17,2,40,17,2048,1061,17,2049,1057,33,36,32,1077,513]

theorem envBound26130 : H12AffineFastState.Bounded env26130 := by
  intro p hp
  have h : env26130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26129_26130 : H12AffineEnvironment.transform 11 16 env26129 = env26130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26129 == env26130) = true)

theorem identity26130 : scanCanonicalize (H12AffineFastState.compose env26130 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26130 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26131 : List Nat := [2,4,8,16,32,16,8,37,512,1024,0,16,40,1076,0,35,1060,1,1025,1,0,33,17,2,40,17,0,1061,17,1,1057,33,36,32,1077,513]

theorem envBound26131 : H12AffineFastState.Bounded env26131 := by
  intro p hp
  have h : env26131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26130_26131 : H12AffineEnvironment.transform 10 0 env26130 = env26131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26130 == env26131) = true)

theorem identity26131 : scanCanonicalize (H12AffineFastState.compose env26131 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26131 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26132 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,16,40,1,0,35,17,1,52,1,0,33,17,2,40,17,0,16,17,1,20,33,36,32,0,513]

theorem envBound26132 : H12AffineFastState.Bounded env26132 := by
  intro p hp
  have h : env26132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26131_26132 : H12AffineEnvironment.transform 9 53 env26131 = env26132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26131 == env26132) = true)

theorem identity26132 : scanCanonicalize (H12AffineFastState.compose env26132 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound26132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26133 : List Nat := [2,4,8,16,32,16,8,37,17,53,0,16,40,1,0,35,17,1,52,1,0,33,17,2,40,17,0,16,17,1,20,33,36,32,0,16]

theorem envBound26133 : H12AffineFastState.Bounded env26133 := by
  intro p hp
  have h : env26133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26132_26133 : H12AffineEnvironment.transform 8 17 env26132 = env26133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env26132 == env26133) = true)

theorem identity26133 : scanCanonicalize (H12AffineFastState.compose env26133 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26134 : List Nat := [2,4,3,16,32,16,3,37,17,53,0,16,35,1,0,35,17,1,52,1,0,33,17,2,35,17,0,16,17,1,20,33,36,32,0,16]

theorem envBound26134 : H12AffineFastState.Bounded env26134 := by
  intro p hp
  have h : env26134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26133_26134 : H12AffineEnvironment.transform 2 3 env26133 = env26134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26133 == env26134) = true)

def env26135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1025,32769,4160,33,17,41310,8193,65,171280,57677,17664,190520,61704,32,257,41340,16465,513]

theorem envBound26135 : H12AffineFastState.Bounded env26135 := by
  intro p hp
  have h : env26135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26122_26135 : H12AffineEnvironment.transform 6 9 env26122 = env26135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26122 == env26135) = true)

theorem identity26135 : scanCanonicalize (H12AffineFastState.compose env26135 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26135 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,131072,10280,1025,8540,4160,33,17,3,8193,65,146509,16400,17664,149861,20565,32,257,33,16465,513]

theorem envBound26136 : H12AffineFastState.Bounded env26136 := by
  intro p hp
  have h : env26136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26135_26136 : H12AffineEnvironment.transform 14 8541 env26135 = env26136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26135 == env26136) = true)

theorem identity26136 : scanCanonicalize (H12AffineFastState.compose env26136 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26136 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env26137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,8192,16384,8541,27930,131072,10280,1025,8540,2129,33,17,3,8193,65,140380,16400,17664,149861,18500,32,257,33,16465,513]

theorem envBound26137 : H12AffineFastState.Bounded env26137 := by
  intro p hp
  have h : env26137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26136_26137 : H12AffineEnvironment.transform 11 2065 env26136 = env26137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env26136 == env26137) = true)

theorem identity26137 : scanCanonicalize (H12AffineFastState.compose env26137 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26137 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env26138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,1,19526,131072,2420,1025,0,2129,33,17,3,349,65,132352,16400,17664,149861,18500,32,257,33,16465,513]

theorem envBound26138 : H12AffineFastState.Bounded env26138 := by
  intro p hp
  have h : env26138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26137_26138 : H12AffineEnvironment.transform 12 348 env26137 = env26138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26137 == env26138) = true)

theorem identity26138 : scanCanonicalize (H12AffineFastState.compose env26138 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26138 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,1,19526,2065,2420,1025,0,2129,33,17,3,349,65,3345,16400,17664,16756,18500,32,257,33,16465,513]

theorem envBound26139 : H12AffineFastState.Bounded env26139 := by
  intro p hp
  have h : env26139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26138_26139 : H12AffineEnvironment.transform 16 2065 env26138 = env26139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2065 env26138 == env26139) = true)

theorem identity26139 : scanCanonicalize (H12AffineFastState.compose env26139 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26139 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env26140 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2065,348,16384,1,18775,2065,2420,272,0,2129,33,17,3,349,65,2048,16400,16401,16756,18500,32,257,33,16465,513]

theorem envBound26140 : H12AffineFastState.Bounded env26140 := by
  intro p hp
  have h : env26140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26139_26140 : H12AffineEnvironment.transform 9 273 env26139 = env26140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26139 == env26140) = true)

theorem identity26140 : scanCanonicalize (H12AffineFastState.compose env26140 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 2075) := by decide +kernel

theorem selectedBound26140 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env26141 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2065,348,2075,1,332,2065,2420,272,0,2129,33,17,3,349,65,2048,2059,2058,2415,95,32,257,33,2122,513]

theorem envBound26141 : H12AffineFastState.Bounded env26141 := by
  intro p hp
  have h : env26141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26140_26141 : H12AffineEnvironment.transform 13 2075 env26140 = env26141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2075 env26140 == env26141) = true)

theorem identity26141 : scanCanonicalize (H12AffineFastState.compose env26141 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26141 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env26142 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2065,40,2075,1,56,2065,2048,100,0,2129,33,17,3,41,65,2048,2059,2058,2075,95,32,117,33,2122,513]

theorem envBound26142 : H12AffineFastState.Bounded env26142 := by
  intro p hp
  have h : env26142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26141_26142 : H12AffineEnvironment.transform 7 116 env26141 = env26142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26141 == env26142) = true)

theorem identity26142 : scanCanonicalize (H12AffineFastState.compose env26142 (packedSelected [0,1,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound26142 : packedSelected [0,1,2,6] rootPS < 2^1333 := by decide +kernel

def env26143 : List Nat := [2,4,8,12,32,64,9,104,512,101,2048,2061,40,2055,1,36,2061,2048,100,0,2125,33,13,3,41,65,2048,2059,2058,2055,67,32,105,33,2122,513]

theorem envBound26143 : H12AffineFastState.Bounded env26143 := by
  intro p hp
  have h : env26143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26142_26143 : H12AffineEnvironment.transform 3 12 env26142 = env26143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env26142 == env26143) = true)

theorem identity26143 : scanCanonicalize (H12AffineFastState.compose env26143 (packedSelected [0,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound26143 : packedSelected [0,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26144 : List Nat := [2,4,8,12,32,10,9,34,512,47,2048,2061,40,2055,1,36,2061,2048,46,0,2055,33,13,3,41,11,2048,2059,2058,2055,9,32,35,33,2048,513]

theorem envBound26144 : H12AffineFastState.Bounded env26144 := by
  intro p hp
  have h : env26144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26143_26144 : H12AffineEnvironment.transform 5 10 env26143 = env26144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env26143 == env26144) = true)

theorem identity26144 : scanCanonicalize (H12AffineFastState.compose env26144 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound26144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26145 : List Nat := [2,4,8,12,32,10,9,34,40,47,2048,2061,40,2055,1,36,2061,2048,46,0,2055,33,13,3,41,11,2048,2059,2058,2055,9,32,35,33,2048,41]

theorem envBound26145 : H12AffineFastState.Bounded env26145 := by
  intro p hp
  have h : env26145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26144_26145 : H12AffineEnvironment.transform 8 40 env26144 = env26145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env26144 == env26145) = true)

theorem identity26145 : scanCanonicalize (H12AffineFastState.compose env26145 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26146 : List Nat := [2,3,8,11,32,10,9,34,40,40,2048,2058,40,2048,1,35,2058,2048,41,0,2048,33,10,3,41,11,2048,2059,2058,2048,9,32,35,33,2048,41]

theorem envBound26146 : H12AffineFastState.Bounded env26146 := by
  intro p hp
  have h : env26146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26145_26146 : H12AffineEnvironment.transform 1 3 env26145 = env26146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26145 == env26146) = true)

theorem identity26146 : scanCanonicalize (H12AffineFastState.compose env26146 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound26146 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26147 : List Nat := [2,3,8,11,32,10,9,34,40,40,10,0,40,10,1,35,0,10,41,0,10,33,10,3,41,11,10,1,0,10,9,32,35,33,10,41]

theorem envBound26147 : H12AffineFastState.Bounded env26147 := by
  intro p hp
  have h : env26147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26146_26147 : H12AffineEnvironment.transform 10 10 env26146 = env26147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env26146 == env26147) = true)

def env26148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374096,4294967296,525568,4308116845,27337993,25733062]

theorem envBound26148 : H12AffineFastState.Bounded env26148 := by
  intro p hp
  have h : env26148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21007_26148 : H12AffineEnvironment.transform 28 77616401 env21007 = env26148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env21007 == env26148) = true)

def env26149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound26149 : H12AffineFastState.Bounded env26149 := by
  intro p hp
  have h : env26149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26148_26149 : H12AffineEnvironment.transform 31 145662400 env26148 = env26149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env26148 == env26149) = true)

def env26150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound26150 : H12AffineFastState.Bounded env26150 := by
  intro p hp
  have h : env26150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26149_26150 : H12AffineEnvironment.transform 29 155254784 env26149 = env26150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env26149 == env26150) = true)

def env26151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound26151 : H12AffineFastState.Bounded env26151 := by
  intro p hp
  have h : env26151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26150_26151 : H12AffineEnvironment.transform 25 64 env26150 = env26151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env26150 == env26151) = true)

def env26152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound26152 : H12AffineFastState.Bounded env26152 := by
  intro p hp
  have h : env26152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26151_26152 : H12AffineEnvironment.transform 26 30393344 env26151 = env26152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env26151 == env26152) = true)

def env26153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound26153 : H12AffineFastState.Bounded env26153 := by
  intro p hp
  have h : env26153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26152_26153 : H12AffineEnvironment.transform 18 1024 env26152 = env26153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26152 == env26153) = true)

theorem identity26153 : scanCanonicalize (H12AffineFastState.compose env26153 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound26153 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,138,8328,64,13090954,2196487,10507601,8830976,8488090,6382922,256,10601511,10560899,8430412]

theorem envBound26154 : H12AffineFastState.Bounded env26154 := by
  intro p hp
  have h : env26154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26153_26154 : H12AffineEnvironment.transform 23 138 env26153 = env26154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env26153 == env26154) = true)

def env26155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,138,8328,64,4554754,2196487,2233817,295048,246802,6382922,256,2327727,2319627,189380]

theorem envBound26155 : H12AffineFastState.Bounded env26155 := by
  intro p hp
  have h : env26155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26154_26155 : H12AffineEnvironment.transform 22 147592 env26154 = env26155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env26154 == env26155) = true)

def env26156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,138,8328,64,4450482,2196487,2233817,190520,246802,6382922,256,2327727,2319627,189380]

theorem envBound26156 : H12AffineFastState.Bounded env26156 := by
  intro p hp
  have h : env26156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26155_26156 : H12AffineEnvironment.transform 17 157872 env26155 = env26156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env26155 == env26156) = true)

theorem identity26156 : scanCanonicalize (H12AffineFastState.compose env26156 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound26156 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10280,1024,32769,2097152,4194304,16,138,8328,64,4302890,2196487,2118977,43168,99466,6382922,256,2212919,2172307,41820]

theorem envBound26157 : H12AffineFastState.Bounded env26157 := by
  intro p hp
  have h : env26157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26156_26157 : H12AffineEnvironment.transform 16 16536 env26156 = env26157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env26156 == env26157) = true)

def env26158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,16,2,8192,64,4302890,2196487,2118977,43048,99330,6382922,256,2212919,2172187,41820]

theorem envBound26158 : H12AffineFastState.Bounded env26158 := by
  intro p hp
  have h : env26158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26157_26158 : H12AffineEnvironment.transform 6 8 env26157 = env26158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26157 == env26158) = true)

theorem identity26158 : scanCanonicalize (H12AffineFastState.compose env26158 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 58729) := by decide +kernel

theorem selectedBound26158 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env26159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,58729,4194304,16,2,8192,64,4302890,90478,45096,43048,99330,4292643,256,74078,114802,41820]

theorem envBound26159 : H12AffineFastState.Bounded env26159 := by
  intro p hp
  have h : env26159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26158_26159 : H12AffineEnvironment.transform 20 58729 env26158 = env26159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58729 env26158 == env26159) = true)

theorem identity26159 : scanCanonicalize (H12AffineFastState.compose env26159 (packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26159 : packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env26160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,58729,4194304,16,2,8192,64,4229152,16740,45096,43048,41992,4235305,256,340,57464,41820]

theorem envBound26160 : H12AffineFastState.Bounded env26160 := by
  intro p hp
  have h : env26160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26159_26160 : H12AffineEnvironment.transform 15 8202 env26159 = env26160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26159 == env26160) = true)

theorem identity26160 : scanCanonicalize (H12AffineFastState.compose env26160 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41048) := by decide +kernel

theorem selectedBound26160 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env26161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,58729,41048,16,2,8192,64,10360,16740,45096,43048,41992,113,256,340,57464,41820]

theorem envBound26161 : H12AffineFastState.Bounded env26161 := by
  intro p hp
  have h : env26161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26160_26161 : H12AffineEnvironment.transform 21 41048 env26160 = env26161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41048 env26160 == env26161) = true)

theorem identity26161 : scanCanonicalize (H12AffineFastState.compose env26161 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound26161 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8312,8202,16400,10280,1024,8313,17681,32,16,2,8192,64,10360,16740,4176,2128,1136,113,256,340,16384,804]

theorem envBound26162 : H12AffineFastState.Bounded env26162 := by
  intro p hp
  have h : env26162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26161_26162 : H12AffineEnvironment.transform 14 8312 env26161 = env26162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env26161 == env26162) = true)

theorem identity26162 : scanCanonicalize (H12AffineFastState.compose env26162 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound26162 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,81,35,16400,2049,1024,80,17681,32,16,2,41,64,2129,16740,4176,2128,1136,113,256,340,16384,804]

theorem envBound26163 : H12AffineFastState.Bounded env26163 := by
  intro p hp
  have h : env26163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26162_26163 : H12AffineEnvironment.transform 12 41 env26162 = env26163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env26162 == env26163) = true)

theorem identity26163 : scanCanonicalize (H12AffineFastState.compose env26163 (packedSelected [0,3,5,6,7,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26163 : packedSelected [0,3,5,6,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26164 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,81,35,16400,2049,1024,80,17509,32,16,2,41,64,2129,16400,4176,2128,1136,113,116,32,16384,592]

theorem envBound26164 : H12AffineFastState.Bounded env26164 := by
  intro p hp
  have h : env26164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26163_26164 : H12AffineEnvironment.transform 7 116 env26163 = env26164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26163 == env26164) = true)

theorem identity26164 : scanCanonicalize (H12AffineFastState.compose env26164 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26164 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env26165 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,16384,1,35,16400,2049,1024,0,17461,32,16,2,41,16,2049,16400,4096,2048,1056,33,36,32,16384,512]

theorem envBound26165 : H12AffineFastState.Bounded env26165 := by
  intro p hp
  have h : env26165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26164_26165 : H12AffineEnvironment.transform 5 16 env26164 = env26165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26164 == env26165) = true)

theorem identity26165 : scanCanonicalize (H12AffineFastState.compose env26165 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26165 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26166 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,16384,1,3,16400,2049,1024,0,17429,0,16,2,9,16,2049,16400,4096,2048,1024,1,4,0,16384,512]

theorem envBound26166 : H12AffineFastState.Bounded env26166 := by
  intro p hp
  have h : env26166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26165_26166 : H12AffineEnvironment.transform 4 0 env26165 = env26166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26165 == env26166) = true)

theorem identity26166 : scanCanonicalize (H12AffineFastState.compose env26166 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound26166 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26167 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5125,1,3,5141,2049,1024,0,4112,0,16,2,9,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound26167 : H12AffineFastState.Bounded env26167 := by
  intro p hp
  have h : env26167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26166_26167 : H12AffineEnvironment.transform 13 5125 env26166 = env26167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env26166 == env26167) = true)

def env26168 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1045,1,3,1029,2049,1024,0,0,0,16,2,9,16,2049,1029,16,2048,1024,1,4,0,1045,512]

theorem envBound26168 : H12AffineFastState.Bounded env26168 := by
  intro p hp
  have h : env26168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26167_26168 : H12AffineEnvironment.transform 11 16 env26167 = env26168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26167 == env26168) = true)

theorem identity26168 : scanCanonicalize (H12AffineFastState.compose env26168 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26169 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,9,1045,1,3,1029,1,1024,0,0,0,16,2,9,16,1,1029,16,0,1024,1,4,0,1045,512]

theorem envBound26169 : H12AffineFastState.Bounded env26169 := by
  intro p hp
  have h : env26169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26168_26169 : H12AffineEnvironment.transform 10 0 env26168 = env26169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26168 == env26169) = true)

def env26170 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,1,1,3,17,1,20,0,0,0,16,2,9,16,1,17,16,0,20,1,4,0,1,512]

theorem envBound26170 : H12AffineFastState.Bounded env26170 := by
  intro p hp
  have h : env26170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26169_26170 : H12AffineEnvironment.transform 9 20 env26169 = env26170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26169 == env26170) = true)

theorem identity26170 : scanCanonicalize (H12AffineFastState.compose env26170 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound26170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26171 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,9,1,1,3,17,1,20,0,0,0,16,2,9,16,1,17,16,0,20,1,4,0,1,31]

theorem envBound26171 : H12AffineFastState.Bounded env26171 := by
  intro p hp
  have h : env26171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26170_26171 : H12AffineEnvironment.transform 8 31 env26170 = env26171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env26170 == env26171) = true)

def leafEnv26171 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,9,1,1,3,17,1,20,0,0,0,16,2,20,9,1,16,1,17,16,0,20,1,4,0,4,3,1,31,1,0,0]

def active26171 : List Nat := [0,1,2,3]

def tree26171 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26171 : H12WitnessSearch.Good tree26171 := H12GlobalWitnessIndex.good

theorem leafIdentity26171 : H12AffineFastState.composeSystem env26171 rootObs = leafEnv26171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26171 rootObs == leafEnv26171) = true)

theorem terminalChecked26171 : H12PackedTerminal.terminalCheckFast leafEnv26171 active26171 tree26171 = true := by decide +kernel

def env26172 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,9,0,1,3,16,1,21,0,0,0,16,2,9,16,1,16,16,0,21,1,4,0,0,512]

theorem envBound26172 : H12AffineFastState.Bounded env26172 := by
  intro p hp
  have h : env26172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26169_26172 : H12AffineEnvironment.transform 9 21 env26169 = env26172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26169 == env26172) = true)

theorem identity26172 : scanCanonicalize (H12AffineFastState.compose env26172 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26173 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,1,3,5,1,0,0,0,0,5,2,9,5,1,5,5,0,0,1,4,0,0,512]

theorem envBound26173 : H12AffineFastState.Bounded env26173 := by
  intro p hp
  have h : env26173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26172_26173 : H12AffineEnvironment.transform 3 5 env26172 = env26173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26172 == env26173) = true)

def leafEnv26173 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,1,3,5,1,0,0,0,0,5,2,0,9,1,5,1,5,5,0,0,1,4,0,4,3,0,512,1,0,0]

def active26173 : List Nat := [0,1,2,8]

def tree26173 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26173 : H12WitnessSearch.Good tree26173 := H12GlobalWitnessIndex.good

theorem leafIdentity26173 : H12AffineFastState.composeSystem env26173 rootObs = leafEnv26173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26173 rootObs == leafEnv26173) = true)

theorem terminalChecked26173 : H12PackedTerminal.terminalCheckFast leafEnv26173 active26173 tree26173 = true := by decide +kernel

def env26174 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1044,1,3,1028,2049,1024,0,1,0,16,2,9,16,2049,1028,17,2048,1024,1,4,0,1044,512]

theorem envBound26174 : H12AffineFastState.Bounded env26174 := by
  intro p hp
  have h : env26174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26167_26174 : H12AffineEnvironment.transform 11 17 env26167 = env26174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26167 == env26174) = true)

theorem identity26174 : scanCanonicalize (H12AffineFastState.compose env26174 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound26174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26175 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,17,9,1044,1,3,1028,1045,1024,0,1,0,16,2,9,16,1045,1028,17,1044,1024,1,4,0,1044,512]

theorem envBound26175 : H12AffineFastState.Bounded env26175 := by
  intro p hp
  have h : env26175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26174_26175 : H12AffineEnvironment.transform 10 1044 env26174 = env26175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env26174 == env26175) = true)

def env26176 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,9,0,1,3,16,1,20,0,1,0,16,2,9,16,1,16,17,0,20,1,4,0,0,512]

theorem envBound26176 : H12AffineFastState.Bounded env26176 := by
  intro p hp
  have h : env26176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26175_26176 : H12AffineEnvironment.transform 9 20 env26175 = env26176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26175 == env26176) = true)

theorem identity26176 : scanCanonicalize (H12AffineFastState.compose env26176 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound26176 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26177 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,17,9,0,1,3,16,1,20,0,1,0,16,2,9,16,1,16,17,0,20,1,4,0,0,31]

theorem envBound26177 : H12AffineFastState.Bounded env26177 := by
  intro p hp
  have h : env26177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26176_26177 : H12AffineEnvironment.transform 8 31 env26176 = env26177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env26176 == env26177) = true)

def leafEnv26177 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,17,9,0,1,3,16,1,20,0,1,0,16,2,20,9,1,16,1,16,17,0,20,1,4,0,4,3,0,31,1,1,0]

def active26177 : List Nat := [0,1,2,3]

def tree26177 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26177 : H12WitnessSearch.Good tree26177 := H12GlobalWitnessIndex.good

theorem leafIdentity26177 : H12AffineFastState.composeSystem env26177 rootObs = leafEnv26177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26177 rootObs == leafEnv26177) = true)

theorem terminalChecked26177 : H12PackedTerminal.terminalCheckFast leafEnv26177 active26177 tree26177 = true := by decide +kernel

def env26178 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,9,1,1,3,17,0,21,0,1,0,16,2,9,16,0,17,17,1,21,1,4,0,1,512]

theorem envBound26178 : H12AffineFastState.Bounded env26178 := by
  intro p hp
  have h : env26178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26175_26178 : H12AffineEnvironment.transform 9 21 env26175 = env26178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26175 == env26178) = true)

theorem identity26178 : scanCanonicalize (H12AffineFastState.compose env26178 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26178 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26179 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,9,1,1,3,4,0,0,0,1,0,5,2,9,5,0,4,4,1,0,1,4,0,1,512]

theorem envBound26179 : H12AffineFastState.Bounded env26179 := by
  intro p hp
  have h : env26179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26178_26179 : H12AffineEnvironment.transform 3 5 env26178 = env26179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26178 == env26179) = true)

def leafEnv26179 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,9,1,1,3,4,0,0,0,1,0,5,2,0,9,1,5,0,4,4,1,0,1,4,0,4,3,1,512,1,1,0]

def active26179 : List Nat := [0,1,2,8]

def tree26179 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26179 : H12WitnessSearch.Good tree26179 := H12GlobalWitnessIndex.good

theorem leafIdentity26179 : H12AffineFastState.composeSystem env26179 rootObs = leafEnv26179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26179 rootObs == leafEnv26179) = true)

theorem terminalChecked26179 : H12PackedTerminal.terminalCheckFast leafEnv26179 active26179 tree26179 = true := by decide +kernel

def env26180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,16,3,8193,64,4302890,2196487,2118977,43049,99331,6382922,256,2212919,2172186,41820]

theorem envBound26180 : H12AffineFastState.Bounded env26180 := by
  intro p hp
  have h : env26180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26157_26180 : H12AffineEnvironment.transform 6 9 env26157 = env26180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26157 == env26180) = true)

theorem identity26180 : scanCanonicalize (H12AffineFastState.compose env26180 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26180 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,2097152,4194304,16,3,8193,64,4262263,2172250,2118977,2420,75102,6382922,256,2188650,2172186,513]

theorem envBound26181 : H12AffineFastState.Bounded env26181 := by
  intro p hp
  have h : env26181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26180_26181 : H12AffineEnvironment.transform 14 8541 env26180 = env26181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26180 == env26181) = true)

theorem identity26181 : scanCanonicalize (H12AffineFastState.compose env26181 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound26181 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,91467,4194304,16,3,8193,64,4262263,16401,77834,2420,75102,4194305,256,33,16465,513]

theorem envBound26182 : H12AffineFastState.Bounded env26182 := by
  intro p hp
  have h : env26182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26181_26182 : H12AffineEnvironment.transform 20 91467 env26181 = env26182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env26181 == env26182) = true)

theorem identity26182 : scanCanonicalize (H12AffineFastState.compose env26182 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26182 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,65536,16401,2421,1024,1,82966,4194304,16,3,348,64,4262263,16401,69975,2420,66563,4194305,256,33,16465,513]

theorem envBound26183 : H12AffineFastState.Bounded env26183 := by
  intro p hp
  have h : env26183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26182_26183 : H12AffineEnvironment.transform 12 349 env26182 = env26183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26182 == env26183) = true)

theorem identity26183 : scanCanonicalize (H12AffineFastState.compose env26183 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound26183 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,343,16401,2421,1024,1,17729,4194304,16,3,348,64,4196384,16401,4096,2420,1364,4194305,256,33,16465,513]

theorem envBound26184 : H12AffineFastState.Bounded env26184 := by
  intro p hp
  have h : env26184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26183_26184 : H12AffineEnvironment.transform 15 343 env26183 = env26184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env26183 == env26184) = true)

theorem identity26184 : scanCanonicalize (H12AffineFastState.compose env26184 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26184 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26185 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1024,1,17681,4194304,16,3,268,16,4196384,16401,4096,2340,1284,4194305,256,33,16385,513]

theorem envBound26185 : H12AffineFastState.Bounded env26185 := by
  intro p hp
  have h : env26185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26184_26185 : H12AffineEnvironment.transform 5 16 env26184 = env26185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26184 == env26185) = true)

theorem identity26185 : scanCanonicalize (H12AffineFastState.compose env26185 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound26185 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26186 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,0,263,5173,2341,1024,1,4405,4194304,16,3,268,16,4196384,5173,4096,2340,1284,4194305,256,33,5157,513]

theorem envBound26186 : H12AffineFastState.Bounded env26186 := by
  intro p hp
  have h : env26186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26185_26186 : H12AffineEnvironment.transform 13 5156 env26185 = env26186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env26185 == env26186) = true)

theorem identity26186 : scanCanonicalize (H12AffineFastState.compose env26186 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound26186 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26187 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,0,263,5173,2341,1024,1,4405,33,16,3,268,16,2049,5173,4096,2340,1284,32,256,33,5157,513]

theorem envBound26187 : H12AffineFastState.Bounded env26187 := by
  intro p hp
  have h : env26187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26186_26187 : H12AffineEnvironment.transform 21 33 env26186 = env26187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26186 == env26187) = true)

theorem identity26187 : scanCanonicalize (H12AffineFastState.compose env26187 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26188 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5173,2048,1024,1,4112,33,16,3,41,16,2049,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound26188 : H12AffineFastState.Bounded env26188 := by
  intro p hp
  have h : env26188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26187_26188 : H12AffineEnvironment.transform 7 37 env26187 = env26188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26187 == env26188) = true)

theorem identity26188 : scanCanonicalize (H12AffineFastState.compose env26188 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26188 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26189 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,0,34,4096,2048,53,1,4112,33,16,3,41,16,2049,4096,4096,2049,20,32,37,33,4112,513]

theorem envBound26189 : H12AffineFastState.Bounded env26189 := by
  intro p hp
  have h : env26189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26188_26189 : H12AffineEnvironment.transform 9 53 env26188 = env26189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26188 == env26189) = true)

theorem identity26189 : scanCanonicalize (H12AffineFastState.compose env26189 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound26189 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26190 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,32,40,49,0,34,32,2048,53,1,48,33,16,3,41,16,2049,32,32,2049,20,32,37,33,48,513]

theorem envBound26190 : H12AffineFastState.Bounded env26190 := by
  intro p hp
  have h : env26190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26189_26190 : H12AffineEnvironment.transform 11 32 env26189 = env26190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env26189 == env26190) = true)

theorem identity26190 : scanCanonicalize (H12AffineFastState.compose env26190 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26191 : List Nat := [2,4,8,16,32,16,9,37,512,53,0,32,40,49,0,34,32,0,53,1,48,33,16,3,41,16,1,32,32,1,20,32,37,33,48,513]

theorem envBound26191 : H12AffineFastState.Bounded env26191 := by
  intro p hp
  have h : env26191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26190_26191 : H12AffineEnvironment.transform 10 0 env26190 = env26191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26190 == env26191) = true)

theorem identity26191 : scanCanonicalize (H12AffineFastState.compose env26191 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26191 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26192 : List Nat := [2,4,8,16,17,16,9,20,512,4,0,17,25,0,0,19,17,0,4,1,1,16,16,3,24,16,1,17,17,1,20,17,20,16,1,513]

theorem envBound26192 : H12AffineFastState.Bounded env26192 := by
  intro p hp
  have h : env26192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26191_26192 : H12AffineEnvironment.transform 4 17 env26191 = env26192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26191 == env26192) = true)

def env26193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,138,8328,64,4450483,2196487,2233817,190521,246802,6382922,256,2327727,2319627,189380]

theorem envBound26193 : H12AffineFastState.Bounded env26193 := by
  intro p hp
  have h : env26193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26155_26193 : H12AffineEnvironment.transform 17 157873 env26155 = env26193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env26155 == env26193) = true)

def env26194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450363,2196487,2233681,190521,246802,6382922,256,2327591,2319627,189260]

theorem envBound26194 : H12AffineFastState.Bounded env26194 := by
  intro p hp
  have h : env26194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26193_26194 : H12AffineEnvironment.transform 6 8 env26193 = env26194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26193 == env26194) = true)

theorem identity26194 : scanCanonicalize (H12AffineFastState.compose env26194 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound26194 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env26195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1024,32769,2097152,4194304,73755,2,8192,64,4229152,2196487,2192714,100386,41993,6382922,256,2155580,2098448,99159]

theorem envBound26195 : H12AffineFastState.Bounded env26195 := by
  intro p hp
  have h : env26195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26194_26195 : H12AffineEnvironment.transform 16 90139 env26194 = env26195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env26194 == env26195) = true)

theorem identity26195 : scanCanonicalize (H12AffineFastState.compose env26195 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound26195 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env26196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1024,32769,2097152,73770,73755,2,8192,64,108554,2196487,2192714,100386,41993,2114912,256,2155580,2098448,99159]

theorem envBound26196 : H12AffineFastState.Bounded env26196 := by
  intro p hp
  have h : env26196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26195_26196 : H12AffineEnvironment.transform 21 73770 env26195 = env26196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env26195 == env26196) = true)

theorem identity26196 : scanCanonicalize (H12AffineFastState.compose env26196 (packedSelected [0,1,3,9,16,20,22,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 83015) := by decide +kernel

theorem selectedBound26196 : packedSelected [0,1,3,9,16,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env26197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1024,32769,83015,73770,73755,2,8192,64,108554,49216,12557,100386,41993,65831,256,106619,82263,99159]

theorem envBound26197 : H12AffineFastState.Bounded env26197 := by
  intro p hp
  have h : env26197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26196_26197 : H12AffineEnvironment.transform 20 83015 env26196 = env26197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83015 env26196 == env26197) = true)

theorem identity26197 : scanCanonicalize (H12AffineFastState.compose env26197 (packedSelected [1,2,3,4,6,8,11,12,14,15,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound26197 : packedSelected [1,2,3,4,6,8,11,12,14,15,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env26198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,65536,90139,67618,1024,81,83015,73770,73755,2,8192,64,75866,16400,12557,67698,9305,65831,256,73771,82263,66311]

theorem envBound26198 : H12AffineFastState.Bounded env26198 := by
  intro p hp
  have h : env26198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26197_26198 : H12AffineEnvironment.transform 14 80 env26197 = env26198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env26197 == env26198) = true)

theorem identity26198 : scanCanonicalize (H12AffineFastState.compose env26198 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26198 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env26199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,80,65536,82198,67618,1024,81,83015,65831,65814,2,269,64,67927,16400,4096,67698,1364,65831,256,65830,82263,66311]

theorem envBound26199 : H12AffineFastState.Bounded env26199 := by
  intro p hp
  have h : env26199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26198_26199 : H12AffineEnvironment.transform 12 269 env26198 = env26199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26198 == env26199) = true)

theorem identity26199 : scanCanonicalize (H12AffineFastState.compose env26199 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound26199 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,80,65536,71011,67618,1024,81,69682,65831,65814,2,269,64,67927,5221,4096,67698,1364,65831,256,65830,70946,66311]

theorem envBound26200 : H12AffineFastState.Bounded env26200 := by
  intro p hp
  have h : env26200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26199_26200 : H12AffineEnvironment.transform 13 5237 env26199 = env26200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env26199 == env26200) = true)

theorem identity26200 : scanCanonicalize (H12AffineFastState.compose env26200 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound26200 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env26201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,80,263,5220,2341,1024,81,4405,32,17,2,269,64,2128,5221,4096,2421,1364,32,256,33,5157,512]

theorem envBound26201 : H12AffineFastState.Bounded env26201 := by
  intro p hp
  have h : env26201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26200_26201 : H12AffineEnvironment.transform 15 263 env26200 = env26201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env26200 == env26201) = true)

theorem identity26201 : scanCanonicalize (H12AffineFastState.compose env26201 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound26201 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,814,4096,269,5237,80,263,5220,523,1024,81,4405,32,17,2,269,64,894,5221,4096,603,1364,32,256,33,5157,512]

theorem envBound26202 : H12AffineFastState.Bounded env26202 := by
  intro p hp
  have h : env26202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26201_26202 : H12AffineEnvironment.transform 10 814 env26201 = env26202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env26201 == env26202) = true)

theorem identity26202 : scanCanonicalize (H12AffineFastState.compose env26202 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound26202 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26203 : List Nat := [2,4,8,16,32,64,8,85,512,1024,635,4096,88,5237,80,82,5220,523,1024,81,4192,32,17,2,88,64,555,5221,4096,603,1025,32,85,33,5157,512]

theorem envBound26203 : H12AffineFastState.Bounded env26203 := by
  intro p hp
  have h : env26203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26202_26203 : H12AffineEnvironment.transform 7 85 env26202 = env26203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env26202 == env26203) = true)

theorem identity26203 : scanCanonicalize (H12AffineFastState.compose env26203 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26203 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26204 : List Nat := [2,4,8,16,1,64,8,85,512,1024,602,4096,88,5204,80,82,5189,523,1024,81,4161,1,17,2,88,64,522,5188,4096,603,1025,1,85,0,5124,512]

theorem envBound26204 : H12AffineFastState.Bounded env26204 := by
  intro p hp
  have h : env26204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26203_26204 : H12AffineEnvironment.transform 4 1 env26203 = env26204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26203 == env26204) = true)

theorem identity26204 : scanCanonicalize (H12AffineFastState.compose env26204 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26204 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26205 : List Nat := [2,4,8,16,1,16,8,5,512,1024,522,4096,8,5124,0,2,5141,523,1024,1,4113,1,17,2,8,16,522,5140,4096,523,1025,1,5,0,5124,512]

theorem envBound26205 : H12AffineFastState.Bounded env26205 := by
  intro p hp
  have h : env26205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26204_26205 : H12AffineEnvironment.transform 5 16 env26204 = env26205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26204 == env26205) = true)

theorem identity26205 : scanCanonicalize (H12AffineFastState.compose env26205 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound26205 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26206 : List Nat := [2,4,8,16,1,16,8,5,512,21,522,4096,8,4113,0,2,4096,523,21,1,4113,1,17,2,8,16,522,4097,4096,523,20,1,5,0,4113,512]

theorem envBound26206 : H12AffineFastState.Bounded env26206 := by
  intro p hp
  have h : env26206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26205_26206 : H12AffineEnvironment.transform 9 21 env26205 = env26206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26205 == env26206) = true)

theorem identity26206 : scanCanonicalize (H12AffineFastState.compose env26206 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 517) := by decide +kernel

theorem selectedBound26206 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26207 : List Nat := [2,4,8,16,1,16,8,5,512,21,522,517,8,532,0,2,517,523,21,1,532,1,17,2,8,16,522,516,517,523,20,1,5,0,532,512]

theorem envBound26207 : H12AffineFastState.Bounded env26207 := by
  intro p hp
  have h : env26207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26206_26207 : H12AffineEnvironment.transform 11 517 env26206 = env26207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 517 env26206 == env26207) = true)

theorem identity26207 : scanCanonicalize (H12AffineFastState.compose env26207 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound26207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26208 : List Nat := [2,4,8,16,1,16,8,5,18,21,24,23,8,6,0,2,23,25,21,1,6,1,17,2,8,16,24,22,23,25,20,1,5,0,6,18]

theorem envBound26208 : H12AffineFastState.Bounded env26208 := by
  intro p hp
  have h : env26208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26207_26208 : H12AffineEnvironment.transform 8 18 env26207 = env26208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env26207 == env26208) = true)

theorem identity26208 : scanCanonicalize (H12AffineFastState.compose env26208 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound26208 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26209 : List Nat := [2,4,8,15,1,15,8,5,13,10,7,8,8,6,0,2,8,6,10,1,6,1,14,2,8,15,7,9,8,6,11,1,5,0,6,13]

theorem envBound26209 : H12AffineFastState.Bounded env26209 := by
  intro p hp
  have h : env26209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26208_26209 : H12AffineEnvironment.transform 3 15 env26208 = env26209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env26208 == env26209) = true)

def env26210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,64,4450362,2196487,2233680,190521,246802,6382922,256,2327590,2319627,189261]

theorem envBound26210 : H12AffineFastState.Bounded env26210 := by
  intro p hp
  have h : env26210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26193_26210 : H12AffineEnvironment.transform 6 9 env26193 = env26210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26193 == env26210) = true)

theorem identity26210 : scanCanonicalize (H12AffineFastState.compose env26210 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound26210 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1024,32769,2097152,4194304,41293,3,8193,64,4262262,2196487,2159644,2421,75102,6382922,256,2188650,2196551,513]

theorem envBound26211 : H12AffineFastState.Bounded env26211 := by
  intro p hp
  have h : env26211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26210_26211 : H12AffineEnvironment.transform 16 57676 env26210 = env26211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env26210 == env26211) = true)

theorem identity26211 : scanCanonicalize (H12AffineFastState.compose env26211 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26211 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1024,32769,2097152,4194304,41293,3,8193,64,4229153,2098512,2159644,2421,41993,6349853,256,2155581,2098448,513]

theorem envBound26212 : H12AffineFastState.Bounded env26212 := by
  intro p hp
  have h : env26212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26211_26212 : H12AffineEnvironment.transform 15 33111 env26211 = env26212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26211 == env26212) = true)

theorem identity26212 : scanCanonicalize (H12AffineFastState.compose env26212 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound26212 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env26213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1024,32769,2097152,32,41293,3,8193,64,34817,2098512,2159644,2421,41993,2155581,256,2155581,2098448,513]

theorem envBound26213 : H12AffineFastState.Bounded env26213 := by
  intro p hp
  have h : env26213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26212_26213 : H12AffineEnvironment.transform 21 32 env26212 = env26213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26212 == env26213) = true)

theorem identity26213 : scanCanonicalize (H12AffineFastState.compose env26213 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26213 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,33111,49217,35188,1024,32769,2097152,32,32832,3,268,64,34817,2098512,2151697,2421,34052,2147632,256,2147632,2098448,513]

theorem envBound26214 : H12AffineFastState.Bounded env26214 := by
  intro p hp
  have h : env26214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26213_26214 : H12AffineEnvironment.transform 12 269 env26213 = env26214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26213 == env26214) = true)

theorem identity26214 : scanCanonicalize (H12AffineFastState.compose env26214 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound26214 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env26215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,32768,33111,37941,35188,1024,32769,2097152,32,32832,3,268,64,34817,2098512,2130277,2421,34052,2134340,256,2134340,2098448,513]

theorem envBound26215 : H12AffineFastState.Bounded env26215 := by
  intro p hp
  have h : env26215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26214_26215 : H12AffineEnvironment.transform 13 5236 env26214 = env26215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env26214 == env26215) = true)

theorem identity26215 : scanCanonicalize (H12AffineFastState.compose env26215 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26215 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env26216 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33031,37941,35108,1024,32769,2097152,32,32784,3,268,16,34817,2098432,2130229,2341,34052,2134292,256,2134292,2098448,513]

theorem envBound26216 : H12AffineFastState.Bounded env26216 := by
  intro p hp
  have h : env26216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26215_26216 : H12AffineEnvironment.transform 5 16 env26215 = env26216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26215 == env26216) = true)

theorem identity26216 : scanCanonicalize (H12AffineFastState.compose env26216 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(20+1) ^^^ 37172) := by decide +kernel

theorem selectedBound26216 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env26217 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33031,37941,35108,1024,32769,37172,32,32784,3,268,16,34817,37940,4097,2341,34052,32,256,32,37924,513]

theorem envBound26217 : H12AffineFastState.Bounded env26217 := by
  intro p hp
  have h : env26217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26216_26217 : H12AffineEnvironment.transform 20 37172 env26216 = env26217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37172 env26216 == env26217) = true)

theorem identity26217 : scanCanonicalize (H12AffineFastState.compose env26217 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound26217 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26218 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,1296,1047,4389,3124,1024,1297,5156,32,1280,3,268,16,3345,4388,4097,2341,20,32,256,32,4404,513]

theorem envBound26218 : H12AffineFastState.Bounded env26218 := by
  intro p hp
  have h : env26218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26217_26218 : H12AffineEnvironment.transform 14 1296 env26217 = env26218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env26217 == env26218) = true)

def env26219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,138,8328,64,4554755,2196487,2233816,295049,246803,6382922,256,2327726,2319626,189381]

theorem envBound26219 : H12AffineFastState.Bounded env26219 := by
  intro p hp
  have h : env26219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26154_26219 : H12AffineEnvironment.transform 22 147593 env26154 = env26219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env26154 == env26219) = true)

def env26220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,138,8328,64,4450483,2196487,2233816,190521,246803,6382922,256,2327726,2319626,189381]

theorem envBound26220 : H12AffineFastState.Bounded env26220 := by
  intro p hp
  have h : env26220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26219_26220 : H12AffineEnvironment.transform 17 157872 env26219 = env26220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env26219 == env26220) = true)

theorem identity26220 : scanCanonicalize (H12AffineFastState.compose env26220 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound26220 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,35188,1024,32769,2097152,4194304,41293,138,8328,64,4262263,2196487,2159644,2557,75223,6382922,256,2188650,2196686,513]

theorem envBound26221 : H12AffineFastState.Bounded env26221 := by
  intro p hp
  have h : env26221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26220_26221 : H12AffineEnvironment.transform 16 57796 env26220 = env26221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env26220 == env26221) = true)

theorem identity26221 : scanCanonicalize (H12AffineFastState.compose env26221 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound26221 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,57796,35188,1024,32769,2097152,4194304,41293,138,8328,64,4229288,2098648,2159644,2557,41992,6349973,256,2155701,2098449,513]

theorem envBound26222 : H12AffineFastState.Bounded env26222 := by
  intro p hp
  have h : env26222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26221_26222 : H12AffineEnvironment.transform 15 33247 env26221 = env26222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env26221 == env26222) = true)

def env26223 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,2097152,4194304,41245,138,8328,16,4229288,2098568,2159644,2477,41992,6349973,256,2155701,2098449,513]

theorem envBound26223 : H12AffineFastState.Bounded env26223 := by
  intro p hp
  have h : env26223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26222_26223 : H12AffineEnvironment.transform 5 16 env26222 = env26223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26222 == env26223) = true)

theorem identity26223 : scanCanonicalize (H12AffineFastState.compose env26223 (packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound26223 : packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env26224 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,2097152,41261,41245,138,8328,16,10629,2098568,2159644,2477,41992,2115000,256,2155701,2098449,513]

theorem envBound26224 : H12AffineFastState.Bounded env26224 := by
  intro p hp
  have h : env26224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26223_26224 : H12AffineEnvironment.transform 21 41261 env26223 = env26224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env26223 == env26224) = true)

theorem identity26224 : scanCanonicalize (H12AffineFastState.compose env26224 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound26224 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26225 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,57748,35108,1024,32769,58397,41261,41245,138,8328,16,10629,57749,4097,2477,41992,41381,256,168,57612,513]

theorem envBound26225 : H12AffineFastState.Bounded env26225 := by
  intro p hp
  have h : env26225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26224_26225 : H12AffineEnvironment.transform 20 58397 env26224 = env26225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env26224 == env26225) = true)

theorem identity26225 : scanCanonicalize (H12AffineFastState.compose env26225 (packedSelected [1,4,5,8,9,14,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound26225 : packedSelected [1,4,5,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env26226 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,32768,33167,49168,35108,1024,32769,50585,32937,32921,138,268,16,2049,49169,4097,2477,34188,32801,256,168,49288,513]

theorem envBound26226 : H12AffineFastState.Bounded env26226 := by
  intro p hp
  have h : env26226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26225_26226 : H12AffineEnvironment.transform 12 388 env26225 = env26226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env26225 == env26226) = true)

theorem identity26226 : scanCanonicalize (H12AffineFastState.compose env26226 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound26226 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env26227 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,0,399,16400,2340,1024,1,17817,169,153,138,268,16,2049,16401,4097,2477,1420,33,256,168,16520,513]

theorem envBound26227 : H12AffineFastState.Bounded env26227 := by
  intro p hp
  have h : env26227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26226_26227 : H12AffineEnvironment.transform 14 0 env26226 = env26227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env26226 == env26227) = true)

theorem identity26227 : scanCanonicalize (H12AffineFastState.compose env26227 (packedSelected [5,7,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 7340) := by decide +kernel

theorem selectedBound26227 : packedSelected [5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26228 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,7340,0,399,7356,2340,1024,1,6453,169,153,138,268,16,2049,7357,4097,2477,1420,33,256,168,7204,513]

theorem envBound26228 : H12AffineFastState.Bounded env26228 := by
  intro p hp
  have h : env26228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26227_26228 : H12AffineEnvironment.transform 13 7340 env26227 = env26228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7340 env26227 == env26228) = true)

theorem identity26228 : scanCanonicalize (H12AffineFastState.compose env26228 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound26228 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26229 : List Nat := [2,4,8,16,32,16,128,256,512,1024,429,4096,388,5377,0,399,5393,137,1024,1,4248,169,153,138,268,16,428,5392,4097,0,1420,33,256,168,5513,513]

theorem envBound26229 : H12AffineFastState.Bounded env26229 := by
  intro p hp
  have h : env26229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26228_26229 : H12AffineEnvironment.transform 10 429 env26228 = env26229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env26228 == env26229) = true)

theorem identity26229 : scanCanonicalize (H12AffineFastState.compose env26229 (packedSelected [0,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound26229 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env26230 : List Nat := [2,4,8,16,32,16,128,256,512,1024,429,309,388,1076,0,399,1060,137,1024,1,429,169,153,138,268,16,428,1061,308,0,1420,33,256,168,1212,513]

theorem envBound26230 : H12AffineFastState.Bounded env26230 := by
  intro p hp
  have h : env26230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26229_26230 : H12AffineEnvironment.transform 11 309 env26229 = env26230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env26229 == env26230) = true)

theorem identity26230 : scanCanonicalize (H12AffineFastState.compose env26230 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26230 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env26231 : List Nat := [2,4,8,16,32,16,128,256,512,52,429,309,388,0,0,399,16,137,52,1,429,169,153,138,268,16,428,17,308,0,440,33,256,168,136,513]

theorem envBound26231 : H12AffineFastState.Bounded env26231 := by
  intro p hp
  have h : env26231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26230_26231 : H12AffineEnvironment.transform 9 52 env26230 = env26231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26230 == env26231) = true)

theorem identity26231 : scanCanonicalize (H12AffineFastState.compose env26231 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26231 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env26232 : List Nat := [2,4,8,16,32,16,8,256,512,52,293,309,268,0,0,263,16,1,52,1,293,33,17,2,268,16,292,17,308,0,304,33,256,32,0,513]

theorem envBound26232 : H12AffineFastState.Bounded env26232 := by
  intro p hp
  have h : env26232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26231_26232 : H12AffineEnvironment.transform 6 8 env26231 = env26232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26231 == env26232) = true)

theorem identity26232 : scanCanonicalize (H12AffineFastState.compose env26232 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26233 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,40,0,0,35,16,1,52,1,1,33,17,2,40,16,0,17,16,0,20,33,36,32,0,513]

theorem envBound26233 : H12AffineFastState.Bounded env26233 := by
  intro p hp
  have h : env26233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26232_26233 : H12AffineEnvironment.transform 7 36 env26232 = env26233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26232 == env26233) = true)

theorem identity26233 : scanCanonicalize (H12AffineFastState.compose env26233 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound26233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26234 : List Nat := [2,4,8,16,32,16,8,36,33,52,1,17,40,0,0,35,16,1,52,1,1,33,17,2,40,16,0,17,16,0,20,33,36,32,0,32]

theorem envBound26234 : H12AffineFastState.Bounded env26234 := by
  intro p hp
  have h : env26234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26233_26234 : H12AffineEnvironment.transform 8 33 env26233 = env26234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env26233 == env26234) = true)

theorem identity26234 : scanCanonicalize (H12AffineFastState.compose env26234 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26235 : List Nat := [2,4,8,16,17,16,8,21,16,5,1,17,25,0,0,18,16,1,5,1,1,16,17,2,25,16,0,17,16,0,20,16,21,17,0,17]

theorem envBound26235 : H12AffineFastState.Bounded env26235 := by
  intro p hp
  have h : env26235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26234_26235 : H12AffineEnvironment.transform 4 17 env26234 = env26235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26234 == env26235) = true)

def env26236 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,2097152,4194304,41244,138,8328,17,4229288,2098569,2159644,2476,41992,6349973,256,2155701,2098449,513]

theorem envBound26236 : H12AffineFastState.Bounded env26236 := by
  intro p hp
  have h : env26236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26222_26236 : H12AffineEnvironment.transform 5 17 env26222 = env26236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26222 == env26236) = true)

def env26237 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,36624,4194304,41244,138,8328,17,4229288,35481,31500,2476,41992,4221829,256,27557,35329,513]

theorem envBound26237 : H12AffineFastState.Bounded env26237 := by
  intro p hp
  have h : env26237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26236_26237 : H12AffineEnvironment.transform 20 36624 env26236 = env26237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36624 env26236 == env26237) = true)

theorem identity26237 : scanCanonicalize (H12AffineFastState.compose env26237 (packedSelected [2,3,4,6,8,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 54788) := by decide +kernel

theorem selectedBound26237 : packedSelected [2,3,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26238 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,36624,54788,41244,138,8328,17,24236,35481,31500,2476,41992,48513,256,27557,35329,513]

theorem envBound26238 : H12AffineFastState.Bounded env26238 := by
  intro p hp
  have h : env26238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26237_26238 : H12AffineEnvironment.transform 21 54788 env26237 = env26238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54788 env26237 == env26238) = true)

def env26239 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33030,57629,35109,1024,32769,36624,54788,41244,2,8192,17,24100,35345,31500,2340,41992,48393,256,27437,35329,513]

theorem envBound26239 : H12AffineFastState.Bounded env26239 := by
  intro p hp
  have h : env26239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26238_26239 : H12AffineEnvironment.transform 6 8 env26238 = env26239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26238 == env26239) = true)

theorem identity26239 : scanCanonicalize (H12AffineFastState.compose env26239 (packedSelected [0,1,7,8,10,12,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 15657) := by decide +kernel

theorem selectedBound26239 : packedSelected [0,1,7,8,10,12,14,17,18] rootPS < 2^1333 := by decide +kernel

def env26240 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,15657,15407,23604,13324,1024,15656,12857,27437,7221,2,8192,17,24100,14136,31500,2340,6433,32,256,27437,14120,513]

theorem envBound26240 : H12AffineFastState.Bounded env26240 := by
  intro p hp
  have h : env26240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26239_26240 : H12AffineEnvironment.transform 14 15657 env26239 = env26240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15657 env26239 == env26240) = true)

theorem identity26240 : scanCanonicalize (H12AffineFastState.compose env26240 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 11020) := by decide +kernel

theorem selectedBound26240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26241 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,11020,15657,15407,14136,13324,1024,15656,12857,33,7221,2,8192,17,13608,14136,4096,2340,6433,32,256,33,14120,513]

theorem envBound26241 : H12AffineFastState.Bounded env26241 := by
  intro p hp
  have h : env26241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26240_26241 : H12AffineEnvironment.transform 13 11020 env26240 = env26241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11020 env26240 == env26241) = true)

theorem identity26241 : scanCanonicalize (H12AffineFastState.compose env26241 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound26241 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26242 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,4096,8192,11020,15132,14874,12557,12857,565,15133,12857,33,6656,2,8192,17,13085,12557,4096,2340,6433,32,256,33,12573,513]

theorem envBound26242 : H12AffineFastState.Bounded env26242 := by
  intro p hp
  have h : env26242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26241_26242 : H12AffineEnvironment.transform 9 565 env26241 = env26242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env26241 == env26242) = true)

theorem identity26242 : scanCanonicalize (H12AffineFastState.compose env26242 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26242 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env26243 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,4096,268,2560,6672,6934,4097,4917,565,6673,4917,33,6656,2,268,17,4625,4097,4096,2340,6433,32,256,33,4113,513]

theorem envBound26243 : H12AffineFastState.Bounded env26243 := by
  intro p hp
  have h : env26243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26242_26243 : H12AffineEnvironment.transform 12 268 env26242 = env26243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26242 == env26243) = true)

theorem identity26243 : scanCanonicalize (H12AffineFastState.compose env26243 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26243 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26244 : List Nat := [2,4,8,16,32,17,8,256,1,52,2048,4096,268,2049,6161,6423,4097,4404,52,6160,4404,33,6145,2,268,17,4112,4097,4096,2340,6433,32,256,33,4113,0]

theorem envBound26244 : H12AffineFastState.Bounded env26244 := by
  intro p hp
  have h : env26244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26243_26244 : H12AffineEnvironment.transform 8 1 env26243 = env26244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26243 == env26244) = true)

theorem identity26244 : scanCanonicalize (H12AffineFastState.compose env26244 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound26244 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26245 : List Nat := [2,4,8,16,32,17,8,256,1,52,2048,2064,268,2049,1,263,2065,2340,52,0,2340,33,17,2,268,17,2048,2065,2064,2340,305,32,256,33,2049,0]

theorem envBound26245 : H12AffineFastState.Bounded env26245 := by
  intro p hp
  have h : env26245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26244_26245 : H12AffineEnvironment.transform 11 2064 env26244 = env26245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env26244 == env26245) = true)

theorem identity26245 : scanCanonicalize (H12AffineFastState.compose env26245 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26245 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26246 : List Nat := [2,4,8,16,32,17,8,4,1,52,2048,2064,8,2049,1,3,2065,2080,52,0,2080,33,17,2,8,17,2048,2065,2064,2080,53,32,4,33,2049,0]

theorem envBound26246 : H12AffineFastState.Bounded env26246 := by
  intro p hp
  have h : env26246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26245_26246 : H12AffineEnvironment.transform 7 4 env26245 = env26246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26245 == env26246) = true)

theorem identity26246 : scanCanonicalize (H12AffineFastState.compose env26246 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound26246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26247 : List Nat := [2,4,8,16,32,17,8,4,1,52,33,49,8,32,1,3,48,1,52,0,1,33,17,2,8,17,33,48,49,1,53,32,4,33,32,0]

theorem envBound26247 : H12AffineFastState.Bounded env26247 := by
  intro p hp
  have h : env26247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26246_26247 : H12AffineEnvironment.transform 10 33 env26246 = env26247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env26246 == env26247) = true)

theorem identity26247 : scanCanonicalize (H12AffineFastState.compose env26247 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26247 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26248 : List Nat := [2,4,8,16,1,17,8,4,1,21,0,16,8,1,1,3,17,1,21,0,1,0,17,2,8,17,0,17,16,1,20,1,4,0,1,0]

theorem envBound26248 : H12AffineFastState.Bounded env26248 := by
  intro p hp
  have h : env26248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26247_26248 : H12AffineEnvironment.transform 4 1 env26247 = env26248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26247 == env26248) = true)

theorem identity26248 : scanCanonicalize (H12AffineFastState.compose env26248 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26249 : List Nat := [2,4,8,1,1,0,8,4,1,4,0,1,8,1,1,3,0,1,4,0,1,0,0,2,8,0,0,0,1,1,5,1,4,0,1,0]

theorem envBound26249 : H12AffineFastState.Bounded env26249 := by
  intro p hp
  have h : env26249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26248_26249 : H12AffineEnvironment.transform 3 1 env26248 = env26249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26248 == env26249) = true)

def env26250 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33031,57628,35109,1024,32769,36624,54788,41244,3,8193,17,24101,35344,31500,2341,41992,48392,256,27436,35329,513]

theorem envBound26250 : H12AffineFastState.Bounded env26250 := by
  intro p hp
  have h : env26250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26238_26250 : H12AffineEnvironment.transform 6 9 env26238 = env26250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26238 == env26250) = true)

theorem identity26250 : scanCanonicalize (H12AffineFastState.compose env26250 (packedSelected [0,1,7,8,10,12,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 7204) := by decide +kernel

theorem selectedBound26250 : packedSelected [0,1,7,8,10,12,14,17,18] rootPS < 2^1333 := by decide +kernel

def env26251 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,7204,7459,32056,5377,1024,7205,4916,18976,15672,3,8193,17,24101,5684,31500,2341,14380,8492,256,27436,5669,513]

theorem envBound26251 : H12AffineFastState.Bounded env26251 := by
  intro p hp
  have h : env26251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26250_26251 : H12AffineEnvironment.transform 14 7204 env26250 = env26251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7204 env26250 == env26251) = true)

theorem identity26251 : scanCanonicalize (H12AffineFastState.compose env26251 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26251 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26252 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,7204,7459,23605,5377,1024,7205,4916,18976,7221,3,268,17,24101,5684,23041,2341,6433,33,256,18977,5669,513]

theorem envBound26252 : H12AffineFastState.Bounded env26252 := by
  intro p hp
  have h : env26252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26251_26252 : H12AffineEnvironment.transform 12 269 env26251 = env26252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26251 == env26252) = true)

theorem identity26252 : scanCanonicalize (H12AffineFastState.compose env26252 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2560) := by decide +kernel

theorem selectedBound26252 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26253 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,2560,7204,7459,5685,5377,1024,7205,4916,32,7221,3,268,17,5157,5684,4097,2341,6433,33,256,33,5669,513]

theorem envBound26253 : H12AffineFastState.Bounded env26253 := by
  intro p hp
  have h : env26253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26252_26253 : H12AffineEnvironment.transform 13 2560 env26252 = env26253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2560 env26252 == env26253) = true)

theorem identity26253 : scanCanonicalize (H12AffineFastState.compose env26253 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound26253 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26254 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1061,4096,269,1573,4097,4358,5685,5377,1024,4096,4916,32,4112,3,268,17,5157,5684,4097,1280,5380,33,256,33,5669,513]

theorem envBound26254 : H12AffineFastState.Bounded env26254 := by
  intro p hp
  have h : env26254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26253_26254 : H12AffineEnvironment.transform 10 1061 env26253 = env26254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env26253 == env26254) = true)

theorem identity26254 : scanCanonicalize (H12AffineFastState.compose env26254 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26254 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env26255 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1061,1076,269,1573,1077,1330,513,309,1024,1076,1792,32,1060,3,268,17,17,512,1077,1280,304,33,256,33,529,513]

theorem envBound26255 : H12AffineFastState.Bounded env26255 := by
  intro p hp
  have h : env26255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26254_26255 : H12AffineEnvironment.transform 11 1076 env26254 = env26255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env26254 == env26255) = true)

theorem identity26255 : scanCanonicalize (H12AffineFastState.compose env26255 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound26255 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26256 : List Nat := [2,4,8,16,32,17,9,256,512,784,821,804,269,309,805,546,513,309,784,804,16,32,820,3,268,17,17,512,805,528,304,33,256,33,529,513]

theorem envBound26256 : H12AffineFastState.Bounded env26256 := by
  intro p hp
  have h : env26256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26255_26256 : H12AffineEnvironment.transform 9 784 env26255 = env26256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env26255 == env26256) = true)

theorem identity26256 : scanCanonicalize (H12AffineFastState.compose env26256 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26256 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26257 : List Nat := [2,4,8,16,16,17,9,256,512,784,773,788,269,261,789,530,513,261,784,788,16,16,772,3,268,17,17,512,789,528,256,17,256,17,529,513]

theorem envBound26257 : H12AffineFastState.Bounded env26257 := by
  intro p hp
  have h : env26257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26256_26257 : H12AffineEnvironment.transform 4 16 env26256 = env26257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26256 == env26257) = true)

theorem identity26257 : scanCanonicalize (H12AffineFastState.compose env26257 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound26257 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env26258 : List Nat := [2,4,8,16,16,17,9,256,277,5,16,1,269,261,0,263,276,261,5,1,16,16,17,3,268,17,17,277,0,261,256,17,256,17,260,276]

theorem envBound26258 : H12AffineFastState.Bounded env26258 := by
  intro p hp
  have h : env26258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26257_26258 : H12AffineEnvironment.transform 8 277 env26257 = env26258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env26257 == env26258) = true)

theorem identity26258 : scanCanonicalize (H12AffineFastState.compose env26258 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26259 : List Nat := [2,4,8,16,16,17,9,5,16,5,16,1,8,0,0,2,17,0,5,1,16,16,17,3,9,17,17,16,0,0,5,17,5,17,1,17]

theorem envBound26259 : H12AffineFastState.Bounded env26259 := by
  intro p hp
  have h : env26259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26258_26259 : H12AffineEnvironment.transform 7 5 env26258 = env26259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26258 == env26259) = true)

def env26260 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,36625,4194304,41244,138,8328,17,4229288,35480,31501,2476,41992,4221828,256,27556,35328,513]

theorem envBound26260 : H12AffineFastState.Bounded env26260 := by
  intro p hp
  have h : env26260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26236_26260 : H12AffineEnvironment.transform 20 36625 env26236 = env26260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36625 env26236 == env26260) = true)

theorem identity26260 : scanCanonicalize (H12AffineFastState.compose env26260 (packedSelected [2,3,4,6,8,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 54925) := by decide +kernel

theorem selectedBound26260 : packedSelected [2,3,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26261 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33166,57749,35109,1024,32769,36625,54925,41244,138,8328,17,24101,35480,31501,2476,41992,48393,256,27556,35328,513]

theorem envBound26261 : H12AffineFastState.Bounded env26261 := by
  intro p hp
  have h : env26261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26260_26261 : H12AffineEnvironment.transform 21 54925 env26260 = env26261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54925 env26260 == env26261) = true)

theorem identity26261 : scanCanonicalize (H12AffineFastState.compose env26261 (packedSelected [0,3,8,10,17,18,20,24,27,28,41] rootPS)) = affineNative (2^(14+1) ^^^ 27525) := by decide +kernel

theorem selectedBound26261 : packedSelected [0,3,8,10,17,18,20,24,27,28,41] rootPS < 2^1333 := by decide +kernel

def env26262 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,27525,27147,2576,25248,1024,27524,25748,15624,19097,138,8328,17,24101,24861,31501,2476,20365,22156,256,27556,24965,513]

theorem envBound26262 : H12AffineFastState.Bounded env26262 := by
  intro p hp
  have h : env26262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26261_26262 : H12AffineEnvironment.transform 14 27525 env26261 = env26262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27525 env26261 == env26262) = true)

theorem identity26262 : scanCanonicalize (H12AffineFastState.compose env26262 (packedSelected [0,1,2,6,8,10,12,20,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26262 : packedSelected [0,1,2,6,8,10,12,20,23,27] rootPS < 2^1333 := by decide +kernel

def env26263 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,27405,27147,2576,25128,1024,27404,25628,15624,18961,2,8192,17,24101,24861,31501,2340,20229,22020,256,27436,24845,513]

theorem envBound26263 : H12AffineFastState.Bounded env26263 := by
  intro p hp
  have h : env26263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26262_26263 : H12AffineEnvironment.transform 6 8 env26262 = env26263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26262 == env26263) = true)

theorem identity26263 : scanCanonicalize (H12AffineFastState.compose env26263 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 11577) := by decide +kernel

theorem selectedBound26263 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env26264 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,11577,1588,1842,2576,3857,1024,1589,2341,15624,10024,2,8192,17,13084,3108,5684,2340,8764,15165,256,1557,3124,513]

theorem envBound26264 : H12AffineFastState.Bounded env26264 := by
  intro p hp
  have h : env26264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26263_26264 : H12AffineEnvironment.transform 13 11577 env26263 = env26264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11577 env26263 == env26264) = true)

theorem identity26264 : scanCanonicalize (H12AffineFastState.compose env26264 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound26264 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env26265 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,7465,4112,1588,1842,2576,3857,1024,1589,2341,33,6657,2,7465,17,3637,3108,5684,2340,7957,1556,256,1557,3124,513]

theorem envBound26265 : H12AffineFastState.Bounded env26265 := by
  intro p hp
  have h : env26265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26264_26265 : H12AffineEnvironment.transform 12 7465 env26264 = env26265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env26264 == env26265) = true)

theorem identity26265 : scanCanonicalize (H12AffineFastState.compose env26265 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3621) := by decide +kernel

theorem selectedBound26265 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env26266 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3621,780,3637,1588,1842,2576,3857,1024,1589,2341,33,1060,2,780,17,3637,3108,2065,2340,304,1556,256,1557,3124,513]

theorem envBound26266 : H12AffineFastState.Bounded env26266 := by
  intro p hp
  have h : env26266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26265_26266 : H12AffineEnvironment.transform 11 3621 env26265 = env26266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3621 env26265 == env26266) = true)

theorem identity26266 : scanCanonicalize (H12AffineFastState.compose env26266 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26266 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env26267 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,3109,268,3125,1076,1330,2064,3345,1024,1077,2341,33,1060,2,268,17,3125,3108,2065,2340,304,1044,256,1045,3124,1]

theorem envBound26267 : H12AffineFastState.Bounded env26267 := by
  intro p hp
  have h : env26267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26266_26267 : H12AffineEnvironment.transform 8 0 env26266 = env26267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26266 == env26267) = true)

theorem identity26267 : scanCanonicalize (H12AffineFastState.compose env26267 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26267 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26268 : List Nat := [2,4,8,16,32,17,8,256,0,52,2048,2065,268,2049,0,262,2064,2341,52,1,2341,33,16,2,268,17,2049,2064,2065,2340,304,32,256,33,2048,1]

theorem envBound26268 : H12AffineFastState.Bounded env26268 := by
  intro p hp
  have h : env26268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26267_26268 : H12AffineEnvironment.transform 9 52 env26267 = env26268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26267 == env26268) = true)

theorem identity26268 : scanCanonicalize (H12AffineFastState.compose env26268 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound26268 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26269 : List Nat := [2,4,8,16,32,17,8,62,0,52,2048,2065,50,2049,0,56,2064,2075,52,1,2075,33,16,2,50,17,2049,2064,2065,2074,14,32,62,33,2048,1]

theorem envBound26269 : H12AffineFastState.Bounded env26269 := by
  intro p hp
  have h : env26269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26268_26269 : H12AffineEnvironment.transform 7 62 env26268 = env26269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env26268 == env26269) = true)

def env26270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,138,8328,64,4450482,2196487,2233816,190520,246803,6382922,256,2327726,2319626,189381]

theorem envBound26270 : H12AffineFastState.Bounded env26270 := by
  intro p hp
  have h : env26270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26219_26270 : H12AffineEnvironment.transform 17 157873 env26219 = env26270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env26219 == env26270) = true)

theorem identity26270 : scanCanonicalize (H12AffineFastState.compose env26270 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26270 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157873,1024,8540,2097152,4194304,147593,138,8328,64,4409839,2172250,2233816,149861,222542,6382922,256,2303475,2319626,148120]

theorem envBound26271 : H12AffineFastState.Bounded env26271 := by
  intro p hp
  have h : env26271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26270_26271 : H12AffineEnvironment.transform 14 8541 env26270 = env26271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26270 == env26271) = true)

theorem identity26271 : scanCanonicalize (H12AffineFastState.compose env26271 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound26271 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env26272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16537,10280,1024,8540,2097152,4194304,16,138,8328,64,4262262,2172250,2118977,2556,75223,6382922,256,2188650,2172307,513]

theorem envBound26272 : H12AffineFastState.Bounded env26272 := by
  intro p hp
  have h : env26272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26271_26272 : H12AffineEnvironment.transform 16 16537 env26271 = env26272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env26271 == env26272) = true)

def env26273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16537,10280,1024,8540,17864,4194304,16,138,8328,64,4262262,90258,4233,2556,75223,4268162,256,73890,90203,513]

theorem envBound26273 : H12AffineFastState.Bounded env26273 := by
  intro p hp
  have h : env26273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26272_26273 : H12AffineEnvironment.transform 20 17864 env26272 = env26273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env26272 == env26273) = true)

theorem identity26273 : scanCanonicalize (H12AffineFastState.compose env26273 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26273 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16537,10280,1024,8540,17864,4194304,16,138,8328,64,4204924,16536,4233,2556,1501,4194440,256,168,16465,513]

theorem envBound26274 : H12AffineFastState.Bounded env26274 := by
  intro p hp
  have h : env26274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26273_26274 : H12AffineEnvironment.transform 15 8202 env26273 = env26274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26273 == env26274) = true)

theorem identity26274 : scanCanonicalize (H12AffineFastState.compose env26274 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound26274 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env26275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16537,10280,1024,8540,17864,248,16,138,8328,64,10628,16536,4233,2556,1501,112,256,168,16465,513]

theorem envBound26275 : H12AffineFastState.Bounded env26275 := by
  intro p hp
  have h : env26275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26274_26275 : H12AffineEnvironment.transform 21 248 env26274 = env26275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env26274 == env26275) = true)

theorem identity26275 : scanCanonicalize (H12AffineFastState.compose env26275 (packedSelected [2,4,6,9,14,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26275 : packedSelected [2,4,6,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env26276 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,8202,16537,10280,1024,8460,17816,168,16,138,8328,16,10628,16536,4233,2476,1421,32,256,168,16385,513]

theorem envBound26276 : H12AffineFastState.Bounded env26276 := by
  intro p hp
  have h : env26276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26275_26276 : H12AffineEnvironment.transform 5 16 env26275 = env26276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26275 == env26276) = true)

theorem identity26276 : scanCanonicalize (H12AffineFastState.compose env26276 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26276 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env26277 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,0,263,16537,2341,1024,1,17816,168,16,138,389,16,2185,16536,4233,2476,1421,32,256,168,16385,513]

theorem envBound26277 : H12AffineFastState.Bounded env26277 := by
  intro p hp
  have h : env26277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26276_26277 : H12AffineEnvironment.transform 12 269 env26276 = env26277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26276 == env26277) = true)

theorem identity26277 : scanCanonicalize (H12AffineFastState.compose env26277 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound26277 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26278 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5292,0,263,5173,2341,1024,1,4404,168,16,138,389,16,2185,5172,4233,2476,1421,32,256,168,5293,513]

theorem envBound26278 : H12AffineFastState.Bounded env26278 := by
  intro p hp
  have h : env26278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26277_26278 : H12AffineEnvironment.transform 13 5292 env26277 = env26278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env26277 == env26278) = true)

theorem identity26278 : scanCanonicalize (H12AffineFastState.compose env26278 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26278 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26279 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5156,0,263,5173,2341,1024,1,4404,32,16,2,269,16,2049,5172,4097,2340,1285,32,256,32,5157,513]

theorem envBound26279 : H12AffineFastState.Bounded env26279 := by
  intro p hp
  have h : env26279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26278_26279 : H12AffineEnvironment.transform 6 8 env26278 = env26279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26278 == env26279) = true)

theorem identity26279 : scanCanonicalize (H12AffineFastState.compose env26279 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26279 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26280 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,34,5173,2048,1024,1,4113,32,16,2,40,16,2049,5172,4097,2049,1056,32,37,32,5157,513]

theorem envBound26280 : H12AffineFastState.Bounded env26280 := by
  intro p hp
  have h : env26280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26279_26280 : H12AffineEnvironment.transform 7 37 env26279 = env26280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26279 == env26280) = true)

theorem identity26280 : scanCanonicalize (H12AffineFastState.compose env26280 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound26280 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26281 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3109,40,2049,0,34,2064,2048,1024,1,3124,32,16,2,40,16,2049,2065,3108,2049,1056,32,37,32,2048,513]

theorem envBound26281 : H12AffineFastState.Bounded env26281 := by
  intro p hp
  have h : env26281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26280_26281 : H12AffineEnvironment.transform 11 3109 env26280 = env26281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env26280 == env26281) = true)

theorem identity26281 : scanCanonicalize (H12AffineFastState.compose env26281 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26281 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26282 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,40,2049,0,34,2064,2048,53,1,2049,32,16,2,40,16,2049,2065,2065,2049,21,32,37,32,2048,513]

theorem envBound26282 : H12AffineFastState.Bounded env26282 := by
  intro p hp
  have h : env26282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26281_26282 : H12AffineEnvironment.transform 9 53 env26281 = env26282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26281 == env26282) = true)

theorem identity26282 : scanCanonicalize (H12AffineFastState.compose env26282 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound26282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26283 : List Nat := [2,4,8,16,32,16,8,37,512,53,561,545,40,560,0,34,545,561,53,1,560,32,16,2,40,16,560,544,544,560,21,32,37,32,561,513]

theorem envBound26283 : H12AffineFastState.Bounded env26283 := by
  intro p hp
  have h : env26283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26282_26283 : H12AffineEnvironment.transform 10 561 env26282 = env26283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env26282 == env26283) = true)

theorem identity26283 : scanCanonicalize (H12AffineFastState.compose env26283 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26283 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26284 : List Nat := [2,4,8,16,32,16,8,37,1,53,48,32,40,49,0,34,32,48,53,1,49,32,16,2,40,16,49,33,33,49,21,32,37,32,48,0]

theorem envBound26284 : H12AffineFastState.Bounded env26284 := by
  intro p hp
  have h : env26284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26283_26284 : H12AffineEnvironment.transform 8 1 env26283 = env26284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26283 == env26284) = true)

def env26285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16537,10280,1024,8540,17865,4194304,16,138,8328,64,4262262,90259,4232,2556,75223,4268163,256,73891,90202,513]

theorem envBound26285 : H12AffineFastState.Bounded env26285 := by
  intro p hp
  have h : env26285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26272_26285 : H12AffineEnvironment.transform 20 17865 env26272 = env26285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env26272 == env26285) = true)

theorem identity26285 : scanCanonicalize (H12AffineFastState.compose env26285 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26285 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8322,16537,10280,1024,8540,17865,4194304,16,138,8328,64,4205044,16401,4232,2556,1365,4194305,256,33,16600,513]

theorem envBound26286 : H12AffineFastState.Bounded env26286 := by
  intro p hp
  have h : env26286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26285_26286 : H12AffineEnvironment.transform 15 8322 env26285 = env26286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26285 == env26286) = true)

theorem identity26286 : scanCanonicalize (H12AffineFastState.compose env26286 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26286 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,17728,4194304,16,3,8193,64,4204925,16401,4097,2421,1365,4194305,256,33,16465,513]

theorem envBound26287 : H12AffineFastState.Bounded env26287 := by
  intro p hp
  have h : env26287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26286_26287 : H12AffineEnvironment.transform 6 9 env26286 = env26287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26286 == env26287) = true)

theorem identity26287 : scanCanonicalize (H12AffineFastState.compose env26287 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound26287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,17728,33,16,3,8193,64,10588,16401,4097,2421,1365,32,256,33,16465,513]

theorem envBound26288 : H12AffineFastState.Bounded env26288 := by
  intro p hp
  have h : env26288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26287_26288 : H12AffineEnvironment.transform 21 33 env26287 = env26288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26287 == env26288) = true)

theorem identity26288 : scanCanonicalize (H12AffineFastState.compose env26288 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound26288 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,16384,33,375,16400,2388,1024,32,17728,33,16,3,381,64,2080,16401,4097,2421,1365,32,256,33,16465,513]

theorem envBound26289 : H12AffineFastState.Bounded env26289 := by
  intro p hp
  have h : env26289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26288_26289 : H12AffineEnvironment.transform 12 380 env26288 = env26289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env26288 == env26289) = true)

theorem identity26289 : scanCanonicalize (H12AffineFastState.compose env26289 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26289 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env26290 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,16384,33,294,16400,2309,1024,32,17681,33,16,3,300,17,2080,16401,4097,2340,1284,32,256,33,16384,513]

theorem envBound26290 : H12AffineFastState.Bounded env26290 := by
  intro p hp
  have h : env26290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26289_26290 : H12AffineEnvironment.transform 5 17 env26289 = env26290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26289 == env26290) = true)

theorem identity26290 : scanCanonicalize (H12AffineFastState.compose env26290 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5173) := by decide +kernel

theorem selectedBound26290 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26291 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,5173,33,294,5157,2309,1024,32,4388,33,16,3,300,17,2080,5156,4097,2340,1284,32,256,33,5173,513]

theorem envBound26291 : H12AffineFastState.Bounded env26291 := by
  intro p hp
  have h : env26291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26290_26291 : H12AffineEnvironment.transform 13 5173 env26290 = env26291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5173 env26290 == env26291) = true)

theorem identity26291 : scanCanonicalize (H12AffineFastState.compose env26291 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound26291 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26292 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1557,4096,301,5173,33,294,5157,1808,1024,32,4388,33,16,3,300,17,1589,5156,4097,1841,1284,32,256,33,5173,513]

theorem envBound26292 : H12AffineFastState.Bounded env26292 := by
  intro p hp
  have h : env26292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26291_26292 : H12AffineEnvironment.transform 10 1557 env26291 = env26292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env26291 == env26292) = true)

def env26293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound26293 : H12AffineFastState.Bounded env26293 := by
  intro p hp
  have h : env26293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26152_26293 : H12AffineEnvironment.transform 18 1025 env26152 = env26293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26152 == env26293) = true)

theorem identity26293 : scanCanonicalize (H12AffineFastState.compose env26293 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 253963) := by decide +kernel

theorem selectedBound26293 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,253963,16777216,8328,64,21241866,18973836,2340186,335882,16933915,23160256,257,19014823,19055874,16991180]

theorem envBound26294 : H12AffineFastState.Bounded env26294 := by
  intro p hp
  have h : env26294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26293_26294 : H12AffineEnvironment.transform 22 253963 env26293 = env26294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 253963 env26293 == env26294) = true)

def env26295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253963,16777216,8328,64,16959642,18973836,2340186,335882,16933915,19369296,257,19014823,19055874,16991180]

theorem envBound26295 : H12AffineFastState.Bounded env26295 := by
  intro p hp
  have h : env26295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26294_26295 : H12AffineEnvironment.transform 21 452752 env26294 = env26295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env26294 == env26295) = true)

def env26296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253963,242968,8328,64,97666,2240916,2340186,335882,119043,2373704,257,2199999,2191386,63188]

theorem envBound26296 : H12AffineFastState.Bounded env26296 := by
  intro p hp
  have h : env26296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26295_26296 : H12AffineEnvironment.transform 23 242968 env26295 = env26296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env26295 == env26296) = true)

def env26297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253963,242968,8328,64,97666,139732,238874,335882,119043,272392,257,98815,90202,63188]

theorem envBound26297 : H12AffineFastState.Bounded env26297 := by
  intro p hp
  have h : env26297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26296_26297 : H12AffineEnvironment.transform 20 4160 env26296 = env26297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26296 == env26297) = true)

theorem identity26297 : scanCanonicalize (H12AffineFastState.compose env26297 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26297 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452752,180225,169234,8328,64,23944,139732,165136,262144,61705,272392,257,41461,16464,63188]

theorem envBound26298 : H12AffineFastState.Bounded env26298 := by
  intro p hp
  have h : env26298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26297_26298 : H12AffineEnvironment.transform 15 8202 env26297 = env26298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26297 == env26298) = true)

def env26299 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452680,180225,169234,8272,64,23888,139532,165136,262144,61705,272392,257,41261,16464,62988]

theorem envBound26299 : H12AffineFastState.Bounded env26299 := by
  intro p hp
  have h : env26299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26298_26299 : H12AffineEnvironment.transform 6 88 env26298 = env26299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env26298 == env26299) = true)

theorem identity26299 : scanCanonicalize (H12AffineFastState.compose env26299 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound26299 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26300 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57677,262144,1025,32769,4160,264453,8524,29791,8272,64,23888,49217,25693,262144,61705,272392,257,41261,16464,62988]

theorem envBound26300 : H12AffineFastState.Bounded env26300 := by
  intro p hp
  have h : env26300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26299_26300 : H12AffineEnvironment.transform 16 57677 env26299 = env26300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env26299 == env26300) = true)

theorem identity26300 : scanCanonicalize (H12AffineFastState.compose env26300 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound26300 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env26301 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57677,2421,1025,32769,4160,112,8524,29791,8272,64,23888,49217,25693,2421,61705,8573,257,41261,16464,62988]

theorem envBound26301 : H12AffineFastState.Bounded env26301 := by
  intro p hp
  have h : env26301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26300_26301 : H12AffineEnvironment.transform 17 2421 env26300 = env26301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env26300 == env26301) = true)

theorem identity26301 : scanCanonicalize (H12AffineFastState.compose env26301 (packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26301 : packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS < 2^1333 := by decide +kernel

def env26302 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,263,49216,2421,1025,32769,4160,112,65,21842,349,64,23888,49217,17744,2421,53252,112,257,32800,16464,55041]

theorem envBound26302 : H12AffineFastState.Bounded env26302 := by
  intro p hp
  have h : env26302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26301_26302 : H12AffineEnvironment.transform 12 269 env26301 = env26302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26301 == env26302) = true)

def env26303 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452681,180225,169234,8273,64,23889,139533,165136,262144,61705,272392,257,41260,16464,62989]

theorem envBound26303 : H12AffineFastState.Bounded env26303 := by
  intro p hp
  have h : env26303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26298_26303 : H12AffineEnvironment.transform 6 89 env26298 = env26303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env26298 == env26303) = true)

theorem identity26303 : scanCanonicalize (H12AffineFastState.compose env26303 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26303 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26304 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,262144,1025,32769,4160,327001,54545,32770,8273,64,23889,13341,36864,262144,61705,272392,257,41260,16464,62989]

theorem envBound26304 : H12AffineFastState.Bounded env26304 := by
  intro p hp
  have h : env26304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26303_26304 : H12AffineEnvironment.transform 16 5392 env26303 = env26304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26303 == env26304) = true)

theorem identity26304 : scanCanonicalize (H12AffineFastState.compose env26304 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound26304 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env26305 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,10280,1025,32769,4160,54641,54545,32770,8273,64,23889,13341,36864,10280,61705,32,257,41260,16464,62989]

theorem envBound26305 : H12AffineFastState.Bounded env26305 := by
  intro p hp
  have h : env26305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26304_26305 : H12AffineEnvironment.transform 17 10280 env26304 = env26305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26304 == env26305) = true)

theorem identity26305 : scanCanonicalize (H12AffineFastState.compose env26305 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26305 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env26306 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13404,32768,8202,5392,10280,1025,32769,4160,41261,41293,32770,8273,64,10509,13341,36864,10280,34133,32,257,41260,13324,33361]

theorem envBound26306 : H12AffineFastState.Bounded env26306 := by
  intro p hp
  have h : env26306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26305_26306 : H12AffineEnvironment.transform 13 13404 env26305 = env26306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26305 == env26306) = true)

theorem identity26306 : scanCanonicalize (H12AffineFastState.compose env26306 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26306 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26307 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13404,1,8202,5392,10280,1025,0,4160,8492,8524,3,8273,64,10509,13341,4097,10280,1364,32,257,8493,13324,592]

theorem envBound26307 : H12AffineFastState.Bounded env26307 := by
  intro p hp
  have h : env26307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26306_26307 : H12AffineEnvironment.transform 14 1 env26306 = env26307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26306 == env26307) = true)

theorem identity26307 : scanCanonicalize (H12AffineFastState.compose env26307 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26307 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26308 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,1,262,5392,2340,1025,0,4160,32,64,3,349,64,2049,5393,4097,2340,1364,32,257,33,5376,592]

theorem envBound26308 : H12AffineFastState.Bounded env26308 := by
  intro p hp
  have h : env26308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26307_26308 : H12AffineEnvironment.transform 12 268 env26307 = env26308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26307 == env26308) = true)

def env26309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253963,242968,8328,64,97666,139733,238875,335882,119043,272393,257,98814,90203,63188]

theorem envBound26309 : H12AffineFastState.Bounded env26309 := by
  intro p hp
  have h : env26309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26296_26309 : H12AffineEnvironment.transform 20 4161 env26296 = env26309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26296 == env26309) = true)

theorem identity26309 : scanCanonicalize (H12AffineFastState.compose env26309 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound26309 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,329866,17,21762,8328,64,97666,115151,17665,335882,119043,272393,257,98814,90203,63188]

theorem envBound26310 : H12AffineFastState.Bounded env26310 := by
  intro p hp
  have h : env26310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26309_26310 : H12AffineEnvironment.transform 16 122906 env26309 = env26310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env26309 == env26310) = true)

def env26311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,329730,17,21762,8192,64,97546,115015,17665,335882,119043,272393,257,98678,90203,63068]

theorem envBound26311 : H12AffineFastState.Bounded env26311 := by
  intro p hp
  have h : env26311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26310_26311 : H12AffineEnvironment.transform 6 8 env26310 = env26311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26310 == env26311) = true)

theorem identity26311 : scanCanonicalize (H12AffineFastState.compose env26311 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound26311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,56437,1025,32769,4161,119927,17,21762,8192,64,97546,115015,17665,130175,119043,62588,257,98678,90203,63068]

theorem envBound26312 : H12AffineFastState.Bounded env26312 := by
  intro p hp
  have h : env26312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26311_26312 : H12AffineEnvironment.transform 17 56437 env26311 = env26312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env26311 == env26312) = true)

theorem identity26312 : scanCanonicalize (H12AffineFastState.compose env26312 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound26312 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env26313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,263,57629,56437,1025,32769,4161,54640,17,21762,8192,64,31757,49216,17665,64888,53252,62588,257,32881,24924,63068]

theorem envBound26313 : H12AffineFastState.Bounded env26313 := by
  intro p hp
  have h : env26313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26312_26313 : H12AffineEnvironment.transform 15 263 env26312 = env26313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env26312 == env26313) = true)

theorem identity26313 : scanCanonicalize (H12AffineFastState.compose env26313 (packedSelected [4,10,11,12,14,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26313 : packedSelected [4,10,11,12,14,19,22] rootPS < 2^1333 := by decide +kernel

def env26314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,263,24860,23668,1025,0,4161,21873,17,21762,8192,64,31757,16449,17665,32121,20485,29821,257,112,24924,30301]

theorem envBound26314 : H12AffineFastState.Bounded env26314 := by
  intro p hp
  have h : env26314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26313_26314 : H12AffineEnvironment.transform 14 1 env26313 = env26314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26313 == env26314) = true)

theorem identity26314 : scanCanonicalize (H12AffineFastState.compose env26314 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26314 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26315 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,263,24860,23589,1025,0,4112,21792,17,21762,8192,17,31757,16400,17665,32040,20485,29740,257,33,24845,30220]

theorem envBound26315 : H12AffineFastState.Bounded env26315 := by
  intro p hp
  have h : env26315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26314_26315 : H12AffineEnvironment.transform 5 17 env26314 = env26315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26314 == env26315) = true)

theorem identity26315 : scanCanonicalize (H12AffineFastState.compose env26315 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound26315 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26316 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,12345,1,263,4389,11292,1025,0,4112,9497,17,9531,8192,17,3124,12329,13624,3345,8252,1045,257,33,4404,1589]

theorem envBound26316 : H12AffineFastState.Bounded env26316 := by
  intro p hp
  have h : env26316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26315_26316 : H12AffineEnvironment.transform 13 12345 env26315 = env26316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env26315 == env26316) = true)

theorem identity26316 : scanCanonicalize (H12AffineFastState.compose env26316 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound26316 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env26317 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,5157,1,263,4389,2048,1025,0,4112,261,17,295,1052,17,3124,5173,4388,3345,1056,1045,257,33,4404,1589]

theorem envBound26317 : H12AffineFastState.Bounded env26317 := by
  intro p hp
  have h : env26317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26316_26317 : H12AffineEnvironment.transform 12 1052 env26316 = env26317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env26316 == env26317) = true)

theorem identity26317 : scanCanonicalize (H12AffineFastState.compose env26317 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26317 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env26318 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,1052,3124,1,263,2356,2048,1025,0,2049,261,17,295,1052,17,3124,3108,2357,3345,1056,1045,257,33,2341,1589]

theorem envBound26318 : H12AffineFastState.Bounded env26318 := by
  intro p hp
  have h : env26318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26317_26318 : H12AffineEnvironment.transform 11 2065 env26317 = env26318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env26317 == env26318) = true)

theorem identity26318 : scanCanonicalize (H12AffineFastState.compose env26318 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26318 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26319 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,1052,3124,1,35,2064,2048,1025,0,2049,33,17,3,1052,17,3124,3108,2065,3125,1056,1045,37,33,2049,1589]

theorem envBound26319 : H12AffineFastState.Bounded env26319 := by
  intro p hp
  have h : env26319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26318_26319 : H12AffineEnvironment.transform 7 36 env26318 = env26319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26318 == env26319) = true)

def env26320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,329731,17,21762,8193,64,97547,115014,17665,335882,119043,272393,257,98679,90203,63069]

theorem envBound26320 : H12AffineFastState.Bounded env26320 := by
  intro p hp
  have h : env26320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26310_26320 : H12AffineEnvironment.transform 6 9 env26310 = env26320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26310 == env26320) = true)

theorem identity26320 : scanCanonicalize (H12AffineFastState.compose env26320 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound26320 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,32041,1025,32769,4161,95530,17,21762,8193,64,97547,115014,17665,89379,119043,21792,257,98679,90203,63069]

theorem envBound26321 : H12AffineFastState.Bounded env26321 := by
  intro p hp
  have h : env26321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26320_26321 : H12AffineEnvironment.transform 17 32041 env26320 = env26321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env26320 == env26321) = true)

theorem identity26321 : scanCanonicalize (H12AffineFastState.compose env26321 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26321 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,32041,1025,0,4161,95530,17,21762,8193,64,97547,82247,17665,89379,86274,21792,257,65910,90203,30300]

theorem envBound26322 : H12AffineFastState.Bounded env26322 := by
  intro p hp
  have h : env26322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26321_26322 : H12AffineEnvironment.transform 14 1 env26321 = env26322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26321 == env26322) = true)

theorem identity26322 : scanCanonicalize (H12AffineFastState.compose env26322 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound26322 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env26323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8282,16449,32041,1025,0,4161,21872,17,21762,8193,64,23889,24861,17665,32121,29016,21792,257,8492,16385,30300]

theorem envBound26323 : H12AffineFastState.Bounded env26323 := by
  intro p hp
  have h : env26323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26322_26323 : H12AffineEnvironment.transform 15 8282 env26322 = env26323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env26322 == env26323) = true)

theorem identity26323 : scanCanonicalize (H12AffineFastState.compose env26323 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26323 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env26324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,263,16449,23668,1025,0,4161,21872,17,21762,348,64,23889,16448,17665,23588,20485,21792,257,113,16385,22273]

theorem envBound26324 : H12AffineFastState.Bounded env26324 := by
  intro p hp
  have h : env26324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26323_26324 : H12AffineEnvironment.transform 12 349 env26323 = env26324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26323 == env26324) = true)

theorem identity26324 : scanCanonicalize (H12AffineFastState.compose env26324 (packedSelected [0,4,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26324 : packedSelected [0,4,10,11] rootPS < 2^1333 := by decide +kernel

def env26325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,263,5441,2420,1025,0,4161,112,17,2,348,64,2129,5440,4097,2340,1285,32,257,113,5377,513]

theorem envBound26325 : H12AffineFastState.Bounded env26325 := by
  intro p hp
  have h : env26325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26324_26325 : H12AffineEnvironment.transform 13 5376 env26324 = env26325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26324 == env26325) = true)

def env26326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253963,242969,8328,64,97667,2240917,2340186,335882,119042,2373705,257,2199998,2191387,63189]

theorem envBound26326 : H12AffineFastState.Bounded env26326 := by
  intro p hp
  have h : env26326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26295_26326 : H12AffineEnvironment.transform 23 242969 env26295 = env26326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env26295 == env26326) = true)

def env26327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253963,242969,8328,64,97667,139733,238874,335882,119042,272393,257,98814,90203,63189]

theorem envBound26327 : H12AffineFastState.Bounded env26327 := by
  intro p hp
  have h : env26327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26326_26327 : H12AffineEnvironment.transform 20 4160 env26326 = env26327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26326 == env26327) = true)

theorem identity26327 : scanCanonicalize (H12AffineFastState.compose env26327 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound26327 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,4160,392286,62661,41431,8328,64,97667,79131,45524,335882,119042,272393,257,98814,90203,63189]

theorem envBound26328 : H12AffineFastState.Bounded env26328 := by
  intro p hp
  have h : env26328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26327_26328 : H12AffineEnvironment.transform 16 70862 env26327 = env26328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env26327 == env26328) = true)

theorem identity26328 : scanCanonicalize (H12AffineFastState.compose env26328 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound26328 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env26329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70862,262144,1025,29909,4160,329866,17,21763,8328,64,97667,79131,17664,335882,75222,272393,257,95530,90203,513]

theorem envBound26329 : H12AffineFastState.Bounded env26329 := by
  intro p hp
  have h : env26329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26328_26329 : H12AffineEnvironment.transform 14 29908 env26328 = env26329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env26328 == env26329) = true)

theorem identity26329 : scanCanonicalize (H12AffineFastState.compose env26329 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26329 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env26330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,70862,262144,1025,137,4160,329866,17,8543,8328,64,68063,79131,12636,335882,75222,272393,257,65910,70663,513]

theorem envBound26330 : H12AffineFastState.Bounded env26330 := by
  intro p hp
  have h : env26330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26329_26330 : H12AffineEnvironment.transform 13 13404 env26329 = env26330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26329 == env26330) = true)

theorem identity26330 : scanCanonicalize (H12AffineFastState.compose env26330 (packedSelected [1,2,3,4,5,6,8,9,10,14,20,26] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound26330 : packedSelected [1,2,3,4,5,6,8,9,10,14,20,26] rootPS < 2^1333 := by decide +kernel

def env26331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,70862,2421,1025,137,4160,66047,17,8543,8328,64,68063,79131,12636,76159,75222,8572,257,65910,70663,513]

theorem envBound26331 : H12AffineFastState.Bounded env26331 := by
  intro p hp
  have h : env26331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26330_26331 : H12AffineEnvironment.transform 17 2421 env26330 = env26331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env26330 == env26331) = true)

theorem identity26331 : scanCanonicalize (H12AffineFastState.compose env26331 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26331 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env26332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,70726,2421,1025,1,4160,65911,17,8543,8192,64,67927,79131,12636,76159,75102,8572,257,65910,70663,513]

theorem envBound26332 : H12AffineFastState.Bounded env26332 := by
  intro p hp
  have h : env26332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26331_26332 : H12AffineEnvironment.transform 6 8 env26331 = env26332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26331 == env26332) = true)

theorem identity26332 : scanCanonicalize (H12AffineFastState.compose env26332 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26332 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,65536,70726,2421,1025,1,4160,65911,17,2,349,64,67927,70726,4097,67618,66563,33,257,65910,70663,513]

theorem envBound26333 : H12AffineFastState.Bounded env26333 := by
  intro p hp
  have h : env26333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26332_26333 : H12AffineEnvironment.transform 12 349 env26332 = env26333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26332 == env26333) = true)

def env26334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253963,242969,8328,64,97667,139732,238875,335882,119042,272392,257,98815,90202,63189]

theorem envBound26334 : H12AffineFastState.Bounded env26334 := by
  intro p hp
  have h : env26334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26326_26334 : H12AffineEnvironment.transform 20 4161 env26326 = env26334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26326 == env26334) = true)

theorem identity26334 : scanCanonicalize (H12AffineFastState.compose env26334 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound26334 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,452752,144597,156103,8328,64,43357,139732,160197,324820,1500,272392,257,21793,46212,63189]

theorem envBound26335 : H12AffineFastState.Bounded env26335 := by
  intro p hp
  have h : env26335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26334_26335 : H12AffineEnvironment.transform 15 54494 env26334 = env26335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env26334 == env26335) = true)

def env26336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,262144,1025,32769,4161,305360,29845,8583,8328,64,43357,24980,12677,324820,1500,272392,257,21793,46212,63189]

theorem envBound26336 : H12AffineFastState.Bounded env26336 := by
  intro p hp
  have h : env26336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26335_26336 : H12AffineEnvironment.transform 16 16448 env26335 = env26336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env26335 == env26336) = true)

theorem identity26336 : scanCanonicalize (H12AffineFastState.compose env26336 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound26336 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,32768,33031,5529,262144,1025,32769,4161,305360,8524,8583,8328,64,43357,13389,12677,303373,1500,272392,257,248,46212,41740]

theorem envBound26337 : H12AffineFastState.Bounded env26337 := by
  intro p hp
  have h : env26337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26336_26337 : H12AffineEnvironment.transform 13 5593 env26336 = env26337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env26336 == env26337) = true)

theorem identity26337 : scanCanonicalize (H12AffineFastState.compose env26337 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound26337 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env26338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,32768,33031,5529,35245,1025,32769,4161,8573,8524,8583,8328,64,43357,13389,12677,10400,1500,41381,257,248,46212,41740]

theorem envBound26338 : H12AffineFastState.Bounded env26338 := by
  intro p hp
  have h : env26338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26337_26338 : H12AffineEnvironment.transform 17 35245 env26337 = env26338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env26337 == env26338) = true)

theorem identity26338 : scanCanonicalize (H12AffineFastState.compose env26338 (packedSelected [0,1,2,6,7,8,17,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26338 : packedSelected [0,1,2,6,7,8,17,19,20] rootPS < 2^1333 := by decide +kernel

def env26339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,33031,5392,35108,1025,32769,4161,8573,8524,8462,8193,64,43357,13389,12556,10281,1365,41260,257,113,46093,41740]

theorem envBound26339 : H12AffineFastState.Bounded env26339 := by
  intro p hp
  have h : env26339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26338_26339 : H12AffineEnvironment.transform 6 9 env26338 = env26339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26338 == env26339) = true)

theorem identity26339 : scanCanonicalize (H12AffineFastState.compose env26339 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound26339 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8313,8574,5392,10589,1025,8312,4161,8573,8524,8462,8193,64,2340,13389,12556,10281,1365,341,257,113,5236,885]

theorem envBound26340 : H12AffineFastState.Bounded env26340 := by
  intro p hp
  have h : env26340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26339_26340 : H12AffineEnvironment.transform 14 8313 env26339 = env26340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env26339 == env26340) = true)

theorem identity26340 : scanCanonicalize (H12AffineFastState.compose env26340 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26340 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env26341 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5237,8313,8283,5173,10360,1025,8312,4161,8280,8297,8235,8193,64,2049,13389,12329,10281,1136,112,36,113,5236,592]

theorem envBound26341 : H12AffineFastState.Bounded env26341 := by
  intro p hp
  have h : env26341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26340_26341 : H12AffineEnvironment.transform 7 37 env26340 = env26341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26340 == env26341) = true)

theorem identity26341 : scanCanonicalize (H12AffineFastState.compose env26341 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound26341 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env26342 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5237,81,115,5173,2128,1025,80,4161,112,65,3,41,64,2049,5221,4097,2049,1136,112,36,113,5236,592]

theorem envBound26342 : H12AffineFastState.Bounded env26342 := by
  intro p hp
  have h : env26342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26341_26342 : H12AffineEnvironment.transform 12 40 env26341 = env26342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env26341 == env26342) = true)

theorem identity26342 : scanCanonicalize (H12AffineFastState.compose env26342 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26342 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env26343 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,8,5205,81,83,5141,2128,1025,80,4161,80,65,3,9,64,2049,5189,4097,2049,1104,80,4,81,5204,592]

theorem envBound26343 : H12AffineFastState.Bounded env26343 := by
  intro p hp
  have h : env26343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26342_26343 : H12AffineEnvironment.transform 4 0 env26342 = env26343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26342 == env26343) = true)

theorem identity26343 : scanCanonicalize (H12AffineFastState.compose env26343 (packedSelected [18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26343 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env26344 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,8,5125,1,3,5141,2048,1025,0,4113,0,17,3,9,16,2049,5141,4097,2049,1024,0,4,1,5124,512]

theorem envBound26344 : H12AffineFastState.Bounded env26344 := by
  intro p hp
  have h : env26344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26343_26344 : H12AffineEnvironment.transform 5 16 env26343 = env26344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26343 == env26344) = true)

def env26345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,262144,1025,32769,4161,305361,29844,8582,8328,64,43357,24981,12676,324820,1500,272392,257,21793,46212,63189]

theorem envBound26345 : H12AffineFastState.Bounded env26345 := by
  intro p hp
  have h : env26345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26335_26345 : H12AffineEnvironment.transform 16 16449 env26335 = env26345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env26335 == env26345) = true)

theorem identity26345 : scanCanonicalize (H12AffineFastState.compose env26345 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26345 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1