import H12CloudChart1Data036

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound9200 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9201 : List Nat := [2,4,8,16,27,64,66,4,27,5,65,64,89,16,80,25,64,91,5,80,65,27,16,73,18,65,16,65,64,11,4,0,4,81,16,75]

theorem envBound9201 : H12AffineFastState.Bounded env9201 := by
  intro p hp
  have h : env9201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9200_9201 : H12AffineEnvironment.transform 12 89 env9200 = env9201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env9200 == env9201) = true)

theorem identity9201 : scanCanonicalize (H12AffineFastState.compose env9201 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9201 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9202 : List Nat := [2,4,8,16,27,16,18,4,27,5,17,16,9,16,0,25,16,11,5,0,17,27,16,25,18,17,16,17,16,11,4,0,4,1,16,27]

theorem envBound9202 : H12AffineFastState.Bounded env9202 := by
  intro p hp
  have h : env9202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9201_9202 : H12AffineEnvironment.transform 5 16 env9201 = env9202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9201 == env9202) = true)

theorem identity9202 : scanCanonicalize (H12AffineFastState.compose env9202 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9202 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9203 : List Nat := [2,4,2,16,17,16,18,4,17,5,17,16,3,16,0,19,16,1,5,0,17,17,16,19,18,17,16,17,16,1,4,0,4,1,16,17]

theorem envBound9203 : H12AffineFastState.Bounded env9203 := by
  intro p hp
  have h : env9203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9202_9203 : H12AffineEnvironment.transform 2 2 env9202 = env9203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9202 == env9203) = true)

theorem identity9203 : scanCanonicalize (H12AffineFastState.compose env9203 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9203 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9204 : List Nat := [2,4,2,1,0,1,3,4,0,5,0,1,3,1,0,2,1,1,5,0,0,0,1,2,3,0,1,0,1,1,4,0,4,1,1,0]

theorem envBound9204 : H12AffineFastState.Bounded env9204 := by
  intro p hp
  have h : env9204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9203_9204 : H12AffineEnvironment.transform 3 1 env9203 = env9204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9203 == env9204) = true)

def env9205 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,73944,4764,8201,65,74371,4720,74449,8329,4096,74377,77946,77947,75786,4,545,4765,73770,78578,73971]

theorem envBound9205 : H12AffineFastState.Bounded env9205 := by
  intro p hp
  have h : env9205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9185_9205 : H12AffineEnvironment.transform 13 561 env9185 = env9205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9185 == env9205) = true)

theorem identity9205 : scanCanonicalize (H12AffineFastState.compose env9205 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9205 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9206 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,561,8201,65536,4096,73760,4708,8201,65,74363,4720,74281,8305,4096,74353,77946,77947,75786,4,545,4709,73770,78346,73739]

theorem envBound9206 : H12AffineFastState.Bounded env9206 := by
  intro p hp
  have h : env9206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9205_9206 : H12AffineEnvironment.transform 6 120 env9205 = env9206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9205 == env9206) = true)

theorem identity9206 : scanCanonicalize (H12AffineFastState.compose env9206 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound9206 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9207 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,561,8201,8251,4096,27,4708,8201,65,576,4720,530,8305,4096,586,4161,4160,2097,4,545,4709,17,4657,48]

theorem envBound9207 : H12AffineFastState.Bounded env9207 := by
  intro p hp
  have h : env9207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9206_9207 : H12AffineEnvironment.transform 15 8251 env9206 = env9207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env9206 == env9207) = true)

theorem identity9207 : scanCanonicalize (H12AffineFastState.compose env9207 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound9207 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9208 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,2587,8192,561,8201,8251,2587,27,2175,8201,65,576,2155,530,8305,2587,586,2650,2651,2097,4,545,2174,17,2090,48]

theorem envBound9208 : H12AffineFastState.Bounded env9208 := by
  intro p hp
  have h : env9208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9207_9208 : H12AffineEnvironment.transform 11 2587 env9207 = env9208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env9207 == env9208) = true)

theorem identity9208 : scanCanonicalize (H12AffineFastState.compose env9208 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound9208 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9209 : List Nat := [2,4,8,16,32,64,120,5,48,4,2048,2091,8192,1,8201,8251,2091,27,2175,8201,65,112,2155,34,8305,2091,122,2154,2155,2097,4,17,2174,17,2090,48]

theorem envBound9209 : H12AffineFastState.Bounded env9209 := by
  intro p hp
  have h : env9209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9208_9209 : H12AffineEnvironment.transform 8 48 env9208 = env9209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env9208 == env9209) = true)

theorem identity9209 : scanCanonicalize (H12AffineFastState.compose env9209 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9209 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9210 : List Nat := [2,4,8,16,32,16,40,5,48,4,2048,2091,8192,1,8201,8251,2091,27,2095,8201,17,32,2107,34,8225,2091,42,2106,2107,2097,4,17,2094,17,2090,48]

theorem envBound9210 : H12AffineFastState.Bounded env9210 := by
  intro p hp
  have h : env9210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9209_9210 : H12AffineEnvironment.transform 5 16 env9209 = env9210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9209 == env9210) = true)

theorem identity9210 : scanCanonicalize (H12AffineFastState.compose env9210 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound9210 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9211 : List Nat := [2,4,8,16,32,16,40,5,48,4,2048,2091,2088,1,2081,2067,2091,27,2095,2081,17,32,2107,34,2057,2091,42,2106,2107,2097,4,17,2094,17,2090,48]

theorem envBound9211 : H12AffineFastState.Bounded env9211 := by
  intro p hp
  have h : env9211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9210_9211 : H12AffineEnvironment.transform 12 2088 env9210 = env9211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env9210 == env9211) = true)

theorem identity9211 : scanCanonicalize (H12AffineFastState.compose env9211 (packedSelected [3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9211 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env9212 : List Nat := [2,4,8,16,32,16,40,5,48,4,43,0,3,1,10,56,0,27,4,10,17,32,16,34,34,0,42,17,16,26,4,17,5,17,1,48]

theorem envBound9212 : H12AffineFastState.Bounded env9212 := by
  intro p hp
  have h : env9212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9211_9212 : H12AffineEnvironment.transform 10 43 env9211 = env9212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9211 == env9212) = true)

theorem identity9212 : scanCanonicalize (H12AffineFastState.compose env9212 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound9212 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9213 : List Nat := [2,4,8,16,11,16,3,5,27,4,0,0,3,1,10,19,0,27,4,10,17,11,16,9,9,0,1,17,16,26,4,17,5,17,1,27]

theorem envBound9213 : H12AffineFastState.Bounded env9213 := by
  intro p hp
  have h : env9213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9212_9213 : H12AffineEnvironment.transform 4 11 env9212 = env9213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env9212 == env9213) = true)

def env9214 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,90337,8329,21040,807681,4735913,4735573,605034,529048,4796991,524289,602954,2695635,90942]

theorem envBound9214 : H12AffineFastState.Bounded env9214 := by
  intro p hp
  have h : env9214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9081_9214 : H12AffineEnvironment.transform 23 90337 env9081 = env9214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env9081 == env9214) = true)

def env9215 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5004,90337,8329,21040,278625,4214985,4215093,75786,504,4268383,4961,73770,2175667,90942]

theorem envBound9215 : H12AffineFastState.Bounded env9215 := by
  intro p hp
  have h : env9215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9214_9215 : H12AffineEnvironment.transform 18 4960 env9214 = env9215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env9214 == env9215) = true)

theorem identity9215 : scanCanonicalize (H12AffineFastState.compose env9215 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9215 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9216 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,2097152,4194304,4721,90337,8329,21040,278625,4214985,4214984,75786,5,4268194,4764,73770,2175667,90819]

theorem envBound9216 : H12AffineFastState.Bounded env9216 := by
  intro p hp
  have h : env9216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9215_9216 : H12AffineEnvironment.transform 7 253 env9215 = env9216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9215 == env9216) = true)

def env9217 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,64,4194304,4721,90337,8329,21040,278625,4214985,4214984,75786,5,4268194,4764,73770,78579,90819]

theorem envBound9217 : H12AffineFastState.Bounded env9217 := by
  intro p hp
  have h : env9217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9216_9217 : H12AffineEnvironment.transform 20 64 env9216 = env9217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9216 == env9217) = true)

theorem identity9217 : scanCanonicalize (H12AffineFastState.compose env9217 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 722) := by decide +kernel

theorem selectedBound9217 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9218 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,722,4765,8201,64,4194304,4721,90337,8329,21040,17075,4214985,4214984,75786,5,4268194,4764,73770,78579,90819]

theorem envBound9218 : H12AffineFastState.Bounded env9218 := by
  intro p hp
  have h : env9218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9217_9218 : H12AffineEnvironment.transform 17 722 env9217 = env9218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 722 env9217 == env9218) = true)

def env9219 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,722,4765,8201,64,16960,4721,90337,8329,21040,17075,4745,4744,75786,5,90850,4764,73770,78579,90819]

theorem envBound9219 : H12AffineFastState.Bounded env9219 := by
  intro p hp
  have h : env9219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9218_9219 : H12AffineEnvironment.transform 21 16960 env9218 = env9219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env9218 == env9219) = true)

def env9220 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,722,4765,8201,64,112,4721,74449,8329,4096,131,4745,4744,75786,5,73938,4764,73770,78579,73971]

theorem envBound9220 : H12AffineFastState.Bounded env9220 := by
  intro p hp
  have h : env9220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9219_9220 : H12AffineEnvironment.transform 13 560 env9219 = env9220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9219 == env9220) = true)

def env9221 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,722,4765,8201,64,113,4721,74448,8329,4097,130,4745,4744,75786,5,73939,4764,73770,78579,73970]

theorem envBound9221 : H12AffineFastState.Bounded env9221 := by
  intro p hp
  have h : env9221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9219_9221 : H12AffineEnvironment.transform 13 561 env9219 = env9221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9219 == env9221) = true)

theorem identity9221 : scanCanonicalize (H12AffineFastState.compose env9221 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9221 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9222 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,561,8201,65536,4096,554,4709,8201,64,113,4721,74280,8305,4097,122,4721,4720,75786,5,73771,4708,73770,78347,73738]

theorem envBound9222 : H12AffineFastState.Bounded env9222 := by
  intro p hp
  have h : env9222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9221_9222 : H12AffineEnvironment.transform 6 120 env9221 = env9222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9221 == env9222) = true)

theorem identity9222 : scanCanonicalize (H12AffineFastState.compose env9222 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 14944) := by decide +kernel

theorem selectedBound9222 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9223 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,4096,8192,561,8201,14944,4096,554,4709,8201,64,113,4721,6216,8305,4097,122,4721,4720,4714,5,6731,4708,6730,2155,6762]

theorem envBound9223 : H12AffineFastState.Bounded env9223 := by
  intro p hp
  have h : env9223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9222_9223 : H12AffineEnvironment.transform 15 14944 env9222 = env9223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14944 env9222 == env9223) = true)

theorem identity9223 : scanCanonicalize (H12AffineFastState.compose env9223 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound9223 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9224 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,2635,8192,561,8201,8235,2635,554,2094,8201,64,113,2106,515,8305,2634,122,2106,2107,2081,5,0,2095,1,2155,33]

theorem envBound9224 : H12AffineFastState.Bounded env9224 := by
  intro p hp
  have h : env9224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9223_9224 : H12AffineEnvironment.transform 11 2635 env9223 = env9224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env9223 == env9224) = true)

theorem identity9224 : scanCanonicalize (H12AffineFastState.compose env9224 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9224 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9225 : List Nat := [2,4,8,16,32,64,120,5,33,4,2048,2154,8192,16,8201,8235,2154,11,2094,8201,64,113,2106,34,8305,2155,122,2106,2107,2081,5,0,2095,1,2155,33]

theorem envBound9225 : H12AffineFastState.Bounded env9225 := by
  intro p hp
  have h : env9225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9224_9225 : H12AffineEnvironment.transform 8 33 env9224 = env9225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9224 == env9225) = true)

theorem identity9225 : scanCanonicalize (H12AffineFastState.compose env9225 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9225 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9226 : List Nat := [2,4,8,16,32,16,40,5,33,4,2048,2106,8192,16,8201,8235,2106,11,2094,8201,16,33,2106,34,8225,2107,42,2106,2107,2081,5,0,2095,1,2107,33]

theorem envBound9226 : H12AffineFastState.Bounded env9226 := by
  intro p hp
  have h : env9226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9225_9226 : H12AffineEnvironment.transform 5 16 env9225 = env9226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9225 == env9226) = true)

theorem identity9226 : scanCanonicalize (H12AffineFastState.compose env9226 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9226 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9227 : List Nat := [2,4,8,16,27,16,19,5,26,4,2048,2049,8192,16,8201,8208,2049,11,2069,8201,16,26,2049,25,8218,2048,17,2049,2048,2074,5,0,2068,1,2048,26]

theorem envBound9227 : H12AffineFastState.Bounded env9227 := by
  intro p hp
  have h : env9227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9226_9227 : H12AffineEnvironment.transform 4 27 env9226 = env9227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9226 == env9227) = true)

theorem identity9227 : scanCanonicalize (H12AffineFastState.compose env9227 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9227 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9228 : List Nat := [2,4,8,11,0,11,8,5,1,4,2048,2049,8192,11,8201,8203,2049,11,2062,8201,11,1,2049,2,8193,2048,10,2049,2048,2049,5,0,2063,1,2048,1]

theorem envBound9228 : H12AffineFastState.Bounded env9228 := by
  intro p hp
  have h : env9228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9227_9228 : H12AffineEnvironment.transform 3 11 env9227 = env9228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9227 == env9228) = true)

theorem identity9228 : scanCanonicalize (H12AffineFastState.compose env9228 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9228 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9229 : List Nat := [2,4,8,11,0,11,8,5,1,4,2048,2049,8,11,1,3,2049,11,2062,1,11,1,2049,2,9,2048,10,2049,2048,2049,5,0,2063,1,2048,1]

theorem envBound9229 : H12AffineFastState.Bounded env9229 := by
  intro p hp
  have h : env9229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9228_9229 : H12AffineEnvironment.transform 12 8 env9228 = env9229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9228 == env9229) = true)

theorem identity9229 : scanCanonicalize (H12AffineFastState.compose env9229 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound9229 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9230 : List Nat := [2,4,8,11,0,11,8,5,1,4,1,0,8,11,1,3,0,11,15,1,11,1,0,2,9,1,10,0,1,0,5,0,14,1,1,1]

theorem envBound9230 : H12AffineFastState.Bounded env9230 := by
  intro p hp
  have h : env9230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9229_9230 : H12AffineEnvironment.transform 10 1 env9229 = env9230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9229 == env9230) = true)

theorem identity9230 : scanCanonicalize (H12AffineFastState.compose env9230 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9231 : List Nat := [2,4,2,1,0,1,2,5,1,4,1,0,2,1,1,3,0,1,5,1,1,1,0,2,3,1,0,0,1,0,5,0,4,1,1,1]

theorem envBound9231 : H12AffineFastState.Bounded env9231 := by
  intro p hp
  have h : env9231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9230_9231 : H12AffineEnvironment.transform 2 2 env9230 = env9231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9230 == env9231) = true)

def env9232 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,722,4765,8201,64,16961,4721,90337,8329,21040,17075,4744,4745,75786,5,90851,4764,73770,78579,90819]

theorem envBound9232 : H12AffineFastState.Bounded env9232 := by
  intro p hp
  have h : env9232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9218_9232 : H12AffineEnvironment.transform 21 16961 env9218 = env9232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env9218 == env9232) = true)

def env9233 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,722,4765,8201,64,113,4721,74449,8329,4096,131,4744,4745,75786,5,73939,4764,73770,78579,73971]

theorem envBound9233 : H12AffineFastState.Bounded env9233 := by
  intro p hp
  have h : env9233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9232_9233 : H12AffineEnvironment.transform 13 560 env9232 = env9233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9232 == env9233) = true)

theorem identity9233 : scanCanonicalize (H12AffineFastState.compose env9233 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8946) := by decide +kernel

theorem selectedBound9233 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9234 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,8946,4096,722,4765,8201,64,113,4721,35,8329,4096,131,4744,4745,2808,5,545,4764,728,4097,513]

theorem envBound9234 : H12AffineFastState.Bounded env9234 := by
  intro p hp
  have h : env9234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9233_9234 : H12AffineEnvironment.transform 15 8946 env9233 = env9234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8946 env9233 == env9234) = true)

theorem identity9234 : scanCanonicalize (H12AffineFastState.compose env9234 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2259) := by decide +kernel

theorem selectedBound9234 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9235 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,2259,8192,560,8201,8946,2259,722,2638,8201,64,113,2722,35,8329,2259,131,2651,2650,2808,5,545,2639,728,2258,513]

theorem envBound9235 : H12AffineFastState.Bounded env9235 := by
  intro p hp
  have h : env9235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9234_9235 : H12AffineEnvironment.transform 11 2259 env9234 = env9235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2259 env9234 == env9235) = true)

theorem identity9235 : scanCanonicalize (H12AffineFastState.compose env9235 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9235 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9236 : List Nat := [2,4,8,16,32,64,128,253,137,252,2048,2259,8192,185,8201,8315,2259,91,2247,8201,64,113,2091,35,8329,2259,131,2258,2259,2161,5,168,2246,81,2258,136]

theorem envBound9236 : H12AffineFastState.Bounded env9236 := by
  intro p hp
  have h : env9236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9235_9236 : H12AffineEnvironment.transform 8 137 env9235 = env9236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9235 == env9236) = true)

theorem identity9236 : scanCanonicalize (H12AffineFastState.compose env9236 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound9236 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9237 : List Nat := [2,4,8,16,32,64,105,20,96,21,2048,2106,8192,80,8201,8315,2106,91,2094,8201,64,113,2091,35,8288,2106,106,2107,2106,2161,5,65,2095,81,2107,97]

theorem envBound9237 : H12AffineFastState.Bounded env9237 := by
  intro p hp
  have h : env9237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9236_9237 : H12AffineEnvironment.transform 6 105 env9236 = env9237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env9236 == env9237) = true)

theorem identity9237 : scanCanonicalize (H12AffineFastState.compose env9237 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound9237 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env9238 : List Nat := [2,4,8,16,32,64,105,20,96,21,2048,2106,2098,80,2107,2121,2106,91,2094,2107,64,113,2091,35,2130,2106,106,2107,2106,2161,5,65,2095,81,2107,97]

theorem envBound9238 : H12AffineFastState.Bounded env9238 := by
  intro p hp
  have h : env9238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9237_9238 : H12AffineEnvironment.transform 12 2098 env9237 = env9238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env9237 == env9238) = true)

theorem identity9238 : scanCanonicalize (H12AffineFastState.compose env9238 (packedSelected [1,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 52) := by decide +kernel

theorem selectedBound9238 : packedSelected [1,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9239 : List Nat := [2,4,8,16,32,52,29,20,20,21,2048,2106,2098,36,2107,2109,2106,47,2094,2107,52,5,2091,35,2086,2106,30,2107,2106,2053,5,53,2095,37,2107,21]

theorem envBound9239 : H12AffineFastState.Bounded env9239 := by
  intro p hp
  have h : env9239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9238_9239 : H12AffineEnvironment.transform 5 52 env9238 = env9239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 52 env9238 == env9239) = true)

theorem identity9239 : scanCanonicalize (H12AffineFastState.compose env9239 (packedSelected [0,2,7,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound9239 : packedSelected [0,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env9240 : List Nat := [2,4,8,16,21,1,29,20,20,21,2048,2063,2055,17,2062,2056,2063,26,2075,2062,1,5,2078,22,2067,2063,30,2062,2063,2053,5,0,2074,16,2062,21]

theorem envBound9240 : H12AffineFastState.Bounded env9240 := by
  intro p hp
  have h : env9240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9239_9240 : H12AffineEnvironment.transform 4 21 env9239 = env9240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env9239 == env9240) = true)

theorem identity9240 : scanCanonicalize (H12AffineFastState.compose env9240 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound9240 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9241 : List Nat := [2,4,8,16,21,1,29,20,20,21,17,30,22,17,31,25,30,26,10,31,1,5,15,22,2,30,30,31,30,20,5,0,11,16,31,21]

theorem envBound9241 : H12AffineFastState.Bounded env9241 := by
  intro p hp
  have h : env9241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9240_9241 : H12AffineEnvironment.transform 10 17 env9240 = env9241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env9240 == env9241) = true)

theorem identity9241 : scanCanonicalize (H12AffineFastState.compose env9241 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound9241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9242 : List Nat := [2,4,8,4,1,1,9,0,0,1,5,10,2,5,11,13,10,14,10,11,1,5,15,2,2,10,10,11,10,0,5,0,11,4,11,1]

theorem envBound9242 : H12AffineFastState.Bounded env9242 := by
  intro p hp
  have h : env9242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9241_9242 : H12AffineEnvironment.transform 3 4 env9241 = env9242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env9241 == env9242) = true)

theorem identity9242 : scanCanonicalize (H12AffineFastState.compose env9242 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9243 : List Nat := [2,4,3,4,1,1,2,0,0,1,5,1,2,5,0,6,1,5,1,0,1,5,4,2,2,1,1,0,1,0,5,0,0,4,0,1]

theorem envBound9243 : H12AffineFastState.Bounded env9243 := by
  intro p hp
  have h : env9243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9242_9243 : H12AffineEnvironment.transform 2 3 env9242 = env9243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9242 == env9243) = true)

theorem identity9243 : scanCanonicalize (H12AffineFastState.compose env9243 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9244 : List Nat := [2,1,3,1,1,1,2,0,0,1,0,1,2,0,0,3,1,0,1,0,1,0,1,2,2,1,1,0,1,0,0,0,0,1,0,1]

theorem envBound9244 : H12AffineFastState.Bounded env9244 := by
  intro p hp
  have h : env9244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9243_9244 : H12AffineEnvironment.transform 1 1 env9243 = env9244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9243 == env9244) = true)

def env9245 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,722,4765,8201,64,112,4721,74448,8329,4097,130,4744,4745,75786,5,73938,4764,73770,78579,73970]

theorem envBound9245 : H12AffineFastState.Bounded env9245 := by
  intro p hp
  have h : env9245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9232_9245 : H12AffineEnvironment.transform 13 561 env9232 = env9245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9232 == env9245) = true)

theorem identity9245 : scanCanonicalize (H12AffineFastState.compose env9245 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound9245 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9246 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,8715,4096,722,4765,8201,64,112,4721,219,8329,4097,130,4744,4745,2561,5,729,4764,545,4344,761]

theorem envBound9246 : H12AffineFastState.Bounded env9246 := by
  intro p hp
  have h : env9246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9245_9246 : H12AffineEnvironment.transform 15 8715 env9245 = env9246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env9245 == env9246) = true)

theorem identity9246 : scanCanonicalize (H12AffineFastState.compose env9246 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9246 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9247 : List Nat := [2,4,8,16,32,64,128,253,136,252,2048,4096,8192,185,8201,8323,4096,90,4117,8201,64,112,4345,219,8329,4097,130,4096,4097,2185,5,81,4116,169,4344,113]

theorem envBound9247 : H12AffineFastState.Bounded env9247 := by
  intro p hp
  have h : env9247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9246_9247 : H12AffineEnvironment.transform 8 136 env9246 = env9247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9246 == env9247) = true)

theorem identity9247 : scanCanonicalize (H12AffineFastState.compose env9247 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9247 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9248 : List Nat := [2,4,8,16,32,64,121,4,113,5,2048,4096,8192,64,8201,8314,4096,90,4117,8201,64,112,4096,34,8304,4097,123,4096,4097,2160,5,81,4116,80,4097,113]

theorem envBound9248 : H12AffineFastState.Bounded env9248 := by
  intro p hp
  have h : env9248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9247_9248 : H12AffineEnvironment.transform 6 121 env9247 = env9248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9247 == env9248) = true)

theorem identity9248 : scanCanonicalize (H12AffineFastState.compose env9248 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound9248 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9249 : List Nat := [2,4,8,16,32,64,121,4,113,5,2048,4096,24,64,17,98,4096,90,4117,17,64,112,4096,34,104,4097,123,4096,4097,2160,5,81,4116,80,4097,113]

theorem envBound9249 : H12AffineFastState.Bounded env9249 := by
  intro p hp
  have h : env9249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9248_9249 : H12AffineEnvironment.transform 12 24 env9248 = env9249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env9248 == env9249) = true)

theorem identity9249 : scanCanonicalize (H12AffineFastState.compose env9249 (packedSelected [2,13,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9249 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9250 : List Nat := [2,4,8,16,32,17,40,4,32,5,2048,4096,24,17,17,51,4096,11,4117,17,17,33,4096,34,57,4097,42,4096,4097,2081,5,0,4116,1,4097,32]

theorem envBound9250 : H12AffineFastState.Bounded env9250 := by
  intro p hp
  have h : env9250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9249_9250 : H12AffineEnvironment.transform 5 17 env9249 = env9250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9249 == env9250) = true)

theorem identity9250 : scanCanonicalize (H12AffineFastState.compose env9250 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound9250 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9251 : List Nat := [2,4,8,16,32,17,40,4,32,5,2048,2065,24,17,17,51,2065,11,2052,17,17,33,2065,34,57,2064,42,2065,2064,2081,5,0,2053,1,2064,32]

theorem envBound9251 : H12AffineFastState.Bounded env9251 := by
  intro p hp
  have h : env9251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9250_9251 : H12AffineEnvironment.transform 11 2065 env9250 = env9251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env9250 == env9251) = true)

theorem identity9251 : scanCanonicalize (H12AffineFastState.compose env9251 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9251 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9252 : List Nat := [2,4,8,16,32,17,40,4,32,5,43,58,24,17,17,51,58,11,47,17,17,33,58,34,57,59,42,58,59,10,5,0,46,1,59,32]

theorem envBound9252 : H12AffineFastState.Bounded env9252 := by
  intro p hp
  have h : env9252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9251_9252 : H12AffineEnvironment.transform 10 43 env9251 = env9252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9251 == env9252) = true)

theorem identity9252 : scanCanonicalize (H12AffineFastState.compose env9252 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9252 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env9253 : List Nat := [2,4,8,11,32,10,40,4,32,5,43,33,3,10,10,40,33,11,47,10,10,33,33,34,34,32,42,33,32,10,5,0,46,1,32,32]

theorem envBound9253 : H12AffineFastState.Bounded env9253 := by
  intro p hp
  have h : env9253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9252_9253 : H12AffineEnvironment.transform 3 11 env9252 = env9253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9252 == env9253) = true)

theorem identity9253 : scanCanonicalize (H12AffineFastState.compose env9253 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9254 : List Nat := [2,4,8,11,1,10,9,4,1,5,10,0,3,10,10,9,0,11,14,10,10,0,0,3,3,1,11,0,1,10,5,0,15,1,1,1]

theorem envBound9254 : H12AffineFastState.Bounded env9254 := by
  intro p hp
  have h : env9254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9253_9254 : H12AffineEnvironment.transform 4 1 env9253 = env9254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9253 == env9254) = true)

theorem identity9254 : scanCanonicalize (H12AffineFastState.compose env9254 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9255 : List Nat := [2,4,3,0,1,1,2,4,1,5,1,0,3,1,1,2,0,0,5,1,1,0,0,3,3,1,0,0,1,1,5,0,4,1,1,1]

theorem envBound9255 : H12AffineFastState.Bounded env9255 := by
  intro p hp
  have h : env9255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9254_9255 : H12AffineEnvironment.transform 2 3 env9254 = env9255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9254 == env9255) = true)

def env9256 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,65,4194304,4721,90337,8329,21040,278625,4214985,4214984,75786,5,4268194,4764,73770,78578,90819]

theorem envBound9256 : H12AffineFastState.Bounded env9256 := by
  intro p hp
  have h : env9256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9216_9256 : H12AffineEnvironment.transform 20 65 env9216 = env9256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9216 == env9256) = true)

theorem identity9256 : scanCanonicalize (H12AffineFastState.compose env9256 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4275) := by decide +kernel

theorem selectedBound9256 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9257 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,4275,4765,8201,65,4194304,4721,90337,8329,21040,20690,4214985,4214984,75786,5,4268194,4764,73770,78578,90819]

theorem envBound9257 : H12AffineFastState.Bounded env9257 := by
  intro p hp
  have h : env9257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9256_9257 : H12AffineEnvironment.transform 17 4275 env9256 = env9257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4275 env9256 == env9257) = true)

def env9258 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8201,65536,4096,4107,4645,8201,65,4194304,4721,90201,8241,21040,20586,4214897,4214896,75786,5,4268058,4644,73770,78410,90747]

theorem envBound9258 : H12AffineFastState.Bounded env9258 := by
  intro p hp
  have h : env9258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9257_9258 : H12AffineEnvironment.transform 6 56 env9257 = env9258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env9257 == env9258) = true)

theorem identity9258 : scanCanonicalize (H12AffineFastState.compose env9258 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 4128) := by decide +kernel

theorem selectedBound9258 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9259 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8201,65536,4096,4107,4645,8201,65,4128,4721,90201,8241,21040,20586,16465,16464,75786,5,77882,4644,73770,78410,90747]

theorem envBound9259 : H12AffineFastState.Bounded env9259 := by
  intro p hp
  have h : env9259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9258_9259 : H12AffineEnvironment.transform 21 4128 env9258 = env9259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4128 env9258 == env9259) = true)

def env9260 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4704,8201,65536,4096,4107,4645,8201,65,4128,4721,78393,8241,80,522,4657,4656,75786,5,77882,4644,73770,78410,77851]

theorem envBound9260 : H12AffineFastState.Bounded env9260 := by
  intro p hp
  have h : env9260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9259_9260 : H12AffineEnvironment.transform 13 4704 env9259 = env9260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4704 env9259 == env9260) = true)

theorem identity9260 : scanCanonicalize (H12AffineFastState.compose env9260 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound9260 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env9261 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4704,8201,8314,4096,4107,4645,8201,65,4128,4721,4675,8241,80,522,4657,4656,2160,5,4160,4644,80,4656,4193]

theorem envBound9261 : H12AffineFastState.Bounded env9261 := by
  intro p hp
  have h : env9261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9260_9261 : H12AffineEnvironment.transform 15 8314 env9260 = env9261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env9260 == env9261) = true)

theorem identity9261 : scanCanonicalize (H12AffineFastState.compose env9261 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9261 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9262 : List Nat := [2,4,8,16,32,64,56,69,512,68,58,4096,8192,4704,8201,8314,4096,4107,4645,8201,65,4128,4721,4675,8241,80,522,4657,4656,74,5,4160,4644,80,4656,4193]

theorem envBound9262 : H12AffineFastState.Bounded env9262 := by
  intro p hp
  have h : env9262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9261_9262 : H12AffineEnvironment.transform 10 58 env9261 = env9262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9261 == env9262) = true)

theorem identity9262 : scanCanonicalize (H12AffineFastState.compose env9262 (packedSelected [1,3,4,5,8,9,10,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9262 : packedSelected [1,3,4,5,8,9,10,19,20] rootPS < 2^1333 := by decide +kernel

def env9263 : List Nat := [2,4,8,16,32,64,56,69,512,68,58,16,8192,624,8201,8314,16,27,565,8201,65,48,609,595,8241,80,522,545,544,74,5,80,564,80,544,113]

theorem envBound9263 : H12AffineFastState.Bounded env9263 := by
  intro p hp
  have h : env9263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9262_9263 : H12AffineEnvironment.transform 11 16 env9262 = env9263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9262 == env9263) = true)

theorem identity9263 : scanCanonicalize (H12AffineFastState.compose env9263 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9263 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9264 : List Nat := [2,4,8,0,32,64,40,69,512,68,42,0,8192,608,8201,8298,0,11,549,8201,65,32,609,579,8225,64,522,545,544,74,5,64,548,64,544,97]

theorem envBound9264 : H12AffineFastState.Bounded env9264 := by
  intro p hp
  have h : env9264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9263_9264 : H12AffineEnvironment.transform 3 0 env9263 = env9264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9263 == env9264) = true)

theorem identity9264 : scanCanonicalize (H12AffineFastState.compose env9264 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound9264 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env9265 : List Nat := [2,4,8,0,32,64,40,69,512,68,42,0,9,608,0,99,0,11,549,0,65,32,609,579,40,64,522,545,544,74,5,64,548,64,544,97]

theorem envBound9265 : H12AffineFastState.Bounded env9265 := by
  intro p hp
  have h : env9265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9264_9265 : H12AffineEnvironment.transform 12 9 env9264 = env9265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env9264 == env9265) = true)

theorem identity9265 : scanCanonicalize (H12AffineFastState.compose env9265 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound9265 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env9266 : List Nat := [2,4,8,0,11,64,3,69,512,68,1,0,9,587,0,72,0,11,526,0,65,11,586,579,3,64,522,522,523,74,5,64,527,64,523,74]

theorem envBound9266 : H12AffineFastState.Bounded env9266 := by
  intro p hp
  have h : env9266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9265_9266 : H12AffineEnvironment.transform 4 11 env9265 = env9266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env9265 == env9266) = true)

theorem identity9266 : scanCanonicalize (H12AffineFastState.compose env9266 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9266 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9267 : List Nat := [2,4,8,0,11,10,3,15,512,14,1,0,9,513,0,2,0,11,526,0,11,11,512,521,3,10,522,522,523,0,5,10,527,10,523,0]

theorem envBound9267 : H12AffineFastState.Bounded env9267 := by
  intro p hp
  have h : env9267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9266_9267 : H12AffineEnvironment.transform 5 10 env9266 = env9267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9266 == env9267) = true)

theorem identity9267 : scanCanonicalize (H12AffineFastState.compose env9267 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound9267 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9268 : List Nat := [2,4,8,0,11,10,3,15,1,14,1,0,9,0,0,2,0,11,15,0,11,11,1,8,3,10,11,11,10,0,5,10,14,10,10,0]

theorem envBound9268 : H12AffineFastState.Bounded env9268 := by
  intro p hp
  have h : env9268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9267_9268 : H12AffineEnvironment.transform 8 1 env9267 = env9268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env9267 == env9268) = true)

theorem identity9268 : scanCanonicalize (H12AffineFastState.compose env9268 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9269 : List Nat := [2,4,3,0,0,1,3,4,1,5,1,0,2,0,0,2,0,0,4,0,0,0,1,3,3,1,0,0,1,0,5,1,5,1,1,0]

theorem envBound9269 : H12AffineFastState.Bounded env9269 := by
  intro p hp
  have h : env9269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9268_9269 : H12AffineEnvironment.transform 2 3 env9268 = env9269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9268 == env9269) = true)

theorem identity9269 : scanCanonicalize (H12AffineFastState.compose env9269 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9270 : List Nat := [2,1,3,0,0,1,3,1,1,0,1,0,2,0,0,2,0,0,1,0,0,0,1,3,3,1,0,0,1,0,0,1,0,1,1,0]

theorem envBound9270 : H12AffineFastState.Bounded env9270 := by
  intro p hp
  have h : env9270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9269_9270 : H12AffineEnvironment.transform 1 1 env9269 = env9270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9269 == env9270) = true)

def env9271 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4705,8201,65536,4096,4107,4645,8201,65,4128,4721,78392,8241,81,523,4656,4657,75786,5,77882,4644,73770,78410,77850]

theorem envBound9271 : H12AffineFastState.Bounded env9271 := by
  intro p hp
  have h : env9271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9259_9271 : H12AffineEnvironment.transform 13 4705 env9259 = env9271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4705 env9259 == env9271) = true)

theorem identity9271 : scanCanonicalize (H12AffineFastState.compose env9271 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound9271 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env9272 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,4705,8201,8714,4096,4107,4645,8201,65,4128,4721,4146,8241,81,523,4656,4657,2560,5,4656,4644,544,4160,4624]

theorem envBound9272 : H12AffineFastState.Bounded env9272 := by
  intro p hp
  have h : env9272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9271_9272 : H12AffineEnvironment.transform 15 8714 env9271 = env9272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env9271 == env9272) = true)

theorem identity9272 : scanCanonicalize (H12AffineFastState.compose env9272 (packedSelected [2,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound9272 : packedSelected [2,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env9273 : List Nat := [2,4,8,16,32,64,56,69,113,68,2048,4096,8192,4112,8201,8315,4096,4107,4180,8201,65,4128,4096,4146,8241,81,122,4161,4160,2161,5,4161,4181,81,4160,4193]

theorem envBound9273 : H12AffineFastState.Bounded env9273 := by
  intro p hp
  have h : env9273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9272_9273 : H12AffineEnvironment.transform 8 113 env9272 = env9273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env9272 == env9273) = true)

theorem identity9273 : scanCanonicalize (H12AffineFastState.compose env9273 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound9273 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env9274 : List Nat := [2,4,8,16,32,64,56,69,113,68,2048,2170,8192,2154,8201,8315,2170,2161,2094,8201,65,2138,2170,2120,8241,81,122,2107,2106,2161,5,2107,2095,81,2106,2075]

theorem envBound9274 : H12AffineFastState.Bounded env9274 := by
  intro p hp
  have h : env9274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9273_9274 : H12AffineEnvironment.transform 11 2170 env9273 = env9274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env9273 == env9274) = true)

theorem identity9274 : scanCanonicalize (H12AffineFastState.compose env9274 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound9274 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env9275 : List Nat := [2,4,8,16,32,64,56,69,113,68,2048,2170,2083,2154,2090,2136,2170,2161,2094,2090,65,2138,2170,2120,2066,81,122,2107,2106,2161,5,2107,2095,81,2106,2075]

theorem envBound9275 : H12AffineFastState.Bounded env9275 := by
  intro p hp
  have h : env9275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9274_9275 : H12AffineEnvironment.transform 12 2083 env9274 = env9275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env9274 == env9275) = true)

theorem identity9275 : scanCanonicalize (H12AffineFastState.compose env9275 (packedSelected [2,4,5,8,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9275 : packedSelected [2,4,5,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9276 : List Nat := [2,4,8,16,32,0,56,5,49,4,2048,2106,2083,2090,2090,2072,2106,2097,2094,2090,1,2074,2106,2056,2066,17,58,2107,2106,2097,5,2107,2095,17,2106,2075]

theorem envBound9276 : H12AffineFastState.Bounded env9276 := by
  intro p hp
  have h : env9276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9275_9276 : H12AffineEnvironment.transform 5 0 env9275 = env9276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9275 == env9276) = true)

theorem identity9276 : scanCanonicalize (H12AffineFastState.compose env9276 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9276 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9277 : List Nat := [2,4,2,16,32,0,50,5,49,4,2048,2096,2083,2080,2080,2066,2096,2097,2084,2080,1,2064,2096,2050,2066,17,48,2097,2096,2097,5,2097,2085,17,2096,2065]

theorem envBound9277 : H12AffineFastState.Bounded env9277 := by
  intro p hp
  have h : env9277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9276_9277 : H12AffineEnvironment.transform 2 2 env9276 = env9277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9276 == env9277) = true)

theorem identity9277 : scanCanonicalize (H12AffineFastState.compose env9277 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9278 : List Nat := [2,4,2,16,16,0,2,5,1,4,2048,2048,2067,2064,2064,2066,2048,2049,2068,2064,1,2064,2048,2050,2066,17,0,2049,2048,2049,5,2049,2069,17,2048,2065]

theorem envBound9278 : H12AffineFastState.Bounded env9278 := by
  intro p hp
  have h : env9278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9277_9278 : H12AffineEnvironment.transform 4 16 env9277 = env9278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9277 == env9278) = true)

def env9279 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8201,65536,4096,4106,4644,8201,65,4194304,4721,90200,8240,21040,20587,4214896,4214897,75786,5,4268059,4645,73770,78411,90746]

theorem envBound9279 : H12AffineFastState.Bounded env9279 := by
  intro p hp
  have h : env9279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9257_9279 : H12AffineEnvironment.transform 6 57 env9257 = env9279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9257 == env9279) = true)

theorem identity9279 : scanCanonicalize (H12AffineFastState.compose env9279 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 28779) := by decide +kernel

theorem selectedBound9279 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env9280 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8201,28779,4096,4106,4644,8201,65,4194304,4721,4147,8240,21040,20587,4214896,4214897,22625,5,4214896,4645,20545,16928,4625]

theorem envBound9280 : H12AffineFastState.Bounded env9280 := by
  intro p hp
  have h : env9280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9279_9280 : H12AffineEnvironment.transform 15 28779 env9279 = env9280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28779 env9279 == env9280) = true)

def env9281 : List Nat := [2,4,8,16,32,0,57,4,512,5,2048,4096,8192,16384,8201,28715,4096,4106,4644,8201,1,4194304,4657,4147,8240,21040,20523,4214832,4214833,22561,5,4214832,4645,20481,16928,4625]

theorem envBound9281 : H12AffineFastState.Bounded env9281 := by
  intro p hp
  have h : env9281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9280_9281 : H12AffineEnvironment.transform 5 0 env9280 = env9281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9280 == env9281) = true)

theorem identity9281 : scanCanonicalize (H12AffineFastState.compose env9281 (packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9281 : packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env9282 : List Nat := [2,4,8,16,32,0,57,4,512,5,58,4096,8192,16384,8201,28715,4096,4106,4644,8201,1,4194304,4657,4147,8240,21040,20523,4214832,4214833,20507,5,4214832,4645,20481,16928,4625]

theorem envBound9282 : H12AffineFastState.Bounded env9282 := by
  intro p hp
  have h : env9282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9281_9282 : H12AffineEnvironment.transform 10 58 env9281 = env9282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9281 == env9282) = true)

theorem identity9282 : scanCanonicalize (H12AffineFastState.compose env9282 (packedSelected [0,2,3,5,7,8,11,12,13,14,15,20,21,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound9282 : packedSelected [0,2,3,5,7,8,11,12,13,14,15,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env9283 : List Nat := [2,4,8,16,32,0,57,4,512,5,58,4096,8192,4113,8201,8250,4096,4106,4644,8201,1,4194304,4657,4147,8240,545,58,4194337,4194336,10,5,4194337,4645,16,4657,4625]

theorem envBound9283 : H12AffineFastState.Bounded env9283 := by
  intro p hp
  have h : env9283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9282_9283 : H12AffineEnvironment.transform 13 4113 env9282 = env9283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env9282 == env9283) = true)

theorem identity9283 : scanCanonicalize (H12AffineFastState.compose env9283 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound9283 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9284 : List Nat := [2,4,8,16,32,0,57,4,32,5,58,4096,8192,4113,8201,8250,4096,4106,4100,8201,1,4194304,4113,4147,8240,1,58,4194337,4194336,10,5,4194337,4101,16,4113,4145]

theorem envBound9284 : H12AffineFastState.Bounded env9284 := by
  intro p hp
  have h : env9284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9283_9284 : H12AffineEnvironment.transform 8 32 env9283 = env9284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env9283 == env9284) = true)

theorem identity9284 : scanCanonicalize (H12AffineFastState.compose env9284 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 4144) := by decide +kernel

theorem selectedBound9284 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env9285 : List Nat := [2,4,8,16,32,0,57,4,32,5,58,4096,8192,4113,8201,8250,4096,4106,4100,8201,1,4144,4113,4147,8240,1,58,4113,4112,10,5,4113,4101,16,4113,4145]

theorem envBound9285 : H12AffineFastState.Bounded env9285 := by
  intro p hp
  have h : env9285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9284_9285 : H12AffineEnvironment.transform 21 4144 env9284 = env9285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4144 env9284 == env9285) = true)

theorem identity9285 : scanCanonicalize (H12AffineFastState.compose env9285 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound9285 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9286 : List Nat := [2,4,8,16,32,0,57,4,32,5,58,17,8192,0,8201,8250,17,27,21,8201,1,33,0,34,8240,1,58,0,1,10,5,0,20,16,0,32]

theorem envBound9286 : H12AffineFastState.Bounded env9286 := by
  intro p hp
  have h : env9286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9285_9286 : H12AffineEnvironment.transform 11 17 env9285 = env9286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9285 == env9286) = true)

theorem identity9286 : scanCanonicalize (H12AffineFastState.compose env9286 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9286 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9287 : List Nat := [2,4,8,10,32,0,35,4,32,5,32,11,8192,0,8201,8224,11,1,15,8201,1,33,0,34,8234,1,32,0,1,10,5,0,14,10,0,32]

theorem envBound9287 : H12AffineFastState.Bounded env9287 := by
  intro p hp
  have h : env9287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9286_9287 : H12AffineEnvironment.transform 3 10 env9286 = env9287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9286 == env9287) = true)

theorem identity9287 : scanCanonicalize (H12AffineFastState.compose env9287 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound9287 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9288 : List Nat := [2,4,8,10,32,0,35,4,32,5,32,11,41,0,32,9,11,1,15,32,1,33,0,34,3,1,32,0,1,10,5,0,14,10,0,32]

theorem envBound9288 : H12AffineFastState.Bounded env9288 := by
  intro p hp
  have h : env9288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9287_9288 : H12AffineEnvironment.transform 12 41 env9287 = env9288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env9287 == env9288) = true)

theorem identity9288 : scanCanonicalize (H12AffineFastState.compose env9288 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9288 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9289 : List Nat := [2,4,8,10,10,0,9,4,10,5,10,11,3,0,10,9,11,1,15,10,1,11,0,8,3,1,10,0,1,10,5,0,14,10,0,10]

theorem envBound9289 : H12AffineFastState.Bounded env9289 := by
  intro p hp
  have h : env9289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9288_9289 : H12AffineEnvironment.transform 4 10 env9288 = env9289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9288 == env9289) = true)

def env9290 : List Nat := [2,4,8,16,32,1,57,5,512,4,2048,4096,8192,16384,8201,28714,4096,4106,4644,8201,0,4194304,4656,4147,8240,21040,20522,4214833,4214832,22560,5,4214833,4645,20480,16928,4625]

theorem envBound9290 : H12AffineFastState.Bounded env9290 := by
  intro p hp
  have h : env9290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9280_9290 : H12AffineEnvironment.transform 5 1 env9280 = env9290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9280 == env9290) = true)

theorem identity9290 : scanCanonicalize (H12AffineFastState.compose env9290 (packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 16913) := by decide +kernel

theorem selectedBound9290 : packedSelected [1,4,5,9,10,11,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env9291 : List Nat := [2,4,8,16,32,1,57,5,512,4,2048,4096,8192,16384,8201,28714,4096,4106,4644,8201,0,16913,4656,4147,8240,21040,20522,4640,4641,22560,5,4640,4645,20480,16928,4625]

theorem envBound9291 : H12AffineFastState.Bounded env9291 := by
  intro p hp
  have h : env9291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9290_9291 : H12AffineEnvironment.transform 21 16913 env9290 = env9291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16913 env9290 == env9291) = true)

theorem identity9291 : scanCanonicalize (H12AffineFastState.compose env9291 (packedSelected [0,1,7,8,13,14,17,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound9291 : packedSelected [0,1,7,8,13,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env9292 : List Nat := [2,4,8,16,32,1,57,5,512,4,2048,2090,8192,16384,8201,26624,2090,2080,2574,8201,0,16913,2586,2073,8240,18970,18432,2570,2571,16394,5,2570,2575,18474,16928,2619]

theorem envBound9292 : H12AffineFastState.Bounded env9292 := by
  intro p hp
  have h : env9292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9291_9292 : H12AffineEnvironment.transform 11 2090 env9291 = env9292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env9291 == env9292) = true)

theorem identity9292 : scanCanonicalize (H12AffineFastState.compose env9292 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound9292 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9293 : List Nat := [2,4,8,16,32,1,57,5,512,4,58,16,8192,16384,8201,24634,16,26,564,8201,0,16913,544,35,8240,16928,16442,560,561,16394,5,560,565,16400,16928,513]

theorem envBound9293 : H12AffineFastState.Bounded env9293 := by
  intro p hp
  have h : env9293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9292_9293 : H12AffineEnvironment.transform 10 58 env9292 = env9293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env9292 == env9293) = true)

theorem identity9293 : scanCanonicalize (H12AffineFastState.compose env9293 (packedSelected [3,5,8,10,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 63) := by decide +kernel

theorem selectedBound9293 : packedSelected [3,5,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env9294 : List Nat := [2,4,8,16,32,1,57,5,512,4,58,16,8192,63,8201,8197,16,26,564,8201,0,558,544,35,8240,543,5,560,561,53,5,560,565,47,543,513]

theorem envBound9294 : H12AffineFastState.Bounded env9294 := by
  intro p hp
  have h : env9294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9293_9294 : H12AffineEnvironment.transform 13 63 env9293 = env9294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 63 env9293 == env9294) = true)

theorem identity9294 : scanCanonicalize (H12AffineFastState.compose env9294 (packedSelected [8,11,12,13,17] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound9294 : packedSelected [8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env9295 : List Nat := [2,4,8,16,31,1,6,5,512,4,5,16,8192,0,8201,8197,16,26,523,8201,0,529,543,28,8207,543,5,527,526,10,5,527,522,16,543,513]

theorem envBound9295 : H12AffineFastState.Bounded env9295 := by
  intro p hp
  have h : env9295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9294_9295 : H12AffineEnvironment.transform 4 31 env9294 = env9295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env9294 == env9295) = true)

theorem identity9295 : scanCanonicalize (H12AffineFastState.compose env9295 (packedSelected [0,1,2,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound9295 : packedSelected [0,1,2,7,10] rootPS < 2^1333 := by decide +kernel

def env9296 : List Nat := [2,4,8,16,31,1,6,5,31,4,5,16,8192,0,8201,8197,16,26,20,8201,0,14,0,28,8207,0,5,16,17,10,5,16,21,16,0,30]

theorem envBound9296 : H12AffineFastState.Bounded env9296 := by
  intro p hp
  have h : env9296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9295_9296 : H12AffineEnvironment.transform 8 31 env9295 = env9296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env9295 == env9296) = true)

def env9297 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5005,90337,8329,21040,278624,4214984,4215092,75787,505,4268382,4960,73771,2175666,90942]

theorem envBound9297 : H12AffineFastState.Bounded env9297 := by
  intro p hp
  have h : env9297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9214_9297 : H12AffineEnvironment.transform 18 4961 env9214 = env9297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env9214 == env9297) = true)

theorem identity9297 : scanCanonicalize (H12AffineFastState.compose env9297 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9297 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9298 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,2097152,4194304,5005,34,8329,21040,278624,4214984,4215092,18632,505,4211101,4960,16616,2118257,1021]

theorem envBound9298 : H12AffineFastState.Bounded env9298 := by
  intro p hp
  have h : env9298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9297_9298 : H12AffineEnvironment.transform 15 24771 env9297 = env9298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9297 == env9298) = true)

def env9299 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,64,4194304,5005,34,8329,21040,278624,4214984,4215092,18632,505,4211101,4960,16616,21041,1021]

theorem envBound9299 : H12AffineFastState.Bounded env9299 := by
  intro p hp
  have h : env9299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9298_9299 : H12AffineEnvironment.transform 20 64 env9298 = env9299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9298 == env9299) = true)

theorem identity9299 : scanCanonicalize (H12AffineFastState.compose env9299 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 262819) := by decide +kernel

theorem selectedBound9299 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9300 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,64,262819,5005,34,8329,21040,278624,283243,283543,18632,505,279358,4960,16616,21041,1021]

theorem envBound9300 : H12AffineFastState.Bounded env9300 := by
  intro p hp
  have h : env9300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9299_9300 : H12AffineEnvironment.transform 21 262819 env9299 = env9300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262819 env9299 == env9300) = true)

def env9301 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8692,8947,4605,262144,4961,8692,64,262819,5005,34,8329,4096,262736,266331,266663,2808,505,262414,4960,728,4097,1021]

theorem envBound9301 : H12AffineFastState.Bounded env9301 := by
  intro p hp
  have h : env9301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9300_9301 : H12AffineEnvironment.transform 13 560 env9300 = env9301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9300 == env9301) = true)

def env9302 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8692,8235,4605,262144,4537,8692,64,262267,4437,34,8329,4096,262280,266331,266663,2080,505,262414,4536,0,4097,293]

theorem envBound9302 : H12AffineFastState.Bounded env9302 := by
  intro p hp
  have h : env9302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9301_9302 : H12AffineEnvironment.transform 8 216 env9301 = env9302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9301 == env9302) = true)

theorem identity9302 : scanCanonicalize (H12AffineFastState.compose env9302 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 422) := by decide +kernel

theorem selectedBound9302 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9303 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8692,8235,4605,422,4537,8692,64,477,4437,34,8329,4096,302,4605,4097,2080,505,168,4536,0,4097,293]

theorem envBound9303 : H12AffineFastState.Bounded env9303 := by
  intro p hp
  have h : env9303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9302_9303 : H12AffineEnvironment.transform 17 422 env9302 = env9303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 422 env9302 == env9303) = true)

theorem identity9303 : scanCanonicalize (H12AffineFastState.compose env9303 (packedSelected [1,3,4,9,12,14,18,20,23,38] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9303 : packedSelected [1,3,4,9,12,14,18,20,23,38] rootPS < 2^1333 := by decide +kernel

def env9304 : List Nat := [2,4,8,16,32,64,121,256,33,257,2048,4096,8192,17,8461,8235,4356,351,4416,8461,64,292,4437,34,8304,4096,302,4356,4097,2080,256,81,4417,0,4097,293]

theorem envBound9304 : H12AffineFastState.Bounded env9304 := by
  intro p hp
  have h : env9304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9303_9304 : H12AffineEnvironment.transform 6 121 env9303 = env9304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9303 == env9304) = true)

theorem identity9304 : scanCanonicalize (H12AffineFastState.compose env9304 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound9304 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9305 : List Nat := [2,4,8,16,32,64,121,256,33,257,2048,2154,8192,17,8461,8235,2414,351,2346,8461,64,292,2367,34,8304,2154,302,2414,2155,2080,256,81,2347,0,2155,293]

theorem envBound9305 : H12AffineFastState.Bounded env9305 := by
  intro p hp
  have h : env9305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9304_9305 : H12AffineEnvironment.transform 11 2154 env9304 = env9305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env9304 == env9305) = true)

theorem identity9305 : scanCanonicalize (H12AffineFastState.compose env9305 (packedSelected [2,3,5,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9305 : packedSelected [2,3,5,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env9306 : List Nat := [2,4,8,16,32,64,121,4,33,5,2048,2154,8192,17,8201,8235,2154,91,2094,8201,64,32,2107,34,8304,2154,42,2154,2155,2080,4,81,2095,0,2155,33]

theorem envBound9306 : H12AffineFastState.Bounded env9306 := by
  intro p hp
  have h : env9306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9305_9306 : H12AffineEnvironment.transform 7 4 env9305 = env9306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9305 == env9306) = true)

theorem identity9306 : scanCanonicalize (H12AffineFastState.compose env9306 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9306 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9307 : List Nat := [2,4,8,16,32,16,41,4,33,5,2048,2106,8192,17,8201,8235,2106,11,2094,8201,16,32,2107,34,8224,2106,42,2106,2107,2080,4,1,2095,0,2107,33]

theorem envBound9307 : H12AffineFastState.Bounded env9307 := by
  intro p hp
  have h : env9307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9306_9307 : H12AffineEnvironment.transform 5 16 env9306 = env9307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9306 == env9307) = true)

theorem identity9307 : scanCanonicalize (H12AffineFastState.compose env9307 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound9307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9308 : List Nat := [2,4,8,16,32,16,41,4,33,5,2048,2106,2073,17,2064,2098,2106,11,2094,2064,16,32,2107,34,2105,2106,42,2106,2107,2080,4,1,2095,0,2107,33]

theorem envBound9308 : H12AffineFastState.Bounded env9308 := by
  intro p hp
  have h : env9308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9307_9308 : H12AffineEnvironment.transform 12 2073 env9307 = env9308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env9307 == env9308) = true)

theorem identity9308 : scanCanonicalize (H12AffineFastState.compose env9308 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9308 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9309 : List Nat := [2,4,8,16,17,16,24,4,16,5,2048,2059,2073,17,2064,2051,2059,11,2079,2064,16,17,2058,19,2056,2059,27,2059,2058,2065,4,1,2078,0,2058,16]

theorem envBound9309 : H12AffineFastState.Bounded env9309 := by
  intro p hp
  have h : env9309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9308_9309 : H12AffineEnvironment.transform 4 17 env9308 = env9309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9308 == env9309) = true)

theorem identity9309 : scanCanonicalize (H12AffineFastState.compose env9309 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound9309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9310 : List Nat := [2,4,8,16,17,16,24,4,16,5,0,11,25,17,16,3,11,11,31,16,16,17,10,19,8,11,27,11,10,17,4,1,30,0,10,16]

theorem envBound9310 : H12AffineFastState.Bounded env9310 := by
  intro p hp
  have h : env9310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9309_9310 : H12AffineEnvironment.transform 10 0 env9309 = env9310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9309 == env9310) = true)

theorem identity9310 : scanCanonicalize (H12AffineFastState.compose env9310 (packedSelected [4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9310 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env9311 : List Nat := [2,4,8,1,0,1,9,4,1,5,0,11,8,0,1,3,11,11,14,1,1,0,10,2,8,11,10,11,10,0,4,1,15,0,10,1]

theorem envBound9311 : H12AffineFastState.Bounded env9311 := by
  intro p hp
  have h : env9311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9310_9311 : H12AffineEnvironment.transform 3 1 env9310 = env9311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9310 == env9311) = true)

theorem identity9311 : scanCanonicalize (H12AffineFastState.compose env9311 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9311 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9312 : List Nat := [2,4,2,1,0,1,3,4,1,5,0,1,2,0,1,3,1,1,4,1,1,0,0,2,2,1,0,1,0,0,4,1,5,0,0,1]

theorem envBound9312 : H12AffineFastState.Bounded env9312 := by
  intro p hp
  have h : env9312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9311_9312 : H12AffineEnvironment.transform 2 2 env9311 = env9312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9311 == env9312) = true)

def env9313 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8692,8234,4605,262144,4536,8692,64,262266,4436,34,8329,4096,262281,266331,266663,2081,505,262414,4537,1,4097,292]

theorem envBound9313 : H12AffineFastState.Bounded env9313 := by
  intro p hp
  have h : env9313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9301_9313 : H12AffineEnvironment.transform 8 217 env9301 = env9313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9301 == env9313) = true)

theorem identity9313 : scanCanonicalize (H12AffineFastState.compose env9313 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9313 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9314 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,233,8352,8234,4265,262144,4332,8352,64,262266,4096,34,8329,4096,262281,266331,266483,2081,173,262234,4333,1,4097,112]

theorem envBound9314 : H12AffineFastState.Bounded env9314 := by
  intro p hp
  have h : env9314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9313_9314 : H12AffineEnvironment.transform 7 84 env9313 = env9314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9313 == env9314) = true)

theorem identity9314 : scanCanonicalize (H12AffineFastState.compose env9314 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9314 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9315 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,4096,8192,64,8201,8234,4096,262144,4165,8201,64,262266,4096,34,8224,4096,262176,266331,266330,2081,4,262234,4164,1,4097,112]

theorem envBound9315 : H12AffineFastState.Bounded env9315 := by
  intro p hp
  have h : env9315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9314_9315 : H12AffineEnvironment.transform 6 41 env9314 = env9315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9314 == env9315) = true)

theorem identity9315 : scanCanonicalize (H12AffineFastState.compose env9315 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound9315 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9316 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,4096,8192,64,8201,8234,4096,90,4165,8201,64,32,4096,34,8224,4096,122,4097,4096,2081,4,0,4164,1,4097,112]

theorem envBound9316 : H12AffineFastState.Bounded env9316 := by
  intro p hp
  have h : env9316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9315_9316 : H12AffineEnvironment.transform 17 90 env9315 = env9316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env9315 == env9316) = true)

theorem identity9316 : scanCanonicalize (H12AffineFastState.compose env9316 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9316 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env9317 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,4096,8,64,1,34,4096,90,4165,1,64,32,4096,34,40,4096,122,4097,4096,2081,4,0,4164,1,4097,112]

theorem envBound9317 : H12AffineFastState.Bounded env9317 := by
  intro p hp
  have h : env9317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9316_9317 : H12AffineEnvironment.transform 12 8 env9316 = env9317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9316 == env9317) = true)

theorem identity9317 : scanCanonicalize (H12AffineFastState.compose env9317 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9317 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9318 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,16,8,64,1,34,16,90,85,1,64,32,16,34,40,16,122,17,16,2081,4,0,84,1,17,112]

theorem envBound9318 : H12AffineFastState.Bounded env9318 := by
  intro p hp
  have h : env9318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9317_9318 : H12AffineEnvironment.transform 11 16 env9317 = env9318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9317 == env9318) = true)

theorem identity9318 : scanCanonicalize (H12AffineFastState.compose env9318 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound9318 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9319 : List Nat := [2,4,8,16,32,64,41,84,112,85,107,16,8,64,1,34,16,90,85,1,64,32,16,34,40,16,122,17,16,74,4,0,84,1,17,112]

theorem envBound9319 : H12AffineFastState.Bounded env9319 := by
  intro p hp
  have h : env9319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9318_9319 : H12AffineEnvironment.transform 10 107 env9318 = env9319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env9318 == env9319) = true)

theorem identity9319 : scanCanonicalize (H12AffineFastState.compose env9319 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9319 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9320 : List Nat := [2,4,8,16,26,64,19,84,74,85,81,16,8,64,1,24,16,90,85,1,64,26,16,24,18,16,64,17,16,74,4,0,84,1,17,74]

theorem envBound9320 : H12AffineFastState.Bounded env9320 := by
  intro p hp
  have h : env9320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9319_9320 : H12AffineEnvironment.transform 4 26 env9319 = env9320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9319 == env9320) = true)

theorem identity9320 : scanCanonicalize (H12AffineFastState.compose env9320 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9320 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9321 : List Nat := [2,4,8,16,26,16,19,4,26,5,1,16,8,16,1,24,16,10,5,1,16,26,16,24,18,16,16,17,16,26,4,0,4,1,17,26]

theorem envBound9321 : H12AffineFastState.Bounded env9321 := by
  intro p hp
  have h : env9321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9320_9321 : H12AffineEnvironment.transform 5 16 env9320 = env9321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9320 == env9321) = true)

def env9322 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8692,8946,4605,262144,4961,8692,64,262819,5005,34,8329,4097,262737,266330,266662,2809,505,262415,4960,729,4096,1021]

theorem envBound9322 : H12AffineFastState.Bounded env9322 := by
  intro p hp
  have h : env9322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9300_9322 : H12AffineEnvironment.transform 13 561 env9300 = env9322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9300 == env9322) = true)

def env9323 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8692,8234,4605,262144,4537,8692,64,262267,4437,34,8329,4097,262281,266330,266662,2081,505,262415,4536,1,4096,293]

theorem envBound9323 : H12AffineFastState.Bounded env9323 := by
  intro p hp
  have h : env9323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9322_9323 : H12AffineEnvironment.transform 8 216 env9322 = env9323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9322 == env9323) = true)

theorem identity9323 : scanCanonicalize (H12AffineFastState.compose env9323 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9323 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9324 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,233,8352,8234,4265,262144,4333,8352,64,262267,4097,34,8329,4097,262281,266330,266482,2081,173,262235,4332,1,4096,113]

theorem envBound9324 : H12AffineFastState.Bounded env9324 := by
  intro p hp
  have h : env9324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9323_9324 : H12AffineEnvironment.transform 7 84 env9323 = env9324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9323 == env9324) = true)

theorem identity9324 : scanCanonicalize (H12AffineFastState.compose env9324 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound9324 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9325 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,233,8352,8234,4265,91,4333,8352,64,32,4097,34,8329,4097,210,4097,4265,2081,173,0,4332,1,4096,113]

theorem envBound9325 : H12AffineFastState.Bounded env9325 := by
  intro p hp
  have h : env9325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9324_9325 : H12AffineEnvironment.transform 17 91 env9324 = env9325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env9324 == env9325) = true)

theorem identity9325 : scanCanonicalize (H12AffineFastState.compose env9325 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound9325 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9326 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,2107,8192,233,8352,8234,2194,91,2262,8352,64,32,2106,34,8329,2106,210,2106,2194,2081,173,0,2263,1,2107,113]

theorem envBound9326 : H12AffineFastState.Bounded env9326 := by
  intro p hp
  have h : env9326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9325_9326 : H12AffineEnvironment.transform 11 2107 env9325 = env9326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env9325 == env9326) = true)

theorem identity9326 : scanCanonicalize (H12AffineFastState.compose env9326 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9326 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9327 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,2107,8192,64,8201,8234,2107,91,2175,8201,64,32,2106,34,8224,2106,123,2106,2107,2081,4,0,2174,1,2107,113]

theorem envBound9327 : H12AffineFastState.Bounded env9327 := by
  intro p hp
  have h : env9327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9326_9327 : H12AffineEnvironment.transform 6 41 env9326 = env9327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9326 == env9327) = true)

theorem identity9327 : scanCanonicalize (H12AffineFastState.compose env9327 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 99) := by decide +kernel

theorem selectedBound9327 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9328 : List Nat := [2,4,8,16,32,64,41,84,113,85,2048,2107,99,64,106,73,2107,91,2175,106,64,32,2106,34,67,2106,123,2106,2107,2081,4,0,2174,1,2107,113]

theorem envBound9328 : H12AffineFastState.Bounded env9328 := by
  intro p hp
  have h : env9328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9327_9328 : H12AffineEnvironment.transform 12 99 env9327 = env9328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 99 env9327 == env9328) = true)

theorem identity9328 : scanCanonicalize (H12AffineFastState.compose env9328 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound9328 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env9329 : List Nat := [2,4,8,16,32,64,41,84,113,85,1,58,99,64,106,73,58,91,126,106,64,32,59,34,67,59,123,59,58,32,4,0,127,1,58,113]

theorem envBound9329 : H12AffineFastState.Bounded env9329 := by
  intro p hp
  have h : env9329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9328_9329 : H12AffineEnvironment.transform 10 1 env9328 = env9329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9328 == env9329) = true)

theorem identity9329 : scanCanonicalize (H12AffineFastState.compose env9329 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound9329 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9330 : List Nat := [2,4,8,16,32,58,41,46,11,47,1,58,25,58,16,51,58,33,4,16,58,32,59,34,57,59,1,59,58,32,4,0,5,1,58,11]

theorem envBound9330 : H12AffineFastState.Bounded env9330 := by
  intro p hp
  have h : env9330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9329_9330 : H12AffineEnvironment.transform 5 58 env9329 = env9330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env9329 == env9330) = true)

theorem identity9330 : scanCanonicalize (H12AffineFastState.compose env9330 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9330 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env9331 : List Nat := [2,4,8,1,32,43,41,46,11,47,1,43,8,43,1,34,43,33,4,1,43,32,42,34,40,42,1,42,43,32,4,0,5,1,43,11]

theorem envBound9331 : H12AffineFastState.Bounded env9331 := by
  intro p hp
  have h : env9331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9330_9331 : H12AffineEnvironment.transform 3 1 env9330 = env9331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9330 == env9331) = true)

theorem identity9331 : scanCanonicalize (H12AffineFastState.compose env9331 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9332 : List Nat := [2,4,3,1,32,32,34,37,0,36,1,32,3,32,1,34,32,33,4,1,32,32,33,34,35,33,1,33,32,32,4,0,5,1,32,0]

theorem envBound9332 : H12AffineFastState.Bounded env9332 := by
  intro p hp
  have h : env9332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9331_9332 : H12AffineEnvironment.transform 2 3 env9331 = env9332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9331 == env9332) = true)

theorem identity9332 : scanCanonicalize (H12AffineFastState.compose env9332 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9332 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9333 : List Nat := [2,4,3,1,0,0,2,5,0,4,1,0,3,0,1,2,0,1,4,1,0,0,1,2,3,1,1,1,0,0,4,0,5,1,0,0]

theorem envBound9333 : H12AffineFastState.Bounded env9333 := by
  intro p hp
  have h : env9333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9332_9333 : H12AffineEnvironment.transform 4 0 env9332 = env9333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9332 == env9333) = true)

def leafEnv9333 : List Nat := [2,4,3,1,0,0,2,5,0,4,1,0,3,0,1,2,0,1,4,1,0,0,1,2,4,3,1,1,1,1,0,0,4,0,5,1,4,3,0,0,1,1,0]

def active9333 : List Nat := [0,1]

def tree9333 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9333 : H12WitnessSearch.Good tree9333 := H12GlobalWitnessIndex.good

theorem leafIdentity9333 : H12AffineFastState.composeSystem env9333 rootObs = leafEnv9333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9333 rootObs == leafEnv9333) = true)

theorem terminalChecked9333 : H12PackedTerminal.terminalCheckFast leafEnv9333 active9333 tree9333 = true := by decide +kernel

def env9334 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8692,8235,4605,262144,4536,8692,64,262266,4436,34,8329,4097,262280,266330,266662,2080,505,262415,4537,0,4096,292]

theorem envBound9334 : H12AffineFastState.Bounded env9334 := by
  intro p hp
  have h : env9334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9322_9334 : H12AffineEnvironment.transform 8 217 env9322 = env9334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9322 == env9334) = true)

theorem identity9334 : scanCanonicalize (H12AffineFastState.compose env9334 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 423) := by decide +kernel

theorem selectedBound9334 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9335 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8692,8235,4605,423,4536,8692,64,477,4436,34,8329,4097,303,4605,4097,2080,505,168,4537,0,4096,292]

theorem envBound9335 : H12AffineFastState.Bounded env9335 := by
  intro p hp
  have h : env9335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9334_9335 : H12AffineEnvironment.transform 17 423 env9334 = env9335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 423 env9334 == env9335) = true)

theorem identity9335 : scanCanonicalize (H12AffineFastState.compose env9335 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9335 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9336 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,232,8352,8235,4265,243,4332,8352,64,137,4096,34,8329,4097,123,4265,4097,2080,173,168,4333,0,4096,112]

theorem envBound9336 : H12AffineFastState.Bounded env9336 := by
  intro p hp
  have h : env9336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9335_9336 : H12AffineEnvironment.transform 7 84 env9335 = env9336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9335 == env9336) = true)

theorem identity9336 : scanCanonicalize (H12AffineFastState.compose env9336 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6347) := by decide +kernel

theorem selectedBound9336 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9337 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,6347,232,6251,6368,4265,243,4332,6251,64,137,4096,34,6210,4097,123,4265,4097,2080,173,168,4333,0,4096,112]

theorem envBound9337 : H12AffineFastState.Bounded env9337 := by
  intro p hp
  have h : env9337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9336_9337 : H12AffineEnvironment.transform 12 6347 env9336 = env9337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6347 env9336 == env9337) = true)

theorem identity9337 : scanCanonicalize (H12AffineFastState.compose env9337 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound9337 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env9338 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,2091,224,232,64,203,2178,243,2247,64,64,137,2091,34,105,2090,123,2178,2090,2080,173,168,2246,0,2091,112]

theorem envBound9338 : H12AffineFastState.Bounded env9338 := by
  intro p hp
  have h : env9338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9337_9338 : H12AffineEnvironment.transform 11 2091 env9337 = env9338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env9337 == env9338) = true)

theorem identity9338 : scanCanonicalize (H12AffineFastState.compose env9338 (packedSelected [1,3,4,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound9338 : packedSelected [1,3,4,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env9339 : List Nat := [2,4,8,16,32,64,128,84,217,85,49,26,224,232,64,203,179,243,246,64,64,137,26,34,105,27,123,179,27,17,173,168,247,0,26,112]

theorem envBound9339 : H12AffineFastState.Bounded env9339 := by
  intro p hp
  have h : env9339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9338_9339 : H12AffineEnvironment.transform 10 49 env9338 = env9339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env9338 == env9339) = true)

theorem identity9339 : scanCanonicalize (H12AffineFastState.compose env9339 (packedSelected [0,1,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9339 : packedSelected [0,1,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9340 : List Nat := [2,4,8,16,26,64,128,84,217,85,11,26,218,210,64,203,137,201,204,64,64,137,26,24,83,27,65,137,27,17,151,146,205,0,26,74]

theorem envBound9340 : H12AffineFastState.Bounded env9340 := by
  intro p hp
  have h : env9340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9339_9340 : H12AffineEnvironment.transform 4 26 env9339 = env9340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9339 == env9340) = true)

theorem identity9340 : scanCanonicalize (H12AffineFastState.compose env9340 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9340 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9341 : List Nat := [2,4,8,11,1,64,128,79,194,78,11,1,193,201,64,203,137,201,204,64,64,137,1,3,72,0,65,137,0,10,140,137,205,0,1,74]

theorem envBound9341 : H12AffineFastState.Bounded env9341 := by
  intro p hp
  have h : env9341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9340_9341 : H12AffineEnvironment.transform 3 11 env9340 = env9341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9340 == env9341) = true)

theorem identity9341 : scanCanonicalize (H12AffineFastState.compose env9341 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9341 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9342 : List Nat := [2,4,2,1,1,64,128,69,194,68,1,1,193,195,64,193,131,195,198,64,64,131,1,3,66,0,65,131,0,0,134,131,199,0,1,64]

theorem envBound9342 : H12AffineFastState.Bounded env9342 := by
  intro p hp
  have h : env9342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9341_9342 : H12AffineEnvironment.transform 2 2 env9341 = env9342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9341 == env9342) = true)

theorem identity9342 : scanCanonicalize (H12AffineFastState.compose env9342 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound9342 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9343 : List Nat := [2,4,2,1,1,64,2,69,64,68,1,1,67,65,64,67,1,65,68,64,64,1,1,3,66,0,65,1,0,0,4,1,69,0,1,64]

theorem envBound9343 : H12AffineFastState.Bounded env9343 := by
  intro p hp
  have h : env9343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9342_9343 : H12AffineEnvironment.transform 6 2 env9342 = env9343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env9342 == env9343) = true)

theorem identity9343 : scanCanonicalize (H12AffineFastState.compose env9343 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9344 : List Nat := [2,4,2,1,1,1,2,4,1,5,1,1,2,0,1,2,1,0,5,1,1,1,1,3,3,0,0,1,0,0,4,1,4,0,1,1]

theorem envBound9344 : H12AffineFastState.Bounded env9344 := by
  intro p hp
  have h : env9344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9343_9344 : H12AffineEnvironment.transform 5 1 env9343 = env9344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9343 == env9344) = true)

def leafEnv9344 : List Nat := [2,4,2,1,1,1,2,4,1,5,1,1,2,0,1,2,1,0,5,1,1,1,1,3,4,3,1,0,0,1,0,0,4,1,4,0,4,2,1,1,1,1,0]

def active9344 : List Nat := [0,1]

def tree9344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9344 : H12WitnessSearch.Good tree9344 := H12GlobalWitnessIndex.good

theorem leafIdentity9344 : H12AffineFastState.composeSystem env9344 rootObs = leafEnv9344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9344 rootObs == leafEnv9344) = true)

theorem terminalChecked9344 : H12PackedTerminal.terminalCheckFast leafEnv9344 active9344 tree9344 = true := by decide +kernel

def env9345 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,65,4194304,5005,34,8329,21040,278624,4214984,4215092,18632,505,4211101,4960,16616,21040,1021]

theorem envBound9345 : H12AffineFastState.Bounded env9345 := by
  intro p hp
  have h : env9345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9298_9345 : H12AffineEnvironment.transform 20 65 env9298 = env9345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9298 == env9345) = true)

theorem identity9345 : scanCanonicalize (H12AffineFastState.compose env9345 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266435) := by decide +kernel

theorem selectedBound9345 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9346 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,65,266435,5005,34,8329,21040,278624,278539,279031,18632,505,282974,4960,16616,21040,1021]

theorem envBound9346 : H12AffineFastState.Bounded env9346 := by
  intro p hp
  have h : env9346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9345_9346 : H12AffineEnvironment.transform 21 266435 env9345 = env9346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266435 env9345 == env9346) = true)

def env9347 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8692,8947,4605,262144,4961,8692,65,266435,5005,34,8329,4096,262736,262715,263111,2808,505,267118,4960,728,4096,1021]

theorem envBound9347 : H12AffineFastState.Bounded env9347 := by
  intro p hp
  have h : env9347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9346_9347 : H12AffineEnvironment.transform 13 560 env9346 = env9347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9346 == env9347) = true)

def env9348 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8692,8235,4605,262144,4537,8692,65,266435,4437,34,8329,4096,262280,262371,262431,2080,505,266678,4536,0,4096,293]

theorem envBound9348 : H12AffineFastState.Bounded env9348 := by
  intro p hp
  have h : env9348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9347_9348 : H12AffineEnvironment.transform 8 216 env9347 = env9348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9347 == env9348) = true)

theorem identity9348 : scanCanonicalize (H12AffineFastState.compose env9348 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound9348 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9349 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8692,8235,4605,4383,4537,8692,65,476,4437,34,8329,4096,4503,4604,4096,2080,505,169,4536,0,4096,293]

theorem envBound9349 : H12AffineFastState.Bounded env9349 := by
  intro p hp
  have h : env9349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9348_9349 : H12AffineEnvironment.transform 17 4383 env9348 = env9349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env9348 == env9349) = true)

theorem identity9349 : scanCanonicalize (H12AffineFastState.compose env9349 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound9349 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9350 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,493,8192,232,8692,8235,16,242,84,8692,65,476,184,34,8329,493,122,17,493,2080,505,169,85,0,493,293]

theorem envBound9350 : H12AffineFastState.Bounded env9350 := by
  intro p hp
  have h : env9350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9349_9350 : H12AffineEnvironment.transform 11 493 env9349 = env9350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env9349 == env9350) = true)

theorem identity9350 : scanCanonicalize (H12AffineFastState.compose env9350 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9350 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env9351 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,185,8192,232,8352,8235,16,242,84,8352,65,136,184,34,8329,185,122,17,185,2080,173,169,85,0,185,113]

theorem envBound9351 : H12AffineFastState.Bounded env9351 := by
  intro p hp
  have h : env9351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9350_9351 : H12AffineEnvironment.transform 7 84 env9350 = env9351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9350 == env9351) = true)

theorem identity9351 : scanCanonicalize (H12AffineFastState.compose env9351 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9351 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9352 : List Nat := [2,4,8,16,32,64,121,84,33,85,2048,64,8192,17,8281,8235,16,11,84,8281,65,113,65,34,8304,64,122,17,64,2080,84,80,85,0,64,113]

theorem envBound9352 : H12AffineFastState.Bounded env9352 := by
  intro p hp
  have h : env9352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9351_9352 : H12AffineEnvironment.transform 6 121 env9351 = env9352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9351 == env9352) = true)

theorem identity9352 : scanCanonicalize (H12AffineFastState.compose env9352 (packedSelected [2,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9352 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env9353 : List Nat := [2,4,8,16,32,10,51,30,33,31,2048,10,8192,17,8211,8235,16,11,30,8211,11,59,11,34,8250,10,48,17,10,2080,30,26,31,0,10,59]

theorem envBound9353 : H12AffineFastState.Bounded env9353 := by
  intro p hp
  have h : env9353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9352_9353 : H12AffineEnvironment.transform 5 10 env9352 = env9353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9352 == env9353) = true)

theorem identity9353 : scanCanonicalize (H12AffineFastState.compose env9353 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound9353 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env9354 : List Nat := [2,4,8,16,32,10,51,30,33,31,2048,10,2051,17,2064,2088,16,11,30,2064,11,59,11,34,2105,10,48,17,10,2080,30,26,31,0,10,59]

theorem envBound9354 : H12AffineFastState.Bounded env9354 := by
  intro p hp
  have h : env9354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9353_9354 : H12AffineEnvironment.transform 12 2051 env9353 = env9354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env9353 == env9354) = true)

theorem identity9354 : scanCanonicalize (H12AffineFastState.compose env9354 (packedSelected [0,1,2,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9354 : packedSelected [0,1,2,5,9] rootPS < 2^1333 := by decide +kernel

def env9355 : List Nat := [2,4,8,10,32,10,41,4,33,5,2048,10,2051,11,2058,2088,10,11,4,2058,11,33,11,34,2083,10,42,11,10,2080,4,0,5,0,10,33]

theorem envBound9355 : H12AffineFastState.Bounded env9355 := by
  intro p hp
  have h : env9355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9354_9355 : H12AffineEnvironment.transform 3 10 env9354 = env9355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9354 == env9355) = true)

theorem identity9355 : scanCanonicalize (H12AffineFastState.compose env9355 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9356 : List Nat := [2,4,8,10,0,10,9,4,1,5,2048,10,2051,11,2058,2056,10,11,4,2058,11,1,11,2,2051,10,10,11,10,2048,4,0,5,0,10,1]

theorem envBound9356 : H12AffineFastState.Bounded env9356 := by
  intro p hp
  have h : env9356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9355_9356 : H12AffineEnvironment.transform 4 0 env9355 = env9356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9355 == env9356) = true)

theorem identity9356 : scanCanonicalize (H12AffineFastState.compose env9356 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9357 : List Nat := [2,4,2,0,0,0,3,4,1,5,2048,0,2051,1,2048,2050,0,1,4,2048,1,1,1,2,2051,0,0,1,0,2048,4,0,5,0,0,1]

theorem envBound9357 : H12AffineFastState.Bounded env9357 := by
  intro p hp
  have h : env9357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9356_9357 : H12AffineEnvironment.transform 2 2 env9356 = env9357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9356 == env9357) = true)

def env9358 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8692,8234,4605,262144,4536,8692,65,266435,4436,34,8329,4096,262281,262370,262430,2081,505,266679,4537,1,4096,292]

theorem envBound9358 : H12AffineFastState.Bounded env9358 := by
  intro p hp
  have h : env9358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9347_9358 : H12AffineEnvironment.transform 8 217 env9347 = env9358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9347 == env9358) = true)

theorem identity9358 : scanCanonicalize (H12AffineFastState.compose env9358 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9358 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9359 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,4096,8192,233,8353,8234,4264,262144,4333,8353,65,266435,4097,34,8329,4096,262281,262370,262219,2081,172,266466,4332,1,4096,113]

theorem envBound9359 : H12AffineFastState.Bounded env9359 := by
  intro p hp
  have h : env9359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9358_9359 : H12AffineEnvironment.transform 7 85 env9358 = env9359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9358 == env9359) = true)

theorem identity9359 : scanCanonicalize (H12AffineFastState.compose env9359 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound9359 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9360 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,4096,8192,233,8353,8234,4264,91,4333,8353,65,4248,4097,34,8329,4096,210,185,16,2081,172,4281,4332,1,4096,113]

theorem envBound9360 : H12AffineFastState.Bounded env9360 := by
  intro p hp
  have h : env9360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9359_9360 : H12AffineEnvironment.transform 17 91 env9359 = env9360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env9359 == env9360) = true)

theorem identity9360 : scanCanonicalize (H12AffineFastState.compose env9360 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound9360 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9361 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,2106,8192,233,8353,8234,2194,91,2263,8353,65,2210,2107,34,8329,2106,210,185,16,2081,172,2179,2262,1,2106,113]

theorem envBound9361 : H12AffineFastState.Bounded env9361 := by
  intro p hp
  have h : env9361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9360_9361 : H12AffineEnvironment.transform 11 2106 env9360 = env9361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env9360 == env9361) = true)

theorem identity9361 : scanCanonicalize (H12AffineFastState.compose env9361 (packedSelected [2,4,9,10,11,13,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2256) := by decide +kernel

theorem selectedBound9361 : packedSelected [2,4,9,10,11,13,14,18] rootPS < 2^1333 := by decide +kernel

def env9362 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,2106,2256,233,2161,2298,2194,91,2263,2161,65,2210,2107,34,2137,2106,210,185,16,2081,172,2179,2262,1,2106,113]

theorem envBound9362 : H12AffineFastState.Bounded env9362 := by
  intro p hp
  have h : env9362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9361_9362 : H12AffineEnvironment.transform 12 2256 env9361 = env9362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2256 env9361 == env9362) = true)

theorem identity9362 : scanCanonicalize (H12AffineFastState.compose env9362 (packedSelected [2,3,8,9,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound9362 : packedSelected [2,3,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env9363 : List Nat := [2,4,8,16,32,64,82,85,11,84,2048,2106,2050,59,2161,2088,2112,91,2053,2161,65,2160,2107,34,2137,2106,0,107,16,2081,126,2129,2052,1,2106,113]

theorem envBound9363 : H12AffineFastState.Bounded env9363 := by
  intro p hp
  have h : env9363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9362_9363 : H12AffineEnvironment.transform 6 82 env9362 = env9363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env9362 == env9363) = true)

theorem identity9363 : scanCanonicalize (H12AffineFastState.compose env9363 (packedSelected [1,2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9363 : packedSelected [1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env9364 : List Nat := [2,4,8,16,32,64,82,85,11,84,43,17,41,59,90,3,107,91,46,90,65,91,16,34,114,17,0,107,16,10,126,122,47,1,17,113]

theorem envBound9364 : H12AffineFastState.Bounded env9364 := by
  intro p hp
  have h : env9364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9363_9364 : H12AffineEnvironment.transform 10 43 env9363 = env9364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9363 == env9364) = true)

theorem identity9364 : scanCanonicalize (H12AffineFastState.compose env9364 (packedSelected [3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9364 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env9365 : List Nat := [2,4,8,16,10,64,82,85,11,84,1,17,3,17,90,3,65,91,4,90,65,91,16,8,88,17,0,65,16,10,84,80,5,1,17,91]

theorem envBound9365 : H12AffineFastState.Bounded env9365 := by
  intro p hp
  have h : env9365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9364_9365 : H12AffineEnvironment.transform 4 10 env9364 = env9365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9364 == env9365) = true)

theorem identity9365 : scanCanonicalize (H12AffineFastState.compose env9365 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9365 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9366 : List Nat := [2,4,8,1,10,64,67,68,11,69,1,0,3,0,75,3,65,74,4,75,65,74,1,8,73,0,0,65,1,10,69,65,5,1,0,74]

theorem envBound9366 : H12AffineFastState.Bounded env9366 := by
  intro p hp
  have h : env9366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9365_9366 : H12AffineEnvironment.transform 3 1 env9365 = env9366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9365 == env9366) = true)

theorem identity9366 : scanCanonicalize (H12AffineFastState.compose env9366 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9366 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9367 : List Nat := [2,4,8,1,10,1,2,5,11,4,1,0,3,0,10,3,0,11,4,10,0,11,1,8,8,0,0,0,1,10,4,0,5,1,0,11]

theorem envBound9367 : H12AffineFastState.Bounded env9367 := by
  intro p hp
  have h : env9367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9366_9367 : H12AffineEnvironment.transform 5 1 env9366 = env9367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9366 == env9367) = true)

theorem identity9367 : scanCanonicalize (H12AffineFastState.compose env9367 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9367 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9368 : List Nat := [2,4,2,1,0,1,2,5,1,4,1,0,3,0,0,3,0,1,4,0,0,1,1,2,2,0,0,0,1,0,4,0,5,1,0,1]

theorem envBound9368 : H12AffineFastState.Bounded env9368 := by
  intro p hp
  have h : env9368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9367_9368 : H12AffineEnvironment.transform 2 2 env9367 = env9368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9367 == env9368) = true)

def env9369 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8692,8946,4605,262144,4961,8692,65,266435,5005,34,8329,4097,262737,262714,263110,2809,505,267119,4960,729,4097,1021]

theorem envBound9369 : H12AffineFastState.Bounded env9369 := by
  intro p hp
  have h : env9369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9346_9369 : H12AffineEnvironment.transform 13 561 env9346 = env9369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9346 == env9369) = true)

def env9370 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8692,8234,4605,262144,4537,8692,65,266435,4437,34,8329,4097,262281,262370,262430,2081,505,266679,4536,1,4097,293]

theorem envBound9370 : H12AffineFastState.Bounded env9370 := by
  intro p hp
  have h : env9370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9369_9370 : H12AffineEnvironment.transform 8 216 env9369 = env9370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9369 == env9370) = true)

theorem identity9370 : scanCanonicalize (H12AffineFastState.compose env9370 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9370 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9371 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,4096,8192,233,8353,8234,4264,262144,4332,8353,65,266435,4096,34,8329,4097,262281,262370,262219,2081,172,266466,4333,1,4097,112]

theorem envBound9371 : H12AffineFastState.Bounded env9371 := by
  intro p hp
  have h : env9371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9370_9371 : H12AffineEnvironment.transform 7 85 env9370 = env9371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9370 == env9371) = true)

theorem identity9371 : scanCanonicalize (H12AffineFastState.compose env9371 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound9371 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env9372 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,16,8192,233,8353,8234,184,262144,252,8353,65,262355,16,34,8329,17,262281,262370,262219,2081,172,262386,253,1,17,112]

theorem envBound9372 : H12AffineFastState.Bounded env9372 := by
  intro p hp
  have h : env9372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9371_9372 : H12AffineEnvironment.transform 11 16 env9371 = env9372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9371 == env9372) = true)

theorem identity9372 : scanCanonicalize (H12AffineFastState.compose env9372 (packedSelected [13,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound9372 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env9373 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,16,8192,233,8353,8234,184,2184,252,8353,65,2139,16,34,8329,17,2049,2154,2243,2081,172,2170,253,1,17,112]

theorem envBound9373 : H12AffineFastState.Bounded env9373 := by
  intro p hp
  have h : env9373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9372_9373 : H12AffineEnvironment.transform 17 2184 env9372 = env9373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env9372 == env9373) = true)

theorem identity9373 : scanCanonicalize (H12AffineFastState.compose env9373 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound9373 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9374 : List Nat := [2,4,8,16,32,64,128,85,216,84,43,16,8192,233,8353,8234,184,163,252,8353,65,112,16,34,8329,17,42,65,232,10,172,81,253,1,17,112]

theorem envBound9374 : H12AffineFastState.Bounded env9374 := by
  intro p hp
  have h : env9374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9373_9374 : H12AffineEnvironment.transform 10 43 env9373 = env9374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env9373 == env9374) = true)

theorem identity9374 : scanCanonicalize (H12AffineFastState.compose env9374 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9374 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9375 : List Nat := [2,4,8,16,32,64,120,85,32,84,43,16,8192,17,8281,8234,64,91,4,8281,65,112,16,34,8305,17,42,65,16,10,84,81,5,1,17,112]

theorem envBound9375 : H12AffineFastState.Bounded env9375 := by
  intro p hp
  have h : env9375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9374_9375 : H12AffineEnvironment.transform 6 120 env9374 = env9375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9374 == env9375) = true)

theorem identity9375 : scanCanonicalize (H12AffineFastState.compose env9375 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound9375 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env9376 : List Nat := [2,4,8,16,32,42,18,63,32,62,43,16,8192,17,8243,8234,42,49,4,8243,43,26,16,34,8219,17,42,43,16,10,62,59,5,1,17,26]

theorem envBound9376 : H12AffineFastState.Bounded env9376 := by
  intro p hp
  have h : env9376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9375_9376 : H12AffineEnvironment.transform 5 42 env9375 = env9376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env9375 == env9376) = true)

def env9377 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8692,8235,4605,262144,4536,8692,65,266435,4436,34,8329,4097,262280,262371,262431,2080,505,266678,4537,0,4097,292]

theorem envBound9377 : H12AffineFastState.Bounded env9377 := by
  intro p hp
  have h : env9377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9369_9377 : H12AffineEnvironment.transform 8 217 env9369 = env9377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9369 == env9377) = true)

theorem identity9377 : scanCanonicalize (H12AffineFastState.compose env9377 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound9377 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9378 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8692,8235,4605,4383,4536,8692,65,476,4436,34,8329,4097,4503,4604,4096,2080,505,169,4537,0,4097,292]

theorem envBound9378 : H12AffineFastState.Bounded env9378 := by
  intro p hp
  have h : env9378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9377_9378 : H12AffineEnvironment.transform 17 4383 env9377 = env9378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env9377 == env9378) = true)

theorem identity9378 : scanCanonicalize (H12AffineFastState.compose env9378 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound9378 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9379 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,185,8192,232,8692,8235,324,422,257,8692,65,476,493,34,8329,184,302,325,185,2080,505,169,256,0,184,292]

theorem envBound9379 : H12AffineFastState.Bounded env9379 := by
  intro p hp
  have h : env9379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9378_9379 : H12AffineEnvironment.transform 11 185 env9378 = env9379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env9378 == env9379) = true)

theorem identity9379 : scanCanonicalize (H12AffineFastState.compose env9379 (packedSelected [0,1,3,7,12,13,14,15,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9379 : packedSelected [0,1,3,7,12,13,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env9380 : List Nat := [2,4,8,16,32,64,120,256,33,257,2048,65,8192,16,8460,8235,324,350,257,8460,65,292,277,34,8305,64,302,325,65,2080,257,81,256,0,64,292]

theorem envBound9380 : H12AffineFastState.Bounded env9380 := by
  intro p hp
  have h : env9380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9379_9380 : H12AffineEnvironment.transform 6 120 env9379 = env9380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9379 == env9380) = true)

theorem identity9380 : scanCanonicalize (H12AffineFastState.compose env9380 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound9380 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9381 : List Nat := [2,4,8,16,32,64,120,4,33,5,2048,65,8192,16,8200,8235,64,90,5,8200,65,32,17,34,8305,64,42,65,65,2080,5,81,4,0,64,32]

theorem envBound9381 : H12AffineFastState.Bounded env9381 := by
  intro p hp
  have h : env9381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9380_9381 : H12AffineEnvironment.transform 7 4 env9380 = env9381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env9380 == env9381) = true)

theorem identity9381 : scanCanonicalize (H12AffineFastState.compose env9381 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6) := by decide +kernel

theorem selectedBound9381 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9382 : List Nat := [2,4,8,16,32,64,120,4,33,5,2048,65,6,16,14,45,64,90,5,14,65,32,17,34,119,64,42,65,65,2080,5,81,4,0,64,32]

theorem envBound9382 : H12AffineFastState.Bounded env9382 := by
  intro p hp
  have h : env9382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9381_9382 : H12AffineEnvironment.transform 12 6 env9381 = env9382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6 env9381 == env9382) = true)

theorem identity9382 : scanCanonicalize (H12AffineFastState.compose env9382 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9382 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9383 : List Nat := [2,4,8,0,32,64,104,4,33,5,2048,65,6,0,14,45,64,74,5,14,65,32,1,34,103,64,42,65,65,2080,5,65,4,0,64,32]

theorem envBound9383 : H12AffineFastState.Bounded env9383 := by
  intro p hp
  have h : env9383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9382_9383 : H12AffineEnvironment.transform 3 0 env9382 = env9383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9382 == env9383) = true)

theorem identity9383 : scanCanonicalize (H12AffineFastState.compose env9383 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound9383 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env9384 : List Nat := [2,4,8,0,32,64,104,4,33,5,10,65,6,0,14,45,64,74,5,14,65,32,1,34,103,64,42,65,65,42,5,65,4,0,64,32]

theorem envBound9384 : H12AffineFastState.Bounded env9384 := by
  intro p hp
  have h : env9384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9383_9384 : H12AffineEnvironment.transform 10 10 env9383 = env9384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env9383 == env9384) = true)

def env9385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,67108864,134217728,138678441,138678613,151259274,84484169,155451871,525568,151257258,203759842,16778207]

theorem envBound9385 : H12AffineFastState.Bounded env9385 := by
  intro p hp
  have h : env9385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8144_9385 : H12AffineEnvironment.transform 27 138678441 env8144 = env9385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env8144 == env9385) = true)

theorem identity9385 : scanCanonicalize (H12AffineFastState.compose env9385 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 16856621) := by decide +kernel

theorem selectedBound9385 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env9386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,16856621,134217728,138678441,138678613,151259274,530020,155451871,525568,151257258,153360079,16778207]

theorem envBound9386 : H12AffineFastState.Bounded env9386 := by
  intro p hp
  have h : env9386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9385_9386 : H12AffineEnvironment.transform 25 16856621 env9385 = env9386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 16856621 env9385 == env9386) = true)

def env9387 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,16777216,8329,16855853,134217728,138678441,138678613,151259274,529252,155451871,524288,151257258,153359311,16778207]

theorem envBound9387 : H12AffineFastState.Bounded env9387 := by
  intro p hp
  have h : env9387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9386_9387 : H12AffineEnvironment.transform 9 256 env9386 = env9387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env9386 == env9387) = true)

def env9388 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,16777216,8329,16855853,4985752,525105,525005,21502738,529252,17306183,524288,21500722,23593047,16778207]

theorem envBound9388 : H12AffineFastState.Bounded env9388 := by
  intro p hp
  have h : env9388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9387_9388 : H12AffineEnvironment.transform 26 4985752 env9387 = env9388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985752 env9387 == env9388) = true)

def env9389 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,4194304,524525,16777216,8329,16855853,4985752,525105,525005,21502738,529252,17306183,524288,21500722,21781063,16778207]

theorem envBound9389 : H12AffineFastState.Bounded env9389 := by
  intro p hp
  have h : env9389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9388_9389 : H12AffineEnvironment.transform 20 285200 env9388 = env9389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9388 == env9389) = true)

theorem identity9389 : scanCanonicalize (H12AffineFastState.compose env9389 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9389 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9390 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,372,524525,16777216,8329,16855853,791276,525105,525005,17308262,529252,17306183,524288,17306182,17586995,16778207]

theorem envBound9390 : H12AffineFastState.Bounded env9390 := by
  intro p hp
  have h : env9390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9389_9390 : H12AffineEnvironment.transform 21 372 env9389 = env9390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9389 == env9390) = true)

theorem identity9390 : scanCanonicalize (H12AffineFastState.compose env9390 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9390 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9391 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,372,524525,35,8329,78606,791276,525105,525005,531013,529252,528996,524288,528997,809744,1020]

theorem envBound9391 : H12AffineFastState.Bounded env9391 := by
  intro p hp
  have h : env9391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9390_9391 : H12AffineEnvironment.transform 23 35 env9390 = env9391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9390 == env9391) = true)

theorem identity9391 : scanCanonicalize (H12AffineFastState.compose env9391 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342727) := by decide +kernel

theorem selectedBound9391 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9392 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,342727,8692,285200,372,342570,35,8329,78606,75819,342518,342026,336002,338339,338083,342727,338082,90583,1020]

theorem envBound9392 : H12AffineFastState.Bounded env9392 := by
  intro p hp
  have h : env9392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9391_9392 : H12AffineEnvironment.transform 18 342727 env9391 = env9392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342727 env9391 == env9392) = true)

theorem identity9392 : scanCanonicalize (H12AffineFastState.compose env9392 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound9392 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9393 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,2421,78770,8692,21349,372,78687,35,8329,78606,75819,77955,78207,76279,73942,74198,78770,74199,90583,1020]

theorem envBound9393 : H12AffineFastState.Bounded env9393 := by
  intro p hp
  have h : env9393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9392_9393 : H12AffineEnvironment.transform 17 2421 env9392 = env9393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env9392 == env9393) = true)

theorem identity9393 : scanCanonicalize (H12AffineFastState.compose env9393 (packedSelected [3,4,5,6,7,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound9393 : packedSelected [3,4,5,6,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env9394 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,4373,8692,65536,4605,2421,78770,8692,624,372,78687,35,8329,78606,75819,77955,78207,76279,73942,74198,78770,74199,78018,1020]

theorem envBound9394 : H12AffineFastState.Bounded env9394 := by
  intro p hp
  have h : env9394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9393_9394 : H12AffineEnvironment.transform 13 4373 env9393 = env9394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env9393 == env9394) = true)

theorem identity9394 : scanCanonicalize (H12AffineFastState.compose env9394 (packedSelected [1,2,3,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 278) := by decide +kernel

theorem selectedBound9394 : packedSelected [1,2,3,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env9395 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,278,4373,226,65536,4605,2421,70308,226,624,372,70217,35,415,70168,67901,70037,69737,67809,65984,65728,70308,65729,70100,1020]

theorem envBound9395 : H12AffineFastState.Bounded env9395 := by
  intro p hp
  have h : env9395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9394_9395 : H12AffineEnvironment.transform 12 278 env9394 = env9395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 278 env9394 == env9395) = true)

theorem identity9395 : scanCanonicalize (H12AffineFastState.compose env9395 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound9395 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env9396 : List Nat := [2,4,8,16,32,64,128,256,512,256,522,4096,278,4373,226,65536,4605,895,70308,226,624,372,70217,35,415,70168,66359,70037,69737,66283,65984,65728,70308,65729,70100,1020]

theorem envBound9396 : H12AffineFastState.Bounded env9396 := by
  intro p hp
  have h : env9396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9395_9396 : H12AffineEnvironment.transform 10 522 env9395 = env9396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env9395 == env9396) = true)

theorem identity9396 : scanCanonicalize (H12AffineFastState.compose env9396 (packedSelected [1,6,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9396 : packedSelected [1,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9397 : List Nat := [2,4,8,16,32,64,40,256,512,256,522,4096,278,4373,74,65536,4437,895,70156,74,624,372,70217,35,311,70168,66359,69949,69737,66115,65896,65640,70156,65641,70012,852]

theorem envBound9397 : H12AffineFastState.Bounded env9397 := by
  intro p hp
  have h : env9397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9396_9397 : H12AffineEnvironment.transform 6 40 env9396 = env9397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9396 == env9397) = true)

theorem identity9397 : scanCanonicalize (H12AffineFastState.compose env9397 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9397 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env9398 : List Nat := [2,4,8,16,32,64,40,37,512,37,522,4096,51,4144,74,65536,4208,602,70156,74,624,81,70217,35,18,70168,66066,69656,69737,66115,65613,65640,70156,65641,69721,625]

theorem envBound9398 : H12AffineFastState.Bounded env9398 := by
  intro p hp
  have h : env9398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9397_9398 : H12AffineEnvironment.transform 7 37 env9397 = env9398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9397 == env9398) = true)

theorem identity9398 : scanCanonicalize (H12AffineFastState.compose env9398 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound9398 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9399 : List Nat := [2,4,8,16,32,64,40,37,512,37,522,4096,51,4144,74,82,4208,602,4702,74,624,81,4635,35,18,4682,576,4170,4155,529,31,58,4702,59,4107,625]

theorem envBound9399 : H12AffineFastState.Bounded env9399 := by
  intro p hp
  have h : env9399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9398_9399 : H12AffineEnvironment.transform 15 82 env9398 = env9399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env9398 == env9399) = true)

theorem identity9399 : scanCanonicalize (H12AffineFastState.compose env9399 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound9399 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9400 : List Nat := [2,4,8,16,32,64,40,37,512,37,522,529,51,545,74,82,609,602,79,74,624,81,10,35,18,91,576,603,554,529,31,58,79,59,538,625]

theorem envBound9400 : H12AffineFastState.Bounded env9400 := by
  intro p hp
  have h : env9400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9399_9400 : H12AffineEnvironment.transform 11 529 env9399 = env9400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env9399 == env9400) = true)

theorem identity9400 : scanCanonicalize (H12AffineFastState.compose env9400 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9400 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env9401 : List Nat := [2,4,8,16,32,49,40,37,512,37,522,529,51,545,59,35,528,555,62,59,513,32,10,35,18,42,561,554,554,529,31,58,62,59,538,512]

theorem envBound9401 : H12AffineFastState.Bounded env9401 := by
  intro p hp
  have h : env9401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9400_9401 : H12AffineEnvironment.transform 5 49 env9400 = env9401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9400 == env9401) = true)

def env9402 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,4194304,524525,16777216,8329,16855853,4985752,525105,525005,21502738,529252,17306183,524288,21500722,21781062,16778207]

theorem envBound9402 : H12AffineFastState.Bounded env9402 := by
  intro p hp
  have h : env9402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9388_9402 : H12AffineEnvironment.transform 20 285201 env9388 = env9402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9388 == env9402) = true)

theorem identity9402 : scanCanonicalize (H12AffineFastState.compose env9402 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9402 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9403 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,477,524525,16777216,8329,16855853,791109,525105,525005,17308367,529252,17306183,524288,17306351,17587099,16778207]

theorem envBound9403 : H12AffineFastState.Bounded env9403 := by
  intro p hp
  have h : env9403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9402_9403 : H12AffineEnvironment.transform 21 477 env9402 = env9403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9402 == env9403) = true)

theorem identity9403 : scanCanonicalize (H12AffineFastState.compose env9403 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9403 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9404 : List Nat := [2,4,8,16,32,64,40,256,512,256,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,285201,373,524357,16777216,8225,16855853,791109,525105,524901,17308263,529252,17306183,524288,17306183,17586995,16778103]

theorem envBound9404 : H12AffineFastState.Bounded env9404 := by
  intro p hp
  have h : env9404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9403_9404 : H12AffineEnvironment.transform 6 40 env9403 = env9404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9403 == env9404) = true)

theorem identity9404 : scanCanonicalize (H12AffineFastState.compose env9404 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9404 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9405 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,285201,33,524357,16777216,8225,16855673,791109,524901,524901,17308263,528944,17306183,524288,17306183,17586791,16777763]

theorem envBound9405 : H12AffineFastState.Bounded env9405 := by
  intro p hp
  have h : env9405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9404_9405 : H12AffineEnvironment.transform 7 84 env9404 = env9405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9404 == env9405) = true)

theorem identity9405 : scanCanonicalize (H12AffineFastState.compose env9405 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound9405 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9406 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8200,65536,4097,262144,78414,8200,285201,33,78347,16777216,8225,16855673,335883,77867,77867,16853033,73854,16850953,78414,16850953,17131561,16777763]

theorem envBound9406 : H12AffineFastState.Bounded env9406 := by
  intro p hp
  have h : env9406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9405_9406 : H12AffineEnvironment.transform 18 78414 env9405 = env9406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env9405 == env9406) = true)

theorem identity9406 : scanCanonicalize (H12AffineFastState.compose env9406 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336418) := by decide +kernel

theorem selectedBound9406 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9407 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8200,65536,4097,262144,78414,8200,285201,33,78347,336418,8225,266331,335883,77867,77867,264715,73854,262699,78414,262699,18955,335873]

theorem envBound9407 : H12AffineFastState.Bounded env9407 := by
  intro p hp
  have h : env9407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9406_9407 : H12AffineEnvironment.transform 23 336418 env9406 = env9407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336418 env9406 == env9407) = true)

theorem identity9407 : scanCanonicalize (H12AffineFastState.compose env9407 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16395) := by decide +kernel

theorem selectedBound9407 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9408 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8200,65536,4097,16395,78414,8200,6682,33,78347,90665,8225,20560,90112,77867,77867,18944,73854,16928,78414,16928,18955,90122]

theorem envBound9408 : H12AffineFastState.Bounded env9408 := by
  intro p hp
  have h : env9408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9407_9408 : H12AffineEnvironment.transform 17 16395 env9407 = env9408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16395 env9407 == env9408) = true)

theorem identity9408 : scanCanonicalize (H12AffineFastState.compose env9408 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14400) := by decide +kernel

theorem selectedBound9408 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9409 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8200,14400,4097,16395,2574,8200,6682,33,2635,23145,8225,20560,22592,2155,2155,18944,6206,16928,2574,16928,18955,22602]

theorem envBound9409 : H12AffineFastState.Bounded env9409 := by
  intro p hp
  have h : env9409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9408_9409 : H12AffineEnvironment.transform 15 14400 env9408 = env9409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14400 env9408 == env9409) = true)

theorem identity9409 : scanCanonicalize (H12AffineFastState.compose env9409 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound9409 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9410 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,8744,8200,14400,4097,8739,2574,8200,6682,33,2635,14401,8225,12920,14952,2155,2155,10280,6206,8200,2574,8200,10275,14946]

theorem envBound9410 : H12AffineFastState.Bounded env9410 := by
  intro p hp
  have h : env9410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9409_9410 : H12AffineEnvironment.transform 13 8744 env9409 = env9410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env9409 == env9410) = true)

theorem identity9410 : scanCanonicalize (H12AffineFastState.compose env9410 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6242) := by decide +kernel

theorem selectedBound9410 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9411 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,6242,6730,6250,34,4097,6721,2574,6250,6682,33,2635,35,6211,2586,522,2155,2155,4170,6206,6250,2574,6250,4161,512]

theorem envBound9411 : H12AffineFastState.Bounded env9411 := by
  intro p hp
  have h : env9411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9410_9411 : H12AffineEnvironment.transform 12 6242 env9410 = env9411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6242 env9410 == env9411) = true)

theorem identity9411 : scanCanonicalize (H12AffineFastState.compose env9411 (packedSelected [0,1,2,4,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 608) := by decide +kernel

theorem selectedBound9411 : packedSelected [0,1,2,4,5,13] rootPS < 2^1333 := by decide +kernel

def env9412 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,608,2562,2090,2570,34,609,2081,2574,2570,2170,33,2635,35,2595,2586,522,2155,2155,554,2654,2570,2574,2570,545,512]

theorem envBound9412 : H12AffineFastState.Bounded env9412 := by
  intro p hp
  have h : env9412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9411_9412 : H12AffineEnvironment.transform 11 608 env9411 = env9412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 608 env9411 == env9412) = true)

def env9413 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,16777216,8329,16855853,4985753,525104,525004,21502739,529252,17306182,524288,21500723,23593046,16778207]

theorem envBound9413 : H12AffineFastState.Bounded env9413 := by
  intro p hp
  have h : env9413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9387_9413 : H12AffineEnvironment.transform 26 4985753 env9387 = env9413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985753 env9387 == env9413) = true)

def env9414 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,4194304,524525,16777216,8329,16855853,4985753,525104,525004,21502739,529252,17306182,524288,21500723,21781062,16778207]

theorem envBound9414 : H12AffineFastState.Bounded env9414 := by
  intro p hp
  have h : env9414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9413_9414 : H12AffineEnvironment.transform 20 285200 env9413 = env9414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9413 == env9414) = true)

theorem identity9414 : scanCanonicalize (H12AffineFastState.compose env9414 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9414 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9415 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,372,524525,16777216,8329,16855853,791277,525104,525004,17308263,529252,17306182,524288,17306183,17586994,16778207]

theorem envBound9415 : H12AffineFastState.Bounded env9415 := by
  intro p hp
  have h : env9415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9414_9415 : H12AffineEnvironment.transform 21 372 env9414 = env9415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9414 == env9415) = true)

theorem identity9415 : scanCanonicalize (H12AffineFastState.compose env9415 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9415 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9416 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,372,524525,35,8329,78606,791277,525104,525004,531012,529252,528997,524288,528996,809745,1020]

theorem envBound9416 : H12AffineFastState.Bounded env9416 := by
  intro p hp
  have h : env9416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9415_9416 : H12AffineEnvironment.transform 23 35 env9415 = env9416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9415 == env9416) = true)

theorem identity9416 : scanCanonicalize (H12AffineFastState.compose env9416 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342727) := by decide +kernel

theorem selectedBound9416 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9417 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,342727,8692,285200,372,342570,35,8329,78606,75818,342519,342027,336003,338339,338082,342727,338083,90582,1020]

theorem envBound9417 : H12AffineFastState.Bounded env9417 := by
  intro p hp
  have h : env9417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9416_9417 : H12AffineEnvironment.transform 18 342727 env9416 = env9417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342727 env9416 == env9417) = true)

theorem identity9417 : scanCanonicalize (H12AffineFastState.compose env9417 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound9417 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9418 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,2524,78619,8692,21452,372,78838,35,8329,78606,75818,77867,78295,76127,73855,74110,78619,74111,90582,1020]

theorem envBound9418 : H12AffineFastState.Bounded env9418 := by
  intro p hp
  have h : env9418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9417_9418 : H12AffineEnvironment.transform 17 2524 env9417 = env9418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env9417 == env9418) = true)

theorem identity9418 : scanCanonicalize (H12AffineFastState.compose env9418 (packedSelected [2,5,7,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 30753) := by decide +kernel

theorem selectedBound9418 : packedSelected [2,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env9419 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,30753,4605,2524,19258,8692,21452,372,19415,35,8329,19247,20491,18442,18934,20862,22622,22879,19258,22878,6647,1020]

theorem envBound9419 : H12AffineFastState.Bounded env9419 := by
  intro p hp
  have h : env9419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9418_9419 : H12AffineEnvironment.transform 15 30753 env9418 = env9419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30753 env9418 == env9419) = true)

theorem identity9419 : scanCanonicalize (H12AffineFastState.compose env9419 (packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 8859) := by decide +kernel

theorem selectedBound9419 : packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env9420 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,8859,8692,6842,4605,2524,10657,8692,12631,372,10572,35,8329,10676,12944,10897,11117,13285,15045,15300,10657,15301,6647,1020]

theorem envBound9420 : H12AffineFastState.Bounded env9420 := by
  intro p hp
  have h : env9420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9419_9420 : H12AffineEnvironment.transform 13 8859 env9419 = env9420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8859 env9419 == env9420) = true)

theorem identity9420 : scanCanonicalize (H12AffineFastState.compose env9420 (packedSelected [0,3,4,6,7,8,9,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2288) := by decide +kernel

theorem selectedBound9420 : packedSelected [0,3,4,6,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env9421 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,2288,2667,2308,6842,4605,2524,337,2308,6567,372,444,35,2169,324,6752,609,925,6933,4661,4916,337,4917,6647,1020]

theorem envBound9421 : H12AffineFastState.Bounded env9421 := by
  intro p hp
  have h : env9421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9420_9421 : H12AffineEnvironment.transform 12 2288 env9420 = env9421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2288 env9420 == env9421) = true)

theorem identity9421 : scanCanonicalize (H12AffineFastState.compose env9421 (packedSelected [0,2,4,7,9,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound9421 : packedSelected [0,2,4,7,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env9422 : List Nat := [2,4,8,16,32,64,128,256,512,256,391,4096,375,1004,131,4925,4605,91,337,131,4128,372,444,35,510,324,5095,609,925,4754,4661,4916,337,4917,4208,1020]

theorem envBound9422 : H12AffineFastState.Bounded env9422 := by
  intro p hp
  have h : env9422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9421_9422 : H12AffineEnvironment.transform 10 391 env9421 = env9422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env9421 == env9422) = true)

theorem identity9422 : scanCanonicalize (H12AffineFastState.compose env9422 (packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound9422 : packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env9423 : List Nat := [2,4,8,16,32,64,128,256,512,256,391,445,375,1004,131,640,64,91,337,131,413,372,444,35,510,324,602,609,925,815,904,649,337,648,461,1020]

theorem envBound9423 : H12AffineFastState.Bounded env9423 := by
  intro p hp
  have h : env9423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9422_9423 : H12AffineEnvironment.transform 11 445 env9422 = env9423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env9422 == env9423) = true)

theorem identity9423 : scanCanonicalize (H12AffineFastState.compose env9423 (packedSelected [1,2,5,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9423 : packedSelected [1,2,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9424 : List Nat := [2,4,8,16,32,64,128,85,512,85,210,232,34,697,131,640,64,91,4,131,200,33,233,35,171,17,602,609,712,634,733,649,4,648,152,681]

theorem envBound9424 : H12AffineFastState.Bounded env9424 := by
  intro p hp
  have h : env9424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9423_9424 : H12AffineEnvironment.transform 7 85 env9423 = env9424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9423 == env9424) = true)

theorem identity9424 : scanCanonicalize (H12AffineFastState.compose env9424 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound9424 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9425 : List Nat := [2,4,8,16,32,64,82,85,512,85,0,58,34,619,81,594,64,91,4,81,26,33,59,35,121,17,602,609,538,634,527,603,4,602,74,635]

theorem envBound9425 : H12AffineFastState.Bounded env9425 := by
  intro p hp
  have h : env9425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9424_9425 : H12AffineEnvironment.transform 6 82 env9424 = env9425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env9424 == env9425) = true)

theorem identity9425 : scanCanonicalize (H12AffineFastState.compose env9425 (packedSelected [4,6] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound9425 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env9426 : List Nat := [2,4,8,16,32,64,82,85,43,85,0,58,34,64,81,121,64,91,4,81,26,33,59,35,121,17,113,74,49,81,36,112,4,113,74,80]

theorem envBound9426 : H12AffineFastState.Bounded env9426 := by
  intro p hp
  have h : env9426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9425_9426 : H12AffineEnvironment.transform 8 43 env9425 = env9426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env9425 == env9426) = true)

def env9427 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,4194304,524525,16777216,8329,16855853,4985753,525104,525004,21502739,529252,17306182,524288,21500723,21781063,16778207]

theorem envBound9427 : H12AffineFastState.Bounded env9427 := by
  intro p hp
  have h : env9427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9413_9427 : H12AffineEnvironment.transform 20 285201 env9413 = env9427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9413 == env9427) = true)

theorem identity9427 : scanCanonicalize (H12AffineFastState.compose env9427 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9427 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9428 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,476,524525,16777216,8329,16855853,791109,525104,525004,17308367,529252,17306182,524288,17306351,17587099,16778207]

theorem envBound9428 : H12AffineFastState.Bounded env9428 := by
  intro p hp
  have h : env9428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9427_9428 : H12AffineEnvironment.transform 21 476 env9427 = env9428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9427 == env9428) = true)

theorem identity9428 : scanCanonicalize (H12AffineFastState.compose env9428 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9428 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9429 : List Nat := [2,4,8,16,32,64,41,256,512,256,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,285201,373,524356,16777216,8224,16855853,791109,525104,524901,17308262,529252,17306182,524288,17306182,17586994,16778102]

theorem envBound9429 : H12AffineFastState.Bounded env9429 := by
  intro p hp
  have h : env9429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9428_9429 : H12AffineEnvironment.transform 6 41 env9428 = env9429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9428 == env9429) = true)

theorem identity9429 : scanCanonicalize (H12AffineFastState.compose env9429 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9429 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9430 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,285201,32,524356,16777216,8224,16855672,791109,524901,524901,17308262,528945,17306182,524288,17306182,17586791,16777763]

theorem envBound9430 : H12AffineFastState.Bounded env9430 := by
  intro p hp
  have h : env9430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9429_9430 : H12AffineEnvironment.transform 7 85 env9429 = env9430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9429 == env9430) = true)

theorem identity9430 : scanCanonicalize (H12AffineFastState.compose env9430 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound9430 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9431 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8200,65536,4097,262144,78415,8200,285201,32,78347,16777216,8224,16855672,335882,77866,77866,16853033,73854,16850953,78415,16850953,17131560,16777763]

theorem envBound9431 : H12AffineFastState.Bounded env9431 := by
  intro p hp
  have h : env9431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9430_9431 : H12AffineEnvironment.transform 18 78415 env9430 = env9431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env9430 == env9431) = true)

theorem identity9431 : scanCanonicalize (H12AffineFastState.compose env9431 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336418) := by decide +kernel

theorem selectedBound9431 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9432 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8200,65536,4097,262144,78415,8200,285201,32,78347,336418,8224,266330,335882,77866,77866,264715,73854,262699,78415,262699,18954,335873]

theorem envBound9432 : H12AffineFastState.Bounded env9432 := by
  intro p hp
  have h : env9432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9431_9432 : H12AffineEnvironment.transform 23 336418 env9431 = env9432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336418 env9431 == env9432) = true)

theorem identity9432 : scanCanonicalize (H12AffineFastState.compose env9432 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16394) := by decide +kernel

theorem selectedBound9432 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9433 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8200,65536,4097,16394,78415,8200,6683,32,78347,90664,8224,20560,90112,77866,77866,18945,73854,16929,78415,16929,18954,90123]

theorem envBound9433 : H12AffineFastState.Bounded env9433 := by
  intro p hp
  have h : env9433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9432_9433 : H12AffineEnvironment.transform 17 16394 env9432 = env9433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16394 env9432 == env9433) = true)

theorem identity9433 : scanCanonicalize (H12AffineFastState.compose env9433 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14400) := by decide +kernel

theorem selectedBound9433 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9434 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8200,14400,4097,16394,2575,8200,6683,32,2635,23144,8224,20560,22592,2154,2154,18945,6206,16929,2575,16929,18954,22603]

theorem envBound9434 : H12AffineFastState.Bounded env9434 := by
  intro p hp
  have h : env9434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9433_9434 : H12AffineEnvironment.transform 15 14400 env9433 = env9434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14400 env9433 == env9434) = true)

theorem identity9434 : scanCanonicalize (H12AffineFastState.compose env9434 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound9434 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9435 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,8745,8200,14400,4097,8739,2575,8200,6683,32,2635,14401,8224,12921,14953,2154,2154,10280,6206,8200,2575,8200,10275,14946]

theorem envBound9435 : H12AffineFastState.Bounded env9435 := by
  intro p hp
  have h : env9435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9434_9435 : H12AffineEnvironment.transform 13 8745 env9434 = env9435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env9434 == env9435) = true)

theorem identity9435 : scanCanonicalize (H12AffineFastState.compose env9435 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6242) := by decide +kernel

theorem selectedBound9435 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9436 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,6242,6731,6250,34,4097,6721,2575,6250,6683,32,2635,35,6210,2587,523,2154,2154,4170,6206,6250,2575,6250,4161,512]

theorem envBound9436 : H12AffineFastState.Bounded env9436 := by
  intro p hp
  have h : env9436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9435_9436 : H12AffineEnvironment.transform 12 6242 env9435 = env9436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6242 env9435 == env9436) = true)

def env9437 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,16777216,8329,16855852,134217728,138678441,138678613,151259274,529253,155451871,524289,151257258,153359310,16778207]

theorem envBound9437 : H12AffineFastState.Bounded env9437 := by
  intro p hp
  have h : env9437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9386_9437 : H12AffineEnvironment.transform 9 257 env9386 = env9437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env9386 == env9437) = true)

def env9438 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,16777216,8329,16855852,4985752,525105,525005,21502738,529253,17306183,524289,21500722,23593046,16778207]

theorem envBound9438 : H12AffineFastState.Bounded env9438 := by
  intro p hp
  have h : env9438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9437_9438 : H12AffineEnvironment.transform 26 4985752 env9437 = env9438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985752 env9437 == env9438) = true)

def env9439 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,4194304,524524,16777216,8329,16855852,4985752,525105,525005,21502738,529253,17306183,524289,21500722,21781062,16778207]

theorem envBound9439 : H12AffineFastState.Bounded env9439 := by
  intro p hp
  have h : env9439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9438_9439 : H12AffineEnvironment.transform 20 285200 env9438 = env9439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9438 == env9439) = true)

theorem identity9439 : scanCanonicalize (H12AffineFastState.compose env9439 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9439 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9440 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,477,524524,16777216,8329,16855852,791109,525105,525005,17308367,529253,17306183,524289,17306351,17587099,16778207]

theorem envBound9440 : H12AffineFastState.Bounded env9440 := by
  intro p hp
  have h : env9440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9439_9440 : H12AffineEnvironment.transform 21 477 env9439 = env9440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9439 == env9440) = true)

theorem identity9440 : scanCanonicalize (H12AffineFastState.compose env9440 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9440 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9441 : List Nat := [2,4,8,16,32,64,40,256,512,257,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,285200,373,524356,16777216,8225,16855852,791109,525105,524901,17308263,529253,17306183,524289,17306183,17586995,16778103]

theorem envBound9441 : H12AffineFastState.Bounded env9441 := by
  intro p hp
  have h : env9441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9440_9441 : H12AffineEnvironment.transform 6 40 env9440 = env9441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9440 == env9441) = true)

theorem identity9441 : scanCanonicalize (H12AffineFastState.compose env9441 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9441 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9442 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,285200,33,524356,16777216,8225,16855672,791109,524901,524901,17308263,528945,17306183,524289,17306183,17586791,16777763]

theorem envBound9442 : H12AffineFastState.Bounded env9442 := by
  intro p hp
  have h : env9442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9441_9442 : H12AffineEnvironment.transform 7 84 env9441 = env9442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9441 == env9442) = true)

theorem identity9442 : scanCanonicalize (H12AffineFastState.compose env9442 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound9442 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9443 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8200,65536,4097,262144,78414,8200,285200,33,78346,16777216,8225,16855672,335883,77867,77867,16853033,73855,16850953,78415,16850953,17131561,16777763]

theorem envBound9443 : H12AffineFastState.Bounded env9443 := by
  intro p hp
  have h : env9443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9442_9443 : H12AffineEnvironment.transform 18 78414 env9442 = env9443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env9442 == env9443) = true)

theorem identity9443 : scanCanonicalize (H12AffineFastState.compose env9443 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336418) := by decide +kernel

theorem selectedBound9443 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9444 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8200,65536,4097,262144,78414,8200,285200,33,78346,336418,8225,266330,335883,77867,77867,264715,73855,262699,78415,262699,18955,335873]

theorem envBound9444 : H12AffineFastState.Bounded env9444 := by
  intro p hp
  have h : env9444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9443_9444 : H12AffineEnvironment.transform 23 336418 env9443 = env9444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336418 env9443 == env9444) = true)

theorem identity9444 : scanCanonicalize (H12AffineFastState.compose env9444 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16394) := by decide +kernel

theorem selectedBound9444 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9445 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8200,65536,4097,16394,78414,8200,6682,33,78346,90664,8225,20560,90113,77867,77867,18945,73855,16929,78415,16929,18955,90123]

theorem envBound9445 : H12AffineFastState.Bounded env9445 := by
  intro p hp
  have h : env9445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9444_9445 : H12AffineEnvironment.transform 17 16394 env9444 = env9445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16394 env9444 == env9445) = true)

theorem identity9445 : scanCanonicalize (H12AffineFastState.compose env9445 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14401) := by decide +kernel

theorem selectedBound9445 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9446 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8200,14401,4097,16394,2575,8200,6682,33,2635,23145,8225,20560,22592,2154,2154,18945,6206,16929,2574,16929,18955,22602]

theorem envBound9446 : H12AffineFastState.Bounded env9446 := by
  intro p hp
  have h : env9446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9445_9446 : H12AffineEnvironment.transform 15 14401 env9445 = env9446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14401 env9445 == env9446) = true)

theorem identity9446 : scanCanonicalize (H12AffineFastState.compose env9446 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound9446 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9447 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,8745,8200,14401,4097,8739,2575,8200,6682,33,2635,14400,8225,12921,14953,2154,2154,10280,6206,8200,2574,8200,10274,14947]

theorem envBound9447 : H12AffineFastState.Bounded env9447 := by
  intro p hp
  have h : env9447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9446_9447 : H12AffineEnvironment.transform 13 8745 env9446 = env9447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env9446 == env9447) = true)

theorem identity9447 : scanCanonicalize (H12AffineFastState.compose env9447 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6243) := by decide +kernel

theorem selectedBound9447 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9448 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,6243,6730,6251,34,4097,6720,2575,6251,6682,33,2635,35,6210,2586,522,2154,2154,4171,6206,6251,2574,6251,4161,512]

theorem envBound9448 : H12AffineFastState.Bounded env9448 := by
  intro p hp
  have h : env9448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9447_9448 : H12AffineEnvironment.transform 12 6243 env9447 = env9448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6243 env9447 == env9448) = true)

theorem identity9448 : scanCanonicalize (H12AffineFastState.compose env9448 (packedSelected [0,1,2,4,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 609) := by decide +kernel

theorem selectedBound9448 : packedSelected [0,1,2,4,5,13] rootPS < 2^1333 := by decide +kernel

def env9449 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,609,2562,2091,2570,34,608,2081,2575,2570,2171,33,2635,35,2595,2586,522,2154,2154,554,2655,2570,2574,2570,544,512]

theorem envBound9449 : H12AffineFastState.Bounded env9449 := by
  intro p hp
  have h : env9449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9448_9449 : H12AffineEnvironment.transform 11 609 env9448 = env9449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 609 env9448 == env9449) = true)

def env9450 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,4194304,524524,16777216,8329,16855852,4985752,525105,525005,21502738,529253,17306183,524289,21500722,21781063,16778207]

theorem envBound9450 : H12AffineFastState.Bounded env9450 := by
  intro p hp
  have h : env9450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9438_9450 : H12AffineEnvironment.transform 20 285201 env9438 = env9450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9438 == env9450) = true)

theorem identity9450 : scanCanonicalize (H12AffineFastState.compose env9450 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9450 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9451 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,372,524524,16777216,8329,16855852,791276,525105,525005,17308262,529253,17306183,524289,17306182,17586995,16778207]

theorem envBound9451 : H12AffineFastState.Bounded env9451 := by
  intro p hp
  have h : env9451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9450_9451 : H12AffineEnvironment.transform 21 372 env9450 = env9451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9450 == env9451) = true)

theorem identity9451 : scanCanonicalize (H12AffineFastState.compose env9451 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9451 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9452 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,372,524524,35,8329,78607,791276,525105,525005,531013,529253,528996,524289,528997,809744,1020]

theorem envBound9452 : H12AffineFastState.Bounded env9452 := by
  intro p hp
  have h : env9452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9451_9452 : H12AffineEnvironment.transform 23 35 env9451 = env9452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9451 == env9452) = true)

theorem identity9452 : scanCanonicalize (H12AffineFastState.compose env9452 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342727) := by decide +kernel

theorem selectedBound9452 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9453 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,342727,8692,285201,372,342571,35,8329,78607,75819,342518,342026,336002,338338,338083,342726,338082,90583,1020]

theorem envBound9453 : H12AffineFastState.Bounded env9453 := by
  intro p hp
  have h : env9453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9452_9453 : H12AffineEnvironment.transform 18 342727 env9452 = env9453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342727 env9452 == env9453) = true)

theorem identity9453 : scanCanonicalize (H12AffineFastState.compose env9453 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound9453 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9454 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,2421,78770,8692,21348,372,78686,35,8329,78607,75819,77955,78207,76279,73943,74198,78771,74199,90583,1020]

theorem envBound9454 : H12AffineFastState.Bounded env9454 := by
  intro p hp
  have h : env9454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9453_9454 : H12AffineEnvironment.transform 17 2421 env9453 = env9454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env9453 == env9454) = true)

theorem identity9454 : scanCanonicalize (H12AffineFastState.compose env9454 (packedSelected [3,4,5,6,7,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound9454 : packedSelected [3,4,5,6,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env9455 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,4373,8692,65536,4605,2421,78770,8692,625,372,78686,35,8329,78607,75819,77955,78207,76279,73943,74198,78771,74199,78018,1020]

theorem envBound9455 : H12AffineFastState.Bounded env9455 := by
  intro p hp
  have h : env9455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9454_9455 : H12AffineEnvironment.transform 13 4373 env9454 = env9455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env9454 == env9455) = true)

theorem identity9455 : scanCanonicalize (H12AffineFastState.compose env9455 (packedSelected [1,2,3,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 278) := by decide +kernel

theorem selectedBound9455 : packedSelected [1,2,3,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1