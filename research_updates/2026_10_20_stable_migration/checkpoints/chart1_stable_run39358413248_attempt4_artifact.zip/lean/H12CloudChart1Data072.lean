import H12CloudChart1Data071

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env18162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180273,144476,243088,8328,65,43477,139613,160077,56437,1501,33,256,21793,46212,74250]

theorem envBound18162 : H12AffineFastState.Bounded env18162 := by
  intro p hp
  have h : env18162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18144_18162 : H12AffineEnvironment.transform 17 10281 env18144 = env18162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env18144 == env18162) = true)

def env18163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,21793,41292,73856,8328,65,43477,46157,58461,56437,1501,33,256,21793,46212,74250]

theorem envBound18163 : H12AffineFastState.Bounded env18163 := by
  intro p hp
  have h : env18163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18162_18163 : H12AffineEnvironment.transform 16 38160 env18162 = env18163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env18162 == env18163) = true)

theorem identity18163 : scanCanonicalize (H12AffineFastState.compose env18163 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18163 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38160,10281,1024,32769,4161,21793,41292,2,8328,65,43477,46157,58461,56437,1501,33,256,21793,46212,648]

theorem envBound18164 : H12AffineFastState.Bounded env18164 := by
  intro p hp
  have h : env18164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18163_18164 : H12AffineEnvironment.transform 15 8322 env18163 = env18164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18163 == env18164) = true)

theorem identity18164 : scanCanonicalize (H12AffineFastState.compose env18164 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound18164 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env18165 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8282,38160,10281,1024,32769,4161,21793,41292,2,8272,65,43277,46157,58461,56437,1285,33,256,21793,46172,592]

theorem envBound18165 : H12AffineFastState.Bounded env18165 := by
  intro p hp
  have h : env18165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18164_18165 : H12AffineEnvironment.transform 6 88 env18164 = env18165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18164 == env18165) = true)

theorem identity18165 : scanCanonicalize (H12AffineFastState.compose env18165 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound18165 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env18166 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21841,8282,16449,10281,1024,21840,4161,21793,29725,2,8272,65,31836,24860,12556,2340,1285,33,256,21793,24845,592]

theorem envBound18166 : H12AffineFastState.Bounded env18166 := by
  intro p hp
  have h : env18166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18165_18166 : H12AffineEnvironment.transform 14 21841 env18165 = env18166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env18165 == env18166) = true)

theorem identity18166 : scanCanonicalize (H12AffineFastState.compose env18166 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18166 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18167 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,16384,21841,342,16449,2341,1024,21840,4161,21793,21777,2,348,65,23888,16400,4096,2340,1285,33,256,21793,16385,592]

theorem envBound18167 : H12AffineFastState.Bounded env18167 := by
  intro p hp
  have h : env18167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18166_18167 : H12AffineEnvironment.transform 12 268 env18166 = env18167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18166 == env18167) = true)

theorem identity18167 : scanCanonicalize (H12AffineFastState.compose env18167 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound18167 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env18168 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5457,0,342,5392,2341,1024,1,4161,112,64,2,348,65,2049,5441,4096,2340,1285,33,256,112,5456,592]

theorem envBound18168 : H12AffineFastState.Bounded env18168 := by
  intro p hp
  have h : env18168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18167_18168 : H12AffineEnvironment.transform 13 5457 env18167 = env18168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env18167 == env18168) = true)

theorem identity18168 : scanCanonicalize (H12AffineFastState.compose env18168 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18168 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18169 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4113,32,16,2,268,17,2049,5393,4096,2340,1285,33,256,32,5376,512]

theorem envBound18169 : H12AffineFastState.Bounded env18169 := by
  intro p hp
  have h : env18169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18168_18169 : H12AffineEnvironment.transform 5 16 env18168 = env18169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18168 == env18169) = true)

theorem identity18169 : scanCanonicalize (H12AffineFastState.compose env18169 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18170 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,268,5377,0,262,5392,2308,1024,1,4113,1,16,2,268,17,2049,5393,4096,2309,1285,0,256,1,5376,512]

theorem envBound18170 : H12AffineFastState.Bounded env18170 := by
  intro p hp
  have h : env18170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18169_18170 : H12AffineEnvironment.transform 4 1 env18169 = env18170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18169 == env18170) = true)

theorem identity18170 : scanCanonicalize (H12AffineFastState.compose env18170 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound18170 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18171 : List Nat := [2,4,8,16,1,16,8,256,512,1024,523,4096,268,5377,0,262,5392,783,1024,1,4113,1,16,2,268,17,522,5393,4096,782,1285,0,256,1,5376,512]

theorem envBound18171 : H12AffineFastState.Bounded env18171 := by
  intro p hp
  have h : env18171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18170_18171 : H12AffineEnvironment.transform 10 523 env18170 = env18171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env18170 == env18171) = true)

def env18172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,21792,41293,73857,8328,65,43477,46156,58460,56437,1501,33,256,21793,46212,74250]

theorem envBound18172 : H12AffineFastState.Bounded env18172 := by
  intro p hp
  have h : env18172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18162_18172 : H12AffineEnvironment.transform 16 38161 env18162 = env18172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env18162 == env18172) = true)

theorem identity18172 : scanCanonicalize (H12AffineFastState.compose env18172 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18172 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1024,32769,4161,21792,41293,138,8328,65,43477,46156,58460,56437,1501,33,256,21793,46212,513]

theorem envBound18173 : H12AffineFastState.Bounded env18173 := by
  intro p hp
  have h : env18173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18172_18173 : H12AffineEnvironment.transform 15 8203 env18172 = env18173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18172 == env18173) = true)

theorem identity18173 : scanCanonicalize (H12AffineFastState.compose env18173 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18173 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env18174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,38161,10281,1024,32769,4161,169,41293,138,8328,65,43477,46156,45525,35324,1501,33,256,168,46212,513]

theorem envBound18174 : H12AffineFastState.Bounded env18174 := by
  intro p hp
  have h : env18174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18173_18174 : H12AffineEnvironment.transform 13 5513 env18173 = env18174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18173 == env18174) = true)

theorem identity18174 : scanCanonicalize (H12AffineFastState.compose env18174 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound18174 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env18175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5513,32768,34,38161,2048,1024,32769,4161,169,33124,138,161,65,35324,37989,37372,35324,1501,33,256,168,38061,513]

theorem envBound18175 : H12AffineFastState.Bounded env18175 := by
  intro p hp
  have h : env18175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18174_18175 : H12AffineEnvironment.transform 12 41 env18174 = env18175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18174 == env18175) = true)

theorem identity18175 : scanCanonicalize (H12AffineFastState.compose env18175 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound18175 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env18176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5513,372,34,5221,2048,1024,373,4161,169,16,138,161,65,2184,5393,4232,2184,1501,33,256,168,5593,513]

theorem envBound18176 : H12AffineFastState.Bounded env18176 := by
  intro p hp
  have h : env18176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18175_18176 : H12AffineEnvironment.transform 14 372 env18175 = env18176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env18175 == env18176) = true)

theorem identity18176 : scanCanonicalize (H12AffineFastState.compose env18176 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18176 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,372,34,5221,2048,1024,373,4161,33,16,2,41,65,2048,5393,4096,2048,1365,33,256,32,5457,513]

theorem envBound18177 : H12AffineFastState.Bounded env18177 := by
  intro p hp
  have h : env18177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18176_18177 : H12AffineEnvironment.transform 6 8 env18176 = env18177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18176 == env18177) = true)

theorem identity18177 : scanCanonicalize (H12AffineFastState.compose env18177 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound18177 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,4096,41,5377,372,34,5221,373,1024,373,4161,33,16,2,41,65,373,5393,4096,373,1365,33,256,32,5457,513]

theorem envBound18178 : H12AffineFastState.Bounded env18178 := by
  intro p hp
  have h : env18178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18177_18178 : H12AffineEnvironment.transform 10 373 env18177 = env18178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env18177 == env18178) = true)

theorem identity18178 : scanCanonicalize (H12AffineFastState.compose env18178 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound18178 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env18179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1061,41,292,372,34,64,373,1024,373,1124,33,16,2,41,65,373,308,1061,373,1365,33,256,32,372,513]

theorem envBound18179 : H12AffineFastState.Bounded env18179 := by
  intro p hp
  have h : env18179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18178_18179 : H12AffineEnvironment.transform 11 1061 env18178 = env18179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env18178 == env18179) = true)

theorem identity18179 : scanCanonicalize (H12AffineFastState.compose env18179 (packedSelected [2,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18179 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env18180 : List Nat := [2,4,8,16,32,64,8,256,512,272,373,309,41,292,372,34,64,373,272,373,372,33,16,2,41,65,373,308,309,373,69,33,256,32,372,513]

theorem envBound18180 : H12AffineFastState.Bounded env18180 := by
  intro p hp
  have h : env18180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18179_18180 : H12AffineEnvironment.transform 9 272 env18179 = env18180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18179 == env18180) = true)

def env18181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound18181 : H12AffineFastState.Bounded env18181 := by
  intro p hp
  have h : env18181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17963_18181 : H12AffineEnvironment.transform 18 1025 env17963 = env18181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17963 == env18181) = true)

theorem identity18181 : scanCanonicalize (H12AffineFastState.compose env18181 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485429) := by decide +kernel

theorem selectedBound18181 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485429,8328,65,14822581,288824,10507600,8830977,10774692,4491636,257,8661016,8702396,10833778]

theorem envBound18182 : H12AffineFastState.Bounded env18182 := by
  intro p hp
  have h : env18182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18181_18182 : H12AffineEnvironment.transform 23 2485429 env18181 = env18182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485429 env18181 == env18182) = true)

def env18183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294200,2485429,8328,65,6705549,288824,2369640,179513,2102684,4491636,257,21792,46212,2175562]

theorem envBound18183 : H12AffineFastState.Bounded env18183 := by
  intro p hp
  have h : env18183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18182_18183 : H12AffineEnvironment.transform 22 294200 env18182 = env18183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294200 env18182 == env18183) = true)

def env18184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294200,98781,8328,65,4340965,288824,17664,179513,293108,4491636,257,21792,46212,352034]

theorem envBound18184 : H12AffineFastState.Bounded env18184 := by
  intro p hp
  have h : env18184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18183_18184 : H12AffineEnvironment.transform 20 290152 env18183 = env18184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env18183 == env18184) = true)

def env18185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294200,98781,8328,65,398437,288824,17664,179513,293108,41460,257,21792,46212,352034]

theorem envBound18185 : H12AffineFastState.Bounded env18185 := by
  intro p hp
  have h : env18185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18184_18185 : H12AffineEnvironment.transform 21 272512 env18184 = env18185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18184 == env18185) = true)

theorem identity18185 : scanCanonicalize (H12AffineFastState.compose env18185 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound18185 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35324,1025,32769,58516,41340,62660,98781,8328,65,171417,57796,17664,179513,61704,41460,257,21792,46212,120542]

theorem envBound18186 : H12AffineFastState.Bounded env18186 := by
  intro p hp
  have h : env18186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18185_18186 : H12AffineEnvironment.transform 17 35324 env18185 = env18186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env18185 == env18186) = true)

def env18187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35324,1025,32769,45460,41340,41412,98781,8328,65,171417,46276,4096,179513,41992,41460,257,32,46212,99294]

theorem envBound18187 : H12AffineFastState.Bounded env18187 := by
  intro p hp
  have h : env18187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18186_18187 : H12AffineEnvironment.transform 13 5376 env18186 = env18187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18186 == env18187) = true)

theorem identity18187 : scanCanonicalize (H12AffineFastState.compose env18187 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,131072,35324,1025,32769,45460,41340,41412,41311,8328,65,171417,46276,4096,179513,41992,41460,257,32,46212,41820]

theorem envBound18188 : H12AffineFastState.Bounded env18188 := by
  intro p hp
  have h : env18188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18187_18188 : H12AffineEnvironment.transform 15 8322 env18187 = env18188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18187 == env18188) = true)

theorem identity18188 : scanCanonicalize (H12AffineFastState.compose env18188 (packedSelected [0,1,8,10,12,18,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound18188 : packedSelected [0,1,8,10,12,18,20,27] rootPS < 2^1333 := by decide +kernel

def env18189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8322,131072,10281,1025,8660,4161,169,17,138,8328,65,146508,5393,4096,138476,1501,33,257,32,5457,649]

theorem envBound18189 : H12AffineFastState.Bounded env18189 := by
  intro p hp
  have h : env18189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18188_18189 : H12AffineEnvironment.transform 14 8661 env18188 = env18189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env18188 == env18189) = true)

theorem identity18189 : scanCanonicalize (H12AffineFastState.compose env18189 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound18189 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,381,5376,168,511,131072,2388,1025,169,4161,169,17,138,501,65,138545,5393,4096,138476,1501,33,257,32,5457,649]

theorem envBound18190 : H12AffineFastState.Bounded env18190 := by
  intro p hp
  have h : env18190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18189_18190 : H12AffineEnvironment.transform 12 381 env18189 = env18190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env18189 == env18190) = true)

def env18191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35324,1025,32769,45461,41340,41413,98781,8328,65,171417,46277,4097,179513,41993,41460,257,33,46212,99295]

theorem envBound18191 : H12AffineFastState.Bounded env18191 := by
  intro p hp
  have h : env18191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18186_18191 : H12AffineEnvironment.transform 13 5377 env18186 = env18191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18186 == env18191) = true)

theorem identity18191 : scanCanonicalize (H12AffineFastState.compose env18191 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound18191 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,35324,1025,32769,45461,41340,41413,3,8328,65,171417,46277,4097,179513,41993,41460,257,33,46212,513]

theorem envBound18192 : H12AffineFastState.Bounded env18192 := by
  intro p hp
  have h : env18192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18191_18192 : H12AffineEnvironment.transform 15 33246 env18191 = env18192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env18191 == env18192) = true)

theorem identity18192 : scanCanonicalize (H12AffineFastState.compose env18192 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound18192 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env18193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,46276,35324,1025,32769,45461,41340,41413,3,8328,65,10589,46277,4097,2557,41993,41460,257,33,46212,513]

theorem envBound18193 : H12AffineFastState.Bounded env18193 := by
  intro p hp
  have h : env18193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18192_18193 : H12AffineEnvironment.transform 16 46276 env18192 = env18193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env18192 == env18193) = true)

theorem identity18193 : scanCanonicalize (H12AffineFastState.compose env18193 (packedSelected [1,2,3,6,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18193 : packedSelected [1,2,3,6,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env18194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,32768,33246,38344,35324,1025,32769,37017,32880,32969,3,388,65,2129,38345,4097,2557,34053,33016,257,33,38280,513]

theorem envBound18194 : H12AffineFastState.Bounded env18194 := by
  intro p hp
  have h : env18194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18193_18194 : H12AffineEnvironment.transform 12 268 env18193 = env18194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18193 == env18194) = true)

theorem identity18194 : scanCanonicalize (H12AffineFastState.compose env18194 (packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18194 : packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env18195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,33111,38209,35189,1025,32769,36880,32880,32832,3,269,65,2129,38208,4097,2420,34053,32881,257,33,38145,513]

theorem envBound18195 : H12AffineFastState.Bounded env18195 := by
  intro p hp
  have h : env18195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18194_18195 : H12AffineEnvironment.transform 6 9 env18194 = env18195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18194 == env18195) = true)

theorem identity18195 : scanCanonicalize (H12AffineFastState.compose env18195 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound18195 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,262,5392,2340,1025,80,4161,33,17,3,269,65,2129,5393,4097,2420,1364,32,257,33,5456,513]

theorem envBound18196 : H12AffineFastState.Bounded env18196 := by
  intro p hp
  have h : env18196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18195_18196 : H12AffineEnvironment.transform 14 81 env18195 = env18196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env18195 == env18196) = true)

theorem identity18196 : scanCanonicalize (H12AffineFastState.compose env18196 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1604) := by decide +kernel

theorem selectedBound18196 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1604,268,837,81,262,852,2340,1025,80,1541,33,17,3,269,65,2129,853,1605,2420,1364,32,257,33,788,513]

theorem envBound18197 : H12AffineFastState.Bounded env18197 := by
  intro p hp
  have h : env18197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18196_18197 : H12AffineEnvironment.transform 11 1604 env18196 = env18197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1604 env18196 == env18197) = true)

theorem identity18197 : scanCanonicalize (H12AffineFastState.compose env18197 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound18197 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18198 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,1604,89,528,81,83,513,2161,1025,80,1541,33,17,3,88,65,2129,512,1605,2081,1025,32,84,33,577,513]

theorem envBound18198 : H12AffineFastState.Bounded env18198 := by
  intro p hp
  have h : env18198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18197_18198 : H12AffineEnvironment.transform 7 85 env18197 = env18198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env18197 == env18198) = true)

theorem identity18198 : scanCanonicalize (H12AffineFastState.compose env18198 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18198 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env18199 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,1556,9,528,1,3,513,2081,1025,0,1541,33,17,3,8,17,2049,512,1557,2081,1025,32,4,33,529,513]

theorem envBound18199 : H12AffineFastState.Bounded env18199 := by
  intro p hp
  have h : env18199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18198_18199 : H12AffineEnvironment.transform 5 16 env18198 = env18199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18198 == env18199) = true)

theorem identity18199 : scanCanonicalize (H12AffineFastState.compose env18199 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound18199 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18200 : List Nat := [2,4,8,16,32,16,9,5,512,37,2048,561,9,528,1,3,513,2081,36,0,544,33,17,3,8,17,2049,512,560,2081,36,32,4,33,529,513]

theorem envBound18200 : H12AffineFastState.Bounded env18200 := by
  intro p hp
  have h : env18200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18199_18200 : H12AffineEnvironment.transform 9 37 env18199 = env18200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env18199 == env18200) = true)

theorem identity18200 : scanCanonicalize (H12AffineFastState.compose env18200 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound18200 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18201 : List Nat := [2,4,8,16,32,16,9,5,512,37,512,561,9,528,1,3,513,545,36,0,544,33,17,3,8,17,513,512,560,545,36,32,4,33,529,513]

theorem envBound18201 : H12AffineFastState.Bounded env18201 := by
  intro p hp
  have h : env18201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18200_18201 : H12AffineEnvironment.transform 10 512 env18200 = env18201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env18200 == env18201) = true)

theorem identity18201 : scanCanonicalize (H12AffineFastState.compose env18201 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18201 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18202 : List Nat := [2,4,8,16,16,16,9,5,512,21,512,513,9,528,1,3,513,529,20,0,528,17,17,3,8,17,513,512,512,529,20,16,4,17,529,513]

theorem envBound18202 : H12AffineFastState.Bounded env18202 := by
  intro p hp
  have h : env18202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18201_18202 : H12AffineEnvironment.transform 4 16 env18201 = env18202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18201 == env18202) = true)

theorem identity18202 : scanCanonicalize (H12AffineFastState.compose env18202 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18203 : List Nat := [2,4,8,16,16,16,9,5,1,21,1,0,9,17,1,3,0,16,20,0,17,17,17,3,8,17,0,1,1,16,20,16,4,17,16,0]

theorem envBound18203 : H12AffineFastState.Bounded env18203 := by
  intro p hp
  have h : env18203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18202_18203 : H12AffineEnvironment.transform 8 1 env18202 = env18203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18202 == env18203) = true)

theorem identity18203 : scanCanonicalize (H12AffineFastState.compose env18203 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18203 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18204 : List Nat := [2,4,8,1,1,1,9,5,1,4,1,0,9,0,1,3,0,1,5,0,0,0,0,3,8,0,0,1,1,1,5,1,4,0,1,0]

theorem envBound18204 : H12AffineFastState.Bounded env18204 := by
  intro p hp
  have h : env18204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18203_18204 : H12AffineEnvironment.transform 3 1 env18203 = env18204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18203 == env18204) = true)

def env18205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294200,98781,8328,65,398436,288824,17664,179513,293108,41461,257,21792,46212,352034]

theorem envBound18205 : H12AffineFastState.Bounded env18205 := by
  intro p hp
  have h : env18205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18184_18205 : H12AffineEnvironment.transform 21 272513 env18184 = env18205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18184 == env18205) = true)

theorem identity18205 : scanCanonicalize (H12AffineFastState.compose env18205 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18205 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,290152,272513,294200,95496,8328,65,398436,288824,17664,149996,293108,21792,257,21792,16465,352034]

theorem envBound18206 : H12AffineFastState.Bounded env18206 := by
  intro p hp
  have h : env18206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18205_18206 : H12AffineEnvironment.transform 14 29909 env18205 = env18206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18205 == env18206) = true)

theorem identity18206 : scanCanonicalize (H12AffineFastState.compose env18206 (packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound18206 : packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS < 2^1333 := by decide +kernel

def env18207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30083,131072,262144,1025,29908,290152,272513,294200,139,8328,65,398436,288824,17664,149996,293108,21792,257,21792,16465,273057]

theorem envBound18207 : H12AffineFastState.Bounded env18207 := by
  intro p hp
  have h : env18207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18206_18207 : H12AffineEnvironment.transform 15 30083 env18206 = env18207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env18206 == env18207) = true)

theorem identity18207 : scanCanonicalize (H12AffineFastState.compose env18207 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound18207 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env18208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30083,131072,2476,1025,29908,25796,8493,29844,139,8328,65,138696,24980,17664,149996,29016,21792,257,21792,16465,8973]

theorem envBound18208 : H12AffineFastState.Bounded env18208 := by
  intro p hp
  have h : env18208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18207_18208 : H12AffineEnvironment.transform 17 2476 env18207 = env18208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env18207 == env18208) = true)

theorem identity18208 : scanCanonicalize (H12AffineFastState.compose env18208 (packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound18208 : packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env18209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,16384,20924,20714,131072,2476,1025,20925,16813,1092,20989,139,1505,65,138696,17661,17664,149996,21553,21792,257,21792,16465,1636]

theorem envBound18209 : H12AffineFastState.Bounded env18209 := by
  intro p hp
  have h : env18209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18208_18209 : H12AffineEnvironment.transform 12 1385 env18208 = env18209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env18208 == env18209) = true)

theorem identity18209 : scanCanonicalize (H12AffineFastState.compose env18209 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 16585) := by decide +kernel

theorem selectedBound18209 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env18210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,16384,20924,20714,16585,2476,1025,20925,16813,1092,20989,139,1505,65,23809,17661,17664,2341,21553,21792,257,21792,16465,1636]

theorem envBound18210 : H12AffineFastState.Bounded env18210 := by
  intro p hp
  have h : env18210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18209_18210 : H12AffineEnvironment.transform 16 16585 env18209 = env18210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16585 env18209 == env18210) = true)

theorem identity18210 : scanCanonicalize (H12AffineFastState.compose env18210 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound18210 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env18211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,2184,6452,6242,2113,2476,1025,6453,2341,1092,6517,139,1505,65,5513,3189,3464,2341,7353,7592,257,7592,2265,1636]

theorem envBound18211 : H12AffineFastState.Bounded env18211 := by
  intro p hp
  have h : env18211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18210_18211 : H12AffineEnvironment.transform 13 2184 env18210 = env18211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env18210 == env18211) = true)

theorem identity18211 : scanCanonicalize (H12AffineFastState.compose env18211 (packedSelected [10,12,19] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound18211 : packedSelected [10,12,19] rootPS < 2^1333 := by decide +kernel

def env18212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,153,1385,2184,2477,2299,2113,2476,1025,2476,2341,1092,2540,139,1505,65,1296,3189,3464,2341,3104,3377,257,3377,2265,1636]

theorem envBound18212 : H12AffineFastState.Bounded env18212 := by
  intro p hp
  have h : env18212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18211_18212 : H12AffineEnvironment.transform 11 153 env18211 = env18212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env18211 == env18212) = true)

theorem identity18212 : scanCanonicalize (H12AffineFastState.compose env18212 (packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound18212 : packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env18213 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,153,1220,2184,2048,2299,2113,2049,1025,2049,2184,1092,2113,139,1100,65,1213,3189,3109,2184,3104,3228,172,3228,2265,1636]

theorem envBound18213 : H12AffineFastState.Bounded env18213 := by
  intro p hp
  have h : env18213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18212_18213 : H12AffineEnvironment.transform 7 173 env18212 = env18213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env18212 == env18213) = true)

theorem identity18213 : scanCanonicalize (H12AffineFastState.compose env18213 (packedSelected [0,1,3,5,7,8,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound18213 : packedSelected [0,1,3,5,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env18214 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,65,1052,2128,2048,2083,2113,2049,1025,2049,2128,1092,2113,83,1100,65,1125,3189,3109,2128,3104,3140,116,3140,2049,1636]

theorem envBound18214 : H12AffineFastState.Bounded env18214 := by
  intro p hp
  have h : env18214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18213_18214 : H12AffineEnvironment.transform 6 88 env18213 = env18214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18213 == env18214) = true)

theorem identity18214 : scanCanonicalize (H12AffineFastState.compose env18214 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound18214 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env18215 : List Nat := [2,4,8,16,32,64,88,117,512,1024,1141,65,1052,1061,1141,1110,1076,1140,1025,1140,1061,1092,1076,83,1100,65,1125,0,80,1061,85,49,116,49,1140,1636]

theorem envBound18215 : H12AffineFastState.Bounded env18215 := by
  intro p hp
  have h : env18215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18214_18215 : H12AffineEnvironment.transform 10 1141 env18214 = env18215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env18214 == env18215) = true)

theorem identity18215 : scanCanonicalize (H12AffineFastState.compose env18215 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound18215 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18216 : List Nat := [2,4,8,16,32,64,88,117,512,117,0,65,105,80,0,35,65,1,116,1,80,49,65,83,57,65,16,0,80,80,85,49,116,49,1,529]

theorem envBound18216 : H12AffineFastState.Bounded env18216 := by
  intro p hp
  have h : env18216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18215_18216 : H12AffineEnvironment.transform 9 117 env18215 = env18216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env18215 == env18216) = true)

theorem identity18216 : scanCanonicalize (H12AffineFastState.compose env18216 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18216 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env18217 : List Nat := [2,4,8,0,32,64,72,101,512,101,0,65,105,64,0,35,65,1,100,1,64,33,65,67,41,65,0,0,64,64,69,33,100,33,1,513]

theorem envBound18217 : H12AffineFastState.Bounded env18217 := by
  intro p hp
  have h : env18217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18216_18217 : H12AffineEnvironment.transform 3 0 env18216 = env18217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18216 == env18217) = true)

theorem identity18217 : scanCanonicalize (H12AffineFastState.compose env18217 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound18217 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18218 : List Nat := [2,4,8,0,32,0,8,37,512,37,0,1,41,0,0,35,1,1,36,1,0,33,1,3,41,1,0,0,0,0,5,33,36,33,1,513]

theorem envBound18218 : H12AffineFastState.Bounded env18218 := by
  intro p hp
  have h : env18218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18217_18218 : H12AffineEnvironment.transform 5 0 env18217 = env18218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env18217 == env18218) = true)

theorem identity18218 : scanCanonicalize (H12AffineFastState.compose env18218 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound18218 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18219 : List Nat := [2,4,8,0,32,0,8,37,32,37,0,1,41,0,0,35,1,1,36,1,0,33,1,3,41,1,0,0,0,0,5,33,36,33,1,33]

theorem envBound18219 : H12AffineFastState.Bounded env18219 := by
  intro p hp
  have h : env18219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18218_18219 : H12AffineEnvironment.transform 8 32 env18218 = env18219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env18218 == env18219) = true)

theorem identity18219 : scanCanonicalize (H12AffineFastState.compose env18219 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18219 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18220 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,1,8,0,0,2,1,1,5,1,0,0,1,3,8,1,0,0,0,0,5,0,5,0,1,0]

theorem envBound18220 : H12AffineFastState.Bounded env18220 := by
  intro p hp
  have h : env18220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18219_18220 : H12AffineEnvironment.transform 4 1 env18219 = env18220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18219 == env18220) = true)

def env18221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294200,98780,8328,65,4340964,288824,17665,179513,293109,4491636,257,21792,46212,352035]

theorem envBound18221 : H12AffineFastState.Bounded env18221 := by
  intro p hp
  have h : env18221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18183_18221 : H12AffineEnvironment.transform 20 290153 env18183 = env18221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env18183 == env18221) = true)

def env18222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294200,98780,8328,65,398436,288824,17665,179513,293109,41460,257,21792,46212,352035]

theorem envBound18222 : H12AffineFastState.Bounded env18222 := by
  intro p hp
  have h : env18222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18221_18222 : H12AffineEnvironment.transform 21 272512 env18221 = env18222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18221 == env18222) = true)

theorem identity18222 : scanCanonicalize (H12AffineFastState.compose env18222 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound18222 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21929,17,98780,8328,65,158029,5393,17665,179513,1500,41460,257,21792,46212,74250]

theorem envBound18223 : H12AffineFastState.Bounded env18223 := by
  intro p hp
  have h : env18223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18222_18223 : H12AffineEnvironment.transform 17 32041 env18222 = env18223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env18222 == env18223) = true)

theorem identity18223 : scanCanonicalize (H12AffineFastState.compose env18223 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18223 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4160,21929,17,41431,8328,65,158029,5393,17665,179513,1500,41460,257,21792,46212,513]

theorem envBound18224 : H12AffineFastState.Bounded env18224 := by
  intro p hp
  have h : env18224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18223_18224 : H12AffineEnvironment.transform 15 8203 env18223 = env18224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18223 == env18224) = true)

theorem identity18224 : scanCanonicalize (H12AffineFastState.compose env18224 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound18224 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env18225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,131072,32041,1025,29709,4160,21929,17,21979,8328,65,158029,5393,17665,149813,1500,22008,257,21792,16520,513]

theorem envBound18225 : H12AffineFastState.Bounded env18225 := by
  intro p hp
  have h : env18225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18224_18225 : H12AffineEnvironment.transform 14 29708 env18224 = env18225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env18224 == env18225) = true)

def env18226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8540,8203,131072,10361,1025,8541,4160,249,17,139,8328,65,146461,5393,4177,138341,1500,168,257,112,5592,513]

theorem envBound18226 : H12AffineFastState.Bounded env18226 := by
  intro p hp
  have h : env18226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18225_18226 : H12AffineEnvironment.transform 13 5456 env18225 = env18226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env18225 == env18226) = true)

theorem identity18226 : scanCanonicalize (H12AffineFastState.compose env18226 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18226 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,8203,131072,10361,1025,8541,4160,113,17,3,8192,65,146461,5393,4177,138341,1364,32,257,112,5456,513]

theorem envBound18227 : H12AffineFastState.Bounded env18227 := by
  intro p hp
  have h : env18227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18226_18227 : H12AffineEnvironment.transform 6 8 env18226 = env18227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18226 == env18227) = true)

theorem identity18227 : scanCanonicalize (H12AffineFastState.compose env18227 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound18227 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,8203,5173,10361,1025,8541,4160,113,17,3,8192,65,10280,5393,4177,2128,1364,32,257,112,5456,513]

theorem envBound18228 : H12AffineFastState.Bounded env18228 := by
  intro p hp
  have h : env18228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18227_18228 : H12AffineEnvironment.transform 16 5173 env18227 = env18228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env18227 == env18228) = true)

theorem identity18228 : scanCanonicalize (H12AffineFastState.compose env18228 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18228 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env18229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,80,263,5173,2421,1025,81,4160,113,17,3,268,65,2340,5393,4177,2128,1364,32,257,112,5456,513]

theorem envBound18229 : H12AffineFastState.Bounded env18229 := by
  intro p hp
  have h : env18229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18228_18229 : H12AffineEnvironment.transform 12 268 env18228 = env18229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18228 == env18229) = true)

theorem identity18229 : scanCanonicalize (H12AffineFastState.compose env18229 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound18229 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,4096,268,5456,80,263,5173,1,1025,81,4160,113,17,3,268,65,80,5393,4177,292,1364,32,257,112,5456,513]

theorem envBound18230 : H12AffineFastState.Bounded env18230 := by
  intro p hp
  have h : env18230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18229_18230 : H12AffineEnvironment.transform 10 372 env18229 = env18230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env18229 == env18230) = true)

theorem identity18230 : scanCanonicalize (H12AffineFastState.compose env18230 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18230 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18231 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,4096,120,5156,80,115,5173,1,1025,81,4160,113,17,3,120,65,80,5221,4177,80,1056,32,117,112,5156,513]

theorem envBound18231 : H12AffineFastState.Bounded env18231 := by
  intro p hp
  have h : env18231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18230_18231 : H12AffineEnvironment.transform 7 116 env18230 = env18231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18230 == env18231) = true)

theorem identity18231 : scanCanonicalize (H12AffineFastState.compose env18231 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound18231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18232 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,80,120,1140,80,115,1125,1,1025,81,16,113,17,3,120,65,80,1077,1,80,1056,32,117,112,1140,513]

theorem envBound18232 : H12AffineFastState.Bounded env18232 := by
  intro p hp
  have h : env18232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18231_18232 : H12AffineEnvironment.transform 11 80 env18231 = env18232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env18231 == env18232) = true)

theorem identity18232 : scanCanonicalize (H12AffineFastState.compose env18232 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound18232 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18233 : List Nat := [2,4,8,16,32,64,8,116,512,84,0,80,120,32,80,115,49,1,85,81,16,113,17,3,120,65,80,97,1,80,116,32,117,112,32,513]

theorem envBound18233 : H12AffineFastState.Bounded env18233 := by
  intro p hp
  have h : env18233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18232_18233 : H12AffineEnvironment.transform 9 84 env18232 = env18233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env18232 == env18233) = true)

theorem identity18233 : scanCanonicalize (H12AffineFastState.compose env18233 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18233 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18234 : List Nat := [2,4,8,16,32,16,8,36,512,4,0,0,40,32,0,35,49,1,5,1,16,33,17,3,40,17,0,49,1,0,36,32,37,32,32,513]

theorem envBound18234 : H12AffineFastState.Bounded env18234 := by
  intro p hp
  have h : env18234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18233_18234 : H12AffineEnvironment.transform 5 16 env18233 = env18234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18233 == env18234) = true)

theorem identity18234 : scanCanonicalize (H12AffineFastState.compose env18234 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound18234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18235 : List Nat := [2,4,8,16,32,16,8,36,36,4,0,0,40,32,0,35,49,1,5,1,16,33,17,3,40,17,0,49,1,0,36,32,37,32,32,37]

theorem envBound18235 : H12AffineFastState.Bounded env18235 := by
  intro p hp
  have h : env18235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18234_18235 : H12AffineEnvironment.transform 8 36 env18234 = env18235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env18234 == env18235) = true)

theorem identity18235 : scanCanonicalize (H12AffineFastState.compose env18235 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18235 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18236 : List Nat := [2,4,8,16,10,16,8,14,14,4,0,0,2,10,0,9,27,1,5,1,16,11,17,3,2,17,0,27,1,0,14,10,15,10,10,15]

theorem envBound18236 : H12AffineFastState.Bounded env18236 := by
  intro p hp
  have h : env18236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18235_18236 : H12AffineEnvironment.transform 4 10 env18235 = env18236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18235 == env18236) = true)

theorem identity18236 : scanCanonicalize (H12AffineFastState.compose env18236 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18236 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18237 : List Nat := [2,4,2,16,0,16,2,4,4,4,0,0,2,0,0,3,17,1,5,1,16,1,17,3,2,17,0,17,1,0,4,0,5,0,0,5]

theorem envBound18237 : H12AffineFastState.Bounded env18237 := by
  intro p hp
  have h : env18237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18236_18237 : H12AffineEnvironment.transform 2 2 env18236 = env18237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18236 == env18237) = true)

theorem identity18237 : scanCanonicalize (H12AffineFastState.compose env18237 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18237 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env18238 : List Nat := [2,4,2,1,0,1,2,4,4,4,0,0,2,0,0,3,0,1,5,1,1,1,0,3,2,0,0,0,1,0,4,0,5,0,0,5]

theorem envBound18238 : H12AffineFastState.Bounded env18238 := by
  intro p hp
  have h : env18238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18237_18238 : H12AffineEnvironment.transform 3 1 env18237 = env18238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18237 == env18238) = true)

theorem identity18238 : scanCanonicalize (H12AffineFastState.compose env18238 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound18238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18239 : List Nat := [1,4,1,1,0,1,1,4,4,4,0,0,1,0,0,0,0,1,5,1,1,1,0,0,1,0,0,0,1,0,4,0,5,0,0,5]

theorem envBound18239 : H12AffineFastState.Bounded env18239 := by
  intro p hp
  have h : env18239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18238_18239 : H12AffineEnvironment.transform 0 1 env18238 = env18239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env18238 == env18239) = true)

def env18240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8541,8203,131072,10360,1025,8540,4160,248,17,138,8328,65,146460,5393,4176,138340,1500,169,257,113,5593,513]

theorem envBound18240 : H12AffineFastState.Bounded env18240 := by
  intro p hp
  have h : env18240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18225_18240 : H12AffineEnvironment.transform 13 5457 env18225 = env18240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env18225 == env18240) = true)

theorem identity18240 : scanCanonicalize (H12AffineFastState.compose env18240 (packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound18240 : packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS < 2^1333 := by decide +kernel

def env18241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8541,8203,13388,10360,1025,8540,4160,248,17,138,8328,65,2128,5393,4176,10280,1500,169,257,113,5593,513]

theorem envBound18241 : H12AffineFastState.Bounded env18241 := by
  intro p hp
  have h : env18241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18240_18241 : H12AffineEnvironment.transform 16 13388 env18240 = env18241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env18240 == env18241) = true)

theorem identity18241 : scanCanonicalize (H12AffineFastState.compose env18241 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18241 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env18242 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,5236,8312,8203,13388,10360,1025,8313,4160,248,17,138,8328,65,2128,5172,4176,10280,1273,169,36,113,5372,513]

theorem envBound18242 : H12AffineFastState.Bounded env18242 := by
  intro p hp
  have h : env18242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18241_18242 : H12AffineEnvironment.transform 7 37 env18241 = env18242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18241 == env18242) = true)

theorem identity18242 : scanCanonicalize (H12AffineFastState.compose env18242 (packedSelected [0,1,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound18242 : packedSelected [0,1,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env18243 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,1220,5236,1212,1231,4232,3260,1025,1213,4160,248,17,138,1100,65,2128,5172,4176,3308,1273,169,36,113,5372,513]

theorem envBound18243 : H12AffineFastState.Bounded env18243 := by
  intro p hp
  have h : env18243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18242_18243 : H12AffineEnvironment.transform 12 1220 env18242 = env18243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env18242 == env18243) = true)

theorem identity18243 : scanCanonicalize (H12AffineFastState.compose env18243 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound18243 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18244 : List Nat := [2,4,8,16,32,64,128,37,512,100,2048,4096,160,4112,216,171,4232,2264,101,217,4160,248,17,138,40,65,2128,4176,4176,2184,157,169,36,113,4248,513]

theorem envBound18244 : H12AffineFastState.Bounded env18244 := by
  intro p hp
  have h : env18244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18243_18244 : H12AffineEnvironment.transform 9 100 env18243 = env18244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env18243 == env18244) = true)

theorem identity18244 : scanCanonicalize (H12AffineFastState.compose env18244 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound18244 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18245 : List Nat := [2,4,8,16,32,64,88,37,512,100,2048,4096,120,4112,0,115,4176,2048,101,1,4160,32,17,82,40,65,2128,4176,4176,2128,69,113,36,113,4160,513]

theorem envBound18245 : H12AffineFastState.Bounded env18245 := by
  intro p hp
  have h : env18245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18244_18245 : H12AffineEnvironment.transform 6 88 env18244 = env18245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18244 == env18245) = true)

theorem identity18245 : scanCanonicalize (H12AffineFastState.compose env18245 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18245 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env18246 : List Nat := [2,4,8,16,32,64,88,37,512,100,0,4096,120,4112,0,115,4176,0,101,1,4160,32,17,82,40,65,80,4176,4176,80,69,113,36,113,4160,513]

theorem envBound18246 : H12AffineFastState.Bounded env18246 := by
  intro p hp
  have h : env18246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18245_18246 : H12AffineEnvironment.transform 10 0 env18245 = env18246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18245 == env18246) = true)

theorem identity18246 : scanCanonicalize (H12AffineFastState.compose env18246 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound18246 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env18247 : List Nat := [2,4,8,16,32,64,88,37,512,100,0,16,120,0,0,115,64,0,101,1,80,32,17,82,40,65,80,64,64,80,69,113,36,113,80,513]

theorem envBound18247 : H12AffineFastState.Bounded env18247 := by
  intro p hp
  have h : env18247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18246_18247 : H12AffineEnvironment.transform 11 16 env18246 = env18247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env18246 == env18247) = true)

theorem identity18247 : scanCanonicalize (H12AffineFastState.compose env18247 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18247 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18248 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,40,0,0,35,16,0,53,1,0,32,17,2,40,17,0,16,16,0,21,33,36,33,0,513]

theorem envBound18248 : H12AffineFastState.Bounded env18248 := by
  intro p hp
  have h : env18248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18247_18248 : H12AffineEnvironment.transform 5 16 env18247 = env18248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18247 == env18248) = true)

theorem identity18248 : scanCanonicalize (H12AffineFastState.compose env18248 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18249 : List Nat := [2,4,8,16,0,16,8,5,512,20,0,16,8,0,0,3,16,0,21,1,0,0,17,2,8,17,0,16,16,0,21,1,4,1,0,513]

theorem envBound18249 : H12AffineFastState.Bounded env18249 := by
  intro p hp
  have h : env18249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18248_18249 : H12AffineEnvironment.transform 4 0 env18248 = env18249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18248 == env18249) = true)

theorem identity18249 : scanCanonicalize (H12AffineFastState.compose env18249 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18250 : List Nat := [2,4,8,16,0,16,8,5,1,20,0,16,8,0,0,3,16,0,21,1,0,0,17,2,8,17,0,16,16,0,21,1,4,1,0,0]

theorem envBound18250 : H12AffineFastState.Bounded env18250 := by
  intro p hp
  have h : env18250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18249_18250 : H12AffineEnvironment.transform 8 1 env18249 = env18250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18249 == env18250) = true)

def env18251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294200,98780,8328,65,398437,288824,17665,179513,293109,41461,257,21792,46212,352035]

theorem envBound18251 : H12AffineFastState.Bounded env18251 := by
  intro p hp
  have h : env18251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18221_18251 : H12AffineEnvironment.transform 21 272513 env18221 = env18251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18221 == env18251) = true)

def env18252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294200,98644,8192,65,398437,288824,17665,179513,292989,41341,257,21792,46092,352035]

theorem envBound18252 : H12AffineFastState.Bounded env18252 := by
  intro p hp
  have h : env18252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18251_18252 : H12AffineEnvironment.transform 6 8 env18251 = env18252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18251 == env18252) = true)

def env18253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,276585,272393,272440,98644,8192,65,398437,277816,4097,179513,273789,41341,257,32,46092,330275]

theorem envBound18253 : H12AffineFastState.Bounded env18253 := by
  intro p hp
  have h : env18253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18252_18253 : H12AffineEnvironment.transform 13 5376 env18252 = env18253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18252 == env18253) = true)

theorem identity18253 : scanCanonicalize (H12AffineFastState.compose env18253 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18253 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1025,32769,276585,272393,272440,41311,8192,65,398437,277816,4097,179513,273789,41341,257,32,46092,272936]

theorem envBound18254 : H12AffineFastState.Bounded env18254 := by
  intro p hp
  have h : env18254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18253_18254 : H12AffineEnvironment.transform 15 8203 env18253 = env18254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18253 == env18254) = true)

theorem identity18254 : scanCanonicalize (H12AffineFastState.compose env18254 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18254 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env18255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,262,131072,262144,1025,32769,268644,264452,264501,32850,269,65,398437,269365,4097,171060,265328,32880,257,32,38145,264997]

theorem envBound18255 : H12AffineFastState.Bounded env18255 := by
  intro p hp
  have h : env18255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18254_18255 : H12AffineEnvironment.transform 12 269 env18254 = env18255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18254 == env18255) = true)

theorem identity18255 : scanCanonicalize (H12AffineFastState.compose env18255 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 38209) := by decide +kernel

theorem selectedBound18255 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env18256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,262,38209,262144,1025,32769,268644,264452,264501,32850,269,65,295204,269365,4097,2421,265328,32880,257,32,38145,264997]

theorem envBound18256 : H12AffineFastState.Bounded env18256 := by
  intro p hp
  have h : env18256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18255_18256 : H12AffineEnvironment.transform 16 38209 env18255 = env18256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38209 env18255 == env18256) = true)

theorem identity18256 : scanCanonicalize (H12AffineFastState.compose env18256 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound18256 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,80,262,5393,262144,1025,81,268644,264452,264501,2,269,65,262516,269365,4097,2421,265328,32,257,32,5457,264997]

theorem envBound18257 : H12AffineFastState.Bounded env18257 := by
  intro p hp
  have h : env18257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18256_18257 : H12AffineEnvironment.transform 14 80 env18256 = env18257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env18256 == env18257) = true)

theorem identity18257 : scanCanonicalize (H12AffineFastState.compose env18257 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound18257 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env18258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,80,262,5393,4112,1025,81,2420,6420,6437,2,269,65,4452,3109,4097,2421,7264,32,257,32,5457,6965]

theorem envBound18258 : H12AffineFastState.Bounded env18258 := by
  intro p hp
  have h : env18258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18257_18258 : H12AffineEnvironment.transform 17 4112 env18257 = env18258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env18257 == env18258) = true)

theorem identity18258 : scanCanonicalize (H12AffineFastState.compose env18258 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2673) := by decide +kernel

theorem selectedBound18258 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env18259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2673,269,3953,80,262,3936,2657,1025,81,2420,869,852,2,269,65,2837,3109,2672,2421,1553,32,257,32,3872,324]

theorem envBound18259 : H12AffineFastState.Bounded env18259 := by
  intro p hp
  have h : env18259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18258_18259 : H12AffineEnvironment.transform 11 2673 env18258 = env18259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2673 env18258 == env18259) = true)

theorem identity18259 : scanCanonicalize (H12AffineFastState.compose env18259 (packedSelected [0,2,3,5,6,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound18259 : packedSelected [0,2,3,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env18260 : List Nat := [2,4,8,16,32,64,8,256,65,1024,2048,2096,269,3376,80,262,3361,2080,1025,81,2420,292,277,2,269,65,2388,3109,2097,2421,1104,32,257,32,3425,324]

theorem envBound18260 : H12AffineFastState.Bounded env18260 := by
  intro p hp
  have h : env18260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18259_18260 : H12AffineEnvironment.transform 8 65 env18259 = env18260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env18259 == env18260) = true)

theorem identity18260 : scanCanonicalize (H12AffineFastState.compose env18260 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound18260 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env18261 : List Nat := [2,4,8,16,32,64,8,85,65,1024,2048,2096,88,3173,80,83,3188,2080,1025,81,2081,113,64,2,88,65,2049,3109,2097,2080,1104,32,84,32,3124,17]

theorem envBound18261 : H12AffineFastState.Bounded env18261 := by
  intro p hp
  have h : env18261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18260_18261 : H12AffineEnvironment.transform 7 85 env18260 = env18261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env18260 == env18261) = true)

theorem identity18261 : scanCanonicalize (H12AffineFastState.compose env18261 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1109) := by decide +kernel

theorem selectedBound18261 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18262 : List Nat := [2,4,8,16,32,64,8,85,65,1024,1109,1125,88,48,80,83,33,1141,1025,81,1140,113,64,2,88,65,1108,112,1124,1141,1104,32,84,32,97,17]

theorem envBound18262 : H12AffineFastState.Bounded env18262 := by
  intro p hp
  have h : env18262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18261_18262 : H12AffineEnvironment.transform 10 1109 env18261 = env18262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1109 env18261 == env18262) = true)

theorem identity18262 : scanCanonicalize (H12AffineFastState.compose env18262 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound18262 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env18263 : List Nat := [2,4,8,16,32,64,8,85,65,117,32,16,88,48,80,83,33,0,116,81,1,113,64,2,88,65,33,112,17,0,37,32,84,32,97,17]

theorem envBound18263 : H12AffineFastState.Bounded env18263 := by
  intro p hp
  have h : env18263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18262_18263 : H12AffineEnvironment.transform 9 117 env18262 = env18263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env18262 == env18263) = true)

theorem identity18263 : scanCanonicalize (H12AffineFastState.compose env18263 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound18263 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18264 : List Nat := [2,4,8,16,32,1,8,20,0,52,32,16,25,48,17,18,33,0,53,16,1,48,1,2,25,0,33,49,17,0,37,32,21,32,32,17]

theorem envBound18264 : H12AffineFastState.Bounded env18264 := by
  intro p hp
  have h : env18264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18263_18264 : H12AffineEnvironment.transform 5 1 env18263 = env18264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env18263 == env18264) = true)

theorem identity18264 : scanCanonicalize (H12AffineFastState.compose env18264 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18265 : List Nat := [2,4,8,1,32,1,8,5,0,37,32,1,8,33,0,3,33,0,36,1,1,33,1,2,8,0,33,32,0,0,37,32,4,32,32,0]

theorem envBound18265 : H12AffineFastState.Bounded env18265 := by
  intro p hp
  have h : env18265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18264_18265 : H12AffineEnvironment.transform 3 1 env18264 = env18265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18264 == env18265) = true)

theorem identity18265 : scanCanonicalize (H12AffineFastState.compose env18265 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18266 : List Nat := [2,4,8,1,1,1,8,5,0,4,1,1,8,0,0,3,0,0,5,1,1,0,1,2,8,0,0,1,0,0,4,1,4,1,1,0]

theorem envBound18266 : H12AffineFastState.Bounded env18266 := by
  intro p hp
  have h : env18266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18265_18266 : H12AffineEnvironment.transform 4 1 env18265 = env18266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18265 == env18266) = true)

theorem identity18266 : scanCanonicalize (H12AffineFastState.compose env18266 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound18266 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18267 : List Nat := [2,0,8,1,1,1,8,1,0,0,1,1,8,0,0,3,0,0,1,1,1,0,1,2,8,0,0,1,0,0,0,1,0,1,1,0]

theorem envBound18267 : H12AffineFastState.Bounded env18267 := by
  intro p hp
  have h : env18267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18266_18267 : H12AffineEnvironment.transform 1 0 env18266 = env18267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env18266 == env18267) = true)

def env18268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1025,32769,276584,272393,272441,98644,8192,65,398437,277817,4096,179513,273788,41341,257,33,46092,330274]

theorem envBound18268 : H12AffineFastState.Bounded env18268 := by
  intro p hp
  have h : env18268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18252_18268 : H12AffineEnvironment.transform 13 5377 env18252 = env18268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18252 == env18268) = true)

theorem identity18268 : scanCanonicalize (H12AffineFastState.compose env18268 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound18268 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1025,32769,77899,73770,73754,98644,8192,65,203846,79130,4096,179513,75103,41341,257,33,46092,513]

theorem envBound18269 : H12AffineFastState.Bounded env18269 := by
  intro p hp
  have h : env18269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18268_18269 : H12AffineEnvironment.transform 17 67619 env18268 = env18269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env18268 == env18269) = true)

theorem identity18269 : scanCanonicalize (H12AffineFastState.compose env18269 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18269 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env18270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,67619,1025,8541,77899,73770,73754,73736,8192,65,203846,79130,4096,138341,75103,33,257,33,5456,513]

theorem envBound18270 : H12AffineFastState.Bounded env18270 := by
  intro p hp
  have h : env18270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18269_18270 : H12AffineEnvironment.transform 14 8540 env18269 = env18270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18269 == env18270) = true)

theorem identity18270 : scanCanonicalize (H12AffineFastState.compose env18270 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18270 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,131072,67619,1025,1,69911,65910,65862,65876,348,65,203846,70726,4096,138341,66563,33,257,33,5456,513]

theorem envBound18271 : H12AffineFastState.Bounded env18271 := by
  intro p hp
  have h : env18271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18270_18271 : H12AffineEnvironment.transform 12 348 env18270 = env18271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18270 == env18271) = true)

theorem identity18271 : scanCanonicalize (H12AffineFastState.compose env18271 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound18271 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env18272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,5440,67619,1025,1,69911,65910,65862,65876,348,65,67846,70726,4096,2341,66563,33,257,33,5456,513]

theorem envBound18272 : H12AffineFastState.Bounded env18272 := by
  intro p hp
  have h : env18272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18271_18272 : H12AffineEnvironment.transform 16 5440 env18271 = env18272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env18271 == env18272) = true)

theorem identity18272 : scanCanonicalize (H12AffineFastState.compose env18272 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound18272 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5440,2421,1025,1,4161,32,16,2,348,65,2128,5392,4096,2341,1365,33,257,33,5456,513]

theorem envBound18273 : H12AffineFastState.Bounded env18273 := by
  intro p hp
  have h : env18273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18272_18273 : H12AffineEnvironment.transform 15 342 env18272 = env18273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env18272 == env18273) = true)

theorem identity18273 : scanCanonicalize (H12AffineFastState.compose env18273 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18273 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18274 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1025,1,4113,32,16,2,268,17,2048,5392,4096,2341,1285,33,257,33,5376,513]

theorem envBound18274 : H12AffineFastState.Bounded env18274 := by
  intro p hp
  have h : env18274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18273_18274 : H12AffineEnvironment.transform 5 16 env18273 = env18274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18273 == env18274) = true)

theorem identity18274 : scanCanonicalize (H12AffineFastState.compose env18274 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18274 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18275 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,17,268,1296,0,262,1281,2341,1025,1,0,32,16,2,268,17,2048,1281,17,2341,1285,33,257,33,1297,513]

theorem envBound18275 : H12AffineFastState.Bounded env18275 := by
  intro p hp
  have h : env18275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18274_18275 : H12AffineEnvironment.transform 11 17 env18274 = env18275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18274 == env18275) = true)

theorem identity18275 : scanCanonicalize (H12AffineFastState.compose env18275 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18275 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18276 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,17,268,292,0,262,309,2341,53,1,0,32,16,2,268,17,2048,309,17,2341,305,33,257,33,293,513]

theorem envBound18276 : H12AffineFastState.Bounded env18276 := by
  intro p hp
  have h : env18276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18275_18276 : H12AffineEnvironment.transform 9 52 env18275 = env18276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18275 == env18276) = true)

theorem identity18276 : scanCanonicalize (H12AffineFastState.compose env18276 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18276 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18277 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,17,41,1,0,35,16,2048,53,1,0,32,16,2,41,17,2048,16,17,2048,20,33,36,33,0,513]

theorem envBound18277 : H12AffineFastState.Bounded env18277 := by
  intro p hp
  have h : env18277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18276_18277 : H12AffineEnvironment.transform 7 37 env18276 = env18277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18276 == env18277) = true)

theorem identity18277 : scanCanonicalize (H12AffineFastState.compose env18277 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound18277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18278 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,17,41,1,0,35,16,49,53,1,0,32,16,2,41,17,49,16,17,49,20,33,36,33,0,513]

theorem envBound18278 : H12AffineFastState.Bounded env18278 := by
  intro p hp
  have h : env18278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18277_18278 : H12AffineEnvironment.transform 10 49 env18277 = env18278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env18277 == env18278) = true)

theorem identity18278 : scanCanonicalize (H12AffineFastState.compose env18278 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18279 : List Nat := [2,4,8,16,16,16,8,21,512,4,1,17,25,1,0,19,16,1,5,1,0,16,16,2,25,17,1,16,17,1,20,17,20,17,0,513]

theorem envBound18279 : H12AffineFastState.Bounded env18279 := by
  intro p hp
  have h : env18279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18278_18279 : H12AffineEnvironment.transform 4 16 env18278 = env18279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18278 == env18279) = true)

def env18280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272392,294200,98645,8193,65,398437,288824,17665,179513,292988,41340,257,21792,46093,352035]

theorem envBound18280 : H12AffineFastState.Bounded env18280 := by
  intro p hp
  have h : env18280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18251_18280 : H12AffineEnvironment.transform 6 9 env18251 = env18280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18251 == env18280) = true)

theorem identity18280 : scanCanonicalize (H12AffineFastState.compose env18280 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 204083) := by decide +kernel

theorem selectedBound18280 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env18281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,204083,1025,32769,225370,210235,221195,98645,8193,65,67926,226571,17665,179513,222543,41340,257,21792,46093,147984]

theorem envBound18281 : H12AffineFastState.Bounded env18281 := by
  intro p hp
  have h : env18281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18280_18281 : H12AffineEnvironment.transform 17 204083 env18280 = env18281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204083 env18280 == env18281) = true)

theorem identity18281 : scanCanonicalize (H12AffineFastState.compose env18281 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound18281 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103494,35189,1025,32769,58396,41341,62541,98645,8193,65,67926,57677,17665,76159,61705,41340,257,21792,46093,120406]

theorem envBound18282 : H12AffineFastState.Bounded env18282 := by
  intro p hp
  have h : env18282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18281_18282 : H12AffineEnvironment.transform 16 103494 env18281 = env18282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env18281 == env18282) = true)

theorem identity18282 : scanCanonicalize (H12AffineFastState.compose env18282 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18282 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,32040,1025,29788,4161,21792,16,95496,8193,65,67926,5392,17665,76159,1364,21793,257,21792,16464,74251]

theorem envBound18283 : H12AffineFastState.Bounded env18283 := by
  intro p hp
  have h : env18283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18282_18283 : H12AffineEnvironment.transform 14 29789 env18282 = env18283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18282 == env18283) = true)

theorem identity18283 : scanCanonicalize (H12AffineFastState.compose env18283 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16401,32040,1025,29788,4161,21792,16,21762,8193,65,10588,5392,17665,2421,1364,21793,257,21792,16464,513]

theorem envBound18284 : H12AffineFastState.Bounded env18284 := by
  intro p hp
  have h : env18284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18283_18284 : H12AffineEnvironment.transform 15 8202 env18283 = env18284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18283 == env18284) = true)

theorem identity18284 : scanCanonicalize (H12AffineFastState.compose env18284 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound18284 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12573,1344,8202,12556,3125,1025,1345,4161,9277,16,9247,8193,65,10588,5392,13340,2421,1364,9276,257,9277,12621,513]

theorem envBound18285 : H12AffineFastState.Bounded env18285 := by
  intro p hp
  have h : env18285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18284_18285 : H12AffineEnvironment.transform 13 12573 env18284 = env18285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env18284 == env18285) = true)

theorem identity18285 : scanCanonicalize (H12AffineFastState.compose env18285 (packedSelected [0,2,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound18285 : packedSelected [0,2,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env18286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2316,6161,1344,2310,6144,3125,1025,1345,4161,3377,16,3347,2317,65,80,5392,7440,2421,1364,3376,257,3377,6209,513]

theorem envBound18286 : H12AffineFastState.Bounded env18286 := by
  intro p hp
  have h : env18286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18285_18286 : H12AffineEnvironment.transform 12 2316 env18285 = env18286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env18285 == env18286) = true)

theorem identity18286 : scanCanonicalize (H12AffineFastState.compose env18286 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound18286 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,2316,3345,1344,2310,3328,3125,1025,1345,1345,3377,16,3347,2317,65,80,16,2064,2421,1364,3376,257,3377,3393,513]

theorem envBound18287 : H12AffineFastState.Bounded env18287 := by
  intro p hp
  have h : env18287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18286_18287 : H12AffineEnvironment.transform 11 1280 env18286 = env18287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env18286 == env18287) = true)

theorem identity18287 : scanCanonicalize (H12AffineFastState.compose env18287 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound18287 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env18288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,1280,40,1077,1344,34,1060,1297,1025,1345,1345,1045,16,1079,41,65,80,16,308,81,1364,1044,257,1045,1125,513]

theorem envBound18288 : H12AffineFastState.Bounded env18288 := by
  intro p hp
  have h : env18288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18287_18288 : H12AffineEnvironment.transform 10 292 env18287 = env18288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env18287 == env18288) = true)

theorem identity18288 : scanCanonicalize (H12AffineFastState.compose env18288 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18288 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env18289 : List Nat := [2,4,8,16,32,64,9,256,512,272,292,16,40,293,80,34,308,1,273,81,81,261,16,295,41,65,80,16,308,81,68,260,257,261,373,513]

theorem envBound18289 : H12AffineFastState.Bounded env18289 := by
  intro p hp
  have h : env18289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18288_18289 : H12AffineEnvironment.transform 9 272 env18288 = env18289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18288 == env18289) = true)

theorem identity18289 : scanCanonicalize (H12AffineFastState.compose env18289 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18289 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18290 : List Nat := [2,4,8,16,32,64,9,117,512,101,81,16,40,80,80,34,65,1,100,81,81,112,16,82,41,65,80,16,65,81,68,113,116,112,0,513]

theorem envBound18290 : H12AffineFastState.Bounded env18290 := by
  intro p hp
  have h : env18290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18289_18290 : H12AffineEnvironment.transform 7 117 env18289 = env18290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18289 == env18290) = true)

theorem identity18290 : scanCanonicalize (H12AffineFastState.compose env18290 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18290 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18291 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,16,40,0,0,34,17,1,52,1,1,32,16,2,41,17,0,16,17,1,20,33,36,32,0,513]

theorem envBound18291 : H12AffineFastState.Bounded env18291 := by
  intro p hp
  have h : env18291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18290_18291 : H12AffineEnvironment.transform 5 16 env18290 = env18291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18290 == env18291) = true)

theorem identity18291 : scanCanonicalize (H12AffineFastState.compose env18291 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18292 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,16,8,0,0,2,17,1,20,1,1,0,16,2,9,17,0,16,17,1,20,1,4,0,0,513]

theorem envBound18292 : H12AffineFastState.Bounded env18292 := by
  intro p hp
  have h : env18292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18291_18292 : H12AffineEnvironment.transform 4 0 env18291 = env18292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18291 == env18292) = true)

theorem identity18292 : scanCanonicalize (H12AffineFastState.compose env18292 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound18292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18293 : List Nat := [2,4,8,16,0,16,9,5,17,21,1,16,8,0,0,2,17,1,20,1,1,0,16,2,9,17,0,16,17,1,20,1,4,0,0,16]

theorem envBound18293 : H12AffineFastState.Bounded env18293 := by
  intro p hp
  have h : env18293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18292_18293 : H12AffineEnvironment.transform 8 17 env18292 = env18293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env18292 == env18293) = true)

def env18294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294201,2485429,8328,65,6705548,288824,2369641,179512,2102685,4491636,257,21793,46213,2175563]

theorem envBound18294 : H12AffineFastState.Bounded env18294 := by
  intro p hp
  have h : env18294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18182_18294 : H12AffineEnvironment.transform 22 294201 env18182 = env18294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294201 env18182 == env18294) = true)

def env18295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294201,98781,8328,65,4340964,288824,17665,179512,293109,4491636,257,21793,46213,352035]

theorem envBound18295 : H12AffineFastState.Bounded env18295 := by
  intro p hp
  have h : env18295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18294_18295 : H12AffineEnvironment.transform 20 290152 env18294 = env18295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env18294 == env18295) = true)

def env18296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294201,98781,8328,65,398436,288824,17665,179512,293109,41460,257,21793,46213,352035]

theorem envBound18296 : H12AffineFastState.Bounded env18296 := by
  intro p hp
  have h : env18296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18295_18296 : H12AffineEnvironment.transform 21 272512 env18295 = env18296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18295 == env18296) = true)

theorem identity18296 : scanCanonicalize (H12AffineFastState.compose env18296 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound18296 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,290152,272512,294201,21763,8328,65,398436,288824,17665,179512,293109,41460,257,21793,46213,297981]

theorem envBound18297 : H12AffineFastState.Bounded env18297 := by
  intro p hp
  have h : env18297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18296_18297 : H12AffineEnvironment.transform 15 54494 env18296 = env18297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env18296 == env18297) = true)

def env18298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146864,1025,32769,151768,136496,147593,21763,8328,65,10708,152968,17665,179512,148805,41460,257,21793,46213,177741]

theorem envBound18298 : H12AffineFastState.Bounded env18298 := by
  intro p hp
  have h : env18298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18297_18298 : H12AffineEnvironment.transform 17 146864 env18297 = env18298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env18297 == env18298) = true)

theorem identity18298 : scanCanonicalize (H12AffineFastState.compose env18298 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound18298 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46156,35324,1025,32769,58516,41340,62661,21763,8328,65,10708,57796,17665,2420,61705,41460,257,21793,46213,513]

theorem envBound18299 : H12AffineFastState.Bounded env18299 := by
  intro p hp
  have h : env18299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18298_18299 : H12AffineEnvironment.transform 16 46156 env18298 = env18299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env18298 == env18299) = true)

theorem identity18299 : scanCanonicalize (H12AffineFastState.compose env18299 (packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18299 : packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env18300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33111,46156,35324,1025,32769,45341,41340,41292,138,8328,65,10708,46157,4232,2420,42112,41460,257,168,46213,513]

theorem envBound18300 : H12AffineFastState.Bounded env18300 := by
  intro p hp
  have h : env18300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18299_18300 : H12AffineEnvironment.transform 13 5513 env18299 = env18300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18299 == env18300) = true)

theorem identity18300 : scanCanonicalize (H12AffineFastState.compose env18300 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound18300 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8323,5528,10280,1025,8661,4297,168,152,138,8328,65,10708,5529,4232,2420,1364,32,257,168,5457,513]

theorem envBound18301 : H12AffineFastState.Bounded env18301 := by
  intro p hp
  have h : env18301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18300_18301 : H12AffineEnvironment.transform 14 8660 env18300 = env18301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env18300 == env18301) = true)

theorem identity18301 : scanCanonicalize (H12AffineFastState.compose env18301 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18301 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10280,1025,8540,4160,33,17,3,8193,65,10589,5392,4097,2420,1364,32,257,33,5457,513]

theorem envBound18302 : H12AffineFastState.Bounded env18302 := by
  intro p hp
  have h : env18302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18301_18302 : H12AffineEnvironment.transform 6 9 env18301 = env18302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18301 == env18302) = true)

theorem identity18302 : scanCanonicalize (H12AffineFastState.compose env18302 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound18302 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,5376,340,3,5393,2081,1025,341,4160,33,17,3,8,65,2388,5392,4097,2420,1364,32,257,33,5457,513]

theorem envBound18303 : H12AffineFastState.Bounded env18303 := by
  intro p hp
  have h : env18303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18302_18303 : H12AffineEnvironment.transform 12 9 env18302 = env18303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env18302 == env18303) = true)

theorem identity18303 : scanCanonicalize (H12AffineFastState.compose env18303 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18303 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18304 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,9,4113,340,3,4096,2081,272,341,4160,33,17,3,8,65,2388,4097,4097,2420,69,32,257,33,4160,513]

theorem envBound18304 : H12AffineFastState.Bounded env18304 := by
  intro p hp
  have h : env18304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18303_18304 : H12AffineEnvironment.transform 9 273 env18303 = env18304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18303 == env18304) = true)

theorem identity18304 : scanCanonicalize (H12AffineFastState.compose env18304 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound18304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18305 : List Nat := [2,4,8,16,32,64,9,53,512,36,2048,4096,9,4113,97,3,4096,2081,37,96,4160,33,17,3,8,65,2145,4097,4097,2113,69,32,52,33,4160,513]

theorem envBound18305 : H12AffineFastState.Bounded env18305 := by
  intro p hp
  have h : env18305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18304_18305 : H12AffineEnvironment.transform 7 53 env18304 = env18305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env18304 == env18305) = true)

theorem identity18305 : scanCanonicalize (H12AffineFastState.compose env18305 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound18305 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env18306 : List Nat := [2,4,8,16,32,64,9,53,512,36,2048,2112,9,2129,97,3,2112,2081,37,96,2048,33,17,3,8,65,2145,2113,2113,2113,69,32,52,33,2048,513]

theorem envBound18306 : H12AffineFastState.Bounded env18306 := by
  intro p hp
  have h : env18306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18305_18306 : H12AffineEnvironment.transform 11 2112 env18305 = env18306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env18305 == env18306) = true)

theorem identity18306 : scanCanonicalize (H12AffineFastState.compose env18306 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound18306 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18307 : List Nat := [2,4,8,16,32,64,9,53,512,36,577,513,9,528,97,3,513,608,37,96,577,33,17,3,8,65,544,512,512,512,69,32,52,33,577,513]

theorem envBound18307 : H12AffineFastState.Bounded env18307 := by
  intro p hp
  have h : env18307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18306_18307 : H12AffineEnvironment.transform 10 577 env18306 = env18307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env18306 == env18307) = true)

theorem identity18307 : scanCanonicalize (H12AffineFastState.compose env18307 (packedSelected [0,1,4,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound18307 : packedSelected [0,1,4,12] rootPS < 2^1333 := by decide +kernel

def env18308 : List Nat := [2,4,8,16,32,48,9,53,512,36,561,513,9,528,17,3,513,528,37,16,561,33,17,3,8,49,544,512,512,512,53,32,52,33,561,513]

theorem envBound18308 : H12AffineFastState.Bounded env18308 := by
  intro p hp
  have h : env18308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18307_18308 : H12AffineEnvironment.transform 5 48 env18307 = env18308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env18307 == env18308) = true)

theorem identity18308 : scanCanonicalize (H12AffineFastState.compose env18308 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18308 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env18309 : List Nat := [2,4,8,16,0,16,9,21,512,4,529,513,9,528,17,3,513,528,5,16,529,1,17,3,8,17,512,512,512,512,21,0,20,1,529,513]

theorem envBound18309 : H12AffineFastState.Bounded env18309 := by
  intro p hp
  have h : env18309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18308_18309 : H12AffineEnvironment.transform 4 0 env18308 = env18309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18308 == env18309) = true)

theorem identity18309 : scanCanonicalize (H12AffineFastState.compose env18309 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18310 : List Nat := [2,4,8,16,0,16,9,21,1,4,16,0,9,17,17,3,0,17,5,16,16,1,17,3,8,17,1,1,1,1,21,0,20,1,16,0]

theorem envBound18310 : H12AffineFastState.Bounded env18310 := by
  intro p hp
  have h : env18310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18309_18310 : H12AffineEnvironment.transform 8 1 env18309 = env18310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18309 == env18310) = true)

theorem identity18310 : scanCanonicalize (H12AffineFastState.compose env18310 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18311 : List Nat := [2,4,8,0,0,0,9,5,1,4,0,0,9,1,1,3,0,1,5,0,0,1,1,3,8,1,1,1,1,1,5,0,4,1,0,0]

theorem envBound18311 : H12AffineFastState.Bounded env18311 := by
  intro p hp
  have h : env18311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18310_18311 : H12AffineEnvironment.transform 3 0 env18310 = env18311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18310 == env18311) = true)

def env18312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146865,1025,32769,151769,136497,147592,21763,8328,65,10709,152969,17665,179512,148804,41460,257,21793,46213,177740]

theorem envBound18312 : H12AffineFastState.Bounded env18312 := by
  intro p hp
  have h : env18312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18297_18312 : H12AffineEnvironment.transform 17 146865 env18297 = env18312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env18297 == env18312) = true)

theorem identity18312 : scanCanonicalize (H12AffineFastState.compose env18312 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound18312 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46277,35188,1025,32769,58396,41460,62541,21763,8328,65,10709,57676,17665,2557,61825,41460,257,21793,46213,649]

theorem envBound18313 : H12AffineFastState.Bounded env18313 := by
  intro p hp
  have h : env18313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18312_18313 : H12AffineEnvironment.transform 16 46277 env18312 = env18313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env18312 == env18313) = true)

theorem identity18313 : scanCanonicalize (H12AffineFastState.compose env18313 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18313 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46157,35188,1025,32769,58396,41340,62541,21763,8192,65,10589,57676,17665,2421,61705,41340,257,21793,46093,513]

theorem envBound18314 : H12AffineFastState.Bounded env18314 := by
  intro p hp
  have h : env18314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18313_18314 : H12AffineEnvironment.transform 6 8 env18313 = env18314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18313 == env18314) = true)

theorem identity18314 : scanCanonicalize (H12AffineFastState.compose env18314 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound18314 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env18315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,33031,46157,35188,1025,32769,45389,41340,41244,82,8192,65,10589,46109,4176,2421,42072,41340,257,112,46093,513]

theorem envBound18315 : H12AffineFastState.Bounded env18315 := by
  intro p hp
  have h : env18315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18314_18315 : H12AffineEnvironment.transform 13 5457 env18314 = env18315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env18314 == env18315) = true)

theorem identity18315 : scanCanonicalize (H12AffineFastState.compose env18315 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18315 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env18316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,8282,5392,10281,1025,8540,4112,33,65,82,8192,65,10589,5440,4176,2421,1285,33,257,112,5456,513]

theorem envBound18316 : H12AffineFastState.Bounded env18316 := by
  intro p hp
  have h : env18316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18315_18316 : H12AffineEnvironment.transform 14 8541 env18315 = env18316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18315 == env18316) = true)

theorem identity18316 : scanCanonicalize (H12AffineFastState.compose env18316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18317 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8202,5392,10281,1025,8460,4112,33,17,2,8192,17,10509,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound18317 : H12AffineFastState.Bounded env18317 := by
  intro p hp
  have h : env18317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18316_18317 : H12AffineEnvironment.transform 5 16 env18316 = env18317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18316 == env18317) = true)

theorem identity18317 : scanCanonicalize (H12AffineFastState.compose env18317 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound18317 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18318 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1288,5377,1029,1282,5392,3361,1025,1028,4112,33,17,2,1288,17,3077,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound18318 : H12AffineFastState.Bounded env18318 := by
  intro p hp
  have h : env18318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18317_18318 : H12AffineEnvironment.transform 12 1288 env18317 = env18318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env18317 == env18318) = true)

def env18319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294201,98781,8328,65,398437,288824,17665,179512,293109,41461,257,21793,46213,352035]

theorem envBound18319 : H12AffineFastState.Bounded env18319 := by
  intro p hp
  have h : env18319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18295_18319 : H12AffineEnvironment.transform 21 272513 env18295 = env18319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18295 == env18319) = true)

theorem identity18319 : scanCanonicalize (H12AffineFastState.compose env18319 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109046) := by decide +kernel

theorem selectedBound18319 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109046,1025,32769,115870,98679,120015,98781,8328,65,245139,115150,17665,179512,119043,41461,257,21793,46213,63189]

theorem envBound18320 : H12AffineFastState.Bounded env18320 := by
  intro p hp
  have h : env18320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18319_18320 : H12AffineEnvironment.transform 17 109046 env18319 = env18320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109046 env18319 == env18320) = true)

def env18321 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108966,1025,32769,115870,98599,119967,98701,8328,17,245139,115102,17665,179512,119043,41381,257,21793,46213,63109]

theorem envBound18321 : H12AffineFastState.Bounded env18321 := by
  intro p hp
  have h : env18321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18320_18321 : H12AffineEnvironment.transform 5 16 env18320 = env18321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18320 == env18321) = true)

theorem identity18321 : scanCanonicalize (H12AffineFastState.compose env18321 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound18321 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18322 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,46108,108966,1025,32769,115870,98599,119967,98701,8328,17,67983,115102,17665,2340,119043,41381,257,21793,46213,63109]

theorem envBound18322 : H12AffineFastState.Bounded env18322 := by
  intro p hp
  have h : env18322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18321_18322 : H12AffineEnvironment.transform 16 46108 env18321 = env18322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env18321 == env18322) = true)

theorem identity18322 : scanCanonicalize (H12AffineFastState.compose env18322 (packedSelected [1,4,5,7,8,9,14,16,17,19,20,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound18322 : packedSelected [1,4,5,7,8,9,14,16,17,19,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env18323 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,30083,46108,56357,1025,32769,45341,62628,41244,62478,8328,17,31756,46109,17665,2340,42112,41381,257,21793,46213,63109]

theorem envBound18323 : H12AffineFastState.Bounded env18323 := by
  intro p hp
  have h : env18323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18322_18323 : H12AffineEnvironment.transform 15 30083 env18322 = env18323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env18322 == env18323) = true)

theorem identity18323 : scanCanonicalize (H12AffineFastState.compose env18323 (packedSelected [0,1,4,7,8,9,10,12,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound18323 : packedSelected [0,1,4,7,8,9,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env18324 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,30083,16400,10281,1025,29709,17681,168,21776,2,8328,17,31756,16401,17665,2340,20620,21929,257,21793,16521,649]

theorem envBound18324 : H12AffineFastState.Bounded env18324 := by
  intro p hp
  have h : env18324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18323_18324 : H12AffineEnvironment.transform 14 29708 env18323 = env18324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env18323 == env18324) = true)

theorem identity18324 : scanCanonicalize (H12AffineFastState.compose env18324 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18324 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18325 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21760,21647,16400,2341,1025,21761,17681,168,21776,2,388,17,23808,16401,17665,2340,20620,21929,257,21793,16521,649]

theorem envBound18325 : H12AffineFastState.Bounded env18325 := by
  intro p hp
  have h : env18325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18324_18325 : H12AffineEnvironment.transform 12 268 env18324 = env18325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18324 == env18325) = true)

theorem identity18325 : scanCanonicalize (H12AffineFastState.compose env18325 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18325 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18326 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,1,398,5393,2341,1025,0,4112,168,17,2,388,17,2049,5392,4096,2340,1421,168,257,32,5512,649]

theorem envBound18326 : H12AffineFastState.Bounded env18326 := by
  intro p hp
  have h : env18326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18325_18326 : H12AffineEnvironment.transform 13 5377 env18325 = env18326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18325 == env18326) = true)

theorem identity18326 : scanCanonicalize (H12AffineFastState.compose env18326 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3718) := by decide +kernel

theorem selectedBound18326 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env18327 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3718,268,2951,1,398,2967,2341,1025,0,3734,168,17,2,388,17,2049,2966,3718,2340,1421,168,257,32,2830,649]

theorem envBound18327 : H12AffineFastState.Bounded env18327 := by
  intro p hp
  have h : env18327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18326_18327 : H12AffineEnvironment.transform 11 3718 env18326 = env18327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3718 env18326 == env18327) = true)

theorem identity18327 : scanCanonicalize (H12AffineFastState.compose env18327 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18327 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env18328 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3598,268,2831,1,262,2847,2341,1025,0,3614,32,17,2,268,17,2049,2846,3598,2340,1285,32,257,32,2830,513]

theorem envBound18328 : H12AffineFastState.Bounded env18328 := by
  intro p hp
  have h : env18328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18327_18328 : H12AffineEnvironment.transform 6 8 env18327 = env18328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18327 == env18328) = true)

theorem identity18328 : scanCanonicalize (H12AffineFastState.compose env18328 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound18328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18329 : List Nat := [2,4,8,16,32,16,8,256,512,1024,782,1280,268,1,1,262,17,555,1025,0,1296,32,17,2,268,17,783,16,1280,554,1285,32,257,32,0,513]

theorem envBound18329 : H12AffineFastState.Bounded env18329 := by
  intro p hp
  have h : env18329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18328_18329 : H12AffineEnvironment.transform 10 782 env18328 = env18329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env18328 == env18329) = true)

theorem identity18329 : scanCanonicalize (H12AffineFastState.compose env18329 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18329 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18330 : List Nat := [2,4,8,16,32,16,8,4,512,1024,522,1028,8,1,1,2,17,555,1025,0,1044,32,17,2,8,17,523,16,1028,554,1025,32,5,32,0,513]

theorem envBound18330 : H12AffineFastState.Bounded env18330 := by
  intro p hp
  have h : env18330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18329_18330 : H12AffineEnvironment.transform 7 4 env18329 = env18330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18329 == env18330) = true)

theorem identity18330 : scanCanonicalize (H12AffineFastState.compose env18330 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound18330 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18331 : List Nat := [2,4,8,16,32,16,8,4,43,1024,33,1028,8,1,1,2,17,0,1025,0,1044,32,17,2,8,17,32,16,1028,1,1025,32,5,32,0,42]

theorem envBound18331 : H12AffineFastState.Bounded env18331 := by
  intro p hp
  have h : env18331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18330_18331 : H12AffineEnvironment.transform 8 43 env18330 = env18331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env18330 == env18331) = true)

theorem identity18331 : scanCanonicalize (H12AffineFastState.compose env18331 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18331 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18332 : List Nat := [2,4,8,16,32,16,8,4,43,20,33,16,8,1,1,2,17,0,21,0,0,32,17,2,8,17,32,16,16,1,21,32,5,32,0,42]

theorem envBound18332 : H12AffineFastState.Bounded env18332 := by
  intro p hp
  have h : env18332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18331_18332 : H12AffineEnvironment.transform 9 20 env18331 = env18332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18331 == env18332) = true)

def env18333 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108967,1025,32769,115870,98598,119966,98700,8328,16,245139,115103,17665,179512,119043,41380,257,21793,46213,63108]

theorem envBound18333 : H12AffineFastState.Bounded env18333 := by
  intro p hp
  have h : env18333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18320_18333 : H12AffineEnvironment.transform 5 17 env18320 = env18333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18320 == env18333) = true)

theorem identity18333 : scanCanonicalize (H12AffineFastState.compose env18333 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound18333 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18334 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,103447,108967,1025,32769,115870,98598,119966,98700,8328,16,10628,115103,17665,76079,119043,41380,257,21793,46213,63108]

theorem envBound18334 : H12AffineFastState.Bounded env18334 := by
  intro p hp
  have h : env18334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18333_18334 : H12AffineEnvironment.transform 16 103447 env18333 = env18334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env18333 == env18334) = true)

theorem identity18334 : scanCanonicalize (H12AffineFastState.compose env18334 (packedSelected [5,8,10,15,24,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound18334 : packedSelected [5,8,10,15,24,26,28,38] rootPS < 2^1333 := by decide +kernel

def env18335 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21760,65536,82199,97447,1025,21761,70046,87078,65950,87180,8328,16,10628,70815,17665,76079,66563,29860,257,21793,24965,9092]

theorem envBound18335 : H12AffineFastState.Bounded env18335 := by
  intro p hp
  have h : env18335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18334_18335 : H12AffineEnvironment.transform 14 21760 env18334 = env18335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env18334 == env18335) = true)

theorem identity18335 : scanCanonicalize (H12AffineFastState.compose env18335 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound18335 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env18336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21760,65536,82199,89378,1025,21761,70046,87078,65950,87180,269,16,2049,70815,17665,67754,66563,21793,257,21793,16384,513]

theorem envBound18336 : H12AffineFastState.Bounded env18336 := by
  intro p hp
  have h : env18336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18335_18336 : H12AffineEnvironment.transform 12 389 env18335 = env18336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env18335 == env18336) = true)

theorem identity18336 : scanCanonicalize (H12AffineFastState.compose env18336 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound18336 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18337 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21760,21510,5393,2340,1025,21761,17816,32,21912,138,269,16,2049,16537,17665,23724,20485,21793,257,21793,16384,513]

theorem envBound18337 : H12AffineFastState.Bounded env18337 := by
  intro p hp
  have h : env18337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18336_18337 : H12AffineEnvironment.transform 15 21510 env18336 = env18337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env18336 == env18337) = true)

theorem identity18337 : scanCanonicalize (H12AffineFastState.compose env18337 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18337 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18338 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,21510,5393,2340,1025,21761,17680,32,21776,2,269,16,2049,16401,17665,23588,20485,21793,257,21793,16384,513]

theorem envBound18338 : H12AffineFastState.Bounded env18338 := by
  intro p hp
  have h : env18338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18337_18338 : H12AffineEnvironment.transform 6 8 env18337 = env18338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18337 == env18338) = true)

theorem identity18338 : scanCanonicalize (H12AffineFastState.compose env18338 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18339 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1025,0,4113,32,17,2,269,16,2049,5392,4096,2341,1284,32,257,32,5377,513]

theorem envBound18339 : H12AffineFastState.Bounded env18339 := by
  intro p hp
  have h : env18339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18338_18339 : H12AffineEnvironment.transform 13 5377 env18338 = env18339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18338 == env18339) = true)

theorem identity18339 : scanCanonicalize (H12AffineFastState.compose env18339 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18340 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,17,269,1296,1,263,1280,2340,1025,0,0,32,17,2,269,16,2049,1281,17,2341,1284,32,257,32,1296,513]

theorem envBound18340 : H12AffineFastState.Bounded env18340 := by
  intro p hp
  have h : env18340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18339_18340 : H12AffineEnvironment.transform 11 17 env18339 = env18340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18339 == env18340) = true)

theorem identity18340 : scanCanonicalize (H12AffineFastState.compose env18340 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound18340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18341 : List Nat := [2,4,8,16,32,17,8,256,512,1024,523,17,269,1296,1,263,1280,815,1025,0,0,32,17,2,269,16,522,1281,17,814,1284,32,257,32,1296,513]

theorem envBound18341 : H12AffineFastState.Bounded env18341 := by
  intro p hp
  have h : env18341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18340_18341 : H12AffineEnvironment.transform 10 523 env18340 = env18341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env18340 == env18341) = true)

theorem identity18341 : scanCanonicalize (H12AffineFastState.compose env18341 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound18341 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18342 : List Nat := [2,4,8,16,32,17,8,256,512,827,523,17,269,555,1,263,571,815,826,0,0,32,17,2,269,16,522,570,17,814,575,32,257,32,555,513]

theorem envBound18342 : H12AffineFastState.Bounded env18342 := by
  intro p hp
  have h : env18342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18341_18342 : H12AffineEnvironment.transform 9 827 env18341 = env18342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env18341 == env18342) = true)

theorem identity18342 : scanCanonicalize (H12AffineFastState.compose env18342 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18342 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18343 : List Nat := [2,4,8,16,0,17,8,256,512,795,523,17,269,523,1,263,539,783,794,0,0,0,17,2,269,16,522,538,17,782,543,0,257,0,523,513]

theorem envBound18343 : H12AffineFastState.Bounded env18343 := by
  intro p hp
  have h : env18343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18342_18343 : H12AffineEnvironment.transform 4 0 env18342 = env18343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18342 == env18343) = true)

theorem identity18343 : scanCanonicalize (H12AffineFastState.compose env18343 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound18343 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18344 : List Nat := [2,4,8,16,0,17,8,256,10,273,1,17,269,1,1,263,17,261,272,0,0,0,17,2,269,16,0,16,17,260,21,0,257,0,1,11]

theorem envBound18344 : H12AffineFastState.Bounded env18344 := by
  intro p hp
  have h : env18344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18343_18344 : H12AffineEnvironment.transform 8 10 env18343 = env18344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env18343 == env18344) = true)

def env18345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294201,98780,8328,65,4340965,288824,17664,179512,293108,4491636,257,21793,46213,352034]

theorem envBound18345 : H12AffineFastState.Bounded env18345 := by
  intro p hp
  have h : env18345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18294_18345 : H12AffineEnvironment.transform 20 290153 env18294 = env18345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env18294 == env18345) = true)

def env18346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294201,98780,8328,65,398437,288824,17664,179512,293108,41460,257,21793,46213,352034]

theorem envBound18346 : H12AffineFastState.Bounded env18346 := by
  intro p hp
  have h : env18346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18345_18346 : H12AffineEnvironment.transform 21 272512 env18345 = env18346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18345 == env18346) = true)

theorem identity18346 : scanCanonicalize (H12AffineFastState.compose env18346 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18346 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272512,294201,41431,8328,65,398437,288824,17664,179512,293108,41460,257,21793,46213,294697]

theorem envBound18347 : H12AffineFastState.Bounded env18347 := by
  intro p hp
  have h : env18347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18346_18347 : H12AffineEnvironment.transform 15 8203 env18346 = env18347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18346 == env18347) = true)

def env18348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272392,294201,41311,8192,65,398437,288824,17664,179512,292988,41340,257,21793,46093,294697]

theorem envBound18348 : H12AffineFastState.Bounded env18348 := by
  intro p hp
  have h : env18348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18347_18348 : H12AffineEnvironment.transform 6 8 env18347 = env18348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18347 == env18348) = true)

theorem identity18348 : scanCanonicalize (H12AffineFastState.compose env18348 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound18348 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8203,131072,262144,1025,29708,290153,272392,294201,21842,8192,65,398437,288824,17664,149813,292988,21873,257,21793,16384,294697]

theorem envBound18349 : H12AffineFastState.Bounded env18349 := by
  intro p hp
  have h : env18349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18348_18349 : H12AffineEnvironment.transform 14 29709 env18348 = env18349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env18348 == env18349) = true)

theorem identity18349 : scanCanonicalize (H12AffineFastState.compose env18349 (packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18349 : packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env18350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8203,5393,262144,1025,29708,290153,272392,294201,21842,8192,65,262516,288824,17664,23588,292988,21873,257,21793,16384,294697]

theorem envBound18350 : H12AffineFastState.Bounded env18350 := by
  intro p hp
  have h : env18350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18349_18350 : H12AffineEnvironment.transform 16 5393 env18349 = env18350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18349 == env18350) = true)

theorem identity18350 : scanCanonicalize (H12AffineFastState.compose env18350 (packedSelected [0,3,5,7,9,10,12,14,15,16,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound18350 : packedSelected [0,3,5,7,9,10,12,14,15,16,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env18351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8203,5393,32040,1025,29708,4161,21792,17,21842,8192,65,31836,5392,17664,23588,1364,21873,257,21793,16384,513]

theorem envBound18351 : H12AffineFastState.Bounded env18351 := by
  intro p hp
  have h : env18351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18350_18351 : H12AffineEnvironment.transform 17 32040 env18350 = env18351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env18350 == env18351) = true)

theorem identity18351 : scanCanonicalize (H12AffineFastState.compose env18351 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18351 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,80,8203,5393,2421,1025,81,4161,8573,17,8463,8192,65,2049,5392,12637,10361,1364,8492,257,8572,13405,513]

theorem envBound18352 : H12AffineFastState.Bounded env18352 := by
  intro p hp
  have h : env18352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18351_18352 : H12AffineEnvironment.transform 13 13405 env18351 = env18352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18351 == env18352) = true)

theorem identity18352 : scanCanonicalize (H12AffineFastState.compose env18352 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18352 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18353 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,8203,5393,2341,1025,1,4113,8493,17,8463,8192,17,2049,5392,12557,10281,1284,8492,257,8492,13325,513]

theorem envBound18353 : H12AffineFastState.Bounded env18353 := by
  intro p hp
  have h : env18353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18352_18353 : H12AffineEnvironment.transform 5 16 env18352 = env18353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18352 == env18353) = true)

def env18354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272393,294201,41310,8193,65,398437,288824,17664,179512,292989,41341,257,21793,46092,294697]

theorem envBound18354 : H12AffineFastState.Bounded env18354 := by
  intro p hp
  have h : env18354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18347_18354 : H12AffineEnvironment.transform 6 9 env18347 = env18354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18347 == env18354) = true)

theorem identity18354 : scanCanonicalize (H12AffineFastState.compose env18354 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound18354 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8203,131072,262144,1025,32769,276537,272393,272489,41310,8193,65,398437,277864,4176,179512,273709,41341,257,113,46092,273017]

theorem envBound18355 : H12AffineFastState.Bounded env18355 := by
  intro p hp
  have h : env18355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18354_18355 : H12AffineEnvironment.transform 13 5456 env18354 = env18355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env18354 == env18355) = true)

theorem identity18355 : scanCanonicalize (H12AffineFastState.compose env18355 (packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound18355 : packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env18356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8203,46109,262144,1025,32769,276537,272393,272489,41310,8193,65,303224,277864,4176,2341,273709,41341,257,113,46092,273017]

theorem envBound18356 : H12AffineFastState.Bounded env18356 := by
  intro p hp
  have h : env18356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18355_18356 : H12AffineEnvironment.transform 16 46109 env18355 = env18356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env18355 == env18356) = true)

theorem identity18356 : scanCanonicalize (H12AffineFastState.compose env18356 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18356 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env18357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8203,5440,262144,1025,8540,276537,272393,272489,3,8193,65,262437,277864,4176,2341,273709,32,257,113,5457,273017]

theorem envBound18357 : H12AffineFastState.Bounded env18357 := by
  intro p hp
  have h : env18357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18356_18357 : H12AffineEnvironment.transform 14 8541 env18356 = env18357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18356 == env18357) = true)

theorem identity18357 : scanCanonicalize (H12AffineFastState.compose env18357 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound18357 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env18358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,292,114,5440,262144,1025,293,268352,264304,264208,3,120,65,262437,269585,4176,2341,265556,32,257,113,5457,264704]

theorem envBound18358 : H12AffineFastState.Bounded env18358 := by
  intro p hp
  have h : env18358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18357_18358 : H12AffineEnvironment.transform 12 121 env18357 = env18358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env18357 == env18358) = true)

theorem identity18358 : scanCanonicalize (H12AffineFastState.compose env18358 (packedSelected [2,4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18358 : packedSelected [2,4,9,14] rootPS < 2^1333 := by decide +kernel

def env18359 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5156,80,114,5172,262144,1025,81,268352,264304,264208,3,120,65,262225,269413,4176,2129,265248,32,117,113,5157,264704]

theorem envBound18359 : H12AffineFastState.Bounded env18359 := by
  intro p hp
  have h : env18359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18358_18359 : H12AffineEnvironment.transform 7 116 env18358 = env18359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18358 == env18359) = true)

theorem identity18359 : scanCanonicalize (H12AffineFastState.compose env18359 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound18359 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18360 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5156,80,114,5172,2049,1025,81,4161,113,17,3,120,65,2128,5220,4176,2129,1057,32,117,113,5157,513]

theorem envBound18360 : H12AffineFastState.Bounded env18360 := by
  intro p hp
  have h : env18360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18359_18360 : H12AffineEnvironment.transform 17 2049 env18359 = env18360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env18359 == env18360) = true)

def env18361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294201,98780,8328,65,398436,288824,17664,179512,293108,41461,257,21793,46213,352034]

theorem envBound18361 : H12AffineFastState.Bounded env18361 := by
  intro p hp
  have h : env18361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18345_18361 : H12AffineEnvironment.transform 21 272513 env18345 = env18361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18345 == env18361) = true)

theorem identity18361 : scanCanonicalize (H12AffineFastState.compose env18361 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound18361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95650,73754,98780,8328,65,215367,79131,17664,179512,75223,41461,257,21793,46213,513]

theorem envBound18362 : H12AffineFastState.Bounded env18362 := by
  intro p hp
  have h : env18362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18361_18362 : H12AffineEnvironment.transform 17 89379 env18361 = env18362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env18361 == env18362) = true)

def env18363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73754,98644,8192,65,215367,79131,17664,179512,75103,41341,257,21793,46093,513]

theorem envBound18363 : H12AffineFastState.Bounded env18363 := by
  intro p hp
  have h : env18363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18362_18363 : H12AffineEnvironment.transform 6 8 env18362 = env18363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18362 == env18363) = true)

theorem identity18363 : scanCanonicalize (H12AffineFastState.compose env18363 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18363 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89379,1025,29789,77898,95530,73754,95496,8192,65,215367,79131,17664,149860,75103,21793,257,21793,16465,513]

theorem envBound18364 : H12AffineFastState.Bounded env18364 := by
  intro p hp
  have h : env18364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18363_18364 : H12AffineEnvironment.transform 14 29788 env18363 = env18364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18363 == env18364) = true)

theorem identity18364 : scanCanonicalize (H12AffineFastState.compose env18364 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 90187) := by decide +kernel

theorem selectedBound18364 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env18365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90187,89379,1025,29789,77898,95530,73754,95496,8192,65,10508,79131,17664,76079,75103,21793,257,21793,16465,513]

theorem envBound18365 : H12AffineFastState.Bounded env18365 := by
  intro p hp
  have h : env18365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18364_18365 : H12AffineEnvironment.transform 16 90187 env18364 = env18365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90187 env18364 == env18365) = true)

theorem identity18365 : scanCanonicalize (H12AffineFastState.compose env18365 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound18365 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env18366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8283,16400,32120,1025,29789,4113,21873,65,21843,8192,65,10508,5440,17664,2420,1284,21793,257,21793,16465,513]

theorem envBound18366 : H12AffineFastState.Bounded env18366 := by
  intro p hp
  have h : env18366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18365_18366 : H12AffineEnvironment.transform 15 8283 env18365 = env18366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env18365 == env18366) = true)

theorem identity18366 : scanCanonicalize (H12AffineFastState.compose env18366 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18366 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18367 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,16400,32040,1025,29709,4113,21793,17,21763,8192,17,10508,5392,17664,2340,1284,21793,257,21793,16385,513]

theorem envBound18367 : H12AffineFastState.Bounded env18367 := by
  intro p hp
  have h : env18367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18366_18367 : H12AffineEnvironment.transform 5 16 env18366 = env18367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18366 == env18367) = true)

theorem identity18367 : scanCanonicalize (H12AffineFastState.compose env18367 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound18367 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env18368 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,16384,21792,295,16400,23556,1025,21793,4113,21793,17,21763,300,17,2080,5392,17664,2340,1284,21793,257,21793,16385,513]

theorem envBound18368 : H12AffineFastState.Bounded env18368 := by
  intro p hp
  have h : env18368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18367_18368 : H12AffineEnvironment.transform 12 300 env18367 = env18368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env18367 == env18368) = true)

theorem identity18368 : scanCanonicalize (H12AffineFastState.compose env18368 (packedSelected [0,2,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound18368 : packedSelected [0,2,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env18369 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,5157,261,295,5173,2081,1025,260,4113,260,17,294,300,17,2080,5392,4389,2340,1284,260,257,260,5156,513]

theorem envBound18369 : H12AffineFastState.Bounded env18369 := by
  intro p hp
  have h : env18369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18368_18369 : H12AffineEnvironment.transform 13 5157 env18368 = env18369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env18368 == env18369) = true)

theorem identity18369 : scanCanonicalize (H12AffineFastState.compose env18369 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18369 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18370 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,9,5157,32,2,5173,2081,1025,33,4113,33,17,3,9,17,2080,5173,4096,2049,1057,33,36,33,5156,513]

theorem envBound18370 : H12AffineFastState.Bounded env18370 := by
  intro p hp
  have h : env18370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18369_18370 : H12AffineEnvironment.transform 7 37 env18369 = env18370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18369 == env18370) = true)

theorem identity18370 : scanCanonicalize (H12AffineFastState.compose env18370 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18371 : List Nat := [2,4,8,16,32,16,8,37,512,20,2048,4096,9,4145,32,2,4129,2081,21,33,4113,33,17,3,9,17,2080,4129,4096,2049,53,33,36,33,4144,513]

theorem envBound18371 : H12AffineFastState.Bounded env18371 := by
  intro p hp
  have h : env18371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18370_18371 : H12AffineEnvironment.transform 9 20 env18370 = env18371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18370 == env18371) = true)

theorem identity18371 : scanCanonicalize (H12AffineFastState.compose env18371 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18371 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18372 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,4096,9,4112,1,2,4096,2048,21,0,4113,0,17,3,9,17,2049,4096,4096,2049,20,0,5,0,4113,513]

theorem envBound18372 : H12AffineFastState.Bounded env18372 := by
  intro p hp
  have h : env18372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18371_18372 : H12AffineEnvironment.transform 4 1 env18371 = env18372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18371 == env18372) = true)

theorem identity18372 : scanCanonicalize (H12AffineFastState.compose env18372 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound18372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18373 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,512,9,528,1,2,512,2048,21,0,529,0,17,3,9,17,2049,512,512,2049,20,0,5,0,529,513]

theorem envBound18373 : H12AffineFastState.Bounded env18373 := by
  intro p hp
  have h : env18373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18372_18373 : H12AffineEnvironment.transform 11 512 env18372 = env18373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env18372 == env18373) = true)

theorem identity18373 : scanCanonicalize (H12AffineFastState.compose env18373 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18374 : List Nat := [2,4,8,16,1,16,8,4,512,20,0,512,9,528,1,2,512,0,21,0,529,0,17,3,9,17,1,512,512,1,20,0,5,0,529,513]

theorem envBound18374 : H12AffineFastState.Bounded env18374 := by
  intro p hp
  have h : env18374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18373_18374 : H12AffineEnvironment.transform 10 0 env18373 = env18374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18373 == env18374) = true)

theorem identity18374 : scanCanonicalize (H12AffineFastState.compose env18374 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18374 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18375 : List Nat := [2,4,8,0,1,0,8,4,512,4,0,512,9,512,1,2,512,0,5,0,513,0,1,3,9,1,1,512,512,1,4,0,5,0,513,513]

theorem envBound18375 : H12AffineFastState.Bounded env18375 := by
  intro p hp
  have h : env18375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18374_18375 : H12AffineEnvironment.transform 3 0 env18374 = env18375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18374 == env18375) = true)

theorem identity18375 : scanCanonicalize (H12AffineFastState.compose env18375 (packedSelected [12] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18375 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env18376 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,1,9,1,1,2,1,0,5,0,0,0,1,3,9,1,1,1,1,1,4,0,5,0,0,0]

theorem envBound18376 : H12AffineFastState.Bounded env18376 := by
  intro p hp
  have h : env18376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18375_18376 : H12AffineEnvironment.transform 8 1 env18375 = env18376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18375 == env18376) = true)

def env18377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95531,73754,98645,8193,65,215367,79131,17664,179512,75102,41340,257,21793,46092,513]

theorem envBound18377 : H12AffineFastState.Bounded env18377 := by
  intro p hp
  have h : env18377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18362_18377 : H12AffineEnvironment.transform 6 9 env18362 = env18377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18362 == env18377) = true)

theorem identity18377 : scanCanonicalize (H12AffineFastState.compose env18377 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18377 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18378 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,88115,273,32769,77898,94267,73754,98645,8193,65,215367,77835,16400,178216,73806,41340,257,20529,45340,513]

theorem envBound18378 : H12AffineFastState.Bounded env18378 := by
  intro p hp
  have h : env18378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18377_18378 : H12AffineEnvironment.transform 9 272 env18377 = env18378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18377 == env18378) = true)

theorem identity18378 : scanCanonicalize (H12AffineFastState.compose env18378 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound18378 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env18379 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,90139,88115,273,32769,77898,94267,73754,98645,8193,65,10588,77835,16400,120883,73806,41340,257,20529,45340,513]

theorem envBound18379 : H12AffineFastState.Bounded env18379 := by
  intro p hp
  have h : env18379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18378_18379 : H12AffineEnvironment.transform 16 90139 env18378 = env18379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env18378 == env18379) = true)

theorem identity18379 : scanCanonicalize (H12AffineFastState.compose env18379 (packedSelected [3,5,10,11,17,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound18379 : packedSelected [3,5,10,11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env18380 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,29004,65536,90139,88115,273,29005,77898,94267,73754,94233,8193,65,10588,77835,16400,76159,73806,20528,257,20529,16464,513]

theorem envBound18380 : H12AffineFastState.Bounded env18380 := by
  intro p hp
  have h : env18380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18379_18380 : H12AffineEnvironment.transform 14 29004 env18379 = env18380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env18379 == env18380) = true)

theorem identity18380 : scanCanonicalize (H12AffineFastState.compose env18380 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound18380 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18381 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8541,65536,77834,67618,273,8540,77898,73770,73754,73736,8193,65,10588,77835,4097,76159,73806,33,257,32,4161,513]

theorem envBound18381 : H12AffineFastState.Bounded env18381 := by
  intro p hp
  have h : env18381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18380_18381 : H12AffineEnvironment.transform 13 4113 env18380 = env18381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env18380 == env18381) = true)

theorem identity18381 : scanCanonicalize (H12AffineFastState.compose env18381 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2397) := by decide +kernel

theorem selectedBound18381 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env18382 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,2397,4113,2048,65536,72023,67618,273,2049,71959,67959,67911,67925,2396,65,1,72022,4097,65570,67859,33,257,32,4161,513]

theorem envBound18382 : H12AffineFastState.Bounded env18382 := by
  intro p hp
  have h : env18382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18381_18382 : H12AffineEnvironment.transform 12 2397 env18381 = env18382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2397 env18381 == env18382) = true)

theorem identity18382 : scanCanonicalize (H12AffineFastState.compose env18382 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 2390) := by decide +kernel

theorem selectedBound18382 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18383 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,2397,4113,2048,2390,4097,372,273,2049,4161,33,17,3,2396,65,1,4096,4097,2420,69,33,257,32,4161,513]

theorem envBound18383 : H12AffineFastState.Bounded env18383 := by
  intro p hp
  have h : env18383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18382_18383 : H12AffineEnvironment.transform 15 2390 env18382 = env18383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2390 env18382 == env18383) = true)

theorem identity18383 : scanCanonicalize (H12AffineFastState.compose env18383 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound18383 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18384 : List Nat := [2,4,8,16,32,64,9,256,512,272,260,4096,89,4113,260,82,4097,372,273,261,4161,33,17,3,88,65,1,4096,4097,112,69,33,257,32,4161,513]

theorem envBound18384 : H12AffineFastState.Bounded env18384 := by
  intro p hp
  have h : env18384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18383_18384 : H12AffineEnvironment.transform 10 260 env18383 = env18384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env18383 == env18384) = true)

theorem identity18384 : scanCanonicalize (H12AffineFastState.compose env18384 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18384 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18385 : List Nat := [2,4,8,16,32,16,9,256,512,272,260,4096,9,4113,260,2,4097,292,273,261,4113,33,17,3,8,17,1,4096,4097,32,21,33,257,32,4113,513]

theorem envBound18385 : H12AffineFastState.Bounded env18385 := by
  intro p hp
  have h : env18385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18384_18385 : H12AffineEnvironment.transform 5 16 env18384 = env18385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18384 == env18385) = true)

theorem identity18385 : scanCanonicalize (H12AffineFastState.compose env18385 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound18385 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18386 : List Nat := [2,4,8,16,32,16,9,256,512,272,260,309,9,292,260,2,308,292,273,261,292,33,17,3,8,17,1,309,308,32,21,33,257,32,292,513]

theorem envBound18386 : H12AffineFastState.Bounded env18386 := by
  intro p hp
  have h : env18386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18385_18386 : H12AffineEnvironment.transform 11 309 env18385 = env18386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env18385 == env18386) = true)

theorem identity18386 : scanCanonicalize (H12AffineFastState.compose env18386 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18386 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18387 : List Nat := [2,4,8,16,32,16,9,256,1,272,260,309,9,292,260,2,308,292,273,261,292,33,17,3,8,17,1,309,308,32,21,33,257,32,292,0]

theorem envBound18387 : H12AffineFastState.Bounded env18387 := by
  intro p hp
  have h : env18387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18386_18387 : H12AffineEnvironment.transform 8 1 env18386 = env18387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18386 == env18387) = true)

theorem identity18387 : scanCanonicalize (H12AffineFastState.compose env18387 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18388 : List Nat := [2,4,8,16,1,16,9,256,1,272,260,276,9,261,260,2,277,261,273,261,261,0,17,3,8,17,1,276,277,1,21,0,257,1,261,0]

theorem envBound18388 : H12AffineFastState.Bounded env18388 := by
  intro p hp
  have h : env18388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18387_18388 : H12AffineEnvironment.transform 4 1 env18387 = env18388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18387 == env18388) = true)

theorem identity18388 : scanCanonicalize (H12AffineFastState.compose env18388 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18388 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18389 : List Nat := [2,4,8,0,1,0,9,256,1,256,260,260,9,261,260,2,261,261,257,261,261,0,1,3,8,1,1,260,261,1,5,0,257,1,261,0]

theorem envBound18389 : H12AffineFastState.Bounded env18389 := by
  intro p hp
  have h : env18389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18388_18389 : H12AffineEnvironment.transform 3 0 env18388 = env18389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18388 == env18389) = true)

theorem identity18389 : scanCanonicalize (H12AffineFastState.compose env18389 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound18389 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18390 : List Nat := [2,4,8,0,1,0,9,14,1,14,10,10,9,11,10,2,11,11,15,11,11,0,1,3,8,1,1,10,11,1,5,0,15,1,11,0]

theorem envBound18390 : H12AffineFastState.Bounded env18390 := by
  intro p hp
  have h : env18390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18389_18390 : H12AffineEnvironment.transform 7 14 env18389 = env18390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env18389 == env18390) = true)

theorem identity18390 : scanCanonicalize (H12AffineFastState.compose env18390 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18390 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18391 : List Nat := [2,4,2,0,1,0,3,4,1,4,0,0,3,1,0,2,1,1,5,1,1,0,1,3,2,1,1,0,1,1,5,0,5,1,1,0]

theorem envBound18391 : H12AffineFastState.Bounded env18391 := by
  intro p hp
  have h : env18391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18390_18391 : H12AffineEnvironment.transform 2 2 env18390 = env18391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18390 == env18391) = true)

def env18392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound18392 : H12AffineFastState.Bounded env18392 := by
  intro p hp
  have h : env18392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15678_18392 : H12AffineEnvironment.transform 31 145662401 env15678 = env18392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env15678 == env18392) = true)

def env18393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound18393 : H12AffineFastState.Bounded env18393 := by
  intro p hp
  have h : env18393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18392_18393 : H12AffineEnvironment.transform 29 155254784 env18392 = env18393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env18392 == env18393) = true)

def env18394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound18394 : H12AffineFastState.Bounded env18394 := by
  intro p hp
  have h : env18394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18393_18394 : H12AffineEnvironment.transform 25 64 env18393 = env18394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env18393 == env18394) = true)

def env18395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound18395 : H12AffineFastState.Bounded env18395 := by
  intro p hp
  have h : env18395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18394_18395 : H12AffineEnvironment.transform 26 30393344 env18394 = env18395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env18394 == env18395) = true)

def env18396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound18396 : H12AffineFastState.Bounded env18396 := by
  intro p hp
  have h : env18396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18395_18396 : H12AffineEnvironment.transform 18 1024 env18395 = env18396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env18395 == env18396) = true)

theorem identity18396 : scanCanonicalize (H12AffineFastState.compose env18396 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601612) := by decide +kernel

theorem selectedBound18396 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601612,8328,64,6685836,8404992,10507601,8830976,2113692,12624205,256,32,57733,2189130]

theorem envBound18397 : H12AffineFastState.Bounded env18397 := by
  intro p hp
  have h : env18397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18396_18397 : H12AffineEnvironment.transform 23 10601612 env18396 = env18397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601612 env18396 == env18397) = true)

def env18398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685836,8393984,10485841,8819968,2102684,12624205,256,32,46213,2175562]

theorem envBound18398 : H12AffineFastState.Bounded env18398 := by
  intro p hp
  have h : env18398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18397_18398 : H12AffineEnvironment.transform 13 5376 env18397 = env18398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18397 == env18398) = true)

def env18399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685836,2098648,4233,2524632,2102684,6336917,256,32,46213,2175562]

theorem envBound18399 : H12AffineFastState.Bounded env18399 := by
  intro p hp
  have h : env18399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18398_18399 : H12AffineEnvironment.transform 22 2101464 env18398 = env18399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env18398 == env18399) = true)

def env18400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491564,2098648,4233,2524632,2102684,2142645,256,32,46213,2175562]

theorem envBound18400 : H12AffineFastState.Bounded env18400 := by
  intro p hp
  have h : env18400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18399_18400 : H12AffineEnvironment.transform 21 32 env18399 = env18400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env18399 == env18400) = true)

theorem identity18400 : scanCanonicalize (H12AffineFastState.compose env18400 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18400 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98644,8192,64,2491428,2098512,4097,2524496,2102548,2142525,256,32,46093,2175562]

theorem envBound18401 : H12AffineFastState.Bounded env18401 := by
  intro p hp
  have h : env18401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18400_18401 : H12AffineEnvironment.transform 6 8 env18400 = env18401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18400 == env18401) = true)

def env18402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98644,8192,64,398436,5392,4097,431376,1364,41341,256,32,46093,74250]

theorem envBound18402 : H12AffineFastState.Bounded env18402 := by
  intro p hp
  have h : env18402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18401_18402 : H12AffineEnvironment.transform 20 4160 env18401 = env18402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18401 == env18402) = true)

theorem identity18402 : scanCanonicalize (H12AffineFastState.compose env18402 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18402 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41311,8192,64,398436,5392,4097,431376,1364,41341,256,32,46093,513]

theorem envBound18403 : H12AffineFastState.Bounded env18403 := by
  intro p hp
  have h : env18403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18402_18403 : H12AffineEnvironment.transform 15 8203 env18402 = env18403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18402 == env18403) = true)

theorem identity18403 : scanCanonicalize (H12AffineFastState.compose env18403 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18403 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,32,16,2,8192,64,398436,5392,4097,406605,1364,32,256,32,5456,513]

theorem envBound18404 : H12AffineFastState.Bounded env18404 := by
  intro p hp
  have h : env18404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18403_18404 : H12AffineEnvironment.transform 14 8541 env18403 = env18404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18403 == env18404) = true)

theorem identity18404 : scanCanonicalize (H12AffineFastState.compose env18404 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound18404 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146792,1024,8540,4160,32,16,2,8192,64,10508,5392,4097,2341,1364,32,256,32,5456,513]

theorem envBound18405 : H12AffineFastState.Bounded env18405 := by
  intro p hp
  have h : env18405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18404_18405 : H12AffineEnvironment.transform 17 146792 env18404 = env18405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env18404 == env18405) = true)

theorem identity18405 : scanCanonicalize (H12AffineFastState.compose env18405 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18405 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env18406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10361,1024,8540,4160,32,16,2,8192,64,10508,5392,4097,2341,1364,32,256,32,5456,513]

theorem envBound18406 : H12AffineFastState.Bounded env18406 := by
  intro p hp
  have h : env18406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18405_18406 : H12AffineEnvironment.transform 16 5393 env18405 = env18406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18405 == env18406) = true)

theorem identity18406 : scanCanonicalize (H12AffineFastState.compose env18406 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18406 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env18407 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5156,8313,8203,5173,10361,1024,8312,4160,32,16,2,8192,64,10280,5172,4097,2049,1136,32,36,32,5236,513]

theorem envBound18407 : H12AffineFastState.Bounded env18407 := by
  intro p hp
  have h : env18407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18406_18407 : H12AffineEnvironment.transform 7 36 env18406 = env18407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18406 == env18407) = true)

def env18408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98644,8192,64,398437,5393,4097,431377,1365,41340,256,32,46093,74251]

theorem envBound18408 : H12AffineFastState.Bounded env18408 := by
  intro p hp
  have h : env18408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18401_18408 : H12AffineEnvironment.transform 20 4161 env18401 = env18408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18401 == env18408) = true)

theorem identity18408 : scanCanonicalize (H12AffineFastState.compose env18408 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound18408 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,4161,32,17,98644,8192,64,203847,5393,4097,236851,1365,41340,256,32,46093,74251]

theorem envBound18409 : H12AffineFastState.Bounded env18409 := by
  intro p hp
  have h : env18409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18408_18409 : H12AffineEnvironment.transform 17 67618 env18408 = env18409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env18408 == env18409) = true)

theorem identity18409 : scanCanonicalize (H12AffineFastState.compose env18409 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18409 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,131072,10280,1024,32769,4161,32,17,41310,8192,64,146509,5393,4097,179513,1365,41340,256,32,46093,513]

theorem envBound18410 : H12AffineFastState.Bounded env18410 := by
  intro p hp
  have h : env18410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18409_18410 : H12AffineEnvironment.transform 15 8202 env18409 = env18410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18409 == env18410) = true)

theorem identity18410 : scanCanonicalize (H12AffineFastState.compose env18410 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18410 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,262,131072,2340,1024,32769,4161,32,17,32850,268,64,138561,5393,4097,171061,1365,32880,256,32,38145,513]

theorem envBound18411 : H12AffineFastState.Bounded env18411 := by
  intro p hp
  have h : env18411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18410_18411 : H12AffineEnvironment.transform 12 268 env18410 = env18411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18410 == env18411) = true)

theorem identity18411 : scanCanonicalize (H12AffineFastState.compose env18411 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound18411 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env18412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,262,5441,2340,1024,32769,4161,32,17,32850,268,64,2048,5393,4097,35188,1365,32880,256,32,38145,513]

theorem envBound18412 : H12AffineFastState.Bounded env18412 := by
  intro p hp
  have h : env18412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18411_18412 : H12AffineEnvironment.transform 16 5441 env18411 = env18412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env18411 == env18412) = true)

def env18413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491565,2098648,4233,2524632,2102684,2142644,256,32,46213,2175562]

theorem envBound18413 : H12AffineFastState.Bounded env18413 := by
  intro p hp
  have h : env18413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18399_18413 : H12AffineEnvironment.transform 21 33 env18399 = env18413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18399 == env18413) = true)

theorem identity18413 : scanCanonicalize (H12AffineFastState.compose env18413 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound18413 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,152,98644,8328,64,398573,5528,4233,431512,1500,41460,256,32,46213,74250]

theorem envBound18414 : H12AffineFastState.Bounded env18414 := by
  intro p hp
  have h : env18414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18413_18414 : H12AffineEnvironment.transform 20 4160 env18413 = env18414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18413 == env18414) = true)

def env18415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98644,8192,64,398437,5392,4097,431376,1364,41340,256,32,46093,74250]

theorem envBound18415 : H12AffineFastState.Bounded env18415 := by
  intro p hp
  have h : env18415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18414_18415 : H12AffineEnvironment.transform 6 8 env18414 = env18415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18414 == env18415) = true)

theorem identity18415 : scanCanonicalize (H12AffineFastState.compose env18415 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18415 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41311,8192,64,398437,5392,4097,431376,1364,41340,256,32,46093,513]

theorem envBound18416 : H12AffineFastState.Bounded env18416 := by
  intro p hp
  have h : env18416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18415_18416 : H12AffineEnvironment.transform 15 8203 env18415 = env18416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18415 == env18416) = true)

theorem identity18416 : scanCanonicalize (H12AffineFastState.compose env18416 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18416 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,33,16,2,8192,64,398437,5392,4097,406605,1364,33,256,32,5456,513]

theorem envBound18417 : H12AffineFastState.Bounded env18417 := by
  intro p hp
  have h : env18417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18416_18417 : H12AffineEnvironment.transform 14 8541 env18416 = env18417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18416 == env18417) = true)

theorem identity18417 : scanCanonicalize (H12AffineFastState.compose env18417 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound18417 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146792,1024,8540,4160,33,16,2,8192,64,10509,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound18418 : H12AffineFastState.Bounded env18418 := by
  intro p hp
  have h : env18418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18417_18418 : H12AffineEnvironment.transform 17 146792 env18417 = env18418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env18417 == env18418) = true)

theorem identity18418 : scanCanonicalize (H12AffineFastState.compose env18418 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18418 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env18419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,131072,138293,1024,1,4160,33,16,2,349,64,2128,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound18419 : H12AffineFastState.Bounded env18419 := by
  intro p hp
  have h : env18419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18418_18419 : H12AffineEnvironment.transform 12 349 env18418 = env18419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18418 == env18419) = true)

theorem identity18419 : scanCanonicalize (H12AffineFastState.compose env18419 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound18419 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1