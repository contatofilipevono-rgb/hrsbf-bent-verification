import H12CloudChart1Data176

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env44864 : List Nat := [2,4,8,16,32,64,9,116,512,1024,0,16,120,1125,1,114,1141,80,1025,0,81,33,17,2,121,64,0,1061,17,81,1136,32,117,113,1077,592]

theorem envBound44864 : H12AffineFastState.Bounded env44864 := by
  intro p hp
  have h : env44864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44863_44864 : H12AffineEnvironment.transform 10 0 env44863 = env44864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44863 == env44864) = true)

theorem identity44864 : scanCanonicalize (H12AffineFastState.compose env44864 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44864 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env44865 : List Nat := [2,4,8,16,32,17,9,37,512,1024,0,16,41,1076,1,35,1060,1,1025,0,0,33,17,2,40,17,0,1061,17,0,1057,32,36,32,1077,513]

theorem envBound44865 : H12AffineFastState.Bounded env44865 := by
  intro p hp
  have h : env44865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44864_44865 : H12AffineEnvironment.transform 5 17 env44864 = env44865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44864 == env44865) = true)

theorem identity44865 : scanCanonicalize (H12AffineFastState.compose env44865 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound44865 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44866 : List Nat := [2,4,8,16,32,17,9,37,512,36,0,16,41,16,1,35,0,1,37,0,0,33,17,2,40,17,0,1,17,0,5,32,36,32,17,513]

theorem envBound44866 : H12AffineFastState.Bounded env44866 := by
  intro p hp
  have h : env44866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44865_44866 : H12AffineEnvironment.transform 9 36 env44865 = env44866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env44865 == env44866) = true)

theorem identity44866 : scanCanonicalize (H12AffineFastState.compose env44866 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44866 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44867 : List Nat := [2,4,8,16,32,17,9,37,17,36,0,16,41,16,1,35,0,1,37,0,0,33,17,2,40,17,0,1,17,0,5,32,36,32,17,16]

theorem envBound44867 : H12AffineFastState.Bounded env44867 := by
  intro p hp
  have h : env44867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44866_44867 : H12AffineEnvironment.transform 8 17 env44866 = env44867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44866 == env44867) = true)

def env44868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254083,16777216,8328,64,16959643,18973836,2340307,336002,16934035,19369433,257,19014703,19056010,16991044]

theorem envBound44868 : H12AffineFastState.Bounded env44868 := by
  intro p hp
  have h : env44868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44786_44868 : H12AffineEnvironment.transform 21 452633 env44786 = env44868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env44786 == env44868) = true)

def env44869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254083,243088,8328,64,97547,2240796,2340307,336002,119043,2373705,257,2199999,2191386,63188]

theorem envBound44869 : H12AffineFastState.Bounded env44869 := by
  intro p hp
  have h : env44869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44868_44869 : H12AffineEnvironment.transform 23 243088 env44868 = env44869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env44868 == env44869) = true)

def env44870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254083,243088,8328,64,97547,139612,238995,336002,119043,272393,257,98815,90202,63188]

theorem envBound44870 : H12AffineFastState.Bounded env44870 := by
  intro p hp
  have h : env44870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44869_44870 : H12AffineEnvironment.transform 20 4160 env44869 = env44870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44869 == env44870) = true)

theorem identity44870 : scanCanonicalize (H12AffineFastState.compose env44870 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound44870 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,400588,201814,213317,8328,64,97547,139612,217414,336002,75222,272393,257,95530,90202,513]

theorem envBound44871 : H12AffineFastState.Bounded env44871 := by
  intro p hp
  have h : env44871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44870_44871 : H12AffineEnvironment.transform 14 29909 env44870 = env44871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env44870 == env44871) = true)

def env44872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,400452,201814,213317,8192,64,97547,139612,217414,335882,75102,272393,257,95530,90202,513]

theorem envBound44872 : H12AffineFastState.Bounded env44872 := by
  intro p hp
  have h : env44872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44871_44872 : H12AffineEnvironment.transform 6 8 env44871 = env44872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44871 == env44872) = true)

theorem identity44872 : scanCanonicalize (H12AffineFastState.compose env44872 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound44872 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1025,29788,4160,359518,29772,8543,8192,64,97547,82246,12636,335882,75102,272393,257,95530,90202,513]

theorem envBound44873 : H12AffineFastState.Bounded env44873 := by
  intro p hp
  have h : env44873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44872_44873 : H12AffineEnvironment.transform 16 90138 env44872 = env44873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env44872 == env44873) = true)

theorem identity44873 : scanCanonicalize (H12AffineFastState.compose env44873 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound44873 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,3172,1025,29788,4160,94266,29772,8543,8192,64,97547,82246,12636,76910,75102,9325,257,95530,90202,513]

theorem envBound44874 : H12AffineFastState.Bounded env44874 := by
  intro p hp
  have h : env44874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44873_44874 : H12AffineEnvironment.transform 17 3172 env44873 = env44874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env44873 == env44874) = true)

theorem identity44874 : scanCanonicalize (H12AffineFastState.compose env44874 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound44874 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env44875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,1345,65536,69894,3172,1025,1344,4160,65830,1360,8543,8192,64,68631,77914,12636,76910,75102,9325,257,66614,69958,513]

theorem envBound44875 : H12AffineFastState.Bounded env44875 := by
  intro p hp
  have h : env44875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44874_44875 : H12AffineEnvironment.transform 13 12572 env44874 = env44875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env44874 == env44875) = true)

theorem identity44875 : scanCanonicalize (H12AffineFastState.compose env44875 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound44875 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,1345,1047,5393,3172,1025,1344,4160,1329,1360,8543,8192,64,2048,13389,12636,10361,8521,9325,257,33,5457,513]

theorem envBound44876 : H12AffineFastState.Bounded env44876 := by
  intro p hp
  have h : env44876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44875_44876 : H12AffineEnvironment.transform 15 1047 env44875 = env44876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env44875 == env44876) = true)

theorem identity44876 : scanCanonicalize (H12AffineFastState.compose env44876 (packedSelected [12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44876 : packedSelected [12,15,17] rootPS < 2^1333 := by decide +kernel

def env44877 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,12393,1076,1047,5220,3172,1025,1077,4160,1092,1061,8234,8192,64,2048,13389,12329,10361,8252,9325,116,33,5156,513]

theorem envBound44877 : H12AffineFastState.Bounded env44877 := by
  intro p hp
  have h : env44877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44876_44877 : H12AffineEnvironment.transform 7 117 env44876 = env44877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44876 == env44877) = true)

theorem identity44877 : scanCanonicalize (H12AffineFastState.compose env44877 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound44877 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44878 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1100,5157,1076,1047,5220,3172,1025,1077,4160,1092,1061,1126,1100,64,2048,4097,5221,3125,1136,33,116,33,5156,513]

theorem envBound44878 : H12AffineFastState.Bounded env44878 := by
  intro p hp
  have h : env44878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44877_44878 : H12AffineEnvironment.transform 12 1100 env44877 = env44878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env44877 == env44878) = true)

theorem identity44878 : scanCanonicalize (H12AffineFastState.compose env44878 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44878 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env44879 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,121,4112,1,34,4177,2129,52,0,4160,113,16,83,121,64,2048,4097,4176,2048,69,33,116,33,4113,513]

theorem envBound44879 : H12AffineFastState.Bounded env44879 := by
  intro p hp
  have h : env44879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44878_44879 : H12AffineEnvironment.transform 9 53 env44878 = env44879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44878 == env44879) = true)

theorem identity44879 : scanCanonicalize (H12AffineFastState.compose env44879 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound44879 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44880 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2065,121,2049,1,34,2112,2129,52,0,2129,113,16,83,121,64,2048,2064,2113,2048,69,33,116,33,2048,513]

theorem envBound44880 : H12AffineFastState.Bounded env44880 := by
  intro p hp
  have h : env44880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44879_44880 : H12AffineEnvironment.transform 11 2065 env44879 = env44880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env44879 == env44880) = true)

def env44881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,400453,201814,213317,8193,64,97547,139612,217414,335883,75103,272393,257,95530,90202,513]

theorem envBound44881 : H12AffineFastState.Bounded env44881 := by
  intro p hp
  have h : env44881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44871_44881 : H12AffineEnvironment.transform 6 9 env44871 = env44881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44871 == env44881) = true)

theorem identity44881 : scanCanonicalize (H12AffineFastState.compose env44881 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound44881 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,4160,156013,201814,213317,8193,64,97547,139612,217414,89379,75103,21793,257,95530,90202,513]

theorem envBound44882 : H12AffineFastState.Bounded env44882 := by
  intro p hp
  have h : env44882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44881_44882 : H12AffineEnvironment.transform 17 32040 env44881 = env44882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env44881 == env44882) = true)

theorem identity44882 : scanCanonicalize (H12AffineFastState.compose env44882 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound44882 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env44883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,131072,32040,1025,29789,4160,156013,136449,147474,8193,64,31836,139612,151569,23668,9224,21793,257,29821,24845,513]

theorem envBound44883 : H12AffineFastState.Bounded env44883 := by
  intro p hp
  have h : env44883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44882_44883 : H12AffineEnvironment.transform 15 343 env44882 = env44883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env44882 == env44883) = true)

theorem identity44883 : scanCanonicalize (H12AffineFastState.compose env44883 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44883 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env44884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,343,131072,2421,1025,0,4160,136496,136449,144463,8193,64,2049,139612,140364,10281,9224,8572,257,32,5456,513]

theorem envBound44884 : H12AffineFastState.Bounded env44884 := by
  intro p hp
  have h : env44884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44883_44884 : H12AffineEnvironment.transform 13 13405 env44883 = env44884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44883 == env44884) = true)

theorem identity44884 : scanCanonicalize (H12AffineFastState.compose env44884 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44884 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,131072,2421,1025,0,4160,136496,136449,136466,348,64,2049,131073,132369,2420,1365,33,257,32,5456,513]

theorem envBound44885 : H12AffineFastState.Bounded env44885 := by
  intro p hp
  have h : env44885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44884_44885 : H12AffineEnvironment.transform 12 349 env44884 = env44885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44884 == env44885) = true)

theorem identity44885 : scanCanonicalize (H12AffineFastState.compose env44885 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound44885 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1025,0,4160,32,17,2,348,64,2049,5393,4097,2420,1365,33,257,32,5456,513]

theorem envBound44886 : H12AffineFastState.Bounded env44886 := by
  intro p hp
  have h : env44886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44885_44886 : H12AffineEnvironment.transform 16 5392 env44885 = env44886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env44885 == env44886) = true)

theorem identity44886 : scanCanonicalize (H12AffineFastState.compose env44886 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 832) := by decide +kernel

theorem selectedBound44886 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44887 : List Nat := [2,4,8,16,32,64,9,256,512,832,2048,4096,349,4672,1,343,4688,2421,833,0,4160,32,17,2,348,64,2049,4689,4097,2420,533,33,257,32,4624,513]

theorem envBound44887 : H12AffineFastState.Bounded env44887 := by
  intro p hp
  have h : env44887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44886_44887 : H12AffineEnvironment.transform 9 832 env44886 = env44887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env44886 == env44887) = true)

theorem identity44887 : scanCanonicalize (H12AffineFastState.compose env44887 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44887 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44888 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,4096,269,4624,1,263,4608,2341,785,0,4112,32,17,2,268,16,2049,4609,4097,2340,533,33,257,32,4624,513]

theorem envBound44888 : H12AffineFastState.Bounded env44888 := by
  intro p hp
  have h : env44888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44887_44888 : H12AffineEnvironment.transform 5 16 env44887 = env44888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44887 == env44888) = true)

theorem identity44888 : scanCanonicalize (H12AffineFastState.compose env44888 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound44888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44889 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,261,269,789,1,263,773,2341,785,0,277,32,17,2,268,16,2049,772,260,2340,533,33,257,32,789,513]

theorem envBound44889 : H12AffineFastState.Bounded env44889 := by
  intro p hp
  have h : env44889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44888_44889 : H12AffineEnvironment.transform 11 261 env44888 = env44889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env44888 == env44889) = true)

theorem identity44889 : scanCanonicalize (H12AffineFastState.compose env44889 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound44889 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44890 : List Nat := [2,4,8,16,32,16,9,256,512,784,293,261,269,789,1,263,773,0,785,0,277,32,17,2,268,16,292,772,260,1,533,33,257,32,789,513]

theorem envBound44890 : H12AffineFastState.Bounded env44890 := by
  intro p hp
  have h : env44890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44889_44890 : H12AffineEnvironment.transform 10 293 env44889 = env44890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env44889 == env44890) = true)

theorem identity44890 : scanCanonicalize (H12AffineFastState.compose env44890 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44890 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44891 : List Nat := [2,4,8,0,32,0,9,256,512,768,293,261,269,773,1,263,773,0,769,0,261,32,1,2,268,0,292,772,260,1,517,33,257,32,773,513]

theorem envBound44891 : H12AffineFastState.Bounded env44891 := by
  intro p hp
  have h : env44891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44890_44891 : H12AffineEnvironment.transform 3 0 env44890 = env44891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44890 == env44891) = true)

theorem identity44891 : scanCanonicalize (H12AffineFastState.compose env44891 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound44891 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44892 : List Nat := [2,4,8,0,32,0,9,256,260,4,293,261,269,1,1,263,1,0,5,0,261,32,1,2,268,0,292,0,260,1,257,33,257,32,1,261]

theorem envBound44892 : H12AffineFastState.Bounded env44892 := by
  intro p hp
  have h : env44892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44891_44892 : H12AffineEnvironment.transform 8 260 env44891 = env44892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env44891 == env44892) = true)

def env44893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254083,243088,8328,64,97547,139613,238994,336002,119043,272392,257,98814,90203,63188]

theorem envBound44893 : H12AffineFastState.Bounded env44893 := by
  intro p hp
  have h : env44893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44869_44893 : H12AffineEnvironment.transform 20 4161 env44869 = env44893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44869 == env44893) = true)

theorem identity44893 : scanCanonicalize (H12AffineFastState.compose env44893 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound44893 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318549,120015,98780,8328,64,97547,5393,102878,336002,119043,272392,257,98814,90203,63188]

theorem envBound44894 : H12AffineFastState.Bounded env44894 := by
  intro p hp
  have h : env44894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44893_44894 : H12AffineEnvironment.transform 16 13388 env44893 = env44894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env44893 == env44894) = true)

def env44895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1025,32769,4161,62709,120015,98780,8328,64,97547,5393,102878,67618,119043,168,257,98814,90203,63188]

theorem envBound44895 : H12AffineFastState.Bounded env44895 := by
  intro p hp
  have h : env44895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44894_44895 : H12AffineEnvironment.transform 17 10400 env44894 = env44895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env44894 == env44895) = true)

theorem identity44895 : scanCanonicalize (H12AffineFastState.compose env44895 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound44895 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env44896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,65536,13388,10400,1025,8232,4161,21724,95462,74229,8328,64,97547,5393,78327,67618,94506,168,257,74199,90203,22269]

theorem envBound44896 : H12AffineFastState.Bounded env44896 := by
  intro p hp
  have h : env44896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44895_44896 : H12AffineEnvironment.transform 14 8233 env44895 = env44896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env44895 == env44896) = true)

theorem identity44896 : scanCanonicalize (H12AffineFastState.compose env44896 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44896 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env44897 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,65536,13388,10400,1025,8232,4161,21724,95462,73857,8328,64,97407,5221,77955,67618,94302,168,117,73891,90203,22269]

theorem envBound44897 : H12AffineFastState.Bounded env44897 := by
  intro p hp
  have h : env44897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44896_44897 : H12AffineEnvironment.transform 7 116 env44896 = env44897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44896 == env44897) = true)

theorem identity44897 : scanCanonicalize (H12AffineFastState.compose env44897 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound44897 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44898 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,29823,13388,10400,1025,8232,4161,21724,153,21758,8328,64,2048,5221,17660,31837,1057,168,117,21724,5156,22269]

theorem envBound44898 : H12AffineFastState.Bounded env44898 := by
  intro p hp
  have h : env44898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44897_44898 : H12AffineEnvironment.transform 15 29823 env44897 = env44898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env44897 == env44898) = true)

theorem identity44898 : scanCanonicalize (H12AffineFastState.compose env44898 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44898 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env44899 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,29823,13388,10281,1025,8232,4161,21589,16,21623,8193,64,2048,5221,17525,31837,1057,33,117,21589,5156,22132]

theorem envBound44899 : H12AffineFastState.Bounded env44899 := by
  intro p hp
  have h : env44899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44898_44899 : H12AffineEnvironment.transform 6 9 env44898 = env44899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44898 == env44899) = true)

theorem identity44899 : scanCanonicalize (H12AffineFastState.compose env44899 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44899 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env44900 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,4096,8192,16384,8233,28746,12409,10281,52,8232,4161,20576,16,20546,8193,64,2048,4176,16448,30824,20,33,117,20576,4113,21057]

theorem envBound44900 : H12AffineFastState.Bounded env44900 := by
  intro p hp
  have h : env44900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44899_44900 : H12AffineEnvironment.transform 9 53 env44899 = env44900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44899 == env44900) = true)

theorem identity44900 : scanCanonicalize (H12AffineFastState.compose env44900 (packedSelected [1,2,6,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 8233) := by decide +kernel

theorem selectedBound44900 : packedSelected [1,2,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44901 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,4096,8192,8233,8233,4195,12409,10281,52,8232,4161,12361,16,12395,8193,64,2048,4176,8297,6209,20,33,117,12361,4113,12904]

theorem envBound44901 : H12AffineFastState.Bounded env44901 := by
  intro p hp
  have h : env44901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44900_44901 : H12AffineEnvironment.transform 13 8233 env44900 = env44901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8233 env44900 == env44901) = true)

theorem identity44901 : scanCanonicalize (H12AffineFastState.compose env44901 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound44901 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44902 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,4096,2168,2129,2129,4195,6145,81,52,2128,4161,6193,16,6163,2169,64,2048,4176,2065,6209,20,33,117,6193,4113,6672]

theorem envBound44902 : H12AffineFastState.Bounded env44902 := by
  intro p hp
  have h : env44902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44901_44902 : H12AffineEnvironment.transform 12 2168 env44901 = env44902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env44901 == env44902) = true)

theorem identity44902 : scanCanonicalize (H12AffineFastState.compose env44902 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound44902 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env44903 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,2064,2168,2129,2129,2163,17,81,52,2128,2129,33,16,3,2169,64,2048,2112,2065,81,20,33,117,33,2049,512]

theorem envBound44903 : H12AffineFastState.Bounded env44903 := by
  intro p hp
  have h : env44903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44902_44903 : H12AffineEnvironment.transform 11 2064 env44902 = env44903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env44902 == env44903) = true)

theorem identity44903 : scanCanonicalize (H12AffineFastState.compose env44903 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound44903 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44904 : List Nat := [2,4,8,16,32,64,9,116,512,53,33,49,89,112,112,82,17,81,52,113,112,33,16,3,88,64,33,97,48,81,20,33,117,33,32,512]

theorem envBound44904 : H12AffineFastState.Bounded env44904 := by
  intro p hp
  have h : env44904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44903_44904 : H12AffineEnvironment.transform 10 33 env44903 = env44904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env44903 == env44904) = true)

theorem identity44904 : scanCanonicalize (H12AffineFastState.compose env44904 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44904 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44905 : List Nat := [2,4,8,16,32,16,9,36,512,53,33,49,9,32,32,2,17,1,52,33,32,33,16,3,8,16,33,49,48,1,20,33,37,33,32,512]

theorem envBound44905 : H12AffineFastState.Bounded env44905 := by
  intro p hp
  have h : env44905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44904_44905 : H12AffineEnvironment.transform 5 16 env44904 = env44905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44904 == env44905) = true)

theorem identity44905 : scanCanonicalize (H12AffineFastState.compose env44905 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44905 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44906 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,16,9,1,1,2,17,1,21,0,1,0,16,3,8,16,0,16,17,1,20,0,4,0,1,512]

theorem envBound44906 : H12AffineFastState.Bounded env44906 := by
  intro p hp
  have h : env44906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44905_44906 : H12AffineEnvironment.transform 4 1 env44905 = env44906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44905 == env44906) = true)

def env44907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10401,1025,32769,4161,62708,120015,98780,8328,64,97547,5393,102878,67619,119043,169,257,98814,90203,63188]

theorem envBound44907 : H12AffineFastState.Bounded env44907 := by
  intro p hp
  have h : env44907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44894_44907 : H12AffineEnvironment.transform 17 10401 env44894 = env44907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44894 == env44907) = true)

theorem identity44907 : scanCanonicalize (H12AffineFastState.compose env44907 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound44907 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env44908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13388,10401,1025,32769,4161,62708,17,21762,8328,64,43477,5393,17664,56573,1501,169,257,21792,46213,63188]

theorem envBound44908 : H12AffineFastState.Bounded env44908 := by
  intro p hp
  have h : env44908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44907_44908 : H12AffineEnvironment.transform 15 54494 env44907 = env44908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env44907 == env44908) = true)

theorem identity44908 : scanCanonicalize (H12AffineFastState.compose env44908 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44908 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env44909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,13388,10401,1025,32769,4161,41461,17,3,8328,64,43477,5393,4097,35324,1501,169,257,33,46213,41941]

theorem envBound44909 : H12AffineFastState.Bounded env44909 := by
  intro p hp
  have h : env44909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44908_44909 : H12AffineEnvironment.transform 13 5377 env44908 = env44909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44908 == env44909) = true)

theorem identity44909 : scanCanonicalize (H12AffineFastState.compose env44909 (packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound44909 : packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env44910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5377,32768,33247,5609,2308,1025,32769,4161,32848,17,3,301,64,34928,5393,4097,35324,1501,169,257,33,38176,33392]

theorem envBound44910 : H12AffineFastState.Bounded env44910 := by
  intro p hp
  have h : env44910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44909_44910 : H12AffineEnvironment.transform 12 421 env44909 = env44910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env44909 == env44910) = true)

theorem identity44910 : scanCanonicalize (H12AffineFastState.compose env44910 (packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound44910 : packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env44911 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,421,5377,32768,33198,5528,2308,1025,32769,4144,32801,17,3,301,49,34817,5393,4097,35213,1452,169,257,33,38176,33281]

theorem envBound44911 : H12AffineFastState.Bounded env44911 := by
  intro p hp
  have h : env44911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44910_44911 : H12AffineEnvironment.transform 5 49 env44910 = env44911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env44910 == env44911) = true)

theorem identity44911 : scanCanonicalize (H12AffineFastState.compose env44911 (packedSelected [2,6,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44911 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env44912 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,421,5377,0,430,5528,2308,1025,1,4144,33,17,3,301,49,2049,5393,4097,2445,1452,169,257,33,5408,513]

theorem envBound44912 : H12AffineFastState.Bounded env44912 := by
  intro p hp
  have h : env44912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44911_44912 : H12AffineEnvironment.transform 14 0 env44911 = env44912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44911 == env44912) = true)

theorem identity44912 : scanCanonicalize (H12AffineFastState.compose env44912 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound44912 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44913 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,4096,268,5377,0,263,5425,2308,1025,1,4144,33,17,3,301,49,2049,5393,4097,2340,1285,0,257,33,5408,513]

theorem envBound44913 : H12AffineFastState.Bounded env44913 := by
  intro p hp
  have h : env44913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44912_44913 : H12AffineEnvironment.transform 6 41 env44912 = env44913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env44912 == env44913) = true)

theorem identity44913 : scanCanonicalize (H12AffineFastState.compose env44913 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound44913 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44914 : List Nat := [2,4,8,16,32,49,41,256,512,1024,1281,4096,268,5377,0,263,5425,1029,1025,1,4144,33,17,3,301,49,1280,5393,4097,1061,1285,0,257,33,5408,513]

theorem envBound44914 : H12AffineFastState.Bounded env44914 := by
  intro p hp
  have h : env44914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44913_44914 : H12AffineEnvironment.transform 10 1281 env44913 = env44914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env44913 == env44914) = true)

theorem identity44914 : scanCanonicalize (H12AffineFastState.compose env44914 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound44914 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env44915 : List Nat := [2,4,8,16,32,49,41,256,512,1024,1281,1540,268,773,0,263,821,1029,1025,1,1588,33,17,3,301,49,1280,789,1541,1061,1285,0,257,33,804,513]

theorem envBound44915 : H12AffineFastState.Bounded env44915 := by
  intro p hp
  have h : env44915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44914_44915 : H12AffineEnvironment.transform 11 1540 env44914 = env44915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env44914 == env44915) = true)

theorem identity44915 : scanCanonicalize (H12AffineFastState.compose env44915 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44915 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env44916 : List Nat := [2,4,8,16,32,49,41,256,512,4,261,512,268,773,0,263,821,1,5,1,560,33,17,3,301,49,260,789,513,33,257,0,257,33,804,513]

theorem envBound44916 : H12AffineFastState.Bounded env44916 := by
  intro p hp
  have h : env44916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44915_44916 : H12AffineEnvironment.transform 9 4 env44915 = env44916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44915 == env44916) = true)

theorem identity44916 : scanCanonicalize (H12AffineFastState.compose env44916 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44916 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44917 : List Nat := [2,4,8,16,32,49,41,256,16,4,261,16,268,277,0,263,293,1,5,1,32,33,17,3,301,49,260,261,17,33,257,0,257,33,308,17]

theorem envBound44917 : H12AffineFastState.Bounded env44917 := by
  intro p hp
  have h : env44917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44916_44917 : H12AffineEnvironment.transform 8 16 env44916 = env44917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44916 == env44917) = true)

theorem identity44917 : scanCanonicalize (H12AffineFastState.compose env44917 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound44917 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44918 : List Nat := [2,4,8,16,32,49,41,52,16,4,49,16,56,33,0,51,17,1,5,1,32,33,17,3,25,49,48,49,17,33,53,0,53,33,0,17]

theorem envBound44918 : H12AffineFastState.Bounded env44918 := by
  intro p hp
  have h : env44918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44917_44918 : H12AffineEnvironment.transform 7 52 env44917 = env44918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env44917 == env44918) = true)

theorem identity44918 : scanCanonicalize (H12AffineFastState.compose env44918 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44918 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44919 : List Nat := [2,4,8,16,0,17,9,20,16,4,17,16,24,1,0,19,17,1,5,1,0,1,17,3,25,17,16,17,17,1,21,0,21,1,0,17]

theorem envBound44919 : H12AffineFastState.Bounded env44919 := by
  intro p hp
  have h : env44919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44918_44919 : H12AffineEnvironment.transform 4 0 env44918 = env44919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44918 == env44919) = true)

theorem identity44919 : scanCanonicalize (H12AffineFastState.compose env44919 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound44919 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44920 : List Nat := [2,4,8,4,0,5,9,0,4,4,5,4,12,1,0,7,5,1,5,1,0,1,5,3,13,5,4,5,5,1,1,0,1,1,0,5]

theorem envBound44920 : H12AffineFastState.Bounded env44920 := by
  intro p hp
  have h : env44920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44919_44920 : H12AffineEnvironment.transform 3 4 env44919 = env44920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env44919 == env44920) = true)

theorem identity44920 : scanCanonicalize (H12AffineFastState.compose env44920 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44921 : List Nat := [0,4,8,4,0,5,9,0,4,4,5,4,12,1,0,5,5,1,5,1,0,1,5,1,13,5,4,5,5,1,1,0,1,1,0,5]

theorem envBound44921 : H12AffineFastState.Bounded env44921 := by
  intro p hp
  have h : env44921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44920_44921 : H12AffineEnvironment.transform 0 0 env44920 = env44921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44920 == env44921) = true)

def env44922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254083,243089,8328,64,97546,2240797,2340307,336002,119042,2373704,257,2199998,2191387,63189]

theorem envBound44922 : H12AffineFastState.Bounded env44922 := by
  intro p hp
  have h : env44922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44868_44922 : H12AffineEnvironment.transform 23 243089 env44868 = env44922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env44868 == env44922) = true)

def env44923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254083,243089,8328,64,97546,139613,238995,336002,119042,272392,257,98814,90203,63189]

theorem envBound44923 : H12AffineFastState.Bounded env44923 := by
  intro p hp
  have h : env44923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44922_44923 : H12AffineEnvironment.transform 20 4160 env44922 = env44923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44922 == env44923) = true)

theorem identity44923 : scanCanonicalize (H12AffineFastState.compose env44923 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound44923 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4160,272512,73754,95496,8328,64,97546,57796,91402,336002,119042,272392,257,98814,90203,63189]

theorem envBound44924 : H12AffineFastState.Bounded env44924 := by
  intro p hp
  have h : env44924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44923_44924 : H12AffineEnvironment.transform 16 49305 env44923 = env44924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env44923 == env44924) = true)

def env44925 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4112,272512,73754,95496,8328,16,97546,57748,91402,336002,119042,272392,257,98734,90123,63109]

theorem envBound44925 : H12AffineFastState.Bounded env44925 := by
  intro p hp
  have h : env44925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44924_44925 : H12AffineEnvironment.transform 5 16 env44924 = env44925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44924 == env44925) = true)

theorem identity44925 : scanCanonicalize (H12AffineFastState.compose env44925 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44925 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env44926 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10280,1025,32769,4112,168,73754,95496,8328,16,97546,57748,91402,67754,119042,32,257,98734,90123,63109]

theorem envBound44926 : H12AffineFastState.Bounded env44926 := by
  intro p hp
  have h : env44926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44925_44926 : H12AffineEnvironment.transform 17 10280 env44925 = env44926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44925 == env44926) = true)

theorem identity44926 : scanCanonicalize (H12AffineFastState.compose env44926 (packedSelected [0,1,2,4,5,6,9,10,11,16,17,23,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound44926 : packedSelected [0,1,2,4,5,6,9,10,11,16,17,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,136,65536,16401,10280,1025,137,4112,168,73754,95496,8328,16,97546,24860,91402,67754,86410,32,257,65830,90123,30221]

theorem envBound44927 : H12AffineFastState.Bounded env44927 := by
  intro p hp
  have h : env44927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44926_44927 : H12AffineEnvironment.transform 14 136 env44926 = env44927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env44926 == env44927) = true)

theorem identity44927 : scanCanonicalize (H12AffineFastState.compose env44927 (packedSelected [1,2,3,4,5,6,8,10,11,17,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound44927 : packedSelected [1,2,3,4,5,6,8,10,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44928 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,136,29962,16401,10280,1025,137,4112,168,21776,2,8328,16,2048,24860,4096,32160,9344,32,257,29740,5377,30221]

theorem envBound44928 : H12AffineFastState.Bounded env44928 := by
  intro p hp
  have h : env44928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44927_44928 : H12AffineEnvironment.transform 15 29962 env44927 = env44928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env44927 == env44928) = true)

theorem identity44928 : scanCanonicalize (H12AffineFastState.compose env44928 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44928 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44929 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,136,8202,5393,10280,1025,137,4112,168,16,2,8328,16,2048,13340,4096,10400,9344,32,257,8492,5377,8973]

theorem envBound44929 : H12AffineFastState.Bounded env44929 := by
  intro p hp
  have h : env44929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44928_44929 : H12AffineEnvironment.transform 13 5376 env44928 = env44929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44928 == env44929) = true)

theorem identity44929 : scanCanonicalize (H12AffineFastState.compose env44929 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44929 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44930 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,8202,5393,10280,1025,0,4112,33,16,2,8193,16,2048,13340,4096,10281,9225,32,257,8492,5377,8973]

theorem envBound44930 : H12AffineFastState.Bounded env44930 := by
  intro p hp
  have h : env44930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44929_44930 : H12AffineEnvironment.transform 6 9 env44929 = env44930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44929 == env44930) = true)

theorem identity44930 : scanCanonicalize (H12AffineFastState.compose env44930 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound44930 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env44931 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,5376,1,8202,5393,9244,1025,0,4112,33,16,2,8193,16,1076,13340,4096,9245,9225,32,257,8492,5377,8973]

theorem envBound44931 : H12AffineFastState.Bounded env44931 := by
  intro p hp
  have h : env44931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44930_44931 : H12AffineEnvironment.transform 10 1076 env44930 = env44931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env44930 == env44931) = true)

theorem identity44931 : scanCanonicalize (H12AffineFastState.compose env44931 (packedSelected [0,1,2,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound44931 : packedSelected [0,1,2,6,8,9] rootPS < 2^1333 := by decide +kernel

def env44932 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,308,8192,1076,1,8202,1061,9244,1025,0,292,33,16,2,8193,16,1076,9512,308,9245,9225,32,257,8492,1077,8973]

theorem envBound44932 : H12AffineFastState.Bounded env44932 := by
  intro p hp
  have h : env44932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44931_44932 : H12AffineEnvironment.transform 11 308 env44931 = env44932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env44931 == env44932) = true)

theorem identity44932 : scanCanonicalize (H12AffineFastState.compose env44932 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound44932 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env44933 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,308,8,1076,1,2,1061,1044,1025,0,292,33,16,2,9,16,1076,1312,308,1045,1025,32,257,292,1077,773]

theorem envBound44933 : H12AffineFastState.Bounded env44933 := by
  intro p hp
  have h : env44933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44932_44933 : H12AffineEnvironment.transform 12 8 env44932 = env44933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env44932 == env44933) = true)

theorem identity44933 : scanCanonicalize (H12AffineFastState.compose env44933 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44933 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env44934 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1044,276,8,1044,1,2,1029,1044,1025,0,260,1,16,2,9,16,1044,1280,276,1045,1025,0,257,260,1045,773]

theorem envBound44934 : H12AffineFastState.Bounded env44934 := by
  intro p hp
  have h : env44934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44933_44934 : H12AffineEnvironment.transform 4 0 env44933 = env44934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44933 == env44934) = true)

theorem identity44934 : scanCanonicalize (H12AffineFastState.compose env44934 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44934 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44935 : List Nat := [2,4,8,16,0,16,9,4,512,1024,1044,16,8,1044,1,2,1029,1044,1025,0,0,1,16,2,9,16,1044,1028,16,1045,1025,0,5,0,1045,513]

theorem envBound44935 : H12AffineFastState.Bounded env44935 := by
  intro p hp
  have h : env44935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44934_44935 : H12AffineEnvironment.transform 7 4 env44934 = env44935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44934 == env44935) = true)

theorem identity44935 : scanCanonicalize (H12AffineFastState.compose env44935 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound44935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44936 : List Nat := [2,4,8,16,0,16,9,4,20,1024,1044,16,8,1044,1,2,1029,1044,1025,0,0,1,16,2,9,16,1044,1028,16,1045,1025,0,5,0,1045,21]

theorem envBound44936 : H12AffineFastState.Bounded env44936 := by
  intro p hp
  have h : env44936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44935_44936 : H12AffineEnvironment.transform 8 20 env44935 = env44936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env44935 == env44936) = true)

theorem identity44936 : scanCanonicalize (H12AffineFastState.compose env44936 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44937 : List Nat := [2,4,8,1,0,1,9,4,5,1024,1029,1,8,1029,1,2,1029,1029,1025,0,0,1,1,2,9,1,1029,1028,1,1028,1025,0,5,0,1028,4]

theorem envBound44937 : H12AffineFastState.Bounded env44937 := by
  intro p hp
  have h : env44937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44936_44937 : H12AffineEnvironment.transform 3 1 env44936 = env44937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44936 == env44937) = true)

theorem identity44937 : scanCanonicalize (H12AffineFastState.compose env44937 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44937 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44938 : List Nat := [2,4,2,1,0,1,3,4,5,1024,1029,1,2,1029,1,2,1029,1029,1025,0,0,1,1,2,3,1,1029,1028,1,1028,1025,0,5,0,1028,4]

theorem envBound44938 : H12AffineFastState.Bounded env44938 := by
  intro p hp
  have h : env44938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44937_44938 : H12AffineEnvironment.transform 2 2 env44937 = env44938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44937 == env44938) = true)

def env44939 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4113,272512,73754,95496,8328,17,97546,57749,91402,336002,119042,272392,257,98735,90122,63108]

theorem envBound44939 : H12AffineFastState.Bounded env44939 := by
  intro p hp
  have h : env44939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44924_44939 : H12AffineEnvironment.transform 5 17 env44924 = env44939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44924 == env44939) = true)

def env44940 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4113,272392,73754,95496,8192,17,97546,57629,91402,335882,119042,272392,257,98599,90122,62988]

theorem envBound44940 : H12AffineFastState.Bounded env44940 := by
  intro p hp
  have h : env44940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44939_44940 : H12AffineEnvironment.transform 6 8 env44939 = env44940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44939 == env44940) = true)

theorem identity44940 : scanCanonicalize (H12AffineFastState.compose env44940 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound44940 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44941 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,262144,1025,32769,4113,272392,62492,41230,8192,17,43276,57629,45324,324620,1284,272392,257,21793,46092,62988]

theorem envBound44941 : H12AffineFastState.Bounded env44941 := by
  intro p hp
  have h : env44941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44940_44941 : H12AffineEnvironment.transform 15 54278 env44940 = env44941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env44940 == env44941) = true)

theorem identity44941 : scanCanonicalize (H12AffineFastState.compose env44941 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound44941 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env44942 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,43049,1025,32769,4113,32801,62492,41230,8192,17,43276,57629,45324,23589,1284,32801,257,21793,46092,62988]

theorem envBound44942 : H12AffineFastState.Bounded env44942 := by
  intro p hp
  have h : env44942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44941_44942 : H12AffineEnvironment.transform 17 43049 env44941 = env44942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env44941 == env44942) = true)

theorem identity44942 : scanCanonicalize (H12AffineFastState.compose env44942 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44942 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44943 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,54278,49169,43049,1025,32769,4113,32801,62492,41002,8192,17,43048,57401,45096,23589,1056,32801,37,21509,46092,62988]

theorem envBound44943 : H12AffineFastState.Bounded env44943 := by
  intro p hp
  have h : env44943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44942_44943 : H12AffineEnvironment.transform 7 36 env44942 = env44943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44942 == env44943) = true)

theorem identity44943 : scanCanonicalize (H12AffineFastState.compose env44943 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44943 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env44944 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,32768,54278,49169,34816,1025,32769,4113,32801,54325,32771,41,17,34817,49168,36865,23589,1056,32801,37,21509,37925,54821]

theorem envBound44944 : H12AffineFastState.Bounded env44944 := by
  intro p hp
  have h : env44944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44943_44944 : H12AffineEnvironment.transform 12 41 env44943 = env44944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44943 == env44944) = true)

theorem identity44944 : scanCanonicalize (H12AffineFastState.compose env44944 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound44944 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44945 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5124,32768,32770,37909,34816,1025,32769,4113,32801,32817,32771,41,17,34817,37908,36865,2081,1056,32801,37,1,37925,33313]

theorem envBound44945 : H12AffineFastState.Bounded env44945 := by
  intro p hp
  have h : env44945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44944_44945 : H12AffineEnvironment.transform 13 5124 env44944 = env44945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env44944 == env44945) = true)

theorem identity44945 : scanCanonicalize (H12AffineFastState.compose env44945 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound44945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44946 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5124,32,34,5173,2080,1025,33,4113,1,17,35,41,17,2081,5172,4129,2081,1056,1,37,1,5125,513]

theorem envBound44946 : H12AffineFastState.Bounded env44946 := by
  intro p hp
  have h : env44946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44945_44946 : H12AffineEnvironment.transform 14 32 env44945 = env44946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env44945 == env44946) = true)

theorem identity44946 : scanCanonicalize (H12AffineFastState.compose env44946 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound44946 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44947 : List Nat := [2,4,8,16,32,17,8,36,512,1024,529,4096,41,5124,32,34,5173,561,1025,33,4113,1,17,35,41,17,560,5172,4129,560,1056,1,37,1,5125,513]

theorem envBound44947 : H12AffineFastState.Bounded env44947 := by
  intro p hp
  have h : env44947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44946_44947 : H12AffineEnvironment.transform 10 529 env44946 = env44947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env44946 == env44947) = true)

theorem identity44947 : scanCanonicalize (H12AffineFastState.compose env44947 (packedSelected [0,1,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound44947 : packedSelected [0,1,4,8,10] rootPS < 2^1333 := by decide +kernel

def env44948 : List Nat := [2,4,8,16,32,17,8,36,512,1024,529,1573,41,545,32,34,528,561,1025,33,1588,1,17,35,41,17,560,529,1540,560,1056,1,37,1,544,513]

theorem envBound44948 : H12AffineFastState.Bounded env44948 := by
  intro p hp
  have h : env44948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44947_44948 : H12AffineEnvironment.transform 11 1573 env44947 = env44948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env44947 == env44948) = true)

theorem identity44948 : scanCanonicalize (H12AffineFastState.compose env44948 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44948 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44949 : List Nat := [2,4,8,16,32,17,8,36,512,20,529,561,41,545,32,34,528,561,21,33,544,1,17,35,41,17,560,529,528,560,52,1,37,1,544,513]

theorem envBound44949 : H12AffineFastState.Bounded env44949 := by
  intro p hp
  have h : env44949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44948_44949 : H12AffineEnvironment.transform 9 20 env44948 = env44949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44948 == env44949) = true)

theorem identity44949 : scanCanonicalize (H12AffineFastState.compose env44949 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44949 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44950 : List Nat := [2,4,8,16,1,17,8,5,512,20,529,528,8,512,1,3,528,528,21,0,513,1,17,2,8,17,529,529,528,529,21,1,4,1,513,513]

theorem envBound44950 : H12AffineFastState.Bounded env44950 := by
  intro p hp
  have h : env44950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44949_44950 : H12AffineEnvironment.transform 4 1 env44949 = env44950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44949 == env44950) = true)

theorem identity44950 : scanCanonicalize (H12AffineFastState.compose env44950 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound44950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44951 : List Nat := [2,4,8,16,1,17,8,5,4,20,21,20,8,4,1,3,20,20,21,0,5,1,17,2,8,17,21,21,20,21,21,1,4,1,5,5]

theorem envBound44951 : H12AffineFastState.Bounded env44951 := by
  intro p hp
  have h : env44951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44950_44951 : H12AffineEnvironment.transform 8 4 env44950 = env44951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env44950 == env44951) = true)

theorem identity44951 : scanCanonicalize (H12AffineFastState.compose env44951 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound44951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44952 : List Nat := [2,4,8,9,1,8,8,5,4,13,12,13,8,4,1,3,13,13,12,0,5,1,8,2,8,8,12,12,13,12,12,1,4,1,5,5]

theorem envBound44952 : H12AffineFastState.Bounded env44952 := by
  intro p hp
  have h : env44952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44951_44952 : H12AffineEnvironment.transform 3 9 env44951 = env44952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env44951 == env44952) = true)

theorem identity44952 : scanCanonicalize (H12AffineFastState.compose env44952 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44953 : List Nat := [2,4,1,0,1,1,1,5,4,4,5,4,1,4,1,3,4,4,5,0,5,1,1,2,1,1,5,5,4,5,5,1,4,1,5,5]

theorem envBound44953 : H12AffineFastState.Bounded env44953 := by
  intro p hp
  have h : env44953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44952_44953 : H12AffineEnvironment.transform 2 1 env44952 = env44953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44952 == env44953) = true)

theorem identity44953 : scanCanonicalize (H12AffineFastState.compose env44953 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44953 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44954 : List Nat := [1,4,1,0,1,1,1,5,4,4,5,4,1,4,1,0,4,4,5,0,5,1,1,1,1,1,5,5,4,5,5,1,4,1,5,5]

theorem envBound44954 : H12AffineFastState.Bounded env44954 := by
  intro p hp
  have h : env44954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44953_44954 : H12AffineEnvironment.transform 0 1 env44953 = env44954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44953 == env44954) = true)

theorem identity44954 : scanCanonicalize (H12AffineFastState.compose env44954 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44954 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env44955 : List Nat := [1,1,1,0,1,1,1,0,1,1,0,1,1,1,1,0,1,1,0,0,0,1,1,1,1,1,0,0,1,0,0,1,1,1,0,0]

theorem envBound44955 : H12AffineFastState.Bounded env44955 := by
  intro p hp
  have h : env44955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44954_44955 : H12AffineEnvironment.transform 1 1 env44954 = env44955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44954 == env44955) = true)

def env44956 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4113,272393,73754,95496,8193,17,97546,57628,91402,335883,119042,272392,257,98598,90122,62989]

theorem envBound44956 : H12AffineFastState.Bounded env44956 := by
  intro p hp
  have h : env44956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44939_44956 : H12AffineEnvironment.transform 6 9 env44939 = env44956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44939 == env44956) = true)

theorem identity44956 : scanCanonicalize (H12AffineFastState.compose env44956 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound44956 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44957 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,49168,262144,1025,32769,4113,272393,32784,54530,8193,17,56576,57628,50432,294913,28936,272392,257,8492,49152,62989]

theorem envBound44957 : H12AffineFastState.Bounded env44957 := by
  intro p hp
  have h : env44957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44956_44957 : H12AffineEnvironment.transform 15 40970 env44956 = env44957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env44956 == env44957) = true)

theorem identity44957 : scanCanonicalize (H12AffineFastState.compose env44957 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound44957 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44958 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,21510,13340,262144,1025,29709,4113,272393,29724,8462,8193,17,10508,5392,12556,291853,28936,272392,257,8492,13324,513]

theorem envBound44958 : H12AffineFastState.Bounded env44958 := by
  intro p hp
  have h : env44958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44957_44958 : H12AffineEnvironment.transform 14 29708 env44957 = env44958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env44957 == env44958) = true)

theorem identity44958 : scanCanonicalize (H12AffineFastState.compose env44958 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44958 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44959 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,21510,5392,262144,1025,21761,4113,264453,21776,2,269,17,2048,5392,4096,283905,20484,264452,257,32,5376,513]

theorem envBound44959 : H12AffineFastState.Bounded env44959 := by
  intro p hp
  have h : env44959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44958_44959 : H12AffineEnvironment.transform 12 268 env44958 = env44959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44958 == env44959) = true)

theorem identity44959 : scanCanonicalize (H12AffineFastState.compose env44959 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound44959 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44960 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,21510,5392,2341,1025,21761,4113,32,21776,2,269,17,2048,5392,4096,23588,20484,33,257,32,5376,513]

theorem envBound44960 : H12AffineFastState.Bounded env44960 := by
  intro p hp
  have h : env44960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44959_44960 : H12AffineEnvironment.transform 17 2341 env44959 = env44960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env44959 == env44960) = true)

theorem identity44960 : scanCanonicalize (H12AffineFastState.compose env44960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44961 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,16384,20496,20758,4096,2341,273,20497,4113,32,20480,2,269,17,2048,4096,4096,22836,20484,33,257,32,4112,513]

theorem envBound44961 : H12AffineFastState.Bounded env44961 := by
  intro p hp
  have h : env44961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44960_44961 : H12AffineEnvironment.transform 9 272 env44960 = env44961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44960 == env44961) = true)

theorem identity44961 : scanCanonicalize (H12AffineFastState.compose env44961 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 6453) := by decide +kernel

theorem selectedBound44961 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44962 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,6453,2341,2083,4096,2341,273,2340,4113,32,2357,2,269,17,2048,4096,4096,1,2353,33,257,32,4112,513]

theorem envBound44962 : H12AffineFastState.Bounded env44962 := by
  intro p hp
  have h : env44962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44961_44962 : H12AffineEnvironment.transform 13 6453 env44961 = env44962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6453 env44961 == env44962) = true)

theorem identity44962 : scanCanonicalize (H12AffineFastState.compose env44962 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound44962 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env44963 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2064,268,293,2341,2083,2064,2341,273,2340,2049,32,2357,2,269,17,2048,2064,2064,1,2353,33,257,32,2048,513]

theorem envBound44963 : H12AffineFastState.Bounded env44963 := by
  intro p hp
  have h : env44963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44962_44963 : H12AffineEnvironment.transform 11 2064 env44962 = env44963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env44962 == env44963) = true)

theorem identity44963 : scanCanonicalize (H12AffineFastState.compose env44963 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44963 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44964 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,40,1,2049,2083,2064,2049,53,2048,2049,32,2065,2,41,17,2048,2064,2064,1,2069,33,37,32,2048,513]

theorem envBound44964 : H12AffineFastState.Bounded env44964 := by
  intro p hp
  have h : env44964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44963_44964 : H12AffineEnvironment.transform 7 36 env44963 = env44964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44963 == env44964) = true)

def env44965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254083,243089,8328,64,97546,139612,238994,336002,119042,272393,257,98815,90202,63189]

theorem envBound44965 : H12AffineFastState.Bounded env44965 := by
  intro p hp
  have h : env44965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44922_44965 : H12AffineEnvironment.transform 20 4161 env44922 = env44965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44922 == env44965) = true)

def env44966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,180409,254083,243089,8328,64,97546,139612,238994,67618,119042,169,257,98815,90202,63189]

theorem envBound44966 : H12AffineFastState.Bounded env44966 := by
  intro p hp
  have h : env44966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44965_44966 : H12AffineEnvironment.transform 17 10400 env44965 = env44966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env44965 == env44966) = true)

def env44967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180273,253963,242969,8192,64,97546,139612,238874,67618,119042,33,257,98679,90202,63069]

theorem envBound44967 : H12AffineFastState.Bounded env44967 := by
  intro p hp
  have h : env44967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44966_44967 : H12AffineEnvironment.transform 6 8 env44966 = env44967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44966 == env44967) = true)

theorem identity44967 : scanCanonicalize (H12AffineFastState.compose env44967 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound44967 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,4161,98678,41292,62558,8192,64,97546,90139,58461,67618,119042,33,257,98679,90202,63069]

theorem envBound44968 : H12AffineFastState.Bounded env44968 := by
  intro p hp
  have h : env44968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44967_44968 : H12AffineEnvironment.transform 16 82247 env44967 = env44968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env44967 == env44968) = true)

theorem identity44968 : scanCanonicalize (H12AffineFastState.compose env44968 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44968 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,2421,1025,32769,4161,98678,32785,54531,349,64,89175,82246,50432,67618,119042,33,257,98679,82183,55040]

theorem envBound44969 : H12AffineFastState.Bounded env44969 := by
  intro p hp
  have h : env44969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44968_44969 : H12AffineEnvironment.transform 12 349 env44968 = env44969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44968 == env44969) = true)

theorem identity44969 : scanCanonicalize (H12AffineFastState.compose env44969 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44969 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env44970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,65536,70727,2421,1025,32769,4161,98678,32785,32771,349,64,67927,70726,36864,67618,99330,33,257,98679,70663,33280]

theorem envBound44970 : H12AffineFastState.Bounded env44970 := by
  intro p hp
  have h : env44970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44969_44970 : H12AffineEnvironment.transform 13 5376 env44969 = env44970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44969 == env44970) = true)

theorem identity44970 : scanCanonicalize (H12AffineFastState.compose env44970 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44970 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,65536,70727,2421,1025,1,4161,65910,17,3,349,64,67927,70726,4096,67618,66562,33,257,65911,70663,512]

theorem envBound44971 : H12AffineFastState.Bounded env44971 := by
  intro p hp
  have h : env44971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44970_44971 : H12AffineEnvironment.transform 14 0 env44970 = env44971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44970 == env44971) = true)

theorem identity44971 : scanCanonicalize (H12AffineFastState.compose env44971 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44971 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env44972 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,65536,70678,2340,1025,1,4112,65831,17,3,268,17,67846,70679,4096,67618,66562,33,257,65830,70663,512]

theorem envBound44972 : H12AffineFastState.Bounded env44972 := by
  intro p hp
  have h : env44972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44971_44972 : H12AffineEnvironment.transform 5 17 env44971 = env44972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44971 == env44972) = true)

theorem identity44972 : scanCanonicalize (H12AffineFastState.compose env44972 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44972 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44973 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5376,0,65536,70678,2308,1025,1,4112,65799,17,3,268,17,67846,70679,4096,67586,66562,1,257,65798,70663,512]

theorem envBound44973 : H12AffineFastState.Bounded env44973 := by
  intro p hp
  have h : env44973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44972_44973 : H12AffineEnvironment.transform 4 0 env44972 = env44973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44972 == env44973) = true)

theorem identity44973 : scanCanonicalize (H12AffineFastState.compose env44973 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44973 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env44974 : List Nat := [2,4,8,16,0,17,8,20,512,1024,2048,4096,24,5140,0,65536,70678,2064,1025,1,4112,65555,17,3,24,17,67602,70679,4096,67586,66562,1,21,65554,70663,512]

theorem envBound44974 : H12AffineFastState.Bounded env44974 := by
  intro p hp
  have h : env44974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44973_44974 : H12AffineEnvironment.transform 7 20 env44973 = env44974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44973 == env44974) = true)

def env44975 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180272,253962,242968,8193,64,97546,139612,238875,67618,119042,32,257,98678,90202,63068]

theorem envBound44975 : H12AffineFastState.Bounded env44975 := by
  intro p hp
  have h : env44975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44966_44975 : H12AffineEnvironment.transform 6 9 env44966 = env44975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44966 == env44975) = true)

theorem identity44975 : scanCanonicalize (H12AffineFastState.compose env44975 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound44975 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4161,73770,16,21762,8193,64,97546,115014,17665,67618,119042,32,257,98678,90202,63068]

theorem envBound44976 : H12AffineFastState.Bounded env44976 := by
  intro p hp
  have h : env44976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44975_44976 : H12AffineEnvironment.transform 16 122906 env44975 = env44976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env44975 == env44976) = true)

theorem identity44976 : scanCanonicalize (H12AffineFastState.compose env44976 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44976 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,103495,10281,1025,32769,4161,73770,16,8543,8193,64,67927,111899,12636,67618,107871,32,257,98678,70663,33281]

theorem envBound44977 : H12AffineFastState.Bounded env44977 := by
  intro p hp
  have h : env44977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44976_44977 : H12AffineEnvironment.transform 13 13405 env44976 = env44977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44976 == env44977) = true)

theorem identity44977 : scanCanonicalize (H12AffineFastState.compose env44977 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound44977 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env44978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,1330,37237,10281,1025,32769,4161,9496,16,8543,8193,64,3173,45097,12636,3344,41069,32,257,33860,4405,33281]

theorem envBound44978 : H12AffineFastState.Bounded env44978 := by
  intro p hp
  have h : env44978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44977_44978 : H12AffineEnvironment.transform 15 1330 env44977 = env44978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env44977 == env44978) = true)

theorem identity44978 : scanCanonicalize (H12AffineFastState.compose env44978 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound44978 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env44979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8461,1330,12408,10281,1025,8460,4161,9496,16,8543,8193,64,3173,4388,12636,3344,352,32,257,9545,4405,8972]

theorem envBound44979 : H12AffineFastState.Bounded env44979 := by
  intro p hp
  have h : env44979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44978_44979 : H12AffineEnvironment.transform 14 8461 env44978 = env44979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env44978 == env44979) = true)

theorem identity44979 : scanCanonicalize (H12AffineFastState.compose env44979 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound44979 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,1125,1330,5392,3393,1025,1124,4161,112,16,1079,1385,64,3173,4388,5172,3344,352,32,257,33,4405,1636]

theorem envBound44980 : H12AffineFastState.Bounded env44980 := by
  intro p hp
  have h : env44980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44979_44980 : H12AffineEnvironment.transform 12 1384 env44979 = env44980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env44979 == env44980) = true)

theorem identity44980 : scanCanonicalize (H12AffineFastState.compose env44980 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound44980 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44981 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,41,4405,292,115,4177,2048,320,293,4161,112,16,374,40,64,2340,4388,4469,2129,352,32,257,33,4405,805]

theorem envBound44981 : H12AffineFastState.Bounded env44981 := by
  intro p hp
  have h : env44981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44980_44981 : H12AffineEnvironment.transform 9 321 env44980 = env44981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44980 == env44981) = true)

theorem identity44981 : scanCanonicalize (H12AffineFastState.compose env44981 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound44981 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env44982 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2113,41,2420,292,115,2064,2048,320,293,2048,112,16,374,40,64,2340,2405,2356,2129,352,32,257,33,2420,805]

theorem envBound44982 : H12AffineFastState.Bounded env44982 := by
  intro p hp
  have h : env44982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44981_44982 : H12AffineEnvironment.transform 11 2113 env44981 = env44982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env44981 == env44982) = true)

theorem identity44982 : scanCanonicalize (H12AffineFastState.compose env44982 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44982 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env44983 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2065,41,2340,292,35,2064,2048,272,293,2048,32,16,294,40,16,2340,2357,2356,2049,304,32,257,33,2340,805]

theorem envBound44983 : H12AffineFastState.Bounded env44983 := by
  intro p hp
  have h : env44983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44982_44983 : H12AffineEnvironment.transform 5 16 env44982 = env44983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44982 == env44983) = true)

def env44984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,180408,254083,243089,8328,64,97546,139612,238994,67619,119042,168,257,98815,90202,63189]

theorem envBound44984 : H12AffineFastState.Bounded env44984 := by
  intro p hp
  have h : env44984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44965_44984 : H12AffineEnvironment.transform 17 10401 env44965 = env44984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44965 == env44984) = true)

def env44985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180272,253963,242969,8192,64,97546,139612,238874,67619,119042,32,257,98679,90202,63069]

theorem envBound44985 : H12AffineFastState.Bounded env44985 := by
  intro p hp
  have h : env44985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44984_44985 : H12AffineEnvironment.transform 6 8 env44984 = env44985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44984 == env44985) = true)

theorem identity44985 : scanCanonicalize (H12AffineFastState.compose env44985 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44985 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,4161,156012,213335,201797,8192,64,97546,139612,197702,67619,94302,32,257,73771,90202,22273]

theorem envBound44986 : H12AffineFastState.Bounded env44986 := by
  intro p hp
  have h : env44986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44985_44986 : H12AffineEnvironment.transform 14 8540 env44985 = env44986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44985 == env44986) = true)

theorem identity44986 : scanCanonicalize (H12AffineFastState.compose env44986 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound44986 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env44987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,13389,10281,1025,8541,4161,21793,95514,73736,8192,64,97546,5393,77835,67619,94302,32,257,73771,90202,22273]

theorem envBound44987 : H12AffineFastState.Bounded env44987 := by
  intro p hp
  have h : env44987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44986_44987 : H12AffineEnvironment.transform 16 13389 env44986 = env44987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env44986 == env44987) = true)

theorem identity44987 : scanCanonicalize (H12AffineFastState.compose env44987 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 20806) := by decide +kernel

theorem selectedBound44987 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env44988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,20806,13389,10281,1025,8541,4161,21793,9308,29006,8192,64,11340,5393,24909,22885,8472,32,257,29037,12572,22273]

theorem envBound44988 : H12AffineFastState.Bounded env44988 := by
  intro p hp
  have h : env44988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44987_44988 : H12AffineEnvironment.transform 15 20806 env44987 = env44988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20806 env44987 == env44988) = true)

theorem identity44988 : scanCanonicalize (H12AffineFastState.compose env44988 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound44988 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,8540,8494,13389,10281,1025,8541,4161,9545,9308,294,8192,64,11340,5393,4389,10509,8472,32,257,261,12572,10089]

theorem envBound44989 : H12AffineFastState.Bounded env44989 := by
  intro p hp
  have h : env44989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44988_44989 : H12AffineEnvironment.transform 13 12392 env44988 = env44989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env44988 == env44989) = true)

theorem identity44989 : scanCanonicalize (H12AffineFastState.compose env44989 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound44989 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env44990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5377,1077,1095,4388,3392,1025,1076,4161,32,309,294,1385,64,2341,5393,4389,3172,1137,32,257,261,5237,512]

theorem envBound44990 : H12AffineFastState.Bounded env44990 := by
  intro p hp
  have h : env44990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44989_44990 : H12AffineEnvironment.transform 12 1385 env44989 = env44990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env44989 == env44990) = true)

theorem identity44990 : scanCanonicalize (H12AffineFastState.compose env44990 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound44990 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env44991 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,1085,5205,1077,1095,4208,3092,1025,1076,4161,32,97,114,1085,64,2161,5189,4209,3172,1137,32,85,81,5237,512]

theorem envBound44991 : H12AffineFastState.Bounded env44991 := by
  intro p hp
  have h : env44991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44990_44991 : H12AffineEnvironment.transform 7 84 env44990 = env44991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env44990 == env44991) = true)

theorem identity44991 : scanCanonicalize (H12AffineFastState.compose env44991 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound44991 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env44992 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1093,4096,1085,5205,1077,1095,4208,81,1025,1076,4161,32,97,114,1085,64,1076,5189,4209,33,1137,32,85,81,5237,512]

theorem envBound44992 : H12AffineFastState.Bounded env44992 := by
  intro p hp
  have h : env44992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44991_44992 : H12AffineEnvironment.transform 10 1093 env44991 = env44992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env44991 == env44992) = true)

theorem identity44992 : scanCanonicalize (H12AffineFastState.compose env44992 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound44992 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env44993 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1093,96,1085,1077,1077,1095,16,81,1025,1076,33,32,97,114,1085,64,1076,1061,17,33,1137,32,85,81,1045,512]

theorem envBound44993 : H12AffineFastState.Bounded env44993 := by
  intro p hp
  have h : env44993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44992_44993 : H12AffineEnvironment.transform 11 96 env44992 = env44993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env44992 == env44993) = true)

theorem identity44993 : scanCanonicalize (H12AffineFastState.compose env44993 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44993 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env44994 : List Nat := [2,4,8,16,32,64,8,84,512,20,81,96,41,33,33,83,16,81,21,32,33,32,97,114,41,64,32,49,17,33,101,32,85,81,1,512]

theorem envBound44994 : H12AffineFastState.Bounded env44994 := by
  intro p hp
  have h : env44994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44993_44994 : H12AffineEnvironment.transform 9 20 env44993 = env44994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44993 == env44994) = true)

theorem identity44994 : scanCanonicalize (H12AffineFastState.compose env44994 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44994 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44995 : List Nat := [2,4,8,16,32,16,8,4,512,20,1,48,41,33,33,3,16,1,21,32,33,32,49,34,41,16,32,49,17,33,53,32,5,1,1,512]

theorem envBound44995 : H12AffineFastState.Bounded env44995 := by
  intro p hp
  have h : env44995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44994_44995 : H12AffineEnvironment.transform 5 16 env44994 = env44995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44994 == env44995) = true)

theorem identity44995 : scanCanonicalize (H12AffineFastState.compose env44995 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound44995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44996 : List Nat := [2,4,8,16,32,16,8,4,53,20,1,48,41,33,33,3,16,1,21,32,33,32,49,34,41,16,32,49,17,33,53,32,5,1,1,53]

theorem envBound44996 : H12AffineFastState.Bounded env44996 := by
  intro p hp
  have h : env44996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44995_44996 : H12AffineEnvironment.transform 8 53 env44995 = env44996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env44995 == env44996) = true)

theorem identity44996 : scanCanonicalize (H12AffineFastState.compose env44996 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44997 : List Nat := [2,4,8,16,17,16,8,4,4,20,1,1,24,16,16,3,16,1,21,17,16,17,0,19,24,16,17,0,17,16,4,17,5,1,1,4]

theorem envBound44997 : H12AffineFastState.Bounded env44997 := by
  intro p hp
  have h : env44997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44996_44997 : H12AffineEnvironment.transform 4 17 env44996 = env44997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44996 == env44997) = true)

theorem identity44997 : scanCanonicalize (H12AffineFastState.compose env44997 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound44997 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44998 : List Nat := [2,4,8,5,4,5,8,4,4,1,1,1,13,5,5,3,5,1,0,4,5,4,0,6,13,5,4,0,4,5,4,4,5,1,1,4]

theorem envBound44998 : H12AffineFastState.Bounded env44998 := by
  intro p hp
  have h : env44998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44997_44998 : H12AffineEnvironment.transform 3 5 env44997 = env44998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env44997 == env44998) = true)

def env44999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180273,253962,242968,8193,64,97546,139612,238875,67619,119042,33,257,98678,90202,63068]

theorem envBound44999 : H12AffineFastState.Bounded env44999 := by
  intro p hp
  have h : env44999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44984_44999 : H12AffineEnvironment.transform 6 9 env44984 = env44999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44984 == env44999) = true)

theorem identity44999 : scanCanonicalize (H12AffineFastState.compose env44999 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound44999 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,4161,144492,201815,213317,8193,64,97546,139612,217414,67619,75103,33,257,95531,90202,513]

theorem envBound45000 : H12AffineFastState.Bounded env45000 := by
  intro p hp
  have h : env45000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44999_45000 : H12AffineEnvironment.transform 14 29789 env44999 = env45000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env44999 == env45000) = true)

theorem identity45000 : scanCanonicalize (H12AffineFastState.compose env45000 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound45000 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env45001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,82247,10280,1025,29788,4161,95531,21776,2,8193,64,97546,90139,4097,67619,75103,33,257,95531,90202,513]

theorem envBound45001 : H12AffineFastState.Bounded env45001 := by
  intro p hp
  have h : env45001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45000_45001 : H12AffineEnvironment.transform 16 82247 env45000 = env45001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env45000 == env45001) = true)

theorem identity45001 : scanCanonicalize (H12AffineFastState.compose env45001 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound45001 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,263,16448,10280,1025,29788,4161,29740,21776,2,8193,64,31757,24860,4097,2340,9304,33,257,29740,24925,513]

theorem envBound45002 : H12AffineFastState.Bounded env45002 := by
  intro p hp
  have h : env45002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45001_45002 : H12AffineEnvironment.transform 15 263 env45001 = env45002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env45001 == env45002) = true)

theorem identity45002 : scanCanonicalize (H12AffineFastState.compose env45002 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45002 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,263,5441,10280,1025,8541,4161,8493,17,2,8193,64,10508,13341,4097,2340,9304,33,257,8493,13404,513]

theorem envBound45003 : H12AffineFastState.Bounded env45003 := by
  intro p hp
  have h : env45003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45002_45003 : H12AffineEnvironment.transform 13 5377 env45002 = env45003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45002 == env45003) = true)

theorem identity45003 : scanCanonicalize (H12AffineFastState.compose env45003 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45003 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,263,5441,2421,1025,0,4161,112,17,2,348,64,2129,5440,4097,2340,1285,33,257,112,5377,513]

theorem envBound45004 : H12AffineFastState.Bounded env45004 := by
  intro p hp
  have h : env45004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45003_45004 : H12AffineEnvironment.transform 12 349 env45003 = env45004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45003 == env45004) = true)

theorem identity45004 : scanCanonicalize (H12AffineFastState.compose env45004 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound45004 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1588,4096,349,5377,1,263,5441,1857,1025,0,4161,112,17,2,348,64,1637,5440,4097,1808,1285,33,257,112,5377,513]

theorem envBound45005 : H12AffineFastState.Bounded env45005 := by
  intro p hp
  have h : env45005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45004_45005 : H12AffineEnvironment.transform 10 1588 env45004 = env45005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env45004 == env45005) = true)

theorem identity45005 : scanCanonicalize (H12AffineFastState.compose env45005 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound45005 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env45006 : List Nat := [2,4,8,16,32,64,9,256,324,1024,1392,4096,349,5377,1,263,5441,1029,1025,0,4161,112,17,2,348,64,1313,5440,4097,1108,1285,33,257,112,5377,325]

theorem envBound45006 : H12AffineFastState.Bounded env45006 := by
  intro p hp
  have h : env45006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45005_45006 : H12AffineEnvironment.transform 8 324 env45005 = env45006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env45005 == env45006) = true)

theorem identity45006 : scanCanonicalize (H12AffineFastState.compose env45006 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound45006 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env45007 : List Nat := [2,4,8,16,32,64,9,256,324,117,261,4096,349,4468,1,263,4404,112,116,0,4161,112,17,2,348,64,340,4405,4097,33,368,33,257,112,4468,325]

theorem envBound45007 : H12AffineFastState.Bounded env45007 := by
  intro p hp
  have h : env45007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45006_45007 : H12AffineEnvironment.transform 9 117 env45006 = env45007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env45006 == env45007) = true)

theorem identity45007 : scanCanonicalize (H12AffineFastState.compose env45007 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound45007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45008 : List Nat := [2,4,8,16,32,64,9,256,324,117,261,261,349,113,1,263,49,112,116,0,324,112,17,2,348,64,340,48,260,33,368,33,257,112,113,325]

theorem envBound45008 : H12AffineFastState.Bounded env45008 := by
  intro p hp
  have h : env45008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45007_45008 : H12AffineEnvironment.transform 11 261 env45007 = env45008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env45007 == env45008) = true)

theorem identity45008 : scanCanonicalize (H12AffineFastState.compose env45008 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound45008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45009 : List Nat := [2,4,8,16,32,64,9,52,112,117,49,49,105,113,1,51,49,112,116,0,112,112,17,2,104,64,96,48,48,33,68,33,53,112,113,113]

theorem envBound45009 : H12AffineFastState.Bounded env45009 := by
  intro p hp
  have h : env45009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45008_45009 : H12AffineEnvironment.transform 7 52 env45008 = env45009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env45008 == env45009) = true)

theorem identity45009 : scanCanonicalize (H12AffineFastState.compose env45009 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45009 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45010 : List Nat := [2,4,8,0,32,64,9,36,96,101,33,33,105,97,1,35,33,96,100,0,96,96,1,2,104,64,96,32,32,33,68,33,37,96,97,97]

theorem envBound45010 : H12AffineFastState.Bounded env45010 := by
  intro p hp
  have h : env45010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45009_45010 : H12AffineEnvironment.transform 3 0 env45009 = env45010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45009 == env45010) = true)

theorem identity45010 : scanCanonicalize (H12AffineFastState.compose env45010 (packedSelected [3,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound45010 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env45011 : List Nat := [2,4,8,0,32,32,9,36,0,5,33,33,9,1,1,35,33,0,4,0,0,0,1,2,8,32,0,32,32,33,36,33,37,0,1,1]

theorem envBound45011 : H12AffineFastState.Bounded env45011 := by
  intro p hp
  have h : env45011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45010_45011 : H12AffineEnvironment.transform 5 32 env45010 = env45011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env45010 == env45011) = true)

theorem identity45011 : scanCanonicalize (H12AffineFastState.compose env45011 (packedSelected [18] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45011 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env45012 : List Nat := [2,4,8,0,0,0,9,4,0,5,1,1,9,1,1,3,1,0,4,0,0,0,1,2,8,0,0,0,0,1,4,1,5,0,1,1]

theorem envBound45012 : H12AffineFastState.Bounded env45012 := by
  intro p hp
  have h : env45012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45011_45012 : H12AffineEnvironment.transform 4 0 env45011 = env45012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45011 == env45012) = true)

def env45013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound45013 : H12AffineFastState.Bounded env45013 := by
  intro p hp
  have h : env45013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44622_45013 : H12AffineEnvironment.transform 26 30393345 env44622 = env45013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env44622 == env45013) = true)

def env45014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound45014 : H12AffineFastState.Bounded env45014 := by
  intro p hp
  have h : env45014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45013_45014 : H12AffineEnvironment.transform 18 1024 env45013 = env45014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env45013 == env45014) = true)

theorem identity45014 : scanCanonicalize (H12AffineFastState.compose env45014 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91587) := by decide +kernel

theorem selectedBound45014 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,16777216,8328,64,29868033,16834894,8466579,8830977,25265168,20971522,256,25207151,25182410,25207750]

theorem envBound45015 : H12AffineFastState.Bounded env45015 := by
  intro p hp
  have h : env45015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45014_45015 : H12AffineEnvironment.transform 20 91587 env45014 = env45015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91587 env45014 == env45015) = true)

def env45016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119892,8328,64,12981333,79130,8466579,8830977,8409156,4314198,256,8484155,8492190,8484754]

theorem envBound45016 : H12AffineFastState.Bounded env45016 := by
  intro p hp
  have h : env45016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45015_45016 : H12AffineEnvironment.transform 23 119892 env45015 = env45016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119892 env45015 == env45016) = true)

def env45017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981333,79130,8466579,8819969,8389956,4292950,256,8462395,8492190,8462994]

theorem envBound45017 : H12AffineFastState.Bounded env45017 := by
  intro p hp
  have h : env45017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45016_45017 : H12AffineEnvironment.transform 13 5376 env45016 = env45017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45016 == env45017) = true)

def env45018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787061,79130,8466579,8819969,8389956,98678,256,8462395,8492190,8462994]

theorem envBound45018 : H12AffineFastState.Bounded env45018 := by
  intro p hp
  have h : env45018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45017_45018 : H12AffineEnvironment.transform 21 32 env45017 = env45018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env45017 == env45018) = true)

theorem identity45018 : scanCanonicalize (H12AffineFastState.compose env45018 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound45018 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,73875,98644,8328,64,472294,79130,4096,505234,75223,98678,256,168,46093,513]

theorem envBound45019 : H12AffineFastState.Bounded env45019 := by
  intro p hp
  have h : env45019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45018_45019 : H12AffineEnvironment.transform 22 73875 env45018 = env45019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env45018 == env45019) = true)

def env45020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,73755,98644,8192,64,472174,79130,4096,505114,75103,98678,256,32,46093,513]

theorem envBound45020 : H12AffineFastState.Bounded env45020 := by
  intro p hp
  have h : env45020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45019_45020 : H12AffineEnvironment.transform 6 8 env45019 = env45020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45019 == env45020) = true)

theorem identity45020 : scanCanonicalize (H12AffineFastState.compose env45020 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound45020 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79130,262144,1024,32769,77899,32,73755,98644,8192,64,262516,79130,4096,294912,75103,98678,256,32,46093,513]

theorem envBound45021 : H12AffineFastState.Bounded env45021 := by
  intro p hp
  have h : env45021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45020_45021 : H12AffineEnvironment.transform 16 79130 env45020 = env45021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env45020 == env45021) = true)

theorem identity45021 : scanCanonicalize (H12AffineFastState.compose env45021 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33863) := by decide +kernel

theorem selectedBound45021 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33863,45405,262144,1024,32769,46092,32,42076,1299,8192,64,262516,45405,4096,294912,41240,1329,256,32,46093,513]

theorem envBound45022 : H12AffineFastState.Bounded env45022 := by
  intro p hp
  have h : env45022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45021_45022 : H12AffineEnvironment.transform 15 33863 env45021 = env45022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33863 env45021 == env45022) = true)

theorem identity45022 : scanCanonicalize (H12AffineFastState.compose env45022 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(17+1) ^^^ 44108) := by decide +kernel

theorem selectedBound45022 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env45023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33863,45405,44108,1024,32769,46092,32,42076,1299,8192,64,44344,45405,4096,11340,41240,1329,256,32,46093,513]

theorem envBound45023 : H12AffineFastState.Bounded env45023 := by
  intro p hp
  have h : env45023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45022_45023 : H12AffineEnvironment.transform 17 44108 env45022 = env45023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44108 env45022 == env45023) = true)

theorem identity45023 : scanCanonicalize (H12AffineFastState.compose env45023 (packedSelected [3,5,10,11,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound45023 : packedSelected [3,5,10,11,21,23] rootPS < 2^1333 := by decide +kernel

def env45024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1344,263,13341,10508,1024,1345,12620,32,8476,1299,8192,64,10360,13341,4096,11340,9304,1329,256,32,12621,513]

theorem envBound45024 : H12AffineFastState.Bounded env45024 := by
  intro p hp
  have h : env45024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45023_45024 : H12AffineEnvironment.transform 14 1344 env45023 = env45024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env45023 == env45024) = true)

theorem identity45024 : scanCanonicalize (H12AffineFastState.compose env45024 (packedSelected [11,12,15,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound45024 : packedSelected [11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env45025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,1344,263,4389,3124,1024,1345,5236,32,1060,1299,1336,64,3392,4389,4096,2420,352,1329,256,32,5237,513]

theorem envBound45025 : H12AffineFastState.Bounded env45025 := by
  intro p hp
  have h : env45025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45024_45025 : H12AffineEnvironment.transform 12 1336 env45024 = env45025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env45024 == env45025) = true)

theorem identity45025 : scanCanonicalize (H12AffineFastState.compose env45025 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound45025 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,1336,65,1344,263,1124,3124,1024,1345,309,32,1060,1299,1336,64,3392,1124,1345,2420,352,1329,256,32,308,513]

theorem envBound45026 : H12AffineFastState.Bounded env45026 := by
  intro p hp
  have h : env45026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45025_45026 : H12AffineEnvironment.transform 11 1345 env45025 = env45026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env45025 == env45026) = true)

theorem identity45026 : scanCanonicalize (H12AffineFastState.compose env45026 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45026 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env45027 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1076,1101,65,1077,114,1124,3124,1024,1076,64,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,65,513]

theorem envBound45027 : H12AffineFastState.Bounded env45027 := by
  intro p hp
  have h : env45027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45026_45027 : H12AffineEnvironment.transform 7 117 env45026 = env45027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45026 == env45027) = true)

theorem identity45027 : scanCanonicalize (H12AffineFastState.compose env45027 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound45027 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env45028 : List Nat := [2,4,8,16,32,64,8,117,80,1024,2048,1076,1101,65,1077,114,1124,3124,1024,1076,64,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,65,81]

theorem envBound45028 : H12AffineFastState.Bounded env45028 := by
  intro p hp
  have h : env45028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45027_45028 : H12AffineEnvironment.transform 8 80 env45027 = env45028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env45027 == env45028) = true)

theorem identity45028 : scanCanonicalize (H12AffineFastState.compose env45028 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45028 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45029 : List Nat := [2,4,8,16,0,64,8,85,80,1024,2048,1044,1101,65,1045,82,1092,3092,1024,1044,64,0,1028,1094,1101,64,3093,1092,1044,2049,21,1092,85,0,65,81]

theorem envBound45029 : H12AffineFastState.Bounded env45029 := by
  intro p hp
  have h : env45029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45028_45029 : H12AffineEnvironment.transform 4 0 env45028 = env45029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45028 == env45029) = true)

theorem identity45029 : scanCanonicalize (H12AffineFastState.compose env45029 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45029 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env45030 : List Nat := [2,4,8,16,0,17,8,4,1,1024,2048,1044,1052,16,1045,3,1045,3092,1024,1044,17,0,1028,1047,1052,17,3093,1045,1044,2049,21,1045,4,0,16,0]

theorem envBound45030 : H12AffineFastState.Bounded env45030 := by
  intro p hp
  have h : env45030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45029_45030 : H12AffineEnvironment.transform 5 17 env45029 = env45030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45029 == env45030) = true)

theorem identity45030 : scanCanonicalize (H12AffineFastState.compose env45030 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45031 : List Nat := [2,4,8,16,0,17,8,4,1,20,2048,0,8,16,1,3,1,2048,20,0,17,0,16,3,8,17,2049,1,0,2049,21,1,4,0,16,0]

theorem envBound45031 : H12AffineFastState.Bounded env45031 := by
  intro p hp
  have h : env45031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45030_45031 : H12AffineEnvironment.transform 9 20 env45030 = env45031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45030 == env45031) = true)

theorem identity45031 : scanCanonicalize (H12AffineFastState.compose env45031 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45032 : List Nat := [2,4,2,16,0,17,2,4,1,20,2048,0,2,16,1,3,1,2048,20,0,17,0,16,3,2,17,2049,1,0,2049,21,1,4,0,16,0]

theorem envBound45032 : H12AffineFastState.Bounded env45032 := by
  intro p hp
  have h : env45032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45031_45032 : H12AffineEnvironment.transform 2 2 env45031 = env45032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45031 == env45032) = true)

theorem identity45032 : scanCanonicalize (H12AffineFastState.compose env45032 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45033 : List Nat := [2,4,2,1,0,0,2,4,1,5,2048,0,2,1,1,3,1,2048,5,0,0,0,1,3,2,0,2049,1,0,2049,4,1,4,0,1,0]

theorem envBound45033 : H12AffineFastState.Bounded env45033 := by
  intro p hp
  have h : env45033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45032_45033 : H12AffineEnvironment.transform 3 1 env45032 = env45033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45032 == env45033) = true)

theorem identity45033 : scanCanonicalize (H12AffineFastState.compose env45033 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45033 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45034 : List Nat := [2,4,2,1,0,0,2,4,1,5,1,0,2,1,1,3,1,1,5,0,0,0,1,3,2,0,0,1,0,0,4,1,4,0,1,0]

theorem envBound45034 : H12AffineFastState.Bounded env45034 := by
  intro p hp
  have h : env45034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45033_45034 : H12AffineEnvironment.transform 10 1 env45033 = env45034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45033 == env45034) = true)

def env45035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98644,8193,64,472175,79130,4096,505115,75102,98678,256,33,46093,513]

theorem envBound45035 : H12AffineFastState.Bounded env45035 := by
  intro p hp
  have h : env45035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45019_45035 : H12AffineEnvironment.transform 6 9 env45019 = env45035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45019 == env45035) = true)

theorem identity45035 : scanCanonicalize (H12AffineFastState.compose env45035 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45035 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,77898,32,73754,73737,8193,64,472175,79130,4096,463942,75102,73771,256,33,5456,513]

theorem envBound45036 : H12AffineFastState.Bounded env45036 := by
  intro p hp
  have h : env45036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45035_45036 : H12AffineEnvironment.transform 14 8541 env45035 = env45036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45035 == env45036) = true)

theorem identity45036 : scanCanonicalize (H12AffineFastState.compose env45036 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45036 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,131072,262144,1024,8540,4160,32,16,3,8193,64,398437,5392,4096,406604,1364,33,256,33,5456,513]

theorem envBound45037 : H12AffineFastState.Bounded env45037 := by
  intro p hp
  have h : env45037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45036_45037 : H12AffineEnvironment.transform 15 8202 env45036 = env45037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45036 == env45037) = true)

theorem identity45037 : scanCanonicalize (H12AffineFastState.compose env45037 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45037 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45038 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,262144,1024,8460,4112,32,16,3,8193,16,398389,5392,4096,406556,1284,33,256,33,5376,513]

theorem envBound45038 : H12AffineFastState.Bounded env45038 := by
  intro p hp
  have h : env45038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45037_45038 : H12AffineEnvironment.transform 5 16 env45037 = env45038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45037 == env45038) = true)

theorem identity45038 : scanCanonicalize (H12AffineFastState.compose env45038 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45038 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45039 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10281,1024,8460,4112,32,16,3,8193,16,146460,5392,4096,138293,1284,33,256,33,5376,513]

theorem envBound45039 : H12AffineFastState.Bounded env45039 := by
  intro p hp
  have h : env45039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45038_45039 : H12AffineEnvironment.transform 17 10281 env45038 = env45039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45038 == env45039) = true)

theorem identity45039 : scanCanonicalize (H12AffineFastState.compose env45039 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45039 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45040 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10281,1024,8460,4112,32,16,3,8193,16,2048,5392,4096,10281,1284,33,256,33,5376,513]

theorem envBound45040 : H12AffineFastState.Bounded env45040 := by
  intro p hp
  have h : env45040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45039_45040 : H12AffineEnvironment.transform 16 13340 env45039 = env45040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env45039 == env45040) = true)

theorem identity45040 : scanCanonicalize (H12AffineFastState.compose env45040 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound45040 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45041 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,5376,1297,1046,4096,3125,1024,1296,4112,32,16,3,1053,16,2048,5392,4096,3125,1284,33,256,33,5376,513]

theorem envBound45041 : H12AffineFastState.Bounded env45041 := by
  intro p hp
  have h : env45041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45040_45041 : H12AffineEnvironment.transform 12 1052 env45040 = env45041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env45040 == env45041) = true)

theorem identity45041 : scanCanonicalize (H12AffineFastState.compose env45041 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45041 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45042 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,4096,1052,5376,1297,1046,4096,1076,1024,1296,4112,32,16,3,1053,16,1,5392,4096,1076,1284,33,256,33,5376,513]

theorem envBound45042 : H12AffineFastState.Bounded env45042 := by
  intro p hp
  have h : env45042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45041_45042 : H12AffineEnvironment.transform 10 1 env45041 = env45042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45041 == env45042) = true)

theorem identity45042 : scanCanonicalize (H12AffineFastState.compose env45042 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound45042 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env45043 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,1280,1052,0,1297,1046,1280,1076,1024,1296,1296,32,16,3,1053,16,1,16,1280,1076,1284,33,256,33,0,513]

theorem envBound45043 : H12AffineFastState.Bounded env45043 := by
  intro p hp
  have h : env45043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45042_45043 : H12AffineEnvironment.transform 11 1280 env45042 = env45043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env45042 == env45043) = true)

theorem identity45043 : scanCanonicalize (H12AffineFastState.compose env45043 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45043 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45044 : List Nat := [2,4,8,16,32,16,9,256,512,273,1,17,269,0,0,263,17,293,273,1,1,32,16,3,268,16,1,16,17,293,21,33,256,33,0,513]

theorem envBound45044 : H12AffineFastState.Bounded env45044 := by
  intro p hp
  have h : env45044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45043_45044 : H12AffineEnvironment.transform 9 273 env45043 = env45044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45043 == env45044) = true)

theorem identity45044 : scanCanonicalize (H12AffineFastState.compose env45044 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound45044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45045 : List Nat := [2,4,8,16,32,16,9,53,512,36,1,17,56,0,0,50,17,16,36,1,1,32,16,3,57,16,1,16,17,16,21,33,53,33,0,513]

theorem envBound45045 : H12AffineFastState.Bounded env45045 := by
  intro p hp
  have h : env45045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45044_45045 : H12AffineEnvironment.transform 7 53 env45044 = env45045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env45044 == env45045) = true)

theorem identity45045 : scanCanonicalize (H12AffineFastState.compose env45045 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound45045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45046 : List Nat := [2,4,8,16,32,16,9,53,8,36,1,17,56,0,0,50,17,16,36,1,1,32,16,3,57,16,1,16,17,16,21,33,53,33,0,9]

theorem envBound45046 : H12AffineFastState.Bounded env45046 := by
  intro p hp
  have h : env45046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45045_45046 : H12AffineEnvironment.transform 8 8 env45045 = env45046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env45045 == env45046) = true)

theorem identity45046 : scanCanonicalize (H12AffineFastState.compose env45046 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45046 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45047 : List Nat := [2,4,3,16,32,16,2,53,3,36,1,17,51,0,0,50,17,16,36,1,1,32,16,3,50,16,1,16,17,16,21,33,53,33,0,2]

theorem envBound45047 : H12AffineFastState.Bounded env45047 := by
  intro p hp
  have h : env45047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45046_45047 : H12AffineEnvironment.transform 2 3 env45046 = env45047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45046 == env45047) = true)

theorem identity45047 : scanCanonicalize (H12AffineFastState.compose env45047 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45047 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45048 : List Nat := [2,4,3,16,16,16,2,5,3,20,1,17,3,0,0,2,17,16,20,1,1,16,16,3,2,16,1,16,17,16,21,17,5,17,0,2]

theorem envBound45048 : H12AffineFastState.Bounded env45048 := by
  intro p hp
  have h : env45048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45047_45048 : H12AffineEnvironment.transform 4 16 env45047 = env45048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45047 == env45048) = true)

def env45049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787060,79130,8466579,8819969,8389956,98679,256,8462395,8492190,8462994]

theorem envBound45049 : H12AffineFastState.Bounded env45049 := by
  intro p hp
  have h : env45049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45017_45049 : H12AffineEnvironment.transform 21 33 env45017 = env45049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env45017 == env45049) = true)

theorem identity45049 : scanCanonicalize (H12AffineFastState.compose env45049 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound45049 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,4160,33,8388608,41431,8328,64,8787060,5529,8392720,8819969,8389956,41460,256,8388792,8434717,8389137]

theorem envBound45050 : H12AffineFastState.Bounded env45050 := by
  intro p hp
  have h : env45050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45049_45050 : H12AffineEnvironment.transform 15 8323 env45049 = env45050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env45049 == env45050) = true)

def env45051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,262144,1024,32769,4160,33,8388608,41431,8328,64,8651060,5529,8392720,8683585,8389956,41460,256,8388792,8434717,8389137]

theorem envBound45051 : H12AffineFastState.Bounded env45051 := by
  intro p hp
  have h : env45051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45050_45051 : H12AffineEnvironment.transform 16 5440 env45050 = env45051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env45050 == env45051) = true)

theorem identity45051 : scanCanonicalize (H12AffineFastState.compose env45051 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297404) := by decide +kernel

theorem selectedBound45051 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,262144,1024,32769,4160,33,297404,41431,8328,64,34952,5529,301484,2557,298232,41460,256,297220,277921,297901]

theorem envBound45052 : H12AffineFastState.Bounded env45052 := by
  intro p hp
  have h : env45052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45051_45052 : H12AffineEnvironment.transform 22 297404 env45051 = env45052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297404 env45051 == env45052) = true)

theorem identity45052 : scanCanonicalize (H12AffineFastState.compose env45052 (packedSelected [1,4,5,7,8,9,16,19,20,21,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45052 : packedSelected [1,4,5,7,8,9,16,19,20,21,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,35189,1024,32769,4160,33,201,41431,8328,64,34952,5529,4313,2557,1421,41460,256,113,46292,728]

theorem envBound45053 : H12AffineFastState.Bounded env45053 := by
  intro p hp
  have h : env45053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45052_45053 : H12AffineEnvironment.transform 17 35189 env45052 = env45053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45052 == env45053) = true)

theorem identity45053 : scanCanonicalize (H12AffineFastState.compose env45053 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound45053 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,136,8323,5440,2557,1024,137,4160,33,201,8543,8328,64,2048,5529,4313,2557,1421,8572,256,113,13404,728]

theorem envBound45054 : H12AffineFastState.Bounded env45054 := by
  intro p hp
  have h : env45054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45053_45054 : H12AffineEnvironment.transform 14 136 env45053 = env45054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env45053 == env45054) = true)

theorem identity45054 : scanCanonicalize (H12AffineFastState.compose env45054 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound45054 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env45055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,136,262,5440,2557,1024,137,4160,33,201,218,269,64,2048,5529,4313,2557,1421,249,256,113,5593,728]

theorem envBound45055 : H12AffineFastState.Bounded env45055 := by
  intro p hp
  have h : env45055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45054_45055 : H12AffineEnvironment.transform 12 389 env45054 = env45055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env45054 == env45055) = true)

theorem identity45055 : scanCanonicalize (H12AffineFastState.compose env45055 (packedSelected [0,1,3,4,5,7,8,9,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound45055 : packedSelected [0,1,3,4,5,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env45056 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,121,5372,136,250,5308,2049,1024,137,4160,33,201,218,241,64,2048,5221,4313,2049,1137,249,252,113,5157,728]

theorem envBound45056 : H12AffineFastState.Bounded env45056 := by
  intro p hp
  have h : env45056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45055_45056 : H12AffineEnvironment.transform 7 252 env45055 = env45056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env45055 == env45056) = true)

theorem identity45056 : scanCanonicalize (H12AffineFastState.compose env45056 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45056 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45057 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,1,115,5173,2049,1024,0,4160,33,64,83,120,64,2048,5221,4176,2049,1137,112,117,113,5157,593]

theorem envBound45057 : H12AffineFastState.Bounded env45057 := by
  intro p hp
  have h : env45057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45056_45057 : H12AffineEnvironment.transform 6 9 env45056 = env45057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45056 == env45057) = true)

theorem identity45057 : scanCanonicalize (H12AffineFastState.compose env45057 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45057 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45058 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,1,35,5173,2049,1024,0,4112,33,16,3,40,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound45058 : H12AffineFastState.Bounded env45058 := by
  intro p hp
  have h : env45058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45057_45058 : H12AffineEnvironment.transform 5 16 env45057 = env45058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45057 == env45058) = true)

def env45059 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,1,35,1029,2049,1024,0,32,33,16,3,40,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound45059 : H12AffineFastState.Bounded env45059 := by
  intro p hp
  have h : env45059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45058_45059 : H12AffineEnvironment.transform 11 48 env45058 = env45059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45058 == env45059) = true)

def env45060 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,1,35,1028,2049,1024,0,33,33,16,3,40,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound45060 : H12AffineFastState.Bounded env45060 := by
  intro p hp
  have h : env45060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45058_45060 : H12AffineEnvironment.transform 11 49 env45058 = env45060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45058 == env45060) = true)

theorem identity45060 : scanCanonicalize (H12AffineFastState.compose env45060 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45061 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,41,33,1,35,49,2049,53,0,33,33,16,3,40,16,2048,49,49,2049,20,32,37,33,33,513]

theorem envBound45061 : H12AffineFastState.Bounded env45061 := by
  intro p hp
  have h : env45061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45060_45061 : H12AffineEnvironment.transform 9 53 env45060 = env45061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45060 == env45061) = true)

theorem identity45061 : scanCanonicalize (H12AffineFastState.compose env45061 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45062 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,0,1,2,16,2049,20,0,0,0,16,3,9,16,2048,16,16,2049,20,1,4,0,0,513]

theorem envBound45062 : H12AffineFastState.Bounded env45062 := by
  intro p hp
  have h : env45062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45061_45062 : H12AffineEnvironment.transform 4 1 env45061 = env45062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45061 == env45062) = true)

def leafEnv45062 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,0,1,2,16,2049,20,0,0,0,16,3,20,9,1,16,2048,16,16,2049,20,1,4,0,4,3,0,513,1,0,0]

def active45062 : List Nat := [0,1,2,3,8,10]

def tree45062 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45062 : H12WitnessSearch.Good tree45062 := H12GlobalWitnessIndex.good

theorem leafIdentity45062 : H12AffineFastState.composeSystem env45062 rootObs = leafEnv45062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45062 rootObs == leafEnv45062) = true)

theorem terminalChecked45062 : H12PackedTerminal.terminalCheckFast leafEnv45062 active45062 tree45062 = true := by decide +kernel

def env45063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,262144,1024,32769,4160,33,8388608,41431,8328,64,8651061,5529,8392720,8683584,8389956,41460,256,8388792,8434717,8389137]

theorem envBound45063 : H12AffineFastState.Bounded env45063 := by
  intro p hp
  have h : env45063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45050_45063 : H12AffineEnvironment.transform 16 5441 env45050 = env45063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env45050 == env45063) = true)

theorem identity45063 : scanCanonicalize (H12AffineFastState.compose env45063 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297269) := by decide +kernel

theorem selectedBound45063 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,262144,1024,32769,4160,33,297269,41431,8328,64,34816,5529,301349,2421,298097,41460,256,297357,277800,297764]

theorem envBound45064 : H12AffineFastState.Bounded env45064 := by
  intro p hp
  have h : env45064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45063_45064 : H12AffineEnvironment.transform 22 297269 env45063 = env45064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297269 env45063 == env45064) = true)

theorem identity45064 : scanCanonicalize (H12AffineFastState.compose env45064 (packedSelected [0,1,3,4,7,11,16,19,20,22,24,26,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound45064 : packedSelected [0,1,3,4,7,11,16,19,20,22,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env45065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,10400,1024,32769,4160,33,41365,41431,8328,64,34816,5529,45445,2421,42193,41460,256,41261,5512,41860]

theorem envBound45065 : H12AffineFastState.Bounded env45065 := by
  intro p hp
  have h : env45065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45064_45065 : H12AffineEnvironment.transform 17 10400 env45064 = env45065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45064 == env45065) = true)

theorem identity45065 : scanCanonicalize (H12AffineFastState.compose env45065 (packedSelected [3,10,16,19,20,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound45065 : packedSelected [3,10,16,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env45066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,137,8323,5441,10400,1024,136,4160,33,8476,8542,8328,64,2185,5529,12556,2421,9304,8573,256,8612,5512,8973]

theorem envBound45066 : H12AffineFastState.Bounded env45066 := by
  intro p hp
  have h : env45066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45065_45066 : H12AffineEnvironment.transform 14 137 env45065 = env45066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env45065 == env45066) = true)

theorem identity45066 : scanCanonicalize (H12AffineFastState.compose env45066 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound45066 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env45067 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,5292,137,8323,5357,10400,1024,136,4160,33,8368,8434,8328,64,2185,5173,12448,2265,9304,8401,172,8200,5156,8865]

theorem envBound45067 : H12AffineFastState.Bounded env45067 := by
  intro p hp
  have h : env45067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45066_45067 : H12AffineEnvironment.transform 7 172 env45066 = env45067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env45066 == env45067) = true)

theorem identity45067 : scanCanonicalize (H12AffineFastState.compose env45067 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45067 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45068 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,0,8202,5220,10281,1024,1,4160,33,8249,8315,8193,64,2048,5173,12329,2128,9304,8280,37,8200,5156,8744]

theorem envBound45068 : H12AffineFastState.Bounded env45068 := by
  intro p hp
  have h : env45068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45067_45068 : H12AffineEnvironment.transform 6 9 env45067 = env45068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45067 == env45068) = true)

theorem identity45068 : scanCanonicalize (H12AffineFastState.compose env45068 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45068 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45069 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,8192,4112,0,8202,4177,10281,53,1,4160,33,8249,8315,8193,64,2048,4096,12329,2128,8301,8280,37,8200,4113,8744]

theorem envBound45069 : H12AffineFastState.Bounded env45069 := by
  intro p hp
  have h : env45069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45068_45069 : H12AffineEnvironment.transform 9 53 env45068 = env45069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45068 == env45069) = true)

theorem identity45069 : scanCanonicalize (H12AffineFastState.compose env45069 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2632) := by decide +kernel

theorem selectedBound45069 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env45070 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,2632,4112,0,2626,4177,609,53,1,4160,33,2673,2611,2633,64,2048,4096,6753,2128,2597,2576,37,2624,4113,2144]

theorem envBound45070 : H12AffineFastState.Bounded env45070 := by
  intro p hp
  have h : env45070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45069_45070 : H12AffineEnvironment.transform 12 2632 env45069 = env45070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2632 env45069 == env45070) = true)

theorem identity45070 : scanCanonicalize (H12AffineFastState.compose env45070 (packedSelected [2,14] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound45070 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env45071 : List Nat := [2,4,8,16,32,64,9,37,512,53,529,4096,89,4112,0,83,4177,609,53,1,4160,33,96,34,88,64,529,4096,4208,577,52,1,37,81,4113,625]

theorem envBound45071 : H12AffineFastState.Bounded env45071 := by
  intro p hp
  have h : env45071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45070_45071 : H12AffineEnvironment.transform 10 529 env45070 = env45071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env45070 == env45071) = true)

theorem identity45071 : scanCanonicalize (H12AffineFastState.compose env45071 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45071 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45072 : List Nat := [2,4,8,16,0,64,9,5,512,21,529,4096,89,4112,0,83,4177,577,21,1,4160,1,64,2,88,64,529,4096,4176,577,20,1,5,81,4113,593]

theorem envBound45072 : H12AffineFastState.Bounded env45072 := by
  intro p hp
  have h : env45072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45071_45072 : H12AffineEnvironment.transform 4 0 env45071 = env45072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45071 == env45072) = true)

theorem identity45072 : scanCanonicalize (H12AffineFastState.compose env45072 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 20) := by decide +kernel

theorem selectedBound45072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45073 : List Nat := [2,4,8,16,0,20,9,5,512,21,529,4096,13,4112,0,7,4101,533,21,1,4116,1,20,2,12,20,529,4096,4100,533,20,1,5,5,4113,517]

theorem envBound45073 : H12AffineFastState.Bounded env45073 := by
  intro p hp
  have h : env45073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45072_45073 : H12AffineEnvironment.transform 5 20 env45072 = env45073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env45072 == env45073) = true)

theorem identity45073 : scanCanonicalize (H12AffineFastState.compose env45073 (packedSelected [1,4] rootPS)) = affineNative (2^(11+1) ^^^ 530) := by decide +kernel

theorem selectedBound45073 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env45074 : List Nat := [2,4,8,16,0,20,9,5,512,21,529,530,13,514,0,7,535,533,21,1,518,1,20,2,12,20,529,530,534,533,20,1,5,5,515,517]

theorem envBound45074 : H12AffineFastState.Bounded env45074 := by
  intro p hp
  have h : env45074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45073_45074 : H12AffineEnvironment.transform 11 530 env45073 = env45074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 530 env45073 == env45074) = true)

theorem identity45074 : scanCanonicalize (H12AffineFastState.compose env45074 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45074 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env45075 : List Nat := [2,4,8,11,0,15,9,5,512,14,522,521,13,514,0,7,524,526,14,1,518,1,15,2,12,15,522,521,525,526,15,1,5,5,515,517]

theorem envBound45075 : H12AffineFastState.Bounded env45075 := by
  intro p hp
  have h : env45075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45074_45075 : H12AffineEnvironment.transform 3 11 env45074 = env45075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45074 == env45075) = true)

def env45076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981333,79130,8466579,8819968,8389957,4292951,256,8462394,8492190,8462995]

theorem envBound45076 : H12AffineFastState.Bounded env45076 := by
  intro p hp
  have h : env45076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45016_45076 : H12AffineEnvironment.transform 13 5377 env45016 = env45076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45016 == env45076) = true)

def env45077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787061,79130,8466579,8819968,8389957,98679,256,8462394,8492190,8462995]

theorem envBound45077 : H12AffineFastState.Bounded env45077 := by
  intro p hp
  have h : env45077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45076_45077 : H12AffineEnvironment.transform 21 32 env45076 = env45077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env45076 == env45077) = true)

theorem identity45077 : scanCanonicalize (H12AffineFastState.compose env45077 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound45077 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,98767,98645,8328,64,497082,79130,45404,464079,99466,98679,256,41461,5457,41820]

theorem envBound45078 : H12AffineFastState.Bounded env45078 := by
  intro p hp
  have h : env45078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45077_45078 : H12AffineEnvironment.transform 22 98767 env45077 = env45078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env45077 == env45078) = true)

def env45079 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77970,32,98719,98565,8328,16,497082,79130,45324,464031,99466,98599,256,41381,5377,41740]

theorem envBound45079 : H12AffineFastState.Bounded env45079 := by
  intro p hp
  have h : env45079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45078_45079 : H12AffineEnvironment.transform 5 16 env45078 = env45079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45078 == env45079) = true)

theorem identity45079 : scanCanonicalize (H12AffineFastState.compose env45079 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound45079 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env45080 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,146744,1024,32769,77970,32,98719,98565,8328,16,108674,79130,45324,76199,99466,98599,256,41381,5377,41740]

theorem envBound45080 : H12AffineFastState.Bounded env45080 := by
  intro p hp
  have h : env45080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45079_45080 : H12AffineEnvironment.transform 17 146744 env45079 = env45080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env45079 == env45080) = true)

theorem identity45080 : scanCanonicalize (H12AffineFastState.compose env45080 (packedSelected [3,10,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound45080 : packedSelected [3,10,21,24,26] rootPS < 2^1333 := by decide +kernel

def env45081 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,33167,131072,146744,1024,32769,45341,32,16,138,8328,16,10509,46229,45324,43048,1285,168,256,41381,5377,41740]

theorem envBound45081 : H12AffineFastState.Bounded env45081 := by
  intro p hp
  have h : env45081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45080_45081 : H12AffineEnvironment.transform 15 33167 env45080 = env45081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env45080 == env45081) = true)

theorem identity45081 : scanCanonicalize (H12AffineFastState.compose env45081 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound45081 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env45082 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,33167,5529,10401,1024,32769,45341,32,16,138,8328,16,10509,46229,45324,43048,1285,168,256,41381,5377,41740]

theorem envBound45082 : H12AffineFastState.Bounded env45082 := by
  intro p hp
  have h : env45082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45081_45082 : H12AffineEnvironment.transform 16 5529 env45081 = env45082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env45081 == env45082) = true)

theorem identity45082 : scanCanonicalize (H12AffineFastState.compose env45082 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound45082 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env45083 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,8202,5529,10401,1024,8580,4248,32,16,138,8328,16,10509,5392,4233,2477,1285,168,256,32,5377,649]

theorem envBound45083 : H12AffineFastState.Bounded env45083 := by
  intro p hp
  have h : env45083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45082_45083 : H12AffineEnvironment.transform 14 8581 env45082 = env45083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env45082 == env45083) = true)

theorem identity45083 : scanCanonicalize (H12AffineFastState.compose env45083 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45083 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env45084 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4405,8581,8202,4525,10401,52,8580,4248,32,16,138,8328,16,10509,4388,4233,2477,305,168,256,32,4405,649]

theorem envBound45084 : H12AffineFastState.Bounded env45084 := by
  intro p hp
  have h : env45084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45083_45084 : H12AffineEnvironment.transform 9 52 env45083 = env45084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45083 == env45084) = true)

theorem identity45084 : scanCanonicalize (H12AffineFastState.compose env45084 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound45084 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45085 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,129,4405,260,139,4525,2080,52,261,4248,32,16,138,9,16,2444,4388,4233,2477,305,168,256,32,4405,649]

theorem envBound45085 : H12AffineFastState.Bounded env45085 := by
  intro p hp
  have h : env45085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45084_45085 : H12AffineEnvironment.transform 12 129 env45084 = env45085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env45084 == env45085) = true)

theorem identity45085 : scanCanonicalize (H12AffineFastState.compose env45085 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound45085 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env45086 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,2201,129,2476,260,139,2356,2080,52,261,2049,32,16,138,9,16,2444,2493,2064,2477,305,168,256,32,2476,649]

theorem envBound45086 : H12AffineFastState.Bounded env45086 := by
  intro p hp
  have h : env45086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45085_45086 : H12AffineEnvironment.transform 11 2201 env45085 = env45086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env45085 == env45086) = true)

theorem identity45086 : scanCanonicalize (H12AffineFastState.compose env45086 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound45086 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env45087 : List Nat := [2,4,8,16,32,16,128,173,512,52,2048,2201,129,2049,169,139,2201,2080,52,168,2049,32,16,138,9,16,2081,2064,2064,2048,156,168,173,32,2049,649]

theorem envBound45087 : H12AffineFastState.Bounded env45087 := by
  intro p hp
  have h : env45087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45086_45087 : H12AffineEnvironment.transform 7 173 env45086 = env45087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env45086 == env45087) = true)

theorem identity45087 : scanCanonicalize (H12AffineFastState.compose env45087 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45087 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45088 : List Nat := [2,4,8,16,32,16,128,173,512,52,0,153,129,1,169,139,153,32,52,168,1,32,16,138,9,16,33,16,16,0,156,168,173,32,1,649]

theorem envBound45088 : H12AffineFastState.Bounded env45088 := by
  intro p hp
  have h : env45088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45087_45088 : H12AffineEnvironment.transform 10 0 env45087 = env45088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45087 == env45088) = true)

theorem identity45088 : scanCanonicalize (H12AffineFastState.compose env45088 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45088 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45089 : List Nat := [2,4,8,16,32,16,128,173,1,52,0,153,129,1,169,139,153,32,52,168,1,32,16,138,9,16,33,16,16,0,156,168,173,32,1,136]

theorem envBound45089 : H12AffineFastState.Bounded env45089 := by
  intro p hp
  have h : env45089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45088_45089 : H12AffineEnvironment.transform 8 1 env45088 = env45089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45088 == env45089) = true)

theorem identity45089 : scanCanonicalize (H12AffineFastState.compose env45089 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45089 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45090 : List Nat := [2,4,8,1,32,1,128,173,1,37,0,136,129,1,169,139,136,32,37,168,1,32,1,138,9,1,33,1,1,0,141,168,173,32,1,136]

theorem envBound45090 : H12AffineFastState.Bounded env45090 := by
  intro p hp
  have h : env45090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45089_45090 : H12AffineEnvironment.transform 3 1 env45089 = env45090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45089 == env45090) = true)

theorem identity45090 : scanCanonicalize (H12AffineFastState.compose env45090 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45090 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45091 : List Nat := [2,4,8,1,1,1,128,140,1,4,0,136,129,1,136,139,136,1,4,137,1,1,1,138,9,1,0,1,1,0,141,137,140,1,1,136]

theorem envBound45091 : H12AffineFastState.Bounded env45091 := by
  intro p hp
  have h : env45091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45090_45091 : H12AffineEnvironment.transform 4 1 env45090 = env45091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45090 == env45091) = true)

theorem identity45091 : scanCanonicalize (H12AffineFastState.compose env45091 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45091 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env45092 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,0,9,1,0,3,0,1,4,1,1,1,1,2,9,1,0,1,1,0,5,1,4,1,1,0]

theorem envBound45092 : H12AffineFastState.Bounded env45092 := by
  intro p hp
  have h : env45092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45091_45092 : H12AffineEnvironment.transform 6 8 env45091 = env45092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45091 == env45092) = true)

def env45093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77971,32,98718,98564,8328,17,497082,79130,45325,464030,99466,98598,256,41380,5376,41741]

theorem envBound45093 : H12AffineFastState.Bounded env45093 := by
  intro p hp
  have h : env45093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45078_45093 : H12AffineEnvironment.transform 5 17 env45078 = env45093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45078 == env45093) = true)

theorem identity45093 : scanCanonicalize (H12AffineFastState.compose env45093 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 204083) := by decide +kernel

theorem selectedBound45093 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env45094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,204083,1024,32769,77971,32,98718,98564,8328,17,34953,79130,45325,2477,99466,98598,256,41380,5376,41741]

theorem envBound45094 : H12AffineFastState.Bounded env45094 := by
  intro p hp
  have h : env45094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45093_45094 : H12AffineEnvironment.transform 17 204083 env45093 = env45094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204083 env45093 == env45094) = true)

def env45095 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,204083,1024,32769,77851,32,98582,98564,8192,17,34817,79130,45325,2341,99330,98598,256,41260,5376,41741]

theorem envBound45095 : H12AffineFastState.Bounded env45095 := by
  intro p hp
  have h : env45095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45094_45095 : H12AffineEnvironment.transform 6 8 env45094 = env45095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45094 == env45095) = true)

theorem identity45095 : scanCanonicalize (H12AffineFastState.compose env45095 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound45095 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env45096 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,67618,1024,32769,77851,32,98582,98564,8192,17,34817,79130,45325,2341,99330,98598,256,41260,5376,41741]

theorem envBound45096 : H12AffineFastState.Bounded env45096 := by
  intro p hp
  have h : env45096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45095_45096 : H12AffineEnvironment.transform 16 5393 env45095 = env45096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env45095 == env45096) = true)

theorem identity45096 : scanCanonicalize (H12AffineFastState.compose env45096 (packedSelected [0,4,6,7,9,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound45096 : packedSelected [0,4,6,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env45097 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,32802,5393,34816,1024,32769,45113,32,308,294,8192,17,34817,46392,45325,2341,1056,260,256,41260,5376,41741]

theorem envBound45097 : H12AffineFastState.Bounded env45097 := by
  intro p hp
  have h : env45097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45096_45097 : H12AffineEnvironment.transform 15 32802 env45096 = env45097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env45096 == env45097) = true)

theorem identity45097 : scanCanonicalize (H12AffineFastState.compose env45097 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45097 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45098 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5156,32768,32802,5172,34816,1024,32769,45113,32,17,3,8192,17,34817,46109,45096,2048,1056,33,37,40969,5157,41512]

theorem envBound45098 : H12AffineFastState.Bounded env45098 := by
  intro p hp
  have h : env45098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45097_45098 : H12AffineEnvironment.transform 7 37 env45097 = env45098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45097 == env45098) = true)

theorem identity45098 : scanCanonicalize (H12AffineFastState.compose env45098 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound45098 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45099 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5156,8232,8202,5172,10280,1024,8233,4113,32,17,3,8192,17,10281,5173,4096,2048,1056,33,37,33,5157,512]

theorem envBound45099 : H12AffineFastState.Bounded env45099 := by
  intro p hp
  have h : env45099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45098_45099 : H12AffineEnvironment.transform 14 8232 env45098 = env45099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env45098 == env45099) = true)

theorem identity45099 : scanCanonicalize (H12AffineFastState.compose env45099 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound45099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45100 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5156,33,3,5172,2081,1024,32,4113,32,17,3,9,17,2080,5173,4096,2048,1056,33,37,33,5157,512]

theorem envBound45100 : H12AffineFastState.Bounded env45100 := by
  intro p hp
  have h : env45100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45099_45100 : H12AffineEnvironment.transform 12 9 env45099 = env45100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env45099 == env45100) = true)

def env45101 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,204083,1024,32769,77850,32,98583,98564,8193,17,34816,79130,45325,2340,99331,98598,256,41261,5376,41741]

theorem envBound45101 : H12AffineFastState.Bounded env45101 := by
  intro p hp
  have h : env45101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45094_45101 : H12AffineEnvironment.transform 6 9 env45094 = env45101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45094 == env45101) = true)

theorem identity45101 : scanCanonicalize (H12AffineFastState.compose env45101 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound45101 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env45102 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,103447,35108,1024,32769,77850,32,98583,98564,8193,17,34816,79130,45325,2340,99331,98598,256,41261,5376,41741]

theorem envBound45102 : H12AffineFastState.Bounded env45102 := by
  intro p hp
  have h : env45102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45101_45102 : H12AffineEnvironment.transform 16 103447 env45101 = env45102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env45101 == env45102) = true)

theorem identity45102 : scanCanonicalize (H12AffineFastState.compose env45102 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45102 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env45103 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,32768,65536,103447,35108,1024,32769,69911,32,98583,98564,268,17,34816,70679,36864,2340,99331,98598,256,32800,5376,33280]

theorem envBound45103 : H12AffineFastState.Bounded env45103 := by
  intro p hp
  have h : env45103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45102_45103 : H12AffineEnvironment.transform 12 269 env45102 = env45103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45102 == env45103) = true)

theorem identity45103 : scanCanonicalize (H12AffineFastState.compose env45103 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound45103 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env45104 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,65536,70679,2340,1024,1,69911,32,65815,65796,268,17,2048,70679,4096,2340,66563,65830,256,32,5376,512]

theorem envBound45104 : H12AffineFastState.Bounded env45104 := by
  intro p hp
  have h : env45104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45103_45104 : H12AffineEnvironment.transform 14 0 env45103 = env45104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env45103 == env45104) = true)

theorem identity45104 : scanCanonicalize (H12AffineFastState.compose env45104 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45104 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45105 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5377,0,65536,70679,2308,1024,1,69911,0,65815,65796,268,17,2048,70679,4096,2308,66563,65798,256,0,5376,512]

theorem envBound45105 : H12AffineFastState.Bounded env45105 := by
  intro p hp
  have h : env45105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45104_45105 : H12AffineEnvironment.transform 4 0 env45104 = env45105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45104 == env45105) = true)

theorem identity45105 : scanCanonicalize (H12AffineFastState.compose env45105 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45105 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env45106 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,269,4373,0,65536,69635,2308,20,1,69911,0,65815,65796,268,17,2048,69635,4096,2308,65559,65798,256,0,4372,512]

theorem envBound45106 : H12AffineFastState.Bounded env45106 := by
  intro p hp
  have h : env45106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45105_45106 : H12AffineEnvironment.transform 9 20 env45105 = env45106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45105 == env45106) = true)

theorem identity45106 : scanCanonicalize (H12AffineFastState.compose env45106 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound45106 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45107 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,269,4373,0,3,4096,2308,20,1,4372,0,276,263,268,17,2048,4096,4096,2308,20,261,256,0,4372,512]

theorem envBound45107 : H12AffineFastState.Bounded env45107 := by
  intro p hp
  have h : env45107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45106_45107 : H12AffineEnvironment.transform 15 3 env45106 = env45107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env45106 == env45107) = true)

theorem identity45107 : scanCanonicalize (H12AffineFastState.compose env45107 (packedSelected [1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound45107 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env45108 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,2577,269,2820,0,3,2577,2308,20,1,2821,0,276,263,268,17,2048,2577,2577,2308,20,261,256,0,2821,512]

theorem envBound45108 : H12AffineFastState.Bounded env45108 := by
  intro p hp
  have h : env45108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45107_45108 : H12AffineEnvironment.transform 11 2577 env45107 = env45108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env45107 == env45108) = true)

theorem identity45108 : scanCanonicalize (H12AffineFastState.compose env45108 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45108 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45109 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,2577,9,2560,0,3,2577,2048,20,1,2561,0,16,3,8,17,2048,2577,2577,2048,20,1,4,0,2561,512]

theorem envBound45109 : H12AffineFastState.Bounded env45109 := by
  intro p hp
  have h : env45109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45108_45109 : H12AffineEnvironment.transform 7 4 env45108 = env45109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45108 == env45109) = true)

theorem identity45109 : scanCanonicalize (H12AffineFastState.compose env45109 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound45109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45110 : List Nat := [2,4,8,16,0,17,9,4,21,20,2048,2052,9,2069,0,3,2052,2048,20,1,2068,0,16,3,8,17,2048,2052,2052,2048,20,1,4,0,2068,21]

theorem envBound45110 : H12AffineFastState.Bounded env45110 := by
  intro p hp
  have h : env45110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45109_45110 : H12AffineEnvironment.transform 8 21 env45109 = env45110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env45109 == env45110) = true)

theorem identity45110 : scanCanonicalize (H12AffineFastState.compose env45110 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound45110 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45111 : List Nat := [2,4,8,4,0,5,9,4,1,0,2048,2052,9,2049,0,3,2052,2048,0,1,2048,0,4,3,8,5,2048,2052,2052,2048,0,1,4,0,2048,1]

theorem envBound45111 : H12AffineFastState.Bounded env45111 := by
  intro p hp
  have h : env45111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45110_45111 : H12AffineEnvironment.transform 3 4 env45110 = env45111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env45110 == env45111) = true)

def leafEnv45111 : List Nat := [2,4,8,4,0,5,9,4,1,0,2048,2052,9,2049,0,3,2052,2048,0,1,2048,0,4,3,0,8,1,5,2048,2052,2052,2048,0,1,4,0,4,2,2048,1,1,2049,0]

def active45111 : List Nat := [0,1,2,10]

def tree45111 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45111 : H12WitnessSearch.Good tree45111 := H12GlobalWitnessIndex.good

theorem leafIdentity45111 : H12AffineFastState.composeSystem env45111 rootObs = leafEnv45111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45111 rootObs == leafEnv45111) = true)

theorem terminalChecked45111 : H12PackedTerminal.terminalCheckFast leafEnv45111 active45111 tree45111 = true := by decide +kernel

def env45112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787060,79130,8466579,8819968,8389957,98678,256,8462394,8492190,8462995]

theorem envBound45112 : H12AffineFastState.Bounded env45112 := by
  intro p hp
  have h : env45112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45076_45112 : H12AffineEnvironment.transform 21 33 env45076 = env45112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env45076 == env45112) = true)

theorem identity45112 : scanCanonicalize (H12AffineFastState.compose env45112 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound45112 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,45341,33,8388608,138,8328,64,8787060,46277,8433996,8819968,8389957,169,256,8430053,8394049,8430412]

theorem envBound45113 : H12AffineFastState.Bounded env45113 := by
  intro p hp
  have h : env45113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45112_45113 : H12AffineEnvironment.transform 15 33247 env45112 = env45113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env45112 == env45113) = true)

theorem identity45113 : scanCanonicalize (H12AffineFastState.compose env45113 (packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound45113 : packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env45114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,10401,1024,32769,45341,33,8388608,138,8328,64,8535253,46277,8433996,8568225,8389957,169,256,8430053,8394049,8430412]

theorem envBound45114 : H12AffineFastState.Bounded env45114 := by
  intro p hp
  have h : env45114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45113_45114 : H12AffineEnvironment.transform 17 10401 env45113 = env45114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45113 == env45114) = true)

theorem identity45114 : scanCanonicalize (H12AffineFastState.compose env45114 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound45114 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,10401,1024,32769,45341,33,41293,138,8328,64,171416,46277,4097,138476,41992,169,256,168,46092,513]

theorem envBound45115 : H12AffineFastState.Bounded env45115 := by
  intro p hp
  have h : env45115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45114_45115 : H12AffineEnvironment.transform 22 41293 env45114 = env45115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env45114 == env45115) = true)

theorem identity45115 : scanCanonicalize (H12AffineFastState.compose env45115 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound45115 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env45116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,13461,10401,1024,32769,45341,33,41293,138,8328,64,43277,46277,4097,10361,41992,169,256,168,46092,513]

theorem envBound45116 : H12AffineFastState.Bounded env45116 := by
  intro p hp
  have h : env45116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45115_45116 : H12AffineEnvironment.transform 16 13461 env45115 = env45116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env45115 == env45116) = true)

theorem identity45116 : scanCanonicalize (H12AffineFastState.compose env45116 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound45116 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env45117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,217,262,13461,10401,1024,216,12740,33,8596,138,8328,64,10708,13340,4097,10361,9425,169,256,168,13525,513]

theorem envBound45117 : H12AffineFastState.Bounded env45117 := by
  intro p hp
  have h : env45117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45116_45117 : H12AffineEnvironment.transform 14 217 env45116 = env45117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env45116 == env45117) = true)

end H12CloudChart1