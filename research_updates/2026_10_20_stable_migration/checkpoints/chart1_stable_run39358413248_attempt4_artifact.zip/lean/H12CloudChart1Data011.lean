import H12CloudChart1Data010

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env2690 : List Nat := [2,4,8,12,13,0,4,8,6,8,1,0,4,0,13,2,12,13,8,13,12,12,13,15,8,0,0,1,12,12,8,0,8,0,1,6]

theorem envBound2690 : H12AffineFastState.Bounded env2690 := by
  intro p hp
  have h : env2690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2689_2690 : H12AffineEnvironment.transform 3 12 env2689 = env2690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2689 == env2690) = true)

def leafEnv2690 : List Nat := [2,4,8,12,13,0,4,8,6,8,1,0,4,0,13,2,12,13,8,13,12,12,13,15,9,8,1,0,0,1,12,12,8,0,8,0,5,15,1,6,1,13,0]

def active2690 : List Nat := [0,1,2]

def tree2690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2690 : H12WitnessSearch.Good tree2690 := H12GlobalWitnessIndex.good

theorem leafIdentity2690 : H12AffineFastState.composeSystem env2690 rootObs = leafEnv2690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2690 rootObs == leafEnv2690) = true)

theorem terminalChecked2690 : H12PackedTerminal.terminalCheckFast leafEnv2690 active2690 tree2690 = true := by decide +kernel

def env2691 : List Nat := [2,4,8,16,17,1,24,21,6,21,1,1,5,28,12,31,13,17,21,12,16,16,17,19,21,1,0,29,16,16,21,0,21,0,29,6]

theorem envBound2691 : H12AffineFastState.Bounded env2691 := by
  intro p hp
  have h : env2691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2688_2691 : H12AffineEnvironment.transform 5 1 env2688 = env2691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2688 == env2691) = true)

def leafEnv2691 : List Nat := [2,4,8,16,17,1,24,21,6,21,1,1,5,28,12,31,13,17,21,12,16,16,17,19,20,21,1,1,0,29,16,16,21,0,21,0,5,14,29,6,1,17,0]

def active2691 : List Nat := [0,1,2,3]

def tree2691 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2691 : H12WitnessSearch.Good tree2691 := H12GlobalWitnessIndex.good

theorem leafIdentity2691 : H12AffineFastState.composeSystem env2691 rootObs = leafEnv2691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2691 rootObs == leafEnv2691) = true)

theorem terminalChecked2691 : H12PackedTerminal.terminalCheckFast leafEnv2691 active2691 tree2691 = true := by decide +kernel

def env2692 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2080,74882,8201,74950,73891,184,73737,8328,73835,75906,2586,74862,2080,74882,0,73855,0,76441,512]

theorem envBound2692 : H12AffineFastState.Bounded env2692 := by
  intro p hp
  have h : env2692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2664_2692 : H12AffineEnvironment.transform 16 76385 env2664 = env2692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2664 == env2692) = true)

theorem identity2692 : scanCanonicalize (H12AffineFastState.compose env2692 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 224) := by decide +kernel

theorem selectedBound2692 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2693 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,224,2587,233,65536,68225,2080,66658,233,66598,65603,184,65769,104,65675,67682,2586,66702,2080,66658,0,65695,0,68217,512]

theorem envBound2693 : H12AffineFastState.Bounded env2693 := by
  intro p hp
  have h : env2693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2692_2693 : H12AffineEnvironment.transform 12 224 env2692 = env2693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env2692 == env2693) = true)

def env2694 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205376,74882,8201,74951,73891,184,73737,8328,73835,131810,2587,134671,2080,74882,0,73855,0,131320,512]

theorem envBound2694 : H12AffineFastState.Bounded env2694 := by
  intro p hp
  have h : env2694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2663_2694 : H12AffineEnvironment.transform 11 1045 env2663 = env2694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env2663 == env2694) = true)

def env2695 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2080,74882,8201,74951,73891,184,73737,8328,73835,75906,2587,74863,2080,74882,0,73855,0,76440,512]

theorem envBound2695 : H12AffineFastState.Bounded env2695 := by
  intro p hp
  have h : env2695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2694_2695 : H12AffineEnvironment.transform 16 76384 env2694 = env2695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2694 == env2695) = true)

theorem identity2695 : scanCanonicalize (H12AffineFastState.compose env2695 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound2695 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2696 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,98,10754,2080,9440,8201,9381,8385,184,8299,8328,8201,10464,2587,9229,2080,9440,0,8221,0,11002,512]

theorem envBound2696 : H12AffineFastState.Bounded env2696 := by
  intro p hp
  have h : env2696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2695_2696 : H12AffineEnvironment.transform 15 98 env2695 = env2696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env2695 == env2696) = true)

def env2697 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2081,74882,8201,74951,73891,184,73737,8328,73835,75907,2587,74862,2080,74882,0,73855,0,76441,512]

theorem envBound2697 : H12AffineFastState.Bounded env2697 := by
  intro p hp
  have h : env2697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2694_2697 : H12AffineEnvironment.transform 16 76385 env2694 = env2697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2694 == env2697) = true)

theorem identity2697 : scanCanonicalize (H12AffineFastState.compose env2697 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2697 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2698 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2586,3614,65536,66678,2081,68245,3614,68304,69300,184,69150,3743,69244,67220,2587,68217,2080,68245,0,69224,0,66702,512]

theorem envBound2698 : H12AffineFastState.Bounded env2698 := by
  intro p hp
  have h : env2698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2697_2698 : H12AffineEnvironment.transform 12 3607 env2697 = env2698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2697 == env2698) = true)

theorem identity2698 : scanCanonicalize (H12AffineFastState.compose env2698 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2698 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2699 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2586,3614,3733,2787,2081,1024,3614,1093,33,184,139,3743,233,2049,2587,1260,2080,1024,0,253,0,2587,512]

theorem envBound2699 : H12AffineFastState.Bounded env2699 := by
  intro p hp
  have h : env2699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2698_2699 : H12AffineEnvironment.transform 15 3733 env2698 = env2699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2698 == env2699) = true)

theorem identity2699 : scanCanonicalize (H12AffineFastState.compose env2699 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound2699 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2700 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2627,2586,2634,2753,2787,2081,84,2634,17,33,184,139,2763,233,2049,2587,184,2080,84,0,253,0,2587,512]

theorem envBound2700 : H12AffineFastState.Bounded env2700 := by
  intro p hp
  have h : env2700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2699_2700 : H12AffineEnvironment.transform 9 84 env2699 = env2700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env2699 == env2700) = true)

theorem identity2700 : scanCanonicalize (H12AffineFastState.compose env2700 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2700 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2701 : List Nat := [2,4,8,16,32,64,41,84,512,84,2048,65,2627,2586,2634,2664,2634,2081,84,2634,17,33,17,34,2658,64,2049,2587,17,2080,84,0,84,0,2587,512]

theorem envBound2701 : H12AffineFastState.Bounded env2701 := by
  intro p hp
  have h : env2701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2700_2701 : H12AffineEnvironment.transform 6 41 env2700 = env2701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2700 == env2701) = true)

def env2702 : List Nat := [2,4,8,16,16,64,25,84,512,84,2048,65,2627,2586,2634,2648,2634,2065,84,2634,17,17,17,18,2642,64,2049,2587,17,2064,84,0,84,0,2587,512]

theorem envBound2702 : H12AffineFastState.Bounded env2702 := by
  intro p hp
  have h : env2702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2701_2702 : H12AffineEnvironment.transform 4 16 env2701 = env2702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2701 == env2702) = true)

def env2703 : List Nat := [2,4,8,16,16,64,25,84,512,84,0,65,579,538,586,600,586,17,84,586,17,17,17,18,594,64,1,539,17,16,84,0,84,0,539,512]

theorem envBound2703 : H12AffineFastState.Bounded env2703 := by
  intro p hp
  have h : env2703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2702_2703 : H12AffineEnvironment.transform 10 0 env2702 = env2703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2702 == env2703) = true)

theorem identity2703 : scanCanonicalize (H12AffineFastState.compose env2703 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound2703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2704 : List Nat := [2,4,8,16,16,64,25,84,86,84,0,65,21,76,28,14,28,17,84,28,17,17,17,18,4,64,1,77,17,16,84,0,84,0,77,86]

theorem envBound2704 : H12AffineFastState.Bounded env2704 := by
  intro p hp
  have h : env2704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2703_2704 : H12AffineEnvironment.transform 8 86 env2703 = env2704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env2703 == env2704) = true)

def env2705 : List Nat := [2,4,8,16,16,0,25,20,22,20,0,1,21,12,28,14,28,17,20,28,17,17,17,18,4,0,1,13,17,16,20,0,20,0,13,22]

theorem envBound2705 : H12AffineFastState.Bounded env2705 := by
  intro p hp
  have h : env2705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2704_2705 : H12AffineEnvironment.transform 5 0 env2704 = env2705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2704 == env2705) = true)

theorem identity2705 : scanCanonicalize (H12AffineFastState.compose env2705 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2705 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2706 : List Nat := [2,4,4,16,16,0,21,20,22,20,0,1,21,0,16,2,16,17,20,16,17,17,17,18,4,0,1,1,17,16,20,0,20,0,1,22]

theorem envBound2706 : H12AffineFastState.Bounded env2706 := by
  intro p hp
  have h : env2706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2705_2706 : H12AffineEnvironment.transform 2 4 env2705 = env2706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2705 == env2706) = true)

def leafEnv2706 : List Nat := [2,4,4,16,16,0,21,20,22,20,0,1,21,0,16,2,16,17,20,16,17,17,17,18,21,4,1,0,1,1,17,16,20,0,20,0,5,18,1,22,1,16,0]

def active2706 : List Nat := [0,1,3]

def tree2706 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2706 : H12WitnessSearch.Good tree2706 := H12GlobalWitnessIndex.good

theorem leafIdentity2706 : H12AffineFastState.composeSystem env2706 rootObs = leafEnv2706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2706 rootObs == leafEnv2706) = true)

theorem terminalChecked2706 : H12PackedTerminal.terminalCheckFast leafEnv2706 active2706 tree2706 = true := by decide +kernel

def env2707 : List Nat := [2,4,8,16,16,1,25,21,23,21,0,0,21,13,28,14,28,17,21,28,17,17,17,18,4,1,1,12,17,16,21,0,21,0,12,23]

theorem envBound2707 : H12AffineFastState.Bounded env2707 := by
  intro p hp
  have h : env2707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2704_2707 : H12AffineEnvironment.transform 5 1 env2704 = env2707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2704 == env2707) = true)

def leafEnv2707 : List Nat := [2,4,8,16,16,1,25,21,23,21,0,0,21,13,28,14,28,17,21,28,17,17,17,18,20,4,1,1,1,12,17,16,21,0,21,0,5,30,12,23,1,16,0]

def active2707 : List Nat := [0,1,2,3]

def tree2707 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2707 : H12WitnessSearch.Good tree2707 := H12GlobalWitnessIndex.good

theorem leafIdentity2707 : H12AffineFastState.composeSystem env2707 rootObs = leafEnv2707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2707 rootObs == leafEnv2707) = true)

theorem terminalChecked2707 : H12PackedTerminal.terminalCheckFast leafEnv2707 active2707 tree2707 = true := by decide +kernel

def env2708 : List Nat := [2,4,8,16,16,64,25,84,512,84,1,65,578,539,587,601,587,16,84,587,17,17,17,18,595,64,0,538,17,17,84,0,84,0,538,512]

theorem envBound2708 : H12AffineFastState.Bounded env2708 := by
  intro p hp
  have h : env2708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2702_2708 : H12AffineEnvironment.transform 10 1 env2702 = env2708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2702 == env2708) = true)

theorem identity2708 : scanCanonicalize (H12AffineFastState.compose env2708 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound2708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2709 : List Nat := [2,4,8,16,16,64,25,84,71,84,1,65,5,92,12,30,12,16,84,12,17,17,17,18,20,64,0,93,17,17,84,0,84,0,93,71]

theorem envBound2709 : H12AffineFastState.Bounded env2709 := by
  intro p hp
  have h : env2709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2708_2709 : H12AffineEnvironment.transform 8 71 env2708 = env2709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env2708 == env2709) = true)

def env2710 : List Nat := [2,4,8,16,16,0,25,20,7,20,1,1,5,28,12,30,12,16,20,12,17,17,17,18,20,0,0,29,17,17,20,0,20,0,29,7]

theorem envBound2710 : H12AffineFastState.Bounded env2710 := by
  intro p hp
  have h : env2710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2709_2710 : H12AffineEnvironment.transform 5 0 env2709 = env2710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2709 == env2710) = true)

def leafEnv2710 : List Nat := [2,4,8,16,16,0,25,20,7,20,1,1,5,28,12,30,12,16,20,12,17,17,17,18,21,20,1,0,0,29,17,17,20,0,20,0,5,14,29,7,1,16,0]

def active2710 : List Nat := [0,1,2,3]

def tree2710 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2710 : H12WitnessSearch.Good tree2710 := H12GlobalWitnessIndex.good

theorem leafIdentity2710 : H12AffineFastState.composeSystem env2710 rootObs = leafEnv2710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2710 rootObs == leafEnv2710) = true)

theorem terminalChecked2710 : H12PackedTerminal.terminalCheckFast leafEnv2710 active2710 tree2710 = true := by decide +kernel

def env2711 : List Nat := [2,4,8,16,16,1,25,21,6,21,1,0,5,29,12,30,12,16,21,12,17,17,17,18,20,1,0,28,17,17,21,0,21,0,28,6]

theorem envBound2711 : H12AffineFastState.Bounded env2711 := by
  intro p hp
  have h : env2711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2709_2711 : H12AffineEnvironment.transform 5 1 env2709 = env2711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2709 == env2711) = true)

theorem identity2711 : scanCanonicalize (H12AffineFastState.compose env2711 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2712 : List Nat := [2,4,8,13,13,1,4,8,6,8,1,0,5,0,12,3,12,13,8,12,12,12,12,15,9,1,0,1,12,12,8,0,8,0,1,6]

theorem envBound2712 : H12AffineFastState.Bounded env2712 := by
  intro p hp
  have h : env2712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2711_2712 : H12AffineEnvironment.transform 3 13 env2711 = env2712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2711 == env2712) = true)

def leafEnv2712 : List Nat := [2,4,8,13,13,1,4,8,6,8,1,0,5,0,12,3,12,13,8,12,12,12,12,15,9,9,1,1,0,1,12,12,8,0,8,0,5,14,1,6,1,13,0]

def active2712 : List Nat := [0,1,2]

def tree2712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2712 : H12WitnessSearch.Good tree2712 := H12GlobalWitnessIndex.good

theorem leafIdentity2712 : H12AffineFastState.composeSystem env2712 rootObs = leafEnv2712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2712 rootObs == leafEnv2712) = true)

theorem terminalChecked2712 : H12PackedTerminal.terminalCheckFast leafEnv2712 active2712 tree2712 = true := by decide +kernel

def env2713 : List Nat := [2,4,8,16,17,64,24,84,512,84,2048,65,2627,2586,2634,2649,2634,2064,84,2634,17,16,17,19,2643,64,2049,2587,17,2065,84,0,84,0,2587,512]

theorem envBound2713 : H12AffineFastState.Bounded env2713 := by
  intro p hp
  have h : env2713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2701_2713 : H12AffineEnvironment.transform 4 17 env2701 = env2713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2701 == env2713) = true)

def env2714 : List Nat := [2,4,8,16,17,64,24,84,512,84,0,65,579,538,586,601,586,16,84,586,17,16,17,19,595,64,1,539,17,17,84,0,84,0,539,512]

theorem envBound2714 : H12AffineFastState.Bounded env2714 := by
  intro p hp
  have h : env2714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2713_2714 : H12AffineEnvironment.transform 10 0 env2713 = env2714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2713 == env2714) = true)

theorem identity2714 : scanCanonicalize (H12AffineFastState.compose env2714 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2715 : List Nat := [2,4,8,12,13,64,4,72,512,72,0,65,579,518,586,581,586,12,72,586,13,12,13,15,591,64,1,519,13,13,72,0,72,0,519,512]

theorem envBound2715 : H12AffineFastState.Bounded env2715 := by
  intro p hp
  have h : env2715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2714_2715 : H12AffineEnvironment.transform 3 12 env2714 = env2715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2714 == env2715) = true)

def env2716 : List Nat := [2,4,8,12,13,0,4,8,512,8,0,1,515,518,522,517,522,12,8,522,13,12,13,15,527,0,1,519,13,13,8,0,8,0,519,512]

theorem envBound2716 : H12AffineFastState.Bounded env2716 := by
  intro p hp
  have h : env2716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2715_2716 : H12AffineEnvironment.transform 5 0 env2715 = env2716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2715 == env2716) = true)

theorem identity2716 : scanCanonicalize (H12AffineFastState.compose env2716 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2717 : List Nat := [2,4,8,12,13,0,4,8,7,8,0,1,4,1,13,2,13,12,8,13,13,12,13,15,8,0,1,0,13,13,8,0,8,0,0,7]

theorem envBound2717 : H12AffineFastState.Bounded env2717 := by
  intro p hp
  have h : env2717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2716_2717 : H12AffineEnvironment.transform 8 7 env2716 = env2717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2716 == env2717) = true)

def leafEnv2717 : List Nat := [2,4,8,12,13,0,4,8,7,8,0,1,4,1,13,2,13,12,8,13,13,12,13,15,9,8,1,0,1,0,13,13,8,0,8,0,5,15,0,7,1,12,0]

def active2717 : List Nat := [0,1,2]

def tree2717 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2717 : H12WitnessSearch.Good tree2717 := H12GlobalWitnessIndex.good

theorem leafIdentity2717 : H12AffineFastState.composeSystem env2717 rootObs = leafEnv2717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2717 rootObs == leafEnv2717) = true)

theorem terminalChecked2717 : H12PackedTerminal.terminalCheckFast leafEnv2717 active2717 tree2717 = true := by decide +kernel

def env2718 : List Nat := [2,4,8,12,13,1,4,9,512,9,0,0,514,518,523,516,523,12,9,523,13,12,13,15,526,1,1,519,13,13,9,0,9,0,519,512]

theorem envBound2718 : H12AffineFastState.Bounded env2718 := by
  intro p hp
  have h : env2718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2715_2718 : H12AffineEnvironment.transform 5 1 env2715 = env2718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2715 == env2718) = true)

def leafEnv2718 : List Nat := [2,4,8,12,13,1,4,9,512,9,0,0,514,518,523,516,523,12,9,523,13,12,13,15,8,526,1,1,1,519,13,13,9,0,9,0,5,521,519,512,1,12,0]

def active2718 : List Nat := [0,1,2,8]

def tree2718 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2718 : H12WitnessSearch.Good tree2718 := H12GlobalWitnessIndex.good

theorem leafIdentity2718 : H12AffineFastState.composeSystem env2718 rootObs = leafEnv2718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2718 rootObs == leafEnv2718) = true)

theorem terminalChecked2718 : H12PackedTerminal.terminalCheckFast leafEnv2718 active2718 tree2718 = true := by decide +kernel

def env2719 : List Nat := [2,4,8,16,17,64,24,84,512,84,1,65,578,539,587,600,587,17,84,587,17,16,17,19,594,64,0,538,17,16,84,0,84,0,538,512]

theorem envBound2719 : H12AffineFastState.Bounded env2719 := by
  intro p hp
  have h : env2719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2713_2719 : H12AffineEnvironment.transform 10 1 env2713 = env2719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2713 == env2719) = true)

theorem identity2719 : scanCanonicalize (H12AffineFastState.compose env2719 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2719 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2720 : List Nat := [2,4,5,16,17,64,21,84,512,84,1,65,578,534,582,597,582,17,84,582,17,16,17,19,594,64,0,535,17,16,84,0,84,0,535,512]

theorem envBound2720 : H12AffineFastState.Bounded env2720 := by
  intro p hp
  have h : env2720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2719_2720 : H12AffineEnvironment.transform 2 5 env2719 = env2720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2719 == env2720) = true)

def env2721 : List Nat := [2,4,5,16,17,0,21,20,512,20,1,1,514,534,518,533,518,17,20,518,17,16,17,19,530,0,0,535,17,16,20,0,20,0,535,512]

theorem envBound2721 : H12AffineFastState.Bounded env2721 := by
  intro p hp
  have h : env2721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2720_2721 : H12AffineEnvironment.transform 5 0 env2720 = env2721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2720 == env2721) = true)

def leafEnv2721 : List Nat := [2,4,5,16,17,0,21,20,512,20,1,1,514,534,518,533,518,17,20,518,17,16,17,19,21,530,1,0,0,535,17,16,20,0,20,0,5,516,535,512,1,16,0]

def active2721 : List Nat := [0,1,3,8]

def tree2721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2721 : H12WitnessSearch.Good tree2721 := H12GlobalWitnessIndex.good

theorem leafIdentity2721 : H12AffineFastState.composeSystem env2721 rootObs = leafEnv2721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2721 rootObs == leafEnv2721) = true)

theorem terminalChecked2721 : H12PackedTerminal.terminalCheckFast leafEnv2721 active2721 tree2721 = true := by decide +kernel

def env2722 : List Nat := [2,4,5,16,17,1,21,21,512,21,1,0,515,534,519,532,519,17,21,519,17,16,17,19,531,1,0,535,17,16,21,0,21,0,535,512]

theorem envBound2722 : H12AffineFastState.Bounded env2722 := by
  intro p hp
  have h : env2722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2720_2722 : H12AffineEnvironment.transform 5 1 env2720 = env2722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2720 == env2722) = true)

theorem identity2722 : scanCanonicalize (H12AffineFastState.compose env2722 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2723 : List Nat := [2,4,5,16,17,1,21,21,23,21,1,0,20,1,16,3,16,17,21,16,17,16,17,19,4,1,0,0,17,16,21,0,21,0,0,23]

theorem envBound2723 : H12AffineFastState.Bounded env2723 := by
  intro p hp
  have h : env2723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2722_2723 : H12AffineEnvironment.transform 8 23 env2722 = env2723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2722 == env2723) = true)

def leafEnv2723 : List Nat := [2,4,5,16,17,1,21,21,23,21,1,0,20,1,16,3,16,17,21,16,17,16,17,19,20,4,1,1,0,0,17,16,21,0,21,0,5,18,0,23,1,16,0]

def active2723 : List Nat := [0,1,3]

def tree2723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2723 : H12WitnessSearch.Good tree2723 := H12GlobalWitnessIndex.good

theorem leafIdentity2723 : H12AffineFastState.composeSystem env2723 rootObs = leafEnv2723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2723 rootObs == leafEnv2723) = true)

theorem terminalChecked2723 : H12PackedTerminal.terminalCheckFast leafEnv2723 active2723 tree2723 = true := by decide +kernel

def env2724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,185,74229,8328,74135,336222,16385,151552,2080,75134,1,73855,0,131333,512]

theorem envBound2724 : H12AffineFastState.Bounded env2724 := by
  intro p hp
  have h : env2724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2647_2724 : H12AffineEnvironment.transform 22 185 env2647 = env2724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env2647 == env2724) = true)

theorem identity2724 : scanCanonicalize (H12AffineFastState.compose env2724 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound2724 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2725 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74882,8201,2097152,73891,185,73736,8328,73834,336035,16385,151552,2080,74883,1,73855,0,131320,512]

theorem envBound2725 : H12AffineFastState.Bounded env2725 := by
  intro p hp
  have h : env2725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2724_2725 : H12AffineEnvironment.transform 7 253 env2724 = env2725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2724 == env2725) = true)

def env2726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2080,17375733,13108376,525568,0,34359738368,25691698]

theorem envBound2726 : H12AffineFastState.Bounded env2726 := by
  intro p hp
  have h : env2726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2642_2726 : H12AffineEnvironment.transform 14 8693 env2642 = env2726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env2642 == env2726) = true)

def env2727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672785,935128,16385,151552,2080,17375733,4867288,525568,0,34359738368,17450610]

theorem envBound2727 : H12AffineFastState.Bounded env2727 := by
  intro p hp
  have h : env2727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2726_2727 : H12AffineEnvironment.transform 22 147520 env2726 = env2727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env2726 == env2727) = true)

def env2728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,4341976,256,0,34359738368,16925298]

theorem envBound2728 : H12AffineFastState.Bounded env2728 := by
  intro p hp
  have h : env2728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2727_2728 : H12AffineEnvironment.transform 18 1024 env2727 = env2728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2727 == env2728) = true)

def env2729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,4341976,256,0,131072,16925298]

theorem envBound2729 : H12AffineFastState.Bounded env2729 := by
  intro p hp
  have h : env2729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2728_2729 : H12AffineEnvironment.transform 34 131072 env2728 = env2729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2728 == env2729) = true)

theorem identity2729 : scanCanonicalize (H12AffineFastState.compose env2729 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2188303) := by decide +kernel

theorem selectedBound2729 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2188303,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,2303191,256,0,131072,16925298]

theorem envBound2730 : H12AffineFastState.Bounded env2730 := by
  intro p hp
  have h : env2730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2729_2730 : H12AffineEnvironment.transform 21 2188303 env2729 = env2730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2188303 env2729 == env2730) = true)

theorem identity2730 : scanCanonicalize (H12AffineFastState.compose env2730 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound2730 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2188303,147520,138,8328,147473,409816,16385,151552,2080,75135,2303191,256,0,131072,148216]

theorem envBound2731 : H12AffineFastState.Bounded env2731 := by
  intro p hp
  have h : env2731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2730_2731 : H12AffineEnvironment.transform 23 138 env2730 = env2731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env2730 == env2731) = true)

theorem identity2731 : scanCanonicalize (H12AffineFastState.compose env2731 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 206123) := by decide +kernel

theorem selectedBound2731 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env2732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,206123,147748,147520,138,8328,147473,409816,16385,151552,2080,75135,508,256,0,131072,148216]

theorem envBound2732 : H12AffineFastState.Bounded env2732 := by
  intro p hp
  have h : env2732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2731_2732 : H12AffineEnvironment.transform 20 206123 env2731 = env2732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206123 env2731 == env2732) = true)

theorem identity2732 : scanCanonicalize (H12AffineFastState.compose env2732 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2732 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env2733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,132181,147748,147520,138,8328,147473,409816,16385,151552,2080,1025,508,256,0,131072,148216]

theorem envBound2733 : H12AffineFastState.Bounded env2733 := by
  intro p hp
  have h : env2733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2732_2733 : H12AffineEnvironment.transform 15 8574 env2732 = env2733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2732 == env2733) = true)

def env2734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1024,8693,17581,476,184,138,8328,233,262176,16385,4344,2080,1025,508,256,0,16632,512]

theorem envBound2734 : H12AffineFastState.Bounded env2734 := by
  intro p hp
  have h : env2734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2733_2734 : H12AffineEnvironment.transform 16 16632 env2733 = env2734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2733 == env2734) = true)

theorem identity2734 : scanCanonicalize (H12AffineFastState.compose env2734 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound2734 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,10281,1024,8693,17581,476,184,138,8328,233,10249,16385,4344,2080,1025,508,256,0,16632,512]

theorem envBound2735 : H12AffineFastState.Bounded env2735 := by
  intro p hp
  have h : env2735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2734_2735 : H12AffineEnvironment.transform 17 10281 env2734 = env2735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env2734 == env2735) = true)

theorem identity2735 : scanCanonicalize (H12AffineFastState.compose env2735 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound2735 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env2736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,16384,80,219,16632,2444,1024,80,17581,476,184,138,301,233,2476,16385,4344,2080,1025,508,256,0,16632,512]

theorem envBound2736 : H12AffineFastState.Bounded env2736 := by
  intro p hp
  have h : env2736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2735_2736 : H12AffineEnvironment.transform 12 421 env2735 = env2736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env2735 == env2736) = true)

theorem identity2736 : scanCanonicalize (H12AffineFastState.compose env2736 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2736 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env2737 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,4096,421,16384,16,155,16568,2444,1024,16,17581,412,184,138,301,169,2476,16385,4280,2080,1025,444,256,0,16568,512]

theorem envBound2737 : H12AffineFastState.Bounded env2737 := by
  intro p hp
  have h : env2737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2736_2737 : H12AffineEnvironment.transform 5 0 env2736 = env2737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2736 == env2737) = true)

def env2738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1024,8693,17580,477,185,138,8328,232,262177,16385,4345,2080,1025,508,256,0,16633,513]

theorem envBound2738 : H12AffineFastState.Bounded env2738 := by
  intro p hp
  have h : env2738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2733_2738 : H12AffineEnvironment.transform 16 16633 env2733 = env2738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2733 == env2738) = true)

theorem identity2738 : scanCanonicalize (H12AffineFastState.compose env2738 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13577) := by decide +kernel

theorem selectedBound2738 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13577,8693,8574,13808,262144,1024,8693,12709,477,185,138,8328,232,262177,13576,4345,2080,1025,508,256,0,13808,513]

theorem envBound2739 : H12AffineFastState.Bounded env2739 := by
  intro p hp
  have h : env2739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2738_2739 : H12AffineEnvironment.transform 13 13577 env2738 = env2739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13577 env2738 == env2739) = true)

theorem identity2739 : scanCanonicalize (H12AffineFastState.compose env2739 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound2739 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,509,374,5624,262144,1024,509,4525,477,185,138,128,232,262177,5376,4345,2080,1025,508,256,0,5624,513]

theorem envBound2740 : H12AffineFastState.Bounded env2740 := by
  intro p hp
  have h : env2740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2739_2740 : H12AffineEnvironment.transform 12 8 env2739 = env2740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env2739 == env2740) = true)

theorem identity2740 : scanCanonicalize (H12AffineFastState.compose env2740 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound2740 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2741 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,8,5140,232,99,5357,262144,1024,232,4280,200,185,138,128,232,262177,5141,4345,2080,1025,233,21,0,5357,513]

theorem envBound2741 : H12AffineFastState.Bounded env2741 := by
  intro p hp
  have h : env2741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2740_2741 : H12AffineEnvironment.transform 7 21 env2740 = env2741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env2740 == env2741) = true)

theorem identity2741 : scanCanonicalize (H12AffineFastState.compose env2741 (packedSelected [1,2,8,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2144) := by decide +kernel

theorem selectedBound2741 : packedSelected [1,2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env2742 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,8,5140,232,99,5357,2144,1024,232,4280,200,185,138,128,232,2113,5141,4345,2080,1025,233,21,0,5357,513]

theorem envBound2742 : H12AffineFastState.Bounded env2742 := by
  intro p hp
  have h : env2742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2741_2742 : H12AffineEnvironment.transform 17 2144 env2741 = env2742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2144 env2741 == env2742) = true)

theorem identity2742 : scanCanonicalize (H12AffineFastState.compose env2742 (packedSelected [4,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2742 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env2743 : List Nat := [2,4,8,16,32,64,40,21,512,1024,2048,4096,8,5140,64,99,5189,2144,1024,64,4112,96,17,34,40,64,2113,5141,4177,2080,1025,65,21,0,5189,513]

theorem envBound2743 : H12AffineFastState.Bounded env2743 := by
  intro p hp
  have h : env2743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2742_2743 : H12AffineEnvironment.transform 6 40 env2742 = env2743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2742 == env2743) = true)

theorem identity2743 : scanCanonicalize (H12AffineFastState.compose env2743 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2743 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2744 : List Nat := [2,4,8,16,32,0,40,21,512,1024,2048,4096,8,5140,0,35,5125,2080,1024,0,4112,32,17,34,40,0,2049,5141,4113,2080,1025,1,21,0,5125,513]

theorem envBound2744 : H12AffineFastState.Bounded env2744 := by
  intro p hp
  have h : env2744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2743_2744 : H12AffineEnvironment.transform 5 0 env2743 = env2744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2743 == env2744) = true)

theorem identity2744 : scanCanonicalize (H12AffineFastState.compose env2744 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2745 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,4096,8,5125,0,35,5125,2080,1024,0,4097,32,0,34,40,0,2049,5124,4096,2080,1025,1,4,0,5125,513]

theorem envBound2745 : H12AffineFastState.Bounded env2745 := by
  intro p hp
  have h : env2745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2744_2745 : H12AffineEnvironment.transform 3 1 env2744 = env2745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2744 == env2745) = true)

theorem identity2745 : scanCanonicalize (H12AffineFastState.compose env2745 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3598) := by decide +kernel

theorem selectedBound2745 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2746 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,3598,8,2571,0,35,2571,2080,1024,0,3599,32,0,34,40,0,2049,2570,3598,2080,1025,1,4,0,2571,513]

theorem envBound2746 : H12AffineFastState.Bounded env2746 := by
  intro p hp
  have h : env2746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2745_2746 : H12AffineEnvironment.transform 11 3598 env2745 = env2746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3598 env2745 == env2746) = true)

theorem identity2746 : scanCanonicalize (H12AffineFastState.compose env2746 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound2746 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2747 : List Nat := [2,4,8,1,32,0,40,4,512,37,2048,2603,8,2571,0,35,2571,2080,37,0,2602,32,0,34,40,0,2049,2570,2603,2080,36,1,4,0,2571,513]

theorem envBound2747 : H12AffineFastState.Bounded env2747 := by
  intro p hp
  have h : env2747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2746_2747 : H12AffineEnvironment.transform 9 37 env2746 = env2747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env2746 == env2747) = true)

theorem identity2747 : scanCanonicalize (H12AffineFastState.compose env2747 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound2747 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2748 : List Nat := [2,4,8,1,32,0,40,4,43,37,2048,2048,8,2080,0,35,2080,2080,37,0,2049,32,0,34,40,0,2049,2081,2048,2080,36,1,4,0,2080,42]

theorem envBound2748 : H12AffineFastState.Bounded env2748 := by
  intro p hp
  have h : env2748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2747_2748 : H12AffineEnvironment.transform 8 43 env2747 = env2748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env2747 == env2748) = true)

theorem identity2748 : scanCanonicalize (H12AffineFastState.compose env2748 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound2748 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2749 : List Nat := [2,4,8,1,32,0,40,4,43,37,44,44,8,12,0,35,12,12,37,0,45,32,0,34,40,0,45,13,44,12,36,1,4,0,12,42]

theorem envBound2749 : H12AffineFastState.Bounded env2749 := by
  intro p hp
  have h : env2749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2748_2749 : H12AffineEnvironment.transform 10 44 env2748 = env2749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env2748 == env2749) = true)

theorem identity2749 : scanCanonicalize (H12AffineFastState.compose env2749 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound2749 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env2750 : List Nat := [2,4,8,1,13,0,5,4,6,8,1,1,8,12,0,14,12,12,8,0,0,13,0,15,5,0,0,13,1,12,9,1,4,0,12,7]

theorem envBound2750 : H12AffineFastState.Bounded env2750 := by
  intro p hp
  have h : env2750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2749_2750 : H12AffineEnvironment.transform 4 13 env2749 = env2750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env2749 == env2750) = true)

theorem identity2750 : scanCanonicalize (H12AffineFastState.compose env2750 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound2750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2751 : List Nat := [2,4,0,1,5,0,5,4,6,0,1,1,0,4,0,6,4,4,0,0,0,5,0,7,5,0,0,5,1,4,1,1,4,0,4,7]

theorem envBound2751 : H12AffineFastState.Bounded env2751 := by
  intro p hp
  have h : env2751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2750_2751 : H12AffineEnvironment.transform 2 0 env2750 = env2751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env2750 == env2751) = true)

def env2752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,4341976,256,0,131073,16925298]

theorem envBound2752 : H12AffineFastState.Bounded env2752 := by
  intro p hp
  have h : env2752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2728_2752 : H12AffineEnvironment.transform 34 131073 env2728 = env2752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2728 == env2752) = true)

theorem identity2752 : scanCanonicalize (H12AffineFastState.compose env2752 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 95246) := by decide +kernel

theorem selectedBound2752 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,95246,147520,16777216,8328,147473,409816,16385,151552,2080,16852469,210134,256,0,131073,16925298]

theorem envBound2753 : H12AffineFastState.Bounded env2753 := by
  intro p hp
  have h : env2753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2752_2753 : H12AffineEnvironment.transform 21 95246 env2752 = env2753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95246 env2752 == env2753) = true)

theorem identity2753 : scanCanonicalize (H12AffineFastState.compose env2753 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 21978) := by decide +kernel

theorem selectedBound2753 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,95246,147520,21978,8328,147473,409816,16385,151552,2080,94255,210134,256,0,131073,137128]

theorem envBound2754 : H12AffineFastState.Bounded env2754 := by
  intro p hp
  have h : env2754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2753_2754 : H12AffineEnvironment.transform 23 21978 env2753 = env2754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 21978 env2753 == env2754) = true)

theorem identity2754 : scanCanonicalize (H12AffineFastState.compose env2754 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2754 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,2097152,21872,147520,21978,8328,147473,409816,16385,151552,2080,20817,136616,256,0,131073,137128]

theorem envBound2755 : H12AffineFastState.Bounded env2755 := by
  intro p hp
  have h : env2755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2754_2755 : H12AffineEnvironment.transform 15 8574 env2754 = env2755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2754 == env2755) = true)

def env2756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16464,262144,1024,8693,2097152,21872,16,21978,8328,65,262280,16385,4176,2080,20817,22008,256,0,16465,22520]

theorem envBound2756 : H12AffineFastState.Bounded env2756 := by
  intro p hp
  have h : env2756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2755_2756 : H12AffineEnvironment.transform 16 16464 env2755 = env2756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env2755 == env2756) = true)

theorem identity2756 : scanCanonicalize (H12AffineFastState.compose env2756 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound2756 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8693,8574,5376,262144,1024,8693,2097152,32,16,138,8328,65,262280,5457,4176,2080,1025,168,256,0,5377,680]

theorem envBound2757 : H12AffineFastState.Bounded env2757 := by
  intro p hp
  have h : env2757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2756_2757 : H12AffineEnvironment.transform 13 5456 env2756 = env2757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env2756 == env2757) = true)

theorem identity2757 : scanCanonicalize (H12AffineFastState.compose env2757 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound2757 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env2758 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5124,8353,8234,5204,262144,1024,8353,2097152,32,16,138,8328,65,262280,5125,4176,2080,1025,168,84,0,5205,680]

theorem envBound2758 : H12AffineFastState.Bounded env2758 := by
  intro p hp
  have h : env2758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2757_2758 : H12AffineEnvironment.transform 7 84 env2757 = env2758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env2757 == env2758) = true)

theorem identity2758 : scanCanonicalize (H12AffineFastState.compose env2758 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound2758 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env2759 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,5124,8353,8234,5204,262144,1024,8353,4161,32,16,138,8328,65,262280,5125,4176,2080,1025,168,84,0,5205,680]

theorem envBound2759 : H12AffineFastState.Bounded env2759 := by
  intro p hp
  have h : env2759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2758_2759 : H12AffineEnvironment.transform 20 4161 env2758 = env2759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env2758 == env2759) = true)

theorem identity2759 : scanCanonicalize (H12AffineFastState.compose env2759 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound2759 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env2760 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,89,5124,248,115,5204,262144,1024,248,4161,32,16,138,209,65,262280,5125,4176,2080,1025,168,84,0,5205,680]

theorem envBound2760 : H12AffineFastState.Bounded env2760 := by
  intro p hp
  have h : env2760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2759_2760 : H12AffineEnvironment.transform 12 89 env2759 = env2760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env2759 == env2760) = true)

theorem identity2760 : scanCanonicalize (H12AffineFastState.compose env2760 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound2760 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env2761 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,9,5124,168,35,5124,262144,1024,168,4113,32,16,138,129,17,262280,5125,4096,2080,1025,168,4,0,5125,680]

theorem envBound2761 : H12AffineFastState.Bounded env2761 := by
  intro p hp
  have h : env2761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2760_2761 : H12AffineEnvironment.transform 5 16 env2760 = env2761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2760 == env2761) = true)

theorem identity2761 : scanCanonicalize (H12AffineFastState.compose env2761 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2761 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env2762 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,9,5124,1,35,5124,262144,1024,1,4113,32,16,35,40,17,262177,5125,4096,2080,1025,1,4,0,5125,513]

theorem envBound2762 : H12AffineFastState.Bounded env2762 := by
  intro p hp
  have h : env2762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2761_2762 : H12AffineEnvironment.transform 6 41 env2761 = env2762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2761 == env2762) = true)

theorem identity2762 : scanCanonicalize (H12AffineFastState.compose env2762 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 571) := by decide +kernel

theorem selectedBound2762 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2763 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,9,5124,1,35,5124,571,1024,1,4113,32,16,35,40,17,538,5125,4096,2080,1025,1,4,0,5125,513]

theorem envBound2763 : H12AffineFastState.Bounded env2763 := by
  intro p hp
  have h : env2763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2762_2763 : H12AffineEnvironment.transform 17 571 env2762 = env2763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 571 env2762 == env2763) = true)

def env2764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16465,262144,1024,8693,2097152,21872,17,21978,8328,64,262281,16385,4177,2080,20817,22009,256,0,16464,22521]

theorem envBound2764 : H12AffineFastState.Bounded env2764 := by
  intro p hp
  have h : env2764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2755_2764 : H12AffineEnvironment.transform 16 16465 env2755 = env2764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env2755 == env2764) = true)

theorem identity2764 : scanCanonicalize (H12AffineFastState.compose env2764 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5624) := by decide +kernel

theorem selectedBound2764 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5624,8693,8574,5545,262144,1024,8693,2097152,136,17,34,8328,64,262281,5625,4177,2080,1193,1,256,0,5544,513]

theorem envBound2765 : H12AffineFastState.Bounded env2765 := by
  intro p hp
  have h : env2765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2764_2765 : H12AffineEnvironment.transform 13 5624 env2764 = env2765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5624 env2764 == env2765) = true)

theorem identity2765 : scanCanonicalize (H12AffineFastState.compose env2765 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4344) := by decide +kernel

theorem selectedBound2765 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5624,8693,8574,5545,262144,1024,8693,4344,136,17,34,8328,64,262281,5625,4177,2080,1193,1,256,0,5544,513]

theorem envBound2766 : H12AffineFastState.Bounded env2766 := by
  intro p hp
  have h : env2766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2765_2766 : H12AffineEnvironment.transform 20 4344 env2765 = env2766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4344 env2765 == env2766) = true)

theorem identity2766 : scanCanonicalize (H12AffineFastState.compose env2766 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound2766 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2767 : List Nat := [2,4,8,16,32,64,128,189,512,1024,2048,4096,8192,5189,8264,8387,5140,262144,1024,8264,4344,136,17,34,8328,64,262281,5188,4177,2080,1193,1,189,0,5141,513]

theorem envBound2767 : H12AffineFastState.Bounded env2767 := by
  intro p hp
  have h : env2767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2766_2767 : H12AffineEnvironment.transform 7 189 env2766 = env2767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env2766 == env2767) = true)

theorem identity2767 : scanCanonicalize (H12AffineFastState.compose env2767 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2767 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2768 : List Nat := [2,4,8,16,32,0,128,189,512,1024,2048,4096,8192,5125,8200,8323,5140,262144,1024,8200,4280,136,17,34,8328,0,262281,5124,4113,2080,1193,1,189,0,5141,513]

theorem envBound2768 : H12AffineFastState.Bounded env2768 := by
  intro p hp
  have h : env2768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2767_2768 : H12AffineEnvironment.transform 5 0 env2767 = env2768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2767 == env2768) = true)

theorem identity2768 : scanCanonicalize (H12AffineFastState.compose env2768 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2768 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env2769 : List Nat := [2,4,8,16,32,0,40,21,512,1024,2048,4096,8192,5125,8200,8235,5140,262144,1024,8200,4112,32,17,34,8224,0,262177,5124,4113,2080,1025,1,21,0,5141,513]

theorem envBound2769 : H12AffineFastState.Bounded env2769 := by
  intro p hp
  have h : env2769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2768_2769 : H12AffineEnvironment.transform 6 40 env2768 = env2769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2768 == env2769) = true)

theorem identity2769 : scanCanonicalize (H12AffineFastState.compose env2769 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound2769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2770 : List Nat := [2,4,8,16,32,0,40,21,512,1024,2048,4096,24,5125,16,51,5140,262144,1024,16,4112,32,17,34,56,0,262177,5124,4113,2080,1025,1,21,0,5141,513]

theorem envBound2770 : H12AffineFastState.Bounded env2770 := by
  intro p hp
  have h : env2770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2769_2770 : H12AffineEnvironment.transform 12 24 env2769 = env2770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env2769 == env2770) = true)

theorem identity2770 : scanCanonicalize (H12AffineFastState.compose env2770 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2770 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2771 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,4096,8,5125,0,35,5124,262144,1024,0,4096,32,1,34,40,0,262177,5124,4097,2080,1025,1,5,0,5125,513]

theorem envBound2771 : H12AffineFastState.Bounded env2771 := by
  intro p hp
  have h : env2771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2770_2771 : H12AffineEnvironment.transform 3 0 env2770 = env2771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2770 == env2771) = true)

theorem identity2771 : scanCanonicalize (H12AffineFastState.compose env2771 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 523) := by decide +kernel

theorem selectedBound2771 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2772 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,4096,8,5125,0,35,5124,523,1024,0,4096,32,1,34,40,0,554,5124,4097,2080,1025,1,5,0,5125,513]

theorem envBound2772 : H12AffineFastState.Bounded env2772 := by
  intro p hp
  have h : env2772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2771_2772 : H12AffineEnvironment.transform 17 523 env2771 = env2772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 523 env2771 == env2772) = true)

theorem identity2772 : scanCanonicalize (H12AffineFastState.compose env2772 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound2772 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env2773 : List Nat := [2,4,8,0,32,0,40,5,512,1024,554,4096,8,5125,0,35,5124,523,1024,0,4096,32,1,34,40,0,554,5124,4097,522,1025,1,5,0,5125,513]

theorem envBound2773 : H12AffineFastState.Bounded env2773 := by
  intro p hp
  have h : env2773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2772_2773 : H12AffineEnvironment.transform 10 554 env2772 = env2773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env2772 == env2773) = true)

theorem identity2773 : scanCanonicalize (H12AffineFastState.compose env2773 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound2773 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2774 : List Nat := [2,4,8,0,32,0,40,5,512,1024,554,32,8,1061,0,35,1060,523,1024,0,32,32,1,34,40,0,554,1060,33,522,1025,1,5,0,1061,513]

theorem envBound2774 : H12AffineFastState.Bounded env2774 := by
  intro p hp
  have h : env2774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2773_2774 : H12AffineEnvironment.transform 11 32 env2773 = env2774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env2773 == env2774) = true)

theorem identity2774 : scanCanonicalize (H12AffineFastState.compose env2774 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound2774 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2775 : List Nat := [2,4,8,0,32,0,40,5,10,1024,32,32,8,1061,0,35,1060,1,1024,0,32,32,1,34,40,0,32,1060,33,0,1025,1,5,0,1061,11]

theorem envBound2775 : H12AffineFastState.Bounded env2775 := by
  intro p hp
  have h : env2775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2774_2775 : H12AffineEnvironment.transform 8 10 env2774 = env2775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env2774 == env2775) = true)

theorem identity2775 : scanCanonicalize (H12AffineFastState.compose env2775 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound2775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2776 : List Nat := [2,4,8,0,8,0,0,5,10,1024,8,8,8,1037,0,11,1036,1,1024,0,8,8,1,10,0,0,8,1036,9,0,1025,1,5,0,1037,11]

theorem envBound2776 : H12AffineFastState.Bounded env2776 := by
  intro p hp
  have h : env2776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2775_2776 : H12AffineEnvironment.transform 4 8 env2775 = env2776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env2775 == env2776) = true)

theorem identity2776 : scanCanonicalize (H12AffineFastState.compose env2776 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 12) := by decide +kernel

theorem selectedBound2776 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env2777 : List Nat := [2,4,8,0,8,0,0,5,10,12,8,8,8,1,0,11,0,1,12,0,8,8,1,10,0,0,8,0,9,0,13,1,5,0,1,11]

theorem envBound2777 : H12AffineFastState.Bounded env2777 := by
  intro p hp
  have h : env2777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2776_2777 : H12AffineEnvironment.transform 9 12 env2776 = env2777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env2776 == env2777) = true)

theorem identity2777 : scanCanonicalize (H12AffineFastState.compose env2777 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2777 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2778 : List Nat := [2,4,4,0,4,0,0,5,6,0,4,4,4,1,0,7,0,1,0,0,4,4,1,6,0,0,4,0,5,0,1,1,5,0,1,7]

theorem envBound2778 : H12AffineFastState.Bounded env2778 := by
  intro p hp
  have h : env2778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2777_2778 : H12AffineEnvironment.transform 2 4 env2777 = env2778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2777 == env2778) = true)

def env2779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16385,151552,2080,16852468,4341977,257,0,34359738368,16925299]

theorem envBound2779 : H12AffineFastState.Bounded env2779 := by
  intro p hp
  have h : env2779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2727_2779 : H12AffineEnvironment.transform 18 1025 env2727 = env2779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2727 == env2779) = true)

def env2780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16385,151552,2080,16852468,4341977,257,0,131072,16925299]

theorem envBound2780 : H12AffineFastState.Bounded env2780 := by
  intro p hp
  have h : env2780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2779_2780 : H12AffineEnvironment.transform 34 131072 env2779 = env2780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2779 == env2780) = true)

theorem identity2780 : scanCanonicalize (H12AffineFastState.compose env2780 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2318671) := by decide +kernel

theorem selectedBound2780 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2318671,147520,16777216,8328,147472,409817,16385,151552,2080,16852468,2171286,257,0,131072,16925299]

theorem envBound2781 : H12AffineFastState.Bounded env2781 := by
  intro p hp
  have h : env2781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2780_2781 : H12AffineEnvironment.transform 21 2318671 env2780 = env2781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2318671 env2780 == env2781) = true)

theorem identity2781 : scanCanonicalize (H12AffineFastState.compose env2781 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound2781 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,2097152,2244916,147520,16777216,8328,147472,409817,16385,151552,2080,16778639,2097645,257,0,131072,16925299]

theorem envBound2782 : H12AffineFastState.Bounded env2782 := by
  intro p hp
  have h : env2782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2781_2782 : H12AffineEnvironment.transform 15 8315 env2781 = env2782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env2781 == env2782) = true)

def env2783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,492,147672,147520,16777216,8328,147472,409817,16385,151552,2080,16778639,1,257,0,131072,16925299]

theorem envBound2783 : H12AffineFastState.Bounded env2783 := by
  intro p hp
  have h : env2783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2782_2783 : H12AffineEnvironment.transform 20 492 env2782 = env2783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 492 env2782 == env2783) = true)

theorem identity2783 : scanCanonicalize (H12AffineFastState.compose env2783 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2783 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2784 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,131072,262144,1025,8433,232,147672,147520,16777216,8328,147472,409817,16385,151552,2080,16778379,1,5,0,131072,16925299]

theorem envBound2784 : H12AffineFastState.Bounded env2784 := by
  intro p hp
  have h : env2784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2783_2784 : H12AffineEnvironment.transform 7 4 env2783 = env2784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2783 == env2784) = true)

def env2785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,493,147673,147520,16777216,8328,147472,409817,16385,151552,2080,16778639,0,257,0,131072,16925299]

theorem envBound2785 : H12AffineFastState.Bounded env2785 := by
  intro p hp
  have h : env2785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2782_2785 : H12AffineEnvironment.transform 20 493 env2782 = env2785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 493 env2782 == env2785) = true)

theorem identity2785 : scanCanonicalize (H12AffineFastState.compose env2785 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147831) := by decide +kernel

theorem selectedBound2785 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,493,147673,147520,147831,8328,147472,409817,16385,151552,2080,148728,0,257,0,131072,772]

theorem envBound2786 : H12AffineFastState.Bounded env2786 := by
  intro p hp
  have h : env2786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2785_2786 : H12AffineEnvironment.transform 23 147831 env2785 = env2786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147831 env2785 == env2786) = true)

theorem identity2786 : scanCanonicalize (H12AffineFastState.compose env2786 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound2786 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env2787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16633,262144,1025,8693,493,32,185,398,8328,233,262176,16385,4345,2080,1025,0,257,0,16633,772]

theorem envBound2787 : H12AffineFastState.Bounded env2787 := by
  intro p hp
  have h : env2787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2786_2787 : H12AffineEnvironment.transform 16 16633 env2786 = env2787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2786 == env2787) = true)

theorem identity2787 : scanCanonicalize (H12AffineFastState.compose env2787 (packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound2787 : packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env2788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16633,2264,1025,8693,493,32,185,398,8328,233,2296,16385,4345,2080,1025,0,257,0,16633,772]

theorem envBound2788 : H12AffineFastState.Bounded env2788 := by
  intro p hp
  have h : env2788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2787_2788 : H12AffineEnvironment.transform 17 2264 env2787 = env2788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env2787 == env2788) = true)

theorem identity2788 : scanCanonicalize (H12AffineFastState.compose env2788 (packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound2788 : packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env2789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1085,16384,1480,1094,16633,2264,1025,1480,493,32,185,398,1205,233,2296,16385,4345,2080,1025,0,257,0,16633,772]

theorem envBound2789 : H12AffineFastState.Bounded env2789 := by
  intro p hp
  have h : env2789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2788_2789 : H12AffineEnvironment.transform 12 1085 env2788 = env2789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env2788 == env2789) = true)

theorem identity2789 : scanCanonicalize (H12AffineFastState.compose env2789 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound2789 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env2790 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1085,16384,1124,1094,16633,2264,1025,1124,65,32,185,34,1205,233,2296,16385,4345,2080,1025,0,173,0,16633,680]

theorem envBound2790 : H12AffineFastState.Bounded env2790 := by
  intro p hp
  have h : env2790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2789_2790 : H12AffineEnvironment.transform 7 172 env2789 = env2790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env2789 == env2790) = true)

theorem identity2790 : scanCanonicalize (H12AffineFastState.compose env2790 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2097) := by decide +kernel

theorem selectedBound2790 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env2791 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1085,2097,1124,1094,2248,2264,1025,1124,65,32,185,34,1205,233,2296,2096,4345,2080,1025,0,173,0,2248,680]

theorem envBound2791 : H12AffineFastState.Bounded env2791 := by
  intro p hp
  have h : env2791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2790_2791 : H12AffineEnvironment.transform 13 2097 env2790 = env2791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2097 env2790 == env2791) = true)

theorem identity2791 : scanCanonicalize (H12AffineFastState.compose env2791 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound2791 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env2792 : List Nat := [2,4,8,16,32,64,128,172,512,116,2048,4096,73,2097,16,50,2248,2264,117,16,65,32,185,34,193,233,2296,2096,4345,2080,117,0,173,0,2248,680]

theorem envBound2792 : H12AffineFastState.Bounded env2792 := by
  intro p hp
  have h : env2792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2791_2792 : H12AffineEnvironment.transform 9 116 env2791 = env2792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env2791 == env2792) = true)

theorem identity2792 : scanCanonicalize (H12AffineFastState.compose env2792 (packedSelected [0,1,3,5,7,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 2296) := by decide +kernel

theorem selectedBound2792 : packedSelected [0,1,3,5,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env2793 : List Nat := [2,4,8,16,32,64,128,172,512,116,2048,2296,73,2097,16,50,2248,2264,117,16,65,32,185,34,193,233,2296,2096,2049,2080,117,0,173,0,2248,680]

theorem envBound2793 : H12AffineFastState.Bounded env2793 := by
  intro p hp
  have h : env2793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2792_2793 : H12AffineEnvironment.transform 11 2296 env2792 = env2793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2296 env2792 == env2793) = true)

theorem identity2793 : scanCanonicalize (H12AffineFastState.compose env2793 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2793 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env2794 : List Nat := [2,4,8,16,32,64,120,84,512,116,2048,2048,73,2097,16,50,2096,2080,117,16,65,32,65,34,57,17,2048,2096,2049,2080,117,0,85,0,2096,592]

theorem envBound2794 : H12AffineFastState.Bounded env2794 := by
  intro p hp
  have h : env2794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2793_2794 : H12AffineEnvironment.transform 6 120 env2793 = env2794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2793 == env2794) = true)

def env2795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16385,151552,2080,16852468,4341977,257,0,131073,16925299]

theorem envBound2795 : H12AffineFastState.Bounded env2795 := by
  intro p hp
  have h : env2795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2779_2795 : H12AffineEnvironment.transform 34 131073 env2779 = env2795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2779 == env2795) = true)

theorem identity2795 : scanCanonicalize (H12AffineFastState.compose env2795 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 225614) := by decide +kernel

theorem selectedBound2795 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,225614,147520,16777216,8328,147472,409817,16385,151552,2080,16852468,78231,257,0,131073,16925299]

theorem envBound2796 : H12AffineFastState.Bounded env2796 := by
  intro p hp
  have h : env2796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2795_2796 : H12AffineEnvironment.transform 21 225614 env2795 = env2796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 225614 env2795 == env2796) = true)

theorem identity2796 : scanCanonicalize (H12AffineFastState.compose env2796 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 94314) := by decide +kernel

theorem selectedBound2796 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,94314,262144,1025,8693,2097152,292,77866,16777216,8328,77946,340147,16385,73834,2080,16852468,78231,257,0,94315,16855577]

theorem envBound2797 : H12AffineFastState.Bounded env2797 := by
  intro p hp
  have h : env2797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2796_2797 : H12AffineEnvironment.transform 16 94314 env2796 = env2797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 94314 env2796 == env2797) = true)

def env2798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,94314,262144,1025,8693,2097152,292,77866,77848,8328,77946,340147,16385,73834,2080,5612,78231,257,0,94315,513]

theorem envBound2798 : H12AffineFastState.Bounded env2798 := by
  intro p hp
  have h : env2798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2797_2798 : H12AffineEnvironment.transform 23 77848 env2797 = env2798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 77848 env2797 == env2798) = true)

theorem identity2798 : scanCanonicalize (H12AffineFastState.compose env2798 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4436) := by decide +kernel

theorem selectedBound2798 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,94314,262144,1025,8693,4436,292,77866,77848,8328,77946,340147,16385,73834,2080,5612,78231,257,0,94315,513]

theorem envBound2799 : H12AffineFastState.Bounded env2799 := by
  intro p hp
  have h : env2799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2798_2799 : H12AffineEnvironment.transform 20 4436 env2798 = env2799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4436 env2798 == env2799) = true)

theorem identity2799 : scanCanonicalize (H12AffineFastState.compose env2799 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound2799 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,90243,262144,1025,8693,445,292,73923,73969,8328,73875,335962,16385,73834,2080,1285,74110,257,0,90242,513]

theorem envBound2800 : H12AffineFastState.Bounded env2800 := by
  intro p hp
  have h : env2800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2799_2800 : H12AffineEnvironment.transform 11 233 env2799 = env2800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env2799 == env2800) = true)

theorem identity2800 : scanCanonicalize (H12AffineFastState.compose env2800 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2800 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2801 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,233,8192,16384,8201,65536,90243,262144,1025,8201,65,216,73923,73969,8328,73875,335962,16385,73834,2080,1273,73858,253,0,90242,513]

theorem envBound2801 : H12AffineFastState.Bounded env2801 := by
  intro p hp
  have h : env2801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2800_2801 : H12AffineEnvironment.transform 7 252 env2800 = env2801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2800 == env2801) = true)

theorem identity2801 : scanCanonicalize (H12AffineFastState.compose env2801 (packedSelected [17,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound2801 : packedSelected [17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env2802 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,233,8192,16384,8201,8322,16385,262144,1025,8201,65,216,65,115,8328,17,262360,16385,232,2080,1273,0,253,0,16384,513]

theorem envBound2802 : H12AffineFastState.Bounded env2802 := by
  intro p hp
  have h : env2802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2801_2802 : H12AffineEnvironment.transform 15 8322 env2801 = env2802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env2801 == env2802) = true)

theorem identity2802 : scanCanonicalize (H12AffineFastState.compose env2802 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound2802 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2803 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,233,8192,81,8201,8322,80,262144,1025,8201,65,216,65,115,8328,17,262360,80,232,2080,1273,0,253,0,81,513]

theorem envBound2803 : H12AffineFastState.Bounded env2803 := by
  intro p hp
  have h : env2803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2802_2803 : H12AffineEnvironment.transform 13 81 env2802 = env2803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env2802 == env2803) = true)

theorem identity2803 : scanCanonicalize (H12AffineFastState.compose env2803 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 1036) := by decide +kernel

theorem selectedBound2803 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2804 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,233,1036,81,1029,1166,80,262144,1025,1029,65,216,65,115,1156,17,262360,80,232,2080,1273,0,253,0,81,513]

theorem envBound2804 : H12AffineFastState.Bounded env2804 := by
  intro p hp
  have h : env2804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2803_2804 : H12AffineEnvironment.transform 12 1036 env2803 = env2804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1036 env2803 == env2804) = true)

theorem identity2804 : scanCanonicalize (H12AffineFastState.compose env2804 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound2804 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env2805 : List Nat := [2,4,8,16,32,64,128,252,512,1024,33,233,1036,81,1029,1166,80,262144,1025,1029,65,216,65,115,1156,17,262360,80,232,1,1273,0,253,0,81,513]

theorem envBound2805 : H12AffineFastState.Bounded env2805 := by
  intro p hp
  have h : env2805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2804_2805 : H12AffineEnvironment.transform 10 33 env2804 = env2805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env2804 == env2805) = true)

theorem identity2805 : scanCanonicalize (H12AffineFastState.compose env2805 (packedSelected [0,2,9] rootPS)) = affineNative (2^(17+1) ^^^ 522) := by decide +kernel

theorem selectedBound2805 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env2806 : List Nat := [2,4,8,16,32,64,128,252,512,1024,33,233,1036,81,1029,1166,80,522,1025,1029,65,216,65,115,1156,17,722,80,232,1,1273,0,253,0,81,513]

theorem envBound2806 : H12AffineFastState.Bounded env2806 := by
  intro p hp
  have h : env2806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2805_2806 : H12AffineEnvironment.transform 17 522 env2805 = env2806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 522 env2805 == env2806) = true)

theorem identity2806 : scanCanonicalize (H12AffineFastState.compose env2806 (packedSelected [0,1,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2806 : packedSelected [0,1,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env2807 : List Nat := [2,4,8,16,32,64,128,252,512,4,33,233,8,81,1,138,80,522,5,1,65,216,65,115,128,17,722,80,232,1,253,0,253,0,81,513]

theorem envBound2807 : H12AffineFastState.Bounded env2807 := by
  intro p hp
  have h : env2807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2806_2807 : H12AffineEnvironment.transform 9 4 env2806 = env2807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2806 == env2807) = true)

theorem identity2807 : scanCanonicalize (H12AffineFastState.compose env2807 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 242) := by decide +kernel

theorem selectedBound2807 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env2808 : List Nat := [2,4,8,16,32,64,128,252,242,4,33,233,8,81,1,138,80,248,5,1,65,216,65,115,128,17,32,80,232,1,253,0,253,0,81,243]

theorem envBound2808 : H12AffineFastState.Bounded env2808 := by
  intro p hp
  have h : env2808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2807_2808 : H12AffineEnvironment.transform 8 242 env2807 = env2808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 242 env2807 == env2808) = true)

theorem identity2808 : scanCanonicalize (H12AffineFastState.compose env2808 (packedSelected [0,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2808 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env2809 : List Nat := [2,4,8,16,32,64,120,4,10,4,33,17,8,81,1,114,80,0,5,1,65,32,65,115,120,17,32,80,16,1,5,0,5,0,81,11]

theorem envBound2809 : H12AffineFastState.Bounded env2809 := by
  intro p hp
  have h : env2809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2808_2809 : H12AffineEnvironment.transform 6 120 env2808 = env2809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2808 == env2809) = true)

theorem identity2809 : scanCanonicalize (H12AffineFastState.compose env2809 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2809 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2810 : List Nat := [2,4,8,16,1,64,89,4,10,4,0,17,8,81,1,83,80,0,5,1,65,1,65,82,89,17,1,80,16,1,5,0,5,0,81,11]

theorem envBound2810 : H12AffineFastState.Bounded env2810 := by
  intro p hp
  have h : env2810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2809_2810 : H12AffineEnvironment.transform 4 1 env2809 = env2810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2809 == env2810) = true)

theorem identity2810 : scanCanonicalize (H12AffineFastState.compose env2810 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound2810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2811 : List Nat := [0,4,8,16,1,64,89,4,8,4,0,17,8,81,1,81,80,0,5,1,65,1,65,80,89,17,1,80,16,1,5,0,5,0,81,9]

theorem envBound2811 : H12AffineFastState.Bounded env2811 := by
  intro p hp
  have h : env2811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2810_2811 : H12AffineEnvironment.transform 0 0 env2810 = env2811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env2810 == env2811) = true)

theorem identity2811 : scanCanonicalize (H12AffineFastState.compose env2811 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2811 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2812 : List Nat := [0,4,8,16,1,1,24,4,8,4,0,17,8,16,1,16,17,0,5,1,0,1,0,17,24,17,1,17,16,1,5,0,5,0,16,9]

theorem envBound2812 : H12AffineFastState.Bounded env2812 := by
  intro p hp
  have h : env2812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2811_2812 : H12AffineEnvironment.transform 5 1 env2811 = env2812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2811 == env2812) = true)

theorem identity2812 : scanCanonicalize (H12AffineFastState.compose env2812 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2812 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2813 : List Nat := [0,4,8,1,1,1,9,4,8,4,0,0,8,1,1,1,0,0,5,1,0,1,0,0,9,0,1,0,1,1,5,0,5,0,1,9]

theorem envBound2813 : H12AffineFastState.Bounded env2813 := by
  intro p hp
  have h : env2813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2812_2813 : H12AffineEnvironment.transform 3 1 env2812 = env2813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2812 == env2813) = true)

theorem identity2813 : scanCanonicalize (H12AffineFastState.compose env2813 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound2813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2814 : List Nat := [0,1,8,1,1,1,9,1,8,1,0,0,8,1,1,1,0,0,0,1,0,1,0,0,9,0,1,0,1,1,0,0,0,0,1,9]

theorem envBound2814 : H12AffineFastState.Bounded env2814 := by
  intro p hp
  have h : env2814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2813_2814 : H12AffineEnvironment.transform 1 1 env2813 = env2814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env2813 == env2814) = true)

def env2815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,94314,262144,1025,8693,2097152,292,77866,77849,8328,77946,340147,16385,73834,2080,5613,78231,257,0,94315,512]

theorem envBound2815 : H12AffineFastState.Bounded env2815 := by
  intro p hp
  have h : env2815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2797_2815 : H12AffineEnvironment.transform 23 77849 env2797 = env2815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 77849 env2797 == env2815) = true)

theorem identity2815 : scanCanonicalize (H12AffineFastState.compose env2815 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2815 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2816 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,65536,94314,262144,1025,8433,2097152,32,77866,77849,8328,77946,340147,16385,73834,2080,5353,77971,5,0,94315,512]

theorem envBound2816 : H12AffineFastState.Bounded env2816 := by
  intro p hp
  have h : env2816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2815_2816 : H12AffineEnvironment.transform 7 4 env2815 = env2816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2815 == env2816) = true)

theorem identity2816 : scanCanonicalize (H12AffineFastState.compose env2816 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound2816 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2817 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,20497,262144,1025,8433,2097152,32,4177,4194,8328,4097,266440,16385,17,2080,5353,4328,5,0,20496,512]

theorem envBound2817 : H12AffineFastState.Bounded env2817 := by
  intro p hp
  have h : env2817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2816_2817 : H12AffineEnvironment.transform 15 8315 env2816 = env2817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env2816 == env2817) = true)

theorem identity2817 : scanCanonicalize (H12AffineFastState.compose env2817 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound2817 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2818 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8433,8315,16632,262144,1025,8433,2097152,32,184,139,8328,232,262177,16385,17,2080,1024,1,5,0,16633,512]

theorem envBound2818 : H12AffineFastState.Bounded env2818 := by
  intro p hp
  have h : env2818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2817_2818 : H12AffineEnvironment.transform 11 233 env2817 = env2818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env2817 == env2818) = true)

theorem identity2818 : scanCanonicalize (H12AffineFastState.compose env2818 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 271479) := by decide +kernel

theorem selectedBound2818 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2819 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8433,8315,16632,262144,1025,8433,271479,32,184,139,8328,232,262177,16385,17,2080,1024,1,5,0,16633,512]

theorem envBound2819 : H12AffineFastState.Bounded env2819 := by
  intro p hp
  have h : env2819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2818_2819 : H12AffineEnvironment.transform 20 271479 env2818 = env2819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 271479 env2818 == env2819) = true)

theorem identity2819 : scanCanonicalize (H12AffineFastState.compose env2819 (packedSelected [3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound2819 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2820 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,16,8192,16384,8200,8315,16385,262144,1025,8200,271479,32,65,114,8305,17,262177,16385,17,2080,1024,1,5,0,16384,512]

theorem envBound2820 : H12AffineFastState.Bounded env2820 := by
  intro p hp
  have h : env2820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2819_2820 : H12AffineEnvironment.transform 6 121 env2819 = env2820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env2819 == env2820) = true)

theorem identity2820 : scanCanonicalize (H12AffineFastState.compose env2820 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 1151) := by decide +kernel

theorem selectedBound2820 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2821 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,16,8192,16384,8200,8315,16385,1151,1025,8200,8200,32,65,114,8305,17,1118,16385,17,2080,1024,1,5,0,16384,512]

theorem envBound2821 : H12AffineFastState.Bounded env2821 := by
  intro p hp
  have h : env2821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2820_2821 : H12AffineEnvironment.transform 17 1151 env2820 = env2821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1151 env2820 == env2821) = true)

theorem identity2821 : scanCanonicalize (H12AffineFastState.compose env2821 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound2821 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2822 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,16,9,16384,1,114,16385,1151,1025,1,1,32,65,114,120,17,1118,16385,17,2080,1024,1,5,0,16384,512]

theorem envBound2822 : H12AffineFastState.Bounded env2822 := by
  intro p hp
  have h : env2822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2821_2822 : H12AffineEnvironment.transform 12 9 env2821 = env2822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env2821 == env2822) = true)

theorem identity2822 : scanCanonicalize (H12AffineFastState.compose env2822 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound2822 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2823 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,16,9,1093,1,114,1092,1151,1025,1,1,32,65,114,120,17,1118,1092,17,2080,1024,1,5,0,1093,512]

theorem envBound2823 : H12AffineFastState.Bounded env2823 := by
  intro p hp
  have h : env2823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2822_2823 : H12AffineEnvironment.transform 13 1093 env2822 = env2823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env2822 == env2823) = true)

theorem identity2823 : scanCanonicalize (H12AffineFastState.compose env2823 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2823 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env2824 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,16,9,1044,1,35,1045,1070,1025,1,1,32,16,35,41,17,1039,1045,17,2080,1024,1,5,0,1044,512]

theorem envBound2824 : H12AffineFastState.Bounded env2824 := by
  intro p hp
  have h : env2824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2823_2824 : H12AffineEnvironment.transform 5 17 env2823 = env2824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2823 == env2824) = true)

theorem identity2824 : scanCanonicalize (H12AffineFastState.compose env2824 (packedSelected [1,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound2824 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env2825 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1039,16,9,1044,1,35,1045,1070,1025,1,1,32,16,35,41,17,1039,1045,17,1071,1024,1,5,0,1044,512]

theorem envBound2825 : H12AffineFastState.Bounded env2825 := by
  intro p hp
  have h : env2825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2824_2825 : H12AffineEnvironment.transform 10 1039 env2824 = env2825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env2824 == env2825) = true)

theorem identity2825 : scanCanonicalize (H12AffineFastState.compose env2825 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound2825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2826 : List Nat := [2,4,8,16,17,17,25,4,512,1024,1039,16,9,1044,1,18,1045,1055,1025,1,1,17,16,18,24,17,1039,1045,17,1054,1024,1,5,0,1044,512]

theorem envBound2826 : H12AffineFastState.Bounded env2826 := by
  intro p hp
  have h : env2826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2825_2826 : H12AffineEnvironment.transform 4 17 env2825 = env2826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2825 == env2826) = true)

theorem identity2826 : scanCanonicalize (H12AffineFastState.compose env2826 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound2826 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2827 : List Nat := [2,4,8,11,10,10,2,4,512,1024,1039,11,9,1039,1,9,1038,1028,1025,1,1,10,11,9,3,10,1039,1038,10,1029,1024,1,5,0,1039,512]

theorem envBound2827 : H12AffineFastState.Bounded env2827 := by
  intro p hp
  have h : env2827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2826_2827 : H12AffineEnvironment.transform 3 11 env2826 = env2827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env2826 == env2827) = true)

theorem identity2827 : scanCanonicalize (H12AffineFastState.compose env2827 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2827 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2828 : List Nat := [2,4,8,11,10,10,2,4,512,4,11,11,9,11,1,9,10,0,5,1,1,10,11,9,3,10,11,10,10,1,4,1,5,0,11,512]

theorem envBound2828 : H12AffineFastState.Bounded env2828 := by
  intro p hp
  have h : env2828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2827_2828 : H12AffineEnvironment.transform 9 4 env2827 = env2828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2827 == env2828) = true)

theorem identity2828 : scanCanonicalize (H12AffineFastState.compose env2828 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound2828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2829 : List Nat := [2,4,8,11,10,10,2,4,13,4,11,11,9,11,1,9,10,0,5,1,1,10,11,9,3,10,11,10,10,1,4,1,5,0,11,13]

theorem envBound2829 : H12AffineFastState.Bounded env2829 := by
  intro p hp
  have h : env2829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2828_2829 : H12AffineEnvironment.transform 8 13 env2828 = env2829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env2828 == env2829) = true)

def env2830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147521,16777216,8328,672784,935129,16385,151552,2080,17375733,4867289,525568,0,34359738368,17450611]

theorem envBound2830 : H12AffineFastState.Bounded env2830 := by
  intro p hp
  have h : env2830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2726_2830 : H12AffineEnvironment.transform 22 147521 env2726 = env2830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env2726 == env2830) = true)

def env2831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16385,151552,2080,16852469,4341977,256,0,34359738368,16925299]

theorem envBound2831 : H12AffineFastState.Bounded env2831 := by
  intro p hp
  have h : env2831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2830_2831 : H12AffineEnvironment.transform 18 1024 env2830 = env2831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2830 == env2831) = true)

def env2832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16385,151552,2080,16852469,4341977,256,0,131072,16925299]

theorem envBound2832 : H12AffineFastState.Bounded env2832 := by
  intro p hp
  have h : env2832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2831_2832 : H12AffineEnvironment.transform 34 131072 env2831 = env2832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2831 == env2832) = true)

theorem identity2832 : scanCanonicalize (H12AffineFastState.compose env2832 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2176095) := by decide +kernel

theorem selectedBound2832 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2176095,147521,16777216,8328,147472,409817,16385,151552,2080,16852469,2323590,256,0,131072,16925299]

theorem envBound2833 : H12AffineFastState.Bounded env2833 := by
  intro p hp
  have h : env2833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2832_2833 : H12AffineEnvironment.transform 21 2176095 env2832 = env2833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2176095 env2832 == env2833) = true)

theorem identity2833 : scanCanonicalize (H12AffineFastState.compose env2833 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 139) := by decide +kernel

theorem selectedBound2833 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2176095,147521,139,8328,147472,409817,16385,151552,2080,75134,2323590,256,0,131072,148216]

theorem envBound2834 : H12AffineFastState.Bounded env2834 := by
  intro p hp
  have h : env2834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2833_2834 : H12AffineEnvironment.transform 23 139 env2833 = env2834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 139 env2833 == env2834) = true)

def env2835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16632,262144,1024,8693,2097152,2176095,185,139,8328,232,262177,16385,4344,2080,75134,2176126,256,0,16632,512]

theorem envBound2835 : H12AffineFastState.Bounded env2835 := by
  intro p hp
  have h : env2835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2834_2835 : H12AffineEnvironment.transform 16 16632 env2834 = env2835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2834 == env2835) = true)

theorem identity2835 : scanCanonicalize (H12AffineFastState.compose env2835 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 78974) := by decide +kernel

theorem selectedBound2835 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16632,262144,1024,8693,78974,33,185,139,8328,232,262177,16385,4344,2080,75134,0,256,0,16632,512]

theorem envBound2836 : H12AffineFastState.Bounded env2836 := by
  intro p hp
  have h : env2836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2835_2836 : H12AffineEnvironment.transform 20 78974 env2835 = env2836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78974 env2835 == env2836) = true)

theorem identity2836 : scanCanonicalize (H12AffineFastState.compose env2836 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2836 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env2837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1024,8693,5376,33,185,139,8328,232,262177,16385,4344,2080,1024,0,256,0,16632,512]

theorem envBound2837 : H12AffineFastState.Bounded env2837 := by
  intro p hp
  have h : env2837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2836_2837 : H12AffineEnvironment.transform 15 8574 env2836 = env2837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2836 == env2837) = true)

def env2838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16633,262144,1024,8693,2097152,2176095,184,139,8328,233,262176,16385,4345,2080,75134,2176127,256,0,16633,513]

theorem envBound2838 : H12AffineFastState.Bounded env2838 := by
  intro p hp
  have h : env2838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2834_2838 : H12AffineEnvironment.transform 16 16633 env2834 = env2838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2834 == env2838) = true)

theorem identity2838 : scanCanonicalize (H12AffineFastState.compose env2838 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound2838 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9263,16633,262144,1024,8693,2097152,2101360,184,139,8328,233,262176,16385,4345,2080,337,2101328,256,0,16633,513]

theorem envBound2839 : H12AffineFastState.Bounded env2839 := by
  intro p hp
  have h : env2839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2838_2839 : H12AffineEnvironment.transform 15 9263 env2838 = env2839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env2838 == env2839) = true)

theorem identity2839 : scanCanonicalize (H12AffineFastState.compose env2839 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 4265) := by decide +kernel

theorem selectedBound2839 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env2840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9263,16633,262144,1024,8693,4265,217,184,139,8328,233,262176,16385,4345,2080,337,249,256,0,16633,513]

theorem envBound2840 : H12AffineFastState.Bounded env2840 := by
  intro p hp
  have h : env2840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2839_2840 : H12AffineEnvironment.transform 20 4265 env2839 = env2840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4265 env2839 == env2840) = true)

theorem identity2840 : scanCanonicalize (H12AffineFastState.compose env2840 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound2840 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2841 : List Nat := [2,4,8,16,32,64,128,256,512,425,2048,4096,8192,16384,8693,8582,16633,262144,425,8693,4265,217,184,139,8328,233,262176,16385,4345,2080,337,249,256,0,16633,513]

theorem envBound2841 : H12AffineFastState.Bounded env2841 := by
  intro p hp
  have h : env2841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2840_2841 : H12AffineEnvironment.transform 9 425 env2840 = env2841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env2840 == env2841) = true)

theorem identity2841 : scanCanonicalize (H12AffineFastState.compose env2841 (packedSelected [13,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2841 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2842 : List Nat := [2,4,8,16,32,64,40,256,512,257,2048,4096,8192,16384,8541,8494,16465,262144,257,8541,4097,113,16,35,8224,65,262176,16385,4177,2080,337,81,256,0,16465,513]

theorem envBound2842 : H12AffineFastState.Bounded env2842 := by
  intro p hp
  have h : env2842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2841_2842 : H12AffineEnvironment.transform 6 40 env2841 = env2842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2841 == env2842) = true)

theorem identity2842 : scanCanonicalize (H12AffineFastState.compose env2842 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 22820) := by decide +kernel

theorem selectedBound2842 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env2843 : List Nat := [2,4,8,16,32,64,40,256,512,257,2048,4096,8192,16384,8541,8494,16465,22820,257,8541,4097,113,16,35,8224,65,22788,16385,4177,2080,337,81,256,0,16465,513]

theorem envBound2843 : H12AffineFastState.Bounded env2843 := by
  intro p hp
  have h : env2843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2842_2843 : H12AffineEnvironment.transform 17 22820 env2842 = env2843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22820 env2842 == env2843) = true)

theorem identity2843 : scanCanonicalize (H12AffineFastState.compose env2843 (packedSelected [1,2,3,5,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 14425) := by decide +kernel

theorem selectedBound2843 : packedSelected [1,2,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env2844 : List Nat := [2,4,8,16,32,64,40,256,512,257,2048,4096,8192,14425,8541,8494,14344,8573,257,8541,4097,113,16,35,8224,65,8541,14424,4177,2080,337,81,256,0,14344,513]

theorem envBound2844 : H12AffineFastState.Bounded env2844 := by
  intro p hp
  have h : env2844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2843_2844 : H12AffineEnvironment.transform 13 14425 env2843 = env2844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14425 env2843 == env2844) = true)

theorem identity2844 : scanCanonicalize (H12AffineFastState.compose env2844 (packedSelected [1,2,6,8,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2121) := by decide +kernel

theorem selectedBound2844 : packedSelected [1,2,6,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env2845 : List Nat := [2,4,8,16,32,64,40,256,512,257,2048,4096,2121,4112,2324,2407,4161,2356,257,2324,4097,113,16,35,2153,65,2324,4113,4177,2080,337,81,256,0,4161,513]

theorem envBound2845 : H12AffineFastState.Bounded env2845 := by
  intro p hp
  have h : env2845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2844_2845 : H12AffineEnvironment.transform 12 2121 env2844 = env2845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2121 env2844 == env2845) = true)

theorem identity2845 : scanCanonicalize (H12AffineFastState.compose env2845 (packedSelected [2,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2845 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env2846 : List Nat := [2,4,8,16,32,0,40,256,512,257,2048,4096,2057,4112,2324,2343,4097,2356,257,2324,4097,49,16,35,2089,1,2324,4113,4113,2080,273,17,256,0,4097,513]

theorem envBound2846 : H12AffineFastState.Bounded env2846 := by
  intro p hp
  have h : env2846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2845_2846 : H12AffineEnvironment.transform 5 0 env2845 = env2846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2845 == env2846) = true)

theorem identity2846 : scanCanonicalize (H12AffineFastState.compose env2846 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound2846 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2847 : List Nat := [2,4,8,16,32,0,40,256,512,257,16,4096,25,4112,260,311,4097,292,257,260,4097,49,16,35,57,1,260,4113,4113,48,273,17,256,0,4097,513]

theorem envBound2847 : H12AffineFastState.Bounded env2847 := by
  intro p hp
  have h : env2847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2846_2847 : H12AffineEnvironment.transform 10 16 env2846 = env2847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env2846 == env2847) = true)

theorem identity2847 : scanCanonicalize (H12AffineFastState.compose env2847 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 525) := by decide +kernel

theorem selectedBound2847 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env2848 : List Nat := [2,4,8,16,32,0,40,256,512,257,16,525,25,541,260,311,524,292,257,260,524,49,16,35,57,1,260,540,540,48,273,17,256,0,524,513]

theorem envBound2848 : H12AffineFastState.Bounded env2848 := by
  intro p hp
  have h : env2848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2847_2848 : H12AffineEnvironment.transform 11 525 env2847 = env2848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 525 env2847 == env2848) = true)

theorem identity2848 : scanCanonicalize (H12AffineFastState.compose env2848 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound2848 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env2849 : List Nat := [2,4,8,16,32,0,40,256,28,257,16,17,25,1,260,311,16,292,257,260,16,49,16,35,57,1,260,0,0,48,273,17,256,0,16,29]

theorem envBound2849 : H12AffineFastState.Bounded env2849 := by
  intro p hp
  have h : env2849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2848_2849 : H12AffineEnvironment.transform 8 28 env2848 = env2849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env2848 == env2849) = true)

theorem identity2849 : scanCanonicalize (H12AffineFastState.compose env2849 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound2849 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env2850 : List Nat := [2,4,8,16,32,0,40,6,28,7,16,17,25,1,2,49,16,34,7,2,16,49,16,35,57,1,2,0,0,48,23,17,6,0,16,29]

theorem envBound2850 : H12AffineFastState.Bounded env2850 := by
  intro p hp
  have h : env2850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2849_2850 : H12AffineEnvironment.transform 7 6 env2849 = env2850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env2849 == env2850) = true)

theorem identity2850 : scanCanonicalize (H12AffineFastState.compose env2850 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound2850 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2851 : List Nat := [2,0,8,16,32,0,40,2,24,3,16,17,25,1,2,49,16,34,3,2,16,49,16,35,57,1,2,0,0,48,19,17,2,0,16,25]

theorem envBound2851 : H12AffineFastState.Bounded env2851 := by
  intro p hp
  have h : env2851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2850_2851 : H12AffineEnvironment.transform 1 0 env2850 = env2851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env2850 == env2851) = true)

theorem identity2851 : scanCanonicalize (H12AffineFastState.compose env2851 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound2851 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env2852 : List Nat := [2,0,8,16,0,0,8,2,24,3,16,17,25,1,2,17,16,2,3,2,16,17,16,3,25,1,2,0,0,16,19,17,2,0,16,25]

theorem envBound2852 : H12AffineFastState.Bounded env2852 := by
  intro p hp
  have h : env2852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2851_2852 : H12AffineEnvironment.transform 4 0 env2851 = env2852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env2851 == env2852) = true)

theorem identity2852 : scanCanonicalize (H12AffineFastState.compose env2852 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound2852 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2853 : List Nat := [2,0,8,2,0,0,8,2,10,3,2,3,11,1,2,3,2,2,3,2,2,3,2,3,11,1,2,0,0,2,1,3,2,0,2,11]

theorem envBound2853 : H12AffineFastState.Bounded env2853 := by
  intro p hp
  have h : env2853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2852_2853 : H12AffineEnvironment.transform 3 2 env2852 = env2853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env2852 == env2853) = true)

theorem identity2853 : scanCanonicalize (H12AffineFastState.compose env2853 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound2853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2854 : List Nat := [2,0,0,2,0,0,0,2,2,3,2,3,3,1,2,3,2,2,3,2,2,3,2,3,3,1,2,0,0,2,1,3,2,0,2,3]

theorem envBound2854 : H12AffineFastState.Bounded env2854 := by
  intro p hp
  have h : env2854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2853_2854 : H12AffineEnvironment.transform 2 0 env2853 = env2854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env2853 == env2854) = true)

theorem identity2854 : scanCanonicalize (H12AffineFastState.compose env2854 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound2854 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env2855 : List Nat := [1,0,0,1,0,0,0,1,1,0,1,0,0,1,1,0,1,1,0,1,1,0,1,0,0,1,1,0,0,1,1,0,1,0,1,0]

theorem envBound2855 : H12AffineFastState.Bounded env2855 := by
  intro p hp
  have h : env2855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2854_2855 : H12AffineEnvironment.transform 0 1 env2854 = env2855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env2854 == env2855) = true)

def env2856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16385,151552,2080,16852469,4341977,256,0,131073,16925299]

theorem envBound2856 : H12AffineFastState.Bounded env2856 := by
  intro p hp
  have h : env2856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2831_2856 : H12AffineEnvironment.transform 34 131073 env2831 = env2856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2831 == env2856) = true)

theorem identity2856 : scanCanonicalize (H12AffineFastState.compose env2856 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 74846) := by decide +kernel

theorem selectedBound2856 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,74846,147521,16777216,8328,147472,409817,16385,151552,2080,16852469,222343,256,0,131073,16925299]

theorem envBound2857 : H12AffineFastState.Bounded env2857 := by
  intro p hp
  have h : env2857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2856_2857 : H12AffineEnvironment.transform 21 74846 env2856 = env2857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74846 env2856 == env2857) = true)

theorem identity2857 : scanCanonicalize (H12AffineFastState.compose env2857 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 1419) := by decide +kernel

theorem selectedBound2857 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,74846,147521,1419,8328,147472,409817,16385,151552,2080,73854,222343,256,0,131073,149496]

theorem envBound2858 : H12AffineFastState.Bounded env2858 := by
  intro p hp
  have h : env2858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2857_2858 : H12AffineEnvironment.transform 23 1419 env2857 = env2858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 1419 env2857 == env2858) = true)

theorem identity2858 : scanCanonicalize (H12AffineFastState.compose env2858 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 17912) := by decide +kernel

theorem selectedBound2858 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,17912,262144,1024,8693,2097152,74846,1465,1419,8328,1512,263457,16385,5624,2080,73854,74111,256,0,17913,512]

theorem envBound2859 : H12AffineFastState.Bounded env2859 := by
  intro p hp
  have h : env2859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2858_2859 : H12AffineEnvironment.transform 16 17912 env2858 = env2859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17912 env2858 == env2859) = true)

theorem identity2859 : scanCanonicalize (H12AffineFastState.compose env2859 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 9343) := by decide +kernel

theorem selectedBound2859 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9343,17912,262144,1024,8693,2097152,33,1465,1419,8328,1512,263457,16385,5624,2080,1025,1280,256,0,17913,512]

theorem envBound2860 : H12AffineFastState.Bounded env2860 := by
  intro p hp
  have h : env2860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2859_2860 : H12AffineEnvironment.transform 15 9343 env2859 = env2860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9343 env2859 == env2860) = true)

theorem identity2860 : scanCanonicalize (H12AffineFastState.compose env2860 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound2860 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2861 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,8574,16633,262144,257,8693,2097152,33,184,138,8328,233,262176,16385,4345,2080,256,1,256,0,16632,512]

theorem envBound2861 : H12AffineFastState.Bounded env2861 := by
  intro p hp
  have h : env2861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2860_2861 : H12AffineEnvironment.transform 9 257 env2860 = env2861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env2860 == env2861) = true)

theorem identity2861 : scanCanonicalize (H12AffineFastState.compose env2861 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound2861 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2862 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,8574,16633,2080,257,8693,2097152,33,184,138,8328,233,2048,16385,4345,2080,256,1,256,0,16632,512]

theorem envBound2862 : H12AffineFastState.Bounded env2862 := by
  intro p hp
  have h : env2862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2861_2862 : H12AffineEnvironment.transform 17 2080 env2861 = env2862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env2861 == env2862) = true)

theorem identity2862 : scanCanonicalize (H12AffineFastState.compose env2862 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2862 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2863 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,16384,8201,8322,16633,2080,253,8201,2097152,33,184,138,8328,233,2048,16385,4345,2080,252,1,252,0,16632,512]

theorem envBound2863 : H12AffineFastState.Bounded env2863 := by
  intro p hp
  have h : env2863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2862_2863 : H12AffineEnvironment.transform 7 252 env2862 = env2863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2862 == env2863) = true)

theorem identity2863 : scanCanonicalize (H12AffineFastState.compose env2863 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26674) := by decide +kernel

theorem selectedBound2863 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env2864 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,16384,8201,8322,16633,2080,253,8201,26674,33,184,138,8328,233,2048,16385,4345,2080,252,1,252,0,16632,512]

theorem envBound2864 : H12AffineFastState.Bounded env2864 := by
  intro p hp
  have h : env2864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2863_2864 : H12AffineEnvironment.transform 20 26674 env2863 = env2864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26674 env2863 == env2864) = true)

theorem identity2864 : scanCanonicalize (H12AffineFastState.compose env2864 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12497) := by decide +kernel

theorem selectedBound2864 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2865 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,12497,8201,8322,12328,2080,253,8201,6371,33,184,138,8328,233,2048,12496,4345,2080,252,1,252,0,12329,512]

theorem envBound2865 : H12AffineFastState.Bounded env2865 := by
  intro p hp
  have h : env2865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2864_2865 : H12AffineEnvironment.transform 13 12497 env2864 = env2865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12497 env2864 == env2865) = true)

theorem identity2865 : scanCanonicalize (H12AffineFastState.compose env2865 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound2865 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env2866 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,2283,6202,2274,2153,6339,2080,253,2274,6371,33,184,138,2147,233,2048,6203,4345,2080,252,1,252,0,6338,512]

theorem envBound2866 : H12AffineFastState.Bounded env2866 := by
  intro p hp
  have h : env2866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2865_2866 : H12AffineEnvironment.transform 12 2283 env2865 = env2866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env2865 == env2866) = true)

theorem identity2866 : scanCanonicalize (H12AffineFastState.compose env2866 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound2866 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env2867 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,2217,2283,147,2274,2153,106,2080,253,2274,74,33,184,138,2147,233,2048,146,2128,2080,252,1,252,0,107,512]

theorem envBound2867 : H12AffineFastState.Bounded env2867 := by
  intro p hp
  have h : env2867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2866_2867 : H12AffineEnvironment.transform 11 2217 env2866 = env2867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env2866 == env2867) = true)

theorem identity2867 : scanCanonicalize (H12AffineFastState.compose env2867 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound2867 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2868 : List Nat := [2,4,8,16,32,64,128,252,512,253,194,107,41,147,32,171,106,226,253,32,74,33,184,138,161,233,194,146,146,226,252,1,252,0,107,512]

theorem envBound2868 : H12AffineFastState.Bounded env2868 := by
  intro p hp
  have h : env2868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2867_2868 : H12AffineEnvironment.transform 10 194 env2867 = env2868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env2867 == env2868) = true)

theorem identity2868 : scanCanonicalize (H12AffineFastState.compose env2868 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound2868 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env2869 : List Nat := [2,4,8,16,32,64,18,110,512,111,80,107,41,1,32,57,106,112,111,32,74,33,42,24,51,123,80,0,0,112,110,1,110,0,107,512]

theorem envBound2869 : H12AffineFastState.Bounded env2869 := by
  intro p hp
  have h : env2869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2868_2869 : H12AffineEnvironment.transform 6 18 env2868 = env2869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env2868 == env2869) = true)

def env2870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2080,16852468,4341976,257,0,34359738368,16925298]

theorem envBound2870 : H12AffineFastState.Bounded env2870 := by
  intro p hp
  have h : env2870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2830_2870 : H12AffineEnvironment.transform 18 1025 env2830 = env2870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2830 == env2870) = true)

def env2871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2080,16852468,4341976,257,0,131072,16925298]

theorem envBound2871 : H12AffineFastState.Bounded env2871 := by
  intro p hp
  have h : env2871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2870_2871 : H12AffineEnvironment.transform 34 131072 env2870 = env2871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2870 == env2871) = true)

theorem identity2871 : scanCanonicalize (H12AffineFastState.compose env2871 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2306335) := by decide +kernel

theorem selectedBound2871 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2306335,147521,16777216,8328,147473,409816,16385,151552,2080,16852468,2191815,257,0,131072,16925298]

theorem envBound2872 : H12AffineFastState.Bounded env2872 := by
  intro p hp
  have h : env2872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2871_2872 : H12AffineEnvironment.transform 21 2306335 env2871 = env2872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2306335 env2871 == env2872) = true)

theorem identity2872 : scanCanonicalize (H12AffineFastState.compose env2872 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound2872 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,2097152,2232676,147521,16777216,8328,147473,409816,16385,151552,2080,16778639,2118076,257,0,131072,16925298]

theorem envBound2873 : H12AffineFastState.Bounded env2873 := by
  intro p hp
  have h : env2873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2872_2873 : H12AffineEnvironment.transform 15 8315 env2872 = env2873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env2872 == env2873) = true)

def env2874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,20924,147672,147521,16777216,8328,147473,409816,16385,151552,2080,16778639,0,257,0,131072,16925298]

theorem envBound2874 : H12AffineFastState.Bounded env2874 := by
  intro p hp
  have h : env2874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2873_2874 : H12AffineEnvironment.transform 20 20924 env2873 = env2874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20924 env2873 == env2874) = true)

theorem identity2874 : scanCanonicalize (H12AffineFastState.compose env2874 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147830) := by decide +kernel

theorem selectedBound2874 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,20924,147672,147521,147830,8328,147473,409816,16385,151552,2080,148729,0,257,0,131072,772]

theorem envBound2875 : H12AffineFastState.Bounded env2875 := by
  intro p hp
  have h : env2875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2874_2875 : H12AffineEnvironment.transform 23 147830 env2874 = env2875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147830 env2874 == env2875) = true)

theorem identity2875 : scanCanonicalize (H12AffineFastState.compose env2875 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound2875 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env2876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,2524,1025,8693,20924,147672,147521,147830,8328,147473,149764,16385,151552,2080,148729,0,257,0,131072,772]

theorem envBound2876 : H12AffineFastState.Bounded env2876 := by
  intro p hp
  have h : env2876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2875_2876 : H12AffineEnvironment.transform 17 2524 env2875 = env2876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env2875 == env2876) = true)

theorem identity2876 : scanCanonicalize (H12AffineFastState.compose env2876 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound2876 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env2877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16632,2524,1025,8693,20924,32,185,398,8328,233,2556,16385,4344,2080,1025,0,257,0,16632,772]

theorem envBound2877 : H12AffineFastState.Bounded env2877 := by
  intro p hp
  have h : env2877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2876_2877 : H12AffineEnvironment.transform 16 16632 env2876 = env2877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2876 == env2877) = true)

theorem identity2877 : scanCanonicalize (H12AffineFastState.compose env2877 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2877 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env2878 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8315,16632,2265,1025,8432,20665,32,185,139,8328,233,2297,16385,4344,2080,1025,0,4,0,16632,513]

theorem envBound2878 : H12AffineFastState.Bounded env2878 := by
  intro p hp
  have h : env2878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2877_2878 : H12AffineEnvironment.transform 7 5 env2877 = env2878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2877 == env2878) = true)

theorem identity2878 : scanCanonicalize (H12AffineFastState.compose env2878 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3766) := by decide +kernel

theorem selectedBound2878 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env2879 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,3766,8432,8315,3662,2265,1025,8432,7695,32,185,139,8328,233,2297,3767,4344,2080,1025,0,4,0,3662,513]

theorem envBound2879 : H12AffineFastState.Bounded env2879 := by
  intro p hp
  have h : env2879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2878_2879 : H12AffineEnvironment.transform 13 3766 env2878 = env2879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3766 env2878 == env2879) = true)

theorem identity2879 : scanCanonicalize (H12AffineFastState.compose env2879 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1751) := by decide +kernel

theorem selectedBound2879 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2880 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,4096,8192,97,8432,8315,153,1550,1025,8432,4312,32,185,139,8328,233,1582,96,4344,1783,1025,0,4,0,153,513]

theorem envBound2880 : H12AffineFastState.Bounded env2880 := by
  intro p hp
  have h : env2880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2879_2880 : H12AffineEnvironment.transform 10 1751 env2879 = env2880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1751 env2879 == env2880) = true)

theorem identity2880 : scanCanonicalize (H12AffineFastState.compose env2880 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1157) := by decide +kernel

theorem selectedBound2880 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2881 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,4096,1157,97,1141,1278,153,1550,1025,1141,4312,32,185,139,1037,233,1582,96,4344,1783,1025,0,4,0,153,513]

theorem envBound2881 : H12AffineFastState.Bounded env2881 := by
  intro p hp
  have h : env2881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2880_2881 : H12AffineEnvironment.transform 12 1157 env2880 = env2881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1157 env2880 == env2881) = true)

theorem identity2881 : scanCanonicalize (H12AffineFastState.compose env2881 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1751) := by decide +kernel

theorem selectedBound2881 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env2882 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,1751,1157,97,1141,1278,153,1550,1025,1141,1551,32,185,139,1037,233,1582,96,1583,1783,1025,0,4,0,153,513]

theorem envBound2882 : H12AffineFastState.Bounded env2882 := by
  intro p hp
  have h : env2882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2881_2882 : H12AffineEnvironment.transform 11 1751 env2881 = env2882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1751 env2881 == env2882) = true)

theorem identity2882 : scanCanonicalize (H12AffineFastState.compose env2882 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound2882 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env2883 : List Nat := [2,4,8,16,32,64,128,5,512,647,80,80,514,97,754,633,153,137,646,754,136,32,185,139,650,233,169,96,168,112,646,0,4,0,153,513]

theorem envBound2883 : H12AffineFastState.Bounded env2883 := by
  intro p hp
  have h : env2883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2882_2883 : H12AffineEnvironment.transform 9 647 env2882 = env2883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env2882 == env2883) = true)

theorem identity2883 : scanCanonicalize (H12AffineFastState.compose env2883 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound2883 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2884 : List Nat := [2,4,8,16,32,64,121,5,512,638,80,80,514,97,523,633,96,112,639,523,113,32,64,114,627,16,80,96,81,112,639,0,4,0,96,513]

theorem envBound2884 : H12AffineFastState.Bounded env2884 := by
  intro p hp
  have h : env2884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2883_2884 : H12AffineEnvironment.transform 6 121 env2883 = env2884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env2883 == env2884) = true)

theorem identity2884 : scanCanonicalize (H12AffineFastState.compose env2884 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound2884 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2885 : List Nat := [2,4,8,16,32,64,121,5,123,5,80,80,121,97,112,2,96,112,4,112,113,32,64,114,8,16,80,96,81,112,4,0,4,0,96,122]

theorem envBound2885 : H12AffineFastState.Bounded env2885 := by
  intro p hp
  have h : env2885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2884_2885 : H12AffineEnvironment.transform 8 123 env2884 = env2885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env2884 == env2885) = true)

theorem identity2885 : scanCanonicalize (H12AffineFastState.compose env2885 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound2885 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2886 : List Nat := [2,4,8,16,32,49,8,5,10,5,33,33,8,16,1,2,17,1,4,1,0,32,49,3,8,16,33,17,32,1,4,0,4,0,17,11]

theorem envBound2886 : H12AffineFastState.Bounded env2886 := by
  intro p hp
  have h : env2886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2885_2886 : H12AffineEnvironment.transform 5 49 env2885 = env2886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env2885 == env2886) = true)

theorem identity2886 : scanCanonicalize (H12AffineFastState.compose env2886 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2886 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2887 : List Nat := [2,4,8,16,1,16,8,5,10,5,0,0,8,16,1,2,17,1,4,1,0,1,16,3,8,16,0,17,1,1,4,0,4,0,17,11]

theorem envBound2887 : H12AffineFastState.Bounded env2887 := by
  intro p hp
  have h : env2887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2886_2887 : H12AffineEnvironment.transform 4 1 env2886 = env2887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2886 == env2887) = true)

theorem identity2887 : scanCanonicalize (H12AffineFastState.compose env2887 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2888 : List Nat := [2,4,4,16,1,16,4,5,6,5,0,0,4,16,1,2,17,1,4,1,0,1,16,3,4,16,0,17,1,1,4,0,4,0,17,7]

theorem envBound2888 : H12AffineFastState.Bounded env2888 := by
  intro p hp
  have h : env2888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2887_2888 : H12AffineEnvironment.transform 2 4 env2887 = env2888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2887 == env2888) = true)

theorem identity2888 : scanCanonicalize (H12AffineFastState.compose env2888 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound2888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2889 : List Nat := [0,4,4,16,1,16,4,5,4,5,0,0,4,16,1,0,17,1,4,1,0,1,16,1,4,16,0,17,1,1,4,0,4,0,17,5]

theorem envBound2889 : H12AffineFastState.Bounded env2889 := by
  intro p hp
  have h : env2889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2888_2889 : H12AffineEnvironment.transform 0 0 env2888 = env2889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env2888 == env2889) = true)

def env2890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1025,8693,20925,147673,147521,16777216,8328,147473,409816,16385,151552,2080,16778639,1,257,0,131072,16925298]

theorem envBound2890 : H12AffineFastState.Bounded env2890 := by
  intro p hp
  have h : env2890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2873_2890 : H12AffineEnvironment.transform 20 20925 env2873 = env2890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20925 env2873 == env2890) = true)

theorem identity2890 : scanCanonicalize (H12AffineFastState.compose env2890 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2890 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2891 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,131072,262144,1025,8433,20665,147673,147521,16777216,8328,147473,409816,16385,151552,2080,16778379,1,5,0,131072,16925298]

theorem envBound2891 : H12AffineFastState.Bounded env2891 := by
  intro p hp
  have h : env2891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2890_2891 : H12AffineEnvironment.transform 7 4 env2890 = env2891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2890 == env2891) = true)

def env2892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2080,16852468,4341976,257,0,131073,16925298]

theorem envBound2892 : H12AffineFastState.Bounded env2892 := by
  intro p hp
  have h : env2892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2870_2892 : H12AffineEnvironment.transform 34 131073 env2870 = env2892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2870 == env2892) = true)

theorem identity2892 : scanCanonicalize (H12AffineFastState.compose env2892 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 205086) := by decide +kernel

theorem selectedBound2892 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,205086,147521,16777216,8328,147473,409816,16385,151552,2080,16852468,90566,257,0,131073,16925298]

theorem envBound2893 : H12AffineFastState.Bounded env2893 := by
  intro p hp
  have h : env2893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2892_2893 : H12AffineEnvironment.transform 21 205086 env2892 = env2893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 205086 env2892 == env2893) = true)

theorem identity2893 : scanCanonicalize (H12AffineFastState.compose env2893 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 73786) := by decide +kernel

theorem selectedBound2893 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,73786,262144,1025,8693,2097152,292,90235,16777216,8328,90155,352482,16385,94266,2080,16852468,90566,257,0,73787,16867912]

theorem envBound2894 : H12AffineFastState.Bounded env2894 := by
  intro p hp
  have h : env2894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2893_2894 : H12AffineEnvironment.transform 16 73786 env2893 = env2894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 73786 env2893 == env2894) = true)

def env2895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,73786,262144,1025,8693,2097152,292,90235,90184,8328,90155,352482,16385,94266,2080,17852,90566,257,0,73787,512]

theorem envBound2895 : H12AffineFastState.Bounded env2895 := by
  intro p hp
  have h : env2895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2894_2895 : H12AffineEnvironment.transform 23 90184 env2894 = env2895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90184 env2894 == env2895) = true)

theorem identity2895 : scanCanonicalize (H12AffineFastState.compose env2895 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2895 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2896 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,65536,73786,262144,1025,8433,2097152,32,90235,90184,8328,90155,352482,16385,94266,2080,17592,90306,5,0,73787,512]

theorem envBound2896 : H12AffineFastState.Bounded env2896 := by
  intro p hp
  have h : env2896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2895_2896 : H12AffineEnvironment.transform 7 4 env2895 = env2896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2895 == env2896) = true)

theorem identity2896 : scanCanonicalize (H12AffineFastState.compose env2896 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound2896 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2897 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,65,262144,1025,8433,2097152,32,16384,16435,8328,16464,278681,16385,20545,2080,17592,16569,5,0,64,512]

theorem envBound2897 : H12AffineFastState.Bounded env2897 := by
  intro p hp
  have h : env2897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2896_2897 : H12AffineEnvironment.transform 15 8315 env2896 = env2897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env2896 == env2897) = true)

theorem identity2897 : scanCanonicalize (H12AffineFastState.compose env2897 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound2897 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2898 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,185,8433,8315,65,262144,1025,8433,2097152,32,185,138,8328,233,262176,184,4344,2080,1025,0,5,0,64,512]

theorem envBound2898 : H12AffineFastState.Bounded env2898 := by
  intro p hp
  have h : env2898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2897_2898 : H12AffineEnvironment.transform 13 185 env2897 = env2898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env2897 == env2898) = true)

theorem identity2898 : scanCanonicalize (H12AffineFastState.compose env2898 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 11439) := by decide +kernel

theorem selectedBound2898 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2899 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,185,8433,8315,65,262144,1025,8433,11439,32,185,138,8328,233,262176,184,4344,2080,1025,0,5,0,64,512]

theorem envBound2899 : H12AffineFastState.Bounded env2899 := by
  intro p hp
  have h : env2899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2898_2899 : H12AffineEnvironment.transform 20 11439 env2898 = env2899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11439 env2898 == env2899) = true)

theorem identity2899 : scanCanonicalize (H12AffineFastState.compose env2899 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2899 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2900 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,185,8433,8315,65,2265,1025,8433,11439,32,185,138,8328,233,2297,184,4344,2080,1025,0,5,0,64,512]

theorem envBound2900 : H12AffineFastState.Bounded env2900 := by
  intro p hp
  have h : env2900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2899_2900 : H12AffineEnvironment.transform 17 2265 env2899 = env2900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2899 == env2900) = true)

theorem identity2900 : scanCanonicalize (H12AffineFastState.compose env2900 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound2900 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2901 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,64,8200,8315,65,2080,1025,8200,11350,32,64,115,8305,16,2048,65,4097,2080,1025,0,5,0,64,512]

theorem envBound2901 : H12AffineFastState.Bounded env2901 := by
  intro p hp
  have h : env2901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2900_2901 : H12AffineEnvironment.transform 6 121 env2900 = env2901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env2900 == env2901) = true)

theorem identity2901 : scanCanonicalize (H12AffineFastState.compose env2901 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2902 : List Nat := [2,4,8,16,32,1,56,4,512,1024,2048,4096,8192,1,8200,8250,0,2080,1025,8200,11287,32,1,50,8240,16,2048,0,4097,2080,1025,0,5,0,1,512]

theorem envBound2902 : H12AffineFastState.Bounded env2902 := by
  intro p hp
  have h : env2902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2901_2902 : H12AffineEnvironment.transform 5 1 env2901 = env2902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2901 == env2902) = true)

theorem identity2902 : scanCanonicalize (H12AffineFastState.compose env2902 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound2902 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2903 : List Nat := [2,4,8,16,32,1,56,4,512,1024,42,4096,8192,1,8200,8250,0,10,1025,8200,9277,32,1,50,8240,16,42,0,4097,10,1025,0,5,0,1,512]

theorem envBound2903 : H12AffineFastState.Bounded env2903 := by
  intro p hp
  have h : env2903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2902_2903 : H12AffineEnvironment.transform 10 42 env2902 = env2903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env2902 == env2903) = true)

theorem identity2903 : scanCanonicalize (H12AffineFastState.compose env2903 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound2903 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2904 : List Nat := [2,4,8,16,32,1,56,4,512,1024,42,4096,1030,1,1038,1084,0,10,1025,1038,59,32,1,50,1078,16,42,0,4097,10,1025,0,5,0,1,512]

theorem envBound2904 : H12AffineFastState.Bounded env2904 := by
  intro p hp
  have h : env2904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2903_2904 : H12AffineEnvironment.transform 12 1030 env2903 = env2904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env2903 == env2904) = true)

theorem identity2904 : scanCanonicalize (H12AffineFastState.compose env2904 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound2904 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2905 : List Nat := [2,4,8,16,17,1,9,4,512,1024,27,4096,1030,1,1038,1037,0,10,1025,1038,10,17,1,3,1031,16,27,0,4097,10,1025,0,5,0,1,512]

theorem envBound2905 : H12AffineFastState.Bounded env2905 := by
  intro p hp
  have h : env2905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2904_2905 : H12AffineEnvironment.transform 4 17 env2904 = env2905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2904 == env2905) = true)

theorem identity2905 : scanCanonicalize (H12AffineFastState.compose env2905 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2905 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2906 : List Nat := [2,4,8,0,1,1,9,4,512,1024,11,4096,1030,1,1038,1037,0,10,1025,1038,10,1,1,3,1031,0,11,0,4097,10,1025,0,5,0,1,512]

theorem envBound2906 : H12AffineFastState.Bounded env2906 := by
  intro p hp
  have h : env2906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2905_2906 : H12AffineEnvironment.transform 3 0 env2905 = env2906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2905 == env2906) = true)

def env2907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,73786,262144,1025,8693,2097152,292,90235,90185,8328,90155,352482,16385,94266,2080,17853,90566,257,0,73787,513]

theorem envBound2907 : H12AffineFastState.Bounded env2907 := by
  intro p hp
  have h : env2907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2894_2907 : H12AffineEnvironment.transform 23 90185 env2894 = env2907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90185 env2894 == env2907) = true)

theorem identity2907 : scanCanonicalize (H12AffineFastState.compose env2907 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4436) := by decide +kernel

theorem selectedBound2907 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,73786,262144,1025,8693,4436,292,90235,90185,8328,90155,352482,16385,94266,2080,17853,90566,257,0,73787,513]

theorem envBound2908 : H12AffineFastState.Bounded env2908 := by
  intro p hp
  have h : env2908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2907_2908 : H12AffineEnvironment.transform 20 4436 env2907 = env2908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4436 env2907 == env2908) = true)

theorem identity2908 : scanCanonicalize (H12AffineFastState.compose env2908 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound2908 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,73786,262144,1025,8693,4436,292,73923,73969,8328,73875,335962,185,77954,2080,1285,74110,257,0,73787,513]

theorem envBound2909 : H12AffineFastState.Bounded env2909 := by
  intro p hp
  have h : env2909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2908_2909 : H12AffineEnvironment.transform 13 184 env2908 = env2909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env2908 == env2909) = true)

theorem identity2909 : scanCanonicalize (H12AffineFastState.compose env2909 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2909 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2910 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,184,8201,65536,73786,262144,1025,8201,4264,216,73923,73969,8328,73875,335962,185,77954,2080,1273,73858,253,0,73787,513]

theorem envBound2910 : H12AffineFastState.Bounded env2910 := by
  intro p hp
  have h : env2910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2909_2910 : H12AffineEnvironment.transform 7 252 env2909 = env2910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2909 == env2910) = true)

theorem identity2910 : scanCanonicalize (H12AffineFastState.compose env2910 (packedSelected [1,3,4,9,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound2910 : packedSelected [1,3,4,9,20,24,28] rootPS < 2^1333 := by decide +kernel

def env2911 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,184,8201,8322,184,262144,1025,8201,4264,216,65,115,8328,17,262360,185,4096,2080,1273,0,253,0,185,513]

theorem envBound2911 : H12AffineFastState.Bounded env2911 := by
  intro p hp
  have h : env2911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2910_2911 : H12AffineEnvironment.transform 15 8322 env2910 = env2911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env2910 == env2911) = true)

theorem identity2911 : scanCanonicalize (H12AffineFastState.compose env2911 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound2911 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2912 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1,8192,184,8201,8322,184,262144,1025,8201,169,216,65,115,8328,17,262360,185,1,2080,1273,0,253,0,185,513]

theorem envBound2912 : H12AffineFastState.Bounded env2912 := by
  intro p hp
  have h : env2912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2911_2912 : H12AffineEnvironment.transform 11 1 env2911 = env2912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env2911 == env2912) = true)

theorem identity2912 : scanCanonicalize (H12AffineFastState.compose env2912 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1237) := by decide +kernel

theorem selectedBound2912 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env2913 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1,1237,184,1244,1111,184,262144,1025,1244,169,216,65,115,1117,17,262360,185,1,2080,1273,0,253,0,185,513]

theorem envBound2913 : H12AffineFastState.Bounded env2913 := by
  intro p hp
  have h : env2913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2912_2913 : H12AffineEnvironment.transform 12 1237 env2912 = env2913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1237 env2912 == env2913) = true)

theorem identity2913 : scanCanonicalize (H12AffineFastState.compose env2913 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound2913 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2914 : List Nat := [2,4,8,16,32,64,128,252,512,117,2048,1,160,184,169,34,184,262144,116,169,169,216,65,115,40,17,262360,185,1,2080,140,0,253,0,185,513]

theorem envBound2914 : H12AffineFastState.Bounded env2914 := by
  intro p hp
  have h : env2914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2913_2914 : H12AffineEnvironment.transform 9 117 env2913 = env2914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env2913 == env2914) = true)

theorem identity2914 : scanCanonicalize (H12AffineFastState.compose env2914 (packedSelected [0,1,3,5,7,8,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2297) := by decide +kernel

theorem selectedBound2914 : packedSelected [0,1,3,5,7,8,12,13] rootPS < 2^1333 := by decide +kernel

def env2915 : List Nat := [2,4,8,16,32,64,128,252,512,117,2048,1,160,184,169,34,184,2297,116,169,169,216,65,115,40,17,2081,185,1,2080,140,0,253,0,185,513]

theorem envBound2915 : H12AffineFastState.Bounded env2915 := by
  intro p hp
  have h : env2915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2914_2915 : H12AffineEnvironment.transform 17 2297 env2914 = env2915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2297 env2914 == env2915) = true)

theorem identity2915 : scanCanonicalize (H12AffineFastState.compose env2915 (packedSelected [0,1,3,5,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound2915 : packedSelected [0,1,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env2916 : List Nat := [2,4,8,16,32,64,128,252,512,117,49,1,160,184,169,34,184,200,116,169,169,216,65,115,40,17,16,185,1,17,140,0,253,0,185,513]

theorem envBound2916 : H12AffineFastState.Bounded env2916 := by
  intro p hp
  have h : env2916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2915_2916 : H12AffineEnvironment.transform 10 49 env2915 = env2916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env2915 == env2916) = true)

theorem identity2916 : scanCanonicalize (H12AffineFastState.compose env2916 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound2916 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env2917 : List Nat := [2,4,8,16,32,49,128,141,512,4,49,1,160,184,169,34,184,185,5,169,169,169,48,2,40,17,16,185,1,17,140,0,140,0,185,513]

theorem envBound2917 : H12AffineFastState.Bounded env2917 := by
  intro p hp
  have h : env2917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2916_2917 : H12AffineEnvironment.transform 5 49 env2916 = env2917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env2916 == env2917) = true)

theorem identity2917 : scanCanonicalize (H12AffineFastState.compose env2917 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound2917 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env2918 : List Nat := [2,4,8,16,32,49,128,141,10,4,49,1,160,184,169,34,184,185,5,169,169,169,48,2,40,17,16,185,1,17,140,0,140,0,185,11]

theorem envBound2918 : H12AffineFastState.Bounded env2918 := by
  intro p hp
  have h : env2918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2917_2918 : H12AffineEnvironment.transform 8 10 env2917 = env2918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env2917 == env2918) = true)

theorem identity2918 : scanCanonicalize (H12AffineFastState.compose env2918 (packedSelected [1,3,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound2918 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env2919 : List Nat := [1,4,8,16,32,49,128,141,9,4,49,1,160,184,169,33,184,185,5,169,169,169,48,1,40,17,16,185,1,17,140,0,140,0,185,8]

theorem envBound2919 : H12AffineFastState.Bounded env2919 := by
  intro p hp
  have h : env2919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2918_2919 : H12AffineEnvironment.transform 0 1 env2918 = env2919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env2918 == env2919) = true)

theorem identity2919 : scanCanonicalize (H12AffineFastState.compose env2919 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2919 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env2920 : List Nat := [1,4,8,16,32,49,41,36,9,4,49,1,9,17,0,33,17,16,5,0,0,0,48,1,40,17,16,16,1,17,37,0,37,0,16,8]

theorem envBound2920 : H12AffineFastState.Bounded env2920 := by
  intro p hp
  have h : env2920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2919_2920 : H12AffineEnvironment.transform 6 41 env2919 = env2920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2919 == env2920) = true)

theorem identity2920 : scanCanonicalize (H12AffineFastState.compose env2920 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2920 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env2921 : List Nat := [1,4,4,16,32,49,37,36,5,4,49,1,5,17,0,33,17,16,5,0,0,0,48,1,36,17,16,16,1,17,37,0,37,0,16,4]

theorem envBound2921 : H12AffineFastState.Bounded env2921 := by
  intro p hp
  have h : env2921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2920_2921 : H12AffineEnvironment.transform 2 4 env2920 = env2921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2920 == env2921) = true)

def env2922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,1073741824,2147483648,3309906205,525568,1073743905,34359738368,25733062]

theorem envBound2922 : H12AffineFastState.Bounded env2922 := by
  intro p hp
  have h : env2922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5_2922 : H12AffineEnvironment.transform 24 8329 env5 = env2922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env5 == env2922) = true)

theorem identity2922 : scanCanonicalize (H12AffineFastState.compose env2922 (packedSelected [6,25] rootPS)) = affineNative (2^(30+1) ^^^ 1283820762) := by decide +kernel

theorem selectedBound2922 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env2923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,1073741824,1283820762,164406727,525568,1073743905,34359738368,25733062]

theorem envBound2923 : H12AffineFastState.Bounded env2923 := by
  intro p hp
  have h : env2923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2922_2923 : H12AffineEnvironment.transform 30 1283820762 env2922 = env2923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 1283820762 env2922 == env2923) = true)

theorem identity2923 : scanCanonicalize (H12AffineFastState.compose env2923 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(29+1) ^^^ 956700811) := by decide +kernel

theorem selectedBound2923 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env2924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,956700811,897815633,164406727,525568,956698794,34359738368,25733062]

theorem envBound2924 : H12AffineFastState.Bounded env2924 := by
  intro p hp
  have h : env2924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2923_2924 : H12AffineEnvironment.transform 29 956700811 env2923 = env2924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 956700811 env2923 == env2924) = true)

def env2925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,268570624,151259275,92374097,164406727,525568,151257258,34359738368,25733062]

theorem envBound2925 : H12AffineFastState.Bounded env2925 := by
  intro p hp
  have h : env2925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2924_2925 : H12AffineEnvironment.transform 28 268570624 env2924 = env2925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570624 env2924 == env2925) = true)

theorem identity2925 : scanCanonicalize (H12AffineFastState.compose env2925 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(23+1) ^^^ 8955335) := by decide +kernel

theorem selectedBound2925 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env2926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,8329,67108864,134217728,268435456,268570624,143437132,67707286,138674176,525568,143435117,34359738368,513]

theorem envBound2926 : H12AffineFastState.Bounded env2926 := by
  intro p hp
  have h : env2926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2925_2926 : H12AffineEnvironment.transform 23 8955335 env2925 = env2926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8955335 env2925 == env2926) = true)

theorem identity2926 : scanCanonicalize (H12AffineFastState.compose env2926 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 10711170) := by decide +kernel

theorem selectedBound2926 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,8329,10711170,134217728,268435456,268570624,143437132,11161876,138674176,525568,143435117,34359738368,513]

theorem envBound2927 : H12AffineFastState.Bounded env2927 := by
  intro p hp
  have h : env2927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2926_2927 : H12AffineEnvironment.transform 25 10711170 env2926 = env2927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 10711170 env2926 == env2927) = true)

theorem identity2927 : scanCanonicalize (H12AffineFastState.compose env2927 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4760941) := by decide +kernel

theorem selectedBound2927 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env2928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,4760941,4194474,8329,7067119,134217728,268435456,268570624,138676257,6485113,138674176,525568,138674176,34359738368,513]

theorem envBound2928 : H12AffineFastState.Bounded env2928 := by
  intro p hp
  have h : env2928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2927_2928 : H12AffineEnvironment.transform 22 4760941 env2927 = env2928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4760941 env2927 == env2928) = true)

theorem identity2928 : scanCanonicalize (H12AffineFastState.compose env2928 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(34+1) ^^^ 407856518) := by decide +kernel

theorem selectedBound2928 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,4760941,4194474,8329,7067119,134217728,268435456,268570624,138676257,6485113,138674176,525568,138674176,407856518,513]

theorem envBound2929 : H12AffineFastState.Bounded env2929 := by
  intro p hp
  have h : env2929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2928_2929 : H12AffineEnvironment.transform 34 407856518 env2928 = env2929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 407856518 env2928 == env2929) = true)

theorem identity2929 : scanCanonicalize (H12AffineFastState.compose env2929 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(26+1) ^^^ 360619) := by decide +kernel

theorem selectedBound2929 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env2930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,4760941,4194474,8329,7067119,360619,268435456,268570624,4294794,6485113,4292779,525568,4292779,273343789,513]

theorem envBound2930 : H12AffineFastState.Bounded env2930 := by
  intro p hp
  have h : env2930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2929_2930 : H12AffineEnvironment.transform 26 360619 env2929 = env2930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 360619 env2929 == env2930) = true)

theorem identity2930 : scanCanonicalize (H12AffineFastState.compose env2930 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(27+1) ^^^ 3005611) := by decide +kernel

theorem selectedBound2930 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env2931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,4760941,4194474,8329,7067119,360619,3005611,3132587,4294794,6485113,4292779,525568,4292779,6764934,513]

theorem envBound2931 : H12AffineFastState.Bounded env2931 := by
  intro p hp
  have h : env2931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2930_2931 : H12AffineEnvironment.transform 27 3005611 env2930 = env2931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 3005611 env2930 == env2931) = true)

theorem identity2931 : scanCanonicalize (H12AffineFastState.compose env2931 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2289964) := by decide +kernel

theorem selectedBound2931 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env2932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,2289964,2774081,2290054,8329,599235,360619,3005611,3132587,2324902,1365,2322823,525568,2322823,379050,513]

theorem envBound2932 : H12AffineFastState.Bounded env2932 := by
  intro p hp
  have h : env2932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2931_2932 : H12AffineEnvironment.transform 21 2289964 env2931 = env2932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2289964 env2931 == env2932) = true)

theorem identity2932 : scanCanonicalize (H12AffineFastState.compose env2932 (packedSelected [2,11,14,23] rootPS)) = affineNative (2^(20+1) ^^^ 225490) := by decide +kernel

theorem selectedBound2932 : packedSelected [2,11,14,23] rootPS < 2^1333 := by decide +kernel

def env2933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,225490,98814,599187,98644,8329,599235,360619,961657,834681,2420,1365,341,525568,341,379050,513]

theorem envBound2933 : H12AffineFastState.Bounded env2933 := by
  intro p hp
  have h : env2933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2932_2933 : H12AffineEnvironment.transform 20 225490 env2932 = env2933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 225490 env2932 == env2933) = true)

theorem identity2933 : scanCanonicalize (H12AffineFastState.compose env2933 (packedSelected [1,4,5,8,9,14,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound2933 : packedSelected [1,4,5,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env2934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,524288,32768,192781,33,566604,139,8329,566556,262516,961657,834681,2420,1365,341,525568,341,280949,513]

theorem envBound2934 : H12AffineFastState.Bounded env2934 := by
  intro p hp
  have h : env2934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2933_2934 : H12AffineEnvironment.transform 15 33247 env2933 = env2934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env2933 == env2934) = true)

theorem identity2934 : scanCanonicalize (H12AffineFastState.compose env2934 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(18+1) ^^^ 272461) := by decide +kernel

theorem selectedBound2934 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env2935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,272461,32768,192781,33,298241,139,8329,298321,262516,164916,37940,2420,1365,341,273741,341,280949,513]

theorem envBound2935 : H12AffineFastState.Bounded env2935 := by
  intro p hp
  have h : env2935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2934_2935 : H12AffineEnvironment.transform 18 272461 env2934 = env2935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272461 env2934 == env2935) = true)

theorem identity2935 : scanCanonicalize (H12AffineFastState.compose env2935 (packedSelected [0,5,7,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound2935 : packedSelected [0,5,7,8,13] rootPS < 2^1333 := by decide +kernel

def env2936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,20156,26353,32768,192781,33,50109,139,8329,50157,20424,164916,37940,2420,1365,341,25585,341,1993,513]

theorem envBound2936 : H12AffineFastState.Bounded env2936 := by
  intro p hp
  have h : env2936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2935_2936 : H12AffineEnvironment.transform 17 20156 env2935 = env2936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env2935 == env2936) = true)

theorem identity2936 : scanCanonicalize (H12AffineFastState.compose env2936 (packedSelected [0,1,2,4,5,6,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 11853) := by decide +kernel

theorem selectedBound2936 : packedSelected [0,1,2,4,5,6,11,12,14] rootPS < 2^1333 := by decide +kernel

def env2937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,11853,12178,131072,20156,26353,11853,155456,33,28144,139,8329,28064,20424,141945,14969,2420,1365,341,25585,341,1993,513]

theorem envBound2937 : H12AffineFastState.Bounded env2937 := by
  intro p hp
  have h : env2937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2936_2937 : H12AffineEnvironment.transform 14 11853 env2936 = env2937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11853 env2936 == env2937) = true)

theorem identity2937 : scanCanonicalize (H12AffineFastState.compose env2937 (packedSelected [1,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 28587) := by decide +kernel

theorem selectedBound2937 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env2938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,11853,12178,28587,20156,26353,11853,12523,33,28144,139,8329,28064,20424,17874,14969,2420,1365,341,25585,341,1993,513]

theorem envBound2938 : H12AffineFastState.Bounded env2938 := by
  intro p hp
  have h : env2938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1