import H12CloudChart1Data231

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity58839 : scanCanonicalize (H12AffineFastState.compose env58839 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 6376003) := by decide +kernel

theorem selectedBound58839 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,6376003,6382036,8328,6363715,134217728,16385,77954,4280971,6320005,140775424,256,138748206,78035,513]

theorem envBound58840 : H12AffineFastState.Bounded env58840 := by
  intro p hp
  have h : env58840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58839_58840 : H12AffineEnvironment.transform 22 6376003 env58839 = env58840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6376003 env58839 == env58840) = true)

theorem identity58840 : scanCanonicalize (H12AffineFastState.compose env58840 (packedSelected [6,25] rootPS)) = affineNative (2^(26+1) ^^^ 2374612) := by decide +kernel

theorem selectedBound58840 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,6376003,6382036,8328,6363715,2374612,16385,77954,4280971,6320005,4205524,256,6363898,78035,513]

theorem envBound58841 : H12AffineFastState.Bounded env58841 := by
  intro p hp
  have h : env58841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58840_58841 : H12AffineEnvironment.transform 26 2374612 env58840 = env58841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 2374612 env58840 == env58841) = true)

theorem identity58841 : scanCanonicalize (H12AffineFastState.compose env58841 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(21+1) ^^^ 2101644) := by decide +kernel

theorem selectedBound58841 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,2101644,89039,94296,8328,68559,2374612,16385,77954,2179847,32265,2112088,256,68470,78035,513]

theorem envBound58842 : H12AffineFastState.Bounded env58842 := by
  intro p hp
  have h : env58842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58841_58842 : H12AffineEnvironment.transform 21 2101644 env58841 = env58842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101644 env58841 == env58842) = true)

theorem identity58842 : scanCanonicalize (H12AffineFastState.compose env58842 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 16464) := by decide +kernel

theorem selectedBound58842 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,16464,20956,89039,94296,8328,68559,293764,16385,77954,66391,32265,31240,256,68470,78035,513]

theorem envBound58843 : H12AffineFastState.Bounded env58843 := by
  intro p hp
  have h : env58843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58842_58843 : H12AffineEnvironment.transform 20 16464 env58842 = env58843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16464 env58842 == env58843) = true)

theorem identity58843 : scanCanonicalize (H12AffineFastState.compose env58843 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 15117) := by decide +kernel

theorem selectedBound58843 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env58844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15117,2640,65536,78035,262144,1025,2640,15197,10961,73922,68437,8328,68559,262281,15116,77954,66391,1284,261,256,68470,78035,513]

theorem envBound58844 : H12AffineFastState.Bounded env58844 := by
  intro p hp
  have h : env58844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58843_58844 : H12AffineEnvironment.transform 13 15117 env58843 = env58844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15117 env58843 == env58844) = true)

theorem identity58844 : scanCanonicalize (H12AffineFastState.compose env58844 (packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 72395) := by decide +kernel

theorem selectedBound58844 : packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env58845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15117,2640,65536,78035,72395,1025,2640,15197,10961,73922,68437,8328,68559,72258,15116,77954,66391,1284,261,256,68470,78035,513]

theorem envBound58845 : H12AffineFastState.Bounded env58845 := by
  intro p hp
  have h : env58845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58844_58845 : H12AffineEnvironment.transform 17 72395 env58844 = env58845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72395 env58844 == env58845) = true)

theorem identity58845 : scanCanonicalize (H12AffineFastState.compose env58845 (packedSelected [3,5,8,13,15,17,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 5103) := by decide +kernel

theorem selectedBound58845 : packedSelected [3,5,8,13,15,17,28,38] rootPS < 2^1333 := by decide +kernel

def env58846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15117,2640,5103,9020,2340,1025,2640,15197,10961,13101,6330,8328,6176,2477,15116,9069,4280,1284,261,256,6297,9020,513]

theorem envBound58846 : H12AffineFastState.Bounded env58846 := by
  intro p hp
  have h : env58846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58845_58846 : H12AffineEnvironment.transform 15 5103 env58845 = env58846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5103 env58845 == env58846) = true)

theorem identity58846 : scanCanonicalize (H12AffineFastState.compose env58846 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2909) := by decide +kernel

theorem selectedBound58846 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2909,4176,2640,5103,2145,2340,1025,2640,4096,396,6256,6330,3029,6176,2477,4177,2096,4280,1284,261,256,6297,2145,513]

theorem envBound58847 : H12AffineFastState.Bounded env58847 := by
  intro p hp
  have h : env58847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58846_58847 : H12AffineEnvironment.transform 12 2909 env58846 = env58847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2909 env58846 == env58847) = true)

theorem identity58847 : scanCanonicalize (H12AffineFastState.compose env58847 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound58847 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,664,2909,712,2640,375,2145,2340,1025,2640,664,396,2792,2594,3029,2744,2477,713,2096,544,1284,261,256,2561,2145,513]

theorem envBound58848 : H12AffineFastState.Bounded env58848 := by
  intro p hp
  have h : env58848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58847_58848 : H12AffineEnvironment.transform 11 664 env58847 = env58848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env58847 == env58848) = true)

theorem identity58848 : scanCanonicalize (H12AffineFastState.compose env58848 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 624) := by decide +kernel

theorem selectedBound58848 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,624,664,301,712,32,375,529,852,1025,32,664,396,152,82,421,200,989,713,576,544,1284,261,256,113,529,513]

theorem envBound58849 : H12AffineFastState.Bounded env58849 := by
  intro p hp
  have h : env58849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58848_58849 : H12AffineEnvironment.transform 10 624 env58848 = env58849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 624 env58848 == env58849) = true)

theorem identity58849 : scanCanonicalize (H12AffineFastState.compose env58849 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58849 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58850 : List Nat := [2,4,8,16,32,64,128,172,512,1024,624,664,129,712,32,219,529,760,1025,32,664,32,152,82,9,200,625,713,576,544,1192,169,172,113,529,513]

theorem envBound58850 : H12AffineFastState.Bounded env58850 := by
  intro p hp
  have h : env58850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58849_58850 : H12AffineEnvironment.transform 7 172 env58849 = env58850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58849 == env58850) = true)

theorem identity58850 : scanCanonicalize (H12AffineFastState.compose env58850 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58850 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env58851 : List Nat := [2,4,8,16,32,64,19,63,512,1024,624,523,18,603,32,72,529,619,1025,32,523,32,11,82,9,91,625,602,576,544,1083,58,63,113,529,513]

theorem envBound58851 : H12AffineFastState.Bounded env58851 := by
  intro p hp
  have h : env58851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58850_58851 : H12AffineEnvironment.transform 6 19 env58850 = env58851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58850 == env58851) = true)

theorem identity58851 : scanCanonicalize (H12AffineFastState.compose env58851 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58851 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58852 : List Nat := [2,4,8,10,32,64,9,37,512,1024,618,523,8,577,32,72,523,619,1025,32,523,32,11,72,9,65,619,576,576,544,1057,32,37,107,523,513]

theorem envBound58852 : H12AffineFastState.Bounded env58852 := by
  intro p hp
  have h : env58852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58851_58852 : H12AffineEnvironment.transform 3 10 env58851 = env58852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58851 == env58852) = true)

theorem identity58852 : scanCanonicalize (H12AffineFastState.compose env58852 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound58852 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58853 : List Nat := [2,4,8,10,32,2,9,37,512,1024,552,523,8,515,32,10,523,553,1025,32,523,32,11,10,9,3,553,514,514,544,1057,32,37,41,523,513]

theorem envBound58853 : H12AffineFastState.Bounded env58853 := by
  intro p hp
  have h : env58853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58852_58853 : H12AffineEnvironment.transform 5 2 env58852 = env58853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env58852 == env58853) = true)

theorem identity58853 : scanCanonicalize (H12AffineFastState.compose env58853 (packedSelected [0,1,2,11] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58853 : packedSelected [0,1,2,11] rootPS < 2^1333 := by decide +kernel

def env58854 : List Nat := [2,4,8,10,32,2,9,37,42,1024,2,33,8,41,32,10,33,3,1025,32,33,32,11,10,9,3,3,40,40,10,1057,32,37,41,33,43]

theorem envBound58854 : H12AffineFastState.Bounded env58854 := by
  intro p hp
  have h : env58854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58853_58854 : H12AffineEnvironment.transform 8 42 env58853 = env58854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58853 == env58854) = true)

theorem identity58854 : scanCanonicalize (H12AffineFastState.compose env58854 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58854 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58855 : List Nat := [2,4,0,2,32,2,1,37,34,1024,2,33,0,33,32,2,33,3,1025,32,33,32,3,2,1,3,3,32,32,2,1057,32,37,33,33,35]

theorem envBound58855 : H12AffineFastState.Bounded env58855 := by
  intro p hp
  have h : env58855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58854_58855 : H12AffineEnvironment.transform 2 0 env58854 = env58855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58854 == env58855) = true)

theorem identity58855 : scanCanonicalize (H12AffineFastState.compose env58855 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound58855 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env58856 : List Nat := [2,4,0,2,32,2,1,37,34,6,2,33,0,33,32,2,33,3,7,32,33,32,3,2,1,3,3,32,32,2,39,32,37,33,33,35]

theorem envBound58856 : H12AffineFastState.Bounded env58856 := by
  intro p hp
  have h : env58856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58855_58856 : H12AffineEnvironment.transform 9 6 env58855 = env58856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env58855 == env58856) = true)

def leafEnv58856 : List Nat := [2,4,0,2,32,2,1,37,34,6,2,33,0,33,32,2,33,3,7,32,33,32,3,2,38,1,1,3,3,32,32,2,39,32,37,33,4,2,33,35,1,33,0]

def active58856 : List Nat := [0,1,4]

def tree58856 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58856 : H12WitnessSearch.Good tree58856 := H12GlobalWitnessIndex.good

theorem leafIdentity58856 : H12AffineFastState.composeSystem env58856 rootObs = leafEnv58856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58856 rootObs == leafEnv58856) = true)

theorem terminalChecked58856 : H12PackedTerminal.terminalCheckFast leafEnv58856 active58856 tree58856 = true := by decide +kernel

def env58857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399767,8329,8409088,134217728,16385,77954,4280971,8463814,140775424,256,144993133,78035,512]

theorem envBound58857 : H12AffineFastState.Bounded env58857 := by
  intro p hp
  have h : env58857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58838_58857 : H12AffineEnvironment.transform 24 8329 env58838 = env58857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env58838 == env58857) = true)

theorem identity58857 : scanCanonicalize (H12AffineFastState.compose env58857 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58857 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399767,8329,8388689,134217728,4176,77954,4260570,8463814,140775424,256,144980796,78035,512]

theorem envBound58858 : H12AffineFastState.Bounded env58858 := by
  intro p hp
  have h : env58858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58857_58858 : H12AffineEnvironment.transform 13 4177 env58857 = env58858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58857 == env58858) = true)

theorem identity58858 : scanCanonicalize (H12AffineFastState.compose env58858 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58858 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399767,8329,8388689,12919238,4176,77954,4260570,8463814,10564038,256,6363898,78035,512]

theorem envBound58859 : H12AffineFastState.Bounded env58859 := by
  intro p hp
  have h : env58859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58858_58859 : H12AffineEnvironment.transform 26 12919238 env58858 = env58859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58858 == env58859) = true)

theorem identity58859 : scanCanonicalize (H12AffineFastState.compose env58859 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 3038) := by decide +kernel

theorem selectedBound58859 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3038,15117,262144,1025,2640,2097152,4194304,8388608,8399767,8329,8388689,12855832,4176,15196,4196612,8400408,10500632,256,6295844,15117,512]

theorem envBound58860 : H12AffineFastState.Bounded env58860 := by
  intro p hp
  have h : env58860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58859_58860 : H12AffineEnvironment.transform 15 3038 env58859 = env58860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3038 env58859 == env58860) = true)

theorem identity58860 : scanCanonicalize (H12AffineFastState.compose env58860 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 270177) := by decide +kernel

theorem selectedBound58860 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3038,15117,262144,1025,2640,2097152,270177,8388608,8399767,8329,8388689,8402297,4176,15196,267877,8400408,10500632,256,2362949,15117,512]

theorem envBound58861 : H12AffineFastState.Bounded env58861 := by
  intro p hp
  have h : env58861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58860_58861 : H12AffineEnvironment.transform 21 270177 env58860 = env58861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270177 env58860 == env58861) = true)

theorem identity58861 : scanCanonicalize (H12AffineFastState.compose env58861 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound58861 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env58862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3038,15117,8001,1025,2640,2097152,32,8388608,8399767,8329,8388689,8402297,4176,15196,2340,8400408,10500632,256,2101508,15117,512]

theorem envBound58862 : H12AffineFastState.Bounded env58862 := by
  intro p hp
  have h : env58862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58861_58862 : H12AffineEnvironment.transform 17 8001 env58861 = env58862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env58861 == env58862) = true)

def env58863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3038,15117,8001,1025,2640,2097152,32,8296,3071,8329,8249,5393,4176,15196,2340,3696,2103920,256,2101508,15117,512]

theorem envBound58863 : H12AffineFastState.Bounded env58863 := by
  intro p hp
  have h : env58863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58862_58863 : H12AffineEnvironment.transform 22 8296 env58862 = env58863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8296 env58862 == env58863) = true)

def env58864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,80,478,12557,5441,1025,80,2097152,32,8296,511,8329,8249,5393,4176,12636,804,1136,2101360,256,2101508,12557,512]

theorem envBound58864 : H12AffineFastState.Bounded env58864 := by
  intro p hp
  have h : env58864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58863_58864 : H12AffineEnvironment.transform 10 512 env58863 = env58864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58863 == env58864) = true)

theorem identity58864 : scanCanonicalize (H12AffineFastState.compose env58864 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1621) := by decide +kernel

theorem selectedBound58864 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,8192,1540,80,478,10072,788,1025,80,2097152,32,8296,511,8329,8249,836,1541,9993,804,1136,2098725,256,2099025,10072,512]

theorem envBound58865 : H12AffineFastState.Bounded env58865 := by
  intro p hp
  have h : env58865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58864_58865 : H12AffineEnvironment.transform 11 1621 env58864 = env58865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1621 env58864 == env58865) = true)

def env58866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,536,1540,80,478,1344,788,1025,80,2097152,32,624,511,657,545,836,1541,1297,804,1136,2098725,256,2099025,1344,512]

theorem envBound58866 : H12AffineFastState.Bounded env58866 := by
  intro p hp
  have h : env58866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58865_58866 : H12AffineEnvironment.transform 12 536 env58865 = env58866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58865 == env58866) = true)

theorem identity58866 : scanCanonicalize (H12AffineFastState.compose env58866 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1344) := by decide +kernel

theorem selectedBound58866 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,536,1540,80,478,1344,788,1025,80,1344,32,624,511,657,545,836,1541,1297,804,1136,869,256,529,1344,512]

theorem envBound58867 : H12AffineFastState.Bounded env58867 := by
  intro p hp
  have h : env58867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58866_58867 : H12AffineEnvironment.transform 20 1344 env58866 = env58867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1344 env58866 == env58867) = true)

def env58868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,537,1540,80,478,1345,788,1025,80,2097152,32,625,511,656,544,836,1541,1296,804,1136,2098725,256,2099025,1345,512]

theorem envBound58868 : H12AffineFastState.Bounded env58868 := by
  intro p hp
  have h : env58868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58865_58868 : H12AffineEnvironment.transform 12 537 env58865 = env58868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58865 == env58868) = true)

theorem identity58868 : scanCanonicalize (H12AffineFastState.compose env58868 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1076) := by decide +kernel

theorem selectedBound58868 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1621,537,1540,80,478,1345,788,1025,80,1076,32,625,511,656,544,836,1541,1296,804,1136,529,256,869,1345,512]

theorem envBound58869 : H12AffineFastState.Bounded env58869 := by
  intro p hp
  have h : env58869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58868_58869 : H12AffineEnvironment.transform 20 1076 env58868 = env58869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1076 env58868 == env58869) = true)

theorem identity58869 : scanCanonicalize (H12AffineFastState.compose env58869 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58869 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58870 : List Nat := [2,4,8,16,32,64,128,116,512,1024,512,1621,537,1540,80,170,1077,608,1025,80,1076,32,625,139,656,544,560,1541,1124,592,1136,529,116,529,1077,512]

theorem envBound58870 : H12AffineFastState.Bounded env58870 := by
  intro p hp
  have h : env58870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58869_58870 : H12AffineEnvironment.transform 7 116 env58869 = env58870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58869 == env58870) = true)

theorem identity58870 : scanCanonicalize (H12AffineFastState.compose env58870 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound58870 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58871 : List Nat := [2,4,8,16,32,64,128,116,512,84,512,513,537,592,80,170,97,608,85,80,96,32,625,139,656,544,560,593,48,592,36,529,116,529,97,512]

theorem envBound58871 : H12AffineFastState.Bounded env58871 := by
  intro p hp
  have h : env58871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58870_58871 : H12AffineEnvironment.transform 9 84 env58870 = env58871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58870 == env58871) = true)

theorem identity58871 : scanCanonicalize (H12AffineFastState.compose env58871 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58871 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58872 : List Nat := [2,4,8,16,32,64,128,116,0,84,0,1,25,80,80,170,97,96,85,80,96,32,113,139,144,32,48,81,48,80,36,17,116,17,97,0]

theorem envBound58872 : H12AffineFastState.Bounded env58872 := by
  intro p hp
  have h : env58872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58871_58872 : H12AffineEnvironment.transform 8 0 env58871 = env58872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58871 == env58872) = true)

theorem identity58872 : scanCanonicalize (H12AffineFastState.compose env58872 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58872 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58873 : List Nat := [2,4,8,16,32,33,128,21,0,53,0,1,25,49,49,170,0,1,52,49,1,32,16,139,144,32,48,48,48,49,36,17,21,17,0,0]

theorem envBound58873 : H12AffineFastState.Bounded env58873 := by
  intro p hp
  have h : env58873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58872_58873 : H12AffineEnvironment.transform 5 33 env58872 = env58873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58872 == env58873) = true)

theorem identity58873 : scanCanonicalize (H12AffineFastState.compose env58873 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58873 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58874 : List Nat := [2,4,8,16,32,33,19,21,0,53,0,1,25,49,49,57,0,1,52,49,1,32,16,24,3,32,48,48,48,49,36,17,21,17,0,0]

theorem envBound58874 : H12AffineFastState.Bounded env58874 := by
  intro p hp
  have h : env58874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58873_58874 : H12AffineEnvironment.transform 6 19 env58873 = env58874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58873 == env58874) = true)

def env58875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,81,479,12556,5440,1025,81,2097152,32,8296,510,8329,8249,5393,4176,12637,805,1137,2101361,256,2101508,12556,512]

theorem envBound58875 : H12AffineFastState.Bounded env58875 := by
  intro p hp
  have h : env58875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58863_58875 : H12AffineEnvironment.transform 10 513 env58863 = env58875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58863 == env58875) = true)

theorem identity58875 : scanCanonicalize (H12AffineFastState.compose env58875 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5757) := by decide +kernel

theorem selectedBound58875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,5757,4177,81,479,1905,5440,1025,81,2097152,32,5653,510,5876,5700,5393,4176,1824,805,1137,2101361,256,2101508,1905,512]

theorem envBound58876 : H12AffineFastState.Bounded env58876 := by
  intro p hp
  have h : env58876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58875_58876 : H12AffineEnvironment.transform 12 5757 env58875 = env58876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5757 env58875 == env58876) = true)

def env58877 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5197,4177,81,479,1345,5440,1025,81,2097152,32,5157,510,5316,5236,5393,4176,1296,277,1137,2101361,256,2101508,1345,48]

theorem envBound58877 : H12AffineFastState.Bounded env58877 := by
  intro p hp
  have h : env58877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58876_58877 : H12AffineEnvironment.transform 8 48 env58876 = env58877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58876 == env58877) = true)

theorem identity58877 : scanCanonicalize (H12AffineFastState.compose env58877 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1076) := by decide +kernel

theorem selectedBound58877 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58878 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5197,4177,81,479,1345,5440,1025,81,1076,32,5157,510,5316,5236,5393,4176,1296,277,1137,5189,256,5424,1345,48]

theorem envBound58878 : H12AffineFastState.Bounded env58878 := by
  intro p hp
  have h : env58878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58877_58878 : H12AffineEnvironment.transform 20 1076 env58877 = env58878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1076 env58877 == env58878) = true)

theorem identity58878 : scanCanonicalize (H12AffineFastState.compose env58878 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58878 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58879 : List Nat := [2,4,8,16,32,64,128,117,48,1024,49,4096,5197,4177,81,170,1076,5173,1025,81,1076,32,5157,139,5316,5236,5220,4176,1125,96,1137,5189,117,5189,1076,48]

theorem envBound58879 : H12AffineFastState.Bounded env58879 := by
  intro p hp
  have h : env58879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58878_58879 : H12AffineEnvironment.transform 7 117 env58878 = env58879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58878 == env58879) = true)

theorem identity58879 : scanCanonicalize (H12AffineFastState.compose env58879 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound58879 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58880 : List Nat := [2,4,8,16,32,64,128,117,48,1024,49,1,1100,80,81,170,1076,1076,1025,81,1076,32,1060,139,1221,1141,1125,81,1125,96,1137,1092,117,1092,1076,48]

theorem envBound58880 : H12AffineFastState.Bounded env58880 := by
  intro p hp
  have h : env58880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58879_58880 : H12AffineEnvironment.transform 11 1 env58879 = env58880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env58879 == env58880) = true)

theorem identity58880 : scanCanonicalize (H12AffineFastState.compose env58880 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58880 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58881 : List Nat := [2,4,8,16,16,64,128,69,0,1024,1,1,1100,80,81,154,1028,1028,1025,81,1028,16,1044,139,1221,1093,1109,81,1109,80,1089,1092,69,1092,1028,0]

theorem envBound58881 : H12AffineFastState.Bounded env58881 := by
  intro p hp
  have h : env58881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58880_58881 : H12AffineEnvironment.transform 4 16 env58880 = env58881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58880 == env58881) = true)

theorem identity58881 : scanCanonicalize (H12AffineFastState.compose env58881 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58882 : List Nat := [2,4,8,16,16,17,128,20,0,1024,1,1,1053,1,0,154,1028,1028,1025,0,1028,16,1044,139,1172,1044,1028,0,1028,1,1040,1045,20,1045,1028,0]

theorem envBound58882 : H12AffineFastState.Bounded env58882 := by
  intro p hp
  have h : env58882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58881_58882 : H12AffineEnvironment.transform 5 17 env58881 = env58882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58881 == env58882) = true)

theorem identity58882 : scanCanonicalize (H12AffineFastState.compose env58882 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58883 : List Nat := [2,4,8,16,16,17,19,20,0,1024,1,1,1053,1,0,9,1028,1028,1025,0,1028,16,1044,24,1031,1044,1028,0,1028,1,1040,1045,20,1045,1028,0]

theorem envBound58883 : H12AffineFastState.Bounded env58883 := by
  intro p hp
  have h : env58883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58882_58883 : H12AffineEnvironment.transform 6 19 env58882 = env58883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58882 == env58883) = true)

theorem identity58883 : scanCanonicalize (H12AffineFastState.compose env58883 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58883 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58884 : List Nat := [2,4,8,10,10,11,9,14,0,1024,1,1,1031,1,0,9,1028,1028,1025,0,1028,10,1038,2,1031,1038,1028,0,1028,1,1034,1039,14,1039,1028,0]

theorem envBound58884 : H12AffineFastState.Bounded env58884 := by
  intro p hp
  have h : env58884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58883_58884 : H12AffineEnvironment.transform 3 10 env58883 = env58884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58883 == env58884) = true)

theorem identity58884 : scanCanonicalize (H12AffineFastState.compose env58884 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58884 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58885 : List Nat := [2,4,8,10,10,11,9,14,0,4,1,1,3,1,0,9,0,0,5,0,0,10,10,2,3,10,0,0,0,1,14,11,14,11,0,0]

theorem envBound58885 : H12AffineFastState.Bounded env58885 := by
  intro p hp
  have h : env58885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58884_58885 : H12AffineEnvironment.transform 9 4 env58884 = env58885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58884 == env58885) = true)

def env58886 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5196,4177,81,479,1344,5440,1025,81,2097152,32,5156,510,5317,5237,5393,4176,1297,276,1137,2101361,256,2101508,1344,49]

theorem envBound58886 : H12AffineFastState.Bounded env58886 := by
  intro p hp
  have h : env58886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58876_58886 : H12AffineEnvironment.transform 8 49 env58876 = env58886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58876 == env58886) = true)

theorem identity58886 : scanCanonicalize (H12AffineFastState.compose env58886 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1345) := by decide +kernel

theorem selectedBound58886 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58887 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5196,4177,81,479,1344,5440,1025,81,1345,32,5156,510,5317,5237,5393,4176,1297,276,1137,5424,256,5189,1344,49]

theorem envBound58887 : H12AffineFastState.Bounded env58887 := by
  intro p hp
  have h : env58887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58886_58887 : H12AffineEnvironment.transform 20 1345 env58886 = env58887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1345 env58886 == env58887) = true)

def env58888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2640,3038,15117,8001,1025,2640,2097152,32,8297,3070,8329,8248,5392,4176,15196,2340,3697,2103921,256,2101508,15117,512]

theorem envBound58888 : H12AffineFastState.Bounded env58888 := by
  intro p hp
  have h : env58888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58862_58888 : H12AffineEnvironment.transform 22 8297 env58862 = env58888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8297 env58862 == env58888) = true)

def env58889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,80,478,12557,5441,1025,80,2097152,32,8297,510,8329,8248,5392,4176,12636,804,1137,2101361,256,2101508,12557,512]

theorem envBound58889 : H12AffineFastState.Bounded env58889 := by
  intro p hp
  have h : env58889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58888_58889 : H12AffineEnvironment.transform 10 512 env58888 = env58889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58888 == env58889) = true)

theorem identity58889 : scanCanonicalize (H12AffineFastState.compose env58889 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5896) := by decide +kernel

theorem selectedBound58889 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,5896,4177,80,478,1541,5441,1025,80,2097152,32,5985,510,6017,5936,5392,4176,1620,804,1137,2101361,256,2101508,1541,512]

theorem envBound58890 : H12AffineFastState.Bounded env58890 := by
  intro p hp
  have h : env58890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58889_58890 : H12AffineEnvironment.transform 12 5896 env58889 = env58890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5896 env58889 == env58890) = true)

def env58891 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5432,4177,80,478,1077,5441,1025,80,2097152,32,5457,510,5553,5376,5392,4176,1124,276,1137,2101361,256,2101508,1077,48]

theorem envBound58891 : H12AffineFastState.Bounded env58891 := by
  intro p hp
  have h : env58891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58890_58891 : H12AffineEnvironment.transform 8 48 env58890 = env58891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58890 == env58891) = true)

theorem identity58891 : scanCanonicalize (H12AffineFastState.compose env58891 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound58891 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58892 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5432,4177,80,478,1077,5441,1025,80,1028,32,5457,510,5553,5376,5392,4176,1124,276,1137,5237,256,5376,1077,48]

theorem envBound58892 : H12AffineFastState.Bounded env58892 := by
  intro p hp
  have h : env58892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58891_58892 : H12AffineEnvironment.transform 20 1028 env58891 = env58892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env58891 == env58892) = true)

theorem identity58892 : scanCanonicalize (H12AffineFastState.compose env58892 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58892 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58893 : List Nat := [2,4,8,16,16,64,128,256,0,1024,0,4096,5384,4177,80,478,1029,5441,1025,80,1028,16,5457,462,5505,5376,5392,4176,1108,276,1089,5189,256,5376,1029,0]

theorem envBound58893 : H12AffineFastState.Bounded env58893 := by
  intro p hp
  have h : env58893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58892_58893 : H12AffineEnvironment.transform 4 16 env58892 = env58893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58892 == env58893) = true)

theorem identity58893 : scanCanonicalize (H12AffineFastState.compose env58893 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58893 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env58894 : List Nat := [2,4,8,16,16,64,128,68,0,1024,0,4096,5196,4177,80,154,1029,5125,1025,80,1028,16,5141,138,5317,5188,5204,4176,1108,80,1089,5189,68,5188,1029,0]

theorem envBound58894 : H12AffineFastState.Bounded env58894 := by
  intro p hp
  have h : env58894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58893_58894 : H12AffineEnvironment.transform 7 68 env58893 = env58894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58893 == env58894) = true)

def env58895 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5433,4177,80,478,1076,5441,1025,80,2097152,32,5456,510,5552,5377,5392,4176,1125,277,1137,2101361,256,2101508,1076,49]

theorem envBound58895 : H12AffineFastState.Bounded env58895 := by
  intro p hp
  have h : env58895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58890_58895 : H12AffineEnvironment.transform 8 49 env58890 = env58895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58890 == env58895) = true)

theorem identity58895 : scanCanonicalize (H12AffineFastState.compose env58895 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1393) := by decide +kernel

theorem selectedBound58895 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58896 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5433,4177,80,478,1076,5441,1025,80,1393,32,5456,510,5552,5377,5392,4176,1125,277,1137,5376,256,5237,1076,49]

theorem envBound58896 : H12AffineFastState.Bounded env58896 := by
  intro p hp
  have h : env58896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58895_58896 : H12AffineEnvironment.transform 20 1393 env58895 = env58896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1393 env58895 == env58896) = true)

theorem identity58896 : scanCanonicalize (H12AffineFastState.compose env58896 (packedSelected [1,3,4,6,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58896 : packedSelected [1,3,4,6,9,13] rootPS < 2^1333 := by decide +kernel

def env58897 : List Nat := [2,4,8,16,32,64,128,116,49,1024,49,4096,5197,4177,80,170,1076,5173,1025,80,1029,32,5156,138,5316,5237,5220,4176,1125,97,1137,5236,116,5237,1076,49]

theorem envBound58897 : H12AffineFastState.Bounded env58897 := by
  intro p hp
  have h : env58897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58896_58897 : H12AffineEnvironment.transform 7 116 env58896 = env58897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58896 == env58897) = true)

def env58898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,81,479,12556,5440,1025,81,2097152,32,8297,511,8329,8248,5392,4176,12637,805,1136,2101360,256,2101508,12556,512]

theorem envBound58898 : H12AffineFastState.Bounded env58898 := by
  intro p hp
  have h : env58898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58888_58898 : H12AffineEnvironment.transform 10 513 env58888 = env58898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58888 == env58898) = true)

theorem identity58898 : scanCanonicalize (H12AffineFastState.compose env58898 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1824) := by decide +kernel

theorem selectedBound58898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,8192,1905,81,479,9772,608,1025,81,2097152,32,8297,511,8329,8248,560,1904,9853,805,1136,2099024,256,2098724,9772,512]

theorem envBound58899 : H12AffineFastState.Bounded env58899 := by
  intro p hp
  have h : env58899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58898_58899 : H12AffineEnvironment.transform 11 1824 env58898 = env58899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1824 env58898 == env58899) = true)

def env58900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,536,1905,81,479,1076,608,1025,81,2097152,32,625,511,657,544,560,1904,1125,805,1136,2099024,256,2098724,1076,512]

theorem envBound58900 : H12AffineFastState.Bounded env58900 := by
  intro p hp
  have h : env58900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58899_58900 : H12AffineEnvironment.transform 12 536 env58899 = env58900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58899 == env58900) = true)

theorem identity58900 : scanCanonicalize (H12AffineFastState.compose env58900 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1589) := by decide +kernel

theorem selectedBound58900 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,536,1905,81,479,1076,608,1025,81,1589,32,625,511,657,544,560,1904,1125,805,1136,357,256,17,1076,512]

theorem envBound58901 : H12AffineFastState.Bounded env58901 := by
  intro p hp
  have h : env58901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58900_58901 : H12AffineEnvironment.transform 20 1589 env58900 = env58901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1589 env58900 == env58901) = true)

theorem identity58901 : scanCanonicalize (H12AffineFastState.compose env58901 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58901 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58902 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1313,25,1392,81,479,1076,97,1025,81,1076,32,112,511,144,33,49,1393,1125,292,1136,357,256,17,1076,1]

theorem envBound58902 : H12AffineFastState.Bounded env58902 := by
  intro p hp
  have h : env58902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58901_58902 : H12AffineEnvironment.transform 8 1 env58901 = env58902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58901 == env58902) = true)

theorem identity58902 : scanCanonicalize (H12AffineFastState.compose env58902 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58902 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env58903 : List Nat := [2,4,8,16,32,64,128,117,1,1024,0,1108,25,1029,81,170,1076,97,1025,81,1076,32,112,138,144,33,49,1028,1125,81,1136,16,117,17,1076,1]

theorem envBound58903 : H12AffineFastState.Bounded env58903 := by
  intro p hp
  have h : env58903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58902_58903 : H12AffineEnvironment.transform 7 117 env58902 = env58903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58902 == env58903) = true)

def env58904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,537,1905,81,479,1077,608,1025,81,2097152,32,624,511,656,545,560,1904,1124,805,1136,2099024,256,2098724,1077,512]

theorem envBound58904 : H12AffineFastState.Bounded env58904 := by
  intro p hp
  have h : env58904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58899_58904 : H12AffineEnvironment.transform 12 537 env58899 = env58904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58899 == env58904) = true)

theorem identity58904 : scanCanonicalize (H12AffineFastState.compose env58904 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1856) := by decide +kernel

theorem selectedBound58904 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1824,537,1905,81,479,1077,608,1025,81,1856,32,624,511,656,545,560,1904,1124,805,1136,16,256,356,1077,512]

theorem envBound58905 : H12AffineFastState.Bounded env58905 := by
  intro p hp
  have h : env58905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58904_58905 : H12AffineEnvironment.transform 20 1856 env58904 = env58905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1856 env58904 == env58905) = true)

theorem identity58905 : scanCanonicalize (H12AffineFastState.compose env58905 (packedSelected [1,3,4,6,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58905 : packedSelected [1,3,4,6,9,13] rootPS < 2^1333 := by decide +kernel

def env58906 : List Nat := [2,4,8,16,32,64,128,117,512,1024,513,1621,537,1540,81,170,1077,608,1025,81,1589,32,624,138,656,545,560,1541,1124,592,1136,16,117,17,1077,512]

theorem envBound58906 : H12AffineFastState.Bounded env58906 := by
  intro p hp
  have h : env58906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58905_58906 : H12AffineEnvironment.transform 7 117 env58905 = env58906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58905 == env58906) = true)

theorem identity58906 : scanCanonicalize (H12AffineFastState.compose env58906 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58906 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58907 : List Nat := [2,4,8,16,32,64,128,117,1,1024,0,1108,24,1029,81,170,1077,97,1025,81,1076,32,113,138,145,32,49,1028,1124,81,1136,16,117,17,1077,1]

theorem envBound58907 : H12AffineFastState.Bounded env58907 := by
  intro p hp
  have h : env58907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58906_58907 : H12AffineEnvironment.transform 8 1 env58906 = env58907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58906 == env58907) = true)

theorem identity58907 : scanCanonicalize (H12AffineFastState.compose env58907 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound58907 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env58908 : List Nat := [2,4,8,16,32,64,128,117,1,220,0,136,24,217,81,170,233,97,221,81,232,32,113,138,145,32,49,216,184,81,172,16,117,17,233,1]

theorem envBound58908 : H12AffineFastState.Bounded env58908 := by
  intro p hp
  have h : env58908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58907_58908 : H12AffineEnvironment.transform 9 220 env58907 = env58908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env58907 == env58908) = true)

theorem identity58908 : scanCanonicalize (H12AffineFastState.compose env58908 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound58908 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env58909 : List Nat := [2,4,8,16,32,64,57,117,1,101,0,49,24,96,81,19,80,97,100,81,81,32,113,51,40,32,49,97,1,81,21,16,117,17,80,1]

theorem envBound58909 : H12AffineFastState.Bounded env58909 := by
  intro p hp
  have h : env58909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58908_58909 : H12AffineEnvironment.transform 6 57 env58908 = env58909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58908 == env58909) = true)

theorem identity58909 : scanCanonicalize (H12AffineFastState.compose env58909 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58909 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env58910 : List Nat := [2,4,8,16,16,64,9,69,1,85,0,1,24,80,81,19,80,81,84,81,81,16,65,3,24,16,1,81,1,81,21,16,69,17,80,1]

theorem envBound58910 : H12AffineFastState.Bounded env58910 := by
  intro p hp
  have h : env58910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58909_58910 : H12AffineEnvironment.transform 4 16 env58909 = env58910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58909 == env58910) = true)

theorem identity58910 : scanCanonicalize (H12AffineFastState.compose env58910 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58911 : List Nat := [2,4,8,16,16,10,9,15,1,31,0,1,24,26,27,19,26,27,30,27,27,16,11,3,24,16,1,27,1,27,21,16,15,17,26,1]

theorem envBound58911 : H12AffineFastState.Bounded env58911 := by
  intro p hp
  have h : env58911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58910_58911 : H12AffineEnvironment.transform 5 10 env58910 = env58911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58910 == env58911) = true)

theorem identity58911 : scanCanonicalize (H12AffineFastState.compose env58911 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58911 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58912 : List Nat := [2,4,8,10,10,10,9,15,1,5,0,1,2,0,1,9,0,1,4,1,1,10,11,3,2,10,1,1,1,1,15,10,15,11,0,1]

theorem envBound58912 : H12AffineFastState.Bounded env58912 := by
  intro p hp
  have h : env58912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58911_58912 : H12AffineEnvironment.transform 3 10 env58911 = env58912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58911 == env58912) = true)

def env58913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399766,33554432,8409088,134217728,16385,77954,4280970,8463814,140775424,256,144993132,78035,33563273]

theorem envBound58913 : H12AffineFastState.Bounded env58913 := by
  intro p hp
  have h : env58913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58837_58913 : H12AffineEnvironment.transform 14 2641 env58837 = env58913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2641 env58837 == env58913) = true)

def env58914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399766,8328,8409088,134217728,16385,77954,4280970,8463814,140775424,256,144993132,78035,513]

theorem envBound58914 : H12AffineFastState.Bounded env58914 := by
  intro p hp
  have h : env58914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58913_58914 : H12AffineEnvironment.transform 24 8328 env58913 = env58914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58913 == env58914) = true)

theorem identity58914 : scanCanonicalize (H12AffineFastState.compose env58914 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 6376002) := by decide +kernel

theorem selectedBound58914 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,6376002,6382036,8328,6363714,134217728,16385,77954,4280970,6320004,140775424,256,138748206,78035,513]

theorem envBound58915 : H12AffineFastState.Bounded env58915 := by
  intro p hp
  have h : env58915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58914_58915 : H12AffineEnvironment.transform 22 6376002 env58914 = env58915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6376002 env58914 == env58915) = true)

theorem identity58915 : scanCanonicalize (H12AffineFastState.compose env58915 (packedSelected [6,25] rootPS)) = affineNative (2^(26+1) ^^^ 2374613) := by decide +kernel

theorem selectedBound58915 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,6376002,6382036,8328,6363714,2374613,16385,77954,4280970,6320004,4205525,256,6363899,78035,513]

theorem envBound58916 : H12AffineFastState.Bounded env58916 := by
  intro p hp
  have h : env58916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58915_58916 : H12AffineEnvironment.transform 26 2374613 env58915 = env58916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 2374613 env58915 == env58916) = true)

theorem identity58916 : scanCanonicalize (H12AffineFastState.compose env58916 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(21+1) ^^^ 2101644) := by decide +kernel

theorem selectedBound58916 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,2101644,89038,94296,8328,68558,2374613,16385,77954,2179846,32264,2112089,256,68471,78035,513]

theorem envBound58917 : H12AffineFastState.Bounded env58917 := by
  intro p hp
  have h : env58917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58916_58917 : H12AffineEnvironment.transform 21 2101644 env58916 = env58917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101644 env58916 == env58917) = true)

theorem identity58917 : scanCanonicalize (H12AffineFastState.compose env58917 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 16464) := by decide +kernel

theorem selectedBound58917 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,16464,20956,89038,94296,8328,68558,293765,16385,77954,66390,32264,31241,256,68471,78035,513]

theorem envBound58918 : H12AffineFastState.Bounded env58918 := by
  intro p hp
  have h : env58918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58917_58918 : H12AffineEnvironment.transform 20 16464 env58917 = env58918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16464 env58917 == env58918) = true)

theorem identity58918 : scanCanonicalize (H12AffineFastState.compose env58918 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 15116) := by decide +kernel

theorem selectedBound58918 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env58919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15116,2641,65536,78035,262144,1025,2641,15196,10960,73922,68436,8328,68558,262281,15117,77954,66390,1284,261,256,68471,78035,513]

theorem envBound58919 : H12AffineFastState.Bounded env58919 := by
  intro p hp
  have h : env58919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58918_58919 : H12AffineEnvironment.transform 13 15116 env58918 = env58919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15116 env58918 == env58919) = true)

theorem identity58919 : scanCanonicalize (H12AffineFastState.compose env58919 (packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 72395) := by decide +kernel

theorem selectedBound58919 : packedSelected [1,3,4,6,8,9,10,11,13,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env58920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15116,2641,65536,78035,72395,1025,2641,15196,10960,73922,68436,8328,68558,72258,15117,77954,66390,1284,261,256,68471,78035,513]

theorem envBound58920 : H12AffineFastState.Bounded env58920 := by
  intro p hp
  have h : env58920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58919_58920 : H12AffineEnvironment.transform 17 72395 env58919 = env58920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72395 env58919 == env58920) = true)

theorem identity58920 : scanCanonicalize (H12AffineFastState.compose env58920 (packedSelected [3,5,8,13,15,17,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 5103) := by decide +kernel

theorem selectedBound58920 : packedSelected [3,5,8,13,15,17,28,38] rootPS < 2^1333 := by decide +kernel

def env58921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,15116,2641,5103,9020,2340,1025,2641,15196,10960,13101,6331,8328,6177,2477,15117,9069,4281,1284,261,256,6296,9020,513]

theorem envBound58921 : H12AffineFastState.Bounded env58921 := by
  intro p hp
  have h : env58921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58920_58921 : H12AffineEnvironment.transform 15 5103 env58920 = env58921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5103 env58920 == env58921) = true)

theorem identity58921 : scanCanonicalize (H12AffineFastState.compose env58921 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2908) := by decide +kernel

theorem selectedBound58921 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2908,4176,2641,5103,2144,2340,1025,2641,4096,396,6257,6331,3028,6177,2477,4177,2097,4281,1284,261,256,6296,2144,513]

theorem envBound58922 : H12AffineFastState.Bounded env58922 := by
  intro p hp
  have h : env58922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58921_58922 : H12AffineEnvironment.transform 12 2908 env58921 = env58922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2908 env58921 == env58922) = true)

theorem identity58922 : scanCanonicalize (H12AffineFastState.compose env58922 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound58922 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,664,2908,712,2641,375,2144,2340,1025,2641,664,396,2793,2595,3028,2745,2477,713,2097,545,1284,261,256,2560,2144,513]

theorem envBound58923 : H12AffineFastState.Bounded env58923 := by
  intro p hp
  have h : env58923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58922_58923 : H12AffineEnvironment.transform 11 664 env58922 = env58923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env58922 == env58923) = true)

theorem identity58923 : scanCanonicalize (H12AffineFastState.compose env58923 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 625) := by decide +kernel

theorem selectedBound58923 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,625,664,301,712,32,375,529,853,1025,32,664,396,152,82,421,200,988,713,576,545,1284,261,256,113,529,513]

theorem envBound58924 : H12AffineFastState.Bounded env58924 := by
  intro p hp
  have h : env58924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58923_58924 : H12AffineEnvironment.transform 10 625 env58923 = env58924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 625 env58923 == env58924) = true)

theorem identity58924 : scanCanonicalize (H12AffineFastState.compose env58924 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58924 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58925 : List Nat := [2,4,8,16,32,64,128,172,512,1024,625,664,129,712,32,219,529,761,1025,32,664,32,152,82,9,200,624,713,576,545,1192,169,172,113,529,513]

theorem envBound58925 : H12AffineFastState.Bounded env58925 := by
  intro p hp
  have h : env58925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58924_58925 : H12AffineEnvironment.transform 7 172 env58924 = env58925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58924 == env58925) = true)

theorem identity58925 : scanCanonicalize (H12AffineFastState.compose env58925 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58925 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env58926 : List Nat := [2,4,8,16,32,64,19,63,512,1024,625,523,18,603,32,72,529,618,1025,32,523,32,11,82,9,91,624,602,576,545,1083,58,63,113,529,513]

theorem envBound58926 : H12AffineFastState.Bounded env58926 := by
  intro p hp
  have h : env58926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58925_58926 : H12AffineEnvironment.transform 6 19 env58925 = env58926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58925 == env58926) = true)

theorem identity58926 : scanCanonicalize (H12AffineFastState.compose env58926 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58926 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58927 : List Nat := [2,4,8,10,32,64,9,37,512,1024,619,523,8,577,32,72,523,618,1025,32,523,32,11,72,9,65,618,576,576,545,1057,32,37,107,523,513]

theorem envBound58927 : H12AffineFastState.Bounded env58927 := by
  intro p hp
  have h : env58927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58926_58927 : H12AffineEnvironment.transform 3 10 env58926 = env58927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58926 == env58927) = true)

theorem identity58927 : scanCanonicalize (H12AffineFastState.compose env58927 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound58927 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58928 : List Nat := [2,4,8,10,32,3,9,37,512,1024,552,523,8,514,32,11,523,553,1025,32,523,32,11,11,9,2,553,515,515,545,1057,32,37,40,523,513]

theorem envBound58928 : H12AffineFastState.Bounded env58928 := by
  intro p hp
  have h : env58928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58927_58928 : H12AffineEnvironment.transform 5 3 env58927 = env58928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env58927 == env58928) = true)

theorem identity58928 : scanCanonicalize (H12AffineFastState.compose env58928 (packedSelected [0,1,2,11] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58928 : packedSelected [0,1,2,11] rootPS < 2^1333 := by decide +kernel

def env58929 : List Nat := [2,4,8,10,32,3,9,37,42,1024,2,33,8,40,32,11,33,3,1025,32,33,32,11,11,9,2,3,41,41,11,1057,32,37,40,33,43]

theorem envBound58929 : H12AffineFastState.Bounded env58929 := by
  intro p hp
  have h : env58929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58928_58929 : H12AffineEnvironment.transform 8 42 env58928 = env58929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58928 == env58929) = true)

theorem identity58929 : scanCanonicalize (H12AffineFastState.compose env58929 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58929 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58930 : List Nat := [2,4,1,3,32,3,0,37,35,1024,2,33,1,33,32,2,33,3,1025,32,33,32,2,2,0,2,3,32,32,2,1057,32,37,33,33,34]

theorem envBound58930 : H12AffineFastState.Bounded env58930 := by
  intro p hp
  have h : env58930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58929_58930 : H12AffineEnvironment.transform 2 1 env58929 = env58930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58929 == env58930) = true)

theorem identity58930 : scanCanonicalize (H12AffineFastState.compose env58930 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound58930 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env58931 : List Nat := [2,4,1,3,32,3,0,37,35,6,2,33,1,33,32,2,33,3,7,32,33,32,2,2,0,2,3,32,32,2,39,32,37,33,33,34]

theorem envBound58931 : H12AffineFastState.Bounded env58931 := by
  intro p hp
  have h : env58931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58930_58931 : H12AffineEnvironment.transform 9 6 env58930 = env58931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env58930 == env58931) = true)

def leafEnv58931 : List Nat := [2,4,1,3,32,3,0,37,35,6,2,33,1,33,32,2,33,3,7,32,33,32,2,2,38,0,1,2,3,32,32,2,39,32,37,33,4,2,33,34,1,33,0]

def active58931 : List Nat := [0,1,4]

def tree58931 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58931 : H12WitnessSearch.Good tree58931 := H12GlobalWitnessIndex.good

theorem leafIdentity58931 : H12AffineFastState.composeSystem env58931 rootObs = leafEnv58931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58931 rootObs == leafEnv58931) = true)

theorem terminalChecked58931 : H12PackedTerminal.terminalCheckFast leafEnv58931 active58931 tree58931 = true := by decide +kernel

def env58932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399766,8329,8409088,134217728,16385,77954,4280970,8463814,140775424,256,144993132,78035,512]

theorem envBound58932 : H12AffineFastState.Bounded env58932 := by
  intro p hp
  have h : env58932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58913_58932 : H12AffineEnvironment.transform 24 8329 env58913 = env58932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env58913 == env58932) = true)

theorem identity58932 : scanCanonicalize (H12AffineFastState.compose env58932 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58932 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env58933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399766,8329,8388689,134217728,4176,77954,4260571,8463814,140775424,256,144980797,78035,512]

theorem envBound58933 : H12AffineFastState.Bounded env58933 := by
  intro p hp
  have h : env58933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58932_58933 : H12AffineEnvironment.transform 13 4177 env58932 = env58933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58932 == env58933) = true)

theorem identity58933 : scanCanonicalize (H12AffineFastState.compose env58933 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58933 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,65536,78035,262144,1025,2641,2097152,4194304,8388608,8399766,8329,8388689,12919238,4176,77954,4260571,8463814,10564038,256,6363899,78035,512]

theorem envBound58934 : H12AffineFastState.Bounded env58934 := by
  intro p hp
  have h : env58934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58933_58934 : H12AffineEnvironment.transform 26 12919238 env58933 = env58934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58933 == env58934) = true)

theorem identity58934 : scanCanonicalize (H12AffineFastState.compose env58934 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 3039) := by decide +kernel

theorem selectedBound58934 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3039,15116,262144,1025,2641,2097152,4194304,8388608,8399766,8329,8388689,12855833,4176,15197,4196612,8400409,10500633,256,6295844,15116,512]

theorem envBound58935 : H12AffineFastState.Bounded env58935 := by
  intro p hp
  have h : env58935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58934_58935 : H12AffineEnvironment.transform 15 3039 env58934 = env58935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3039 env58934 == env58935) = true)

theorem identity58935 : scanCanonicalize (H12AffineFastState.compose env58935 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 270177) := by decide +kernel

theorem selectedBound58935 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3039,15116,262144,1025,2641,2097152,270177,8388608,8399766,8329,8388689,8402296,4176,15197,267877,8400409,10500633,256,2362949,15116,512]

theorem envBound58936 : H12AffineFastState.Bounded env58936 := by
  intro p hp
  have h : env58936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58935_58936 : H12AffineEnvironment.transform 21 270177 env58935 = env58936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270177 env58935 == env58936) = true)

theorem identity58936 : scanCanonicalize (H12AffineFastState.compose env58936 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound58936 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env58937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3039,15116,8001,1025,2641,2097152,32,8388608,8399766,8329,8388689,8402296,4176,15197,2340,8400409,10500633,256,2101508,15116,512]

theorem envBound58937 : H12AffineFastState.Bounded env58937 := by
  intro p hp
  have h : env58937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58936_58937 : H12AffineEnvironment.transform 17 8001 env58936 = env58937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env58936 == env58937) = true)

def env58938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3039,15116,8001,1025,2641,2097152,32,8296,3070,8329,8249,5392,4176,15197,2340,3697,2103921,256,2101508,15116,512]

theorem envBound58938 : H12AffineFastState.Bounded env58938 := by
  intro p hp
  have h : env58938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58937_58938 : H12AffineEnvironment.transform 22 8296 env58937 = env58938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8296 env58937 == env58938) = true)

def env58939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,81,479,12556,5441,1025,81,2097152,32,8296,510,8329,8249,5392,4176,12637,804,1137,2101361,256,2101508,12556,512]

theorem envBound58939 : H12AffineFastState.Bounded env58939 := by
  intro p hp
  have h : env58939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58938_58939 : H12AffineEnvironment.transform 10 512 env58938 = env58939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58938 == env58939) = true)

theorem identity58939 : scanCanonicalize (H12AffineFastState.compose env58939 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5756) := by decide +kernel

theorem selectedBound58939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,5756,4177,81,479,1904,5441,1025,81,2097152,32,5652,510,5877,5701,5392,4176,1825,804,1137,2101361,256,2101508,1904,512]

theorem envBound58940 : H12AffineFastState.Bounded env58940 := by
  intro p hp
  have h : env58940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58939_58940 : H12AffineEnvironment.transform 12 5756 env58939 = env58940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5756 env58939 == env58940) = true)

def env58941 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5196,4177,81,479,1344,5441,1025,81,2097152,32,5156,510,5317,5237,5392,4176,1297,276,1137,2101361,256,2101508,1344,48]

theorem envBound58941 : H12AffineFastState.Bounded env58941 := by
  intro p hp
  have h : env58941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58940_58941 : H12AffineEnvironment.transform 8 48 env58940 = env58941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58940 == env58941) = true)

theorem identity58941 : scanCanonicalize (H12AffineFastState.compose env58941 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4389) := by decide +kernel

theorem selectedBound58941 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58942 : List Nat := [2,4,8,16,32,64,128,256,48,1024,48,4096,5196,4177,81,479,1344,5441,1025,81,4389,32,5156,510,5317,5237,5392,4176,1297,276,1137,340,256,33,1344,48]

theorem envBound58942 : H12AffineFastState.Bounded env58942 := by
  intro p hp
  have h : env58942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58941_58942 : H12AffineEnvironment.transform 20 4389 env58941 = env58942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4389 env58941 == env58942) = true)

theorem identity58942 : scanCanonicalize (H12AffineFastState.compose env58942 (packedSelected [1,3,6,7,9,10,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58942 : packedSelected [1,3,6,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env58943 : List Nat := [2,4,8,16,32,64,128,69,48,1024,48,4096,5196,4177,81,154,1029,5124,1025,81,4192,32,5156,187,5317,5237,5205,4176,1108,81,1137,17,69,33,1029,48]

theorem envBound58943 : H12AffineFastState.Bounded env58943 := by
  intro p hp
  have h : env58943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58942_58943 : H12AffineEnvironment.transform 7 69 env58942 = env58943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58942 == env58943) = true)

theorem identity58943 : scanCanonicalize (H12AffineFastState.compose env58943 (packedSelected [0,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58943 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env58944 : List Nat := [2,4,8,16,17,64,128,69,1,1024,1,4096,5196,4177,81,154,1029,5124,1025,81,4177,17,5141,138,5317,5188,5205,4176,1108,81,1088,17,69,16,1029,1]

theorem envBound58944 : H12AffineFastState.Bounded env58944 := by
  intro p hp
  have h : env58944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58943_58944 : H12AffineEnvironment.transform 4 17 env58943 = env58944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58943 == env58944) = true)

def env58945 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5197,4177,81,479,1345,5441,1025,81,2097152,32,5157,510,5316,5236,5392,4176,1296,277,1137,2101361,256,2101508,1345,49]

theorem envBound58945 : H12AffineFastState.Bounded env58945 := by
  intro p hp
  have h : env58945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58940_58945 : H12AffineEnvironment.transform 8 49 env58940 = env58945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58940 == env58945) = true)

theorem identity58945 : scanCanonicalize (H12AffineFastState.compose env58945 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58945 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58946 : List Nat := [2,4,8,16,32,64,128,256,49,1024,49,4096,5197,4177,81,479,1345,5441,1025,81,4177,32,5157,510,5316,5236,5392,4176,1296,277,1137,32,256,341,1345,49]

theorem envBound58946 : H12AffineFastState.Bounded env58946 := by
  intro p hp
  have h : env58946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58945_58946 : H12AffineEnvironment.transform 20 4177 env58945 = env58946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4177 env58945 == env58946) = true)

theorem identity58946 : scanCanonicalize (H12AffineFastState.compose env58946 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58946 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58947 : List Nat := [2,4,8,16,32,64,128,116,49,1024,49,4096,5197,4177,81,171,1077,5173,1025,81,4177,32,5157,138,5316,5236,5220,4176,1124,97,1137,32,116,33,1077,49]

theorem envBound58947 : H12AffineFastState.Bounded env58947 := by
  intro p hp
  have h : env58947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58946_58947 : H12AffineEnvironment.transform 7 116 env58946 = env58947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58946 == env58947) = true)

theorem identity58947 : scanCanonicalize (H12AffineFastState.compose env58947 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58947 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58948 : List Nat := [2,4,8,16,17,64,128,69,0,1024,0,4096,5197,4177,81,154,1028,5124,1025,81,4177,17,5140,138,5316,5189,5205,4176,1109,80,1088,17,69,16,1028,0]

theorem envBound58948 : H12AffineFastState.Bounded env58948 := by
  intro p hp
  have h : env58948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58947_58948 : H12AffineEnvironment.transform 4 17 env58947 = env58948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58947 == env58948) = true)

def env58949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,80,478,12557,5440,1025,80,2097152,32,8296,511,8329,8249,5392,4176,12636,805,1136,2101360,256,2101508,12557,512]

theorem envBound58949 : H12AffineFastState.Bounded env58949 := by
  intro p hp
  have h : env58949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58938_58949 : H12AffineEnvironment.transform 10 513 env58938 = env58949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58938 == env58949) = true)

theorem identity58949 : scanCanonicalize (H12AffineFastState.compose env58949 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1620) := by decide +kernel

theorem selectedBound58949 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,8192,1541,80,478,10073,788,1025,80,2097152,32,8296,511,8329,8249,836,1540,9992,805,1136,2098724,256,2099024,10073,512]

theorem envBound58950 : H12AffineFastState.Bounded env58950 := by
  intro p hp
  have h : env58950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58949_58950 : H12AffineEnvironment.transform 11 1620 env58949 = env58950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1620 env58949 == env58950) = true)

def env58951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,536,1541,80,478,1345,788,1025,80,2097152,32,624,511,657,545,836,1540,1296,805,1136,2098724,256,2099024,1345,512]

theorem envBound58951 : H12AffineFastState.Bounded env58951 := by
  intro p hp
  have h : env58951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58950_58951 : H12AffineEnvironment.transform 12 536 env58950 = env58951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58950 == env58951) = true)

theorem identity58951 : scanCanonicalize (H12AffineFastState.compose env58951 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1540) := by decide +kernel

theorem selectedBound58951 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,536,1541,80,478,1345,788,1025,80,1540,32,624,511,657,545,836,1540,1296,805,1136,32,256,340,1345,512]

theorem envBound58952 : H12AffineFastState.Bounded env58952 := by
  intro p hp
  have h : env58952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58951_58952 : H12AffineEnvironment.transform 20 1540 env58951 = env58952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1540 env58951 == env58952) = true)

theorem identity58952 : scanCanonicalize (H12AffineFastState.compose env58952 (packedSelected [1,5,6,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58952 : packedSelected [1,5,6,12] rootPS < 2^1333 := by decide +kernel

def env58953 : List Nat := [2,4,8,16,32,64,128,117,512,1024,513,1620,536,1541,80,171,1076,609,1025,80,1540,32,624,138,657,545,561,1540,1125,592,1136,32,117,33,1076,512]

theorem envBound58953 : H12AffineFastState.Bounded env58953 := by
  intro p hp
  have h : env58953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58952_58953 : H12AffineEnvironment.transform 7 117 env58952 = env58953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58952 == env58953) = true)

theorem identity58953 : scanCanonicalize (H12AffineFastState.compose env58953 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58953 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58954 : List Nat := [2,4,8,16,32,64,128,117,1,1024,0,1109,25,1028,80,171,1076,96,1025,80,1029,32,113,138,144,32,48,1029,1125,81,1136,32,117,33,1076,1]

theorem envBound58954 : H12AffineFastState.Bounded env58954 := by
  intro p hp
  have h : env58954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58953_58954 : H12AffineEnvironment.transform 8 1 env58953 = env58954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58953 == env58954) = true)

def env58955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,537,1541,80,478,1344,788,1025,80,2097152,32,625,511,656,544,836,1540,1297,805,1136,2098724,256,2099024,1344,512]

theorem envBound58955 : H12AffineFastState.Bounded env58955 := by
  intro p hp
  have h : env58955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58950_58955 : H12AffineEnvironment.transform 12 537 env58950 = env58955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58950 == env58955) = true)

theorem identity58955 : scanCanonicalize (H12AffineFastState.compose env58955 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1905) := by decide +kernel

theorem selectedBound58955 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,1620,537,1541,80,478,1344,788,1025,80,1905,32,625,511,656,544,836,1540,1297,805,1136,341,256,33,1344,512]

theorem envBound58956 : H12AffineFastState.Bounded env58956 := by
  intro p hp
  have h : env58956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58955_58956 : H12AffineEnvironment.transform 20 1905 env58955 = env58956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1905 env58955 == env58956) = true)

theorem identity58956 : scanCanonicalize (H12AffineFastState.compose env58956 (packedSelected [1,3,6,7,9,10,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58956 : packedSelected [1,3,6,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env58957 : List Nat := [2,4,8,16,32,64,128,256,373,1024,372,1313,364,1392,80,478,1344,97,1025,80,1028,32,260,511,485,341,49,1393,1297,80,1136,341,256,33,1344,373]

theorem envBound58957 : H12AffineFastState.Bounded env58957 := by
  intro p hp
  have h : env58957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58956_58957 : H12AffineEnvironment.transform 8 373 env58956 = env58957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58956 == env58957) = true)

theorem identity58957 : scanCanonicalize (H12AffineFastState.compose env58957 (packedSelected [0,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58957 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env58958 : List Nat := [2,4,8,16,32,64,128,117,0,1024,1,1108,25,1029,80,171,1077,97,1025,80,1028,32,113,138,144,32,49,1028,1124,80,1136,32,117,33,1077,0]

theorem envBound58958 : H12AffineFastState.Bounded env58958 := by
  intro p hp
  have h : env58958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58957_58958 : H12AffineEnvironment.transform 7 117 env58957 = env58958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58957 == env58958) = true)

def env58959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2641,3039,15116,8001,1025,2641,2097152,32,8297,3071,8329,8248,5393,4176,15197,2340,3696,2103920,256,2101508,15116,512]

theorem envBound58959 : H12AffineFastState.Bounded env58959 := by
  intro p hp
  have h : env58959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58937_58959 : H12AffineEnvironment.transform 22 8297 env58937 = env58959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8297 env58937 == env58959) = true)

def env58960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,4096,8192,4177,81,479,12556,5441,1025,81,2097152,32,8297,511,8329,8248,5393,4176,12637,804,1136,2101360,256,2101508,12556,512]

theorem envBound58960 : H12AffineFastState.Bounded env58960 := by
  intro p hp
  have h : env58960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58959_58960 : H12AffineEnvironment.transform 10 512 env58959 = env58960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env58959 == env58960) = true)

theorem identity58960 : scanCanonicalize (H12AffineFastState.compose env58960 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1825) := by decide +kernel

theorem selectedBound58960 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,8192,1904,81,479,9773,608,1025,81,2097152,32,8297,511,8329,8248,560,1905,9852,804,1136,2099025,256,2098725,9773,512]

theorem envBound58961 : H12AffineFastState.Bounded env58961 := by
  intro p hp
  have h : env58961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58960_58961 : H12AffineEnvironment.transform 11 1825 env58960 = env58961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1825 env58960 == env58961) = true)

def env58962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,536,1904,81,479,1077,608,1025,81,2097152,32,625,511,657,544,560,1905,1124,804,1136,2099025,256,2098725,1077,512]

theorem envBound58962 : H12AffineFastState.Bounded env58962 := by
  intro p hp
  have h : env58962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58961_58962 : H12AffineEnvironment.transform 12 536 env58961 = env58962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env58961 == env58962) = true)

theorem identity58962 : scanCanonicalize (H12AffineFastState.compose env58962 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1393) := by decide +kernel

theorem selectedBound58962 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,536,1904,81,479,1077,608,1025,81,1393,32,625,511,657,544,560,1905,1124,804,1136,544,256,852,1077,512]

theorem envBound58963 : H12AffineFastState.Bounded env58963 := by
  intro p hp
  have h : env58963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58962_58963 : H12AffineEnvironment.transform 20 1393 env58962 = env58963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1393 env58962 == env58963) = true)

theorem identity58963 : scanCanonicalize (H12AffineFastState.compose env58963 (packedSelected [0,3,5,7,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58963 : packedSelected [0,3,5,7,12,13] rootPS < 2^1333 := by decide +kernel

def env58964 : List Nat := [2,4,8,16,32,64,128,256,373,1024,373,1108,365,1029,81,479,1077,277,1025,81,1393,32,260,511,484,341,325,1028,1124,81,1136,341,256,33,1077,373]

theorem envBound58964 : H12AffineFastState.Bounded env58964 := by
  intro p hp
  have h : env58964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58963_58964 : H12AffineEnvironment.transform 8 373 env58963 = env58964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58963 == env58964) = true)

theorem identity58964 : scanCanonicalize (H12AffineFastState.compose env58964 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58964 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58965 : List Nat := [2,4,8,16,32,64,128,117,0,1024,0,1108,24,1029,81,170,1077,96,1025,81,1028,32,113,138,145,32,48,1028,1124,81,1136,32,117,33,1077,0]

theorem envBound58965 : H12AffineFastState.Bounded env58965 := by
  intro p hp
  have h : env58965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58964_58965 : H12AffineEnvironment.transform 7 117 env58964 = env58965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58964 == env58965) = true)

def env58966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,537,1904,81,479,1076,608,1025,81,2097152,32,624,511,656,545,560,1905,1125,804,1136,2099025,256,2098725,1076,512]

theorem envBound58966 : H12AffineFastState.Bounded env58966 := by
  intro p hp
  have h : env58966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58961_58966 : H12AffineEnvironment.transform 12 537 env58961 = env58966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env58961 == env58966) = true)

theorem identity58966 : scanCanonicalize (H12AffineFastState.compose env58966 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 1029) := by decide +kernel

theorem selectedBound58966 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,512,1825,537,1904,81,479,1076,608,1025,81,1029,32,624,511,656,545,560,1905,1125,804,1136,852,256,544,1076,512]

theorem envBound58967 : H12AffineFastState.Bounded env58967 := by
  intro p hp
  have h : env58967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58966_58967 : H12AffineEnvironment.transform 20 1029 env58966 = env58967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1029 env58966 == env58967) = true)

theorem identity58967 : scanCanonicalize (H12AffineFastState.compose env58967 (packedSelected [4,9,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58967 : packedSelected [4,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58968 : List Nat := [2,4,8,16,32,64,128,117,512,1024,512,1620,537,1541,81,170,1076,608,1025,81,1029,32,624,138,656,545,560,1540,1125,593,1136,545,117,544,1076,512]

theorem envBound58968 : H12AffineFastState.Bounded env58968 := by
  intro p hp
  have h : env58968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58967_58968 : H12AffineEnvironment.transform 7 117 env58967 = env58968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58967 == env58968) = true)

theorem identity58968 : scanCanonicalize (H12AffineFastState.compose env58968 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58968 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58969 : List Nat := [2,4,8,16,32,64,128,117,1,1024,1,1109,24,1028,81,170,1076,97,1025,81,1029,32,113,138,145,32,49,1029,1125,80,1136,32,117,33,1076,1]

theorem envBound58969 : H12AffineFastState.Bounded env58969 := by
  intro p hp
  have h : env58969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58968_58969 : H12AffineEnvironment.transform 8 1 env58968 = env58969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58968 == env58969) = true)

def env58970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,8192,4177,80,478,12557,5440,1025,80,2097152,32,8297,510,8329,8248,5393,4176,12636,805,1137,2101361,256,2101508,12557,512]

theorem envBound58970 : H12AffineFastState.Bounded env58970 := by
  intro p hp
  have h : env58970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58959_58970 : H12AffineEnvironment.transform 10 513 env58959 = env58970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58959 == env58970) = true)

theorem identity58970 : scanCanonicalize (H12AffineFastState.compose env58970 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5897) := by decide +kernel

theorem selectedBound58970 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,513,4096,5897,4177,80,478,1540,5440,1025,80,2097152,32,5984,510,6016,5937,5393,4176,1621,805,1137,2101361,256,2101508,1540,512]

theorem envBound58971 : H12AffineFastState.Bounded env58971 := by
  intro p hp
  have h : env58971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58970_58971 : H12AffineEnvironment.transform 12 5897 env58970 = env58971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5897 env58970 == env58971) = true)

def env58972 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5433,4177,80,478,1076,5440,1025,80,2097152,32,5456,510,5552,5377,5393,4176,1125,277,1137,2101361,256,2101508,1076,48]

theorem envBound58972 : H12AffineFastState.Bounded env58972 := by
  intro p hp
  have h : env58972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58971_58972 : H12AffineEnvironment.transform 8 48 env58971 = env58972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58971 == env58972) = true)

theorem identity58972 : scanCanonicalize (H12AffineFastState.compose env58972 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4192) := by decide +kernel

theorem selectedBound58972 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58973 : List Nat := [2,4,8,16,32,64,128,256,48,1024,49,4096,5433,4177,80,478,1076,5440,1025,80,4192,32,5456,510,5552,5377,5393,4176,1125,277,1137,17,256,356,1076,48]

theorem envBound58973 : H12AffineFastState.Bounded env58973 := by
  intro p hp
  have h : env58973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58972_58973 : H12AffineEnvironment.transform 20 4192 env58972 = env58973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4192 env58972 == env58973) = true)

theorem identity58973 : scanCanonicalize (H12AffineFastState.compose env58973 (packedSelected [0,3,5,7,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58973 : packedSelected [0,3,5,7,12,13] rootPS < 2^1333 := by decide +kernel

def env58974 : List Nat := [2,4,8,16,32,64,128,69,48,1024,49,4096,5244,4177,80,155,1076,5125,1025,80,4192,32,5141,187,5365,5188,5204,4176,1125,80,1137,17,69,33,1076,48]

theorem envBound58974 : H12AffineFastState.Bounded env58974 := by
  intro p hp
  have h : env58974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58973_58974 : H12AffineEnvironment.transform 7 69 env58973 = env58974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58973 == env58974) = true)

theorem identity58974 : scanCanonicalize (H12AffineFastState.compose env58974 (packedSelected [1,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58974 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env58975 : List Nat := [2,4,8,16,17,64,128,69,1,1024,0,4096,5197,4177,80,155,1029,5125,1025,80,4177,17,5141,138,5316,5188,5204,4176,1108,80,1088,17,69,16,1029,1]

theorem envBound58975 : H12AffineFastState.Bounded env58975 := by
  intro p hp
  have h : env58975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58974_58975 : H12AffineEnvironment.transform 4 17 env58974 = env58975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58974 == env58975) = true)

def env58976 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5432,4177,80,478,1077,5440,1025,80,2097152,32,5457,510,5553,5376,5393,4176,1124,276,1137,2101361,256,2101508,1077,49]

theorem envBound58976 : H12AffineFastState.Bounded env58976 := by
  intro p hp
  have h : env58976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58971_58976 : H12AffineEnvironment.transform 8 49 env58971 = env58976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58971 == env58976) = true)

theorem identity58976 : scanCanonicalize (H12AffineFastState.compose env58976 (packedSelected [11] rootPS)) = affineNative (2^(20+1) ^^^ 4372) := by decide +kernel

theorem selectedBound58976 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58977 : List Nat := [2,4,8,16,32,64,128,256,49,1024,48,4096,5432,4177,80,478,1077,5440,1025,80,4372,32,5457,510,5553,5376,5393,4176,1124,276,1137,357,256,16,1077,49]

theorem envBound58977 : H12AffineFastState.Bounded env58977 := by
  intro p hp
  have h : env58977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58976_58977 : H12AffineEnvironment.transform 20 4372 env58976 = env58977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4372 env58976 == env58977) = true)

theorem identity58977 : scanCanonicalize (H12AffineFastState.compose env58977 (packedSelected [4,9,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58977 : packedSelected [4,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58978 : List Nat := [2,4,8,16,32,64,128,116,49,1024,48,4096,5196,4177,80,170,1077,5172,1025,80,4192,32,5157,138,5317,5236,5221,4176,1124,96,1137,17,116,16,1077,49]

theorem envBound58978 : H12AffineFastState.Bounded env58978 := by
  intro p hp
  have h : env58978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58977_58978 : H12AffineEnvironment.transform 7 116 env58977 = env58978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58977 == env58978) = true)

theorem identity58978 : scanCanonicalize (H12AffineFastState.compose env58978 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58978 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58979 : List Nat := [2,4,8,16,17,64,128,69,0,1024,1,4096,5196,4177,80,155,1028,5125,1025,80,4177,17,5140,138,5317,5189,5204,4176,1109,81,1088,17,69,16,1028,0]

theorem envBound58979 : H12AffineFastState.Bounded env58979 := by
  intro p hp
  have h : env58979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58978_58979 : H12AffineEnvironment.transform 4 17 env58978 = env58979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58978 == env58979) = true)

def env58980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131153,4315355,8463814,4294967296,256,4307611965,131073,33563273]

theorem envBound58980 : H12AffineFastState.Bounded env58980 := by
  intro p hp
  have h : env58980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58834_58980 : H12AffineEnvironment.transform 34 131073 env58834 = env58980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58834 == env58980) = true)

theorem identity58980 : scanCanonicalize (H12AffineFastState.compose env58980 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 138883282) := by decide +kernel

theorem selectedBound58980 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131153,4315355,8463814,138883282,256,143114735,131073,33563273]

theorem envBound58981 : H12AffineFastState.Bounded env58981 := by
  intro p hp
  have h : env58981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58980_58981 : H12AffineEnvironment.transform 31 138883282 env58980 = env58981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 138883282 env58980 == env58981) = true)

theorem identity58981 : scanCanonicalize (H12AffineFastState.compose env58981 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound58981 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,12992837,16385,131153,4315355,8463814,8483223,256,4292778,131073,33563273]

theorem envBound58982 : H12AffineFastState.Bounded env58982 := by
  intro p hp
  have h : env58982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58981_58982 : H12AffineEnvironment.transform 26 12992837 env58981 = env58982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env58981 == env58982) = true)

def env58983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8388688,12980501,4177,131153,4294795,8463814,8462791,256,4292778,131073,33563273]

theorem envBound58983 : H12AffineFastState.Bounded env58983 := by
  intro p hp
  have h : env58983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58982_58983 : H12AffineEnvironment.transform 13 4176 env58982 = env58983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58982 == env58983) = true)

theorem identity58983 : scanCanonicalize (H12AffineFastState.compose env58983 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58983 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388688,12980501,4177,131153,4294795,8463814,8462791,256,4292778,131073,513]

theorem envBound58984 : H12AffineFastState.Bounded env58984 := by
  intro p hp
  have h : env58984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58983_58984 : H12AffineEnvironment.transform 24 8328 env58983 = env58984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58983 == env58984) = true)

theorem identity58984 : scanCanonicalize (H12AffineFastState.compose env58984 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 209246) := by decide +kernel

theorem selectedBound58984 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,209246,8388608,8430023,8328,8388688,8724555,4177,131153,178645,8463814,8462791,256,176628,131073,513]

theorem envBound58985 : H12AffineFastState.Bounded env58985 := by
  intro p hp
  have h : env58985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58984_58985 : H12AffineEnvironment.transform 21 209246 env58984 = env58985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 209246 env58984 == env58985) = true)

theorem identity58985 : scanCanonicalize (H12AffineFastState.compose env58985 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58985 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,209246,8388608,8430023,8328,8388688,8724555,4177,131153,178645,8463814,8462791,256,176628,131073,513]

theorem envBound58986 : H12AffineFastState.Bounded env58986 := by
  intro p hp
  have h : env58986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58985_58986 : H12AffineEnvironment.transform 20 4096 env58985 = env58986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58985 == env58986) = true)

theorem identity58986 : scanCanonicalize (H12AffineFastState.compose env58986 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound58986 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,209246,98766,73737,8328,98718,303493,4177,131153,178645,41992,40969,256,176628,131073,513]

theorem envBound58987 : H12AffineFastState.Bounded env58987 := by
  intro p hp
  have h : env58987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58986_58987 : H12AffineEnvironment.transform 22 98766 env58986 = env58987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env58986 == env58987) = true)

theorem identity58987 : scanCanonicalize (H12AffineFastState.compose env58987 (packedSelected [6,25] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound58987 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,4096,396,98766,73737,8328,98718,303493,4177,77955,100615,41992,40969,256,98598,78035,513]

theorem envBound58988 : H12AffineFastState.Bounded env58988 := by
  intro p hp
  have h : env58988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58987_58988 : H12AffineEnvironment.transform 16 78034 env58987 = env58988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env58987 == env58988) = true)

theorem identity58988 : scanCanonicalize (H12AffineFastState.compose env58988 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound58988 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58989 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,32768,65536,77835,262144,1025,32768,4096,341,98583,73737,8273,98631,303452,4177,77914,100615,41992,40969,256,98598,77834,513]

theorem envBound58989 : H12AffineFastState.Bounded env58989 := by
  intro p hp
  have h : env58989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58988_58989 : H12AffineEnvironment.transform 6 89 env58988 = env58989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58988 == env58989) = true)

theorem identity58989 : scanCanonicalize (H12AffineFastState.compose env58989 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound58989 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58990 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,32768,8283,4176,262144,1025,32768,4096,341,41292,82,8273,41244,303452,4177,4097,43356,41992,40969,256,41341,4177,513]

theorem envBound58990 : H12AffineFastState.Bounded env58990 := by
  intro p hp
  have h : env58990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58989_58990 : H12AffineEnvironment.transform 15 8283 env58989 = env58990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env58989 == env58990) = true)

theorem identity58990 : scanCanonicalize (H12AffineFastState.compose env58990 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound58990 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58991 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,113,8283,4176,262144,1025,113,4096,341,8509,82,8273,8557,270637,4177,4097,10541,9337,8312,256,8460,4177,513]

theorem envBound58991 : H12AffineFastState.Bounded env58991 := by
  intro p hp
  have h : env58991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58990_58991 : H12AffineEnvironment.transform 14 113 env58990 = env58991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env58990 == env58991) = true)

theorem identity58991 : scanCanonicalize (H12AffineFastState.compose env58991 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound58991 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58992 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,113,8283,4176,2048,1025,113,4096,341,8509,82,8273,8557,10541,4177,4097,10541,9337,8312,256,8460,4177,513]

theorem envBound58992 : H12AffineFastState.Bounded env58992 := by
  intro p hp
  have h : env58992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58991_58992 : H12AffineEnvironment.transform 17 2048 env58991 = env58992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env58991 == env58992) = true)

theorem identity58992 : scanCanonicalize (H12AffineFastState.compose env58992 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound58992 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58993 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,381,4176,113,294,4176,2048,1025,113,4096,341,64,82,300,16,2128,4177,4097,2128,1284,261,256,113,4177,513]

theorem envBound58993 : H12AffineFastState.Bounded env58993 := by
  intro p hp
  have h : env58993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58992_58993 : H12AffineEnvironment.transform 12 381 env58992 = env58993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env58992 == env58993) = true)

theorem identity58993 : scanCanonicalize (H12AffineFastState.compose env58993 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound58993 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env58994 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,576,381,528,113,294,528,2048,1025,113,576,341,64,82,300,16,2128,529,577,2128,1284,261,256,113,529,513]

theorem envBound58994 : H12AffineFastState.Bounded env58994 := by
  intro p hp
  have h : env58994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58993_58994 : H12AffineEnvironment.transform 11 576 env58993 = env58994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env58993 == env58994) = true)

theorem identity58994 : scanCanonicalize (H12AffineFastState.compose env58994 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound58994 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env58995 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,576,381,528,113,294,528,1802,1025,113,576,341,64,82,300,16,1882,529,577,1882,1284,261,256,113,529,513]

theorem envBound58995 : H12AffineFastState.Bounded env58995 := by
  intro p hp
  have h : env58995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58994_58995 : H12AffineEnvironment.transform 10 1802 env58994 = env58995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env58994 == env58995) = true)

theorem identity58995 : scanCanonicalize (H12AffineFastState.compose env58995 (packedSelected [2,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58995 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env58996 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1802,528,301,528,33,294,528,1802,1025,33,528,261,16,2,300,16,1802,529,529,1802,1284,261,256,33,529,513]

theorem envBound58996 : H12AffineFastState.Bounded env58996 := by
  intro p hp
  have h : env58996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58995_58996 : H12AffineEnvironment.transform 5 16 env58995 = env58996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58995 == env58996) = true)

theorem identity58996 : scanCanonicalize (H12AffineFastState.compose env58996 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 280) := by decide +kernel

theorem selectedBound58996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58997 : List Nat := [2,4,8,16,32,16,9,256,512,280,530,528,301,528,33,294,528,530,281,33,528,261,16,2,300,16,530,529,529,530,28,261,256,33,529,513]

theorem envBound58997 : H12AffineFastState.Bounded env58997 := by
  intro p hp
  have h : env58997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58996_58997 : H12AffineEnvironment.transform 9 280 env58996 = env58997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 280 env58996 == env58997) = true)

theorem identity58997 : scanCanonicalize (H12AffineFastState.compose env58997 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58997 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58998 : List Nat := [2,4,8,16,32,16,9,256,26,280,8,10,301,10,33,294,10,8,281,33,10,261,16,2,300,16,8,11,11,8,28,261,256,33,11,27]

theorem envBound58998 : H12AffineFastState.Bounded env58998 := by
  intro p hp
  have h : env58998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58997_58998 : H12AffineEnvironment.transform 8 26 env58997 = env58998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58997 == env58998) = true)

theorem identity58998 : scanCanonicalize (H12AffineFastState.compose env58998 (packedSelected [1,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58998 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env58999 : List Nat := [2,4,8,16,17,16,9,256,26,280,8,10,284,10,16,279,10,8,281,16,10,261,16,2,285,16,8,11,11,8,28,261,256,16,11,27]

theorem envBound58999 : H12AffineFastState.Bounded env58999 := by
  intro p hp
  have h : env58999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58998_58999 : H12AffineEnvironment.transform 4 17 env58998 = env58999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58998 == env58999) = true)

theorem identity58999 : scanCanonicalize (H12AffineFastState.compose env58999 (packedSelected [20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound58999 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env59000 : List Nat := [2,4,8,16,17,16,9,20,26,12,8,10,8,10,16,3,10,8,13,16,10,17,16,2,9,16,8,11,11,8,28,17,20,16,11,27]

theorem envBound59000 : H12AffineFastState.Bounded env59000 := by
  intro p hp
  have h : env59000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58999_59000 : H12AffineEnvironment.transform 7 20 env58999 = env59000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env58999 == env59000) = true)

def env59001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8388689,12980500,4176,131153,4294794,8463814,8462790,256,4292778,131073,33563273]

theorem envBound59001 : H12AffineFastState.Bounded env59001 := by
  intro p hp
  have h : env59001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58982_59001 : H12AffineEnvironment.transform 13 4177 env58982 = env59001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58982 == env59001) = true)

def env59002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304863,33554432,6329801,2524300,4176,131153,4294794,6402142,6403166,256,4292778,131073,33563273]

theorem envBound59002 : H12AffineFastState.Bounded env59002 := by
  intro p hp
  have h : env59002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59001_59002 : H12AffineEnvironment.transform 22 6329752 env59001 = env59002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env59001 == env59002) = true)

def env59003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304863,4227080,6329801,2524300,4176,131153,4294794,6402142,6403166,256,4292778,131073,4235905]

theorem envBound59003 : H12AffineFastState.Bounded env59003 := by
  intro p hp
  have h : env59003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59002_59003 : H12AffineEnvironment.transform 24 4227080 env59002 = env59003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env59002 == env59003) = true)

theorem identity59003 : scanCanonicalize (H12AffineFastState.compose env59003 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound59003 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env59004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,41088,2110744,2135263,8328,2110793,2524300,4176,131153,75786,2167006,2168030,256,73770,131073,513]

theorem envBound59004 : H12AffineFastState.Bounded env59004 := by
  intro p hp
  have h : env59004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59003_59004 : H12AffineEnvironment.transform 21 41088 env59003 = env59004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env59003 == env59004) = true)

theorem identity59004 : scanCanonicalize (H12AffineFastState.compose env59004 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111830) := by decide +kernel

theorem selectedBound59004 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,111830,41088,98766,73737,8328,98719,471130,4176,131153,75786,41992,40968,256,73770,131073,513]

theorem envBound59005 : H12AffineFastState.Bounded env59005 := by
  intro p hp
  have h : env59005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59004_59005 : H12AffineEnvironment.transform 20 111830 env59004 = env59005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111830 env59004 == env59005) = true)

theorem identity59005 : scanCanonicalize (H12AffineFastState.compose env59005 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13577) := by decide +kernel

theorem selectedBound59005 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13577,262144,1025,32768,111830,41088,98766,73737,8328,98719,329043,4176,13656,75786,41992,40968,256,73770,13576,513]

theorem envBound59006 : H12AffineFastState.Bounded env59006 := by
  intro p hp
  have h : env59006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59005_59006 : H12AffineEnvironment.transform 16 13577 env59005 = env59006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13577 env59005 == env59006) = true)

theorem identity59006 : scanCanonicalize (H12AffineFastState.compose env59006 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59006 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env59007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,1528,65536,13577,262144,1025,1528,78126,9592,66614,73737,8328,66663,329043,4176,13656,75786,8688,9712,256,73770,13576,513]

theorem envBound59007 : H12AffineFastState.Bounded env59007 := by
  intro p hp
  have h : env59007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59006_59007 : H12AffineEnvironment.transform 14 1528 env59006 = env59007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1528 env59006 == env59007) = true)

theorem identity59007 : scanCanonicalize (H12AffineFastState.compose env59007 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound59007 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env59008 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,8192,4177,625,65536,12928,262144,904,625,78126,8945,66495,73737,8328,66542,328410,4176,13009,75786,8688,8825,256,73770,12929,513]

theorem envBound59008 : H12AffineFastState.Bounded env59008 := by
  intro p hp
  have h : env59008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59007_59008 : H12AffineEnvironment.transform 9 905 env59007 = env59008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env59007 == env59008) = true)

theorem identity59008 : scanCanonicalize (H12AffineFastState.compose env59008 (packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound59008 : packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env59009 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,8192,4177,625,65536,12928,2340,904,625,78126,8945,66495,73737,8328,66542,68606,4176,13009,75786,8688,8825,256,73770,12929,513]

theorem envBound59009 : H12AffineFastState.Bounded env59009 := by
  intro p hp
  have h : env59009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59008_59009 : H12AffineEnvironment.transform 17 2340 env59008 = env59009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env59008 == env59009) = true)

theorem identity59009 : scanCanonicalize (H12AffineFastState.compose env59009 (packedSelected [0,3,4,5,7,9,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound59009 : packedSelected [0,3,4,5,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env59010 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,492,8192,445,625,65536,9068,2340,904,625,73922,8945,66495,73737,8328,66542,68606,444,9021,75786,8688,8825,256,73770,9069,513]

theorem envBound59010 : H12AffineFastState.Bounded env59010 := by
  intro p hp
  have h : env59010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59009_59010 : H12AffineEnvironment.transform 11 492 env59009 = env59010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env59009 == env59010) = true)

theorem identity59010 : scanCanonicalize (H12AffineFastState.compose env59010 (packedSelected [1,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 893) := by decide +kernel

theorem selectedBound59010 : packedSelected [1,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env59011 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,492,893,445,625,65536,17,2340,904,625,66495,396,66495,66420,1013,66542,68606,444,64,68471,653,260,256,66391,16,513]

theorem envBound59011 : H12AffineFastState.Bounded env59011 := by
  intro p hp
  have h : env59011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59010_59011 : H12AffineEnvironment.transform 12 893 env59010 = env59011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 893 env59010 == env59011) = true)

theorem identity59011 : scanCanonicalize (H12AffineFastState.compose env59011 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 595) := by decide +kernel

theorem selectedBound59011 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59012 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,492,893,445,625,595,17,2340,904,625,492,396,492,295,1013,445,2477,444,64,2340,653,260,256,260,16,513]

theorem envBound59012 : H12AffineFastState.Bounded env59012 := by
  intro p hp
  have h : env59012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59011_59012 : H12AffineEnvironment.transform 15 595 env59011 = env59012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 595 env59011 == env59012) = true)

theorem identity59012 : scanCanonicalize (H12AffineFastState.compose env59012 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound59012 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59013 : List Nat := [2,4,8,16,32,64,128,172,512,549,2048,64,721,17,625,595,17,2184,548,625,64,32,64,139,601,17,2049,16,64,2184,653,168,172,168,16,513]

theorem envBound59013 : H12AffineFastState.Bounded env59013 := by
  intro p hp
  have h : env59013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59012_59013 : H12AffineEnvironment.transform 7 172 env59012 = env59013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env59012 == env59013) = true)

theorem identity59013 : scanCanonicalize (H12AffineFastState.compose env59013 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound59013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59014 : List Nat := [2,4,8,16,32,64,128,172,48,21,2048,64,225,17,65,99,17,2184,20,65,64,32,64,139,105,17,2049,16,64,2184,189,168,172,168,16,49]

theorem envBound59014 : H12AffineFastState.Bounded env59014 := by
  intro p hp
  have h : env59014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59013_59014 : H12AffineEnvironment.transform 8 48 env59013 = env59014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env59013 == env59014) = true)

theorem identity59014 : scanCanonicalize (H12AffineFastState.compose env59014 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound59014 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59015 : List Nat := [2,4,8,16,32,64,128,172,48,21,64,64,225,17,65,99,17,200,20,65,64,32,64,139,105,17,65,16,64,200,189,168,172,168,16,49]

theorem envBound59015 : H12AffineFastState.Bounded env59015 := by
  intro p hp
  have h : env59015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59014_59015 : H12AffineEnvironment.transform 10 64 env59014 = env59015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env59014 == env59015) = true)

theorem identity59015 : scanCanonicalize (H12AffineFastState.compose env59015 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound59015 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59016 : List Nat := [2,4,8,16,32,27,128,172,48,21,27,27,186,17,26,56,17,147,20,26,27,32,27,139,50,17,26,16,27,147,189,168,172,168,16,49]

theorem envBound59016 : H12AffineFastState.Bounded env59016 := by
  intro p hp
  have h : env59016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59015_59016 : H12AffineEnvironment.transform 5 27 env59015 = env59016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env59015 == env59016) = true)

theorem identity59016 : scanCanonicalize (H12AffineFastState.compose env59016 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound59016 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59017 : List Nat := [2,4,8,16,32,27,3,47,48,21,27,27,57,17,26,56,17,16,20,26,27,32,27,8,50,17,26,16,27,16,62,43,47,43,16,49]

theorem envBound59017 : H12AffineFastState.Bounded env59017 := by
  intro p hp
  have h : env59017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59016_59017 : H12AffineEnvironment.transform 6 3 env59016 = env59017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env59016 == env59017) = true)

theorem identity59017 : scanCanonicalize (H12AffineFastState.compose env59017 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59017 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59018 : List Nat := [2,4,8,16,17,27,3,30,1,21,27,27,8,17,26,9,17,16,20,26,27,17,27,8,3,17,26,16,27,16,15,26,30,26,16,0]

theorem envBound59018 : H12AffineFastState.Bounded env59018 := by
  intro p hp
  have h : env59018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59017_59018 : H12AffineEnvironment.transform 4 17 env59017 = env59018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59017 == env59018) = true)

theorem identity59018 : scanCanonicalize (H12AffineFastState.compose env59018 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59019 : List Nat := [0,4,8,16,17,25,1,28,1,21,25,25,8,17,24,9,17,16,20,24,25,17,25,8,1,17,24,16,25,16,13,24,28,24,16,0]

theorem envBound59019 : H12AffineFastState.Bounded env59019 := by
  intro p hp
  have h : env59019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59018_59019 : H12AffineEnvironment.transform 0 0 env59018 = env59019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59018 == env59019) = true)

theorem identity59019 : scanCanonicalize (H12AffineFastState.compose env59019 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59019 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59020 : List Nat := [0,4,1,16,17,16,1,21,1,21,16,16,1,17,17,0,17,16,20,17,16,17,16,1,1,17,17,16,16,16,4,17,21,17,16,0]

theorem envBound59020 : H12AffineFastState.Bounded env59020 := by
  intro p hp
  have h : env59020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59019_59020 : H12AffineEnvironment.transform 2 1 env59019 = env59020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59019 == env59020) = true)

def env59021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304863,4227081,6329801,2524300,4176,131153,4294794,6402142,6403166,256,4292778,131073,4235904]

theorem envBound59021 : H12AffineFastState.Bounded env59021 := by
  intro p hp
  have h : env59021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59002_59021 : H12AffineEnvironment.transform 24 4227081 env59002 = env59021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env59002 == env59021) = true)

def env59022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304862,33554432,6329800,2524301,4176,131153,4294794,6402143,6403167,256,4292778,131073,33563273]

theorem envBound59022 : H12AffineFastState.Bounded env59022 := by
  intro p hp
  have h : env59022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59001_59022 : H12AffineEnvironment.transform 22 6329753 env59001 = env59022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env59001 == env59022) = true)

def env59023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304862,4227080,6329800,2524301,4176,131153,4294794,6402143,6403167,256,4292778,131073,4235905]

theorem envBound59023 : H12AffineFastState.Bounded env59023 := by
  intro p hp
  have h : env59023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59022_59023 : H12AffineEnvironment.transform 24 4227080 env59022 = env59023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env59022 == env59023) = true)

theorem identity59023 : scanCanonicalize (H12AffineFastState.compose env59023 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound59023 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env59024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,41088,2110745,2135262,8328,2110792,2524301,4176,131153,75786,2167007,2168031,256,73770,131073,513]

theorem envBound59024 : H12AffineFastState.Bounded env59024 := by
  intro p hp
  have h : env59024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59023_59024 : H12AffineEnvironment.transform 21 41088 env59023 = env59024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env59023 == env59024) = true)

theorem identity59024 : scanCanonicalize (H12AffineFastState.compose env59024 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111831) := by decide +kernel

theorem selectedBound59024 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,111831,41088,98766,73737,8328,98719,471130,4176,131153,75786,41992,40968,256,73770,131073,513]

theorem envBound59025 : H12AffineFastState.Bounded env59025 := by
  intro p hp
  have h : env59025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59024_59025 : H12AffineEnvironment.transform 20 111831 env59024 = env59025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111831 env59024 == env59025) = true)

theorem identity59025 : scanCanonicalize (H12AffineFastState.compose env59025 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13576) := by decide +kernel

theorem selectedBound59025 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13576,262144,1025,32768,111831,41088,98766,73737,8328,98719,329042,4176,13657,75786,41992,40968,256,73770,13577,513]

theorem envBound59026 : H12AffineFastState.Bounded env59026 := by
  intro p hp
  have h : env59026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59025_59026 : H12AffineEnvironment.transform 16 13576 env59025 = env59026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13576 env59025 == env59026) = true)

theorem identity59026 : scanCanonicalize (H12AffineFastState.compose env59026 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound59026 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env59027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,32803,13576,262144,1025,32768,13556,41088,493,41002,8328,444,296305,4176,13657,43049,41992,40968,256,40969,13577,513]

theorem envBound59027 : H12AffineFastState.Bounded env59027 := by
  intro p hp
  have h : env59027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59026_59027 : H12AffineEnvironment.transform 15 32803 env59026 = env59027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env59026 == env59027) = true)

theorem identity59027 : scanCanonicalize (H12AffineFastState.compose env59027 (packedSelected [0,1,4,5,6,7,8,9,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound59027 : packedSelected [0,1,4,5,6,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env59028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,8495,13576,262144,1025,8460,13556,396,493,294,8328,444,271485,4176,13657,2341,1284,260,256,261,13577,513]

theorem envBound59028 : H12AffineFastState.Bounded env59028 := by
  intro p hp
  have h : env59028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59027_59028 : H12AffineEnvironment.transform 14 8460 env59027 = env59028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env59027 == env59028) = true)

theorem identity59028 : scanCanonicalize (H12AffineFastState.compose env59028 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound59028 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env59029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,8495,13576,8001,1025,8460,13556,396,493,294,8328,444,15164,4176,13657,2341,1284,260,256,261,13577,513]

theorem envBound59029 : H12AffineFastState.Bounded env59029 := by
  intro p hp
  have h : env59029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59028_59029 : H12AffineEnvironment.transform 17 8001 env59028 = env59029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env59028 == env59029) = true)

theorem identity59029 : scanCanonicalize (H12AffineFastState.compose env59029 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound59029 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env59030 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,8192,4177,8460,8495,12929,6344,904,8460,13181,396,493,294,8328,444,15164,4176,13008,2341,653,260,256,261,12928,513]

theorem envBound59030 : H12AffineFastState.Bounded env59030 := by
  intro p hp
  have h : env59030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59029_59030 : H12AffineEnvironment.transform 9 905 env59029 = env59030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env59029 == env59030) = true)

theorem identity59030 : scanCanonicalize (H12AffineFastState.compose env59030 (packedSelected [6,25] rootPS)) = affineNative (2^(12+1) ^^^ 892) := by decide +kernel

theorem selectedBound59030 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env59031 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,892,4177,624,595,4605,6344,904,624,4097,396,493,294,1012,444,6208,4176,4524,2341,653,260,256,261,4604,513]

theorem envBound59031 : H12AffineFastState.Bounded env59031 := by
  intro p hp
  have h : env59031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59030_59031 : H12AffineEnvironment.transform 12 892 env59030 = env59031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 892 env59030 == env59031) = true)

theorem identity59031 : scanCanonicalize (H12AffineFastState.compose env59031 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound59031 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59032 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,492,892,445,624,595,17,2340,904,624,493,396,493,294,1012,444,2476,444,64,2341,653,260,256,261,16,513]

theorem envBound59032 : H12AffineFastState.Bounded env59032 := by
  intro p hp
  have h : env59032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59031_59032 : H12AffineEnvironment.transform 11 492 env59031 = env59032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env59031 == env59032) = true)

theorem identity59032 : scanCanonicalize (H12AffineFastState.compose env59032 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound59032 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59033 : List Nat := [2,4,8,16,32,64,128,256,216,337,2048,492,420,445,168,139,17,2340,336,168,493,396,493,294,300,444,2476,444,64,2341,85,260,256,261,16,217]

theorem envBound59033 : H12AffineFastState.Bounded env59033 := by
  intro p hp
  have h : env59033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59032_59033 : H12AffineEnvironment.transform 8 216 env59032 = env59033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env59032 == env59033) = true)

theorem identity59033 : scanCanonicalize (H12AffineFastState.compose env59033 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound59033 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env59034 : List Nat := [2,4,8,16,32,27,128,256,131,266,2048,439,420,445,168,139,17,2340,267,168,438,396,438,294,300,444,2476,444,27,2341,14,260,256,261,16,130]

theorem envBound59034 : H12AffineFastState.Bounded env59034 := by
  intro p hp
  have h : env59034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59033_59034 : H12AffineEnvironment.transform 5 27 env59033 = env59034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env59033 == env59034) = true)

def env59035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304862,4227081,6329800,2524301,4176,131153,4294794,6402143,6403167,256,4292778,131073,4235904]

theorem envBound59035 : H12AffineFastState.Bounded env59035 := by
  intro p hp
  have h : env59035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59022_59035 : H12AffineEnvironment.transform 24 4227081 env59022 = env59035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env59022 == env59035) = true)

def env59036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,8409089,134217728,16385,656465,4840667,8463814,4294967296,525569,4307611964,34359738368,33563273]

theorem envBound59036 : H12AffineFastState.Bounded env59036 := by
  intro p hp
  have h : env59036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58770_59036 : H12AffineEnvironment.transform 25 8409089 env58770 = env59036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409089 env58770 == env59036) = true)

def env59037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131153,4315355,8463814,4294967296,257,4307611964,34359738368,33563273]

theorem envBound59037 : H12AffineFastState.Bounded env59037 := by
  intro p hp
  have h : env59037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59036_59037 : H12AffineEnvironment.transform 18 1024 env59036 = env59037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env59036 == env59037) = true)

def env59038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131153,4315355,8463814,4294967296,257,4307611964,131072,33563273]

theorem envBound59038 : H12AffineFastState.Bounded env59038 := by
  intro p hp
  have h : env59038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59037_59038 : H12AffineEnvironment.transform 34 131072 env59037 = env59038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env59037 == env59038) = true)

theorem identity59038 : scanCanonicalize (H12AffineFastState.compose env59038 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 140846483) := by decide +kernel

theorem selectedBound59038 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env59039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131153,4315355,8463814,140846483,257,145085615,131072,33563273]

theorem envBound59039 : H12AffineFastState.Bounded env59039 := by
  intro p hp
  have h : env59039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59038_59039 : H12AffineEnvironment.transform 31 140846483 env59038 = env59039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 140846483 env59038 == env59039) = true)

theorem identity59039 : scanCanonicalize (H12AffineFastState.compose env59039 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound59039 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env59040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8388689,134217728,4177,131153,4294795,8463814,140846483,257,145065215,131072,33563273]

theorem envBound59040 : H12AffineFastState.Bounded env59040 := by
  intro p hp
  have h : env59040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59039_59040 : H12AffineEnvironment.transform 13 4176 env59039 = env59040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env59039 == env59040) = true)

theorem identity59040 : scanCanonicalize (H12AffineFastState.compose env59040 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound59040 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env59041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388689,134217728,4177,131153,4294795,8463814,140846483,257,145065215,131072,513]

theorem envBound59041 : H12AffineFastState.Bounded env59041 := by
  intro p hp
  have h : env59041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59040_59041 : H12AffineEnvironment.transform 24 8328 env59040 = env59041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env59040 == env59041) = true)

theorem identity59041 : scanCanonicalize (H12AffineFastState.compose env59041 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound59041 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388689,8724554,4177,131153,4294795,8463814,14681561,257,2139317,131072,513]

theorem envBound59042 : H12AffineFastState.Bounded env59042 := by
  intro p hp
  have h : env59042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59041_59042 : H12AffineEnvironment.transform 26 8724554 env59041 = env59042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env59041 == env59042) = true)

theorem identity59042 : scanCanonicalize (H12AffineFastState.compose env59042 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound59042 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,4194304,8388608,8430022,8328,8388689,8724554,4177,131153,4294795,8463814,12588505,257,46261,131072,513]

theorem envBound59043 : H12AffineFastState.Bounded env59043 := by
  intro p hp
  have h : env59043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59042_59043 : H12AffineEnvironment.transform 20 4096 env59042 = env59043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env59042 == env59043) = true)

theorem identity59043 : scanCanonicalize (H12AffineFastState.compose env59043 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370577) := by decide +kernel

theorem selectedBound59043 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env59044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,4194304,4370577,4329815,8328,4370624,4690139,4177,131153,4294795,4429143,173384,257,46261,131072,513]

theorem envBound59044 : H12AffineFastState.Bounded env59044 := by
  intro p hp
  have h : env59044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59043_59044 : H12AffineEnvironment.transform 22 4370577 env59043 = env59044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370577 env59043 == env59044) = true)

theorem identity59044 : scanCanonicalize (H12AffineFastState.compose env59044 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound59044 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env59045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,396,176413,135387,8328,176460,495959,4177,131153,100615,234715,173384,257,46261,131072,513]

theorem envBound59045 : H12AffineFastState.Bounded env59045 := by
  intro p hp
  have h : env59045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59044_59045 : H12AffineEnvironment.transform 21 396 env59044 = env59045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env59044 == env59045) = true)

theorem identity59045 : scanCanonicalize (H12AffineFastState.compose env59045 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound59045 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env59046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,131072,262144,1024,8461,4096,396,135184,135387,8328,135233,471130,4177,131153,75786,210390,132165,257,5560,131072,513]

theorem envBound59046 : H12AffineFastState.Bounded env59046 := by
  intro p hp
  have h : env59046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59045_59046 : H12AffineEnvironment.transform 14 8461 env59045 = env59046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env59045 == env59046) = true)

theorem identity59046 : scanCanonicalize (H12AffineFastState.compose env59046 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13423) := by decide +kernel

theorem selectedBound59046 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env59047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,13423,131072,262144,1024,8461,4096,396,135184,135387,8328,135233,394293,4177,131153,7269,131513,132165,257,5560,131072,513]

theorem envBound59047 : H12AffineFastState.Bounded env59047 := by
  intro p hp
  have h : env59047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59046_59047 : H12AffineEnvironment.transform 15 13423 env59046 = env59047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13423 env59046 == env59047) = true)

theorem identity59047 : scanCanonicalize (H12AffineFastState.compose env59047 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 7268) := by decide +kernel

theorem selectedBound59047 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env59048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,13423,131072,7268,1024,8461,4096,396,135184,135387,8328,135233,137297,4177,131153,7269,131513,132165,257,5560,131072,513]

theorem envBound59048 : H12AffineFastState.Bounded env59048 := by
  intro p hp
  have h : env59048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59047_59048 : H12AffineEnvironment.transform 17 7268 env59047 = env59048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7268 env59047 == env59048) = true)

theorem identity59048 : scanCanonicalize (H12AffineFastState.compose env59048 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59048 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59049 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4176,8352,13423,131072,7268,1024,8352,4096,33,135184,135387,8328,135233,137297,4177,131153,7269,131092,132165,172,5141,131072,513]

theorem envBound59049 : H12AffineFastState.Bounded env59049 := by
  intro p hp
  have h : env59049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59048_59049 : H12AffineEnvironment.transform 7 173 env59048 = env59049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59048 == env59049) = true)

theorem identity59049 : scanCanonicalize (H12AffineFastState.compose env59049 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 4177) := by decide +kernel

theorem selectedBound59049 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env59050 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4176,8352,13423,4177,7268,1024,8352,4096,33,65,138,8328,16,2048,4177,4096,7269,4165,5140,172,5141,4177,513]

theorem envBound59050 : H12AffineFastState.Bounded env59050 := by
  intro p hp
  have h : env59050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59049_59050 : H12AffineEnvironment.transform 16 4177 env59049 = env59050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4177 env59049 == env59050) = true)

theorem identity59050 : scanCanonicalize (H12AffineFastState.compose env59050 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59050 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59051 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,8352,13374,4096,7221,1024,8352,4096,33,16,138,8328,16,2048,4096,4096,7220,4116,5140,172,5141,4096,513]

theorem envBound59051 : H12AffineFastState.Bounded env59051 := by
  intro p hp
  have h : env59051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59050_59051 : H12AffineEnvironment.transform 5 17 env59050 = env59051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59050 == env59051) = true)

theorem identity59051 : scanCanonicalize (H12AffineFastState.compose env59051 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound59051 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59052 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8,4097,168,5174,4096,7221,1024,168,4096,33,16,138,128,16,2048,4096,4096,7220,4116,5140,172,5141,4096,513]

theorem envBound59052 : H12AffineFastState.Bounded env59052 := by
  intro p hp
  have h : env59052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59051_59052 : H12AffineEnvironment.transform 12 8 env59051 = env59052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env59051 == env59052) = true)

theorem identity59052 : scanCanonicalize (H12AffineFastState.compose env59052 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound59052 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env59053 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2075,8,2074,168,3117,2075,1070,1024,168,2075,33,16,138,128,16,2048,2075,2075,1071,2063,3087,172,3086,2075,513]

theorem envBound59053 : H12AffineFastState.Bounded env59053 := by
  intro p hp
  have h : env59053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59052_59053 : H12AffineEnvironment.transform 11 2075 env59052 = env59053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env59052 == env59053) = true)

theorem identity59053 : scanCanonicalize (H12AffineFastState.compose env59053 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59053 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env59054 : List Nat := [2,4,8,10,32,11,128,173,512,1024,2048,2049,8,2048,168,3117,2049,1070,1024,168,2049,33,10,138,128,10,2048,2049,2049,1071,2063,3087,172,3086,2049,513]

theorem envBound59054 : H12AffineFastState.Bounded env59054 := by
  intro p hp
  have h : env59054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59053_59054 : H12AffineEnvironment.transform 3 10 env59053 = env59054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59053 == env59054) = true)

theorem identity59054 : scanCanonicalize (H12AffineFastState.compose env59054 (packedSelected [1,2,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound59054 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env59055 : List Nat := [2,4,8,10,32,11,128,173,512,549,2048,2049,8,2048,168,2568,2049,523,549,168,2049,33,10,138,128,10,2048,2049,2049,522,2063,2602,172,2603,2049,513]

theorem envBound59055 : H12AffineFastState.Bounded env59055 := by
  intro p hp
  have h : env59055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59054_59055 : H12AffineEnvironment.transform 9 549 env59054 = env59055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env59054 == env59055) = true)

theorem identity59055 : scanCanonicalize (H12AffineFastState.compose env59055 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound59055 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env59056 : List Nat := [2,4,8,10,32,11,128,173,512,549,130,131,8,130,168,650,131,523,549,168,131,33,10,138,128,10,130,131,131,522,141,680,172,681,131,513]

theorem envBound59056 : H12AffineFastState.Bounded env59056 := by
  intro p hp
  have h : env59056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59055_59056 : H12AffineEnvironment.transform 10 130 env59055 = env59056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env59055 == env59056) = true)

def env59057 : List Nat := [2,4,8,10,32,11,128,173,0,37,130,131,8,130,168,138,131,11,37,168,131,33,10,138,128,10,130,131,131,10,141,168,172,169,131,1]

theorem envBound59057 : H12AffineFastState.Bounded env59057 := by
  intro p hp
  have h : env59057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59056_59057 : H12AffineEnvironment.transform 8 0 env59056 = env59057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59056 == env59057) = true)

theorem identity59057 : scanCanonicalize (H12AffineFastState.compose env59057 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59057 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59058 : List Nat := [2,4,8,10,11,11,128,134,0,14,130,131,8,130,131,138,131,11,14,131,131,10,10,138,128,10,130,131,131,10,141,131,135,130,131,1]

theorem envBound59058 : H12AffineFastState.Bounded env59058 := by
  intro p hp
  have h : env59058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59057_59058 : H12AffineEnvironment.transform 4 11 env59057 = env59058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59057 == env59058) = true)

theorem identity59058 : scanCanonicalize (H12AffineFastState.compose env59058 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59059 : List Nat := [2,4,8,10,11,11,0,6,0,14,2,3,8,2,3,10,3,11,14,3,3,10,10,10,0,10,2,3,3,10,13,3,7,2,3,1]

theorem envBound59059 : H12AffineFastState.Bounded env59059 := by
  intro p hp
  have h : env59059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59058_59059 : H12AffineEnvironment.transform 6 0 env59058 = env59059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59058 == env59059) = true)

def leafEnv59059 : List Nat := [2,4,8,10,11,11,0,6,0,14,2,3,8,2,3,10,3,11,14,3,3,10,10,10,12,0,1,10,2,3,3,10,13,3,7,2,4,2,3,1,1,3,0]

def active59059 : List Nat := [0,1,2]

def tree59059 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood59059 : H12WitnessSearch.Good tree59059 := H12GlobalWitnessIndex.good

theorem leafIdentity59059 : H12AffineFastState.composeSystem env59059 rootObs = leafEnv59059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env59059 rootObs == leafEnv59059) = true)

theorem terminalChecked59059 : H12PackedTerminal.terminalCheckFast leafEnv59059 active59059 tree59059 = true := by decide +kernel

def env59060 : List Nat := [2,4,8,10,32,11,128,173,1,36,130,131,8,130,168,139,131,10,36,168,131,33,10,138,128,10,130,131,131,11,141,169,172,168,131,0]

theorem envBound59060 : H12AffineFastState.Bounded env59060 := by
  intro p hp
  have h : env59060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59056_59060 : H12AffineEnvironment.transform 8 1 env59056 = env59060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59056 == env59060) = true)

def env59061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131153,4315355,8463814,4294967296,257,4307611964,131073,33563273]

theorem envBound59061 : H12AffineFastState.Bounded env59061 := by
  intro p hp
  have h : env59061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59037_59061 : H12AffineEnvironment.transform 34 131073 env59037 = env59061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env59037 == env59061) = true)

theorem identity59061 : scanCanonicalize (H12AffineFastState.compose env59061 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 138753426) := by decide +kernel

theorem selectedBound59061 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env59062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131153,4315355,8463814,138753426,257,142984366,131073,33563273]

theorem envBound59062 : H12AffineFastState.Bounded env59062 := by
  intro p hp
  have h : env59062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59061_59062 : H12AffineEnvironment.transform 31 138753426 env59061 = env59062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 138753426 env59061 == env59062) = true)

theorem identity59062 : scanCanonicalize (H12AffineFastState.compose env59062 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound59062 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env59063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,12919238,16385,131153,4315355,8463814,8393812,257,4253032,131073,33563273]

theorem envBound59063 : H12AffineFastState.Bounded env59063 := by
  intro p hp
  have h : env59063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59062_59063 : H12AffineEnvironment.transform 26 12919238 env59062 = env59063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env59062 == env59063) = true)

theorem identity59063 : scanCanonicalize (H12AffineFastState.compose env59063 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28888) := by decide +kernel

theorem selectedBound59063 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env59064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,28888,8409089,12919238,16385,131153,4315355,8463814,8393812,257,4253032,131073,21073]

theorem envBound59064 : H12AffineFastState.Bounded env59064 := by
  intro p hp
  have h : env59064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59063_59064 : H12AffineEnvironment.transform 24 28888 env59063 = env59064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28888 env59063 == env59064) = true)

def env59065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388689,12919238,4177,131153,4294795,8463814,8393812,257,4240696,131073,513]

theorem envBound59065 : H12AffineFastState.Bounded env59065 := by
  intro p hp
  have h : env59065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59064_59065 : H12AffineEnvironment.transform 13 4176 env59064 = env59065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env59064 == env59065) = true)

theorem identity59065 : scanCanonicalize (H12AffineFastState.compose env59065 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound59065 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,396,8388608,8430022,8328,8388689,8724554,4177,131153,100615,8463814,8393812,257,46260,131073,513]

theorem envBound59066 : H12AffineFastState.Bounded env59066 := by
  intro p hp
  have h : env59066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59065_59066 : H12AffineEnvironment.transform 21 396 env59065 = env59066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env59065 == env59066) = true)

theorem identity59066 : scanCanonicalize (H12AffineFastState.compose env59066 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound59066 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,396,8388608,8430022,8328,8388689,8724554,4177,131153,100615,8463814,8393812,257,46260,131073,513]

theorem envBound59067 : H12AffineFastState.Bounded env59067 := by
  intro p hp
  have h : env59067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59066_59067 : H12AffineEnvironment.transform 20 4096 env59066 = env59067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env59066 == env59067) = true)

theorem identity59067 : scanCanonicalize (H12AffineFastState.compose env59067 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176413) := by decide +kernel

theorem selectedBound59067 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,396,176413,135387,8328,176460,495959,4177,131153,100615,234715,173385,257,46260,131073,513]

theorem envBound59068 : H12AffineFastState.Bounded env59068 := by
  intro p hp
  have h : env59068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59067_59068 : H12AffineEnvironment.transform 22 176413 env59067 = env59068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176413 env59067 == env59068) = true)

theorem identity59068 : scanCanonicalize (H12AffineFastState.compose env59068 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound59068 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env59069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,131072,262144,1024,8460,4096,396,135185,135387,8328,135232,471131,4177,131153,75787,210391,132165,257,5560,131073,513]

theorem envBound59069 : H12AffineFastState.Bounded env59069 := by
  intro p hp
  have h : env59069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59068_59069 : H12AffineEnvironment.transform 14 8460 env59068 = env59069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env59068 == env59069) = true)

theorem identity59069 : scanCanonicalize (H12AffineFastState.compose env59069 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13422) := by decide +kernel

theorem selectedBound59069 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env59070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,13422,131072,262144,1024,8460,4096,396,135185,135387,8328,135232,394293,4177,131153,7269,131513,132165,257,5560,131073,513]

theorem envBound59070 : H12AffineFastState.Bounded env59070 := by
  intro p hp
  have h : env59070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59069_59070 : H12AffineEnvironment.transform 15 13422 env59069 = env59070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13422 env59069 == env59070) = true)

theorem identity59070 : scanCanonicalize (H12AffineFastState.compose env59070 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 134196) := by decide +kernel

theorem selectedBound59070 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env59071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,13422,131072,134196,1024,8460,4096,396,135185,135387,8328,135232,2049,4177,131153,7269,131513,132165,257,5560,131073,513]

theorem envBound59071 : H12AffineFastState.Bounded env59071 := by
  intro p hp
  have h : env59071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59070_59071 : H12AffineEnvironment.transform 17 134196 env59070 = env59071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 134196 env59070 == env59071) = true)

theorem identity59071 : scanCanonicalize (H12AffineFastState.compose env59071 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59071 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59072 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4176,8353,13422,131072,134196,1024,8353,4096,33,135185,135387,8328,135232,2049,4177,131153,7269,131092,132165,172,5141,131073,513]

theorem envBound59072 : H12AffineFastState.Bounded env59072 := by
  intro p hp
  have h : env59072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59071_59072 : H12AffineEnvironment.transform 7 173 env59071 = env59072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59071 == env59072) = true)

theorem identity59072 : scanCanonicalize (H12AffineFastState.compose env59072 (packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2267) := by decide +kernel

theorem selectedBound59072 : packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env59073 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,2267,4176,2170,7349,131072,134196,1024,2170,4096,33,135185,135387,2131,135232,2049,4177,131153,7269,131092,132165,172,5141,131073,513]

theorem envBound59073 : H12AffineFastState.Bounded env59073 := by
  intro p hp
  have h : env59073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59072_59073 : H12AffineEnvironment.transform 12 2267 env59072 = env59073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2267 env59072 == env59073) = true)

theorem identity59073 : scanCanonicalize (H12AffineFastState.compose env59073 (packedSelected [0,2,3,7,8,10,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound59073 : packedSelected [0,2,3,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env59074 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,2267,4176,2170,7349,4096,7220,1024,2170,4096,33,17,219,2131,64,2049,4177,4177,7269,4116,5189,172,5141,4097,513]

theorem envBound59074 : H12AffineFastState.Bounded env59074 := by
  intro p hp
  have h : env59074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59073_59074 : H12AffineEnvironment.transform 16 4096 env59073 = env59074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env59073 == env59074) = true)

theorem identity59074 : scanCanonicalize (H12AffineFastState.compose env59074 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound59074 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59075 : List Nat := [2,4,8,16,32,64,128,173,512,1024,130,4096,89,4176,248,5175,4096,5302,1024,248,4096,33,17,219,209,64,131,4177,4177,5351,4116,5189,172,5141,4097,513]

theorem envBound59075 : H12AffineFastState.Bounded env59075 := by
  intro p hp
  have h : env59075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59074_59075 : H12AffineEnvironment.transform 10 130 env59074 = env59075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env59074 == env59075) = true)

theorem identity59075 : scanCanonicalize (H12AffineFastState.compose env59075 (packedSelected [0,1,2,3,4,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 183) := by decide +kernel

theorem selectedBound59075 : packedSelected [0,1,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env59076 : List Nat := [2,4,8,16,32,64,128,173,512,183,130,4096,89,4176,248,4224,4096,4097,183,248,4096,33,17,219,209,64,131,4177,4177,4176,4116,4338,172,4258,4097,513]

theorem envBound59076 : H12AffineFastState.Bounded env59076 := by
  intro p hp
  have h : env59076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59075_59076 : H12AffineEnvironment.transform 9 183 env59075 = env59076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 183 env59075 == env59076) = true)

theorem identity59076 : scanCanonicalize (H12AffineFastState.compose env59076 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound59076 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env59077 : List Nat := [2,4,8,16,32,64,128,173,147,183,130,4096,89,4176,248,4224,4096,4097,183,248,4096,33,17,219,209,64,131,4177,4177,4176,4116,4338,172,4258,4097,146]

theorem envBound59077 : H12AffineFastState.Bounded env59077 := by
  intro p hp
  have h : env59077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59076_59077 : H12AffineEnvironment.transform 8 147 env59076 = env59077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env59076 == env59077) = true)

theorem identity59077 : scanCanonicalize (H12AffineFastState.compose env59077 (packedSelected [5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 91) := by decide +kernel

theorem selectedBound59077 : packedSelected [5,8,11] rootPS < 2^1333 := by decide +kernel

def env59078 : List Nat := [2,4,8,16,32,64,128,173,147,183,130,91,89,11,248,219,91,90,183,248,91,33,17,219,209,64,131,10,10,11,79,169,172,249,90,146]

theorem envBound59078 : H12AffineFastState.Bounded env59078 := by
  intro p hp
  have h : env59078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59077_59078 : H12AffineEnvironment.transform 11 91 env59077 = env59078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 91 env59077 == env59078) = true)

theorem identity59078 : scanCanonicalize (H12AffineFastState.compose env59078 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound59078 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env59079 : List Nat := [2,4,8,16,32,64,66,111,81,117,64,91,89,11,58,25,91,90,117,58,91,33,17,25,19,64,65,10,10,11,79,107,110,59,90,80]

theorem envBound59079 : H12AffineFastState.Bounded env59079 := by
  intro p hp
  have h : env59079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59078_59079 : H12AffineEnvironment.transform 6 66 env59078 = env59079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env59078 == env59079) = true)

theorem identity59079 : scanCanonicalize (H12AffineFastState.compose env59079 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59079 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env59080 : List Nat := [2,4,8,16,17,64,66,94,81,68,64,91,89,11,11,25,91,90,68,11,91,16,17,25,19,64,65,10,10,11,79,90,95,10,90,80]

theorem envBound59080 : H12AffineFastState.Bounded env59080 := by
  intro p hp
  have h : env59080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59079_59080 : H12AffineEnvironment.transform 4 17 env59079 = env59080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59079 == env59080) = true)

theorem identity59080 : scanCanonicalize (H12AffineFastState.compose env59080 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound59080 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59081 : List Nat := [2,4,8,16,17,2,0,28,19,6,2,25,27,11,11,25,25,24,6,11,25,16,17,25,19,2,3,10,10,11,13,24,29,10,24,18]

theorem envBound59081 : H12AffineFastState.Bounded env59081 := by
  intro p hp
  have h : env59081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59080_59081 : H12AffineEnvironment.transform 5 2 env59080 = env59081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env59080 == env59081) = true)

theorem identity59081 : scanCanonicalize (H12AffineFastState.compose env59081 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59081 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env59082 : List Nat := [2,4,8,3,2,2,0,15,0,6,2,10,8,11,11,10,10,11,6,11,10,3,2,10,0,2,3,10,10,11,13,11,14,10,11,1]

theorem envBound59082 : H12AffineFastState.Bounded env59082 := by
  intro p hp
  have h : env59082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59081_59082 : H12AffineEnvironment.transform 3 3 env59081 = env59082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59081 == env59082) = true)

def leafEnv59082 : List Nat := [2,4,8,3,2,2,0,15,0,6,2,10,8,11,11,10,10,11,6,11,10,3,2,10,12,0,1,2,3,10,10,11,13,11,14,10,4,2,11,1,1,11,0]

def active59082 : List Nat := [0,1,2]

def tree59082 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood59082 : H12WitnessSearch.Good tree59082 := H12GlobalWitnessIndex.good

theorem leafIdentity59082 : H12AffineFastState.composeSystem env59082 rootObs = leafEnv59082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env59082 rootObs == leafEnv59082) = true)

theorem terminalChecked59082 : H12PackedTerminal.terminalCheckFast leafEnv59082 active59082 tree59082 = true := by decide +kernel

def env59083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8329,8388688,12919238,4176,131153,4294794,8463814,8393812,257,4240697,131073,512]

theorem envBound59083 : H12AffineFastState.Bounded env59083 := by
  intro p hp
  have h : env59083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59064_59083 : H12AffineEnvironment.transform 13 4177 env59064 = env59083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env59064 == env59083) = true)

theorem identity59083 : scanCanonicalize (H12AffineFastState.compose env59083 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound59083 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,8329,8388688,12919238,4176,77955,4294794,8463814,8393812,257,4240697,78035,512]

theorem envBound59084 : H12AffineFastState.Bounded env59084 := by
  intro p hp
  have h : env59084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59083_59084 : H12AffineEnvironment.transform 16 78034 env59083 = env59084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env59083 == env59084) = true)

theorem identity59084 : scanCanonicalize (H12AffineFastState.compose env59084 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 103746) := by decide +kernel

theorem selectedBound59084 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1024,32768,2097152,103746,8388608,8430022,8329,8388688,8696964,4176,77955,7624,8463814,8393812,257,73851,78035,512]

theorem envBound59085 : H12AffineFastState.Bounded env59085 := by
  intro p hp
  have h : env59085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59084_59085 : H12AffineEnvironment.transform 21 103746 env59084 = env59085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 103746 env59084 == env59085) = true)

theorem identity59085 : scanCanonicalize (H12AffineFastState.compose env59085 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 38243) := by decide +kernel

theorem selectedBound59085 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env59086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,262144,1024,32768,2097152,33,8388608,8430022,8329,8388688,8696964,4176,42464,7624,8433829,8393812,257,46360,42416,512]

theorem envBound59086 : H12AffineFastState.Bounded env59086 := by
  intro p hp
  have h : env59086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59085_59086 : H12AffineEnvironment.transform 15 38243 env59085 = env59086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38243 env59085 == env59086) = true)

def env59087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,262144,1024,32768,2097152,33,64,41350,8329,16,308420,4176,42464,7624,45285,5140,257,46360,42416,512]

theorem envBound59087 : H12AffineFastState.Bounded env59087 := by
  intro p hp
  have h : env59087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59086_59087 : H12AffineEnvironment.transform 22 64 env59086 = env59087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env59086 == env59087) = true)

theorem identity59087 : scanCanonicalize (H12AffineFastState.compose env59087 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 48324) := by decide +kernel

theorem selectedBound59087 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,48324,1024,32768,2097152,33,64,41350,8329,16,2048,4176,42464,7624,45285,5140,257,46360,42416,512]

theorem envBound59088 : H12AffineFastState.Bounded env59088 := by
  intro p hp
  have h : env59088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59087_59088 : H12AffineEnvironment.transform 17 48324 env59087 = env59088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48324 env59087 == env59088) = true)

theorem identity59088 : scanCanonicalize (H12AffineFastState.compose env59088 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 1944) := by decide +kernel

theorem selectedBound59088 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,48324,1024,32768,1944,33,64,41350,8329,16,2048,4176,42464,7624,45285,5140,257,46360,42416,512]

theorem envBound59089 : H12AffineFastState.Bounded env59089 := by
  intro p hp
  have h : env59089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59088_59089 : H12AffineEnvironment.transform 20 1944 env59088 = env59089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1944 env59088 == env59089) = true)

theorem identity59089 : scanCanonicalize (H12AffineFastState.compose env59089 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound59089 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,13422,1212,7625,1024,8461,1944,33,64,139,8329,16,2048,4176,1261,7624,4584,5140,257,5141,1213,512]

theorem envBound59090 : H12AffineFastState.Bounded env59090 := by
  intro p hp
  have h : env59090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59089_59090 : H12AffineEnvironment.transform 14 8461 env59089 = env59090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env59089 == env59090) = true)

theorem identity59090 : scanCanonicalize (H12AffineFastState.compose env59090 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound59090 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env59091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,8192,2587,8461,11812,1212,1923,1024,8461,1944,33,64,139,8329,16,2048,2586,1261,1922,2978,3678,257,3679,1213,512]

theorem envBound59091 : H12AffineFastState.Bounded env59091 := by
  intro p hp
  have h : env59091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59090_59091 : H12AffineEnvironment.transform 11 2634 env59090 = env59091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env59090 == env59091) = true)

theorem identity59091 : scanCanonicalize (H12AffineFastState.compose env59091 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 1110) := by decide +kernel

theorem selectedBound59091 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env59092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,1110,2587,1371,2674,1212,1923,1024,1371,1944,33,64,139,1247,16,2048,2586,1261,1922,2978,3678,257,3679,1213,512]

theorem envBound59092 : H12AffineFastState.Bounded env59092 := by
  intro p hp
  have h : env59092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59091_59092 : H12AffineEnvironment.transform 12 1110 env59091 = env59092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1110 env59091 == env59092) = true)

theorem identity59092 : scanCanonicalize (H12AffineFastState.compose env59092 (packedSelected [0,1,2,5,7,15] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound59092 : packedSelected [0,1,2,5,7,15] rootPS < 2^1333 := by decide +kernel

def env59093 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,2414,1110,2367,1371,2390,1212,1191,1024,1371,1212,33,64,139,1247,16,2048,2366,1261,1190,2182,3450,257,3451,1213,292]

theorem envBound59093 : H12AffineFastState.Bounded env59093 := by
  intro p hp
  have h : env59093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59092_59093 : H12AffineEnvironment.transform 8 292 env59092 = env59093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env59092 == env59093) = true)

theorem identity59093 : scanCanonicalize (H12AffineFastState.compose env59093 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1410) := by decide +kernel

theorem selectedBound59093 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59094 : List Nat := [2,4,8,16,32,64,128,256,292,1024,1410,1260,1110,1213,1371,1236,1212,1191,1024,1371,1212,33,64,139,1247,16,1410,1212,1261,1190,1284,248,257,249,1213,292]

theorem envBound59094 : H12AffineFastState.Bounded env59094 := by
  intro p hp
  have h : env59094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59093_59094 : H12AffineEnvironment.transform 10 1410 env59093 = env59094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1410 env59093 == env59094) = true)

def env59095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,262144,1024,32768,2097152,33,65,41351,8329,17,308421,4176,42464,7624,45284,5141,257,46360,42416,512]

end H12CloudChart1