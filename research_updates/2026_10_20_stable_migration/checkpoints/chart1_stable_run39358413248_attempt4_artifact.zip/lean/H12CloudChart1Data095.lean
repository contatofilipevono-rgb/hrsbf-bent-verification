import H12CloudChart1Data094

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound24050 : packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS < 2^1333 := by decide +kernel

def env24051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5157,32768,171,5529,2340,1025,32769,2097152,261,2101248,2101558,41,17,34816,38161,4388,2136216,34189,397,257,2134292,2098228,33281]

theorem envBound24051 : H12AffineFastState.Bounded env24051 := by
  intro p hp
  have h : env24051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24050_24051 : H12AffineEnvironment.transform 13 5157 env24050 = env24051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env24050 == env24051) = true)

theorem identity24051 : scanCanonicalize (H12AffineFastState.compose env24051 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound24051 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env24052 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5157,137,171,5529,2340,1025,136,2097152,261,2101248,2101558,41,17,2185,5528,4388,2103313,1284,397,257,2101661,2098228,648]

theorem envBound24052 : H12AffineFastState.Bounded env24052 := by
  intro p hp
  have h : env24052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24051_24052 : H12AffineEnvironment.transform 14 137 env24051 = env24052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env24051 == env24052) = true)

theorem identity24052 : scanCanonicalize (H12AffineFastState.compose env24052 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 4540) := by decide +kernel

theorem selectedBound24052 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24053 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5157,137,171,5529,2340,1025,136,4540,261,444,138,41,17,2185,5528,4388,2477,1284,397,257,33,5512,648]

theorem envBound24053 : H12AffineFastState.Bounded env24053 := by
  intro p hp
  have h : env24053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24052_24053 : H12AffineEnvironment.transform 20 4540 env24052 = env24053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4540 env24052 == env24053) = true)

theorem identity24053 : scanCanonicalize (H12AffineFastState.compose env24053 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound24053 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24054 : List Nat := [2,4,8,16,32,17,128,256,512,1024,293,4096,161,5157,137,171,5529,1,1025,136,4540,261,444,138,41,17,428,5528,4388,136,1284,397,257,33,5512,648]

theorem envBound24054 : H12AffineFastState.Bounded env24054 := by
  intro p hp
  have h : env24054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24053_24054 : H12AffineEnvironment.transform 10 293 env24053 = env24054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env24053 == env24054) = true)

theorem identity24054 : scanCanonicalize (H12AffineFastState.compose env24054 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound24054 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env24055 : List Nat := [2,4,8,16,32,17,128,256,512,1024,293,153,161,1212,137,171,1280,1,1025,136,293,261,444,138,41,17,428,1281,445,136,1284,397,257,33,1297,648]

theorem envBound24055 : H12AffineFastState.Bounded env24055 := by
  intro p hp
  have h : env24055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24054_24055 : H12AffineEnvironment.transform 11 153 env24054 = env24055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env24054 == env24055) = true)

theorem identity24055 : scanCanonicalize (H12AffineFastState.compose env24055 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24055 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env24056 : List Nat := [2,4,8,16,32,17,128,36,512,1024,1,153,161,1212,137,171,1060,1,1025,136,1,33,152,138,41,17,136,1061,153,136,1056,169,37,33,1077,648]

theorem envBound24056 : H12AffineFastState.Bounded env24056 := by
  intro p hp
  have h : env24056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24055_24056 : H12AffineEnvironment.transform 7 36 env24055 = env24056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24055 == env24056) = true)

theorem identity24056 : scanCanonicalize (H12AffineFastState.compose env24056 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24056 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env24057 : List Nat := [2,4,8,16,1,17,128,5,512,1024,1,153,128,1181,137,138,1029,1,1025,136,1,0,152,138,8,17,136,1028,153,136,1025,136,4,0,1044,648]

theorem envBound24057 : H12AffineFastState.Bounded env24057 := by
  intro p hp
  have h : env24057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24056_24057 : H12AffineEnvironment.transform 4 1 env24056 = env24057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24056 == env24057) = true)

theorem identity24057 : scanCanonicalize (H12AffineFastState.compose env24057 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 157) := by decide +kernel

theorem selectedBound24057 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24058 : List Nat := [2,4,8,16,1,17,128,5,157,1024,1,153,128,1181,137,138,1029,1,1025,136,1,0,152,138,8,17,136,1028,153,136,1025,136,4,0,1044,21]

theorem envBound24058 : H12AffineFastState.Bounded env24058 := by
  intro p hp
  have h : env24058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24057_24058 : H12AffineEnvironment.transform 8 157 env24057 = env24058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 157 env24057 == env24058) = true)

theorem identity24058 : scanCanonicalize (H12AffineFastState.compose env24058 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24058 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24059 : List Nat := [2,4,8,16,1,17,128,5,157,21,1,153,128,136,137,138,16,1,20,136,1,0,152,138,8,17,136,17,153,136,20,136,4,0,1,21]

theorem envBound24059 : H12AffineFastState.Bounded env24059 := by
  intro p hp
  have h : env24059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24058_24059 : H12AffineEnvironment.transform 9 21 env24058 = env24059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24058 == env24059) = true)

theorem identity24059 : scanCanonicalize (H12AffineFastState.compose env24059 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound24059 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24060 : List Nat := [2,4,8,2,1,3,128,5,143,7,1,139,128,136,137,138,2,1,6,136,1,0,138,138,8,3,136,3,139,136,6,136,4,0,1,7]

theorem envBound24060 : H12AffineFastState.Bounded env24060 := by
  intro p hp
  have h : env24060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24059_24060 : H12AffineEnvironment.transform 3 2 env24059 = env24060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env24059 == env24060) = true)

theorem identity24060 : scanCanonicalize (H12AffineFastState.compose env24060 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24060 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24061 : List Nat := [2,4,8,2,1,3,8,5,7,7,1,3,8,0,1,2,2,1,6,0,1,0,2,2,8,3,0,3,3,0,6,0,4,0,1,7]

theorem envBound24061 : H12AffineFastState.Bounded env24061 := by
  intro p hp
  have h : env24061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24060_24061 : H12AffineEnvironment.transform 6 8 env24060 = env24061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24060 == env24061) = true)

def env24062 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272513,2101248,2114835,8328,17,121999,115103,17665,2404637,119043,329731,257,2199999,2191387,63109]

theorem envBound24062 : H12AffineFastState.Bounded env24062 := by
  intro p hp
  have h : env24062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24034_24062 : H12AffineEnvironment.transform 21 272513 env24034 = env24062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24034 == env24062) = true)

theorem identity24062 : scanCanonicalize (H12AffineFastState.compose env24062 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound24062 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24063 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,77851,272513,73755,95496,8328,17,121999,115103,17665,360710,119043,329731,257,41380,16384,63109]

theorem envBound24063 : H12AffineFastState.Bounded env24063 := by
  intro p hp
  have h : env24063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24062_24063 : H12AffineEnvironment.transform 20 77851 env24062 = env24063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env24062 == env24063) = true)

def env24064 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,77851,272513,73755,95496,8328,17,121999,115103,17665,360710,119043,329731,257,41348,16384,63109]

theorem envBound24064 : H12AffineFastState.Bounded env24064 := by
  intro p hp
  have h : env24064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24063_24064 : H12AffineEnvironment.transform 4 0 env24063 = env24064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24063 == env24064) = true)

theorem identity24064 : scanCanonicalize (H12AffineFastState.compose env24064 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56461) := by decide +kernel

theorem selectedBound24064 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env24065 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,56461,1025,32769,77851,62476,73755,95496,8328,17,121999,115103,17665,89483,119043,119950,257,41348,16384,63109]

theorem envBound24065 : H12AffineFastState.Bounded env24065 := by
  intro p hp
  have h : env24065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24064_24065 : H12AffineEnvironment.transform 17 56461 env24064 = env24065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56461 env24064 == env24065) = true)

theorem identity24065 : scanCanonicalize (H12AffineFastState.compose env24065 (packedSelected [2,6,9,11,14,17,19,22,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound24065 : packedSelected [2,6,9,11,14,17,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env24066 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,29831,24861,56461,1025,32769,17564,62476,21660,399,8328,17,43016,46360,17665,10508,42372,40969,257,41348,16384,63109]

theorem envBound24066 : H12AffineFastState.Bounded env24066 := by
  intro p hp
  have h : env24066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24065_24066 : H12AffineEnvironment.transform 15 29831 env24065 = env24066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env24065 == env24066) = true)

theorem identity24066 : scanCanonicalize (H12AffineFastState.compose env24066 (packedSelected [0,2,3,4,5,7,10,11,12,14,15,16,17,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13696) := by decide +kernel

theorem selectedBound24066 : packedSelected [0,2,3,4,5,7,10,11,12,14,15,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env24067 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,13696,32768,263,5277,43277,1025,32769,12572,33164,8476,399,8328,17,43016,46360,12417,10508,42372,40969,257,41348,13696,33541]

theorem envBound24067 : H12AffineFastState.Bounded env24067 := by
  intro p hp
  have h : env24067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24066_24067 : H12AffineEnvironment.transform 13 13696 env24066 = env24067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13696 env24066 == env24067) = true)

theorem identity24067 : scanCanonicalize (H12AffineFastState.compose env24067 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound24067 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env24068 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,13696,136,263,5277,10629,1025,137,12572,260,8476,399,8328,17,10368,13712,12417,10508,9484,8321,257,8460,13696,909]

theorem envBound24068 : H12AffineFastState.Bounded env24068 := by
  intro p hp
  have h : env24068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24067_24068 : H12AffineEnvironment.transform 14 136 env24067 = env24068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env24067 == env24068) = true)

theorem identity24068 : scanCanonicalize (H12AffineFastState.compose env24068 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound24068 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24069 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8,5512,136,263,5277,2445,1025,137,4372,260,276,399,128,17,2184,5528,4233,2308,1284,137,257,260,5512,909]

theorem envBound24069 : H12AffineFastState.Bounded env24069 := by
  intro p hp
  have h : env24069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24068_24069 : H12AffineEnvironment.transform 12 8 env24068 = env24069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24068 == env24069) = true)

theorem identity24069 : scanCanonicalize (H12AffineFastState.compose env24069 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24069 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24070 : List Nat := [2,4,8,16,0,17,128,4,512,1024,2048,4096,8,5260,136,3,5277,2185,1025,137,4112,0,16,139,128,17,2184,5276,4233,2048,1024,137,5,0,5260,649]

theorem envBound24070 : H12AffineFastState.Bounded env24070 := by
  intro p hp
  have h : env24070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24069_24070 : H12AffineEnvironment.transform 7 4 env24069 = env24070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24069 == env24070) = true)

theorem identity24070 : scanCanonicalize (H12AffineFastState.compose env24070 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24070 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24071 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5125,1,3,5140,2048,1025,0,4112,0,16,2,9,17,2049,5141,4096,2048,1024,0,5,0,5125,512]

theorem envBound24071 : H12AffineFastState.Bounded env24071 := by
  intro p hp
  have h : env24071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24070_24071 : H12AffineEnvironment.transform 6 9 env24070 = env24071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24070 == env24071) = true)

theorem identity24071 : scanCanonicalize (H12AffineFastState.compose env24071 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24071 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24072 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1045,8,16,1,3,1,2048,1025,0,1029,0,16,2,9,17,2049,0,1045,2048,1024,0,5,0,16,512]

theorem envBound24072 : H12AffineFastState.Bounded env24072 := by
  intro p hp
  have h : env24072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24071_24072 : H12AffineEnvironment.transform 11 1045 env24071 = env24072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24071 == env24072) = true)

theorem identity24072 : scanCanonicalize (H12AffineFastState.compose env24072 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound24072 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24073 : List Nat := [2,4,8,16,0,17,9,4,512,1024,27,1045,8,16,1,3,1,27,1025,0,1029,0,16,2,9,17,26,0,1045,27,1024,0,5,0,16,512]

theorem envBound24073 : H12AffineFastState.Bounded env24073 := by
  intro p hp
  have h : env24073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24072_24073 : H12AffineEnvironment.transform 10 27 env24072 = env24073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env24072 == env24073) = true)

theorem identity24073 : scanCanonicalize (H12AffineFastState.compose env24073 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound24073 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24074 : List Nat := [2,4,8,16,0,17,9,4,512,30,27,11,8,16,1,3,1,27,31,0,27,0,16,2,9,17,26,0,11,27,30,0,5,0,16,512]

theorem envBound24074 : H12AffineFastState.Bounded env24074 := by
  intro p hp
  have h : env24074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24073_24074 : H12AffineEnvironment.transform 9 30 env24073 = env24074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env24073 == env24074) = true)

theorem identity24074 : scanCanonicalize (H12AffineFastState.compose env24074 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24074 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24075 : List Nat := [2,4,8,11,0,10,9,4,512,5,0,11,8,11,1,3,1,0,4,0,0,0,11,2,9,10,1,0,11,0,5,0,5,0,11,512]

theorem envBound24075 : H12AffineFastState.Bounded env24075 := by
  intro p hp
  have h : env24075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24074_24075 : H12AffineEnvironment.transform 3 11 env24074 = env24075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24074 == env24075) = true)

theorem identity24075 : scanCanonicalize (H12AffineFastState.compose env24075 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound24075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24076 : List Nat := [2,1,8,11,0,10,9,1,512,0,0,11,8,11,1,3,1,0,1,0,0,0,11,2,9,10,1,0,11,0,0,0,0,0,11,512]

theorem envBound24076 : H12AffineFastState.Bounded env24076 := by
  intro p hp
  have h : env24076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24075_24076 : H12AffineEnvironment.transform 1 1 env24075 = env24076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env24075 == env24076) = true)

def env24077 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,77851,272513,73755,95496,8328,17,121999,115103,17665,360710,119043,329731,257,41349,16384,63109]

theorem envBound24077 : H12AffineFastState.Bounded env24077 := by
  intro p hp
  have h : env24077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24063_24077 : H12AffineEnvironment.transform 4 1 env24063 = env24077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24063 == env24077) = true)

theorem identity24077 : scanCanonicalize (H12AffineFastState.compose env24077 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 10248) := by decide +kernel

theorem selectedBound24077 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env24078 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10248,1025,32769,77851,137,73755,95496,8328,17,121999,115103,17665,108814,119043,73739,257,41349,16384,63109]

theorem envBound24078 : H12AffineFastState.Bounded env24078 := by
  intro p hp
  have h : env24078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24077_24078 : H12AffineEnvironment.transform 17 10248 env24077 = env24078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10248 env24077 == env24078) = true)

theorem identity24078 : scanCanonicalize (H12AffineFastState.compose env24078 (packedSelected [0,1,3,4,5,7,8,10,17,18,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound24078 : packedSelected [0,1,3,4,5,7,8,10,17,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env24079 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,136,65536,24861,10248,1025,137,77851,137,73755,95496,8328,17,89095,82199,17665,76166,86411,73739,257,8461,16384,30221]

theorem envBound24079 : H12AffineFastState.Bounded env24079 := by
  intro p hp
  have h : env24079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24078_24079 : H12AffineEnvironment.transform 14 136 env24078 = env24079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env24078 == env24079) = true)

theorem identity24079 : scanCanonicalize (H12AffineFastState.compose env24079 (packedSelected [1,4,8,11,17,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 1424) := by decide +kernel

theorem selectedBound24079 : packedSelected [1,4,8,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24080 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,1424,16384,136,65536,17549,3480,1025,137,71051,137,66955,86168,1304,17,89095,82199,17665,68630,86411,66971,257,1181,16384,21405]

theorem envBound24080 : H12AffineFastState.Bounded env24080 := by
  intro p hp
  have h : env24080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24079_24080 : H12AffineEnvironment.transform 12 1424 env24079 = env24080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1424 env24079 == env24080) = true)

theorem identity24080 : scanCanonicalize (H12AffineFastState.compose env24080 (packedSelected [0,1,2,3,5,6,7,8,10,12,15,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound24080 : packedSelected [0,1,2,3,5,6,7,8,10,12,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env24081 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,1424,16384,136,1047,17549,3480,1025,137,4508,137,412,21647,1304,17,22544,17664,17665,2049,21916,396,257,1181,16384,21405]

theorem envBound24081 : H12AffineFastState.Bounded env24081 := by
  intro p hp
  have h : env24081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24080_24081 : H12AffineEnvironment.transform 15 1047 env24080 = env24081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env24080 == env24081) = true)

theorem identity24081 : scanCanonicalize (H12AffineFastState.compose env24081 (packedSelected [2,3,4,5,6,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5261) := by decide +kernel

theorem selectedBound24081 : packedSelected [2,3,4,5,6,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env24082 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,1424,5261,136,1047,4096,3480,1025,137,4508,137,412,2,1304,17,3229,4493,4492,2049,273,396,257,1181,5261,1808]

theorem envBound24082 : H12AffineFastState.Bounded env24082 := by
  intro p hp
  have h : env24082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24081_24082 : H12AffineEnvironment.transform 13 5261 env24081 = env24082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5261 env24081 == env24082) = true)

theorem identity24082 : scanCanonicalize (H12AffineFastState.compose env24082 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound24082 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24083 : List Nat := [2,4,8,16,1,17,128,256,512,156,2048,4096,268,4113,136,139,4096,2308,157,137,4508,137,412,2,388,17,2049,4493,4492,2049,273,396,257,1,4113,908]

theorem envBound24083 : H12AffineFastState.Bounded env24083 := by
  intro p hp
  have h : env24083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24082_24083 : H12AffineEnvironment.transform 9 156 env24082 = env24083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env24082 == env24083) = true)

theorem identity24083 : scanCanonicalize (H12AffineFastState.compose env24083 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24083 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24084 : List Nat := [2,4,8,16,1,17,128,4,512,156,2048,4096,8,4113,136,139,4096,2048,157,137,4248,137,152,2,128,17,2049,4233,4232,2049,21,136,5,1,4113,648]

theorem envBound24084 : H12AffineFastState.Bounded env24084 := by
  intro p hp
  have h : env24084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24083_24084 : H12AffineEnvironment.transform 7 4 env24083 = env24084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24083 == env24084) = true)

theorem identity24084 : scanCanonicalize (H12AffineFastState.compose env24084 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound24084 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24085 : List Nat := [2,4,8,16,1,17,128,4,512,156,131,4096,8,4113,136,139,4096,131,157,137,4248,137,152,2,128,17,130,4233,4232,130,21,136,5,1,4113,648]

theorem envBound24085 : H12AffineFastState.Bounded env24085 := by
  intro p hp
  have h : env24085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24084_24085 : H12AffineEnvironment.transform 10 131 env24084 = env24085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env24084 == env24085) = true)

theorem identity24085 : scanCanonicalize (H12AffineFastState.compose env24085 (packedSelected [1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 662) := by decide +kernel

theorem selectedBound24085 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env24086 : List Nat := [2,4,8,16,1,17,128,4,512,156,131,662,8,647,136,139,662,131,157,137,526,137,152,2,128,17,130,543,542,130,21,136,5,1,647,648]

theorem envBound24086 : H12AffineFastState.Bounded env24086 := by
  intro p hp
  have h : env24086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24085_24086 : H12AffineEnvironment.transform 11 662 env24085 = env24086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 662 env24085 == env24086) = true)

theorem identity24086 : scanCanonicalize (H12AffineFastState.compose env24086 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 151) := by decide +kernel

theorem selectedBound24086 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24087 : List Nat := [2,4,8,16,1,17,128,4,151,156,131,1,8,16,136,139,1,131,157,137,153,137,152,2,128,17,130,136,137,130,21,136,5,1,16,31]

theorem envBound24087 : H12AffineFastState.Bounded env24087 := by
  intro p hp
  have h : env24087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24086_24087 : H12AffineEnvironment.transform 8 151 env24086 = env24087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 151 env24086 == env24087) = true)

theorem identity24087 : scanCanonicalize (H12AffineFastState.compose env24087 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound24087 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env24088 : List Nat := [2,4,8,12,1,13,128,4,139,128,131,1,8,12,136,139,1,131,129,137,133,137,132,2,128,13,130,136,137,130,9,136,5,1,12,3]

theorem envBound24088 : H12AffineFastState.Bounded env24088 := by
  intro p hp
  have h : env24088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24087_24088 : H12AffineEnvironment.transform 3 12 env24087 = env24088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env24087 == env24088) = true)

theorem identity24088 : scanCanonicalize (H12AffineFastState.compose env24088 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound24088 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env24089 : List Nat := [2,4,8,12,1,13,3,4,8,3,0,1,8,12,11,8,1,0,2,10,6,10,7,2,3,13,1,11,10,1,9,11,5,1,12,3]

theorem envBound24089 : H12AffineFastState.Bounded env24089 := by
  intro p hp
  have h : env24089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24088_24089 : H12AffineEnvironment.transform 6 3 env24088 = env24089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env24088 == env24089) = true)

theorem identity24089 : scanCanonicalize (H12AffineFastState.compose env24089 (packedSelected [2,11] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound24089 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env24090 : List Nat := [2,2,8,10,1,11,3,2,8,3,0,1,8,10,11,8,1,0,2,10,0,10,1,2,3,11,1,11,10,1,9,11,3,1,10,3]

theorem envBound24090 : H12AffineFastState.Bounded env24090 := by
  intro p hp
  have h : env24090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24089_24090 : H12AffineEnvironment.transform 1 2 env24089 = env24090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env24089 == env24090) = true)

theorem identity24090 : scanCanonicalize (H12AffineFastState.compose env24090 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24091 : List Nat := [2,2,2,0,1,1,3,2,2,3,0,1,2,0,1,2,1,0,2,0,0,0,1,2,3,1,1,1,0,1,3,1,3,1,0,3]

theorem envBound24091 : H12AffineFastState.Bounded env24091 := by
  intro p hp
  have h : env24091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24090_24091 : H12AffineEnvironment.transform 2 2 env24090 = env24091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24090 == env24091) = true)

theorem identity24091 : scanCanonicalize (H12AffineFastState.compose env24091 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound24091 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24092 : List Nat := [0,0,0,0,1,1,1,0,0,1,0,1,0,0,1,0,1,0,0,0,0,0,1,0,1,1,1,1,0,1,1,1,1,1,0,1]

theorem envBound24092 : H12AffineFastState.Bounded env24092 := by
  intro p hp
  have h : env24092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24091_24092 : H12AffineEnvironment.transform 0 0 env24091 = env24092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env24091 == env24092) = true)

def env24093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2101249,2114835,8328,17,4584463,115103,17664,2404636,119042,4268162,257,2199998,2191386,63108]

theorem envBound24093 : H12AffineFastState.Bounded env24093 := by
  intro p hp
  have h : env24093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24033_24093 : H12AffineEnvironment.transform 22 2101249 env24033 = env24093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101249 env24033 == env24093) = true)

def env24094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,121999,115103,17664,2404636,119042,329730,257,2199998,2191386,63108]

theorem envBound24094 : H12AffineFastState.Bounded env24094 := by
  intro p hp
  have h : env24094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24093_24094 : H12AffineEnvironment.transform 21 272512 env24093 = env24094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24093 == env24094) = true)

theorem identity24094 : scanCanonicalize (H12AffineFastState.compose env24094 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound24094 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,24861,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,2048,5392,17664,2404636,1421,318605,257,2114865,2139285,63108]

theorem envBound24095 : H12AffineFastState.Bounded env24095 := by
  intro p hp
  have h : env24095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24094_24095 : H12AffineEnvironment.transform 15 54415 env24094 = env24095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env24094 == env24095) = true)

theorem identity24095 : scanCanonicalize (H12AffineFastState.compose env24095 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound24095 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24861,262144,1025,29828,2097152,272512,2101249,2114835,8328,17,2048,5392,17664,2377113,1421,272392,257,2114865,2117648,513]

theorem envBound24096 : H12AffineFastState.Bounded env24096 := by
  intro p hp
  have h : env24096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24095_24096 : H12AffineEnvironment.transform 14 29829 env24095 = env24096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env24095 == env24096) = true)

theorem identity24096 : scanCanonicalize (H12AffineFastState.compose env24096 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound24096 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env24097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24861,262144,1025,29828,281653,272512,285748,264486,8328,17,2048,5392,17664,2476,1421,272392,257,264452,269349,513]

theorem envBound24097 : H12AffineFastState.Bounded env24097 := by
  intro p hp
  have h : env24097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24096_24097 : H12AffineEnvironment.transform 20 281653 env24096 = env24097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env24096 == env24097) = true)

theorem identity24097 : scanCanonicalize (H12AffineFastState.compose env24097 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound24097 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env24098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24861,23725,1025,29828,4248,29741,153,21899,8328,17,2048,5392,17664,2476,1421,29861,257,21929,16520,513]

theorem envBound24098 : H12AffineFastState.Bounded env24098 := by
  intro p hp
  have h : env24098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24097_24098 : H12AffineEnvironment.transform 17 23725 env24097 = env24098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env24097 == env24098) = true)

theorem identity24098 : scanCanonicalize (H12AffineFastState.compose env24098 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound24098 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env24099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,0,8202,5528,10280,1025,1,4248,168,153,8462,8328,17,2048,5392,12677,2476,1421,32,257,8492,13325,513]

theorem envBound24099 : H12AffineFastState.Bounded env24099 := by
  intro p hp
  have h : env24099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24098_24099 : H12AffineEnvironment.transform 13 13445 env24098 = env24099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env24098 == env24099) = true)

theorem identity24099 : scanCanonicalize (H12AffineFastState.compose env24099 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24099 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24100 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8202,5393,10280,1025,1,4113,33,16,8462,8193,17,2048,5392,12556,2341,1284,32,257,8492,13325,513]

theorem envBound24100 : H12AffineFastState.Bounded env24100 := by
  intro p hp
  have h : env24100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24099_24100 : H12AffineEnvironment.transform 6 9 env24099 = env24100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24099 == env24100) = true)

theorem identity24100 : scanCanonicalize (H12AffineFastState.compose env24100 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24100 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24101 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1025,1,4113,33,16,2,269,17,2048,5392,4096,2341,1284,32,257,32,5377,513]

theorem envBound24101 : H12AffineFastState.Bounded env24101 := by
  intro p hp
  have h : env24101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24100_24101 : H12AffineEnvironment.transform 12 268 env24100 = env24101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24100 == env24101) = true)

theorem identity24101 : scanCanonicalize (H12AffineFastState.compose env24101 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24102 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,17,268,1297,0,262,1280,2340,1025,1,0,33,16,2,269,17,2048,1281,17,2341,1284,32,257,32,1296,513]

theorem envBound24102 : H12AffineFastState.Bounded env24102 := by
  intro p hp
  have h : env24102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24101_24102 : H12AffineEnvironment.transform 11 17 env24101 = env24102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24101 == env24102) = true)

theorem identity24102 : scanCanonicalize (H12AffineFastState.compose env24102 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound24102 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24103 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1819,17,268,1297,0,262,1280,1599,1025,1,0,33,16,2,269,17,1819,1281,17,1598,1284,32,257,32,1296,513]

theorem envBound24103 : H12AffineFastState.Bounded env24103 := by
  intro p hp
  have h : env24103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24102_24103 : H12AffineEnvironment.transform 10 1819 env24102 = env24103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env24102 == env24103) = true)

theorem identity24103 : scanCanonicalize (H12AffineFastState.compose env24103 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound24103 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24104 : List Nat := [2,4,8,16,32,17,9,256,512,542,261,17,268,783,0,262,798,33,543,1,0,33,16,2,269,17,261,799,17,32,794,32,257,32,782,513]

theorem envBound24104 : H12AffineFastState.Bounded env24104 := by
  intro p hp
  have h : env24104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24103_24104 : H12AffineEnvironment.transform 9 542 env24103 = env24104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env24103 == env24104) = true)

theorem identity24104 : scanCanonicalize (H12AffineFastState.compose env24104 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24104 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24105 : List Nat := [2,4,8,16,1,17,9,256,512,542,261,17,268,783,0,262,798,0,543,1,0,0,16,2,269,17,261,799,17,1,794,1,257,1,782,513]

theorem envBound24105 : H12AffineFastState.Bounded env24105 := by
  intro p hp
  have h : env24105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24104_24105 : H12AffineEnvironment.transform 4 1 env24104 = env24105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24104 == env24105) = true)

def env24106 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272513,2101249,2114835,8328,17,121998,115103,17664,2404636,119042,329731,257,2199998,2191386,63108]

theorem envBound24106 : H12AffineFastState.Bounded env24106 := by
  intro p hp
  have h : env24106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24093_24106 : H12AffineEnvironment.transform 21 272513 env24093 = env24106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24093 == env24106) = true)

theorem identity24106 : scanCanonicalize (H12AffineFastState.compose env24106 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound24106 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24107 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,115871,272513,119966,98700,8328,17,121998,115103,17664,357763,119042,329731,257,21793,46213,63108]

theorem envBound24107 : H12AffineFastState.Bounded env24107 := by
  intro p hp
  have h : env24107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24106_24107 : H12AffineEnvironment.transform 20 115871 env24106 = env24107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env24106 == env24107) = true)

def env24108 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,115735,272393,119830,98564,8192,17,121862,114967,17664,357643,119042,329731,257,21793,46093,62988]

theorem envBound24108 : H12AffineFastState.Bounded env24108 := by
  intro p hp
  have h : env24108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24107_24108 : H12AffineEnvironment.transform 6 8 env24107 = env24108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24107 == env24108) = true)

theorem identity24108 : scanCanonicalize (H12AffineFastState.compose env24108 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound24108 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env24109 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24861,262144,1025,8461,91419,272393,95514,73736,8192,17,97546,90139,17664,357643,94222,329731,257,21793,5377,22272]

theorem envBound24109 : H12AffineFastState.Bounded env24109 := by
  intro p hp
  have h : env24109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24108_24109 : H12AffineEnvironment.transform 14 8460 env24108 = env24109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env24108 == env24109) = true)

theorem identity24109 : scanCanonicalize (H12AffineFastState.compose env24109 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound24109 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24110 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24861,67618,1025,8461,91419,73771,95514,73736,8192,17,97546,90139,17664,32041,94222,33,257,21793,5377,22272]

theorem envBound24110 : H12AffineFastState.Bounded env24110 := by
  intro p hp
  have h : env24110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24109_24110 : H12AffineEnvironment.transform 17 67618 env24109 = env24110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env24109 == env24110) = true)

theorem identity24110 : scanCanonicalize (H12AffineFastState.compose env24110 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24110 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env24111 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,263,24861,2341,1025,8461,25628,8492,29725,8463,8192,17,31757,24860,17664,32041,28937,33,257,21793,5377,22272]

theorem envBound24111 : H12AffineFastState.Bounded env24111 := by
  intro p hp
  have h : env24111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24110_24111 : H12AffineEnvironment.transform 15 263 env24110 = env24111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24110 == env24111) = true)

theorem identity24111 : scanCanonicalize (H12AffineFastState.compose env24111 (packedSelected [0,7,11,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound24111 : packedSelected [0,7,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24112 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,8192,16384,8460,263,24861,1077,1025,8461,25628,8492,29725,8463,8192,17,28957,24860,17664,28729,28937,33,257,21793,5377,22272]

theorem envBound24112 : H12AffineFastState.Bounded env24112 := by
  intro p hp
  have h : env24112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24111_24112 : H12AffineEnvironment.transform 10 1296 env24111 = env24112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env24111 == env24112) = true)

theorem identity24112 : scanCanonicalize (H12AffineFastState.compose env24112 (packedSelected [0,1,4,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound24112 : packedSelected [0,1,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env24113 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,1060,8192,16384,8460,263,24861,1077,1025,8461,25628,8492,24633,8463,8192,17,25913,24860,17664,25629,25901,33,257,16645,293,17188]

theorem envBound24113 : H12AffineFastState.Bounded env24113 := by
  intro p hp
  have h : env24113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24112_24113 : H12AffineEnvironment.transform 11 1060 env24112 = env24113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env24112 == env24113) = true)

theorem identity24113 : scanCanonicalize (H12AffineFastState.compose env24113 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 8233) := by decide +kernel

theorem selectedBound24113 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env24114 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,1060,8192,8233,8460,263,308,1077,1025,8461,1077,8492,16,8463,8192,17,1296,309,9513,1076,1284,33,257,8492,293,8973]

theorem envBound24114 : H12AffineFastState.Bounded env24114 := by
  intro p hp
  have h : env24114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24113_24114 : H12AffineEnvironment.transform 13 8233 env24113 = env24114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8233 env24113 == env24114) = true)

theorem identity24114 : scanCanonicalize (H12AffineFastState.compose env24114 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound24114 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24115 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,1060,1336,1297,1076,263,308,1077,1025,1077,1077,1044,16,1079,1336,17,1296,309,17,1076,1284,33,257,1044,293,1589]

theorem envBound24115 : H12AffineFastState.Bounded env24115 := by
  intro p hp
  have h : env24115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24114_24115 : H12AffineEnvironment.transform 12 1336 env24114 = env24115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env24114 == env24115) = true)

theorem identity24115 : scanCanonicalize (H12AffineFastState.compose env24115 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24115 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24116 : List Nat := [2,4,8,16,32,17,8,256,512,53,293,17,269,292,1,263,308,0,52,0,0,33,16,2,269,17,293,309,17,1,305,33,257,33,293,512]

theorem envBound24116 : H12AffineFastState.Bounded env24116 := by
  intro p hp
  have h : env24116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24115_24116 : H12AffineEnvironment.transform 9 53 env24115 = env24116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24115 == env24116) = true)

theorem identity24116 : scanCanonicalize (H12AffineFastState.compose env24116 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24116 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24117 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,17,40,1,1,34,17,0,52,0,0,33,16,2,40,17,0,16,17,1,20,33,36,33,0,512]

theorem envBound24117 : H12AffineFastState.Bounded env24117 := by
  intro p hp
  have h : env24117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24116_24117 : H12AffineEnvironment.transform 7 37 env24116 = env24117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24116 == env24117) = true)

theorem identity24117 : scanCanonicalize (H12AffineFastState.compose env24117 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound24117 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24118 : List Nat := [2,0,8,16,32,17,8,33,512,49,0,17,40,1,1,34,17,0,48,0,0,33,16,2,40,17,0,16,17,1,16,33,32,33,0,512]

theorem envBound24118 : H12AffineFastState.Bounded env24118 := by
  intro p hp
  have h : env24118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24117_24118 : H12AffineEnvironment.transform 1 0 env24117 = env24118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env24117 == env24118) = true)

theorem identity24118 : scanCanonicalize (H12AffineFastState.compose env24118 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound24118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24119 : List Nat := [0,0,8,16,32,17,8,33,512,49,0,17,40,1,1,32,17,0,48,0,0,33,16,0,40,17,0,16,17,1,16,33,32,33,0,512]

theorem envBound24119 : H12AffineFastState.Bounded env24119 := by
  intro p hp
  have h : env24119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24118_24119 : H12AffineEnvironment.transform 0 0 env24118 = env24119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env24118 == env24119) = true)

theorem identity24119 : scanCanonicalize (H12AffineFastState.compose env24119 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 41) := by decide +kernel

theorem selectedBound24119 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24120 : List Nat := [0,0,8,16,32,17,8,33,41,49,0,17,40,1,1,32,17,0,48,0,0,33,16,0,40,17,0,16,17,1,16,33,32,33,0,41]

theorem envBound24120 : H12AffineFastState.Bounded env24120 := by
  intro p hp
  have h : env24120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24119_24120 : H12AffineEnvironment.transform 8 41 env24119 = env24120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 41 env24119 == env24120) = true)

theorem identity24120 : scanCanonicalize (H12AffineFastState.compose env24120 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound24120 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24121 : List Nat := [0,0,8,16,9,17,8,8,0,24,0,17,1,1,1,9,17,0,25,0,0,8,16,0,1,17,0,16,17,1,16,8,9,8,0,0]

theorem envBound24121 : H12AffineFastState.Bounded env24121 := by
  intro p hp
  have h : env24121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24120_24121 : H12AffineEnvironment.transform 4 9 env24120 = env24121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env24120 == env24121) = true)

theorem identity24121 : scanCanonicalize (H12AffineFastState.compose env24121 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound24121 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24122 : List Nat := [0,0,8,8,9,9,8,8,0,0,0,9,1,1,1,9,9,0,1,0,0,8,8,0,1,9,0,8,9,1,8,8,9,8,0,0]

theorem envBound24122 : H12AffineFastState.Bounded env24122 := by
  intro p hp
  have h : env24122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24121_24122 : H12AffineEnvironment.transform 3 8 env24121 = env24122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env24121 == env24122) = true)

theorem identity24122 : scanCanonicalize (H12AffineFastState.compose env24122 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound24122 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24123 : List Nat := [0,0,0,0,1,1,0,0,0,0,0,1,1,1,1,1,1,0,1,0,0,0,0,0,1,1,0,0,1,1,0,0,1,0,0,0]

theorem envBound24123 : H12AffineFastState.Bounded env24123 := by
  intro p hp
  have h : env24123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24122_24123 : H12AffineEnvironment.transform 2 0 env24122 = env24123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env24122 == env24123) = true)

def env24124 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,115734,272392,119831,98565,8193,17,121863,114966,17664,357642,119042,329731,257,21793,46092,62989]

theorem envBound24124 : H12AffineFastState.Bounded env24124 := by
  intro p hp
  have h : env24124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24107_24124 : H12AffineEnvironment.transform 6 9 env24107 = env24124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24107 == env24124) = true)

theorem identity24124 : scanCanonicalize (H12AffineFastState.compose env24124 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 41262) := by decide +kernel

theorem selectedBound24124 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env24125 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,41262,24861,262144,1025,32769,25912,272392,30009,8235,8193,17,32041,24632,17664,316452,28716,305453,257,21793,46092,62989]

theorem envBound24125 : H12AffineFastState.Bounded env24125 := by
  intro p hp
  have h : env24125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24124_24125 : H12AffineEnvironment.transform 15 41262 env24124 = env24125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41262 env24124 == env24125) = true)

theorem identity24125 : scanCanonicalize (H12AffineFastState.compose env24125 (packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24125 : packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env24126 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,16384,32768,33030,16693,262144,1025,32769,17680,264224,21777,3,41,17,23809,16400,17664,316452,20484,297221,257,21793,37924,54821]

theorem envBound24126 : H12AffineFastState.Bounded env24126 := by
  intro p hp
  have h : env24126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24125_24126 : H12AffineEnvironment.transform 12 40 env24125 = env24126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24125 == env24126) = true)

theorem identity24126 : scanCanonicalize (H12AffineFastState.compose env24126 (packedSelected [1,8,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24126 : packedSelected [1,8,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24127 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,32768,33030,5173,262144,1025,32769,4112,264224,17,3,41,17,2049,5392,4096,295204,1284,297221,257,33,37924,33573]

theorem envBound24127 : H12AffineFastState.Bounded env24127 := by
  intro p hp
  have h : env24127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24126_24127 : H12AffineEnvironment.transform 13 5376 env24126 = env24127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24126 == env24127) = true)

theorem identity24127 : scanCanonicalize (H12AffineFastState.compose env24127 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24127 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24128 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,9,5376,32768,33030,5140,262144,1025,32769,4112,264193,17,3,8,17,2049,5392,4096,295173,1284,297221,257,0,37893,33540]

theorem envBound24128 : H12AffineFastState.Bounded env24128 := by
  intro p hp
  have h : env24128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24127_24128 : H12AffineEnvironment.transform 4 1 env24127 = env24128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24127 == env24128) = true)

theorem identity24128 : scanCanonicalize (H12AffineFastState.compose env24128 (packedSelected [1,8,10,12,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound24128 : packedSelected [1,8,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24129 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,9,5376,32768,33030,5140,2048,1025,32769,4112,1,17,3,8,17,2049,5392,4096,35077,1284,33029,257,0,37893,33540]

theorem envBound24129 : H12AffineFastState.Bounded env24129 := by
  intro p hp
  have h : env24129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24128_24129 : H12AffineEnvironment.transform 17 2048 env24128 = env24129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env24128 == env24129) = true)

theorem identity24129 : scanCanonicalize (H12AffineFastState.compose env24129 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24129 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24130 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,9,5376,1,263,5140,2048,1025,0,4112,1,17,3,8,17,2049,5392,4096,2308,1284,260,257,0,5124,773]

theorem envBound24130 : H12AffineFastState.Bounded env24130 := by
  intro p hp
  have h : env24130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24129_24130 : H12AffineEnvironment.transform 14 1 env24129 = env24130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24129 == env24130) = true)

theorem identity24130 : scanCanonicalize (H12AffineFastState.compose env24130 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24130 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24131 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5125,1,2,5140,2048,1025,0,4112,1,17,3,8,17,2049,5141,4096,2049,1025,1,4,0,5124,512]

theorem envBound24131 : H12AffineFastState.Bounded env24131 := by
  intro p hp
  have h : env24131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24130_24131 : H12AffineEnvironment.transform 7 5 env24130 = env24131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24130 == env24131) = true)

def env24132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066126,115151,10507600,8692045,10600787,4268163,257,8487407,8478795,10544772]

theorem envBound24132 : H12AffineFastState.Bounded env24132 := by
  intro p hp
  have h : env24132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24017_24132 : H12AffineEnvironment.transform 16 24909 env24017 = env24132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env24017 == env24132) = true)

def env24133 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114835,8328,16,15066126,115103,10507520,8691997,10600707,4268163,257,8487359,8478747,10544772]

theorem envBound24133 : H12AffineFastState.Bounded env24133 := by
  intro p hp
  have h : env24133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24132_24133 : H12AffineEnvironment.transform 5 16 env24132 = env24133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24132 == env24133) = true)

theorem identity24133 : scanCanonicalize (H12AffineFastState.compose env24133 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2155533) := by decide +kernel

theorem selectedBound24133 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env24134 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2155533,2114835,8328,16,4521987,115103,45325,2376976,75022,4268163,257,2188722,2196502,649]

theorem envBound24134 : H12AffineFastState.Bounded env24134 := by
  intro p hp
  have h : env24134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24133_24134 : H12AffineEnvironment.transform 22 2155533 env24133 = env24134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env24133 == env24134) = true)

def env24135 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,2114864,2155533,2114835,8328,16,2442547,115103,45325,2376976,75022,2188723,257,2188722,2196502,649]

theorem envBound24135 : H12AffineFastState.Bounded env24135 := by
  intro p hp
  have h : env24135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24134_24135 : H12AffineEnvironment.transform 21 2114864 env24134 = env24135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114864 env24134 == env24135) = true)

theorem identity24135 : scanCanonicalize (H12AffineFastState.compose env24135 (packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24135 : packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS < 2^1333 := by decide +kernel

def env24136 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,2114864,2155533,2114835,8328,16,2190619,115103,45325,2125112,75022,2188723,257,2188722,2196502,649]

theorem envBound24136 : H12AffineFastState.Bounded env24136 := by
  intro p hp
  have h : env24136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24135_24136 : H12AffineEnvironment.transform 17 10280 env24135 = env24136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24135 == env24136) = true)

theorem identity24136 : scanCanonicalize (H12AffineFastState.compose env24136 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 124306) := by decide +kernel

theorem selectedBound24136 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env24137 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,124306,106658,65951,106625,8328,16,34953,115103,45325,100522,75022,32801,257,32800,24964,649]

theorem envBound24137 : H12AffineFastState.Bounded env24137 := by
  intro p hp
  have h : env24137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24136_24137 : H12AffineEnvironment.transform 20 124306 env24136 = env24137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124306 env24136 == env24137) = true)

theorem identity24137 : scanCanonicalize (H12AffineFastState.compose env24137 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound24137 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env24138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,262,24861,10280,1025,32769,58516,41380,153,41351,8328,16,34953,49305,45325,35244,9224,32801,257,32800,24964,649]

theorem envBound24138 : H12AffineFastState.Bounded env24138 := by
  intro p hp
  have h : env24138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24137_24138 : H12AffineEnvironment.transform 15 262 env24137 = env24138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env24137 == env24138) = true)

theorem identity24138 : scanCanonicalize (H12AffineFastState.compose env24138 (packedSelected [1,3,5,8,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound24138 : packedSelected [1,3,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env24139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,32768,262,16537,2476,1025,32769,50448,32800,153,32771,268,16,34953,49305,37001,35244,1420,32801,257,32800,16384,649]

theorem envBound24139 : H12AffineFastState.Bounded env24139 := by
  intro p hp
  have h : env24139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24138_24139 : H12AffineEnvironment.transform 12 388 env24138 = env24139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env24138 == env24139) = true)

theorem identity24139 : scanCanonicalize (H12AffineFastState.compose env24139 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24139 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env24140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,262,16401,2340,1025,32769,50448,32800,17,32771,268,16,34817,49169,36865,35108,1284,32801,257,32800,16384,513]

theorem envBound24140 : H12AffineFastState.Bounded env24140 := by
  intro p hp
  have h : env24140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24139_24140 : H12AffineEnvironment.transform 6 8 env24139 = env24140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24139 == env24140) = true)

theorem identity24140 : scanCanonicalize (H12AffineFastState.compose env24140 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 1290) := by decide +kernel

theorem selectedBound24140 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1290,262,16401,2340,1025,1291,16410,1322,17,1289,268,16,3339,17691,5387,3118,1284,1323,257,1322,16384,513]

theorem envBound24141 : H12AffineFastState.Bounded env24141 := by
  intro p hp
  have h : env24141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24140_24141 : H12AffineEnvironment.transform 14 1290 env24140 = env24141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1290 env24140 == env24141) = true)

theorem identity24141 : scanCanonicalize (H12AffineFastState.compose env24141 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound24141 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24142 : List Nat := [2,4,8,16,32,16,8,256,512,267,2048,4096,268,16384,1,262,16401,2340,266,0,16410,33,17,2,268,16,2048,16400,4096,2341,15,32,257,33,16384,513]

theorem envBound24142 : H12AffineFastState.Bounded env24142 := by
  intro p hp
  have h : env24142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24141_24142 : H12AffineEnvironment.transform 9 267 env24141 = env24142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env24141 == env24142) = true)

theorem identity24142 : scanCanonicalize (H12AffineFastState.compose env24142 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound24142 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24143 : List Nat := [2,4,8,16,32,16,8,256,512,267,2048,4096,268,4356,1,262,4373,2340,266,0,4382,33,17,2,268,16,2048,4372,4096,2341,15,32,257,33,4356,513]

theorem envBound24143 : H12AffineFastState.Bounded env24143 := by
  intro p hp
  have h : env24143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24142_24143 : H12AffineEnvironment.transform 13 4356 env24142 = env24143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env24142 == env24143) = true)

theorem identity24143 : scanCanonicalize (H12AffineFastState.compose env24143 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound24143 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24144 : List Nat := [2,4,8,16,32,16,8,256,512,267,2048,2096,268,2356,1,262,2341,2340,266,0,2350,33,17,2,268,16,2048,2340,2096,2341,15,32,257,33,2356,513]

theorem envBound24144 : H12AffineFastState.Bounded env24144 := by
  intro p hp
  have h : env24144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24143_24144 : H12AffineEnvironment.transform 11 2096 env24143 = env24144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env24143 == env24144) = true)

theorem identity24144 : scanCanonicalize (H12AffineFastState.compose env24144 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound24144 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24145 : List Nat := [2,4,8,16,32,16,8,256,48,267,2048,2096,268,2356,1,262,2341,2340,266,0,2350,33,17,2,268,16,2048,2340,2096,2341,15,32,257,33,2356,49]

theorem envBound24145 : H12AffineFastState.Bounded env24145 := by
  intro p hp
  have h : env24145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24144_24145 : H12AffineEnvironment.transform 8 48 env24144 = env24145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env24144 == env24145) = true)

theorem identity24145 : scanCanonicalize (H12AffineFastState.compose env24145 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound24145 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24146 : List Nat := [2,4,8,16,32,16,8,256,48,267,309,261,268,1,1,262,16,17,266,0,27,33,17,2,268,16,309,17,261,16,15,32,257,33,1,49]

theorem envBound24146 : H12AffineFastState.Bounded env24146 := by
  intro p hp
  have h : env24146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24145_24146 : H12AffineEnvironment.transform 10 309 env24145 = env24146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env24145 == env24146) = true)

theorem identity24146 : scanCanonicalize (H12AffineFastState.compose env24146 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound24146 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24147 : List Nat := [2,4,8,16,32,16,8,52,48,63,1,49,56,1,1,50,16,17,62,0,27,33,17,2,56,16,1,17,49,16,15,32,53,33,1,49]

theorem envBound24147 : H12AffineFastState.Bounded env24147 := by
  intro p hp
  have h : env24147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24146_24147 : H12AffineEnvironment.transform 7 52 env24146 = env24147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env24146 == env24147) = true)

theorem identity24147 : scanCanonicalize (H12AffineFastState.compose env24147 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound24147 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24148 : List Nat := [2,3,8,16,32,16,8,51,48,56,1,49,56,1,1,50,16,17,57,0,27,33,17,2,56,16,1,17,49,16,8,32,50,33,1,49]

theorem envBound24148 : H12AffineFastState.Bounded env24148 := by
  intro p hp
  have h : env24148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24147_24148 : H12AffineEnvironment.transform 1 3 env24147 = env24148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env24147 == env24148) = true)

theorem identity24148 : scanCanonicalize (H12AffineFastState.compose env24148 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24148 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env24149 : List Nat := [2,3,8,16,0,16,8,19,16,24,1,17,24,1,1,18,16,17,25,0,27,1,17,2,24,16,1,17,17,16,8,0,18,1,1,17]

theorem envBound24149 : H12AffineFastState.Bounded env24149 := by
  intro p hp
  have h : env24149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24148_24149 : H12AffineEnvironment.transform 4 0 env24148 = env24149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24148 == env24149) = true)

def env24150 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,2114865,2155533,2114835,8328,16,2442546,115103,45325,2376976,75022,2188722,257,2188722,2196502,649]

theorem envBound24150 : H12AffineFastState.Bounded env24150 := by
  intro p hp
  have h : env24150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24134_24150 : H12AffineEnvironment.transform 21 2114865 env24134 = env24150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114865 env24134 == env24150) = true)

theorem identity24150 : scanCanonicalize (H12AffineFastState.compose env24150 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24150 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24151 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,2114865,2155533,2114835,8192,16,2442546,114967,45325,2376976,75022,2188602,257,2188602,2196502,513]

theorem envBound24151 : H12AffineFastState.Bounded env24151 := by
  intro p hp
  have h : env24151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24150_24151 : H12AffineEnvironment.transform 6 8 env24150 = env24151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24150 == env24151) = true)

theorem identity24151 : scanCanonicalize (H12AffineFastState.compose env24151 (packedSelected [0,7,16,19,21,26] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound24151 : packedSelected [0,7,16,19,21,26] rootPS < 2^1333 := by decide +kernel

def env24152 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,58396,41261,17,41231,8192,16,368942,114967,45325,303372,75022,98598,257,98598,90122,513]

theorem envBound24152 : H12AffineFastState.Bounded env24152 := by
  intro p hp
  have h : env24152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24151_24152 : H12AffineEnvironment.transform 20 58396 env24151 = env24152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env24151 == env24152) = true)

theorem identity24152 : scanCanonicalize (H12AffineFastState.compose env24152 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24152 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24153 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,58396,41261,17,41231,8192,16,100614,114967,45325,35108,75022,98598,257,98598,90122,513]

theorem envBound24153 : H12AffineFastState.Bounded env24153 := by
  intro p hp
  have h : env24153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24152_24153 : H12AffineEnvironment.transform 17 10280 env24152 = env24153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24152 == env24153) = true)

theorem identity24153 : scanCanonicalize (H12AffineFastState.compose env24153 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound24153 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env24154 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,24861,10280,1025,32769,58396,41261,17,41231,8192,16,10509,24860,45325,35108,34053,8493,257,8493,49153,513]

theorem envBound24154 : H12AffineFastState.Bounded env24154 := by
  intro p hp
  have h : env24154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24153_24154 : H12AffineEnvironment.transform 15 40971 env24153 = env24154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env24153 == env24154) = true)

theorem identity24154 : scanCanonicalize (H12AffineFastState.compose env24154 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound24154 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24155 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,263,24861,10280,1025,8461,17680,33,17,3,8192,16,10509,24860,4097,10280,9225,8493,257,8493,24845,513]

theorem envBound24155 : H12AffineFastState.Bounded env24155 := by
  intro p hp
  have h : env24155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24154_24155 : H12AffineEnvironment.transform 14 8460 env24154 = env24155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env24154 == env24155) = true)

theorem identity24155 : scanCanonicalize (H12AffineFastState.compose env24155 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound24155 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env24156 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,8192,16384,8460,263,24861,10280,1025,8461,17680,33,17,3,8192,16,10509,24860,1588,10280,9225,8493,257,8493,24845,513]

theorem envBound24156 : H12AffineFastState.Bounded env24156 := by
  intro p hp
  have h : env24156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24155_24156 : H12AffineEnvironment.transform 11 1589 env24155 = env24156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env24155 == env24156) = true)

theorem identity24156 : scanCanonicalize (H12AffineFastState.compose env24156 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound24156 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env24157 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,8192,10508,8460,263,2065,10280,1025,8461,11292,33,17,3,8192,16,10509,2064,1588,10280,9225,8493,257,8493,2049,513]

theorem envBound24157 : H12AffineFastState.Bounded env24157 := by
  intro p hp
  have h : env24157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24156_24157 : H12AffineEnvironment.transform 13 10508 env24156 = env24157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env24156 == env24157) = true)

theorem identity24157 : scanCanonicalize (H12AffineFastState.compose env24157 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1036) := by decide +kernel

theorem selectedBound24157 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24158 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,1036,3328,1280,263,2065,3108,1025,1281,2064,33,17,3,1036,16,3329,2064,1588,3108,5,1313,257,1313,2049,513]

theorem envBound24158 : H12AffineFastState.Bounded env24158 := by
  intro p hp
  have h : env24158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24157_24158 : H12AffineEnvironment.transform 12 1036 env24157 = env24158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1036 env24157 == env24158) = true)

theorem identity24158 : scanCanonicalize (H12AffineFastState.compose env24158 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound24158 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24159 : List Nat := [2,4,8,16,32,16,8,256,308,1024,2048,1281,1036,3328,1280,263,2065,3108,1025,1281,2064,33,17,3,1036,16,3329,2064,1280,3108,5,1313,257,1313,2049,309]

theorem envBound24159 : H12AffineFastState.Bounded env24159 := by
  intro p hp
  have h : env24159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24158_24159 : H12AffineEnvironment.transform 8 308 env24158 = env24159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env24158 == env24159) = true)

theorem identity24159 : scanCanonicalize (H12AffineFastState.compose env24159 (packedSelected [1,5,14] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound24159 : packedSelected [1,5,14] rootPS < 2^1333 := by decide +kernel

def env24160 : List Nat := [2,4,8,16,32,16,8,256,308,257,2048,0,269,2049,1,263,2065,2341,256,0,2064,33,17,3,269,16,2048,2064,1,2341,5,32,257,32,2049,309]

theorem envBound24160 : H12AffineFastState.Bounded env24160 := by
  intro p hp
  have h : env24160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24159_24160 : H12AffineEnvironment.transform 9 257 env24159 = env24160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env24159 == env24160) = true)

theorem identity24160 : scanCanonicalize (H12AffineFastState.compose env24160 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24160 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24161 : List Nat := [2,4,8,16,17,16,8,256,261,257,2048,0,269,2049,1,263,2065,2324,256,0,2064,16,17,3,269,16,2048,2064,1,2324,5,17,257,17,2049,260]

theorem envBound24161 : H12AffineFastState.Bounded env24161 := by
  intro p hp
  have h : env24161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24160_24161 : H12AffineEnvironment.transform 4 17 env24160 = env24161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24160 == env24161) = true)

theorem identity24161 : scanCanonicalize (H12AffineFastState.compose env24161 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24161 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24162 : List Nat := [2,4,8,1,0,1,8,256,261,257,2048,0,269,2049,1,263,2048,2309,256,0,2049,1,0,3,269,1,2048,2049,1,2309,5,0,257,0,2049,260]

theorem envBound24162 : H12AffineFastState.Bounded env24162 := by
  intro p hp
  have h : env24162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24161_24162 : H12AffineEnvironment.transform 3 1 env24161 = env24162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24161 == env24162) = true)

theorem identity24162 : scanCanonicalize (H12AffineFastState.compose env24162 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24163 : List Nat := [2,4,8,1,0,1,8,256,261,257,1,0,269,0,1,263,1,260,256,0,0,1,0,3,269,1,1,0,1,260,5,0,257,0,0,260]

theorem envBound24163 : H12AffineFastState.Bounded env24163 := by
  intro p hp
  have h : env24163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24162_24163 : H12AffineEnvironment.transform 10 1 env24162 = env24163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24162 == env24163) = true)

theorem identity24163 : scanCanonicalize (H12AffineFastState.compose env24163 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24163 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24164 : List Nat := [2,4,2,1,0,1,2,256,261,257,1,0,263,0,1,263,1,260,256,0,0,1,0,3,263,1,1,0,1,260,5,0,257,0,0,260]

theorem envBound24164 : H12AffineFastState.Bounded env24164 := by
  intro p hp
  have h : env24164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24163_24164 : H12AffineEnvironment.transform 2 2 env24163 = env24164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24163 == env24164) = true)

theorem identity24164 : scanCanonicalize (H12AffineFastState.compose env24164 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24164 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24165 : List Nat := [2,4,2,1,0,1,2,5,0,4,1,0,2,0,1,2,1,1,5,0,0,1,0,3,2,1,1,0,1,1,5,0,4,0,0,1]

theorem envBound24165 : H12AffineFastState.Bounded env24165 := by
  intro p hp
  have h : env24165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24164_24165 : H12AffineEnvironment.transform 7 5 env24164 = env24165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24164 == env24165) = true)

def env24166 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114834,8328,17,15066126,115102,10507521,8691996,10600706,4268163,257,8487358,8478746,10544772]

theorem envBound24166 : H12AffineFastState.Bounded env24166 := by
  intro p hp
  have h : env24166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24132_24166 : H12AffineEnvironment.transform 5 17 env24132 = env24166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24132 == env24166) = true)

theorem identity24166 : scanCanonicalize (H12AffineFastState.compose env24166 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2411557) := by decide +kernel

theorem selectedBound24166 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env24167 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2411557,2114834,8328,17,4270123,115102,301348,2125113,331047,4268163,257,2444699,2468927,273057]

theorem envBound24167 : H12AffineFastState.Bounded env24167 := by
  intro p hp
  have h : env24167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24166_24167 : H12AffineEnvironment.transform 22 2411557 env24166 = env24167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2411557 env24166 == env24167) = true)

def env24168 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,32,2411557,2114834,8328,17,75787,115102,301348,2125113,331047,73891,257,2444699,2468927,273057]

theorem envBound24168 : H12AffineFastState.Bounded env24168 := by
  intro p hp
  have h : env24168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24167_24168 : H12AffineEnvironment.transform 21 32 env24167 = env24168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env24167 == env24168) = true)

theorem identity24168 : scanCanonicalize (H12AffineFastState.compose env24168 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound24168 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env24169 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,67754,1025,32769,2097152,32,2213007,2114834,8328,17,75787,115102,102798,2125113,1421,73891,257,2114865,2139285,74251]

theorem envBound24169 : H12AffineFastState.Bounded env24169 := by
  intro p hp
  have h : env24169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24168_24169 : H12AffineEnvironment.transform 17 67754 env24168 = env24169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env24168 == env24169) = true)

theorem identity24169 : scanCanonicalize (H12AffineFastState.compose env24169 (packedSelected [16,17,19,20,21,26] rootPS)) = affineNative (2^(20+1) ^^^ 50584) := by decide +kernel

theorem selectedBound24169 : packedSelected [16,17,19,20,21,26] rootPS < 2^1333 := by decide +kernel

def env24170 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,67754,1025,32769,50584,32,65815,32906,8328,17,75787,115102,102798,43169,1421,73891,257,32937,24845,74251]

theorem envBound24170 : H12AffineFastState.Bounded env24170 := by
  intro p hp
  have h : env24170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24169_24170 : H12AffineEnvironment.transform 20 50584 env24169 = env24170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50584 env24169 == env24170) = true)

theorem identity24170 : scanCanonicalize (H12AffineFastState.compose env24170 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound24170 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env24171 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40971,24860,43169,1025,32769,50584,32,41244,32906,8328,17,34816,24981,12677,43169,1421,32936,257,32937,24845,33280]

theorem envBound24171 : H12AffineFastState.Bounded env24171 := by
  intro p hp
  have h : env24171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24170_24171 : H12AffineEnvironment.transform 15 40971 env24170 = env24171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env24170 == env24171) = true)

theorem identity24171 : scanCanonicalize (H12AffineFastState.compose env24171 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound24171 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24172 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,33166,16537,35108,1025,32769,50584,32,32921,32906,269,17,34816,16400,4096,35108,1421,32936,257,32937,16520,33280]

theorem envBound24172 : H12AffineFastState.Bounded env24172 := by
  intro p hp
  have h : env24172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24171_24172 : H12AffineEnvironment.transform 12 389 env24171 = env24172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env24171 == env24172) = true)

theorem identity24172 : scanCanonicalize (H12AffineFastState.compose env24172 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound24172 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env24173 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,16384,32768,32802,16537,34952,1025,32769,50228,32,32921,32906,161,17,34816,16400,4096,34952,1057,32936,173,32937,16520,33280]

theorem envBound24173 : H12AffineFastState.Bounded env24173 := by
  intro p hp
  have h : env24173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24172_24173 : H12AffineEnvironment.transform 7 172 env24172 = env24173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env24172 == env24173) = true)

theorem identity24173 : scanCanonicalize (H12AffineFastState.compose env24173 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound24173 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24174 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,16384,137,171,16537,2049,1025,136,17597,32,16,3,161,17,2185,16400,4096,2049,1057,33,173,32,16520,649]

theorem envBound24174 : H12AffineFastState.Bounded env24174 := by
  intro p hp
  have h : env24174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24173_24174 : H12AffineEnvironment.transform 14 137 env24173 = env24174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env24173 == env24174) = true)

theorem identity24174 : scanCanonicalize (H12AffineFastState.compose env24174 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound24174 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env24175 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,5156,137,171,5309,2049,1025,136,4249,32,16,3,161,17,2185,5172,4096,2049,1057,33,173,32,5292,649]

theorem envBound24175 : H12AffineFastState.Bounded env24175 := by
  intro p hp
  have h : env24175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24174_24175 : H12AffineEnvironment.transform 13 5156 env24174 = env24175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env24174 == env24175) = true)

theorem identity24175 : scanCanonicalize (H12AffineFastState.compose env24175 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24175 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env24176 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,0,34,5172,2049,1025,1,4112,32,16,3,40,17,2048,5172,4096,2049,1057,33,36,32,5157,512]

theorem envBound24176 : H12AffineFastState.Bounded env24176 := by
  intro p hp
  have h : env24176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24175_24176 : H12AffineEnvironment.transform 6 9 env24175 = env24176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24175 == env24176) = true)

theorem identity24176 : scanCanonicalize (H12AffineFastState.compose env24176 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24177 : List Nat := [2,4,8,16,32,17,9,37,512,20,2048,4096,41,4144,0,34,4128,2049,21,1,4112,32,16,3,40,17,2048,4128,4096,2049,53,33,36,32,4145,512]

theorem envBound24177 : H12AffineFastState.Bounded env24177 := by
  intro p hp
  have h : env24177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24176_24177 : H12AffineEnvironment.transform 9 20 env24176 = env24177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24176 == env24177) = true)

def env24178 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,33,2411557,2114834,8328,17,75786,115102,301348,2125113,331047,73890,257,2444699,2468927,273057]

theorem envBound24178 : H12AffineFastState.Bounded env24178 := by
  intro p hp
  have h : env24178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24167_24178 : H12AffineEnvironment.transform 21 33 env24167 = env24178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env24167 == env24178) = true)

theorem identity24178 : scanCanonicalize (H12AffineFastState.compose env24178 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24178 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env24179 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,65536,24860,262144,1025,1,2097152,33,2378789,2114834,8328,17,75786,82334,268580,2125113,331047,73890,257,2444699,2436159,273057]

theorem envBound24179 : H12AffineFastState.Bounded env24179 := by
  intro p hp
  have h : env24179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24178_24179 : H12AffineEnvironment.transform 14 0 env24178 = env24179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24178 == env24179) = true)

theorem identity24179 : scanCanonicalize (H12AffineFastState.compose env24179 (packedSelected [0,4,5,7,9,10,12,16,18,24] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound24179 : packedSelected [0,4,5,7,9,10,12,16,18,24] rootPS < 2^1333 := by decide +kernel

def env24180 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,65536,24860,67755,1025,1,2097152,33,2180238,2114834,8328,17,75786,82334,70031,2125113,1420,73890,257,2114864,2106516,74250]

theorem envBound24180 : H12AffineFastState.Bounded env24180 := by
  intro p hp
  have h : env24180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24179_24180 : H12AffineEnvironment.transform 17 67755 env24179 = env24180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env24179 == env24180) = true)

theorem identity24180 : scanCanonicalize (H12AffineFastState.compose env24180 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24180 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env24181 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,0,65536,16401,67755,1025,1,2097152,33,2180238,2114834,389,17,67847,82334,70031,2116660,1420,65967,257,2114864,2098585,66311]

theorem envBound24181 : H12AffineFastState.Bounded env24181 := by
  intro p hp
  have h : env24181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24180_24181 : H12AffineEnvironment.transform 12 269 env24180 = env24181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24180 == env24181) = true)

theorem identity24181 : scanCanonicalize (H12AffineFastState.compose env24181 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24181 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env24182 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,65536,16401,67618,1025,1,2097152,33,2180103,2114834,268,17,67847,82199,69894,2116660,1285,65830,257,2114864,2098448,66311]

theorem envBound24182 : H12AffineFastState.Bounded env24182 := by
  intro p hp
  have h : env24182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24181_24182 : H12AffineEnvironment.transform 6 9 env24181 = env24182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24181 == env24182) = true)

theorem identity24182 : scanCanonicalize (H12AffineFastState.compose env24182 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 4404) := by decide +kernel

theorem selectedBound24182 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24183 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,65536,16401,67618,1025,1,4404,33,87347,21542,268,17,67847,82199,69894,23808,1285,65830,257,21508,5156,66311]

theorem envBound24183 : H12AffineFastState.Bounded env24183 := by
  intro p hp
  have h : env24183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24182_24183 : H12AffineEnvironment.transform 20 4404 env24182 = env24183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4404 env24182 == env24183) = true)

theorem identity24183 : scanCanonicalize (H12AffineFastState.compose env24183 (packedSelected [1,3,5,6,7,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24183 : packedSelected [1,3,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env24184 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1025,1,4404,33,21556,21542,268,17,2048,16400,4097,23808,1285,33,257,21508,5156,512]

theorem envBound24184 : H12AffineFastState.Bounded env24184 := by
  intro p hp
  have h : env24184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24183_24184 : H12AffineEnvironment.transform 15 263 env24183 = env24184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24183 == env24184) = true)

theorem identity24184 : scanCanonicalize (H12AffineFastState.compose env24184 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound24184 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24185 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5124,0,263,5141,2341,1025,1,4404,33,48,34,268,17,2048,5140,4097,2308,1285,33,257,0,5156,512]

theorem envBound24185 : H12AffineFastState.Bounded env24185 := by
  intro p hp
  have h : env24185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24184_24185 : H12AffineEnvironment.transform 13 5124 env24184 = env24185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env24184 == env24185) = true)

theorem identity24185 : scanCanonicalize (H12AffineFastState.compose env24185 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24185 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24186 : List Nat := [2,4,8,16,32,17,9,256,512,21,2048,4096,269,4113,0,263,4096,2341,20,1,4404,33,48,34,268,17,2048,4097,4097,2308,272,33,257,0,4145,512]

theorem envBound24186 : H12AffineFastState.Bounded env24186 := by
  intro p hp
  have h : env24186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24185_24186 : H12AffineEnvironment.transform 9 21 env24185 = env24186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24185 == env24186) = true)

theorem identity24186 : scanCanonicalize (H12AffineFastState.compose env24186 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24186 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env24187 : List Nat := [2,4,8,16,1,17,9,256,512,21,2048,4096,269,4113,0,263,4096,2308,20,1,4373,0,17,3,268,17,2048,4097,4097,2308,272,0,257,0,4112,512]

theorem envBound24187 : H12AffineFastState.Bounded env24187 := by
  intro p hp
  have h : env24187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24186_24187 : H12AffineEnvironment.transform 4 1 env24186 = env24187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24186 == env24187) = true)

theorem identity24187 : scanCanonicalize (H12AffineFastState.compose env24187 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound24187 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24188 : List Nat := [2,4,8,16,1,17,9,256,512,21,4,4096,269,4113,0,263,4096,256,20,1,4373,0,17,3,268,17,4,4097,4097,256,272,0,257,0,4112,512]

theorem envBound24188 : H12AffineFastState.Bounded env24188 := by
  intro p hp
  have h : env24188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24187_24188 : H12AffineEnvironment.transform 10 4 env24187 = env24188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env24187 == env24188) = true)

theorem identity24188 : scanCanonicalize (H12AffineFastState.compose env24188 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24189 : List Nat := [2,4,8,16,1,17,9,256,512,21,4,17,269,0,0,263,17,256,20,1,260,0,17,3,268,17,4,16,16,256,272,0,257,0,1,512]

theorem envBound24189 : H12AffineFastState.Bounded env24189 := by
  intro p hp
  have h : env24189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24188_24189 : H12AffineEnvironment.transform 11 17 env24188 = env24189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24188 == env24189) = true)

def env24190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound24190 : H12AffineFastState.Bounded env24190 := by
  intro p hp
  have h : env24190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23536_24190 : H12AffineEnvironment.transform 25 65 env23536 = env24190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env23536 == env24190) = true)

def env24191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound24191 : H12AffineFastState.Bounded env24191 := by
  intro p hp
  have h : env24191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24190_24191 : H12AffineEnvironment.transform 26 30393344 env24190 = env24191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env24190 == env24191) = true)

def env24192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound24192 : H12AffineFastState.Bounded env24192 := by
  intro p hp
  have h : env24192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24191_24192 : H12AffineEnvironment.transform 18 1024 env24191 = env24192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env24191 == env24192) = true)

theorem identity24192 : scanCanonicalize (H12AffineFastState.compose env24192 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound24192 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403503,18973837,10507601,8497519,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound24193 : H12AffineFastState.Bounded env24193 := by
  intro p hp
  have h : env24193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24192_24193 : H12AffineEnvironment.transform 17 223599 env24192 = env24193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env24192 == env24193) = true)

def env24194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760179,5393,10507601,8497519,10491277,4256861,256,8410416,8434836,10564186]

theorem envBound24194 : H12AffineFastState.Bounded env24194 := by
  intro p hp
  have h : env24194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24193_24194 : H12AffineEnvironment.transform 23 2199964 env24193 = env24194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env24193 == env24194) = true)

def env24195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270243,5393,17665,2210111,1501,4256861,256,2114912,2139332,74250]

theorem envBound24195 : H12AffineFastState.Bounded env24195 := by
  intro p hp
  have h : env24195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24194_24195 : H12AffineEnvironment.transform 22 2101328 env24194 = env24195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env24194 == env24195) = true)

def env24196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,16,98780,8328,65,4270243,5393,17665,108927,1501,4256861,256,21792,46212,74250]

theorem envBound24196 : H12AffineFastState.Bounded env24196 := by
  intro p hp
  have h : env24196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24195_24196 : H12AffineEnvironment.transform 20 4160 env24195 = env24196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24195 == env24196) = true)

theorem identity24196 : scanCanonicalize (H12AffineFastState.compose env24196 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24196 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,223599,1024,29908,4160,4194304,16,95497,8328,65,4270243,5393,17665,89514,1501,4194440,256,21792,16465,74250]

theorem envBound24197 : H12AffineFastState.Bounded env24197 := by
  intro p hp
  have h : env24197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24196_24197 : H12AffineEnvironment.transform 14 29909 env24196 = env24197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24196 == env24197) = true)

def env24198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212079,1024,8660,4160,4194304,16,73737,8328,65,4270243,5393,4097,67754,1501,4194440,256,32,5457,74250]

theorem envBound24198 : H12AffineFastState.Bounded env24198 := by
  intro p hp
  have h : env24198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24197_24198 : H12AffineEnvironment.transform 13 5376 env24197 = env24198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24197 == env24198) = true)

theorem identity24198 : scanCanonicalize (H12AffineFastState.compose env24198 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound24198 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,67755,1024,8660,4160,4194304,16,73737,8328,65,4270243,5393,4097,67754,1501,4194440,256,32,5457,74250]

theorem envBound24199 : H12AffineFastState.Bounded env24199 := by
  intro p hp
  have h : env24199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24198_24199 : H12AffineEnvironment.transform 16 13508 env24198 = env24199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env24198 == env24199) = true)

theorem identity24199 : scanCanonicalize (H12AffineFastState.compose env24199 (packedSelected [0,2,3,4,5,6,9,10,16,27] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound24199 : packedSelected [0,2,3,4,5,6,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env24200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,67755,1024,8660,4160,73891,16,73737,8328,65,2048,5393,4097,67754,1501,73771,256,32,5457,74250]

theorem envBound24200 : H12AffineFastState.Bounded env24200 := by
  intro p hp
  have h : env24200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24199_24200 : H12AffineEnvironment.transform 21 73891 env24199 = env24200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env24199 == env24200) = true)

theorem identity24200 : scanCanonicalize (H12AffineFastState.compose env24200 (packedSelected [1,8,9,10,11,15,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8402) := by decide +kernel

theorem selectedBound24200 : packedSelected [1,8,9,10,11,15,20,22] rootPS < 2^1333 := by decide +kernel

def env24201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8402,13508,10361,1024,8660,4160,113,16,219,8328,65,2048,5393,4097,10360,1501,249,256,32,5457,728]

theorem envBound24201 : H12AffineFastState.Bounded env24201 := by
  intro p hp
  have h : env24201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24200_24201 : H12AffineEnvironment.transform 15 8402 env24200 = env24201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8402 env24200 == env24201) = true)

theorem identity24201 : scanCanonicalize (H12AffineFastState.compose env24201 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24201 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env24202 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10361,1024,8460,4160,113,16,3,8272,65,2048,5393,4097,10360,1285,33,256,32,5457,512]

theorem envBound24202 : H12AffineFastState.Bounded env24202 := by
  intro p hp
  have h : env24202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24201_24202 : H12AffineEnvironment.transform 6 88 env24201 = env24202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24201 == env24202) = true)

theorem identity24202 : scanCanonicalize (H12AffineFastState.compose env24202 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound24202 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24203 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,381,5376,112,375,5473,2308,1024,113,4160,113,16,3,301,65,2048,5393,4097,2309,1285,33,256,32,5457,512]

theorem envBound24203 : H12AffineFastState.Bounded env24203 := by
  intro p hp
  have h : env24203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24202_24203 : H12AffineEnvironment.transform 12 381 env24202 = env24203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env24202 == env24203) = true)

theorem identity24203 : scanCanonicalize (H12AffineFastState.compose env24203 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound24203 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env24204 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2405,381,3173,112,375,3076,2308,1024,113,2341,113,16,3,301,65,2048,3188,2404,2309,1285,33,256,32,3124,512]

theorem envBound24204 : H12AffineFastState.Bounded env24204 := by
  intro p hp
  have h : env24204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24203_24204 : H12AffineEnvironment.transform 11 2405 env24203 = env24204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env24203 == env24204) = true)

theorem identity24204 : scanCanonicalize (H12AffineFastState.compose env24204 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24204 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env24205 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,2324,268,3092,1,262,3076,2308,1024,0,2341,0,16,3,301,48,2048,3077,2325,2309,1285,33,256,32,3124,512]

theorem envBound24205 : H12AffineFastState.Bounded env24205 := by
  intro p hp
  have h : env24205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24204_24205 : H12AffineEnvironment.transform 5 49 env24204 = env24205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24204 == env24205) = true)

theorem identity24205 : scanCanonicalize (H12AffineFastState.compose env24205 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24205 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24206 : List Nat := [2,4,8,16,32,49,41,256,512,52,2048,2324,268,2080,1,262,2096,2308,52,0,2341,0,16,3,301,48,2048,2097,2325,2309,305,33,256,32,2048,512]

theorem envBound24206 : H12AffineFastState.Bounded env24206 := by
  intro p hp
  have h : env24206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24205_24206 : H12AffineEnvironment.transform 9 52 env24205 = env24206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24205 == env24206) = true)

theorem identity24206 : scanCanonicalize (H12AffineFastState.compose env24206 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24206 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env24207 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,2096,40,2080,1,34,2096,2080,52,0,2049,0,16,3,9,48,2048,2097,2097,2081,21,33,36,32,2048,512]

theorem envBound24207 : H12AffineFastState.Bounded env24207 := by
  intro p hp
  have h : env24207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24206_24207 : H12AffineEnvironment.transform 7 36 env24206 = env24207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24206 == env24207) = true)

theorem identity24207 : scanCanonicalize (H12AffineFastState.compose env24207 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24207 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24208 : List Nat := [2,4,8,16,32,49,41,36,512,52,1,49,40,33,1,34,49,33,52,0,0,0,16,3,9,48,1,48,48,32,21,33,36,32,1,512]

theorem envBound24208 : H12AffineFastState.Bounded env24208 := by
  intro p hp
  have h : env24208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24207_24208 : H12AffineEnvironment.transform 10 1 env24207 = env24208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24207 == env24208) = true)

theorem identity24208 : scanCanonicalize (H12AffineFastState.compose env24208 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24209 : List Nat := [2,4,8,16,32,49,41,36,1,52,1,49,40,33,1,34,49,33,52,0,0,0,16,3,9,48,1,48,48,32,21,33,36,32,1,1]

theorem envBound24209 : H12AffineFastState.Bounded env24209 := by
  intro p hp
  have h : env24209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24208_24209 : H12AffineEnvironment.transform 8 1 env24208 = env24209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24208 == env24209) = true)

def env24210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212078,1024,8661,4160,4194304,16,73736,8328,65,4270243,5393,4096,67755,1501,4194440,256,33,5456,74250]

theorem envBound24210 : H12AffineFastState.Bounded env24210 := by
  intro p hp
  have h : env24210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24197_24210 : H12AffineEnvironment.transform 13 5377 env24197 = env24210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24197 == env24210) = true)

theorem identity24210 : scanCanonicalize (H12AffineFastState.compose env24210 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound24210 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,67619,1024,8661,4160,4194304,16,73736,8328,65,4270243,5393,4096,67755,1501,4194440,256,33,5456,74250]

theorem envBound24211 : H12AffineFastState.Bounded env24211 := by
  intro p hp
  have h : env24211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24210_24211 : H12AffineEnvironment.transform 16 13389 env24210 = env24211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env24210 == env24211) = true)

theorem identity24211 : scanCanonicalize (H12AffineFastState.compose env24211 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24211 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13389,10280,1024,8661,4160,4194304,16,3,8328,65,4196520,5393,4096,10400,1501,4194440,256,33,5456,513]

theorem envBound24212 : H12AffineFastState.Bounded env24212 := by
  intro p hp
  have h : env24212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24211_24212 : H12AffineEnvironment.transform 15 8203 env24211 = env24212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24211 == env24212) = true)

theorem identity24212 : scanCanonicalize (H12AffineFastState.compose env24212 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound24212 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13389,10280,1024,8661,4160,112,16,3,8328,65,2264,5393,4096,10400,1501,248,256,33,5456,513]

theorem envBound24213 : H12AffineFastState.Bounded env24213 := by
  intro p hp
  have h : env24213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24212_24213 : H12AffineEnvironment.transform 21 112 env24212 = env24213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env24212 == env24213) = true)

theorem identity24213 : scanCanonicalize (H12AffineFastState.compose env24213 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24213 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env24214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,343,5393,2420,1024,137,4160,112,16,3,468,65,2264,5393,4096,2556,1501,248,256,33,5456,513]

theorem envBound24214 : H12AffineFastState.Bounded env24214 := by
  intro p hp
  have h : env24214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24213_24214 : H12AffineEnvironment.transform 12 348 env24213 = env24214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24213 == env24214) = true)

def env24215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,17,98781,8328,65,4270243,5393,17665,108926,1501,4256861,256,21793,46213,74250]

theorem envBound24215 : H12AffineFastState.Bounded env24215 := by
  intro p hp
  have h : env24215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24195_24215 : H12AffineEnvironment.transform 20 4161 env24195 = env24215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24195 == env24215) = true)

theorem identity24215 : scanCanonicalize (H12AffineFastState.compose env24215 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound24215 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,156133,17,98781,8328,65,215366,5393,17665,108926,1501,169400,256,21793,46213,74250]

theorem envBound24216 : H12AffineFastState.Bounded env24216 := by
  intro p hp
  have h : env24216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24215_24216 : H12AffineEnvironment.transform 21 156133 env24215 = env24216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env24215 == env24216) = true)

theorem identity24216 : scanCanonicalize (H12AffineFastState.compose env24216 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24216 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env24217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,2421,1024,32769,4161,66047,17,98781,8328,65,10588,5393,17665,108926,1501,128418,256,21793,46213,74250]

theorem envBound24217 : H12AffineFastState.Bounded env24217 := by
  intro p hp
  have h : env24217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24216_24217 : H12AffineEnvironment.transform 16 90138 env24216 = env24217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24216 == env24217) = true)

theorem identity24217 : scanCanonicalize (H12AffineFastState.compose env24217 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24217 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env24218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,2421,1024,29908,4161,66047,17,95496,8328,65,10588,5393,17665,89515,1501,65911,256,21793,16464,74250]

theorem envBound24218 : H12AffineFastState.Bounded env24218 := by
  intro p hp
  have h : env24218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24217_24218 : H12AffineEnvironment.transform 14 29909 env24217 = env24218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24217 == env24218) = true)

theorem identity24218 : scanCanonicalize (H12AffineFastState.compose env24218 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24218 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env24219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16401,2421,1024,29908,4161,8692,17,21763,8328,65,10588,5393,17665,32160,1501,8572,256,21793,16464,513]

theorem envBound24219 : H12AffineFastState.Bounded env24219 := by
  intro p hp
  have h : env24219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24218_24219 : H12AffineEnvironment.transform 15 8203 env24218 = env24219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24218 == env24219) = true)

def env24220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270242,5393,17664,2210110,1500,4256861,256,2114913,2139333,74251]

theorem envBound24220 : H12AffineFastState.Bounded env24220 := by
  intro p hp
  have h : env24220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24194_24220 : H12AffineEnvironment.transform 22 2101329 env24194 = env24220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env24194 == env24220) = true)

def env24221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,17,98780,8328,65,4270242,5393,17664,108926,1500,4256861,256,21793,46213,74251]

theorem envBound24221 : H12AffineFastState.Bounded env24221 := by
  intro p hp
  have h : env24221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24220_24221 : H12AffineEnvironment.transform 20 4160 env24220 = env24221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24220 == env24221) = true)

theorem identity24221 : scanCanonicalize (H12AffineFastState.compose env24221 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound24221 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169264,17,98780,8328,65,245138,5393,17664,108926,1500,156013,256,21793,46213,74251]

theorem envBound24222 : H12AffineFastState.Bounded env24222 := by
  intro p hp
  have h : env24222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24221_24222 : H12AffineEnvironment.transform 21 169264 env24221 = env24222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env24221 == env24222) = true)

def env24223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169264,17,98644,8192,65,245018,5393,17664,108926,1364,156013,256,21793,46093,74251]

theorem envBound24223 : H12AffineFastState.Bounded env24223 := by
  intro p hp
  have h : env24223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24222_24223 : H12AffineEnvironment.transform 6 8 env24222 = env24223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24222 == env24223) = true)

theorem identity24223 : scanCanonicalize (H12AffineFastState.compose env24223 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24223 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,169264,17,41310,8192,65,171280,5393,17664,35188,1364,156013,256,21793,46093,513]

theorem envBound24224 : H12AffineFastState.Bounded env24224 := by
  intro p hp
  have h : env24224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24223_24224 : H12AffineEnvironment.transform 15 8202 env24223 = env24224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24223 == env24224) = true)

theorem identity24224 : scanCanonicalize (H12AffineFastState.compose env24224 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24224 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4160,54561,17,41310,8192,65,56577,5393,17664,35188,1364,8572,256,21793,46093,513]

theorem envBound24225 : H12AffineFastState.Bounded env24225 := by
  intro p hp
  have h : env24225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24224_24225 : H12AffineEnvironment.transform 16 16401 env24224 = env24225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24224 == env24225) = true)

theorem identity24225 : scanCanonicalize (H12AffineFastState.compose env24225 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound24225 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2420,1024,8540,4160,29820,17,3,8192,65,31836,5393,17664,10281,1364,8572,256,21793,5456,513]

theorem envBound24226 : H12AffineFastState.Bounded env24226 := by
  intro p hp
  have h : env24226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24225_24226 : H12AffineEnvironment.transform 14 8541 env24225 = env24226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env24225 == env24226) = true)

theorem identity24226 : scanCanonicalize (H12AffineFastState.compose env24226 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound24226 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8202,13340,2420,1024,8540,4160,113,17,3,8192,65,2129,5393,12557,10281,1364,8572,256,8492,5456,513]

theorem envBound24227 : H12AffineFastState.Bounded env24227 := by
  intro p hp
  have h : env24227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24226_24227 : H12AffineEnvironment.transform 13 13325 env24226 = env24227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env24226 == env24227) = true)

theorem identity24227 : scanCanonicalize (H12AffineFastState.compose env24227 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound24227 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env24228 : List Nat := [2,4,8,16,32,64,8,100,512,1024,2048,4096,8192,13325,8249,8202,13340,2064,1024,8248,4160,113,17,3,8192,65,2129,5237,12393,10281,1072,8216,100,8264,5172,513]

theorem envBound24228 : H12AffineFastState.Bounded env24228 := by
  intro p hp
  have h : env24228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24227_24228 : H12AffineEnvironment.transform 7 100 env24227 = env24228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env24227 == env24228) = true)

theorem identity24228 : scanCanonicalize (H12AffineFastState.compose env24228 (packedSelected [1,4,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24228 : packedSelected [1,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24229 : List Nat := [2,4,8,16,32,64,8,100,512,52,2048,4096,8192,12345,8249,8202,12328,2064,52,8248,4160,113,17,3,8192,65,2129,4161,12393,10281,4,8216,100,8264,4096,513]

theorem envBound24229 : H12AffineFastState.Bounded env24229 := by
  intro p hp
  have h : env24229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24228_24229 : H12AffineEnvironment.transform 9 52 env24228 = env24229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24228 == env24229) = true)

def env24230 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169264,17,98645,8193,65,245019,5393,17664,108926,1365,156013,256,21793,46092,74251]

theorem envBound24230 : H12AffineFastState.Bounded env24230 := by
  intro p hp
  have h : env24230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24222_24230 : H12AffineEnvironment.transform 6 9 env24222 = env24230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24222 == env24230) = true)

theorem identity24230 : scanCanonicalize (H12AffineFastState.compose env24230 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24230 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24231 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190521,1024,32769,4160,169264,17,3,8193,65,146509,5393,17664,10280,1365,156013,256,21793,46092,41821]

theorem envBound24231 : H12AffineFastState.Bounded env24231 := by
  intro p hp
  have h : env24231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24230_24231 : H12AffineEnvironment.transform 15 33110 env24230 = env24231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24230 == env24231) = true)

theorem identity24231 : scanCanonicalize (H12AffineFastState.compose env24231 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound24231 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env24232 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,46109,23588,1024,32769,4160,8493,17,3,8193,65,34896,5393,17664,10280,1365,54640,256,21793,46092,41821]

theorem envBound24232 : H12AffineFastState.Bounded env24232 := by
  intro p hp
  have h : env24232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24231_24232 : H12AffineEnvironment.transform 16 46109 env24231 = env24232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env24231 == env24232) = true)

theorem identity24232 : scanCanonicalize (H12AffineFastState.compose env24232 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound24232 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env24233 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,34,13673,23588,1024,373,4160,8493,17,3,8193,65,2340,5393,17664,10280,1365,21508,256,21793,13688,8745]

theorem envBound24233 : H12AffineFastState.Bounded env24233 := by
  intro p hp
  have h : env24233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24232_24233 : H12AffineEnvironment.transform 14 372 env24232 = env24233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env24232 == env24233) = true)

theorem identity24233 : scanCanonicalize (H12AffineFastState.compose env24233 (packedSelected [1,3,4,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24233 : packedSelected [1,3,4,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env24234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,372,34,5392,23588,1024,373,4160,340,17,3,120,65,2340,5393,17664,2129,1365,21508,256,21793,5377,592]

theorem envBound24234 : H12AffineFastState.Bounded env24234 := by
  intro p hp
  have h : env24234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24233_24234 : H12AffineEnvironment.transform 12 121 env24233 = env24234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24233 == env24234) = true)

theorem identity24234 : scanCanonicalize (H12AffineFastState.compose env24234 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound24234 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env24235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5157,372,34,5392,2049,1024,373,4160,340,17,3,120,65,2340,5393,4389,2129,1365,33,256,260,5377,592]

theorem envBound24235 : H12AffineFastState.Bounded env24235 := by
  intro p hp
  have h : env24235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24234_24235 : H12AffineEnvironment.transform 13 5157 env24234 = env24235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env24234 == env24235) = true)

theorem identity24235 : scanCanonicalize (H12AffineFastState.compose env24235 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24235 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24236 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5157,292,34,5392,2049,1024,293,4112,260,17,3,40,17,2340,5393,4389,2049,1285,33,256,260,5377,512]

theorem envBound24236 : H12AffineFastState.Bounded env24236 := by
  intro p hp
  have h : env24236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24235_24236 : H12AffineEnvironment.transform 5 16 env24235 = env24236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24235 == env24236) = true)

theorem identity24236 : scanCanonicalize (H12AffineFastState.compose env24236 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24236 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24237 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,41,5157,33,34,5141,2049,1024,32,4112,1,17,3,40,17,2081,5140,4128,2049,1024,33,5,1,5124,512]

theorem envBound24237 : H12AffineFastState.Bounded env24237 := by
  intro p hp
  have h : env24237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24236_24237 : H12AffineEnvironment.transform 7 5 env24236 = env24237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24236 == env24237) = true)

def env24238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98781,8328,65,4270242,5393,17664,108927,1500,4256861,256,21792,46212,74251]

theorem envBound24238 : H12AffineFastState.Bounded env24238 := by
  intro p hp
  have h : env24238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24220_24238 : H12AffineEnvironment.transform 20 4161 env24220 = env24238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24220 == env24238) = true)

def env24239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98645,8192,65,4270122,5393,17664,108927,1364,4256861,256,21792,46092,74251]

theorem envBound24239 : H12AffineFastState.Bounded env24239 := by
  intro p hp
  have h : env24239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24238_24239 : H12AffineEnvironment.transform 6 8 env24238 = env24239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24238 == env24239) = true)

theorem identity24239 : scanCanonicalize (H12AffineFastState.compose env24239 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound24239 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67618,1024,32769,4161,4194304,16,98645,8192,65,4270122,5393,17664,108927,1364,4256861,256,21792,46092,74251]

theorem envBound24240 : H12AffineFastState.Bounded env24240 := by
  intro p hp
  have h : env24240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24239_24240 : H12AffineEnvironment.transform 16 24909 env24239 = env24240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env24239 == env24240) = true)

theorem identity24240 : scanCanonicalize (H12AffineFastState.compose env24240 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound24240 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env24241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67618,1024,32769,4161,65911,16,98645,8192,65,10589,5393,17664,108927,1364,128298,256,21792,46092,74251]

theorem envBound24241 : H12AffineFastState.Bounded env24241 := by
  intro p hp
  have h : env24241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24240_24241 : H12AffineEnvironment.transform 21 65911 env24240 = env24241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env24240 == env24241) = true)

theorem identity24241 : scanCanonicalize (H12AffineFastState.compose env24241 (packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound24241 : packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS < 2^1333 := by decide +kernel

def env24242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24909,64808,1024,32769,4161,62589,16,29791,8192,65,10589,5393,17664,23669,1364,32,256,21792,46092,55041]

theorem envBound24242 : H12AffineFastState.Bounded env24242 := by
  intro p hp
  have h : env24242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24241_24242 : H12AffineEnvironment.transform 15 62730 env24241 = env24242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env24241 == env24242) = true)

theorem identity24242 : scanCanonicalize (H12AffineFastState.compose env24242 (packedSelected [2,5,6,10,11,12,14,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound24242 : packedSelected [2,5,6,10,11,12,14,20,24] rootPS < 2^1333 := by decide +kernel

def env24243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33030,5441,35108,1024,32769,4161,32881,16,83,8192,65,10589,5393,12556,10361,1364,32,256,8492,46092,41741]

theorem envBound24243 : H12AffineFastState.Bounded env24243 := by
  intro p hp
  have h : env24243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24242_24243 : H12AffineEnvironment.transform 13 13324 env24242 = env24243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env24242 == env24243) = true)

theorem identity24243 : scanCanonicalize (H12AffineFastState.compose env24243 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24243 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24244 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,32768,33030,5393,35108,1024,32769,4113,32801,16,3,8192,17,10509,5393,12556,10281,1284,32,256,8492,46092,41741]

theorem envBound24244 : H12AffineFastState.Bounded env24244 := by
  intro p hp
  have h : env24244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24243_24244 : H12AffineEnvironment.transform 5 16 env24243 = env24244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24243 == env24244) = true)

theorem identity24244 : scanCanonicalize (H12AffineFastState.compose env24244 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24244 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env24245 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,263,5393,2341,1024,0,4113,32,16,3,8192,17,10509,5393,12556,10281,1284,32,256,8492,13325,8972]

theorem envBound24245 : H12AffineFastState.Bounded env24245 := by
  intro p hp
  have h : env24245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24244_24245 : H12AffineEnvironment.transform 14 1 env24244 = env24245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24244 == env24245) = true)

theorem identity24245 : scanCanonicalize (H12AffineFastState.compose env24245 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound24245 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24246 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7465,2341,1,263,5393,2341,1024,0,4113,32,16,3,7465,17,5156,5393,3109,5376,1284,32,256,7173,2340,7717]

theorem envBound24246 : H12AffineFastState.Bounded env24246 := by
  intro p hp
  have h : env24246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24245_24246 : H12AffineEnvironment.transform 12 7465 env24245 = env24246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env24245 == env24246) = true)

theorem identity24246 : scanCanonicalize (H12AffineFastState.compose env24246 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound24246 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env24247 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1028,4096,4397,1313,1,263,5393,1313,1024,0,4113,32,16,3,4397,17,5156,5393,33,5376,1284,32,256,4097,1312,4641]

theorem envBound24247 : H12AffineFastState.Bounded env24247 := by
  intro p hp
  have h : env24247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24246_24247 : H12AffineEnvironment.transform 10 1028 env24246 = env24247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env24246 == env24247) = true)

def env24248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98644,8193,65,4270123,5393,17664,108927,1365,4256861,256,21792,46093,74251]

theorem envBound24248 : H12AffineFastState.Bounded env24248 := by
  intro p hp
  have h : env24248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24238_24248 : H12AffineEnvironment.transform 6 9 env24238 = env24248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24238 == env24248) = true)

theorem identity24248 : scanCanonicalize (H12AffineFastState.compose env24248 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound24248 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,108927,1024,32769,4161,4194304,16,98644,8193,65,4270123,5393,17664,108927,1365,4256861,256,21792,46093,74251]

theorem envBound24249 : H12AffineFastState.Bounded env24249 := by
  intro p hp
  have h : env24249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24248_24249 : H12AffineEnvironment.transform 16 49168 env24248 = env24249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env24248 == env24249) = true)

theorem identity24249 : scanCanonicalize (H12AffineFastState.compose env24249 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound24249 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,108927,1024,32769,4161,29741,16,98644,8193,65,89094,5393,17664,108927,1365,32880,256,21792,46093,74251]

theorem envBound24250 : H12AffineFastState.Bounded env24250 := by
  intro p hp
  have h : env24250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24249_24250 : H12AffineEnvironment.transform 21 29741 env24249 = env24250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env24249 == env24250) = true)

theorem identity24250 : scanCanonicalize (H12AffineFastState.compose env24250 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound24250 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,49168,2421,1024,32769,4161,29741,16,8542,8193,65,64524,5393,17664,2421,1365,32880,256,21792,46093,33281]

theorem envBound24251 : H12AffineFastState.Bounded env24251 := by
  intro p hp
  have h : env24251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24250_24251 : H12AffineEnvironment.transform 15 40970 env24250 = env24251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env24250 == env24251) = true)

theorem identity24251 : scanCanonicalize (H12AffineFastState.compose env24251 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24251 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,32802,49168,2421,1024,32769,4161,21509,16,374,41,65,56356,5393,17664,2421,1365,32880,256,21792,37925,33281]

theorem envBound24252 : H12AffineFastState.Bounded env24252 := by
  intro p hp
  have h : env24252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24251_24252 : H12AffineEnvironment.transform 12 40 env24251 = env24252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24251 == env24252) = true)

theorem identity24252 : scanCanonicalize (H12AffineFastState.compose env24252 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24252 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,32802,38161,2421,1024,32769,4161,260,16,374,41,65,35109,5393,4097,2421,1365,32880,256,33,37925,33281]

theorem envBound24253 : H12AffineFastState.Bounded env24253 := by
  intro p hp
  have h : env24253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24252_24253 : H12AffineEnvironment.transform 13 5377 env24252 = env24253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24252 == env24253) = true)

theorem identity24253 : scanCanonicalize (H12AffineFastState.compose env24253 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound24253 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env24254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,373,343,5220,2421,1024,372,4161,260,16,374,41,65,2128,5393,4097,2421,1365,261,256,33,5456,884]

theorem envBound24254 : H12AffineFastState.Bounded env24254 := by
  intro p hp
  have h : env24254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24253_24254 : H12AffineEnvironment.transform 14 373 env24253 = env24254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env24253 == env24254) = true)

theorem identity24254 : scanCanonicalize (H12AffineFastState.compose env24254 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24254 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env24255 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,40,4113,373,343,4468,2421,272,372,4161,260,16,374,41,65,2128,4097,4097,2421,69,261,256,33,4160,884]

theorem envBound24255 : H12AffineFastState.Bounded env24255 := by
  intro p hp
  have h : env24255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24254_24255 : H12AffineEnvironment.transform 9 272 env24254 = env24255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24254 == env24255) = true)

def env24256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760178,5392,10507601,8497519,10491276,4256860,256,8410417,8434837,10564187]

theorem envBound24256 : H12AffineFastState.Bounded env24256 := by
  intro p hp
  have h : env24256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24193_24256 : H12AffineEnvironment.transform 23 2199965 env24193 = env24256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env24193 == env24256) = true)

def env24257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270242,5392,17665,2210111,1500,4256860,256,2114913,2139333,74251]

theorem envBound24257 : H12AffineFastState.Bounded env24257 := by
  intro p hp
  have h : env24257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24256_24257 : H12AffineEnvironment.transform 22 2101328 env24256 = env24257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env24256 == env24257) = true)

def env24258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,16,98781,8328,65,4270242,5392,17665,108927,1500,4256860,256,21793,46213,74251]

theorem envBound24258 : H12AffineFastState.Bounded env24258 := by
  intro p hp
  have h : env24258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24257_24258 : H12AffineEnvironment.transform 20 4160 env24257 = env24258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24257 == env24258) = true)

theorem identity24258 : scanCanonicalize (H12AffineFastState.compose env24258 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24258 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,4194304,16,41431,8328,65,4196520,5392,17665,35189,1500,4256860,256,21793,46213,513]

theorem envBound24259 : H12AffineFastState.Bounded env24259 := by
  intro p hp
  have h : env24259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24258_24259 : H12AffineEnvironment.transform 15 8202 env24258 = env24259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24258 == env24259) = true)

theorem identity24259 : scanCanonicalize (H12AffineFastState.compose env24259 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8693) := by decide +kernel

theorem selectedBound24259 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env24260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,8693,16,41431,8328,65,10589,5392,17665,35189,1500,54697,256,21793,46213,513]

theorem envBound24260 : H12AffineFastState.Bounded env24260 := by
  intro p hp
  have h : env24260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24259_24260 : H12AffineEnvironment.transform 21 8693 env24259 = env24260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8693 env24259 == env24260) = true)

theorem identity24260 : scanCanonicalize (H12AffineFastState.compose env24260 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24260 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env24261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,8573,16,41311,8192,65,10589,5392,17665,35189,1364,54561,256,21793,46093,513]

theorem envBound24261 : H12AffineFastState.Bounded env24261 := by
  intro p hp
  have h : env24261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24260_24261 : H12AffineEnvironment.transform 6 8 env24260 = env24261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24260 == env24261) = true)

theorem identity24261 : scanCanonicalize (H12AffineFastState.compose env24261 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound24261 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24909,10280,1024,32769,4160,8573,16,41311,8192,65,10589,5392,17665,35189,1364,54561,256,21793,46093,513]

theorem envBound24262 : H12AffineFastState.Bounded env24262 := by
  intro p hp
  have h : env24262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24261_24262 : H12AffineEnvironment.transform 16 24909 env24261 = env24262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env24261 == env24262) = true)

theorem identity24262 : scanCanonicalize (H12AffineFastState.compose env24262 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound24262 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,24909,10280,1024,21760,4160,8573,16,29790,8192,65,10589,5392,17665,23668,1364,32,256,21793,24844,513]

theorem envBound24263 : H12AffineFastState.Bounded env24263 := by
  intro p hp
  have h : env24263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24262_24263 : H12AffineEnvironment.transform 14 21761 env24262 = env24263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env24262 == env24263) = true)

theorem identity24263 : scanCanonicalize (H12AffineFastState.compose env24263 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24263 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16400,2421,1024,21760,4160,32,16,21763,349,65,2048,5392,17665,23668,1364,32,256,21793,16465,513]

theorem envBound24264 : H12AffineFastState.Bounded env24264 := by
  intro p hp
  have h : env24264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24263_24264 : H12AffineEnvironment.transform 12 349 env24263 = env24264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24263 == env24264) = true)

def env24265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,17,98780,8328,65,4270242,5392,17665,108926,1500,4256860,256,21792,46212,74251]

theorem envBound24265 : H12AffineFastState.Bounded env24265 := by
  intro p hp
  have h : env24265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24257_24265 : H12AffineEnvironment.transform 20 4161 env24257 = env24265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24257 == env24265) = true)

theorem identity24265 : scanCanonicalize (H12AffineFastState.compose env24265 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243003) := by decide +kernel

theorem selectedBound24265 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243003,17,98780,8328,65,171417,5392,17665,108926,1500,213351,256,21792,46212,74251]

theorem envBound24266 : H12AffineFastState.Bounded env24266 := by
  intro p hp
  have h : env24266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24265_24266 : H12AffineEnvironment.transform 21 243003 env24265 = env24266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243003 env24265 == env24266) = true)

def env24267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243003,17,98644,8192,65,171281,5392,17665,108926,1364,213351,256,21792,46092,74251]

theorem envBound24267 : H12AffineFastState.Bounded env24267 := by
  intro p hp
  have h : env24267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24266_24267 : H12AffineEnvironment.transform 6 8 env24266 = env24267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24266 == env24267) = true)

theorem identity24267 : scanCanonicalize (H12AffineFastState.compose env24267 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24267 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,169265,17,41310,8192,65,171281,5392,17665,35188,1364,156013,256,21792,46092,513]

theorem envBound24268 : H12AffineFastState.Bounded env24268 := by
  intro p hp
  have h : env24268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24267_24268 : H12AffineEnvironment.transform 15 8202 env24267 = env24268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24267 == env24268) = true)

theorem identity24268 : scanCanonicalize (H12AffineFastState.compose env24268 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24268 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4161,54560,17,41310,8192,65,56576,5392,17665,35188,1364,8572,256,21792,46092,513]

theorem envBound24269 : H12AffineFastState.Bounded env24269 := by
  intro p hp
  have h : env24269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24268_24269 : H12AffineEnvironment.transform 16 16401 env24268 = env24269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24268 == env24269) = true)

theorem identity24269 : scanCanonicalize (H12AffineFastState.compose env24269 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound24269 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2420,1024,8540,4161,29821,17,3,8192,65,31837,5392,17665,10281,1364,8572,256,21792,5457,513]

theorem envBound24270 : H12AffineFastState.Bounded env24270 := by
  intro p hp
  have h : env24270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24269_24270 : H12AffineEnvironment.transform 14 8541 env24269 = env24270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env24269 == env24270) = true)

theorem identity24270 : scanCanonicalize (H12AffineFastState.compose env24270 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound24270 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,8202,13341,2420,1024,8540,4161,113,17,3,8192,65,2129,5392,12557,10281,1364,8572,256,8492,5457,513]

theorem envBound24271 : H12AffineFastState.Bounded env24271 := by
  intro p hp
  have h : env24271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24270_24271 : H12AffineEnvironment.transform 13 13324 env24270 = env24271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env24270 == env24271) = true)

theorem identity24271 : scanCanonicalize (H12AffineFastState.compose env24271 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound24271 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env24272 : List Nat := [2,4,8,16,32,64,8,52,512,1024,2048,4096,8192,13324,8297,8202,13341,2112,1024,8296,4161,113,17,3,8192,65,2129,5156,12345,10281,1120,8264,52,8216,5221,513]

theorem envBound24272 : H12AffineFastState.Bounded env24272 := by
  intro p hp
  have h : env24272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24271_24272 : H12AffineEnvironment.transform 7 52 env24271 = env24272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env24271 == env24272) = true)

theorem identity24272 : scanCanonicalize (H12AffineFastState.compose env24272 (packedSelected [1,2,4,6,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24272 : packedSelected [1,2,4,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24273 : List Nat := [2,4,8,16,32,64,8,52,512,52,2048,4096,8192,12344,8297,8202,12329,2112,52,8296,4161,113,17,3,8192,65,2129,4112,12345,10281,84,8264,52,8216,4177,513]

theorem envBound24273 : H12AffineFastState.Bounded env24273 := by
  intro p hp
  have h : env24273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24272_24273 : H12AffineEnvironment.transform 9 52 env24272 = env24273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24272 == env24273) = true)

theorem identity24273 : scanCanonicalize (H12AffineFastState.compose env24273 (packedSelected [0,1,2,6,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound24273 : packedSelected [0,1,2,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env24274 : List Nat := [2,4,8,16,32,64,8,52,512,52,2048,4096,105,4177,0,99,4160,2112,52,1,4161,113,17,3,105,65,2129,4112,4176,2112,84,33,52,113,4177,513]

theorem envBound24274 : H12AffineFastState.Bounded env24274 := by
  intro p hp
  have h : env24274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24273_24274 : H12AffineEnvironment.transform 12 105 env24273 = env24274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env24273 == env24274) = true)

theorem identity24274 : scanCanonicalize (H12AffineFastState.compose env24274 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound24274 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env24275 : List Nat := [2,4,8,16,32,64,8,52,512,52,2048,2064,105,2113,0,99,2128,2112,52,1,2129,113,17,3,105,65,2129,2048,2112,2112,84,33,52,113,2113,513]

theorem envBound24275 : H12AffineFastState.Bounded env24275 := by
  intro p hp
  have h : env24275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24274_24275 : H12AffineEnvironment.transform 11 2064 env24274 = env24275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env24274 == env24275) = true)

theorem identity24275 : scanCanonicalize (H12AffineFastState.compose env24275 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24275 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24276 : List Nat := [2,4,8,16,32,16,8,52,512,52,2048,2064,57,2065,0,51,2048,2064,52,1,2049,33,17,3,57,17,2049,2048,2064,2064,4,33,52,33,2065,513]

theorem envBound24276 : H12AffineFastState.Bounded env24276 := by
  intro p hp
  have h : env24276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24275_24276 : H12AffineEnvironment.transform 5 16 env24275 = env24276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24275 == env24276) = true)

theorem identity24276 : scanCanonicalize (H12AffineFastState.compose env24276 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24276 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24277 : List Nat := [2,4,8,0,32,0,8,36,512,36,2048,2048,41,2049,0,35,2048,2048,36,1,2049,33,1,3,41,1,2049,2048,2048,2048,4,33,36,33,2049,513]

theorem envBound24277 : H12AffineFastState.Bounded env24277 := by
  intro p hp
  have h : env24277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24276_24277 : H12AffineEnvironment.transform 3 0 env24276 = env24277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24276 == env24277) = true)

theorem identity24277 : scanCanonicalize (H12AffineFastState.compose env24277 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound24277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24278 : List Nat := [2,4,8,0,32,0,8,36,0,36,2048,2048,41,2049,0,35,2048,2048,36,1,2049,33,1,3,41,1,2049,2048,2048,2048,4,33,36,33,2049,1]

theorem envBound24278 : H12AffineFastState.Bounded env24278 := by
  intro p hp
  have h : env24278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24277_24278 : H12AffineEnvironment.transform 8 0 env24277 = env24278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env24277 == env24278) = true)

theorem identity24278 : scanCanonicalize (H12AffineFastState.compose env24278 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound24278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24279 : List Nat := [2,4,8,0,32,0,8,36,0,36,11,11,41,10,0,35,11,11,36,1,10,33,1,3,41,1,10,11,11,11,4,33,36,33,10,1]

theorem envBound24279 : H12AffineFastState.Bounded env24279 := by
  intro p hp
  have h : env24279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24278_24279 : H12AffineEnvironment.transform 10 11 env24278 = env24279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env24278 == env24279) = true)

theorem identity24279 : scanCanonicalize (H12AffineFastState.compose env24279 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24279 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24280 : List Nat := [2,4,2,0,32,0,2,36,0,36,1,1,35,0,0,35,1,1,36,1,0,33,1,3,35,1,0,1,1,1,4,33,36,33,0,1]

theorem envBound24280 : H12AffineFastState.Bounded env24280 := by
  intro p hp
  have h : env24280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24279_24280 : H12AffineEnvironment.transform 2 2 env24279 = env24280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env24279 == env24280) = true)

def env24281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243003,17,98645,8193,65,171280,5392,17665,108926,1365,213351,256,21792,46093,74251]

theorem envBound24281 : H12AffineFastState.Bounded env24281 := by
  intro p hp
  have h : env24281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24266_24281 : H12AffineEnvironment.transform 6 9 env24266 = env24281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24266 == env24281) = true)

theorem identity24281 : scanCanonicalize (H12AffineFastState.compose env24281 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24281 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190521,1024,32769,4161,144493,17,3,8193,65,171280,5392,17665,10280,1365,180273,256,21792,46093,41821]

theorem envBound24282 : H12AffineFastState.Bounded env24282 := by
  intro p hp
  have h : env24282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24281_24282 : H12AffineEnvironment.transform 15 33110 env24281 = env24282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24281 == env24282) = true)

theorem identity24282 : scanCanonicalize (H12AffineFastState.compose env24282 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound24282 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env24283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,46108,23589,1024,32769,4161,32881,17,3,8193,65,10508,5392,17665,10280,1365,29741,256,21792,46093,41821]

theorem envBound24283 : H12AffineFastState.Bounded env24283 := by
  intro p hp
  have h : env24283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24282_24283 : H12AffineEnvironment.transform 16 46108 env24282 = env24283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env24282 == env24283) = true)

theorem identity24283 : scanCanonicalize (H12AffineFastState.compose env24283 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound24283 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env24284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,16448,23589,1024,29789,4161,29741,17,3,8193,65,10508,5392,17665,10280,1365,29741,256,21792,16465,22273]

theorem envBound24284 : H12AffineFastState.Bounded env24284 := by
  intro p hp
  have h : env24284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24283_24284 : H12AffineEnvironment.transform 14 29788 env24283 = env24284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env24283 == env24284) = true)

theorem identity24284 : scanCanonicalize (H12AffineFastState.compose env24284 (packedSelected [0,2,7,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound24284 : packedSelected [0,2,7,14,20] rootPS < 2^1333 := by decide +kernel

def env24285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13657,261,83,13593,10620,1024,260,4161,372,17,3,8193,65,10508,5392,12376,10280,1365,372,256,8313,13576,8792]

theorem envBound24285 : H12AffineFastState.Bounded env24285 := by
  intro p hp
  have h : env24285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24284_24285 : H12AffineEnvironment.transform 13 13657 env24284 = env24285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env24284 == env24285) = true)

theorem identity24285 : scanCanonicalize (H12AffineFastState.compose env24285 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24285 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env24286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5488,261,83,5424,2389,1024,260,4161,372,17,3,40,65,2341,5392,4209,2049,1365,372,256,80,5409,625]

theorem envBound24286 : H12AffineFastState.Bounded env24286 := by
  intro p hp
  have h : env24286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24285_24286 : H12AffineEnvironment.transform 12 41 env24285 = env24286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24285 == env24286) = true)

theorem identity24286 : scanCanonicalize (H12AffineFastState.compose env24286 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24286 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24287 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5409,261,2,5424,2308,1024,260,4112,293,17,3,40,16,2341,5392,4128,2049,1284,293,256,1,5409,544]

theorem envBound24287 : H12AffineFastState.Bounded env24287 := by
  intro p hp
  have h : env24287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24286_24287 : H12AffineEnvironment.transform 5 17 env24286 = env24287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24286 == env24287) = true)

theorem identity24287 : scanCanonicalize (H12AffineFastState.compose env24287 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24287 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24288 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,41,5157,1,2,5172,2048,1024,0,4112,33,17,3,40,16,2081,5140,4128,2049,1024,33,4,1,5157,544]

theorem envBound24288 : H12AffineFastState.Bounded env24288 := by
  intro p hp
  have h : env24288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24287_24288 : H12AffineEnvironment.transform 7 4 env24287 = env24288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24287 == env24288) = true)

theorem identity24288 : scanCanonicalize (H12AffineFastState.compose env24288 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24288 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24289 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,1,2,5141,2048,1024,0,4112,0,17,3,9,16,2048,5140,4097,2049,1024,0,4,1,5124,513]

theorem envBound24289 : H12AffineFastState.Bounded env24289 := by
  intro p hp
  have h : env24289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24288_24289 : H12AffineEnvironment.transform 4 1 env24288 = env24289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24288 == env24289) = true)

theorem identity24289 : scanCanonicalize (H12AffineFastState.compose env24289 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24290 : List Nat := [2,4,8,1,1,0,9,4,512,1024,2048,4096,8,5124,1,2,5124,2048,1024,0,4097,0,0,3,9,1,2048,5125,4097,2049,1024,0,4,1,5124,513]

theorem envBound24290 : H12AffineFastState.Bounded env24290 := by
  intro p hp
  have h : env24290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24289_24290 : H12AffineEnvironment.transform 3 1 env24289 = env24290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24289 == env24290) = true)

theorem identity24290 : scanCanonicalize (H12AffineFastState.compose env24290 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound24290 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24291 : List Nat := [2,4,8,1,1,0,9,4,512,1024,2048,1540,8,512,1,2,512,2048,1024,0,1541,0,0,3,9,1,2048,513,1541,2049,1024,0,4,1,512,513]

theorem envBound24291 : H12AffineFastState.Bounded env24291 := by
  intro p hp
  have h : env24291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24290_24291 : H12AffineEnvironment.transform 11 1540 env24290 = env24291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env24290 == env24291) = true)

theorem identity24291 : scanCanonicalize (H12AffineFastState.compose env24291 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound24291 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24292 : List Nat := [2,4,8,1,1,0,9,4,512,1024,1540,1540,8,512,1,2,512,1540,1024,0,1541,0,0,3,9,1,1540,513,1541,1541,1024,0,4,1,512,513]

theorem envBound24292 : H12AffineFastState.Bounded env24292 := by
  intro p hp
  have h : env24292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24291_24292 : H12AffineEnvironment.transform 10 1540 env24291 = env24292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env24291 == env24292) = true)

def env24293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270243,5392,17664,2210110,1501,4256860,256,2114912,2139332,74250]

theorem envBound24293 : H12AffineFastState.Bounded env24293 := by
  intro p hp
  have h : env24293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24256_24293 : H12AffineEnvironment.transform 22 2101329 env24256 = env24293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env24256 == env24293) = true)

def env24294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,17,98781,8328,65,4270243,5392,17664,108926,1501,4256860,256,21792,46212,74250]

theorem envBound24294 : H12AffineFastState.Bounded env24294 := by
  intro p hp
  have h : env24294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24293_24294 : H12AffineEnvironment.transform 20 4160 env24293 = env24294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24293 == env24294) = true)

theorem identity24294 : scanCanonicalize (H12AffineFastState.compose env24294 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213486) := by decide +kernel

theorem selectedBound24294 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,213486,17,98781,8328,65,158029,5392,17664,108926,1501,243122,256,21792,46212,74250]

theorem envBound24295 : H12AffineFastState.Bounded env24295 := by
  intro p hp
  have h : env24295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24294_24295 : H12AffineEnvironment.transform 21 213486 env24294 = env24295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213486 env24294 == env24295) = true)

theorem identity24295 : scanCanonicalize (H12AffineFastState.compose env24295 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24295 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4160,156133,17,41430,8328,65,158029,5392,17664,35189,1501,169401,256,21792,46212,513]

theorem envBound24296 : H12AffineFastState.Bounded env24296 := by
  intro p hp
  have h : env24296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24295_24296 : H12AffineEnvironment.transform 15 8203 env24295 = env24296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24295 == env24296) = true)

theorem identity24296 : scanCanonicalize (H12AffineFastState.compose env24296 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24296 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2420,1024,32769,4160,8693,17,41430,8328,65,10589,5392,17664,35189,1501,54697,256,21792,46212,513]

theorem envBound24297 : H12AffineFastState.Bounded env24297 := by
  intro p hp
  have h : env24297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24296_24297 : H12AffineEnvironment.transform 16 16400 env24296 = env24297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24296 == env24297) = true)

theorem identity24297 : scanCanonicalize (H12AffineFastState.compose env24297 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound24297 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env24298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16400,2420,1024,29709,4160,8693,17,21978,8328,65,10589,5392,17664,32121,1501,8613,256,21792,16520,513]

theorem envBound24298 : H12AffineFastState.Bounded env24298 := by
  intro p hp
  have h : env24298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24297_24298 : H12AffineEnvironment.transform 14 29708 env24297 = env24298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env24297 == env24298) = true)

theorem identity24298 : scanCanonicalize (H12AffineFastState.compose env24298 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24298 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21841,342,16400,2420,1024,21840,4160,168,17,21978,469,65,2048,5392,17664,23588,1501,248,256,21792,16520,513]

theorem envBound24299 : H12AffineFastState.Bounded env24299 := by
  intro p hp
  have h : env24299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24298_24299 : H12AffineEnvironment.transform 12 349 env24298 = env24299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24298 == env24299) = true)

theorem identity24299 : scanCanonicalize (H12AffineFastState.compose env24299 (packedSelected [1,2,5,7,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3528) := by decide +kernel

theorem selectedBound24299 : packedSelected [1,2,5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,3528,6297,342,3544,2420,1024,6296,4160,168,17,6162,469,65,2048,5392,2248,4588,1501,248,256,6376,3392,513]

theorem envBound24300 : H12AffineFastState.Bounded env24300 := by
  intro p hp
  have h : env24300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24299_24300 : H12AffineEnvironment.transform 13 3528 env24299 = env24300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3528 env24299 == env24300) = true)

theorem identity24300 : scanCanonicalize (H12AffineFastState.compose env24300 (packedSelected [0,2,3,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound24300 : packedSelected [0,2,3,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env24301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,349,3528,2420,342,3544,2420,1024,2421,429,168,17,2559,469,65,2048,1277,2248,1,1501,248,256,2309,3392,513]

theorem envBound24301 : H12AffineFastState.Bounded env24301 := by
  intro p hp
  have h : env24301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24300_24301 : H12AffineEnvironment.transform 11 493 env24300 = env24301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env24300 == env24301) = true)

theorem identity24301 : scanCanonicalize (H12AffineFastState.compose env24301 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24301 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24302 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,152,40,3261,2049,35,3245,2049,1024,2048,216,168,17,2186,160,65,2048,1277,2248,1,1192,248,117,2160,3125,513]

theorem envBound24302 : H12AffineFastState.Bounded env24302 := by
  intro p hp
  have h : env24302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24301_24302 : H12AffineEnvironment.transform 7 117 env24301 = env24302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24301 == env24302) = true)

theorem identity24302 : scanCanonicalize (H12AffineFastState.compose env24302 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound24302 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24303 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1125,152,40,216,1124,35,200,1124,1024,1125,216,168,17,1263,160,65,1125,1277,1197,1,1192,248,117,1045,80,513]

theorem envBound24303 : H12AffineFastState.Bounded env24303 := by
  intro p hp
  have h : env24303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24302_24303 : H12AffineEnvironment.transform 10 1125 env24302 = env24303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env24302 == env24303) = true)

theorem identity24303 : scanCanonicalize (H12AffineFastState.compose env24303 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24303 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env24304 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1077,152,40,136,1076,35,152,1076,1024,1077,136,168,17,1215,160,17,1077,1197,1197,1,1192,168,37,1045,0,513]

theorem envBound24304 : H12AffineFastState.Bounded env24304 := by
  intro p hp
  have h : env24304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24303_24304 : H12AffineEnvironment.transform 5 16 env24303 = env24304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24303 == env24304) = true)

theorem identity24304 : scanCanonicalize (H12AffineFastState.compose env24304 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound24304 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env24305 : List Nat := [2,4,8,16,32,16,128,37,512,188,137,152,40,136,136,35,152,136,188,137,136,168,17,3,160,17,137,17,17,1,20,168,37,169,0,513]

theorem envBound24305 : H12AffineFastState.Bounded env24305 := by
  intro p hp
  have h : env24305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24304_24305 : H12AffineEnvironment.transform 9 188 env24304 = env24305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env24304 == env24305) = true)

theorem identity24305 : scanCanonicalize (H12AffineFastState.compose env24305 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound24305 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24306 : List Nat := [2,4,8,16,32,16,128,37,27,188,137,152,40,136,136,35,152,136,188,137,136,168,17,3,160,17,137,17,17,1,20,168,37,169,0,26]

theorem envBound24306 : H12AffineFastState.Bounded env24306 := by
  intro p hp
  have h : env24306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1