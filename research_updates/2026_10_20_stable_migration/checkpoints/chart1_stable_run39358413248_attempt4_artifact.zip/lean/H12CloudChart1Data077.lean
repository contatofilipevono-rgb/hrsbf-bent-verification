import H12CloudChart1Data076

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound19447 : H12AffineFastState.Bounded env19447 := by
  intro p hp
  have h : env19447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19446_19447 : H12AffineEnvironment.transform 11 276 env19446 = env19447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env19446 == env19447) = true)

theorem identity19447 : scanCanonicalize (H12AffineFastState.compose env19447 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound19447 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19448 : List Nat := [2,4,8,16,32,16,9,256,512,304,49,276,268,292,1,263,308,277,304,0,260,33,16,3,269,17,48,308,276,277,52,32,256,33,293,513]

theorem envBound19448 : H12AffineFastState.Bounded env19448 := by
  intro p hp
  have h : env19448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19447_19448 : H12AffineEnvironment.transform 9 304 env19447 = env19448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env19447 == env19448) = true)

theorem identity19448 : scanCanonicalize (H12AffineFastState.compose env19448 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound19448 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19449 : List Nat := [2,4,8,16,32,16,9,256,292,304,49,276,268,292,1,263,308,277,304,0,260,33,16,3,269,17,48,308,276,277,52,32,256,33,293,293]

theorem envBound19449 : H12AffineFastState.Bounded env19449 := by
  intro p hp
  have h : env19449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19448_19449 : H12AffineEnvironment.transform 8 292 env19448 = env19449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env19448 == env19449) = true)

theorem identity19449 : scanCanonicalize (H12AffineFastState.compose env19449 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19449 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19450 : List Nat := [2,4,8,16,17,16,9,256,277,257,0,276,268,277,1,263,261,277,257,0,260,16,16,3,269,17,1,261,276,277,5,17,256,16,276,276]

theorem envBound19450 : H12AffineFastState.Bounded env19450 := by
  intro p hp
  have h : env19450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19449_19450 : H12AffineEnvironment.transform 4 17 env19449 = env19450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19449 == env19450) = true)

theorem identity19450 : scanCanonicalize (H12AffineFastState.compose env19450 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19451 : List Nat := [2,4,8,1,0,1,9,256,260,257,0,261,268,260,1,263,261,260,257,0,260,1,1,3,269,0,1,261,261,260,5,0,256,1,261,261]

theorem envBound19451 : H12AffineFastState.Bounded env19451 := by
  intro p hp
  have h : env19451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19450_19451 : H12AffineEnvironment.transform 3 1 env19450 = env19451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19450 == env19451) = true)

def env19452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,98780,8328,65,4237692,5393,17664,10400,1500,4256861,256,21793,46213,74251]

theorem envBound19452 : H12AffineFastState.Bounded env19452 := by
  intro p hp
  have h : env19452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19426_19452 : H12AffineEnvironment.transform 20 4161 env19426 = env19452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19426 == env19452) = true)

theorem identity19452 : scanCanonicalize (H12AffineFastState.compose env19452 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound19452 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,180272,17,98780,8328,65,158028,5393,17664,10400,1500,144493,256,21793,46213,74251]

theorem envBound19453 : H12AffineFastState.Bounded env19453 := by
  intro p hp
  have h : env19453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19452_19453 : H12AffineEnvironment.transform 21 180272 env19452 = env19453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env19452 == env19453) = true)

theorem identity19453 : scanCanonicalize (H12AffineFastState.compose env19453 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19453 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190640,1024,32769,4161,180272,17,41430,8328,65,158028,5393,17664,10400,1500,144493,256,21793,46213,513]

theorem envBound19454 : H12AffineFastState.Bounded env19454 := by
  intro p hp
  have h : env19454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19453_19454 : H12AffineEnvironment.transform 15 8202 env19453 = env19454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19453 == env19454) = true)

theorem identity19454 : scanCanonicalize (H12AffineFastState.compose env19454 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound19454 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43169,1024,32769,4161,32801,17,41430,8328,65,10589,5393,17664,10400,1500,29820,256,21793,46213,513]

theorem envBound19455 : H12AffineFastState.Bounded env19455 := by
  intro p hp
  have h : env19455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19454_19455 : H12AffineEnvironment.transform 16 16401 env19454 = env19455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env19454 == env19455) = true)

theorem identity19455 : scanCanonicalize (H12AffineFastState.compose env19455 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound19455 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env19456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,16401,23725,1024,29709,4161,29741,17,21978,8328,65,10589,5393,17664,10400,1500,29820,256,21793,16521,513]

theorem envBound19456 : H12AffineFastState.Bounded env19456 := by
  intro p hp
  have h : env19456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19455_19456 : H12AffineEnvironment.transform 14 29708 env19455 = env19456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env19455 == env19456) = true)

theorem identity19456 : scanCanonicalize (H12AffineFastState.compose env19456 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19456 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env19457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8202,16401,23589,1024,29709,4161,29741,17,21842,8192,65,10589,5393,17664,10280,1364,29820,256,21793,16385,513]

theorem envBound19457 : H12AffineFastState.Bounded env19457 := by
  intro p hp
  have h : env19457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19456_19457 : H12AffineEnvironment.transform 6 8 env19456 = env19457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19456 == env19457) = true)

theorem identity19457 : scanCanonicalize (H12AffineFastState.compose env19457 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound19457 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4452,9576,8202,4469,3393,1024,9577,4161,9545,17,1078,8192,65,10589,5393,5220,10280,1364,9496,256,1093,4453,513]

theorem envBound19458 : H12AffineFastState.Bounded env19458 := by
  intro p hp
  have h : env19458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19457_19458 : H12AffineEnvironment.transform 13 4452 env19457 = env19458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env19457 == env19458) = true)

theorem identity19458 : scanCanonicalize (H12AffineFastState.compose env19458 (packedSelected [2,3,4,6,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19458 : packedSelected [2,3,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env19459 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,4405,9529,8202,4388,3344,1024,9528,4112,9496,17,1078,8192,16,10508,5393,5173,10280,1285,9496,256,1044,4404,513]

theorem envBound19459 : H12AffineFastState.Bounded env19459 := by
  intro p hp
  have h : env19459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19458_19459 : H12AffineEnvironment.transform 5 17 env19458 = env19459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19458 == env19459) = true)

theorem identity19459 : scanCanonicalize (H12AffineFastState.compose env19459 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound19459 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env19460 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,4405,293,1046,4388,3344,1024,292,4112,260,17,1078,1052,16,3344,5393,5173,3124,1285,260,256,1044,4404,513]

theorem envBound19460 : H12AffineFastState.Bounded env19460 := by
  intro p hp
  have h : env19460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19459_19460 : H12AffineEnvironment.transform 12 1052 env19459 = env19460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env19459 == env19460) = true)

theorem identity19460 : scanCanonicalize (H12AffineFastState.compose env19460 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19460 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19461 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,40,4405,293,34,4388,2340,52,292,4112,260,17,2,40,16,2340,4389,4097,2048,305,260,256,32,4404,513]

theorem envBound19461 : H12AffineFastState.Bounded env19461 := by
  intro p hp
  have h : env19461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19460_19461 : H12AffineEnvironment.transform 9 52 env19460 = env19461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19460 == env19461) = true)

theorem identity19461 : scanCanonicalize (H12AffineFastState.compose env19461 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19461 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19462 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,40,4113,1,34,4096,2048,52,0,4112,32,17,2,40,16,2048,4097,4097,2048,21,32,36,32,4112,513]

theorem envBound19462 : H12AffineFastState.Bounded env19462 := by
  intro p hp
  have h : env19462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19461_19462 : H12AffineEnvironment.transform 7 36 env19461 = env19462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19461 == env19462) = true)

theorem identity19462 : scanCanonicalize (H12AffineFastState.compose env19462 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound19462 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19463 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2049,40,2064,1,34,2049,2048,52,0,2065,32,17,2,40,16,2048,2048,2048,2048,21,32,36,32,2065,513]

theorem envBound19463 : H12AffineFastState.Bounded env19463 := by
  intro p hp
  have h : env19463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19462_19463 : H12AffineEnvironment.transform 11 2049 env19462 = env19463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env19462 == env19463) = true)

theorem identity19463 : scanCanonicalize (H12AffineFastState.compose env19463 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19464 : List Nat := [2,4,8,16,11,17,8,15,512,31,2048,2049,3,2064,1,9,2049,2048,31,0,2065,11,17,2,3,16,2048,2048,2048,2048,21,11,15,11,2065,513]

theorem envBound19464 : H12AffineFastState.Bounded env19464 := by
  intro p hp
  have h : env19464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19463_19464 : H12AffineEnvironment.transform 4 11 env19463 = env19464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19463 == env19464) = true)

theorem identity19464 : scanCanonicalize (H12AffineFastState.compose env19464 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound19464 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19465 : List Nat := [2,4,8,16,11,17,8,15,512,31,17,16,3,1,1,9,16,17,31,0,0,11,17,2,3,16,17,17,17,17,21,11,15,11,0,513]

theorem envBound19465 : H12AffineFastState.Bounded env19465 := by
  intro p hp
  have h : env19465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19464_19465 : H12AffineEnvironment.transform 10 17 env19464 = env19465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env19464 == env19465) = true)

theorem identity19465 : scanCanonicalize (H12AffineFastState.compose env19465 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19465 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19466 : List Nat := [2,4,8,0,11,1,8,15,512,15,1,0,3,1,1,9,0,1,15,0,0,11,1,2,3,0,1,1,1,1,5,11,15,11,0,513]

theorem envBound19466 : H12AffineFastState.Bounded env19466 := by
  intro p hp
  have h : env19466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19465_19466 : H12AffineEnvironment.transform 3 0 env19465 = env19466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19465 == env19466) = true)

def env19467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,98781,8328,65,6338876,2098513,17665,2111713,2102685,6349853,256,21793,46213,2175562]

theorem envBound19467 : H12AffineFastState.Bounded env19467 := by
  intro p hp
  have h : env19467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19425_19467 : H12AffineEnvironment.transform 17 190641 env19425 = env19467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env19425 == env19467) = true)

def env19468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,98781,8328,65,4237692,5393,17665,10401,1501,4256861,256,21793,46213,74250]

theorem envBound19468 : H12AffineFastState.Bounded env19468 := by
  intro p hp
  have h : env19468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19467_19468 : H12AffineEnvironment.transform 20 4160 env19467 = env19468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19467 == env19468) = true)

theorem identity19468 : scanCanonicalize (H12AffineFastState.compose env19468 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound19468 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,144613,17,98781,8328,65,171417,5393,17665,10401,1501,180408,256,21793,46213,74250]

theorem envBound19469 : H12AffineFastState.Bounded env19469 := by
  intro p hp
  have h : env19469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19468_19469 : H12AffineEnvironment.transform 21 144613 env19468 = env19469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env19468 == env19469) = true)

def env19470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144493,17,98645,8192,65,171281,5393,17665,10281,1365,180272,256,21793,46093,74250]

theorem envBound19470 : H12AffineFastState.Bounded env19470 := by
  intro p hp
  have h : env19470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19469_19470 : H12AffineEnvironment.transform 6 8 env19469 = env19470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19469 == env19470) = true)

theorem identity19470 : scanCanonicalize (H12AffineFastState.compose env19470 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19470 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190521,1024,32769,4160,144493,17,2,8192,65,171281,5393,17665,10281,1365,180272,256,21793,46093,41821]

theorem envBound19471 : H12AffineFastState.Bounded env19471 := by
  intro p hp
  have h : env19471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19470_19471 : H12AffineEnvironment.transform 15 33111 env19470 = env19471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19470 == env19471) = true)

theorem identity19471 : scanCanonicalize (H12AffineFastState.compose env19471 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19471 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33111,131072,171061,1024,32769,4160,144493,17,2,8192,65,171281,5393,12557,10281,1365,177212,256,8493,46093,41821]

theorem envBound19472 : H12AffineFastState.Bounded env19472 := by
  intro p hp
  have h : env19472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19471_19472 : H12AffineEnvironment.transform 13 13324 env19471 = env19472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19471 == env19472) = true)

theorem identity19472 : scanCanonicalize (H12AffineFastState.compose env19472 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound19472 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,263,131072,138341,1024,81,4160,144493,17,2,8192,65,138561,5393,12557,10281,1365,144492,256,8493,13405,8973]

theorem envBound19473 : H12AffineFastState.Bounded env19473 := by
  intro p hp
  have h : env19473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19472_19473 : H12AffineEnvironment.transform 14 80 env19472 = env19473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env19472 == env19473) = true)

theorem identity19473 : scanCanonicalize (H12AffineFastState.compose env19473 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound19473 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,263,5173,2128,1024,81,4160,8280,17,2,8192,65,2420,5393,12557,10281,1365,8281,256,8493,13405,8973]

theorem envBound19474 : H12AffineFastState.Bounded env19474 := by
  intro p hp
  have h : env19474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19473_19474 : H12AffineEnvironment.transform 16 5173 env19473 = env19474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env19473 == env19474) = true)

theorem identity19474 : scanCanonicalize (H12AffineFastState.compose env19474 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound19474 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19475 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,13324,80,83,5173,2128,1024,81,4160,8280,17,2,8192,65,2080,5189,12377,10281,1025,8281,84,8313,13405,8793]

theorem envBound19475 : H12AffineFastState.Bounded env19475 := by
  intro p hp
  have h : env19475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19474_19475 : H12AffineEnvironment.transform 7 84 env19474 = env19475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env19474 == env19475) = true)

theorem identity19475 : scanCanonicalize (H12AffineFastState.compose env19475 (packedSelected [1,6,8,11,12,14,15,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19475 : packedSelected [1,6,8,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env19476 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,8192,13324,32,35,5173,2080,1024,33,4144,8232,17,2,8192,49,2080,5173,12329,10281,1025,8233,36,8201,13357,8745]

theorem envBound19476 : H12AffineFastState.Bounded env19476 := by
  intro p hp
  have h : env19476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19475_19476 : H12AffineEnvironment.transform 5 48 env19475 = env19476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19475 == env19476) = true)

def env19477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,98644,8193,65,171280,5393,17665,10280,1364,180273,256,21793,46092,74250]

theorem envBound19477 : H12AffineFastState.Bounded env19477 := by
  intro p hp
  have h : env19477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19469_19477 : H12AffineEnvironment.transform 6 9 env19469 = env19477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19469 == env19477) = true)

theorem identity19477 : scanCanonicalize (H12AffineFastState.compose env19477 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19477 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4160,144492,17,41311,8193,65,171280,5393,17665,10280,1364,180273,256,21793,46092,513]

theorem envBound19478 : H12AffineFastState.Bounded env19478 := by
  intro p hp
  have h : env19478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19477_19478 : H12AffineEnvironment.transform 15 8203 env19477 = env19478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19477 == env19478) = true)

theorem identity19478 : scanCanonicalize (H12AffineFastState.compose env19478 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19478 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19479 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4112,144444,17,41231,8193,17,171280,5393,17665,10280,1284,180273,256,21793,46092,513]

theorem envBound19479 : H12AffineFastState.Bounded env19479 := by
  intro p hp
  have h : env19479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19478_19479 : H12AffineEnvironment.transform 5 16 env19478 = env19479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19478 == env19479) = true)

theorem identity19479 : scanCanonicalize (H12AffineFastState.compose env19479 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound19479 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env19480 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43048,1024,32769,4112,29740,17,41231,8193,17,56576,5393,17665,10280,1284,32801,256,21793,46092,513]

theorem envBound19480 : H12AffineFastState.Bounded env19480 := by
  intro p hp
  have h : env19480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19479_19480 : H12AffineEnvironment.transform 16 16400 env19479 = env19480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19479 == env19480) = true)

theorem identity19480 : scanCanonicalize (H12AffineFastState.compose env19480 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19480 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19481 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,2341,1024,8460,4112,29740,17,2,8193,17,31757,5393,17665,10280,1284,8492,256,21793,5377,513]

theorem envBound19481 : H12AffineFastState.Bounded env19481 := by
  intro p hp
  have h : env19481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19480_19481 : H12AffineEnvironment.transform 14 8461 env19480 = env19481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19480 == env19481) = true)

theorem identity19481 : scanCanonicalize (H12AffineFastState.compose env19481 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2828) := by decide +kernel

theorem selectedBound19481 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19482 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,2828,16384,2561,2823,16400,2341,1024,2560,4112,24352,17,2,2829,17,22273,5393,17665,804,1284,2592,256,21793,5377,513]

theorem envBound19482 : H12AffineFastState.Bounded env19482 := by
  intro p hp
  have h : env19482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19481_19482 : H12AffineEnvironment.transform 12 2828 env19481 = env19482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2828 env19481 == env19482) = true)

def env19483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,98781,8328,65,4237693,5392,17665,10400,1500,4256860,256,21793,46213,74251]

theorem envBound19483 : H12AffineFastState.Bounded env19483 := by
  intro p hp
  have h : env19483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19467_19483 : H12AffineEnvironment.transform 20 4161 env19467 = env19483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19467 == env19483) = true)

theorem identity19483 : scanCanonicalize (H12AffineFastState.compose env19483 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound19483 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138341,1024,29909,4161,4194304,16,95497,8328,65,4218281,5392,17665,10400,1500,4194440,256,21793,16465,74251]

theorem envBound19484 : H12AffineFastState.Bounded env19484 := by
  intro p hp
  have h : env19484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19483_19484 : H12AffineEnvironment.transform 14 29908 env19483 = env19484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env19483 == env19484) = true)

def env19485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138341,1024,8661,4161,4194304,16,73737,8328,65,4196521,5392,4097,10400,1500,4194440,256,33,5457,74251]

theorem envBound19485 : H12AffineFastState.Bounded env19485 := by
  intro p hp
  have h : env19485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19484_19485 : H12AffineEnvironment.transform 13 5376 env19484 = env19485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19484 == env19485) = true)

theorem identity19485 : scanCanonicalize (H12AffineFastState.compose env19485 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound19485 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70862,67755,1024,8661,4161,4194304,16,73737,8328,65,4196521,5392,4097,10400,1500,4194440,256,33,5457,74251]

theorem envBound19486 : H12AffineFastState.Bounded env19486 := by
  intro p hp
  have h : env19486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19485_19486 : H12AffineEnvironment.transform 16 70862 env19485 = env19486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env19485 == env19486) = true)

def env19487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138341,1024,8660,4161,4194304,16,73736,8328,65,4196520,5392,4096,10400,1500,4194440,256,32,5456,74251]

theorem envBound19487 : H12AffineFastState.Bounded env19487 := by
  intro p hp
  have h : env19487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19484_19487 : H12AffineEnvironment.transform 13 5377 env19484 = env19487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19484 == env19487) = true)

theorem identity19487 : scanCanonicalize (H12AffineFastState.compose env19487 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound19487 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70727,67618,1024,8660,4161,4194304,16,73736,8328,65,4196520,5392,4096,10400,1500,4194440,256,32,5456,74251]

theorem envBound19488 : H12AffineFastState.Bounded env19488 := by
  intro p hp
  have h : env19488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19487_19488 : H12AffineEnvironment.transform 16 70727 env19487 = env19488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env19487 == env19488) = true)

theorem identity19488 : scanCanonicalize (H12AffineFastState.compose env19488 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19488 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13389,10280,1024,8660,4161,4194304,16,2,8328,65,4196520,5392,4096,10400,1500,4194440,256,32,5456,513]

theorem envBound19489 : H12AffineFastState.Bounded env19489 := by
  intro p hp
  have h : env19489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19488_19489 : H12AffineEnvironment.transform 15 8202 env19488 = env19489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19488 == env19489) = true)

theorem identity19489 : scanCanonicalize (H12AffineFastState.compose env19489 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 249) := by decide +kernel

theorem selectedBound19489 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13389,10280,1024,8660,4161,249,16,2,8328,65,2129,5392,4096,10400,1500,113,256,32,5456,513]

theorem envBound19490 : H12AffineFastState.Bounded env19490 := by
  intro p hp
  have h : env19490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19489_19490 : H12AffineEnvironment.transform 21 249 env19489 = env19490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 249 env19489 == env19490) = true)

def env19491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554081,485740,8328,65,6705548,2551264,437681,2111712,2102684,6687916,256,21792,46212,2175563]

theorem envBound19491 : H12AffineFastState.Bounded env19491 := by
  intro p hp
  have h : env19491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19424_19491 : H12AffineEnvironment.transform 22 2554081 env19424 = env19491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554081 env19424 == env19491) = true)

def env19492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,98780,8328,65,6338876,2098512,17665,2111712,2102684,6349852,256,21792,46212,2175563]

theorem envBound19492 : H12AffineFastState.Bounded env19492 := by
  intro p hp
  have h : env19492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19491_19492 : H12AffineEnvironment.transform 17 190640 env19491 = env19492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env19491 == env19492) = true)

def env19493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,98780,8328,65,4237692,5392,17665,10400,1500,4256860,256,21792,46212,74251]

theorem envBound19493 : H12AffineFastState.Bounded env19493 := by
  intro p hp
  have h : env19493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19492_19493 : H12AffineEnvironment.transform 20 4160 env19492 = env19493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19492 == env19493) = true)

theorem identity19493 : scanCanonicalize (H12AffineFastState.compose env19493 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254010) := by decide +kernel

theorem selectedBound19493 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,254010,17,98780,8328,65,215366,5392,17665,10400,1500,201830,256,21792,46212,74251]

theorem envBound19494 : H12AffineFastState.Bounded env19494 := by
  intro p hp
  have h : env19494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19493_19494 : H12AffineEnvironment.transform 21 254010 env19493 = env19494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254010 env19493 == env19494) = true)

def env19495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254010,17,98644,8192,65,215366,5392,17665,10280,1364,201830,256,21792,46092,74251]

theorem envBound19495 : H12AffineFastState.Bounded env19495 := by
  intro p hp
  have h : env19495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19494_19495 : H12AffineEnvironment.transform 6 8 env19494 = env19495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19494 == env19495) = true)

theorem identity19495 : scanCanonicalize (H12AffineFastState.compose env19495 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound19495 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190520,1024,32769,4160,156012,17,2,8192,65,182288,5392,17665,10280,1364,169264,256,21792,46092,41821]

theorem envBound19496 : H12AffineFastState.Bounded env19496 := by
  intro p hp
  have h : env19496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19495_19496 : H12AffineEnvironment.transform 15 33110 env19495 = env19496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env19495 == env19496) = true)

theorem identity19496 : scanCanonicalize (H12AffineFastState.compose env19496 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19496 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,149860,1024,8541,4160,156012,17,2,8192,65,158028,5392,17665,10280,1364,144492,256,21792,5456,513]

theorem envBound19497 : H12AffineFastState.Bounded env19497 := by
  intro p hp
  have h : env19497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19496_19497 : H12AffineEnvironment.transform 14 8540 env19496 = env19497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19496 == env19497) = true)

theorem identity19497 : scanCanonicalize (H12AffineFastState.compose env19497 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound19497 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8540,8202,131072,138561,1024,8541,4160,144713,17,2,8192,65,146793,5392,4388,10280,1364,144492,256,261,5456,513]

theorem envBound19498 : H12AffineFastState.Bounded env19498 := by
  intro p hp
  have h : env19498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19497_19498 : H12AffineEnvironment.transform 13 5157 env19497 = env19498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env19497 == env19498) = true)

theorem identity19498 : scanCanonicalize (H12AffineFastState.compose env19498 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound19498 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env19499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8540,8202,5172,2421,1024,8541,4160,8573,17,2,8192,65,10589,5392,4388,10280,1364,8280,256,261,5456,513]

theorem envBound19499 : H12AffineFastState.Bounded env19499 := by
  intro p hp
  have h : env19499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19498_19499 : H12AffineEnvironment.transform 16 5172 env19498 = env19499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env19498 == env19499) = true)

theorem identity19499 : scanCanonicalize (H12AffineFastState.compose env19499 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19499 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env19500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5157,373,35,5172,2421,1024,372,4160,340,17,2,41,65,2420,5392,4388,2049,1364,113,256,261,5456,513]

theorem envBound19500 : H12AffineFastState.Bounded env19500 := by
  intro p hp
  have h : env19500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19499_19500 : H12AffineEnvironment.transform 12 41 env19499 = env19500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19499 == env19500) = true)

theorem identity19500 : scanCanonicalize (H12AffineFastState.compose env19500 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound19500 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env19501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,41,2421,373,35,2404,2421,1024,372,3344,340,17,2,41,65,2420,2112,3188,2049,1364,113,256,261,2048,513]

theorem envBound19501 : H12AffineFastState.Bounded env19501 := by
  intro p hp
  have h : env19501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19500_19501 : H12AffineEnvironment.transform 11 3408 env19500 = env19501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env19500 == env19501) = true)

theorem identity19501 : scanCanonicalize (H12AffineFastState.compose env19501 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound19501 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,1141,41,80,373,35,65,80,1024,372,1077,340,17,2,41,65,81,357,1361,292,1364,113,256,261,293,513]

theorem envBound19502 : H12AffineFastState.Bounded env19502 := by
  intro p hp
  have h : env19502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19501_19502 : H12AffineEnvironment.transform 10 293 env19501 = env19502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env19501 == env19502) = true)

theorem identity19502 : scanCanonicalize (H12AffineFastState.compose env19502 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound19502 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env19503 : List Nat := [2,4,8,16,32,64,8,256,512,53,293,64,41,80,373,35,65,80,53,372,0,340,17,2,41,65,81,357,356,292,353,113,256,261,293,513]

theorem envBound19503 : H12AffineFastState.Bounded env19503 := by
  intro p hp
  have h : env19503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19502_19503 : H12AffineEnvironment.transform 9 53 env19502 = env19503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19502 == env19503) = true)

theorem identity19503 : scanCanonicalize (H12AffineFastState.compose env19503 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19504 : List Nat := [2,4,8,16,32,64,8,117,512,53,80,64,41,80,0,35,65,80,53,1,0,33,17,2,41,65,81,16,17,81,20,113,117,112,80,513]

theorem envBound19504 : H12AffineFastState.Bounded env19504 := by
  intro p hp
  have h : env19504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19503_19504 : H12AffineEnvironment.transform 7 117 env19503 = env19504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19503 == env19504) = true)

def env19505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254010,17,98645,8193,65,215366,5392,17665,10281,1365,201830,256,21792,46093,74251]

theorem envBound19505 : H12AffineFastState.Bounded env19505 := by
  intro p hp
  have h : env19505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19494_19505 : H12AffineEnvironment.transform 6 9 env19494 = env19505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19494 == env19505) = true)

theorem identity19505 : scanCanonicalize (H12AffineFastState.compose env19505 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19505 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,180272,17,41311,8193,65,158028,5392,17665,10281,1365,144492,256,21792,46093,513]

theorem envBound19506 : H12AffineFastState.Bounded env19506 := by
  intro p hp
  have h : env19506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19505_19506 : H12AffineEnvironment.transform 15 8202 env19505 = env19506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19505 == env19506) = true)

theorem identity19506 : scanCanonicalize (H12AffineFastState.compose env19506 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound19506 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4160,32801,17,41311,8193,65,10589,5392,17665,10281,1365,29821,256,21792,46093,513]

theorem envBound19507 : H12AffineFastState.Bounded env19507 := by
  intro p hp
  have h : env19507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19506_19507 : H12AffineEnvironment.transform 16 16401 env19506 = env19507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env19506 == env19507) = true)

theorem identity19507 : scanCanonicalize (H12AffineFastState.compose env19507 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19507 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2420,1024,8541,4160,8573,17,3,8193,65,10589,5392,17665,10281,1365,29821,256,21792,5457,513]

theorem envBound19508 : H12AffineFastState.Bounded env19508 := by
  intro p hp
  have h : env19508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19507_19508 : H12AffineEnvironment.transform 14 8540 env19507 = env19508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19507 == env19508) = true)

theorem identity19508 : scanCanonicalize (H12AffineFastState.compose env19508 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19508 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,8202,13341,2420,1024,8541,4160,8573,17,3,8193,65,10589,5392,12557,10281,1365,113,256,8492,5457,513]

theorem envBound19509 : H12AffineFastState.Bounded env19509 := by
  intro p hp
  have h : env19509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19508_19509 : H12AffineEnvironment.transform 13 13324 env19508 = env19509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19508 == env19509) = true)

theorem identity19509 : scanCanonicalize (H12AffineFastState.compose env19509 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound19509 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env19510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4404,1124,1330,4389,2420,1024,1125,4160,1093,17,3,1337,65,3173,5392,5173,3345,1365,113,256,1044,5457,513]

theorem envBound19510 : H12AffineFastState.Bounded env19510 := by
  intro p hp
  have h : env19510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19509_19510 : H12AffineEnvironment.transform 12 1336 env19509 = env19510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env19509 == env19510) = true)

theorem identity19510 : scanCanonicalize (H12AffineFastState.compose env19510 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19510 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env19511 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4404,1,343,4389,2420,101,0,4160,32,17,3,348,65,2048,4469,4176,2420,304,113,256,113,4404,513]

theorem envBound19511 : H12AffineFastState.Bounded env19511 := by
  intro p hp
  have h : env19511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19510_19511 : H12AffineEnvironment.transform 9 101 env19510 = env19511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19510 == env19511) = true)

theorem identity19511 : scanCanonicalize (H12AffineFastState.compose env19511 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19511 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19512 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,4404,1,263,4389,2340,53,0,4112,32,17,3,268,17,2048,4389,4096,2340,304,33,256,33,4404,513]

theorem envBound19512 : H12AffineFastState.Bounded env19512 := by
  intro p hp
  have h : env19512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19511_19512 : H12AffineEnvironment.transform 5 16 env19511 = env19512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19511 == env19512) = true)

theorem identity19512 : scanCanonicalize (H12AffineFastState.compose env19512 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19512 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19513 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,1,34,4096,2049,53,0,4112,32,17,3,41,17,2048,4096,4096,2049,21,33,37,33,4113,513]

theorem envBound19513 : H12AffineFastState.Bounded env19513 := by
  intro p hp
  have h : env19513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19512_19513 : H12AffineEnvironment.transform 7 37 env19512 = env19513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19512 == env19513) = true)

theorem identity19513 : scanCanonicalize (H12AffineFastState.compose env19513 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19513 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19514 : List Nat := [2,4,8,1,32,1,9,37,512,36,2048,4096,40,4096,1,34,4096,2049,36,0,4097,32,0,3,41,0,2048,4096,4096,2049,4,33,37,33,4096,513]

theorem envBound19514 : H12AffineFastState.Bounded env19514 := by
  intro p hp
  have h : env19514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19513_19514 : H12AffineEnvironment.transform 3 1 env19513 = env19514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19513 == env19514) = true)

theorem identity19514 : scanCanonicalize (H12AffineFastState.compose env19514 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound19514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19515 : List Nat := [2,4,8,1,32,1,9,37,512,36,2048,2602,40,2602,1,34,2602,2049,36,0,2603,32,0,3,41,0,2048,2602,2602,2049,4,33,37,33,2602,513]

theorem envBound19515 : H12AffineFastState.Bounded env19515 := by
  intro p hp
  have h : env19515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19514_19515 : H12AffineEnvironment.transform 11 2602 env19514 = env19515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env19514 == env19515) = true)

def env19516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,98780,8328,65,4237693,5393,17665,10401,1501,4256861,256,21792,46212,74250]

theorem envBound19516 : H12AffineFastState.Bounded env19516 := by
  intro p hp
  have h : env19516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19492_19516 : H12AffineEnvironment.transform 20 4161 env19492 = env19516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19492 == env19516) = true)

theorem identity19516 : scanCanonicalize (H12AffineFastState.compose env19516 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19516 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4161,4194304,16,41431,8328,65,4237693,5393,17665,10401,1501,4256861,256,21792,46212,513]

theorem envBound19517 : H12AffineFastState.Bounded env19517 := by
  intro p hp
  have h : env19517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19516_19517 : H12AffineEnvironment.transform 15 8203 env19516 = env19517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19516 == env19517) = true)

theorem identity19517 : scanCanonicalize (H12AffineFastState.compose env19517 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound19517 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4161,32800,16,41431,8328,65,10589,5393,17665,10401,1501,29821,256,21792,46212,513]

theorem envBound19518 : H12AffineFastState.Bounded env19518 := by
  intro p hp
  have h : env19518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19517_19518 : H12AffineEnvironment.transform 21 32800 env19517 = env19518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env19517 == env19518) = true)

theorem identity19518 : scanCanonicalize (H12AffineFastState.compose env19518 (packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound19518 : packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env19519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,35189,1024,32769,4161,32800,16,41431,8328,65,10589,5393,17665,10401,1501,29821,256,21792,46212,513]

theorem envBound19519 : H12AffineFastState.Bounded env19519 := by
  intro p hp
  have h : env19519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19518_19519 : H12AffineEnvironment.transform 16 25029 env19518 = env19519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env19518 == env19519) = true)

theorem identity19519 : scanCanonicalize (H12AffineFastState.compose env19519 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19519 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env19520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,35189,1024,32769,4161,32800,16,41310,8193,65,10589,5393,17665,10280,1364,29821,256,21792,46093,513]

theorem envBound19520 : H12AffineFastState.Bounded env19520 := by
  intro p hp
  have h : env19520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19519_19520 : H12AffineEnvironment.transform 6 9 env19519 = env19520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19519 == env19520) = true)

theorem identity19520 : scanCanonicalize (H12AffineFastState.compose env19520 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound19520 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,24908,23669,1024,21761,4161,21792,16,29790,8193,65,10589,5393,17665,10280,1364,29821,256,21792,24845,513]

theorem envBound19521 : H12AffineFastState.Bounded env19521 := by
  intro p hp
  have h : env19521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19520_19521 : H12AffineEnvironment.transform 14 21760 env19520 = env19521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env19520 == env19521) = true)

theorem identity19521 : scanCanonicalize (H12AffineFastState.compose env19521 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound19521 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,5393,10280,1024,8540,4161,8573,16,3,8193,65,10589,5393,12636,10280,1364,32,256,8573,5456,513]

theorem envBound19522 : H12AffineFastState.Bounded env19522 := by
  intro p hp
  have h : env19522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19521_19522 : H12AffineEnvironment.transform 13 13405 env19521 = env19522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env19521 == env19522) = true)

theorem identity19522 : scanCanonicalize (H12AffineFastState.compose env19522 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19522 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env19523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5393,2420,1024,0,4161,33,16,3,349,65,2049,5393,4096,2420,1364,32,256,33,5456,513]

theorem envBound19523 : H12AffineFastState.Bounded env19523 := by
  intro p hp
  have h : env19523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19522_19523 : H12AffineEnvironment.transform 12 348 env19522 = env19523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19522 == env19523) = true)

theorem identity19523 : scanCanonicalize (H12AffineFastState.compose env19523 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound19523 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,348,292,1,343,308,2420,1024,0,1124,33,16,3,349,65,2049,308,1061,2420,1364,32,256,33,373,513]

theorem envBound19524 : H12AffineFastState.Bounded env19524 := by
  intro p hp
  have h : env19524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19523_19524 : H12AffineEnvironment.transform 11 1061 env19523 = env19524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env19523 == env19524) = true)

theorem identity19524 : scanCanonicalize (H12AffineFastState.compose env19524 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound19524 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,1061,348,292,1,343,308,1124,1024,0,1124,33,16,3,349,65,1297,308,1061,1124,1364,32,256,33,373,513]

theorem envBound19525 : H12AffineFastState.Bounded env19525 := by
  intro p hp
  have h : env19525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19524_19525 : H12AffineEnvironment.transform 10 1296 env19524 = env19525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env19524 == env19525) = true)

theorem identity19525 : scanCanonicalize (H12AffineFastState.compose env19525 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound19525 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env19526 : List Nat := [2,4,8,16,32,33,9,256,512,1024,1296,1061,317,292,1,310,308,1029,1024,0,1029,33,16,3,316,32,1297,308,1061,1029,1333,32,256,33,276,513]

theorem envBound19526 : H12AffineFastState.Bounded env19526 := by
  intro p hp
  have h : env19526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19525_19526 : H12AffineEnvironment.transform 5 33 env19525 = env19526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env19525 == env19526) = true)

theorem identity19526 : scanCanonicalize (H12AffineFastState.compose env19526 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound19526 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env19527 : List Nat := [2,4,8,16,32,33,9,256,292,1024,1296,1061,317,292,1,310,308,1029,1024,0,1029,33,16,3,316,32,1297,308,1061,1029,1333,32,256,33,276,293]

theorem envBound19527 : H12AffineFastState.Bounded env19527 := by
  intro p hp
  have h : env19527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19526_19527 : H12AffineEnvironment.transform 8 292 env19526 = env19527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env19526 == env19527) = true)

theorem identity19527 : scanCanonicalize (H12AffineFastState.compose env19527 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19527 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19528 : List Nat := [2,4,8,16,1,0,9,256,261,1024,1296,1028,284,261,1,279,277,1029,1024,0,1029,0,16,3,285,1,1297,277,1028,1029,1300,1,256,0,276,260]

theorem envBound19528 : H12AffineFastState.Bounded env19528 := by
  intro p hp
  have h : env19528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19527_19528 : H12AffineEnvironment.transform 4 1 env19527 = env19528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19527 == env19528) = true)

theorem identity19528 : scanCanonicalize (H12AffineFastState.compose env19528 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19528 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env19529 : List Nat := [2,4,8,0,1,0,9,256,261,1024,1280,1028,268,261,1,263,261,1029,1024,0,1029,0,0,3,269,1,1281,261,1028,1029,1284,1,256,0,260,260]

theorem envBound19529 : H12AffineFastState.Bounded env19529 := by
  intro p hp
  have h : env19529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19528_19529 : H12AffineEnvironment.transform 3 0 env19528 = env19529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19528 == env19529) = true)

theorem identity19529 : scanCanonicalize (H12AffineFastState.compose env19529 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound19529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19530 : List Nat := [2,4,8,0,1,0,9,256,261,257,1,261,268,261,1,263,261,260,257,0,260,0,0,3,269,1,0,261,261,260,5,1,256,0,260,260]

theorem envBound19530 : H12AffineFastState.Bounded env19530 := by
  intro p hp
  have h : env19530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19529_19530 : H12AffineEnvironment.transform 9 257 env19529 = env19530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env19529 == env19530) = true)

theorem identity19530 : scanCanonicalize (H12AffineFastState.compose env19530 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19531 : List Nat := [2,4,8,0,1,0,9,4,1,5,1,1,8,1,1,3,1,0,5,0,0,0,0,3,9,1,0,1,1,0,5,1,4,0,0,0]

theorem envBound19531 : H12AffineFastState.Bounded env19531 := by
  intro p hp
  have h : env19531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19530_19531 : H12AffineEnvironment.transform 7 4 env19530 = env19531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19530 == env19531) = true)

def env19532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,98781,8328,65,6338877,2098513,17664,2111712,2102684,6349853,256,21792,46212,2175563]

theorem envBound19532 : H12AffineFastState.Bounded env19532 := by
  intro p hp
  have h : env19532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19491_19532 : H12AffineEnvironment.transform 17 190641 env19491 = env19532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env19491 == env19532) = true)

def env19533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,98781,8328,65,4237693,5393,17664,10400,1500,4256861,256,21792,46212,74251]

theorem envBound19533 : H12AffineFastState.Bounded env19533 := by
  intro p hp
  have h : env19533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19532_19533 : H12AffineEnvironment.transform 20 4160 env19532 = env19533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19532 == env19533) = true)

theorem identity19533 : scanCanonicalize (H12AffineFastState.compose env19533 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound19533 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190641,1024,32769,4160,4194304,16,21762,8328,65,4237693,5393,17664,10400,1500,4256861,256,21792,46212,63188]

theorem envBound19534 : H12AffineFastState.Bounded env19534 := by
  intro p hp
  have h : env19534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19533_19534 : H12AffineEnvironment.transform 15 54495 env19533 = env19534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env19533 == env19534) = true)

def env19535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4160,4194304,16,21762,8192,65,4237693,5393,17664,10280,1364,4256861,256,21792,46092,63068]

theorem envBound19535 : H12AffineFastState.Bounded env19535 := by
  intro p hp
  have h : env19535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19534_19535 : H12AffineEnvironment.transform 6 8 env19534 = env19535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19534 == env19535) = true)

theorem identity19535 : scanCanonicalize (H12AffineFastState.compose env19535 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound19535 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19536 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,32040,1024,32769,4160,4194304,16,21762,8192,65,4237693,5393,17664,10280,1364,4256861,256,21792,46092,63068]

theorem envBound19536 : H12AffineFastState.Bounded env19536 := by
  intro p hp
  have h : env19536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19535_19536 : H12AffineEnvironment.transform 16 38161 env19535 = env19536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env19535 == env19536) = true)

theorem identity19536 : scanCanonicalize (H12AffineFastState.compose env19536 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound19536 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,32040,1024,32769,4160,8573,16,21762,8192,65,34816,5393,17664,10280,1364,54560,256,21792,46092,63068]

theorem envBound19537 : H12AffineFastState.Bounded env19537 := by
  intro p hp
  have h : env19537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19536_19537 : H12AffineEnvironment.transform 21 8573 env19536 = env19537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env19536 == env19537) = true)

theorem identity19537 : scanCanonicalize (H12AffineFastState.compose env19537 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound19537 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env19538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,16401,32040,1024,21761,4160,8573,16,21762,8192,65,23808,5393,17664,10280,1364,32,256,21792,24844,9052]

theorem envBound19538 : H12AffineFastState.Bounded env19538 := by
  intro p hp
  have h : env19538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19537_19538 : H12AffineEnvironment.transform 14 21760 env19537 = env19538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env19537 == env19538) = true)

theorem identity19538 : scanCanonicalize (H12AffineFastState.compose env19538 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19538 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env19539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16401,23669,1024,21761,4160,32,16,21762,349,65,23808,5393,17664,2421,1364,32,256,21792,16465,513]

theorem envBound19539 : H12AffineFastState.Bounded env19539 := by
  intro p hp
  have h : env19539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19538_19539 : H12AffineEnvironment.transform 12 349 env19538 = env19539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19538 == env19539) = true)

theorem identity19539 : scanCanonicalize (H12AffineFastState.compose env19539 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19539 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19540 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21760,262,16401,23588,1024,21761,4113,32,16,21762,268,16,23808,5393,17664,2340,1285,32,256,21792,16384,513]

theorem envBound19540 : H12AffineFastState.Bounded env19540 := by
  intro p hp
  have h : env19540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19539_19540 : H12AffineEnvironment.transform 5 17 env19539 = env19540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19539 == env19540) = true)

theorem identity19540 : scanCanonicalize (H12AffineFastState.compose env19540 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 1792) := by decide +kernel

theorem selectedBound19540 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env19541 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,1792,4608,262,1809,6948,1024,4609,4113,32,16,4610,268,16,6656,5393,512,2340,1285,32,256,4640,1792,513]

theorem envBound19541 : H12AffineFastState.Bounded env19541 := by
  intro p hp
  have h : env19541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19540_19541 : H12AffineEnvironment.transform 13 1792 env19540 = env19541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1792 env19540 == env19541) = true)

def env19542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4160,4194304,16,21762,8193,65,4237693,5393,17664,10281,1365,4256861,256,21792,46093,63069]

theorem envBound19542 : H12AffineFastState.Bounded env19542 := by
  intro p hp
  have h : env19542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19534_19542 : H12AffineEnvironment.transform 6 9 env19534 = env19542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19534 == env19542) = true)

theorem identity19542 : scanCanonicalize (H12AffineFastState.compose env19542 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound19542 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56436,1024,32769,4160,4194304,16,21762,8193,65,4237693,5393,17664,10281,1365,4256861,256,21792,46093,63069]

theorem envBound19543 : H12AffineFastState.Bounded env19543 := by
  intro p hp
  have h : env19543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19542_19543 : H12AffineEnvironment.transform 16 13388 env19542 = env19543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env19542 == env19543) = true)

theorem identity19543 : scanCanonicalize (H12AffineFastState.compose env19543 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 54560) := by decide +kernel

theorem selectedBound19543 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env19544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56436,1024,32769,4160,54560,16,21762,8193,65,31837,5393,17664,10281,1365,8573,256,21792,46093,63069]

theorem envBound19544 : H12AffineFastState.Bounded env19544 := by
  intro p hp
  have h : env19544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19543_19544 : H12AffineEnvironment.transform 21 54560 env19543 = env19544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54560 env19543 == env19544) = true)

theorem identity19544 : scanCanonicalize (H12AffineFastState.compose env19544 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19544 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env19545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13388,10280,1024,29789,4160,8572,16,21762,8193,65,31837,5393,17664,10281,1365,8573,256,21792,16465,513]

theorem envBound19545 : H12AffineFastState.Bounded env19545 := by
  intro p hp
  have h : env19545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19544_19545 : H12AffineEnvironment.transform 14 29788 env19544 = env19545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19544 == env19545) = true)

theorem identity19545 : scanCanonicalize (H12AffineFastState.compose env19545 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8202,13388,10280,1024,81,4160,8572,16,8462,8193,65,2129,5393,12556,10281,1365,8573,256,8492,13405,513]

theorem envBound19546 : H12AffineFastState.Bounded env19546 := by
  intro p hp
  have h : env19546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19545_19546 : H12AffineEnvironment.transform 13 13324 env19545 = env19546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19545 == env19546) = true)

def env19547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,98781,8328,65,4237692,5392,17664,10401,1501,4256860,256,21792,46212,74250]

theorem envBound19547 : H12AffineFastState.Bounded env19547 := by
  intro p hp
  have h : env19547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19532_19547 : H12AffineEnvironment.transform 20 4161 env19532 = env19547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19532 == env19547) = true)

theorem identity19547 : scanCanonicalize (H12AffineFastState.compose env19547 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound19547 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,201967,17,98781,8328,65,245139,5392,17664,10401,1501,254131,256,21792,46212,74250]

theorem envBound19548 : H12AffineFastState.Bounded env19548 := by
  intro p hp
  have h : env19548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19547_19548 : H12AffineEnvironment.transform 21 201967 env19547 = env19548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env19547 == env19548) = true)

def env19549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,201831,17,98645,8192,65,245019,5392,17664,10281,1365,254011,256,21792,46092,74250]

theorem envBound19549 : H12AffineFastState.Bounded env19549 := by
  intro p hp
  have h : env19549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19548_19549 : H12AffineEnvironment.transform 6 8 env19548 = env19549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19548 == env19549) = true)

theorem identity19549 : scanCanonicalize (H12AffineFastState.compose env19549 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19549 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190521,1024,32769,4161,169264,17,2,8192,65,146508,5392,17664,10281,1365,156012,256,21792,46092,41821]

theorem envBound19550 : H12AffineFastState.Bounded env19550 := by
  intro p hp
  have h : env19550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19549_19550 : H12AffineEnvironment.transform 15 33111 env19549 = env19550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19549 == env19550) = true)

theorem identity19550 : scanCanonicalize (H12AffineFastState.compose env19550 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound19550 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,33111,131072,171060,1024,32769,4161,169264,17,2,8192,65,146508,5392,12557,10281,1365,136545,256,8493,46092,41821]

theorem envBound19551 : H12AffineFastState.Bounded env19551 := by
  intro p hp
  have h : env19551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19550_19551 : H12AffineEnvironment.transform 13 13325 env19550 = env19551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env19550 == env19551) = true)

theorem identity19551 : scanCanonicalize (H12AffineFastState.compose env19551 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound19551 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env19552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,33111,13673,43357,1024,32769,4161,41049,17,2,8192,65,2341,5392,12557,10281,1365,8200,256,8493,46092,41821]

theorem envBound19552 : H12AffineFastState.Bounded env19552 := by
  intro p hp
  have h : env19552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19551_19552 : H12AffineEnvironment.transform 16 13673 env19551 = env19552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env19551 == env19552) = true)

theorem identity19552 : scanCanonicalize (H12AffineFastState.compose env19552 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19552 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env19553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8202,13673,2048,1024,8540,4161,260,17,2,8192,65,2341,5392,12557,10281,1365,8200,256,8493,5457,512]

theorem envBound19553 : H12AffineFastState.Bounded env19553 := by
  intro p hp
  have h : env19553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19552_19553 : H12AffineEnvironment.transform 14 8541 env19552 = env19553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19552 == env19553) = true)

theorem identity19553 : scanCanonicalize (H12AffineFastState.compose env19553 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19553 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19554 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13325,8313,8202,13389,2048,1024,8312,4161,32,17,2,8192,65,2049,5172,12329,10281,1137,8200,36,8201,5237,512]

theorem envBound19554 : H12AffineFastState.Bounded env19554 := by
  intro p hp
  have h : env19554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19553_19554 : H12AffineEnvironment.transform 7 36 env19553 = env19554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19553 == env19554) = true)

theorem identity19554 : scanCanonicalize (H12AffineFastState.compose env19554 (packedSelected [2,3,5,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound19554 : packedSelected [2,3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env19555 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,88,5205,33,82,5141,2048,1024,32,4161,32,17,2,88,65,2049,5172,4209,2161,1137,80,36,81,5237,512]

theorem envBound19555 : H12AffineFastState.Bounded env19555 := by
  intro p hp
  have h : env19555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19554_19555 : H12AffineEnvironment.transform 12 88 env19554 = env19555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env19554 == env19555) = true)

theorem identity19555 : scanCanonicalize (H12AffineFastState.compose env19555 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19555 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19556 : List Nat := [2,4,8,16,0,64,8,4,512,1024,2048,4096,88,5205,1,82,5141,2048,1024,0,4161,0,17,2,88,65,2049,5140,4177,2129,1105,80,4,81,5205,512]

theorem envBound19556 : H12AffineFastState.Bounded env19556 := by
  intro p hp
  have h : env19556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19555_19556 : H12AffineEnvironment.transform 4 0 env19555 = env19556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19555 == env19556) = true)

def env19557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,201830,17,98644,8193,65,245018,5392,17664,10280,1364,254010,256,21792,46093,74250]

theorem envBound19557 : H12AffineFastState.Bounded env19557 := by
  intro p hp
  have h : env19557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19548_19557 : H12AffineEnvironment.transform 6 9 env19548 = env19557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19548 == env19557) = true)

theorem identity19557 : scanCanonicalize (H12AffineFastState.compose env19557 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19557 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4161,144493,17,41311,8193,65,171281,5392,17664,10280,1364,180273,256,21792,46093,513]

theorem envBound19558 : H12AffineFastState.Bounded env19558 := by
  intro p hp
  have h : env19558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19557_19558 : H12AffineEnvironment.transform 15 8203 env19557 = env19558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19557 == env19558) = true)

theorem identity19558 : scanCanonicalize (H12AffineFastState.compose env19558 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19558 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19559 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4113,144445,17,41231,8193,17,171281,5392,17664,10280,1284,180273,256,21792,46093,513]

theorem envBound19559 : H12AffineFastState.Bounded env19559 := by
  intro p hp
  have h : env19559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19558_19559 : H12AffineEnvironment.transform 5 16 env19558 = env19559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19558 == env19559) = true)

theorem identity19559 : scanCanonicalize (H12AffineFastState.compose env19559 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound19559 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env19560 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43048,1024,32769,4113,29741,17,41231,8193,17,56577,5392,17664,10280,1284,32801,256,21792,46093,513]

theorem envBound19560 : H12AffineFastState.Bounded env19560 := by
  intro p hp
  have h : env19560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19559_19560 : H12AffineEnvironment.transform 16 16400 env19559 = env19560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19559 == env19560) = true)

theorem identity19560 : scanCanonicalize (H12AffineFastState.compose env19560 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19560 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19561 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,2341,1024,8460,4113,29741,17,2,8193,17,31756,5392,17664,10280,1284,8492,256,21792,5376,513]

theorem envBound19561 : H12AffineFastState.Bounded env19561 := by
  intro p hp
  have h : env19561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19560_19561 : H12AffineEnvironment.transform 14 8461 env19560 = env19561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19560 == env19561) = true)

theorem identity19561 : scanCanonicalize (H12AffineFastState.compose env19561 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2829) := by decide +kernel

theorem selectedBound19561 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19562 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,2829,16384,2560,2822,16400,2341,1024,2561,4113,24352,17,2,2828,17,22273,5392,17664,805,1284,2593,256,21792,5376,513]

theorem envBound19562 : H12AffineFastState.Bounded env19562 := by
  intro p hp
  have h : env19562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19561_19562 : H12AffineEnvironment.transform 12 2829 env19561 = env19562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2829 env19561 == env19562) = true)

theorem identity19562 : scanCanonicalize (H12AffineFastState.compose env19562 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound19562 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19563 : List Nat := [2,4,8,16,32,16,9,256,512,1024,512,4096,269,16384,0,262,16400,805,1024,1,4113,21792,17,2,268,17,22273,5392,17664,805,1284,33,256,21792,5376,513]

theorem envBound19563 : H12AffineFastState.Bounded env19563 := by
  intro p hp
  have h : env19563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19562_19563 : H12AffineEnvironment.transform 10 512 env19562 = env19563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env19562 == env19563) = true)

theorem identity19563 : scanCanonicalize (H12AffineFastState.compose env19563 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19563 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19564 : List Nat := [2,4,8,16,32,16,9,256,512,1024,512,4096,269,5377,0,262,5393,805,1024,1,4113,33,17,2,268,17,512,5392,4097,805,1284,33,256,33,5376,513]

theorem envBound19564 : H12AffineFastState.Bounded env19564 := by
  intro p hp
  have h : env19564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19563_19564 : H12AffineEnvironment.transform 13 5377 env19563 = env19564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19563 == env19564) = true)

theorem identity19564 : scanCanonicalize (H12AffineFastState.compose env19564 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19565 : List Nat := [2,4,8,16,17,16,9,256,512,1024,512,4096,269,5377,0,262,5393,788,1024,1,4113,16,17,2,268,17,512,5392,4097,788,1284,16,256,16,5376,513]

theorem envBound19565 : H12AffineFastState.Bounded env19565 := by
  intro p hp
  have h : env19565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19564_19565 : H12AffineEnvironment.transform 4 17 env19564 = env19565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19564 == env19565) = true)

theorem identity19565 : scanCanonicalize (H12AffineFastState.compose env19565 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound19565 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19566 : List Nat := [2,4,8,16,17,16,9,256,512,516,512,4096,269,4869,0,262,4885,788,516,1,4113,16,17,2,268,17,512,4884,4097,788,768,16,256,16,4868,513]

theorem envBound19566 : H12AffineFastState.Bounded env19566 := by
  intro p hp
  have h : env19566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19565_19566 : H12AffineEnvironment.transform 9 516 env19565 = env19566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env19565 == env19566) = true)

theorem identity19566 : scanCanonicalize (H12AffineFastState.compose env19566 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound19566 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19567 : List Nat := [2,4,8,16,17,16,9,256,512,516,512,773,269,0,0,262,16,788,516,1,788,16,17,2,268,17,512,17,772,788,768,16,256,16,1,513]

theorem envBound19567 : H12AffineFastState.Bounded env19567 := by
  intro p hp
  have h : env19567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19566_19567 : H12AffineEnvironment.transform 11 773 env19566 = env19567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env19566 == env19567) = true)

theorem identity19567 : scanCanonicalize (H12AffineFastState.compose env19567 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound19567 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19568 : List Nat := [2,4,8,16,17,16,9,256,260,256,260,1,269,0,0,262,16,16,256,1,16,16,17,2,268,17,260,17,0,16,4,16,256,16,1,261]

theorem envBound19568 : H12AffineFastState.Bounded env19568 := by
  intro p hp
  have h : env19568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19567_19568 : H12AffineEnvironment.transform 8 260 env19567 = env19568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env19567 == env19568) = true)

theorem identity19568 : scanCanonicalize (H12AffineFastState.compose env19568 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19568 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19569 : List Nat := [2,4,8,16,17,16,9,20,16,20,16,1,25,0,0,18,16,16,20,1,16,16,17,2,24,17,16,17,0,16,4,16,20,16,1,17]

theorem envBound19569 : H12AffineFastState.Bounded env19569 := by
  intro p hp
  have h : env19569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19568_19569 : H12AffineEnvironment.transform 7 20 env19568 = env19569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19568 == env19569) = true)

theorem identity19569 : scanCanonicalize (H12AffineFastState.compose env19569 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19570 : List Nat := [2,4,8,0,1,0,9,4,0,4,0,1,9,0,0,2,0,0,4,1,0,0,1,2,8,1,0,1,0,0,4,0,4,0,1,1]

theorem envBound19570 : H12AffineFastState.Bounded env19570 := by
  intro p hp
  have h : env19570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19569_19570 : H12AffineEnvironment.transform 3 0 env19569 = env19570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19569 == env19570) = true)

def env19571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound19571 : H12AffineFastState.Bounded env19571 := by
  intro p hp
  have h : env19571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19422_19571 : H12AffineEnvironment.transform 18 1025 env19422 = env19571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19422 == env19571) = true)

theorem identity19571 : scanCanonicalize (H12AffineFastState.compose env19571 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297452) := by decide +kernel

theorem selectedBound19571 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297452,16777216,8328,65,21187052,18973837,2415804,149996,17108477,23160256,257,19221824,19246309,17050155]

theorem envBound19572 : H12AffineFastState.Bounded env19572 := by
  intro p hp
  have h : env19572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19571_19572 : H12AffineEnvironment.transform 22 297452 env19571 = env19572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297452 env19571 == env19572) = true)

def env19573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182764,1025,32769,2097152,4194304,147456,16777216,8328,65,21187052,18973837,2233680,149996,17024017,23160256,257,19104940,19096841,16966599]

theorem envBound19573 : H12AffineFastState.Bounded env19573 := by
  intro p hp
  have h : env19573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19572_19573 : H12AffineEnvironment.transform 17 182764 env19572 = env19573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182764 env19572 == env19573) = true)

def env19574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35188,1025,32769,2097152,4194304,152,16777216,8328,65,21039476,18973837,2119112,2420,16876681,23160256,257,18990132,18949521,16819039]

theorem envBound19574 : H12AffineFastState.Bounded env19574 := by
  intro p hp
  have h : env19574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19573_19574 : H12AffineEnvironment.transform 16 16536 env19573 = env19574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env19573 == env19574) = true)

theorem identity19574 : scanCanonicalize (H12AffineFastState.compose env19574 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound19574 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35188,1025,32769,2097152,4194304,152,138,8328,65,4262398,2196487,2119112,2420,99331,6382922,257,2213054,2172187,41941]

theorem envBound19575 : H12AffineFastState.Bounded env19575 := by
  intro p hp
  have h : env19575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19574_19575 : H12AffineEnvironment.transform 23 138 env19574 = env19575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env19574 == env19575) = true)

def env19576 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35108,1025,32769,2097152,4194304,152,138,8328,17,4262318,2196487,2119064,2340,99331,6382874,257,2213054,2172187,41861]

theorem envBound19576 : H12AffineFastState.Bounded env19576 := by
  intro p hp
  have h : env19576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19575_19576 : H12AffineEnvironment.transform 5 16 env19575 = env19576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19575 == env19576) = true)

def env19577 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13728,32768,65536,13624,35108,1025,32769,2097152,4194304,152,138,8328,17,4262318,2196487,2105400,2340,99331,6361274,257,2208030,2172187,41861]

theorem envBound19577 : H12AffineFastState.Bounded env19577 := by
  intro p hp
  have h : env19577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19576_19577 : H12AffineEnvironment.transform 13 13728 env19576 = env19577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env19576 == env19577) = true)

theorem identity19577 : scanCanonicalize (H12AffineFastState.compose env19577 (packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound19577 : packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS < 2^1333 := by decide +kernel

def env19578 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5156,32768,65536,5308,35108,1025,32769,2097152,4194304,152,138,268,17,4262318,2196487,2097596,2340,99331,6361274,257,2199706,2163871,33281]

theorem envBound19578 : H12AffineFastState.Bounded env19578 := by
  intro p hp
  have h : env19578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19577_19578 : H12AffineEnvironment.transform 12 388 env19577 = env19578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env19577 == env19578) = true)

theorem identity19578 : scanCanonicalize (H12AffineFastState.compose env19578 (packedSelected [3,4,5,12,14,16,19,20,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 2101524) := by decide +kernel

theorem selectedBound19578 : packedSelected [3,4,5,12,14,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env19579 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5156,32768,65536,5308,35108,1025,32769,2097152,2101524,152,138,268,17,2169018,2196487,2097596,2340,99331,65966,257,2199706,2163871,33281]

theorem envBound19579 : H12AffineFastState.Bounded env19579 := by
  intro p hp
  have h : env19579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19578_19579 : H12AffineEnvironment.transform 21 2101524 env19578 = env19579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101524 env19578 == env19579) = true)

theorem identity19579 : scanCanonicalize (H12AffineFastState.compose env19579 (packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19579 : packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env19580 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,65536,5173,35108,1025,32769,2097152,2101524,17,3,268,17,2168883,2196487,2097461,2340,99331,65831,257,2199571,2163734,33281]

theorem envBound19580 : H12AffineFastState.Bounded env19580 := by
  intro p hp
  have h : env19580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19579_19580 : H12AffineEnvironment.transform 6 9 env19579 = env19580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19579 == env19580) = true)

theorem identity19580 : scanCanonicalize (H12AffineFastState.compose env19580 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound19580 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19581 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33031,5173,35108,1025,32769,2097152,2101524,17,3,268,17,2136372,2098432,2097461,2340,1284,32800,257,2101524,2131217,33281]

theorem envBound19581 : H12AffineFastState.Bounded env19581 := by
  intro p hp
  have h : env19581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19580_19581 : H12AffineEnvironment.transform 15 33031 env19580 = env19581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env19580 == env19581) = true)

theorem identity19581 : scanCanonicalize (H12AffineFastState.compose env19581 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 37173) := by decide +kernel

theorem selectedBound19581 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env19582 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,32768,33031,5173,35108,1025,32769,37173,32801,17,3,268,17,2049,37941,36864,2340,1284,32800,257,32801,5156,33281]

theorem envBound19582 : H12AffineFastState.Bounded env19582 := by
  intro p hp
  have h : env19582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19581_19582 : H12AffineEnvironment.transform 20 37173 env19581 = env19582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37173 env19581 == env19582) = true)

theorem identity19582 : scanCanonicalize (H12AffineFastState.compose env19582 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound19582 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env19583 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,293,34,5173,2049,1025,292,4112,260,17,3,268,17,2049,5392,4389,2340,1284,261,257,260,5156,804]

theorem envBound19583 : H12AffineFastState.Bounded env19583 := by
  intro p hp
  have h : env19583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19582_19583 : H12AffineEnvironment.transform 14 293 env19582 = env19583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env19582 == env19583) = true)

theorem identity19583 : scanCanonicalize (H12AffineFastState.compose env19583 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19583 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env19584 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5125,260,3,5140,2049,1025,261,4112,260,17,3,268,17,2049,5392,4356,2309,1284,261,257,260,5125,773]

theorem envBound19584 : H12AffineFastState.Bounded env19584 := by
  intro p hp
  have h : env19584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19583_19584 : H12AffineEnvironment.transform 4 1 env19583 = env19584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19583 == env19584) = true)

def env19585 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13729,32768,65536,13625,35108,1025,32769,2097152,4194304,152,138,8328,17,4262318,2196487,2105401,2340,99331,6361275,257,2208031,2172187,41861]

theorem envBound19585 : H12AffineFastState.Bounded env19585 := by
  intro p hp
  have h : env19585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19576_19585 : H12AffineEnvironment.transform 13 13729 env19576 = env19585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env19576 == env19585) = true)

theorem identity19585 : scanCanonicalize (H12AffineFastState.compose env19585 (packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19585 : packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,17,19,22,27,32] rootPS < 2^1333 := by decide +kernel

def env19586 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,32768,65536,5173,35108,1025,32769,2097152,4194304,152,138,388,17,4262318,2196487,2097461,2340,99331,6361275,257,2199571,2163735,33417]

theorem envBound19586 : H12AffineFastState.Bounded env19586 := by
  intro p hp
  have h : env19586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19585_19586 : H12AffineEnvironment.transform 12 268 env19585 = env19586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19585 == env19586) = true)

theorem identity19586 : scanCanonicalize (H12AffineFastState.compose env19586 (packedSelected [0,1,3,4,7,8,10,12,15,22,24] rootPS)) = affineNative (2^(20+1) ^^^ 37308) := by decide +kernel

theorem selectedBound19586 : packedSelected [0,1,3,4,7,8,10,12,15,22,24] rootPS < 2^1333 := by decide +kernel

def env19587 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,32768,65536,5173,35108,1025,32769,37308,4194304,152,138,388,17,4262318,71099,37001,2340,99331,4292871,257,65967,103851,33417]

theorem envBound19587 : H12AffineFastState.Bounded env19587 := by
  intro p hp
  have h : env19587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19586_19587 : H12AffineEnvironment.transform 20 37308 env19586 = env19587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37308 env19586 == env19587) = true)

theorem identity19587 : scanCanonicalize (H12AffineFastState.compose env19587 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19587 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env19588 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,0,65536,5173,2340,1025,1,4540,4194304,152,138,388,17,4262318,71099,4233,2340,66563,4260103,257,65967,71083,649]

theorem envBound19588 : H12AffineFastState.Bounded env19588 := by
  intro p hp
  have h : env19588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19587_19588 : H12AffineEnvironment.transform 14 0 env19587 = env19588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19587 == env19588) = true)

theorem identity19588 : scanCanonicalize (H12AffineFastState.compose env19588 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(21+1) ^^^ 65967) := by decide +kernel

theorem selectedBound19588 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19589 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5293,0,65536,5173,2340,1025,1,4540,65967,152,138,388,17,2049,71099,4233,2340,66563,168,257,65967,71083,649]

theorem envBound19589 : H12AffineFastState.Bounded env19589 := by
  intro p hp
  have h : env19589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19588_19589 : H12AffineEnvironment.transform 21 65967 env19588 = env19589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65967 env19588 == env19589) = true)

def env19590 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35109,1025,32769,2097152,4194304,152,138,8328,16,4262319,2196487,2119065,2341,99331,6382875,257,2213054,2172187,41860]

theorem envBound19590 : H12AffineFastState.Bounded env19590 := by
  intro p hp
  have h : env19590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19575_19590 : H12AffineEnvironment.transform 5 17 env19575 = env19590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19575 == env19590) = true)

theorem identity19590 : scanCanonicalize (H12AffineFastState.compose env19590 (packedSelected [2,4,6,8,10,17,18,19,20,22,23,26,28] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound19590 : packedSelected [2,4,6,8,10,17,18,19,20,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env19591 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35109,1025,32769,2097152,73771,152,138,8328,16,10628,2196487,2119065,2341,99331,2114864,257,2213054,2172187,41860]

theorem envBound19591 : H12AffineFastState.Bounded env19591 := by
  intro p hp
  have h : env19591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19590_19591 : H12AffineEnvironment.transform 21 73771 env19590 = env19591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env19590 == env19591) = true)

def env19592 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35077,1025,32769,2097152,73739,152,138,8328,16,10628,2196487,2119065,2309,99331,2114832,257,2213022,2172187,41860]

theorem envBound19592 : H12AffineFastState.Bounded env19592 := by
  intro p hp
  have h : env19592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19591_19592 : H12AffineEnvironment.transform 4 0 env19591 = env19592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19591 == env19592) = true)

theorem identity19592 : scanCanonicalize (H12AffineFastState.compose env19592 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19592 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19593 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35077,1025,32769,2097152,73739,16,2,8192,16,10508,2196487,2118929,2309,99331,2114832,257,2212886,2172187,41740]

theorem envBound19593 : H12AffineFastState.Bounded env19593 := by
  intro p hp
  have h : env19593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19592_19593 : H12AffineEnvironment.transform 6 8 env19592 = env19593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19592 == env19593) = true)

theorem identity19593 : scanCanonicalize (H12AffineFastState.compose env19593 (packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound19593 : packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS < 2^1333 := by decide +kernel

def env19594 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35077,1025,32769,17681,73739,16,2,8192,16,10508,114966,4096,2309,99331,1,257,98567,90122,41740]

theorem envBound19594 : H12AffineFastState.Bounded env19594 := by
  intro p hp
  have h : env19594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19593_19594 : H12AffineEnvironment.transform 20 17681 env19593 = env19594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env19593 == env19594) = true)

theorem identity19594 : scanCanonicalize (H12AffineFastState.compose env19594 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound19594 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env19595 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,16400,10249,1025,8461,17681,73739,16,2,8192,16,10508,90138,4096,2309,75023,1,257,73739,90122,512]

theorem envBound19595 : H12AffineFastState.Bounded env19595 := by
  intro p hp
  have h : env19595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19594_19595 : H12AffineEnvironment.transform 14 8460 env19594 = env19595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env19594 == env19595) = true)

theorem identity19595 : scanCanonicalize (H12AffineFastState.compose env19595 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 19478) := by decide +kernel

theorem selectedBound19595 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env19596 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8460,19478,16400,10249,1025,8461,17681,27677,16,2,8192,16,10508,11276,4096,2309,26905,1,257,27677,11292,512]

theorem envBound19596 : H12AffineFastState.Bounded env19596 := by
  intro p hp
  have h : env19596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19595_19596 : H12AffineEnvironment.transform 15 19478 env19595 = env19596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19478 env19595 == env19596) = true)

theorem identity19596 : scanCanonicalize (H12AffineFastState.compose env19596 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound19596 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env19597 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,7433,16384,7173,19478,16400,5376,1025,7172,17681,20756,16,2,7433,16,5125,4357,4096,2309,21520,1,257,20756,4373,512]

theorem envBound19597 : H12AffineFastState.Bounded env19597 := by
  intro p hp
  have h : env19597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19596_19597 : H12AffineEnvironment.transform 12 7433 env19596 = env19597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env19596 == env19597) = true)

theorem identity19597 : scanCanonicalize (H12AffineFastState.compose env19597 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19597 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env19598 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,6169,16384,6421,18694,16400,4112,273,6420,16385,20756,16,2,6169,16,4373,4357,4096,2309,20736,1,257,20756,4373,512]

theorem envBound19598 : H12AffineFastState.Bounded env19598 := by
  intro p hp
  have h : env19598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19597_19598 : H12AffineEnvironment.transform 9 272 env19597 = env19598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19597 == env19598) = true)

theorem identity19598 : scanCanonicalize (H12AffineFastState.compose env19598 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound19598 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env19599 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,6169,2049,6421,263,2065,4112,273,6420,2048,6421,16,2,6169,16,4373,4357,4096,2309,6401,1,257,6421,4373,512]

theorem envBound19599 : H12AffineFastState.Bounded env19599 := by
  intro p hp
  have h : env19599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19598_19599 : H12AffineEnvironment.transform 13 2049 env19598 = env19599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env19598 == env19599) = true)

theorem identity19599 : scanCanonicalize (H12AffineFastState.compose env19599 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound19599 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env19600 : List Nat := [2,4,8,16,0,17,8,256,512,272,260,4096,4381,261,4113,263,277,4112,273,4112,260,4113,16,2,4381,16,4373,4357,4096,1,4101,1,257,4113,4373,512]

theorem envBound19600 : H12AffineFastState.Bounded env19600 := by
  intro p hp
  have h : env19600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19599_19600 : H12AffineEnvironment.transform 10 260 env19599 = env19600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env19599 == env19600) = true)

theorem identity19600 : scanCanonicalize (H12AffineFastState.compose env19600 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19600 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env19601 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,4096,4121,1,4113,3,17,4112,21,4112,0,4113,16,2,4121,16,4113,4097,4096,1,4101,1,5,4113,4113,512]

theorem envBound19601 : H12AffineFastState.Bounded env19601 := by
  intro p hp
  have h : env19601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19600_19601 : H12AffineEnvironment.transform 7 4 env19600 = env19601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19600 == env19601) = true)

def env19602 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35076,1025,32769,2097152,73738,152,138,8328,16,10628,2196487,2119065,2308,99331,2114833,257,2213023,2172187,41860]

theorem envBound19602 : H12AffineFastState.Bounded env19602 := by
  intro p hp
  have h : env19602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19591_19602 : H12AffineEnvironment.transform 4 1 env19591 = env19602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19591 == env19602) = true)

theorem identity19602 : scanCanonicalize (H12AffineFastState.compose env19602 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19602 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19603 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,16536,10249,1025,8460,2097152,73738,152,138,8328,16,10628,2172170,2119065,2308,75022,2114833,257,2188690,2172187,649]

theorem envBound19603 : H12AffineFastState.Bounded env19603 := by
  intro p hp
  have h : env19603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19602_19603 : H12AffineEnvironment.transform 14 8461 env19602 = env19603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19602 == env19603) = true)

theorem identity19603 : scanCanonicalize (H12AffineFastState.compose env19603 (packedSelected [3,4,5,9,10,11,17] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound19603 : packedSelected [3,4,5,9,10,11,17] rootPS < 2^1333 := by decide +kernel

def env19604 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,8461,65536,16536,10249,1025,8460,82967,73738,152,138,8328,16,10628,24861,70030,2308,75022,65798,257,8581,24844,649]

theorem envBound19604 : H12AffineFastState.Bounded env19604 := by
  intro p hp
  have h : env19604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19603_19604 : H12AffineEnvironment.transform 20 82967 env19603 = env19604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env19603 == env19604) = true)

theorem identity19604 : scanCanonicalize (H12AffineFastState.compose env19604 (packedSelected [0,1,3,5,7,8,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19604 : packedSelected [0,1,3,5,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env19605 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,389,16384,136,65536,16536,2444,1025,137,82967,65935,152,138,269,16,2049,16536,70030,2308,66699,65798,257,0,16521,649]

theorem envBound19605 : H12AffineFastState.Bounded env19605 := by
  intro p hp
  have h : env19605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19604_19605 : H12AffineEnvironment.transform 12 389 env19604 = env19605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19604 == env19605) = true)

theorem identity19605 : scanCanonicalize (H12AffineFastState.compose env19605 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound19605 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19606 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,389,16384,136,398,16536,2444,1025,137,17817,1,152,138,269,16,2049,16536,4096,2308,1285,136,257,0,16521,649]

theorem envBound19606 : H12AffineFastState.Bounded env19606 := by
  intro p hp
  have h : env19606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19605_19606 : H12AffineEnvironment.transform 15 398 env19605 = env19606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env19605 == env19606) = true)

theorem identity19606 : scanCanonicalize (H12AffineFastState.compose env19606 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19606 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env19607 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,268,16384,1,263,16401,2309,1025,0,17680,1,17,3,269,16,2049,16401,4096,2308,1285,1,257,0,16384,512]

theorem envBound19607 : H12AffineFastState.Bounded env19607 := by
  intro p hp
  have h : env19607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19606_19607 : H12AffineEnvironment.transform 6 9 env19606 = env19607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19606 == env19607) = true)

theorem identity19607 : scanCanonicalize (H12AffineFastState.compose env19607 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19608 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,16384,1,2,16401,2048,1025,0,17429,1,17,3,8,16,2049,16401,4096,2049,1024,1,4,0,16384,512]

theorem envBound19608 : H12AffineFastState.Bounded env19608 := by
  intro p hp
  have h : env19608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19607_19608 : H12AffineEnvironment.transform 7 5 env19607 = env19608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19607 == env19608) = true)

theorem identity19608 : scanCanonicalize (H12AffineFastState.compose env19608 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound19608 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19609 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5125,1,2,5140,2048,1025,0,4112,1,17,3,8,16,2049,5140,4096,2049,1024,1,4,0,5125,512]

theorem envBound19609 : H12AffineFastState.Bounded env19609 := by
  intro p hp
  have h : env19609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19608_19609 : H12AffineEnvironment.transform 13 5125 env19608 = env19609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env19608 == env19609) = true)

def env19610 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1045,1,2,1028,2048,1025,0,0,1,17,3,8,16,2049,1028,16,2049,1024,1,4,0,1045,512]

theorem envBound19610 : H12AffineFastState.Bounded env19610 := by
  intro p hp
  have h : env19610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19609_19610 : H12AffineEnvironment.transform 11 16 env19609 = env19610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env19609 == env19610) = true)

theorem identity19610 : scanCanonicalize (H12AffineFastState.compose env19610 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound19610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19611 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,9,0,1,2,17,2048,20,0,0,1,17,3,8,16,2049,17,16,2049,21,1,4,0,0,512]

theorem envBound19611 : H12AffineFastState.Bounded env19611 := by
  intro p hp
  have h : env19611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19610_19611 : H12AffineEnvironment.transform 9 21 env19610 = env19611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19610 == env19611) = true)

theorem identity19611 : scanCanonicalize (H12AffineFastState.compose env19611 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound19611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19612 : List Nat := [2,4,8,16,1,17,9,5,512,21,543,16,9,0,1,2,17,543,20,0,0,1,17,3,8,16,542,17,16,542,21,1,4,0,0,512]

theorem envBound19612 : H12AffineFastState.Bounded env19612 := by
  intro p hp
  have h : env19612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19611_19612 : H12AffineEnvironment.transform 10 543 env19611 = env19612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env19611 == env19612) = true)

def leafEnv19612 : List Nat := [2,4,8,16,1,17,9,5,512,21,543,16,9,0,1,2,17,543,20,0,0,1,17,3,20,8,1,16,542,17,16,542,21,1,4,0,5,3,0,512,1,0,0]

def active19612 : List Nat := [0,1,2,3,8]

def tree19612 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19612 : H12WitnessSearch.Good tree19612 := H12GlobalWitnessIndex.good

theorem leafIdentity19612 : H12AffineFastState.composeSystem env19612 rootObs = leafEnv19612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19612 rootObs == leafEnv19612) = true)

theorem terminalChecked19612 : H12PackedTerminal.terminalCheckFast leafEnv19612 active19612 tree19612 = true := by decide +kernel

def env19613 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1044,1,2,1029,2048,1025,0,1,1,17,3,8,16,2049,1029,17,2049,1024,1,4,0,1044,512]

theorem envBound19613 : H12AffineFastState.Bounded env19613 := by
  intro p hp
  have h : env19613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19609_19613 : H12AffineEnvironment.transform 11 17 env19609 = env19613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19609 == env19613) = true)

def env19614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35189,1025,32769,2097152,4194304,153,16777216,8328,65,21039477,18973837,2119113,2421,16876680,23160256,257,18990133,18949520,16819038]

theorem envBound19614 : H12AffineFastState.Bounded env19614 := by
  intro p hp
  have h : env19614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19573_19614 : H12AffineEnvironment.transform 16 16537 env19573 = env19614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env19573 == env19614) = true)

theorem identity19614 : scanCanonicalize (H12AffineFastState.compose env19614 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41431) := by decide +kernel

theorem selectedBound19614 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35189,1025,32769,2097152,4194304,153,41431,8328,65,4303010,2172250,2119113,2421,75103,6407191,257,2188770,2196551,649]

theorem envBound19615 : H12AffineFastState.Bounded env19615 := by
  intro p hp
  have h : env19615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19614_19615 : H12AffineEnvironment.transform 23 41431 env19614 = env19615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41431 env19614 == env19615) = true)

def env19616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302890,2172250,2118977,2421,75103,6407191,257,2188650,2196551,513]

theorem envBound19616 : H12AffineFastState.Bounded env19616 := by
  intro p hp
  have h : env19616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19615_19616 : H12AffineEnvironment.transform 6 8 env19615 = env19616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19615 == env19616) = true)

theorem identity19616 : scanCanonicalize (H12AffineFastState.compose env19616 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound19616 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env19617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115735,4194304,17,41311,8192,65,4302890,57677,102742,2421,75103,4194304,257,41341,16464,513]

theorem envBound19617 : H12AffineFastState.Bounded env19617 := by
  intro p hp
  have h : env19617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19616_19617 : H12AffineEnvironment.transform 20 115735 env19616 = env19617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env19616 == env19617) = true)

theorem identity19617 : scanCanonicalize (H12AffineFastState.compose env19617 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19617 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env19618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91466,4194304,17,2,8192,65,4262263,16400,77835,2421,75103,4194304,257,32,16464,513]

theorem envBound19618 : H12AffineFastState.Bounded env19618 := by
  intro p hp
  have h : env19618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19617_19618 : H12AffineEnvironment.transform 14 8541 env19617 = env19618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19617 == env19618) = true)

theorem identity19618 : scanCanonicalize (H12AffineFastState.compose env19618 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19618 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env19619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91466,32,17,2,8192,65,67927,16400,77835,2421,75103,32,257,32,16464,513]

theorem envBound19619 : H12AffineFastState.Bounded env19619 := by
  intro p hp
  have h : env19619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19618_19619 : H12AffineEnvironment.transform 21 32 env19618 = env19619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19618 == env19619) = true)

def env19620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,41310,8193,65,4302891,2172250,2118976,2421,75103,6407191,257,2188651,2196551,512]

theorem envBound19620 : H12AffineFastState.Bounded env19620 := by
  intro p hp
  have h : env19620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19615_19620 : H12AffineEnvironment.transform 6 9 env19615 = env19620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19615 == env19620) = true)

theorem identity19620 : scanCanonicalize (H12AffineFastState.compose env19620 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound19620 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,17460,4194304,16,41310,8193,65,4302891,90478,4468,2421,75103,4292643,257,74079,114803,512]

theorem envBound19621 : H12AffineFastState.Bounded env19621 := by
  intro p hp
  have h : env19621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19620_19621 : H12AffineEnvironment.transform 20 17460 env19620 = env19621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env19620 == env19621) = true)

theorem identity19621 : scanCanonicalize (H12AffineFastState.compose env19621 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 33142) := by decide +kernel

theorem selectedBound19621 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33142,16400,35189,1025,32769,17460,4194304,16,41310,8193,65,4204893,57368,4468,2421,42025,4194645,257,41001,16645,512]

theorem envBound19622 : H12AffineFastState.Bounded env19622 := by
  intro p hp
  have h : env19622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19621_19622 : H12AffineEnvironment.transform 15 33142 env19621 = env19622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33142 env19621 == env19622) = true)

theorem identity19622 : scanCanonicalize (H12AffineFastState.compose env19622 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound19622 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env19623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33142,16400,35189,1025,32769,17460,41341,16,41310,8193,65,34848,57368,4468,2421,42025,41000,257,41001,16645,512]

theorem envBound19623 : H12AffineFastState.Bounded env19623 := by
  intro p hp
  have h : env19623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19622_19623 : H12AffineEnvironment.transform 21 41341 env19622 = env19623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env19622 == env19623) = true)

theorem identity19623 : scanCanonicalize (H12AffineFastState.compose env19623 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19623 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8315,16400,10360,1025,8460,17460,112,16,83,8193,65,10541,16661,4468,2421,1316,293,257,292,16645,512]

theorem envBound19624 : H12AffineFastState.Bounded env19624 := by
  intro p hp
  have h : env19624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19623_19624 : H12AffineEnvironment.transform 14 8461 env19623 = env19624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19623 == env19624) = true)

theorem identity19624 : scanCanonicalize (H12AffineFastState.compose env19624 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,17,18,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19624 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env19625 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8192,16384,8201,8315,16400,10360,1025,8200,17460,112,16,83,8193,65,10281,16401,4208,2161,1056,33,5,32,16385,512]

theorem envBound19625 : H12AffineFastState.Bounded env19625 := by
  intro p hp
  have h : env19625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19624_19625 : H12AffineEnvironment.transform 7 4 env19624 = env19625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19624 == env19625) = true)

theorem identity19625 : scanCanonicalize (H12AffineFastState.compose env19625 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound19625 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env19626 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8,16384,1,115,16400,2160,1025,0,17460,112,16,83,9,65,2081,16401,4208,2161,1056,33,5,32,16385,512]

theorem envBound19626 : H12AffineFastState.Bounded env19626 := by
  intro p hp
  have h : env19626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19625_19626 : H12AffineEnvironment.transform 12 8 env19625 = env19626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env19625 == env19626) = true)

theorem identity19626 : scanCanonicalize (H12AffineFastState.compose env19626 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19626 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19627 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,16384,1,35,16400,2080,1025,0,17460,32,16,3,9,17,2081,16401,4128,2081,1056,33,5,32,16385,512]

theorem envBound19627 : H12AffineFastState.Bounded env19627 := by
  intro p hp
  have h : env19627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19626_19627 : H12AffineEnvironment.transform 5 16 env19626 = env19627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19626 == env19627) = true)

theorem identity19627 : scanCanonicalize (H12AffineFastState.compose env19627 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19627 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19628 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,4096,8,16384,1,3,16400,2048,1025,0,17428,0,16,3,9,17,2049,16401,4096,2049,1024,1,5,0,16385,512]

theorem envBound19628 : H12AffineFastState.Bounded env19628 := by
  intro p hp
  have h : env19628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19627_19628 : H12AffineEnvironment.transform 4 0 env19627 = env19628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19627 == env19628) = true)

theorem identity19628 : scanCanonicalize (H12AffineFastState.compose env19628 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound19628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19629 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,4096,8,5125,1,3,5141,2048,1025,0,4113,0,16,3,9,17,2049,5140,4096,2049,1024,1,5,0,5124,512]

theorem envBound19629 : H12AffineFastState.Bounded env19629 := by
  intro p hp
  have h : env19629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19628_19629 : H12AffineEnvironment.transform 13 5125 env19628 = env19629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env19628 == env19629) = true)

theorem identity19629 : scanCanonicalize (H12AffineFastState.compose env19629 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound19629 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19630 : List Nat := [2,4,8,16,0,16,9,4,512,1024,522,4096,8,5125,1,3,5141,522,1025,0,4113,0,16,3,9,17,523,5140,4096,523,1024,1,5,0,5124,512]

theorem envBound19630 : H12AffineFastState.Bounded env19630 := by
  intro p hp
  have h : env19630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19629_19630 : H12AffineEnvironment.transform 10 522 env19629 = env19630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env19629 == env19630) = true)

def env19631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182765,1025,32769,2097152,4194304,147457,16777216,8328,65,21187052,18973837,2233681,149996,17024016,23160256,257,19104941,19096840,16966598]

theorem envBound19631 : H12AffineFastState.Bounded env19631 := by
  intro p hp
  have h : env19631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19572_19631 : H12AffineEnvironment.transform 17 182765 env19572 = env19631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182765 env19572 == env19631) = true)

theorem identity19631 : scanCanonicalize (H12AffineFastState.compose env19631 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound19631 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182765,1025,32769,2097152,4194304,147457,188871,8328,65,4302891,2319690,2233681,149996,75223,6521863,257,2188650,2196687,513]

theorem envBound19632 : H12AffineFastState.Bounded env19632 := by
  intro p hp
  have h : env19632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19631_19632 : H12AffineEnvironment.transform 23 188871 env19631 = env19632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env19631 == env19632) = true)

def env19633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35189,1025,32769,2097152,4194304,153,41311,8328,65,4302891,2172370,2119113,2420,75223,6407327,257,2188650,2196687,513]

theorem envBound19633 : H12AffineFastState.Bounded env19633 := by
  intro p hp
  have h : env19633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19632_19633 : H12AffineEnvironment.transform 16 16536 env19632 = env19633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env19632 == env19633) = true)

theorem identity19633 : scanCanonicalize (H12AffineFastState.compose env19633 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19633 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302891,2172250,2118977,2420,75103,6407191,257,2188650,2196551,513]

theorem envBound19634 : H12AffineFastState.Bounded env19634 := by
  intro p hp
  have h : env19634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19633_19634 : H12AffineEnvironment.transform 6 8 env19633 = env19634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19633 == env19634) = true)

theorem identity19634 : scanCanonicalize (H12AffineFastState.compose env19634 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound19634 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115735,4194304,17,41311,8192,65,4302891,57677,102742,2420,75103,4194304,257,41341,16464,513]

theorem envBound19635 : H12AffineFastState.Bounded env19635 := by
  intro p hp
  have h : env19635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19634_19635 : H12AffineEnvironment.transform 20 115735 env19634 = env19635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env19634 == env19635) = true)

def env19636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91199,4194304,17,375,8192,65,4261891,16741,78206,2420,75103,4194304,257,341,16464,513]

theorem envBound19636 : H12AffineFastState.Bounded env19636 := by
  intro p hp
  have h : env19636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19635_19636 : H12AffineEnvironment.transform 14 8232 env19635 = env19636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env19635 == env19636) = true)

theorem identity19636 : scanCanonicalize (H12AffineFastState.compose env19636 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19636 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env19637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,0,65536,16400,2421,1025,1,82967,4194304,17,375,40,65,4261891,16741,69974,2420,66935,4194304,257,341,16464,513]

theorem envBound19637 : H12AffineFastState.Bounded env19637 := by
  intro p hp
  have h : env19637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19636_19637 : H12AffineEnvironment.transform 12 40 env19636 = env19637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19636 == env19637) = true)

theorem identity19637 : scanCanonicalize (H12AffineFastState.compose env19637 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19637 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,0,65536,16400,2421,1025,1,82967,32,17,375,40,65,67619,16741,69974,2420,66935,32,257,341,16464,513]

theorem envBound19638 : H12AffineFastState.Bounded env19638 := by
  intro p hp
  have h : env19638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19637_19638 : H12AffineEnvironment.transform 21 32 env19637 = env19638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19637 == env19638) = true)

theorem identity19638 : scanCanonicalize (H12AffineFastState.compose env19638 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19638 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env19639 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,0,65536,16400,2048,1025,1,82967,32,17,2,40,65,67619,16400,69667,2049,66562,32,116,32,16464,513]

theorem envBound19639 : H12AffineFastState.Bounded env19639 := by
  intro p hp
  have h : env19639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19638_19639 : H12AffineEnvironment.transform 7 117 env19638 = env19639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19638 == env19639) = true)

theorem identity19639 : scanCanonicalize (H12AffineFastState.compose env19639 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound19639 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19640 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,0,35,16400,2048,1025,1,17460,32,17,2,40,65,2048,16400,4096,2049,1057,32,116,32,16464,513]

theorem envBound19640 : H12AffineFastState.Bounded env19640 := by
  intro p hp
  have h : env19640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19639_19640 : H12AffineEnvironment.transform 15 35 env19639 = env19640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env19639 == env19640) = true)

theorem identity19640 : scanCanonicalize (H12AffineFastState.compose env19640 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound19640 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19641 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1140,40,16384,0,35,16400,2048,1025,1,17460,32,17,2,40,65,2048,16400,1140,2049,1057,32,116,32,16464,513]

theorem envBound19641 : H12AffineFastState.Bounded env19641 := by
  intro p hp
  have h : env19641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19640_19641 : H12AffineEnvironment.transform 11 1140 env19640 = env19641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env19640 == env19641) = true)

theorem identity19641 : scanCanonicalize (H12AffineFastState.compose env19641 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 3685) := by decide +kernel

theorem selectedBound19641 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19642 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1140,40,3685,0,35,3701,2048,1025,1,2641,32,17,2,40,65,2048,3701,1140,2049,1057,32,116,32,3637,513]

theorem envBound19642 : H12AffineFastState.Bounded env19642 := by
  intro p hp
  have h : env19642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19641_19642 : H12AffineEnvironment.transform 13 3685 env19641 = env19642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3685 env19641 == env19642) = true)

theorem identity19642 : scanCanonicalize (H12AffineFastState.compose env19642 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19642 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19643 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1061,40,3636,0,35,3620,2048,1025,1,2560,32,17,2,40,16,2048,3620,1061,2049,1057,32,37,32,3637,513]

theorem envBound19643 : H12AffineFastState.Bounded env19643 := by
  intro p hp
  have h : env19643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19642_19643 : H12AffineEnvironment.transform 5 17 env19642 = env19643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19642 == env19643) = true)

theorem identity19643 : scanCanonicalize (H12AffineFastState.compose env19643 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19644 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1028,9,3605,0,2,3589,2048,1025,1,2560,1,17,2,9,16,2048,3589,1028,2049,1024,1,4,1,3604,513]

theorem envBound19644 : H12AffineFastState.Bounded env19644 := by
  intro p hp
  have h : env19644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19643_19644 : H12AffineEnvironment.transform 4 1 env19643 = env19644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19643 == env19644) = true)

theorem identity19644 : scanCanonicalize (H12AffineFastState.compose env19644 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound19644 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19645 : List Nat := [2,4,8,16,1,17,8,5,512,516,2048,512,9,2065,0,2,2049,2048,517,1,2560,1,17,2,9,16,2048,2049,512,2049,516,1,4,1,2064,513]

theorem envBound19645 : H12AffineFastState.Bounded env19645 := by
  intro p hp
  have h : env19645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19644_19645 : H12AffineEnvironment.transform 9 516 env19644 = env19645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env19644 == env19645) = true)

theorem identity19645 : scanCanonicalize (H12AffineFastState.compose env19645 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19645 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19646 : List Nat := [2,4,8,16,1,17,8,5,1,5,2048,1,9,2065,0,2,2049,2048,4,1,2049,1,17,2,9,16,2048,2049,1,2049,5,1,4,1,2064,0]

theorem envBound19646 : H12AffineFastState.Bounded env19646 := by
  intro p hp
  have h : env19646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19645_19646 : H12AffineEnvironment.transform 8 1 env19645 = env19646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19645 == env19646) = true)

theorem identity19646 : scanCanonicalize (H12AffineFastState.compose env19646 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound19646 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env19647 : List Nat := [2,4,8,16,1,17,8,5,1,5,16,1,9,1,0,2,17,16,4,1,17,1,17,2,9,16,16,17,1,17,5,1,4,1,0,0]

theorem envBound19647 : H12AffineFastState.Bounded env19647 := by
  intro p hp
  have h : env19647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19646_19647 : H12AffineEnvironment.transform 10 16 env19646 = env19647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env19646 == env19647) = true)

def env19648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91198,4194304,17,374,8192,65,4261890,16740,78207,2420,75103,4194304,257,340,16464,513]

theorem envBound19648 : H12AffineFastState.Bounded env19648 := by
  intro p hp
  have h : env19648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19635_19648 : H12AffineEnvironment.transform 14 8233 env19635 = env19648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env19635 == env19648) = true)

theorem identity19648 : scanCanonicalize (H12AffineFastState.compose env19648 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19648 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env19649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,372,65536,16400,2049,1025,373,83299,4194304,17,374,349,65,4261890,16740,69666,2420,66562,4194304,257,340,16464,513]

theorem envBound19649 : H12AffineFastState.Bounded env19649 := by
  intro p hp
  have h : env19649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19648_19649 : H12AffineEnvironment.transform 12 349 env19648 = env19649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19648 == env19649) = true)

theorem identity19649 : scanCanonicalize (H12AffineFastState.compose env19649 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19649 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env19650 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,0,65536,16400,2049,1025,1,82967,4194304,17,2,41,65,4261890,16400,69666,2048,66562,4194304,117,32,16464,513]

theorem envBound19650 : H12AffineFastState.Bounded env19650 := by
  intro p hp
  have h : env19650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19649_19650 : H12AffineEnvironment.transform 7 116 env19649 = env19650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19649 == env19650) = true)

theorem identity19650 : scanCanonicalize (H12AffineFastState.compose env19650 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound19650 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19651 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,0,34,16400,2049,1025,1,17461,4194304,17,2,41,65,4196384,16400,4096,2048,1056,4194304,117,32,16464,513]

theorem envBound19651 : H12AffineFastState.Bounded env19651 := by
  intro p hp
  have h : env19651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19650_19651 : H12AffineEnvironment.transform 15 34 env19650 = env19651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env19650 == env19651) = true)

theorem identity19651 : scanCanonicalize (H12AffineFastState.compose env19651 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19651 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19652 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,0,34,16400,2049,1025,1,17461,4194304,17,2,41,16,4196384,16400,4096,2048,1056,4194304,36,32,16385,513]

theorem envBound19652 : H12AffineFastState.Bounded env19652 := by
  intro p hp
  have h : env19652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19651_19652 : H12AffineEnvironment.transform 5 17 env19651 = env19652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19651 == env19652) = true)

theorem identity19652 : scanCanonicalize (H12AffineFastState.compose env19652 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound19652 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19653 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5172,2049,1025,1,4113,4194304,17,2,41,16,4196384,5172,4096,2048,1056,4194304,36,32,5157,513]

theorem envBound19653 : H12AffineFastState.Bounded env19653 := by
  intro p hp
  have h : env19653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19652_19653 : H12AffineEnvironment.transform 13 5156 env19652 = env19653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env19652 == env19653) = true)

theorem identity19653 : scanCanonicalize (H12AffineFastState.compose env19653 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound19653 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19654 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5172,2049,1025,1,4113,33,17,2,41,16,2049,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound19654 : H12AffineFastState.Bounded env19654 := by
  intro p hp
  have h : env19654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19653_19654 : H12AffineEnvironment.transform 21 33 env19653 = env19654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env19653 == env19654) = true)

def env19655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35188,1025,32769,2097152,4194304,152,41310,8328,65,4302891,2172371,2119112,2421,75223,6407326,257,2188650,2196687,513]

theorem envBound19655 : H12AffineFastState.Bounded env19655 := by
  intro p hp
  have h : env19655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19632_19655 : H12AffineEnvironment.transform 16 16537 env19632 = env19655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env19632 == env19655) = true)

theorem identity19655 : scanCanonicalize (H12AffineFastState.compose env19655 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound19655 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1025,8661,2097152,4194304,152,138,8328,65,4262399,2172371,2119112,2421,75223,6382922,257,2188650,2172187,513]

theorem envBound19656 : H12AffineFastState.Bounded env19656 := by
  intro p hp
  have h : env19656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19655_19656 : H12AffineEnvironment.transform 14 8660 env19655 = env19656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env19655 == env19656) = true)

theorem identity19656 : scanCanonicalize (H12AffineFastState.compose env19656 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound19656 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16537,10400,1025,8661,2097152,4194304,152,138,8328,65,4204925,2098513,2119112,2421,1365,6309320,257,2115048,2098585,513]

theorem envBound19657 : H12AffineFastState.Bounded env19657 := by
  intro p hp
  have h : env19657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19656_19657 : H12AffineEnvironment.transform 15 8322 env19656 = env19657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env19656 == env19657) = true)

theorem identity19657 : scanCanonicalize (H12AffineFastState.compose env19657 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound19657 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env19658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16537,10400,1025,8661,2097152,168,152,138,8328,65,10709,2098513,2119112,2421,1365,2114912,257,2115048,2098585,513]

theorem envBound19658 : H12AffineFastState.Bounded env19658 := by
  intro p hp
  have h : env19658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19657_19658 : H12AffineEnvironment.transform 21 168 env19657 = env19658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env19657 == env19658) = true)

theorem identity19658 : scanCanonicalize (H12AffineFastState.compose env19658 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19658 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,8322,16537,10400,1025,8581,2097152,168,152,138,8328,17,10629,2098433,2119064,2341,1285,2114864,257,2115000,2098585,513]

theorem envBound19659 : H12AffineFastState.Bounded env19659 := by
  intro p hp
  have h : env19659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19658_19659 : H12AffineEnvironment.transform 5 16 env19658 = env19659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19658 == env19659) = true)

theorem identity19659 : scanCanonicalize (H12AffineFastState.compose env19659 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19659 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19660 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,137,399,16537,2477,1025,136,2097152,168,152,138,389,17,2184,2098433,2119064,2341,1285,2114864,257,2115000,2098585,513]

theorem envBound19660 : H12AffineFastState.Bounded env19660 := by
  intro p hp
  have h : env19660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19659_19660 : H12AffineEnvironment.transform 12 269 env19659 = env19660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19659 == env19660) = true)

theorem identity19660 : scanCanonicalize (H12AffineFastState.compose env19660 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound19660 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env19661 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5293,137,399,5172,2477,1025,136,2097152,168,152,138,389,17,2184,2098433,2097461,2341,1285,2101661,257,2101525,2098585,513]

theorem envBound19661 : H12AffineFastState.Bounded env19661 := by
  intro p hp
  have h : env19661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19660_19661 : H12AffineEnvironment.transform 13 5293 env19660 = env19661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env19660 == env19661) = true)

theorem identity19661 : scanCanonicalize (H12AffineFastState.compose env19661 (packedSelected [0,1,3,7,11,18] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound19661 : packedSelected [0,1,3,7,11,18] rootPS < 2^1333 := by decide +kernel

def env19662 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5293,137,399,5172,2477,1025,136,4405,168,152,138,389,17,2184,5172,4096,2341,1285,168,257,32,5292,513]

theorem envBound19662 : H12AffineFastState.Bounded env19662 := by
  intro p hp
  have h : env19662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19661_19662 : H12AffineEnvironment.transform 20 4405 env19661 = env19662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env19661 == env19662) = true)

theorem identity19662 : scanCanonicalize (H12AffineFastState.compose env19662 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19662 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env19663 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,1,263,5172,2341,1025,0,4405,32,16,2,269,17,2048,5172,4096,2341,1285,32,257,32,5156,513]

theorem envBound19663 : H12AffineFastState.Bounded env19663 := by
  intro p hp
  have h : env19663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19662_19663 : H12AffineEnvironment.transform 6 8 env19662 = env19663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19662 == env19663) = true)

theorem identity19663 : scanCanonicalize (H12AffineFastState.compose env19663 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound19663 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19664 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,269,1297,1,263,1280,2341,1025,0,1,32,16,2,269,17,2048,1280,308,2341,1285,32,257,32,1296,513]

theorem envBound19664 : H12AffineFastState.Bounded env19664 := by
  intro p hp
  have h : env19664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19663_19664 : H12AffineEnvironment.transform 11 308 env19663 = env19664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env19663 == env19664) = true)

theorem identity19664 : scanCanonicalize (H12AffineFastState.compose env19664 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19664 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19665 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,308,269,293,1,263,308,2341,53,0,1,32,16,2,269,17,2048,308,308,2341,305,32,257,32,292,513]

theorem envBound19665 : H12AffineFastState.Bounded env19665 := by
  intro p hp
  have h : env19665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19664_19665 : H12AffineEnvironment.transform 9 52 env19664 = env19665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19664 == env19665) = true)

theorem identity19665 : scanCanonicalize (H12AffineFastState.compose env19665 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound19665 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19666 : List Nat := [2,4,8,16,32,16,8,62,512,52,2048,10,51,27,1,57,10,2075,53,0,1,32,16,2,51,17,2048,10,10,2075,15,32,63,32,26,513]

theorem envBound19666 : H12AffineFastState.Bounded env19666 := by
  intro p hp
  have h : env19666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19665_19666 : H12AffineEnvironment.transform 7 62 env19665 = env19666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env19665 == env19666) = true)

theorem identity19666 : scanCanonicalize (H12AffineFastState.compose env19666 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound19666 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19667 : List Nat := [2,4,8,11,32,11,8,37,512,47,2048,10,40,0,1,34,10,2048,46,0,1,32,11,2,40,10,2048,10,10,2048,15,32,36,32,1,513]

theorem envBound19667 : H12AffineFastState.Bounded env19667 := by
  intro p hp
  have h : env19667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19666_19667 : H12AffineEnvironment.transform 3 11 env19666 = env19667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env19666 == env19667) = true)

theorem identity19667 : scanCanonicalize (H12AffineFastState.compose env19667 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19668 : List Nat := [2,4,8,11,32,11,8,37,512,47,1,10,40,0,1,34,10,1,46,0,1,32,11,2,40,10,1,10,10,1,15,32,36,32,1,513]

theorem envBound19668 : H12AffineFastState.Bounded env19668 := by
  intro p hp
  have h : env19668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19667_19668 : H12AffineEnvironment.transform 10 1 env19667 = env19668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19667 == env19668) = true)

def env19669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound19669 : H12AffineFastState.Bounded env19669 := by
  intro p hp
  have h : env19669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18392_19669 : H12AffineEnvironment.transform 29 155254785 env18392 = env19669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env18392 == env19669) = true)

def env19670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound19670 : H12AffineFastState.Bounded env19670 := by
  intro p hp
  have h : env19670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19669_19670 : H12AffineEnvironment.transform 25 64 env19669 = env19670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env19669 == env19670) = true)

def env19671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound19671 : H12AffineFastState.Bounded env19671 := by
  intro p hp
  have h : env19671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19670_19671 : H12AffineEnvironment.transform 26 30393344 env19670 = env19671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env19670 == env19671) = true)

def env19672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound19672 : H12AffineFastState.Bounded env19672 := by
  intro p hp
  have h : env19672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19671_19672 : H12AffineEnvironment.transform 18 1024 env19671 = env19672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19671 == env19672) = true)

theorem identity19672 : scanCanonicalize (H12AffineFastState.compose env19672 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2213020) := by decide +kernel

theorem selectedBound19672 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2213020,8328,64,15074460,16400,10507601,8830977,10502284,4235613,256,8388656,8446357,10577754]

theorem envBound19673 : H12AffineFastState.Bounded env19673 := by
  intro p hp
  have h : env19673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19672_19673 : H12AffineEnvironment.transform 23 2213020 env19672 = env19673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2213020 env19672 == env19673) = true)

def env19674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21776,2213020,8328,64,6705548,16400,2097217,431377,2102684,4235613,256,21792,46213,2175562]

theorem envBound19674 : H12AffineFastState.Bounded env19674 := by
  intro p hp
  have h : env19674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19673_19674 : H12AffineEnvironment.transform 22 21776 env19673 = env19674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21776 env19673 == env19674) = true)

def env19675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21776,98644,8328,64,4592708,16400,17801,431377,20564,4235613,256,21792,46213,96130]

theorem envBound19675 : H12AffineFastState.Bounded env19675 := by
  intro p hp
  have h : env19675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19674_19675 : H12AffineEnvironment.transform 20 17864 env19674 = env19675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env19674 == env19675) = true)

def env19676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,16,98644,8328,64,4592708,5392,4233,431377,1364,4235613,256,32,46213,74370]

theorem envBound19676 : H12AffineFastState.Bounded env19676 := by
  intro p hp
  have h : env19676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19675_19676 : H12AffineEnvironment.transform 13 5376 env19675 = env19676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19675 == env19676) = true)

theorem identity19676 : scanCanonicalize (H12AffineFastState.compose env19676 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19676 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,4194304,16,98644,8192,64,4592708,5392,4097,431377,1364,4235613,256,32,46093,74250]

theorem envBound19677 : H12AffineFastState.Bounded env19677 := by
  intro p hp
  have h : env19677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19676_19677 : H12AffineEnvironment.transform 6 8 env19676 = env19677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19676 == env19677) = true)

theorem identity19677 : scanCanonicalize (H12AffineFastState.compose env19677 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19677 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,4194304,16,41311,8192,64,4592708,5392,4097,431377,1364,4235613,256,32,46093,513]

theorem envBound19678 : H12AffineFastState.Bounded env19678 := by
  intro p hp
  have h : env19678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19677_19678 : H12AffineEnvironment.transform 15 8203 env19677 = env19678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19677 == env19678) = true)

theorem identity19678 : scanCanonicalize (H12AffineFastState.compose env19678 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19678 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,4194304,16,2,8192,64,4592708,5392,4097,406604,1364,4194304,256,32,5456,513]

theorem envBound19679 : H12AffineFastState.Bounded env19679 := by
  intro p hp
  have h : env19679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19678_19679 : H12AffineEnvironment.transform 14 8541 env19678 = env19679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19678 == env19679) = true)

theorem identity19679 : scanCanonicalize (H12AffineFastState.compose env19679 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound19679 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146793,1024,8540,4160,4194304,16,2,8192,64,4204845,5392,4097,2341,1364,4194304,256,32,5456,513]

theorem envBound19680 : H12AffineFastState.Bounded env19680 := by
  intro p hp
  have h : env19680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19679_19680 : H12AffineEnvironment.transform 17 146793 env19679 = env19680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env19679 == env19680) = true)

theorem identity19680 : scanCanonicalize (H12AffineFastState.compose env19680 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound19680 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env19681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146793,1024,8540,4160,136497,16,2,8192,64,146460,5392,4097,2341,1364,136497,256,32,5456,513]

theorem envBound19681 : H12AffineFastState.Bounded env19681 := by
  intro p hp
  have h : env19681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19680_19681 : H12AffineEnvironment.transform 21 136497 env19680 = env19681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env19680 == env19681) = true)

theorem identity19681 : scanCanonicalize (H12AffineFastState.compose env19681 (packedSelected [1,8,12,15,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19681 : packedSelected [1,8,12,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env19682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10361,1024,8540,4160,33,16,2,8192,64,10508,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound19682 : H12AffineFastState.Bounded env19682 := by
  intro p hp
  have h : env19682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19681_19682 : H12AffineEnvironment.transform 16 5392 env19681 = env19682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19681 == env19682) = true)

theorem identity19682 : scanCanonicalize (H12AffineFastState.compose env19682 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 5481) := by decide +kernel

theorem selectedBound19682 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env19683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5481,5376,5172,5474,5392,7440,1024,5173,4160,33,16,2,5481,64,7269,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound19683 : H12AffineFastState.Bounded env19683 := by
  intro p hp
  have h : env19683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19682_19683 : H12AffineEnvironment.transform 12 5481 env19682 = env19683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5481 env19682 == env19683) = true)

theorem identity19683 : scanCanonicalize (H12AffineFastState.compose env19683 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound19683 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1125,268,357,81,263,373,2421,1024,80,1061,33,16,2,268,64,2048,373,1124,2341,1364,33,256,32,309,513]

theorem envBound19684 : H12AffineFastState.Bounded env19684 := by
  intro p hp
  have h : env19684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19683_19684 : H12AffineEnvironment.transform 11 1125 env19683 = env19684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env19683 == env19684) = true)

theorem identity19684 : scanCanonicalize (H12AffineFastState.compose env19684 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound19684 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env19685 : List Nat := [2,4,8,16,32,64,8,95,512,1024,2048,1125,83,58,81,88,42,2090,1024,80,1061,33,16,2,83,64,2048,42,1124,2170,1035,33,95,32,106,513]

theorem envBound19685 : H12AffineFastState.Bounded env19685 := by
  intro p hp
  have h : env19685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19684_19685 : H12AffineEnvironment.transform 7 95 env19684 = env19685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env19684 == env19685) = true)

theorem identity19685 : scanCanonicalize (H12AffineFastState.compose env19685 (packedSelected [0,5,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19685 : packedSelected [0,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env19686 : List Nat := [2,4,8,16,32,16,8,15,512,1024,2048,1077,3,58,1,8,42,2090,1024,0,1061,33,16,2,3,16,2048,42,1076,2090,1035,33,15,32,58,513]

theorem envBound19686 : H12AffineFastState.Bounded env19686 := by
  intro p hp
  have h : env19686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19685_19686 : H12AffineEnvironment.transform 5 16 env19685 = env19686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19685 == env19686) = true)

theorem identity19686 : scanCanonicalize (H12AffineFastState.compose env19686 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound19686 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19687 : List Nat := [2,4,8,16,32,16,8,15,512,1024,33,1077,3,58,1,8,42,11,1024,0,1061,33,16,2,3,16,33,42,1076,11,1035,33,15,32,58,513]

theorem envBound19687 : H12AffineFastState.Bounded env19687 := by
  intro p hp
  have h : env19687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19686_19687 : H12AffineEnvironment.transform 10 33 env19686 = env19687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env19686 == env19687) = true)

theorem identity19687 : scanCanonicalize (H12AffineFastState.compose env19687 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound19687 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19688 : List Nat := [2,4,8,16,32,16,8,15,512,4,33,49,3,58,1,8,42,11,4,0,33,33,16,2,3,16,33,42,48,11,15,33,15,32,58,513]

theorem envBound19688 : H12AffineFastState.Bounded env19688 := by
  intro p hp
  have h : env19688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19687_19688 : H12AffineEnvironment.transform 9 4 env19687 = env19688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env19687 == env19688) = true)

def env19689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,17,98644,8328,64,4592708,5393,4232,431377,1365,4235613,256,33,46213,74371]

theorem envBound19689 : H12AffineFastState.Bounded env19689 := by
  intro p hp
  have h : env19689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19675_19689 : H12AffineEnvironment.transform 13 5377 env19675 = env19689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19675 == env19689) = true)

theorem identity19689 : scanCanonicalize (H12AffineFastState.compose env19689 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19689 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,32,17,98644,8328,64,398436,5393,4232,431377,1365,41341,256,33,46213,74371]

theorem envBound19690 : H12AffineFastState.Bounded env19690 := by
  intro p hp
  have h : env19690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19689_19690 : H12AffineEnvironment.transform 21 32 env19689 = env19690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19689 == env19690) = true)

def env19691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,17,98644,8192,64,398436,5393,4096,431377,1365,41341,256,33,46093,74251]

theorem envBound19691 : H12AffineFastState.Bounded env19691 := by
  intro p hp
  have h : env19691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19690_19691 : H12AffineEnvironment.transform 6 8 env19690 = env19691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19690 == env19691) = true)

theorem identity19691 : scanCanonicalize (H12AffineFastState.compose env19691 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound19691 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,4161,32,17,98644,8192,64,203847,5393,4096,236850,1365,41341,256,33,46093,74251]

theorem envBound19692 : H12AffineFastState.Bounded env19692 := by
  intro p hp
  have h : env19692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19691_19692 : H12AffineEnvironment.transform 17 67619 env19691 = env19692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env19691 == env19692) = true)

theorem identity19692 : scanCanonicalize (H12AffineFastState.compose env19692 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19692 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env19693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,65536,131072,67619,1024,1,4161,32,17,65876,8192,64,203847,5393,4096,204082,1365,8573,256,33,13325,74251]

theorem envBound19693 : H12AffineFastState.Bounded env19693 := by
  intro p hp
  have h : env19693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19692_19693 : H12AffineEnvironment.transform 14 0 env19692 = env19693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19692 == env19693) = true)

theorem identity19693 : scanCanonicalize (H12AffineFastState.compose env19693 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound19693 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env19694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,65536,70727,67619,1024,1,4161,32,17,65876,8192,64,2048,5393,4096,2421,1365,8573,256,33,13325,74251]

theorem envBound19694 : H12AffineFastState.Bounded env19694 := by
  intro p hp
  have h : env19694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19693_19694 : H12AffineEnvironment.transform 16 70727 env19693 = env19694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env19693 == env19694) = true)

theorem identity19694 : scanCanonicalize (H12AffineFastState.compose env19694 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound19694 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,262,5441,2341,1024,1,4161,32,17,82,8192,64,2048,5393,4096,2421,1365,8573,256,33,13325,8973]

theorem envBound19695 : H12AffineFastState.Bounded env19695 := by
  intro p hp
  have h : env19695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19694_19695 : H12AffineEnvironment.transform 15 262 env19694 = env19695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env19694 == env19695) = true)

theorem identity19695 : scanCanonicalize (H12AffineFastState.compose env19695 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19695 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env19696 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,0,262,4177,2341,272,1,4161,32,17,82,8192,64,2048,4097,4096,2421,69,8573,256,33,12573,8973]

theorem envBound19696 : H12AffineFastState.Bounded env19696 := by
  intro p hp
  have h : env19696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19695_19696 : H12AffineEnvironment.transform 9 272 env19695 = env19696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19695 == env19696) = true)

def env19697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98644,8193,64,398436,5393,4097,431377,1365,41341,256,33,46092,74250]

theorem envBound19697 : H12AffineFastState.Bounded env19697 := by
  intro p hp
  have h : env19697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19690_19697 : H12AffineEnvironment.transform 6 9 env19690 = env19697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19690 == env19697) = true)

theorem identity19697 : scanCanonicalize (H12AffineFastState.compose env19697 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound19697 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1024,32769,4160,32,17,98644,8193,64,245018,5393,4097,212079,1365,41341,256,33,46092,74250]

theorem envBound19698 : H12AffineFastState.Bounded env19698 := by
  intro p hp
  have h : env19698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19697_19698 : H12AffineEnvironment.transform 17 108926 env19697 = env19698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env19697 == env19698) = true)

theorem identity19698 : scanCanonicalize (H12AffineFastState.compose env19698 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19698 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35189,1024,32769,4160,32,17,41311,8193,64,171281,5393,4097,138340,1365,41341,256,33,46092,513]

theorem envBound19699 : H12AffineFastState.Bounded env19699 := by
  intro p hp
  have h : env19699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19698_19699 : H12AffineEnvironment.transform 15 8203 env19698 = env19699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19698 == env19699) = true)

theorem identity19699 : scanCanonicalize (H12AffineFastState.compose env19699 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12636) := by decide +kernel

theorem selectedBound19699 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19700 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,12636,35189,1024,32769,4160,32,17,41311,8193,64,44109,5393,4097,11576,1365,41341,256,33,46092,513]

theorem envBound19700 : H12AffineFastState.Bounded env19700 := by
  intro p hp
  have h : env19700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19699_19700 : H12AffineEnvironment.transform 16 12636 env19699 = env19700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12636 env19699 == env19700) = true)

theorem identity19700 : scanCanonicalize (H12AffineFastState.compose env19700 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound19700 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env19701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,32768,1095,5392,35189,1024,32769,4160,32,17,34067,1101,64,34817,5393,4097,2420,1365,34097,256,33,36928,513]

theorem envBound19701 : H12AffineFastState.Bounded env19701 := by
  intro p hp
  have h : env19701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19700_19701 : H12AffineEnvironment.transform 12 1100 env19700 = env19701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env19700 == env19701) = true)

theorem identity19701 : scanCanonicalize (H12AffineFastState.compose env19701 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5685) := by decide +kernel

theorem selectedBound19701 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,5685,1095,5392,8000,1024,5684,4160,32,17,4902,1101,64,7732,5393,4097,2420,1365,4868,256,33,1653,513]

theorem envBound19702 : H12AffineFastState.Bounded env19702 := by
  intro p hp
  have h : env19702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19701_19702 : H12AffineEnvironment.transform 14 5685 env19701 = env19702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5685 env19701 == env19702) = true)

def env19703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21776,98645,8328,64,4592709,16400,17800,431377,20565,4235613,256,21792,46213,96131]

theorem envBound19703 : H12AffineFastState.Bounded env19703 := by
  intro p hp
  have h : env19703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19674_19703 : H12AffineEnvironment.transform 20 17865 env19674 = env19703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env19674 == env19703) = true)

def env19704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,16,98645,8328,64,4592709,5392,4232,431377,1365,4235613,256,32,46213,74371]

theorem envBound19704 : H12AffineFastState.Bounded env19704 := by
  intro p hp
  have h : env19704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19703_19704 : H12AffineEnvironment.transform 13 5376 env19703 = env19704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19703 == env19704) = true)

theorem identity19704 : scanCanonicalize (H12AffineFastState.compose env19704 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19704 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4297,4194304,16,73736,8328,64,4592709,5392,4232,406604,1365,4194304,256,32,5592,74371]

theorem envBound19705 : H12AffineFastState.Bounded env19705 := by
  intro p hp
  have h : env19705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19704_19705 : H12AffineEnvironment.transform 14 8541 env19704 = env19705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19704 == env19705) = true)

theorem identity19705 : scanCanonicalize (H12AffineFastState.compose env19705 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound19705 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,262144,1024,8540,4297,4194304,16,138,8328,64,4592709,5392,4232,406604,1365,4194304,256,32,5592,513]

theorem envBound19706 : H12AffineFastState.Bounded env19706 := by
  intro p hp
  have h : env19706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19705_19706 : H12AffineEnvironment.transform 15 8322 env19705 = env19706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env19705 == env19706) = true)

def env19707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,262144,1024,8540,4297,409024,16,138,8328,64,10629,5392,4232,406604,1365,409024,256,32,5592,513]

end H12CloudChart1