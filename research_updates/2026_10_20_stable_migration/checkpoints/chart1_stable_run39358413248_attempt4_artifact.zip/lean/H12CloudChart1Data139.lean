import H12CloudChart1Data138

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans35267_35268 : H12AffineEnvironment.transform 11 2123 env35267 = env35268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2123 env35267 == env35268) = true)

theorem identity35268 : scanCanonicalize (H12AffineFastState.compose env35268 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 633) := by decide +kernel

theorem selectedBound35268 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35269 : List Nat := [2,4,8,16,32,64,128,236,512,116,633,562,176,546,0,186,562,616,117,1,626,33,17,139,56,64,632,698,699,616,68,169,237,169,627,513]

theorem envBound35269 : H12AffineFastState.Bounded env35269 := by
  intro p hp
  have h : env35269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35268_35269 : H12AffineEnvironment.transform 10 633 env35268 = env35269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 633 env35268 == env35269) = true)

theorem identity35269 : scanCanonicalize (H12AffineFastState.compose env35269 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35269 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35270 : List Nat := [2,4,8,16,32,64,8,100,512,116,633,562,56,546,0,50,562,616,117,1,626,33,17,3,56,64,632,562,563,616,68,33,101,33,627,513]

theorem envBound35270 : H12AffineFastState.Bounded env35270 := by
  intro p hp
  have h : env35270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35269_35270 : H12AffineEnvironment.transform 6 8 env35269 = env35270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35269 == env35270) = true)

def env35271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180225,95497,8328,64,23944,185600,45525,262144,143640,400589,257,21793,46213,202447]

theorem envBound35271 : H12AffineFastState.Bounded env35271 := by
  intro p hp
  have h : env35271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35258_35271 : H12AffineEnvironment.transform 21 272513 env35258 = env35271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35258 == env35271) = true)

theorem identity35271 : scanCanonicalize (H12AffineFastState.compose env35271 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound35271 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140420,272513,144597,95497,8328,64,23944,139732,17665,262144,143640,400589,257,21793,16465,202447]

theorem envBound35272 : H12AffineFastState.Bounded env35272 := by
  intro p hp
  have h : env35272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35271_35272 : H12AffineEnvironment.transform 14 29908 env35271 = env35272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env35271 == env35272) = true)

theorem identity35272 : scanCanonicalize (H12AffineFastState.compose env35272 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound35272 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env35273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,76158,1025,29909,140420,66047,144597,95497,8328,64,23944,139732,17665,76158,143640,210355,257,21793,16465,202447]

theorem envBound35273 : H12AffineFastState.Bounded env35273 := by
  intro p hp
  have h : env35273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35272_35273 : H12AffineEnvironment.transform 17 76158 env35272 = env35273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env35272 == env35273) = true)

def env35274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,76158,1025,29789,140300,65911,144477,95497,8192,64,23808,139612,17665,76158,143640,210235,257,21793,16465,202311]

theorem envBound35274 : H12AffineFastState.Bounded env35274 := by
  intro p hp
  have h : env35274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35273_35274 : H12AffineEnvironment.transform 6 8 env35273 = env35274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35273 == env35274) = true)

theorem identity35274 : scanCanonicalize (H12AffineFastState.compose env35274 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound35274 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,76158,1025,29789,77898,65911,73755,95497,8192,64,23808,79130,17665,76158,75102,8573,257,21793,16465,513]

theorem envBound35275 : H12AffineFastState.Bounded env35275 := by
  intro p hp
  have h : env35275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35274_35275 : H12AffineEnvironment.transform 16 70726 env35274 = env35275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env35274 == env35275) = true)

theorem identity35275 : scanCanonicalize (H12AffineFastState.compose env35275 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound35275 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env35276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,16400,32040,1025,29789,25628,21793,29773,8543,8192,64,23808,24908,17665,32040,28936,8573,257,21793,16465,513]

theorem envBound35276 : H12AffineFastState.Bounded env35276 := by
  intro p hp
  have h : env35276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35275_35276 : H12AffineEnvironment.transform 15 21590 env35275 = env35276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env35275 == env35276) = true)

theorem identity35276 : scanCanonicalize (H12AffineFastState.compose env35276 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,16400,23669,1025,21760,17729,21793,21776,2,349,64,23808,16401,17665,23669,20565,32,257,21793,16465,513]

theorem envBound35277 : H12AffineFastState.Bounded env35277 := by
  intro p hp
  have h : env35277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35276_35277 : H12AffineEnvironment.transform 12 349 env35276 = env35277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35276 == env35277) = true)

theorem identity35277 : scanCanonicalize (H12AffineFastState.compose env35277 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35277 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5392,2421,1025,0,4161,33,16,2,349,64,2048,5393,4097,2421,1365,32,257,33,5457,513]

theorem envBound35278 : H12AffineFastState.Bounded env35278 := by
  intro p hp
  have h : env35278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35277_35278 : H12AffineEnvironment.transform 13 5376 env35277 = env35278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35277 == env35278) = true)

theorem identity35278 : scanCanonicalize (H12AffineFastState.compose env35278 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35279 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,35,5221,2048,1025,0,4161,33,16,2,40,64,2048,5220,4097,2048,1056,32,116,33,5156,513]

theorem envBound35279 : H12AffineFastState.Bounded env35279 := by
  intro p hp
  have h : env35279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35278_35279 : H12AffineEnvironment.transform 7 117 env35278 = env35279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35278 == env35279) = true)

theorem identity35279 : scanCanonicalize (H12AffineFastState.compose env35279 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35279 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35280 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5172,2048,1025,0,4112,33,16,2,40,17,2048,5173,4097,2048,1056,32,37,33,5156,513]

theorem envBound35280 : H12AffineFastState.Bounded env35280 := by
  intro p hp
  have h : env35280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35279_35280 : H12AffineEnvironment.transform 5 17 env35279 = env35280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35279 == env35280) = true)

def env35281 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1044,1,35,1028,2048,1025,0,32,33,16,2,40,17,2048,1029,49,2048,1056,32,37,33,1044,513]

theorem envBound35281 : H12AffineFastState.Bounded env35281 := by
  intro p hp
  have h : env35281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35280_35281 : H12AffineEnvironment.transform 11 48 env35280 = env35281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35280 == env35281) = true)

theorem identity35281 : scanCanonicalize (H12AffineFastState.compose env35281 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35282 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,40,1044,1,35,1028,0,1025,0,32,33,16,2,40,17,0,1029,49,0,1056,32,37,33,1044,513]

theorem envBound35282 : H12AffineFastState.Bounded env35282 := by
  intro p hp
  have h : env35282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35281_35282 : H12AffineEnvironment.transform 10 0 env35281 = env35282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35281 == env35282) = true)

def env35283 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,40,32,1,35,48,0,53,0,32,33,16,2,40,17,0,49,49,0,20,32,37,33,32,513]

theorem envBound35283 : H12AffineFastState.Bounded env35283 := by
  intro p hp
  have h : env35283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35282_35283 : H12AffineEnvironment.transform 9 52 env35282 = env35283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35282 == env35283) = true)

theorem identity35283 : scanCanonicalize (H12AffineFastState.compose env35283 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35283 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35284 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,40,32,1,35,48,0,53,0,32,33,16,2,40,17,0,49,49,0,20,32,37,33,32,11]

theorem envBound35284 : H12AffineFastState.Bounded env35284 := by
  intro p hp
  have h : env35284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35283_35284 : H12AffineEnvironment.transform 8 10 env35283 = env35284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35283 == env35284) = true)

def leafEnv35284 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,40,32,1,35,48,0,53,0,32,33,16,2,21,40,1,17,0,49,49,0,20,32,37,33,5,35,32,11,1,32,0]

def active35284 : List Nat := [0,1,2,3,4]

def tree35284 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35284 : H12WitnessSearch.Good tree35284 := H12GlobalWitnessIndex.good

theorem leafIdentity35284 : H12AffineFastState.composeSystem env35284 rootObs = leafEnv35284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35284 rootObs == leafEnv35284) = true)

theorem terminalChecked35284 : H12PackedTerminal.terminalCheckFast leafEnv35284 active35284 tree35284 = true := by decide +kernel

def env35285 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,33,1,35,49,0,52,0,32,33,16,2,40,17,0,48,49,0,21,32,37,33,33,513]

theorem envBound35285 : H12AffineFastState.Bounded env35285 := by
  intro p hp
  have h : env35285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35282_35285 : H12AffineEnvironment.transform 9 53 env35282 = env35285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35282 == env35285) = true)

theorem identity35285 : scanCanonicalize (H12AffineFastState.compose env35285 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35286 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,8,1,1,3,17,0,20,0,0,1,16,2,8,17,0,16,17,0,21,0,5,1,1,513]

theorem envBound35286 : H12AffineFastState.Bounded env35286 := by
  intro p hp
  have h : env35286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35285_35286 : H12AffineEnvironment.transform 4 0 env35285 = env35286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35285 == env35286) = true)

def leafEnv35286 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,8,1,1,3,17,0,20,0,0,1,16,2,20,8,1,17,0,16,17,0,21,0,5,1,5,3,1,513,1,0,0]

def active35286 : List Nat := [0,1,2,3,8]

def tree35286 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35286 : H12WitnessSearch.Good tree35286 := H12GlobalWitnessIndex.good

theorem leafIdentity35286 : H12AffineFastState.composeSystem env35286 rootObs = leafEnv35286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35286 rootObs == leafEnv35286) = true)

theorem terminalChecked35286 : H12PackedTerminal.terminalCheckFast leafEnv35286 active35286 tree35286 = true := by decide +kernel

def env35287 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1045,1,35,1029,2048,1025,0,33,33,16,2,40,17,2048,1028,48,2048,1056,32,37,33,1045,513]

theorem envBound35287 : H12AffineFastState.Bounded env35287 := by
  intro p hp
  have h : env35287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35280_35287 : H12AffineEnvironment.transform 11 49 env35280 = env35287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35280 == env35287) = true)

theorem identity35287 : scanCanonicalize (H12AffineFastState.compose env35287 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound35287 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35288 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,40,1045,1,35,1029,1076,1025,0,33,33,16,2,40,17,1076,1028,48,1076,1056,32,37,33,1045,513]

theorem envBound35288 : H12AffineFastState.Bounded env35288 := by
  intro p hp
  have h : env35288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35287_35288 : H12AffineEnvironment.transform 10 1076 env35287 = env35288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env35287 == env35288) = true)

def env35289 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,33,1,35,49,0,53,0,33,33,16,2,40,17,0,48,48,0,20,32,37,33,33,513]

theorem envBound35289 : H12AffineFastState.Bounded env35289 := by
  intro p hp
  have h : env35289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35288_35289 : H12AffineEnvironment.transform 9 52 env35288 = env35289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35288 == env35289) = true)

theorem identity35289 : scanCanonicalize (H12AffineFastState.compose env35289 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35289 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35290 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,40,33,1,35,49,0,53,0,33,33,16,2,40,17,0,48,48,0,20,32,37,33,33,11]

theorem envBound35290 : H12AffineFastState.Bounded env35290 := by
  intro p hp
  have h : env35290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35289_35290 : H12AffineEnvironment.transform 8 10 env35289 = env35290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35289 == env35290) = true)

def leafEnv35290 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,40,33,1,35,49,0,53,0,33,33,16,2,21,40,1,17,0,48,48,0,20,32,37,33,5,35,33,11,1,33,0]

def active35290 : List Nat := [0,1,2,3,4]

def tree35290 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35290 : H12WitnessSearch.Good tree35290 := H12GlobalWitnessIndex.good

theorem leafIdentity35290 : H12AffineFastState.composeSystem env35290 rootObs = leafEnv35290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35290 rootObs == leafEnv35290) = true)

theorem terminalChecked35290 : H12PackedTerminal.terminalCheckFast leafEnv35290 active35290 tree35290 = true := by decide +kernel

def env35291 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,40,32,1,35,48,1,52,0,33,33,16,2,40,17,1,49,48,1,21,32,37,33,32,513]

theorem envBound35291 : H12AffineFastState.Bounded env35291 := by
  intro p hp
  have h : env35291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35288_35291 : H12AffineEnvironment.transform 9 53 env35288 = env35291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35288 == env35291) = true)

theorem identity35291 : scanCanonicalize (H12AffineFastState.compose env35291 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35291 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35292 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,8,0,1,3,16,1,20,0,1,1,16,2,8,17,1,17,16,1,21,0,5,1,0,513]

theorem envBound35292 : H12AffineFastState.Bounded env35292 := by
  intro p hp
  have h : env35292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35291_35292 : H12AffineEnvironment.transform 4 0 env35291 = env35292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35291 == env35292) = true)

def leafEnv35292 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,8,0,1,3,16,1,20,0,1,1,16,2,20,8,1,17,1,17,16,1,21,0,5,1,5,3,0,513,1,1,0]

def active35292 : List Nat := [0,1,2,3,8]

def tree35292 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35292 : H12WitnessSearch.Good tree35292 := H12GlobalWitnessIndex.good

theorem leafIdentity35292 : H12AffineFastState.composeSystem env35292 rootObs = leafEnv35292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35292 rootObs == leafEnv35292) = true)

theorem terminalChecked35292 : H12PackedTerminal.terminalCheckFast leafEnv35292 active35292 tree35292 = true := by decide +kernel

def env35293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,76158,1025,29788,140301,65910,144476,95497,8193,64,23809,139613,17665,76158,143640,210234,257,21793,16465,202310]

theorem envBound35293 : H12AffineFastState.Bounded env35293 := by
  intro p hp
  have h : env35293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35273_35293 : H12AffineEnvironment.transform 6 9 env35273 = env35293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35273 == env35293) = true)

theorem identity35293 : scanCanonicalize (H12AffineFastState.compose env35293 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35293 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,65536,131072,76158,1025,0,140301,65910,144476,65877,8193,64,10589,139613,12637,76158,143640,210234,257,8573,13325,202310]

theorem envBound35294 : H12AffineFastState.Bounded env35294 := by
  intro p hp
  have h : env35294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35293_35294 : H12AffineEnvironment.transform 13 13404 env35293 = env35294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35293 == env35294) = true)

theorem identity35294 : scanCanonicalize (H12AffineFastState.compose env35294 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound35294 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,1,65536,131072,67926,1025,0,132133,65910,136308,65877,41,64,2421,131445,4469,67926,135472,202002,257,341,5157,202310]

theorem envBound35295 : H12AffineFastState.Bounded env35295 := by
  intro p hp
  have h : env35295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35294_35295 : H12AffineEnvironment.transform 12 40 env35294 = env35295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env35294 == env35295) = true)

theorem identity35295 : scanCanonicalize (H12AffineFastState.compose env35295 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35295 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,1,115,131072,2341,1025,0,132133,261,136308,294,41,64,2421,131445,4469,2341,135472,136545,257,341,5157,136757]

theorem envBound35296 : H12AffineFastState.Bounded env35296 := by
  intro p hp
  have h : env35296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35295_35296 : H12AffineEnvironment.transform 15 115 env35295 = env35296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35295 == env35296) = true)

theorem identity35296 : scanCanonicalize (H12AffineFastState.compose env35296 (packedSelected [1,8,12,15,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35296 : packedSelected [1,8,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env35297 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5236,1,115,131072,2048,1025,0,132133,32,136308,3,41,64,2128,131152,4176,2048,135189,136260,36,112,5157,136757]

theorem envBound35297 : H12AffineFastState.Bounded env35297 := by
  intro p hp
  have h : env35297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35296_35297 : H12AffineEnvironment.transform 7 37 env35296 = env35297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35296 == env35297) = true)

theorem identity35297 : scanCanonicalize (H12AffineFastState.compose env35297 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound35297 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35298 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5236,1,115,5172,2048,1025,0,4113,32,64,3,41,64,2128,5220,4176,2048,1057,112,36,112,5157,513]

theorem envBound35298 : H12AffineFastState.Bounded env35298 := by
  intro p hp
  have h : env35298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35297_35298 : H12AffineEnvironment.transform 16 5172 env35297 = env35298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env35297 == env35298) = true)

theorem identity35298 : scanCanonicalize (H12AffineFastState.compose env35298 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound35298 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env35299 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,1140,40,0,1,115,64,2048,1025,0,1125,32,64,3,41,64,2128,16,1060,2048,1057,112,36,112,81,513]

theorem envBound35299 : H12AffineFastState.Bounded env35299 := by
  intro p hp
  have h : env35299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35298_35299 : H12AffineEnvironment.transform 11 1140 env35298 = env35299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env35298 == env35299) = true)

theorem identity35299 : scanCanonicalize (H12AffineFastState.compose env35299 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35299 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35300 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,16,40,0,1,115,64,2048,101,0,1,32,64,3,41,64,2128,16,64,2048,69,112,36,112,81,513]

theorem envBound35300 : H12AffineFastState.Bounded env35300 := by
  intro p hp
  have h : env35300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35299_35300 : H12AffineEnvironment.transform 9 100 env35299 = env35300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35299 == env35300) = true)

theorem identity35300 : scanCanonicalize (H12AffineFastState.compose env35300 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound35300 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35301 : List Nat := [2,4,8,16,32,64,9,37,512,100,528,16,40,0,1,115,64,528,101,0,1,32,64,3,41,64,576,16,64,528,69,112,36,112,81,513]

theorem envBound35301 : H12AffineFastState.Bounded env35301 := by
  intro p hp
  have h : env35301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35300_35301 : H12AffineEnvironment.transform 10 528 env35300 = env35301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env35300 == env35301) = true)

theorem identity35301 : scanCanonicalize (H12AffineFastState.compose env35301 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound35301 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35302 : List Nat := [2,4,8,16,32,11,9,37,512,47,528,16,40,0,1,56,11,528,46,0,1,32,11,3,41,11,523,16,11,528,14,59,36,59,26,513]

theorem envBound35302 : H12AffineFastState.Bounded env35302 := by
  intro p hp
  have h : env35302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35301_35302 : H12AffineEnvironment.transform 5 11 env35301 = env35302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env35301 == env35302) = true)

theorem identity35302 : scanCanonicalize (H12AffineFastState.compose env35302 (packedSelected [0,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35302 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env35303 : List Nat := [2,4,8,16,32,11,9,37,16,47,0,16,40,0,1,56,11,0,46,0,1,32,11,3,41,11,27,16,11,0,14,59,36,59,26,17]

theorem envBound35303 : H12AffineFastState.Bounded env35303 := by
  intro p hp
  have h : env35303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35302_35303 : H12AffineEnvironment.transform 8 16 env35302 = env35303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35302 == env35303) = true)

theorem identity35303 : scanCanonicalize (H12AffineFastState.compose env35303 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35303 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35304 : List Nat := [2,4,8,10,32,11,9,37,10,47,0,10,40,0,1,34,11,0,46,0,1,32,11,3,41,11,1,10,11,0,14,33,36,33,0,11]

theorem envBound35304 : H12AffineFastState.Bounded env35304 := by
  intro p hp
  have h : env35304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35303_35304 : H12AffineEnvironment.transform 3 10 env35303 = env35304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35303 == env35304) = true)

theorem identity35304 : scanCanonicalize (H12AffineFastState.compose env35304 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35304 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35305 : List Nat := [2,4,3,1,32,0,2,37,1,36,0,1,35,0,1,34,0,0,37,0,1,32,0,3,34,0,1,1,0,0,5,33,36,33,0,0]

theorem envBound35305 : H12AffineFastState.Bounded env35305 := by
  intro p hp
  have h : env35305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35304_35305 : H12AffineEnvironment.transform 2 3 env35304 = env35305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35304 == env35305) = true)

theorem identity35305 : scanCanonicalize (H12AffineFastState.compose env35305 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35306 : List Nat := [2,4,3,1,1,0,2,4,1,5,0,1,2,0,1,3,0,0,4,0,1,1,0,3,3,0,1,1,0,0,5,0,5,0,0,0]

theorem envBound35306 : H12AffineFastState.Bounded env35306 := by
  intro p hp
  have h : env35306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35305_35306 : H12AffineEnvironment.transform 4 1 env35305 = env35306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35305 == env35306) = true)

def env35307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,8388608,8631561,8328,64,4486408,8393984,8548820,8830977,143641,12645452,257,21792,46212,202446]

theorem envBound35307 : H12AffineFastState.Bounded env35307 := by
  intro p hp
  have h : env35307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35176_35307 : H12AffineEnvironment.transform 23 8631561 env35176 = env35307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631561 env35176 == env35307) = true)

def env35308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180224,95497,8328,64,4486408,185600,45524,262145,143641,4338764,257,21792,46212,202446]

theorem envBound35308 : H12AffineFastState.Bounded env35308 := by
  intro p hp
  have h : env35308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35307_35308 : H12AffineEnvironment.transform 22 180224 env35307 = env35308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env35307 == env35308) = true)

def env35309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180224,95497,8328,64,23944,185600,45524,262145,143641,400588,257,21792,46212,202446]

theorem envBound35309 : H12AffineFastState.Bounded env35309 := by
  intro p hp
  have h : env35309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35308_35309 : H12AffineEnvironment.transform 21 272512 env35308 = env35309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35308 == env35309) = true)

theorem identity35309 : scanCanonicalize (H12AffineFastState.compose env35309 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound35309 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,140420,272512,180224,41431,8328,64,23944,185600,45524,262145,143641,400588,257,21792,46212,180752]

theorem envBound35310 : H12AffineFastState.Bounded env35310 := by
  intro p hp
  have h : env35310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35309_35310 : H12AffineEnvironment.transform 15 54494 env35309 = env35310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env35309 == env35310) = true)

def env35311 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,140420,272512,180224,41351,8328,16,23944,185600,45444,262145,143641,400540,257,21792,46212,180752]

theorem envBound35311 : H12AffineFastState.Bounded env35311 := by
  intro p hp
  have h : env35311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35310_35311 : H12AffineEnvironment.transform 5 16 env35310 = env35311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35310 == env35311) = true)

theorem identity35311 : scanCanonicalize (H12AffineFastState.compose env35311 (packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS)) = affineNative (2^(16+1) ^^^ 46229) := by decide +kernel

theorem selectedBound35311 : packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS < 2^1333 := by decide +kernel

def env35312 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,46229,262144,1025,32769,36881,272512,29845,41351,8328,16,23944,24981,45444,262145,34188,305161,257,21792,46212,30341]

theorem envBound35312 : H12AffineFastState.Bounded env35312 := by
  intro p hp
  have h : env35312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35311_35312 : H12AffineEnvironment.transform 16 46229 env35311 = env35312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46229 env35311 == env35312) = true)

theorem identity35312 : scanCanonicalize (H12AffineFastState.compose env35312 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound35312 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env35313 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,46229,23588,1025,32769,36881,29860,29845,41351,8328,16,23944,24981,45444,23589,34188,62509,257,21792,46212,30341]

theorem envBound35313 : H12AffineFastState.Bounded env35313 := by
  intro p hp
  have h : env35313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35312_35313 : H12AffineEnvironment.transform 17 23588 env35312 = env35313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env35312 == env35313) = true)

theorem identity35313 : scanCanonicalize (H12AffineFastState.compose env35313 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound35313 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35314 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,33030,46229,2476,1025,32769,36881,8492,8477,41351,8328,16,2048,13341,45444,2477,34188,41381,257,168,46212,8973]

theorem envBound35314 : H12AffineFastState.Bounded env35314 := by
  intro p hp
  have h : env35314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35313_35314 : H12AffineEnvironment.transform 13 5512 env35313 = env35314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env35313 == env35314) = true)

theorem identity35314 : scanCanonicalize (H12AffineFastState.compose env35314 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35314 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env35315 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32768,33030,46108,2341,1025,32769,36881,8492,8477,41230,8193,16,2048,13341,45325,2340,34053,41260,257,33,46093,8973]

theorem envBound35315 : H12AffineFastState.Bounded env35315 := by
  intro p hp
  have h : env35315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35314_35315 : H12AffineEnvironment.transform 6 9 env35314 = env35315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35314 == env35315) = true)

theorem identity35315 : scanCanonicalize (H12AffineFastState.compose env35315 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound35315 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35316 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,293,35,13625,2341,1025,292,4404,8492,8477,8235,8193,16,2048,13341,12328,2340,1056,8201,257,33,13608,8973]

theorem envBound35316 : H12AffineFastState.Bounded env35316 := by
  intro p hp
  have h : env35316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35315_35316 : H12AffineEnvironment.transform 14 293 env35315 = env35316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env35315 == env35316) = true)

theorem identity35316 : scanCanonicalize (H12AffineFastState.compose env35316 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35316 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35317 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5377,293,35,5392,2341,1025,292,4404,261,308,2,40,16,2048,5172,4097,2340,1056,32,257,33,5377,804]

theorem envBound35317 : H12AffineFastState.Bounded env35317 := by
  intro p hp
  have h : env35317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35316_35317 : H12AffineEnvironment.transform 12 41 env35316 = env35317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35316 == env35317) = true)

theorem identity35317 : scanCanonicalize (H12AffineFastState.compose env35317 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound35317 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35318 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,41,293,293,35,308,2341,1025,292,1296,261,308,2,40,16,2048,16,1061,2340,1056,32,257,33,293,804]

theorem envBound35318 : H12AffineFastState.Bounded env35318 := by
  intro p hp
  have h : env35318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35317_35318 : H12AffineEnvironment.transform 11 1060 env35317 = env35318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env35317 == env35318) = true)

theorem identity35318 : scanCanonicalize (H12AffineFastState.compose env35318 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35318 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35319 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,1060,41,0,0,35,17,2048,1025,1,1077,32,17,2,40,16,2048,16,1061,2049,1056,32,36,33,0,513]

theorem envBound35319 : H12AffineFastState.Bounded env35319 := by
  intro p hp
  have h : env35319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35318_35319 : H12AffineEnvironment.transform 7 37 env35318 = env35319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35318 == env35319) = true)

def env35320 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,140420,272512,180224,41350,8328,17,23944,185600,45445,262145,143641,400541,257,21792,46212,180752]

theorem envBound35320 : H12AffineFastState.Bounded env35320 := by
  intro p hp
  have h : env35320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35310_35320 : H12AffineEnvironment.transform 5 17 env35310 = env35320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35310 == env35320) = true)

theorem identity35320 : scanCanonicalize (H12AffineFastState.compose env35320 (packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound35320 : packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS < 2^1333 := by decide +kernel

def env35321 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,157753,1025,32769,140420,147641,180224,41350,8328,17,23944,185600,45445,157752,143641,29860,257,21792,46212,180752]

theorem envBound35321 : H12AffineFastState.Bounded env35321 := by
  intro p hp
  have h : env35321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35320_35321 : H12AffineEnvironment.transform 17 157753 env35320 = env35321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env35320 == env35321) = true)

theorem identity35321 : scanCanonicalize (H12AffineFastState.compose env35321 (packedSelected [1,4,5,7,8,9,10,11,16,18,20,23,24,27,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound35321 : packedSelected [1,4,5,7,8,9,10,11,16,18,20,23,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env35322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,49305,43168,1025,32769,58397,32800,153,41350,8328,17,23944,5529,45445,43169,61824,29860,257,21792,46212,649]

theorem envBound35322 : H12AffineFastState.Bounded env35322 := by
  intro p hp
  have h : env35322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35321_35322 : H12AffineEnvironment.transform 16 49305 env35321 = env35322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env35321 == env35322) = true)

theorem identity35322 : scanCanonicalize (H12AffineFastState.compose env35322 (packedSelected [3,5,10,12,15,16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35322 : packedSelected [3,5,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env35323 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,32768,54415,49305,35244,1025,32769,50449,32800,153,32906,388,17,23944,5529,37001,35245,53388,21928,257,21792,38280,649]

theorem envBound35323 : H12AffineFastState.Bounded env35323 := by
  intro p hp
  have h : env35323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35322_35323 : H12AffineEnvironment.transform 12 268 env35322 = env35323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35322 == env35323) = true)

theorem identity35323 : scanCanonicalize (H12AffineFastState.compose env35323 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound35323 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35324 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,136,21511,16401,2340,1025,137,17817,168,153,2,388,17,23944,5529,4097,2341,20484,21928,257,21792,5376,649]

theorem envBound35324 : H12AffineFastState.Bounded env35324 := by
  intro p hp
  have h : env35324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35323_35324 : H12AffineEnvironment.transform 14 136 env35323 = env35324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env35323 == env35324) = true)

theorem identity35324 : scanCanonicalize (H12AffineFastState.compose env35324 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35324 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env35325 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,136,262,5392,2340,1025,137,4248,168,153,2,388,17,2185,5529,4097,2341,1285,169,257,33,5376,649]

theorem envBound35325 : H12AffineFastState.Bounded env35325 := by
  intro p hp
  have h : env35325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35324_35325 : H12AffineEnvironment.transform 13 5377 env35324 = env35325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35324 == env35325) = true)

theorem identity35325 : scanCanonicalize (H12AffineFastState.compose env35325 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound35325 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env35326 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,308,268,1077,136,262,1060,2340,1025,137,428,168,153,2,388,17,2185,1197,309,2341,1285,169,257,33,1076,649]

theorem envBound35326 : H12AffineFastState.Bounded env35326 := by
  intro p hp
  have h : env35326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35325_35326 : H12AffineEnvironment.transform 11 308 env35325 = env35326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env35325 == env35326) = true)

theorem identity35326 : scanCanonicalize (H12AffineFastState.compose env35326 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound35326 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env35327 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1076,308,268,1077,136,262,1060,1296,1025,137,428,168,153,2,388,17,1213,1197,309,1297,1285,169,257,33,1076,649]

theorem envBound35327 : H12AffineFastState.Bounded env35327 := by
  intro p hp
  have h : env35327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35326_35327 : H12AffineEnvironment.transform 10 1076 env35326 = env35327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env35326 == env35327) = true)

theorem identity35327 : scanCanonicalize (H12AffineFastState.compose env35327 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound35327 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35328 : List Nat := [2,4,8,16,32,17,128,256,512,189,137,308,268,136,136,262,153,429,188,137,428,168,153,2,388,17,0,16,309,428,440,169,257,33,137,649]

theorem envBound35328 : H12AffineFastState.Bounded env35328 := by
  intro p hp
  have h : env35328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35327_35328 : H12AffineEnvironment.transform 9 189 env35327 = env35328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env35327 == env35328) = true)

def env35329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180224,95497,8328,64,23945,185600,45524,262145,143641,400589,257,21792,46212,202446]

theorem envBound35329 : H12AffineFastState.Bounded env35329 := by
  intro p hp
  have h : env35329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35308_35329 : H12AffineEnvironment.transform 21 272513 env35308 = env35329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35308 == env35329) = true)

theorem identity35329 : scanCanonicalize (H12AffineFastState.compose env35329 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound35329 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,77899,272513,120015,95497,8328,64,23945,115151,45524,262145,75222,329730,257,21792,46212,513]

theorem envBound35330 : H12AffineFastState.Bounded env35330 := by
  intro p hp
  have h : env35330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35329_35330 : H12AffineEnvironment.transform 16 70863 env35329 = env35330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env35329 == env35330) = true)

def env35331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,77899,272393,119879,95497,8192,64,23809,115015,45404,262145,75102,329730,257,21792,46092,513]

theorem envBound35331 : H12AffineFastState.Bounded env35331 := by
  intro p hp
  have h : env35331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35330_35331 : H12AffineEnvironment.transform 6 8 env35330 = env35331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35330 == env35331) = true)

def env35332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272392,119878,95497,8193,64,23808,115014,45405,262145,75103,329730,257,21792,46093,513]

theorem envBound35332 : H12AffineFastState.Bounded env35332 := by
  intro p hp
  have h : env35332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35330_35332 : H12AffineEnvironment.transform 6 9 env35330 = env35332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35330 == env35332) = true)

theorem identity35332 : scanCanonicalize (H12AffineFastState.compose env35332 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35332 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,70726,262144,1025,32769,77899,272392,106523,65876,8193,64,10589,111899,45405,262145,75103,329730,257,8573,46093,513]

theorem envBound35333 : H12AffineFastState.Bounded env35333 := by
  intro p hp
  have h : env35333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35332_35333 : H12AffineEnvironment.transform 13 13405 env35332 = env35333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35332 == env35333) = true)

theorem identity35333 : scanCanonicalize (H12AffineFastState.compose env35333 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound35333 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,41050,46108,262144,1025,32769,36881,272392,65,41230,8193,64,10589,5441,45405,262145,34053,305240,257,8573,46093,513]

theorem envBound35334 : H12AffineFastState.Bounded env35334 := by
  intro p hp
  have h : env35334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35333_35334 : H12AffineEnvironment.transform 15 41050 env35333 = env35334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env35333 == env35334) = true)

theorem identity35334 : scanCanonicalize (H12AffineFastState.compose env35334 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound35334 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,32768,34098,37236,262144,1025,32769,36881,265568,65,33894,1385,64,3125,5441,37941,262145,34053,298288,257,1045,37221,513]

theorem envBound35335 : H12AffineFastState.Bounded env35335 := by
  intro p hp
  have h : env35335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35334_35335 : H12AffineEnvironment.transform 12 1384 env35334 = env35335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env35334 == env35335) = true)

theorem identity35335 : scanCanonicalize (H12AffineFastState.compose env35335 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 3393) := by decide +kernel

theorem selectedBound35335 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,32768,34098,37236,3393,1025,32769,36881,33,65,33894,1385,64,3125,5441,37941,3392,34053,32881,257,1045,37221,513]

theorem envBound35336 : H12AffineFastState.Bounded env35336 := by
  intro p hp
  have h : env35336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35335_35336 : H12AffineEnvironment.transform 17 3393 env35335 = env35336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3393 env35335 == env35336) = true)

theorem identity35336 : scanCanonicalize (H12AffineFastState.compose env35336 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 7504) := by decide +kernel

theorem selectedBound35336 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env35337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,7504,6242,3108,3393,1025,7505,3393,33,65,6454,1385,64,3125,5441,2405,3392,6229,7457,257,1045,3125,513]

theorem envBound35337 : H12AffineFastState.Bounded env35337 := by
  intro p hp
  have h : env35337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35336_35337 : H12AffineEnvironment.transform 14 7504 env35336 = env35337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7504 env35336 == env35337) = true)

theorem identity35337 : scanCanonicalize (H12AffineFastState.compose env35337 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35337 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35338 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,268,4405,6452,6242,2112,2341,101,6453,2341,33,65,6454,269,64,2129,4389,2405,2340,6229,6469,257,113,2129,513]

theorem envBound35338 : H12AffineFastState.Bounded env35338 := by
  intro p hp
  have h : env35338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35337_35338 : H12AffineEnvironment.transform 9 100 env35337 = env35338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35337 == env35338) = true)

theorem identity35338 : scanCanonicalize (H12AffineFastState.compose env35338 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound35338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35339 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2357,268,2048,1,343,2112,2341,101,0,2341,33,65,3,269,64,2129,2064,2405,2340,352,112,257,113,2129,513]

theorem envBound35339 : H12AffineFastState.Bounded env35339 := by
  intro p hp
  have h : env35339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35338_35339 : H12AffineEnvironment.transform 11 2357 env35338 = env35339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env35338 == env35339) = true)

theorem identity35339 : scanCanonicalize (H12AffineFastState.compose env35339 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35339 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35340 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2357,268,2048,1,263,2064,2341,53,0,2341,33,17,3,269,16,2049,2064,2357,2340,304,32,257,33,2049,513]

theorem envBound35340 : H12AffineFastState.Bounded env35340 := by
  intro p hp
  have h : env35340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35339_35340 : H12AffineEnvironment.transform 5 16 env35339 = env35340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35339 == env35340) = true)

theorem identity35340 : scanCanonicalize (H12AffineFastState.compose env35340 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound35340 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35341 : List Nat := [2,4,8,16,32,16,9,256,512,52,309,0,268,309,1,263,293,16,53,0,16,33,17,3,269,16,308,293,0,17,304,32,257,33,308,513]

theorem envBound35341 : H12AffineFastState.Bounded env35341 := by
  intro p hp
  have h : env35341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35340_35341 : H12AffineEnvironment.transform 10 309 env35340 = env35341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env35340 == env35341) = true)

theorem identity35341 : scanCanonicalize (H12AffineFastState.compose env35341 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound35341 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35342 : List Nat := [2,4,8,16,32,16,9,256,293,52,309,0,268,309,1,263,293,16,53,0,16,33,17,3,269,16,308,293,0,17,304,32,257,33,308,292]

theorem envBound35342 : H12AffineFastState.Bounded env35342 := by
  intro p hp
  have h : env35342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35341_35342 : H12AffineEnvironment.transform 8 293 env35341 = env35342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env35341 == env35342) = true)

theorem identity35342 : scanCanonicalize (H12AffineFastState.compose env35342 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35342 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35343 : List Nat := [2,4,8,16,32,16,9,36,1,52,17,0,40,17,1,35,1,16,53,0,16,33,17,3,41,16,16,1,0,17,20,32,37,33,16,0]

theorem envBound35343 : H12AffineFastState.Bounded env35343 := by
  intro p hp
  have h : env35343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35342_35343 : H12AffineEnvironment.transform 7 36 env35342 = env35343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35342 == env35343) = true)

theorem identity35343 : scanCanonicalize (H12AffineFastState.compose env35343 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35344 : List Nat := [2,4,8,11,32,11,9,36,1,47,10,0,40,10,1,35,1,11,46,0,11,33,10,3,41,11,11,1,0,10,15,32,37,33,11,0]

theorem envBound35344 : H12AffineFastState.Bounded env35344 := by
  intro p hp
  have h : env35344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35343_35344 : H12AffineEnvironment.transform 3 11 env35343 = env35344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35343 == env35344) = true)

def env35345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180225,95496,8328,64,4486408,185601,45525,262144,143641,4338765,257,21792,46212,202446]

theorem envBound35345 : H12AffineFastState.Bounded env35345 := by
  intro p hp
  have h : env35345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35307_35345 : H12AffineEnvironment.transform 22 180225 env35307 = env35345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env35307 == env35345) = true)

def env35346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180225,95496,8328,64,23944,185601,45525,262144,143641,400589,257,21792,46212,202446]

theorem envBound35346 : H12AffineFastState.Bounded env35346 := by
  intro p hp
  have h : env35346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35345_35346 : H12AffineEnvironment.transform 21 272512 env35345 = env35346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35345 == env35346) = true)

theorem identity35346 : scanCanonicalize (H12AffineFastState.compose env35346 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35346 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140420,272512,180225,21762,8328,64,23944,185601,45525,262144,143641,400589,257,21792,46212,145092]

theorem envBound35347 : H12AffineFastState.Bounded env35347 := by
  intro p hp
  have h : env35347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35346_35347 : H12AffineEnvironment.transform 15 8202 env35346 = env35347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35346 == env35347) = true)

def env35348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140300,272392,180225,21762,8192,64,23808,185601,45405,262144,143641,400453,257,21792,46092,144972]

theorem envBound35348 : H12AffineFastState.Bounded env35348 := by
  intro p hp
  have h : env35348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35347_35348 : H12AffineEnvironment.transform 6 8 env35347 = env35348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35347 == env35348) = true)

def env35349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,58396,272392,17,21762,8192,64,23808,5393,45405,262144,61705,318549,257,21792,46092,63068]

theorem envBound35349 : H12AffineFastState.Bounded env35349 := by
  intro p hp
  have h : env35349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35348_35349 : H12AffineEnvironment.transform 16 49168 env35348 = env35349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35348 == env35349) = true)

theorem identity35349 : scanCanonicalize (H12AffineFastState.compose env35349 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35349 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10280,1025,32769,58396,32,17,21762,8192,64,23808,5393,45405,10280,61705,62589,257,21792,46092,63068]

theorem envBound35350 : H12AffineFastState.Bounded env35350 := by
  intro p hp
  have h : env35350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35349_35350 : H12AffineEnvironment.transform 17 10280 env35349 = env35350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35349 == env35350) = true)

theorem identity35350 : scanCanonicalize (H12AffineFastState.compose env35350 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35350 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env35351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,5393,10280,1025,21760,12573,32,17,21762,8192,64,23808,5393,25692,10280,9224,8572,257,21792,24845,9053]

theorem envBound35351 : H12AffineFastState.Bounded env35351 := by
  intro p hp
  have h : env35351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35350_35351 : H12AffineEnvironment.transform 14 21761 env35350 = env35351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35350 == env35351) = true)

theorem identity35351 : scanCanonicalize (H12AffineFastState.compose env35351 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35351 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,8202,5393,10280,1025,0,12573,32,17,2,8192,64,2048,5393,12636,10280,9224,8572,257,32,13325,9053]

theorem envBound35352 : H12AffineFastState.Bounded env35352 := by
  intro p hp
  have h : env35352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35351_35352 : H12AffineEnvironment.transform 13 5376 env35351 = env35352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35351 == env35352) = true)

theorem identity35352 : scanCanonicalize (H12AffineFastState.compose env35352 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35352 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env35353 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,1,8202,5221,10280,1025,0,12393,32,17,2,8192,64,2048,5221,12328,10280,9224,8200,117,32,13325,8745]

theorem envBound35353 : H12AffineFastState.Bounded env35353 := by
  intro p hp
  have h : env35353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35352_35353 : H12AffineEnvironment.transform 7 116 env35352 = env35353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35352 == env35353) = true)

theorem identity35353 : scanCanonicalize (H12AffineFastState.compose env35353 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35353 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env35354 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,4096,8192,5236,1,8202,5221,8233,1025,0,12393,32,17,2,8192,64,1,5221,12328,8233,9224,8200,117,32,13325,8745]

theorem envBound35354 : H12AffineFastState.Bounded env35354 := by
  intro p hp
  have h : env35354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35353_35354 : H12AffineEnvironment.transform 10 1 env35353 = env35354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35353 == env35354) = true)

theorem identity35354 : scanCanonicalize (H12AffineFastState.compose env35354 (packedSelected [0,3,5,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound35354 : packedSelected [0,3,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env35355 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,4096,1101,5236,1,1095,5221,1124,1025,0,5156,32,17,2,1101,64,1,5221,5221,1124,69,1093,117,32,4160,1636]

theorem envBound35355 : H12AffineFastState.Bounded env35355 := by
  intro p hp
  have h : env35355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35354_35355 : H12AffineEnvironment.transform 12 1101 env35354 = env35355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env35354 == env35355) = true)

theorem identity35355 : scanCanonicalize (H12AffineFastState.compose env35355 (packedSelected [3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound35355 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env35356 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,1141,1101,1,1,1095,16,1124,1025,0,81,32,17,2,1101,64,1,16,16,1124,69,1093,117,32,1077,1636]

theorem envBound35356 : H12AffineFastState.Bounded env35356 := by
  intro p hp
  have h : env35356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35355_35356 : H12AffineEnvironment.transform 11 1141 env35355 = env35356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env35355 == env35356) = true)

theorem identity35356 : scanCanonicalize (H12AffineFastState.compose env35356 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35356 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35357 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,1061,1053,1,1,1047,16,1076,1025,0,1,32,17,2,1053,16,1,16,16,1076,21,1045,37,32,1077,1588]

theorem envBound35357 : H12AffineFastState.Bounded env35357 := by
  intro p hp
  have h : env35357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35356_35357 : H12AffineEnvironment.transform 5 16 env35356 = env35357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35356 == env35357) = true)

theorem identity35357 : scanCanonicalize (H12AffineFastState.compose env35357 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35357 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env35358 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,41,1,1,35,16,0,53,0,1,32,17,2,41,16,1,16,16,0,21,33,37,32,1,512]

theorem envBound35358 : H12AffineFastState.Bounded env35358 := by
  intro p hp
  have h : env35358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35357_35358 : H12AffineEnvironment.transform 9 52 env35357 = env35358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35357 == env35358) = true)

theorem identity35358 : scanCanonicalize (H12AffineFastState.compose env35358 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound35358 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35359 : List Nat := [2,4,8,16,32,16,8,36,20,52,1,17,41,1,1,35,16,0,53,0,1,32,17,2,41,16,1,16,16,0,21,33,37,32,1,20]

theorem envBound35359 : H12AffineFastState.Bounded env35359 := by
  intro p hp
  have h : env35359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35358_35359 : H12AffineEnvironment.transform 8 20 env35358 = env35359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env35358 == env35359) = true)

theorem identity35359 : scanCanonicalize (H12AffineFastState.compose env35359 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound35359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35360 : List Nat := [2,4,8,16,7,16,8,3,20,19,1,17,14,1,1,4,16,0,18,0,1,7,17,2,14,16,1,16,16,0,21,6,2,7,1,20]

theorem envBound35360 : H12AffineFastState.Bounded env35360 := by
  intro p hp
  have h : env35360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35359_35360 : H12AffineEnvironment.transform 4 7 env35359 = env35360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env35359 == env35360) = true)

theorem identity35360 : scanCanonicalize (H12AffineFastState.compose env35360 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound35360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35361 : List Nat := [2,4,8,6,7,6,8,3,2,5,1,7,14,1,1,4,6,0,4,0,1,7,7,2,14,6,1,6,6,0,3,6,2,7,1,2]

theorem envBound35361 : H12AffineFastState.Bounded env35361 := by
  intro p hp
  have h : env35361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35360_35361 : H12AffineEnvironment.transform 3 6 env35360 = env35361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env35360 == env35361) = true)

theorem identity35361 : scanCanonicalize (H12AffineFastState.compose env35361 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35361 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35362 : List Nat := [2,4,4,6,7,6,4,3,2,5,1,7,2,1,1,4,6,0,4,0,1,7,7,2,2,6,1,6,6,0,3,6,2,7,1,2]

theorem envBound35362 : H12AffineFastState.Bounded env35362 := by
  intro p hp
  have h : env35362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35361_35362 : H12AffineEnvironment.transform 2 4 env35361 = env35362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35361 == env35362) = true)

theorem identity35362 : scanCanonicalize (H12AffineFastState.compose env35362 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35362 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35363 : List Nat := [2,2,2,0,1,0,2,3,2,3,1,1,2,1,1,2,0,0,2,0,1,1,1,2,2,0,1,0,0,0,3,0,2,1,1,2]

theorem envBound35363 : H12AffineFastState.Bounded env35363 := by
  intro p hp
  have h : env35363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35362_35363 : H12AffineEnvironment.transform 1 2 env35362 = env35363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35362 == env35363) = true)

def env35364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,58397,272392,16,21762,8192,64,23808,5392,45405,262144,61704,318548,257,21792,46092,63069]

theorem envBound35364 : H12AffineFastState.Bounded env35364 := by
  intro p hp
  have h : env35364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35348_35364 : H12AffineEnvironment.transform 16 49169 env35348 = env35364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35348 == env35364) = true)

theorem identity35364 : scanCanonicalize (H12AffineFastState.compose env35364 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35364 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env35365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49169,262144,1025,32769,50497,264532,16,21762,348,64,23808,5392,36865,262144,53332,318548,257,21792,38224,55041]

theorem envBound35365 : H12AffineFastState.Bounded env35365 := by
  intro p hp
  have h : env35365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35364_35365 : H12AffineEnvironment.transform 12 348 env35364 = env35365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35364 == env35365) = true)

def env35366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140301,272393,180225,21762,8193,64,23809,185601,45404,262144,143641,400452,257,21792,46093,144973]

theorem envBound35366 : H12AffineFastState.Bounded env35366 := by
  intro p hp
  have h : env35366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35347_35366 : H12AffineEnvironment.transform 6 9 env35347 = env35366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35347 == env35366) = true)

def env35367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,58397,272393,17,21762,8193,64,23809,5393,45404,262144,61705,318548,257,21792,46093,63069]

theorem envBound35367 : H12AffineFastState.Bounded env35367 := by
  intro p hp
  have h : env35367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35366_35367 : H12AffineEnvironment.transform 16 49168 env35366 = env35367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35366 == env35367) = true)

theorem identity35367 : scanCanonicalize (H12AffineFastState.compose env35367 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound35367 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,35189,1025,32769,58397,41340,17,21762,8193,64,23809,5393,45404,35189,61705,21793,257,21792,46093,63069]

theorem envBound35368 : H12AffineFastState.Bounded env35368 := by
  intro p hp
  have h : env35368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35367_35368 : H12AffineEnvironment.transform 17 35189 env35367 = env35368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env35367 == env35368) = true)

theorem identity35368 : scanCanonicalize (H12AffineFastState.compose env35368 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35368 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env35369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24909,10280,1025,8540,17728,33,17,21762,8193,64,23809,5393,4097,10280,20564,21793,257,21792,5456,22272]

theorem envBound35369 : H12AffineFastState.Bounded env35369 := by
  intro p hp
  have h : env35369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35368_35369 : H12AffineEnvironment.transform 14 8541 env35368 = env35369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35368 == env35369) = true)

theorem identity35369 : scanCanonicalize (H12AffineFastState.compose env35369 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35369 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env35370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8202,5392,10280,1025,8540,12573,33,17,8543,8193,64,10588,5393,4097,10280,9225,8572,257,8573,5456,9053]

theorem envBound35370 : H12AffineFastState.Bounded env35370 := by
  intro p hp
  have h : env35370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35369_35370 : H12AffineEnvironment.transform 13 13405 env35369 = env35370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35369 == env35370) = true)

theorem identity35370 : scanCanonicalize (H12AffineFastState.compose env35370 (packedSelected [2,5,6,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6477) := by decide +kernel

theorem selectedBound35370 : packedSelected [2,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6477,3344,6160,6471,5392,4453,1025,6161,2128,33,17,6162,6476,64,4113,5393,4097,4453,7492,6193,257,6192,5456,6672]

theorem envBound35371 : H12AffineFastState.Bounded env35371 := by
  intro p hp
  have h : env35371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35370_35371 : H12AffineEnvironment.transform 12 6477 env35370 = env35371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6477 env35370 == env35371) = true)

theorem identity35371 : scanCanonicalize (H12AffineFastState.compose env35371 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35371 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env35372 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,6200,3173,6160,6194,5221,4112,1025,6161,2128,33,17,6162,6201,64,4113,5220,4097,4112,7217,6193,116,6192,5157,6672]

theorem envBound35372 : H12AffineFastState.Bounded env35372 := by
  intro p hp
  have h : env35372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35371_35372 : H12AffineEnvironment.transform 7 117 env35371 = env35372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35371 == env35372) = true)

theorem identity35372 : scanCanonicalize (H12AffineFastState.compose env35372 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound35372 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env35373 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,64,2168,3173,2128,2162,1061,80,1025,2129,2128,33,17,2130,2169,64,81,1060,65,80,3185,2161,116,2160,1125,2640]

theorem envBound35373 : H12AffineFastState.Bounded env35373 := by
  intro p hp
  have h : env35373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35372_35373 : H12AffineEnvironment.transform 11 64 env35372 = env35373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env35372 == env35373) = true)

theorem identity35373 : scanCanonicalize (H12AffineFastState.compose env35373 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound35373 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35374 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,64,40,1077,0,34,1061,80,1025,1,0,33,17,2,41,64,81,1060,65,80,1057,33,116,32,1125,512]

theorem envBound35374 : H12AffineFastState.Bounded env35374 := by
  intro p hp
  have h : env35374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35373_35374 : H12AffineEnvironment.transform 10 80 env35373 = env35374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env35373 == env35374) = true)

theorem identity35374 : scanCanonicalize (H12AffineFastState.compose env35374 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35375 : List Nat := [2,4,8,16,32,49,9,4,512,1024,33,49,40,1077,0,34,1061,33,1025,1,0,33,17,2,41,49,32,1060,48,33,1057,33,5,32,1044,512]

theorem envBound35375 : H12AffineFastState.Bounded env35375 := by
  intro p hp
  have h : env35375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35374_35375 : H12AffineEnvironment.transform 5 49 env35374 = env35375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35374 == env35375) = true)

theorem identity35375 : scanCanonicalize (H12AffineFastState.compose env35375 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35375 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35376 : List Nat := [2,4,8,16,32,49,9,4,512,53,33,49,40,0,0,34,16,33,52,1,0,33,17,2,41,49,32,17,48,33,20,33,5,32,33,512]

theorem envBound35376 : H12AffineFastState.Bounded env35376 := by
  intro p hp
  have h : env35376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35375_35376 : H12AffineEnvironment.transform 9 53 env35375 = env35376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35375 == env35376) = true)

def env35377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,58396,272393,16,21762,8193,64,23809,5392,45404,262144,61704,318549,257,21792,46093,63068]

theorem envBound35377 : H12AffineFastState.Bounded env35377 := by
  intro p hp
  have h : env35377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35366_35377 : H12AffineEnvironment.transform 16 49169 env35366 = env35377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35366 == env35377) = true)

theorem identity35377 : scanCanonicalize (H12AffineFastState.compose env35377 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35377 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24909,262144,1025,8541,17728,272393,16,21762,8193,64,23809,5392,4096,262144,20564,294153,257,21792,5457,22272]

theorem envBound35378 : H12AffineFastState.Bounded env35378 := by
  intro p hp
  have h : env35378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35377_35378 : H12AffineEnvironment.transform 14 8540 env35377 = env35378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35377 == env35378) = true)

theorem identity35378 : scanCanonicalize (H12AffineFastState.compose env35378 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound35378 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24909,32041,1025,8541,17728,21792,16,21762,8193,64,23809,5392,4096,32041,20564,32,257,21792,5457,22272]

theorem envBound35379 : H12AffineFastState.Bounded env35379 := by
  intro p hp
  have h : env35379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35378_35379 : H12AffineEnvironment.transform 17 32041 env35378 = env35379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env35378 == env35379) = true)

theorem identity35379 : scanCanonicalize (H12AffineFastState.compose env35379 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35379 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35380 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,8540,8202,24909,31005,53,8541,16756,20756,16,20790,8193,64,22837,4388,4096,31005,20564,32,257,20756,4453,21300]

theorem envBound35380 : H12AffineFastState.Bounded env35380 := by
  intro p hp
  have h : env35380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35379_35380 : H12AffineEnvironment.transform 9 52 env35379 = env35380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35379 == env35380) = true)

theorem identity35380 : scanCanonicalize (H12AffineFastState.compose env35380 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound35380 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env35381 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,6429,16384,6209,6423,22608,16384,53,6208,16756,20756,16,20790,6428,64,22837,4388,4096,16384,20564,32,257,20756,4453,21300]

theorem envBound35381 : H12AffineFastState.Bounded env35381 := by
  intro p hp
  have h : env35381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35380_35381 : H12AffineEnvironment.transform 12 6429 env35380 = env35381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env35380 == env35381) = true)

theorem identity35381 : scanCanonicalize (H12AffineFastState.compose env35381 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound35381 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35382 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,357,2168,16384,2340,2162,18741,16384,53,2341,16756,16497,16,16467,2169,64,18512,65,357,16384,16689,32,257,16497,0,16977]

theorem envBound35382 : H12AffineFastState.Bounded env35382 := by
  intro p hp
  have h : env35382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35381_35382 : H12AffineEnvironment.transform 11 357 env35381 = env35382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env35381 == env35382) = true)

theorem identity35382 : scanCanonicalize (H12AffineFastState.compose env35382 (packedSelected [2,3,4,5,9,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound35382 : packedSelected [2,3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env35383 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,357,2168,2049,2340,2162,308,2049,53,2341,2421,2160,16,2130,2169,64,81,65,357,2049,2352,32,257,2160,0,2640]

theorem envBound35383 : H12AffineFastState.Bounded env35383 := by
  intro p hp
  have h : env35383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35382_35383 : H12AffineEnvironment.transform 13 2049 env35382 = env35383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env35382 == env35383) = true)

def env35384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180225,95496,8328,64,23945,185601,45525,262144,143641,400588,257,21792,46212,202446]

theorem envBound35384 : H12AffineFastState.Bounded env35384 := by
  intro p hp
  have h : env35384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35345_35384 : H12AffineEnvironment.transform 21 272513 env35345 = env35384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35345 == env35384) = true)

theorem identity35384 : scanCanonicalize (H12AffineFastState.compose env35384 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound35384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115870,272513,73755,95496,8328,64,23945,79131,45525,262144,119043,392406,257,21792,46212,63188]

theorem envBound35385 : H12AffineFastState.Bounded env35385 := by
  intro p hp
  have h : env35385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35384_35385 : H12AffineEnvironment.transform 16 122906 env35384 = env35385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env35384 == env35385) = true)

def env35386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10400,1025,32769,115870,33,73755,95496,8328,64,23945,79131,45525,10400,119043,119926,257,21792,46212,63188]

theorem envBound35386 : H12AffineFastState.Bounded env35386 := by
  intro p hp
  have h : env35386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35385_35386 : H12AffineEnvironment.transform 17 10400 env35385 = env35386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35385 == env35386) = true)

theorem identity35386 : scanCanonicalize (H12AffineFastState.compose env35386 (packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound35386 : packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env35387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,5393,10400,1025,32769,12693,33,54544,32771,8328,64,23945,49168,45525,10400,9224,8573,257,21792,46212,63188]

theorem envBound35387 : H12AffineFastState.Bounded env35387 := by
  intro p hp
  have h : env35387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35386_35387 : H12AffineEnvironment.transform 15 62731 env35386 = env35387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env35386 == env35387) = true)

theorem identity35387 : scanCanonicalize (H12AffineFastState.compose env35387 (packedSelected [2,5,6,9,10,11,12,14,15,16,17,20,22,23,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound35387 : packedSelected [2,5,6,9,10,11,12,14,15,16,17,20,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env35388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8323,5393,10400,1025,21897,12693,33,152,21899,8328,64,23945,5528,25693,10400,9224,8573,257,21792,24844,9052]

theorem envBound35388 : H12AffineFastState.Bounded env35388 := by
  intro p hp
  have h : env35388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35387_35388 : H12AffineEnvironment.transform 14 21896 env35387 = env35388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env35387 == env35388) = true)

theorem identity35388 : scanCanonicalize (H12AffineFastState.compose env35388 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35388 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env35389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8660,8323,5393,10400,1025,8661,12693,33,152,8663,8328,64,10709,5528,4097,10400,9224,8573,257,8572,5456,9052]

theorem envBound35389 : H12AffineFastState.Bounded env35389 := by
  intro p hp
  have h : env35389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35388_35389 : H12AffineEnvironment.transform 13 13404 env35388 = env35389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35388 == env35389) = true)

theorem identity35389 : scanCanonicalize (H12AffineFastState.compose env35389 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35389 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,8203,5393,10280,1025,8541,12573,33,16,8543,8192,64,10589,5392,4097,10280,9224,8573,257,8572,5456,9052]

theorem envBound35390 : H12AffineFastState.Bounded env35390 := by
  intro p hp
  have h : env35390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35389_35390 : H12AffineEnvironment.transform 6 8 env35389 = env35390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35389 == env35390) = true)

theorem identity35390 : scanCanonicalize (H12AffineFastState.compose env35390 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35390 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,80,263,5393,2340,1025,81,4113,33,16,83,268,64,2129,5392,4097,2340,1284,113,257,112,5456,592]

theorem envBound35391 : H12AffineFastState.Bounded env35391 := by
  intro p hp
  have h : env35391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35390_35391 : H12AffineEnvironment.transform 12 268 env35390 = env35391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35390 == env35391) = true)

theorem identity35391 : scanCanonicalize (H12AffineFastState.compose env35391 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35391 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35392 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1025,0,4113,33,16,2,268,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound35392 : H12AffineFastState.Bounded env35392 := by
  intro p hp
  have h : env35392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35391_35392 : H12AffineEnvironment.transform 5 17 env35391 = env35392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35391 == env35392) = true)

theorem identity35392 : scanCanonicalize (H12AffineFastState.compose env35392 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35392 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35393 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5172,2049,1025,0,4113,33,16,2,41,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound35393 : H12AffineFastState.Bounded env35393 := by
  intro p hp
  have h : env35393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35392_35393 : H12AffineEnvironment.transform 7 37 env35392 = env35393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35392 == env35393) = true)

def env35394 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,1,34,1028,2049,1025,0,33,33,16,2,41,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound35394 : H12AffineFastState.Bounded env35394 := by
  intro p hp
  have h : env35394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35393_35394 : H12AffineEnvironment.transform 11 48 env35393 = env35394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35393 == env35394) = true)

theorem identity35394 : scanCanonicalize (H12AffineFastState.compose env35394 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound35394 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35395 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,48,41,561,1,34,545,2049,548,0,33,33,16,2,41,17,2048,544,49,2049,516,32,36,33,561,513]

theorem envBound35395 : H12AffineFastState.Bounded env35395 := by
  intro p hp
  have h : env35395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35394_35395 : H12AffineEnvironment.transform 9 549 env35394 = env35395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env35394 == env35395) = true)

def env35396 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,41,33,1,34,49,2049,52,0,33,33,16,2,41,17,2048,48,49,2049,20,32,36,33,33,17]

theorem envBound35396 : H12AffineFastState.Bounded env35396 := by
  intro p hp
  have h : env35396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35395_35396 : H12AffineEnvironment.transform 8 16 env35395 = env35396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35395 == env35396) = true)

theorem identity35396 : scanCanonicalize (H12AffineFastState.compose env35396 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound35396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35397 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,48,41,33,1,34,49,33,52,0,33,33,16,2,41,17,32,48,49,33,20,32,36,33,33,17]

theorem envBound35397 : H12AffineFastState.Bounded env35397 := by
  intro p hp
  have h : env35397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35396_35397 : H12AffineEnvironment.transform 10 32 env35396 = env35397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env35396 == env35397) = true)

def leafEnv35397 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,48,41,33,1,34,49,33,52,0,33,33,16,2,21,41,1,17,32,48,49,33,20,32,36,33,5,34,33,17,1,33,0]

def active35397 : List Nat := [0,1,2,3,4]

def tree35397 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35397 : H12WitnessSearch.Good tree35397 := H12GlobalWitnessIndex.good

theorem leafIdentity35397 : H12AffineFastState.composeSystem env35397 rootObs = leafEnv35397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35397 rootObs == leafEnv35397) = true)

theorem terminalChecked35397 : H12PackedTerminal.terminalCheckFast leafEnv35397 active35397 tree35397 = true := by decide +kernel

def env35398 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,41,32,1,34,48,2049,53,0,33,33,16,2,41,17,2048,49,49,2049,21,32,36,33,32,16]

theorem envBound35398 : H12AffineFastState.Bounded env35398 := by
  intro p hp
  have h : env35398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35395_35398 : H12AffineEnvironment.transform 8 17 env35395 = env35398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35395 == env35398) = true)

theorem identity35398 : scanCanonicalize (H12AffineFastState.compose env35398 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound35398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35399 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,41,32,1,34,48,27,53,0,33,33,16,2,41,17,26,49,49,27,21,32,36,33,32,16]

theorem envBound35399 : H12AffineFastState.Bounded env35399 := by
  intro p hp
  have h : env35399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35398_35399 : H12AffineEnvironment.transform 10 26 env35398 = env35399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env35398 == env35399) = true)

def leafEnv35399 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,41,32,1,34,48,27,53,0,33,33,16,2,20,41,1,17,26,49,49,27,21,32,36,33,5,34,32,16,1,33,0]

def active35399 : List Nat := [0,1,2,3,4]

def tree35399 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35399 : H12WitnessSearch.Good tree35399 := H12GlobalWitnessIndex.good

theorem leafIdentity35399 : H12AffineFastState.composeSystem env35399 rootObs = leafEnv35399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35399 rootObs == leafEnv35399) = true)

theorem terminalChecked35399 : H12PackedTerminal.terminalCheckFast leafEnv35399 active35399 tree35399 = true := by decide +kernel

def env35400 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,1,34,1029,2049,1025,0,32,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound35400 : H12AffineFastState.Bounded env35400 := by
  intro p hp
  have h : env35400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35393_35400 : H12AffineEnvironment.transform 11 49 env35393 = env35400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35393 == env35400) = true)

theorem identity35400 : scanCanonicalize (H12AffineFastState.compose env35400 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35401 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,49,41,1045,1,34,1029,2049,1025,0,32,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,16]

theorem envBound35401 : H12AffineFastState.Bounded env35401 := by
  intro p hp
  have h : env35401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35400_35401 : H12AffineEnvironment.transform 8 17 env35400 = env35401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35400 == env35401) = true)

def env35402 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,41,33,1,34,49,2049,53,0,32,33,16,2,41,17,2048,48,48,2049,21,32,36,33,33,16]

theorem envBound35402 : H12AffineFastState.Bounded env35402 := by
  intro p hp
  have h : env35402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35401_35402 : H12AffineEnvironment.transform 9 52 env35401 = env35402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35401 == env35402) = true)

theorem identity35402 : scanCanonicalize (H12AffineFastState.compose env35402 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound35402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35403 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,41,33,1,34,49,27,53,0,32,33,16,2,41,17,26,48,48,27,21,32,36,33,33,16]

theorem envBound35403 : H12AffineFastState.Bounded env35403 := by
  intro p hp
  have h : env35403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35402_35403 : H12AffineEnvironment.transform 10 26 env35402 = env35403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env35402 == env35403) = true)

def leafEnv35403 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,41,33,1,34,49,27,53,0,32,33,16,2,20,41,1,17,26,48,48,27,21,32,36,33,5,34,33,16,1,32,0]

def active35403 : List Nat := [0,1,2,3,4]

def tree35403 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35403 : H12WitnessSearch.Good tree35403 := H12GlobalWitnessIndex.good

theorem leafIdentity35403 : H12AffineFastState.composeSystem env35403 rootObs = leafEnv35403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35403 rootObs == leafEnv35403) = true)

theorem terminalChecked35403 : H12PackedTerminal.terminalCheckFast leafEnv35403 active35403 tree35403 = true := by decide +kernel

def env35404 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,41,32,1,34,48,2049,52,0,32,33,16,2,41,17,2048,49,48,2049,20,32,36,33,32,16]

theorem envBound35404 : H12AffineFastState.Bounded env35404 := by
  intro p hp
  have h : env35404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35401_35404 : H12AffineEnvironment.transform 9 53 env35401 = env35404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35401 == env35404) = true)

theorem identity35404 : scanCanonicalize (H12AffineFastState.compose env35404 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound35404 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35405 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,49,41,32,1,34,48,32,52,0,32,33,16,2,41,17,33,49,48,32,20,32,36,33,32,16]

theorem envBound35405 : H12AffineFastState.Bounded env35405 := by
  intro p hp
  have h : env35405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35404_35405 : H12AffineEnvironment.transform 10 33 env35404 = env35405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env35404 == env35405) = true)

def leafEnv35405 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,49,41,32,1,34,48,32,52,0,32,33,16,2,21,41,1,17,33,49,48,32,20,32,36,33,5,34,32,16,1,32,0]

def active35405 : List Nat := [0,1,2,3,4]

def tree35405 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35405 : H12WitnessSearch.Good tree35405 := H12GlobalWitnessIndex.good

theorem leafIdentity35405 : H12AffineFastState.composeSystem env35405 rootObs = leafEnv35405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35405 rootObs == leafEnv35405) = true)

theorem terminalChecked35405 : H12PackedTerminal.terminalCheckFast leafEnv35405 active35405 tree35405 = true := by decide +kernel

def env35406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10401,1025,32769,115870,32,73755,95496,8328,64,23945,79131,45525,10401,119043,119927,257,21792,46212,63188]

theorem envBound35406 : H12AffineFastState.Bounded env35406 := by
  intro p hp
  have h : env35406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35385_35406 : H12AffineEnvironment.transform 17 10401 env35385 = env35406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35385 == env35406) = true)

theorem identity35406 : scanCanonicalize (H12AffineFastState.compose env35406 (packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound35406 : packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env35407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,70726,10401,1025,29789,78018,32,73755,95496,8328,64,23945,79131,17801,10401,75103,73771,257,21792,16600,648]

theorem envBound35407 : H12AffineFastState.Bounded env35407 := by
  intro p hp
  have h : env35407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35406_35407 : H12AffineEnvironment.transform 14 29788 env35406 = env35407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env35406 == env35407) = true)

theorem identity35407 : scanCanonicalize (H12AffineFastState.compose env35407 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound35407 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env35408 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29788,65536,70726,10361,1025,29789,77850,32,73755,95496,8272,64,23889,79131,17745,10361,75103,73771,257,21792,16384,592]

theorem envBound35408 : H12AffineFastState.Bounded env35408 := by
  intro p hp
  have h : env35408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35407_35408 : H12AffineEnvironment.transform 6 88 env35407 = env35408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env35407 == env35408) = true)

theorem identity35408 : scanCanonicalize (H12AffineFastState.compose env35408 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound35408 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35409 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5237,8233,65536,70726,10361,1025,8232,77850,32,73755,74109,8272,64,2340,79131,4388,10361,75103,73771,257,341,5237,592]

theorem envBound35409 : H12AffineFastState.Bounded env35409 := by
  intro p hp
  have h : env35409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35408_35409 : H12AffineEnvironment.transform 13 5237 env35408 = env35409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env35408 == env35409) = true)

theorem identity35409 : scanCanonicalize (H12AffineFastState.compose env35409 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound35409 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env35410 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5237,8233,8495,13673,10361,1025,8232,4405,32,308,82,8272,64,2340,5172,4388,10361,1136,260,257,341,5237,592]

theorem envBound35410 : H12AffineFastState.Bounded env35410 := by
  intro p hp
  have h : env35410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35409_35410 : H12AffineEnvironment.transform 15 8495 env35409 = env35410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env35409 == env35410) = true)

theorem identity35410 : scanCanonicalize (H12AffineFastState.compose env35410 (packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35410 : packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env35411 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,4096,8192,4160,8233,8495,12636,10361,52,8232,4405,32,308,82,8272,64,2340,4097,4388,10361,69,260,257,341,4160,592]

theorem envBound35411 : H12AffineFastState.Bounded env35411 := by
  intro p hp
  have h : env35411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35410_35411 : H12AffineEnvironment.transform 9 53 env35410 = env35411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35410 == env35411) = true)

theorem identity35411 : scanCanonicalize (H12AffineFastState.compose env35411 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound35411 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env35412 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,4096,121,4160,80,342,4389,2048,52,81,4405,32,308,82,41,64,2340,4097,4388,2048,69,260,257,341,4160,592]

theorem envBound35412 : H12AffineFastState.Bounded env35412 := by
  intro p hp
  have h : env35412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35411_35412 : H12AffineEnvironment.transform 12 121 env35411 = env35412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env35411 == env35412) = true)

theorem identity35412 : scanCanonicalize (H12AffineFastState.compose env35412 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35412 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35413 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,40,4113,1,263,4389,2048,52,0,4405,32,308,3,41,17,2340,4097,4388,2048,20,260,257,260,4113,513]

theorem envBound35413 : H12AffineFastState.Bounded env35413 := by
  intro p hp
  have h : env35413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35412_35413 : H12AffineEnvironment.transform 5 17 env35412 = env35413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35412 == env35413) = true)

theorem identity35413 : scanCanonicalize (H12AffineFastState.compose env35413 (packedSelected [1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2837) := by decide +kernel

theorem selectedBound35413 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env35414 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2837,40,2820,1,263,2608,2048,52,0,2592,32,308,3,41,17,2340,2836,2609,2048,20,260,257,260,2820,513]

theorem envBound35414 : H12AffineFastState.Bounded env35414 := by
  intro p hp
  have h : env35414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35413_35414 : H12AffineEnvironment.transform 11 2837 env35413 = env35414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2837 env35413 == env35414) = true)

theorem identity35414 : scanCanonicalize (H12AffineFastState.compose env35414 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound35414 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env35415 : List Nat := [2,4,8,16,32,17,9,256,512,53,545,308,40,293,1,263,17,545,52,0,1,32,308,3,41,17,773,309,16,545,20,260,257,260,293,513]

theorem envBound35415 : H12AffineFastState.Bounded env35415 := by
  intro p hp
  have h : env35415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35414_35415 : H12AffineEnvironment.transform 10 545 env35414 = env35415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env35414 == env35415) = true)

theorem identity35415 : scanCanonicalize (H12AffineFastState.compose env35415 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35415 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35416 : List Nat := [2,4,8,16,32,17,9,36,512,53,545,16,40,1,1,35,17,545,52,0,1,32,16,3,41,17,545,17,16,545,20,32,37,32,1,513]

theorem envBound35416 : H12AffineFastState.Bounded env35416 := by
  intro p hp
  have h : env35416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35415_35416 : H12AffineEnvironment.transform 7 36 env35415 = env35416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35415 == env35416) = true)

def env35417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound35417 : H12AffineFastState.Bounded env35417 := by
  intro p hp
  have h : env35417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34975_35417 : H12AffineEnvironment.transform 26 30393345 env34975 = env35417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env34975 == env35417) = true)

def env35418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound35418 : H12AffineFastState.Bounded env35418 := by
  intro p hp
  have h : env35418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35417_35418 : H12AffineEnvironment.transform 18 1024 env35417 = env35418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env35417 == env35418) = true)

theorem identity35418 : scanCanonicalize (H12AffineFastState.compose env35418 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41413) := by decide +kernel

theorem selectedBound35418 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41413,16777216,8328,64,21455300,18973836,2159765,418244,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound35419 : H12AffineFastState.Bounded env35419 := by
  intro p hp
  have h : env35419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35418_35419 : H12AffineEnvironment.transform 22 41413 env35418 = env35419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41413 env35418 == env35419) = true)

def env35420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,262144,1024,32769,2097152,4194304,41413,16777216,8328,64,21331968,18973836,2159765,294912,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound35420 : H12AffineFastState.Bounded env35420 := by
  intro p hp
  have h : env35420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35419_35420 : H12AffineEnvironment.transform 16 57796 env35419 = env35420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env35419 == env35420) = true)

def env35421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10280,1024,32769,2097152,4194304,41413,16777216,8328,64,21080104,18973836,2159765,43048,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound35421 : H12AffineFastState.Bounded env35421 := by
  intro p hp
  have h : env35421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35420_35421 : H12AffineEnvironment.transform 17 10280 env35420 = env35421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35420 == env35421) = true)

theorem identity35421 : scanCanonicalize (H12AffineFastState.compose env35421 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35421 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env35422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,16777216,8192,64,21080104,18973700,2159645,43048,16852317,23160136,256,18965864,18973764,16777731]

theorem envBound35422 : H12AffineFastState.Bounded env35422 := by
  intro p hp
  have h : env35422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35421_35422 : H12AffineEnvironment.transform 6 8 env35421 = env35422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35421 == env35422) = true)

theorem identity35422 : scanCanonicalize (H12AffineFastState.compose env35422 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound35422 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302890,2196486,2159645,43048,75103,6382922,256,2188650,2196550,513]

theorem envBound35423 : H12AffineFastState.Bounded env35423 := by
  intro p hp
  have h : env35423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35422_35423 : H12AffineEnvironment.transform 23 2 env35422 = env35423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env35422 == env35423) = true)

theorem identity35423 : scanCanonicalize (H12AffineFastState.compose env35423 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound35423 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env35424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4196384,2106380,2159645,43048,34133,6341952,256,2147680,2106444,513]

theorem envBound35424 : H12AffineFastState.Bounded env35424 := by
  intro p hp
  have h : env35424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35423_35424 : H12AffineEnvironment.transform 15 40970 env35423 = env35424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env35423 == env35424) = true)

theorem identity35424 : scanCanonicalize (H12AffineFastState.compose env35424 (packedSelected [1,2,5,6,8,11,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35424 : packedSelected [1,2,5,6,8,11,17,18,24] rootPS < 2^1333 := by decide +kernel

def env35425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,16400,10280,1024,8541,2097152,4194304,17,2,8192,64,4196384,2106380,2118977,2420,9225,6317084,256,2122812,2106444,513]

theorem envBound35425 : H12AffineFastState.Bounded env35425 := by
  intro p hp
  have h : env35425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35424_35425 : H12AffineEnvironment.transform 14 8540 env35424 = env35425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35424 == env35425) = true)

theorem identity35425 : scanCanonicalize (H12AffineFastState.compose env35425 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound35425 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,16400,10280,1024,8541,2097152,2114913,17,2,8192,64,2116929,2106380,2118977,2420,9225,8573,256,2122812,2106444,513]

theorem envBound35426 : H12AffineFastState.Bounded env35426 := by
  intro p hp
  have h : env35426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35425_35426 : H12AffineEnvironment.transform 21 2114913 env35425 = env35426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env35425 == env35426) = true)

theorem identity35426 : scanCanonicalize (H12AffineFastState.compose env35426 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound35426 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env35427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,16400,10280,1024,8541,17729,32,17,2,8192,64,2048,24909,4096,2420,9225,8573,256,8573,24845,513]

theorem envBound35427 : H12AffineFastState.Bounded env35427 := by
  intro p hp
  have h : env35427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35426_35427 : H12AffineEnvironment.transform 20 17729 env35426 = env35427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env35426 == env35427) = true)

def env35428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10281,1024,32769,2097152,4194304,41413,16777216,8328,64,21080105,18973836,2159765,43049,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound35428 : H12AffineFastState.Bounded env35428 := by
  intro p hp
  have h : env35428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35420_35428 : H12AffineEnvironment.transform 17 10281 env35420 = env35428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35420 == env35428) = true)

theorem identity35428 : scanCanonicalize (H12AffineFastState.compose env35428 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35428 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env35429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16537,10281,1024,8540,2097152,4194304,152,16777216,8328,64,21039476,18949585,2119112,2420,16852437,23160256,256,18965864,18949521,16777731]

theorem envBound35429 : H12AffineFastState.Bounded env35429 := by
  intro p hp
  have h : env35429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35428_35429 : H12AffineEnvironment.transform 14 8541 env35428 = env35429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35428 == env35429) = true)

theorem identity35429 : scanCanonicalize (H12AffineFastState.compose env35429 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound35429 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8322,16537,10281,1024,8540,2097152,4194304,152,16777216,8328,64,20982262,18875731,2119112,2420,16778583,23086402,256,18892266,18875667,16777731]

theorem envBound35430 : H12AffineFastState.Bounded env35430 := by
  intro p hp
  have h : env35430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35429_35430 : H12AffineEnvironment.transform 15 8322 env35429 = env35430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env35429 == env35430) = true)

theorem identity35430 : scanCanonicalize (H12AffineFastState.compose env35430 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound35430 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env35431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8322,16537,10281,1024,8540,2097152,4194304,152,2,8328,64,4205044,2098513,2119112,2420,1365,6309184,256,2115048,2098449,513]

theorem envBound35431 : H12AffineFastState.Bounded env35431 := by
  intro p hp
  have h : env35431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35430_35431 : H12AffineEnvironment.transform 23 2 env35430 = env35431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env35430 == env35431) = true)

theorem identity35431 : scanCanonicalize (H12AffineFastState.compose env35431 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35431 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env35432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8322,16537,10281,1024,8540,5457,4194304,152,2,8328,64,4205044,4096,16537,2420,1365,4214801,256,20665,4160,513]

theorem envBound35432 : H12AffineFastState.Bounded env35432 := by
  intro p hp
  have h : env35432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35431_35432 : H12AffineEnvironment.transform 20 5457 env35431 = env35432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env35431 == env35432) = true)

theorem identity35432 : scanCanonicalize (H12AffineFastState.compose env35432 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound35432 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8322,4232,10281,1024,8540,5457,4194304,152,2,8328,64,4205044,4096,4232,2420,1365,4194304,256,168,4160,513]

theorem envBound35433 : H12AffineFastState.Bounded env35433 := by
  intro p hp
  have h : env35433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35432_35433 : H12AffineEnvironment.transform 13 4113 env35432 = env35433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env35432 == env35433) = true)

theorem identity35433 : scanCanonicalize (H12AffineFastState.compose env35433 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound35433 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env35434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8322,4232,10281,1024,8540,5457,8572,152,2,8328,64,2184,4096,4232,2420,1365,8572,256,168,4160,513]

theorem envBound35434 : H12AffineFastState.Bounded env35434 := by
  intro p hp
  have h : env35434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35433_35434 : H12AffineEnvironment.transform 21 8572 env35433 = env35434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env35433 == env35434) = true)

theorem identity35434 : scanCanonicalize (H12AffineFastState.compose env35434 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound35434 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env35435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,137,342,4232,2557,1024,136,5457,168,152,2,348,64,2184,4096,4232,2420,1365,168,256,168,4160,513]

theorem envBound35435 : H12AffineFastState.Bounded env35435 := by
  intro p hp
  have h : env35435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35434_35435 : H12AffineEnvironment.transform 12 468 env35434 = env35435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env35434 == env35435) = true)

theorem identity35435 : scanCanonicalize (H12AffineFastState.compose env35435 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35435 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4113,1,342,4096,2421,1024,0,5457,32,16,2,348,64,2048,4096,4096,2420,1365,32,256,32,4160,513]

theorem envBound35436 : H12AffineFastState.Bounded env35436 := by
  intro p hp
  have h : env35436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35435_35436 : H12AffineEnvironment.transform 6 8 env35435 = env35436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35435 == env35436) = true)

theorem identity35436 : scanCanonicalize (H12AffineFastState.compose env35436 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1793) := by decide +kernel

theorem selectedBound35436 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1793,348,1808,1,342,1793,2421,1024,0,592,32,16,2,348,64,2048,1793,1793,2420,1365,32,256,32,1857,513]

theorem envBound35437 : H12AffineFastState.Bounded env35437 := by
  intro p hp
  have h : env35437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35436_35437 : H12AffineEnvironment.transform 11 1793 env35436 = env35437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1793 env35436 == env35437) = true)

theorem identity35437 : scanCanonicalize (H12AffineFastState.compose env35437 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1653) := by decide +kernel

theorem selectedBound35437 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1653,1793,348,1808,1,342,1793,1792,1024,0,592,32,16,2,348,64,1653,1793,1793,1793,1365,32,256,32,1857,513]

theorem envBound35438 : H12AffineFastState.Bounded env35438 := by
  intro p hp
  have h : env35438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35437_35438 : H12AffineEnvironment.transform 10 1653 env35437 = env35438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1653 env35437 == env35438) = true)

theorem identity35438 : scanCanonicalize (H12AffineFastState.compose env35438 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35438 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env35439 : List Nat := [2,4,8,16,32,64,8,256,512,273,868,528,348,513,1,342,528,529,273,0,592,32,16,2,348,64,868,528,528,528,68,32,256,32,592,513]

theorem envBound35439 : H12AffineFastState.Bounded env35439 := by
  intro p hp
  have h : env35439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35438_35439 : H12AffineEnvironment.transform 9 273 env35438 = env35439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35438 == env35439) = true)

theorem identity35439 : scanCanonicalize (H12AffineFastState.compose env35439 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35440 : List Nat := [2,4,8,16,32,64,8,21,512,4,625,528,73,513,1,67,528,529,4,0,592,32,16,2,73,64,625,528,528,528,68,32,21,32,592,513]

theorem envBound35440 : H12AffineFastState.Bounded env35440 := by
  intro p hp
  have h : env35440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35439_35440 : H12AffineEnvironment.transform 7 21 env35439 = env35440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35439 == env35440) = true)

theorem identity35440 : scanCanonicalize (H12AffineFastState.compose env35440 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35440 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env35441 : List Nat := [2,4,8,16,1,64,8,21,512,4,592,528,73,513,1,67,528,529,4,0,592,1,16,2,73,64,592,528,528,528,68,1,21,1,592,513]

theorem envBound35441 : H12AffineFastState.Bounded env35441 := by
  intro p hp
  have h : env35441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35440_35441 : H12AffineEnvironment.transform 4 1 env35440 = env35441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35440 == env35441) = true)

theorem identity35441 : scanCanonicalize (H12AffineFastState.compose env35441 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35441 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35442 : List Nat := [2,4,8,16,1,0,8,21,512,4,528,528,9,513,1,3,528,529,4,0,528,1,16,2,9,0,528,528,528,528,4,1,21,1,528,513]

theorem envBound35442 : H12AffineFastState.Bounded env35442 := by
  intro p hp
  have h : env35442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35441_35442 : H12AffineEnvironment.transform 5 0 env35441 = env35442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35441 == env35442) = true)

theorem identity35442 : scanCanonicalize (H12AffineFastState.compose env35442 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35442 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35443 : List Nat := [2,4,8,16,1,0,8,21,16,4,0,0,9,17,1,3,0,1,4,0,0,1,16,2,9,0,0,0,0,0,4,1,21,1,0,17]

theorem envBound35443 : H12AffineFastState.Bounded env35443 := by
  intro p hp
  have h : env35443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35442_35443 : H12AffineEnvironment.transform 8 16 env35442 = env35443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35442 == env35443) = true)

theorem identity35443 : scanCanonicalize (H12AffineFastState.compose env35443 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35443 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35444 : List Nat := [2,4,8,1,1,0,8,4,1,4,0,0,9,0,1,3,0,1,4,0,0,1,1,2,9,0,0,0,0,0,4,1,4,1,0,0]

theorem envBound35444 : H12AffineFastState.Bounded env35444 := by
  intro p hp
  have h : env35444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35443_35444 : H12AffineEnvironment.transform 3 1 env35443 = env35444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35443 == env35444) = true)

def env35445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,262144,1024,32769,2097152,4194304,41413,16777216,8328,64,21331969,18973836,2159765,294913,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound35445 : H12AffineFastState.Bounded env35445 := by
  intro p hp
  have h : env35445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35419_35445 : H12AffineEnvironment.transform 16 57797 env35419 = env35445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env35419 == env35445) = true)

theorem identity35445 : scanCanonicalize (H12AffineFastState.compose env35445 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound35445 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,262144,1024,32769,2097152,4194304,41413,2,8328,64,4554755,2196622,2159765,294913,75223,6383042,256,2188650,2196686,513]

theorem envBound35446 : H12AffineFastState.Bounded env35446 := by
  intro p hp
  have h : env35446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35445_35446 : H12AffineEnvironment.transform 23 2 env35445 = env35446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env35445 == env35446) = true)

def env35447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10280,1024,32769,2097152,4194304,41413,2,8328,64,4302891,2196622,2159765,43049,75223,6383042,256,2188650,2196686,513]

theorem envBound35447 : H12AffineFastState.Bounded env35447 := by
  intro p hp
  have h : env35447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35446_35447 : H12AffineEnvironment.transform 17 10280 env35446 = env35447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35446 == env35447) = true)

theorem identity35447 : scanCanonicalize (H12AffineFastState.compose env35447 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35447 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env35448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302891,2196486,2159645,43049,75103,6382922,256,2188650,2196550,513]

theorem envBound35448 : H12AffineFastState.Bounded env35448 := by
  intro p hp
  have h : env35448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35447_35448 : H12AffineEnvironment.transform 6 8 env35447 = env35448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35447 == env35448) = true)

theorem identity35448 : scanCanonicalize (H12AffineFastState.compose env35448 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35448 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env35449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,2,8192,64,4262262,2172251,2118976,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound35449 : H12AffineFastState.Bounded env35449 := by
  intro p hp
  have h : env35449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35448_35449 : H12AffineEnvironment.transform 14 8541 env35448 = env35449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35448 == env35449) = true)

theorem identity35449 : scanCanonicalize (H12AffineFastState.compose env35449 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound35449 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91466,4194304,16,2,8192,64,4262262,16401,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound35450 : H12AffineFastState.Bounded env35450 := by
  intro p hp
  have h : env35450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35449_35450 : H12AffineEnvironment.transform 20 91466 env35449 = env35450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env35449 == env35450) = true)

theorem identity35450 : scanCanonicalize (H12AffineFastState.compose env35450 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound35450 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16400,10280,1024,8540,25629,4194304,16,2,8192,64,4196385,16401,12637,2420,9224,4194304,256,32,16465,513]

theorem envBound35451 : H12AffineFastState.Bounded env35451 := by
  intro p hp
  have h : env35451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35450_35451 : H12AffineEnvironment.transform 15 343 env35450 = env35451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env35450 == env35451) = true)

theorem identity35451 : scanCanonicalize (H12AffineFastState.compose env35451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,343,16400,2420,1024,0,17729,4194304,16,2,348,64,4196385,16401,4097,2420,1364,4194304,256,32,16465,513]

theorem envBound35452 : H12AffineFastState.Bounded env35452 := by
  intro p hp
  have h : env35452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35451_35452 : H12AffineEnvironment.transform 12 348 env35451 = env35452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35451 == env35452) = true)

theorem identity35452 : scanCanonicalize (H12AffineFastState.compose env35452 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35453 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16400,2341,1024,0,17680,4194304,16,2,269,17,4196385,16401,4097,2341,1285,4194304,256,32,16384,513]

theorem envBound35453 : H12AffineFastState.Bounded env35453 := by
  intro p hp
  have h : env35453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35452_35453 : H12AffineEnvironment.transform 5 17 env35452 = env35453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35452 == env35453) = true)

theorem identity35453 : scanCanonicalize (H12AffineFastState.compose env35453 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21508) := by decide +kernel

theorem selectedBound35453 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env35454 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16400,2341,1024,0,17680,21508,16,2,269,17,23589,16401,4097,2341,1285,21508,256,32,16384,513]

theorem envBound35454 : H12AffineFastState.Bounded env35454 := by
  intro p hp
  have h : env35454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35453_35454 : H12AffineEnvironment.transform 21 21508 env35453 = env35454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21508 env35453 == env35454) = true)

theorem identity35454 : scanCanonicalize (H12AffineFastState.compose env35454 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound35454 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35455 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5157,1,262,5173,2341,1024,0,4405,33,16,2,269,17,2048,5172,4097,2341,1285,33,256,32,5157,513]

theorem envBound35455 : H12AffineFastState.Bounded env35455 := by
  intro p hp
  have h : env35455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35454_35455 : H12AffineEnvironment.transform 13 5157 env35454 = env35455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env35454 == env35455) = true)

def env35456 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2837,1,262,2821,2341,1024,0,3589,33,16,2,269,17,2048,2820,3889,2341,1285,33,256,32,2837,513]

theorem envBound35456 : H12AffineFastState.Bounded env35456 := by
  intro p hp
  have h : env35456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35455_35456 : H12AffineEnvironment.transform 11 3888 env35455 = env35456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env35455 == env35456) = true)

def env35457 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1045,1,262,1029,1573,1024,0,261,33,16,2,269,17,1792,1028,49,1573,1285,33,256,32,1045,513]

theorem envBound35457 : H12AffineFastState.Bounded env35457 := by
  intro p hp
  have h : env35457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35456_35457 : H12AffineEnvironment.transform 10 1792 env35456 = env35457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env35456 == env35457) = true)

theorem identity35457 : scanCanonicalize (H12AffineFastState.compose env35457 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound35457 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35458 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,48,269,789,1,262,773,293,768,0,261,33,16,2,269,17,0,772,49,293,517,33,256,32,789,513]

theorem envBound35458 : H12AffineFastState.Bounded env35458 := by
  intro p hp
  have h : env35458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35457_35458 : H12AffineEnvironment.transform 9 768 env35457 = env35458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env35457 == env35458) = true)

def env35459 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,48,269,33,1,262,49,293,52,0,261,33,16,2,269,17,0,48,49,293,305,33,256,32,33,309]

theorem envBound35459 : H12AffineFastState.Bounded env35459 := by
  intro p hp
  have h : env35459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35458_35459 : H12AffineEnvironment.transform 8 308 env35458 = env35459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env35458 == env35459) = true)

theorem identity35459 : scanCanonicalize (H12AffineFastState.compose env35459 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35459 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35460 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,269,33,1,262,42,293,47,0,261,33,11,2,269,10,0,43,42,293,298,33,256,32,33,302]

theorem envBound35460 : H12AffineFastState.Bounded env35460 := by
  intro p hp
  have h : env35460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35459_35460 : H12AffineEnvironment.transform 3 11 env35459 = env35460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35459 == env35460) = true)

def leafEnv35460 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,269,33,1,262,42,293,47,0,261,33,11,2,298,269,1,10,0,43,42,293,298,33,256,32,4,262,33,302,1,261,0]

def active35460 : List Nat := [0,1,2,4,7]

def tree35460 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35460 : H12WitnessSearch.Good tree35460 := H12GlobalWitnessIndex.good

theorem leafIdentity35460 : H12AffineFastState.composeSystem env35460 rootObs = leafEnv35460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35460 rootObs == leafEnv35460) = true)

theorem terminalChecked35460 : H12PackedTerminal.terminalCheckFast leafEnv35460 active35460 tree35460 = true := by decide +kernel

def env35461 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,269,32,1,262,48,293,53,0,261,33,16,2,269,17,0,49,49,293,304,33,256,32,32,308]

theorem envBound35461 : H12AffineFastState.Bounded env35461 := by
  intro p hp
  have h : env35461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35458_35461 : H12AffineEnvironment.transform 8 309 env35458 = env35461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env35458 == env35461) = true)

theorem identity35461 : scanCanonicalize (H12AffineFastState.compose env35461 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35461 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35462 : List Nat := [2,4,8,16,0,17,8,256,277,21,0,16,269,0,1,262,16,261,21,0,261,1,16,2,269,17,0,17,17,261,272,1,256,0,0,276]

theorem envBound35462 : H12AffineFastState.Bounded env35462 := by
  intro p hp
  have h : env35462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35461_35462 : H12AffineEnvironment.transform 4 0 env35461 = env35462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35461 == env35462) = true)

def leafEnv35462 : List Nat := [2,4,8,16,0,17,8,256,277,21,0,16,269,0,1,262,16,261,21,0,261,1,16,2,272,269,1,17,0,17,17,261,272,1,256,0,4,262,0,276,1,261,0]

def active35462 : List Nat := [0,1,2,3,7]

def tree35462 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35462 : H12WitnessSearch.Good tree35462 := H12GlobalWitnessIndex.good

theorem leafIdentity35462 : H12AffineFastState.composeSystem env35462 rootObs = leafEnv35462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35462 rootObs == leafEnv35462) = true)

theorem terminalChecked35462 : H12PackedTerminal.terminalCheckFast leafEnv35462 active35462 tree35462 = true := by decide +kernel

def env35463 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1044,1,262,1028,1572,1024,0,260,33,16,2,269,17,1793,1029,48,1572,1285,33,256,32,1044,513]

theorem envBound35463 : H12AffineFastState.Bounded env35463 := by
  intro p hp
  have h : env35463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35456_35463 : H12AffineEnvironment.transform 10 1793 env35456 = env35463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env35456 == env35463) = true)

theorem identity35463 : scanCanonicalize (H12AffineFastState.compose env35463 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35464 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1297,49,269,1044,1,262,1028,1076,1024,0,260,33,16,2,269,17,1297,1029,48,1076,1285,33,256,32,1044,17]

theorem envBound35464 : H12AffineFastState.Bounded env35464 := by
  intro p hp
  have h : env35464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35463_35464 : H12AffineEnvironment.transform 8 16 env35463 = env35464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35463 == env35464) = true)

def env35465 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,269,32,1,262,48,0,52,0,260,33,16,2,269,17,293,49,48,0,305,33,256,32,32,17]

theorem envBound35465 : H12AffineFastState.Bounded env35465 := by
  intro p hp
  have h : env35465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35464_35465 : H12AffineEnvironment.transform 9 52 env35464 = env35465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35464 == env35465) = true)

theorem identity35465 : scanCanonicalize (H12AffineFastState.compose env35465 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35466 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,269,32,1,262,42,0,46,0,260,33,10,2,269,11,293,43,42,0,299,33,256,32,32,11]

theorem envBound35466 : H12AffineFastState.Bounded env35466 := by
  intro p hp
  have h : env35466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35465_35466 : H12AffineEnvironment.transform 3 10 env35465 = env35466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35465 == env35466) = true)

def leafEnv35466 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,269,32,1,262,42,0,46,0,260,33,10,2,299,269,1,11,293,43,42,0,299,33,256,32,4,262,32,11,1,260,0]

def active35466 : List Nat := [0,1,2,4,7]

def tree35466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35466 : H12WitnessSearch.Good tree35466 := H12GlobalWitnessIndex.good

theorem leafIdentity35466 : H12AffineFastState.composeSystem env35466 rootObs = leafEnv35466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35466 rootObs == leafEnv35466) = true)

theorem terminalChecked35466 : H12PackedTerminal.terminalCheckFast leafEnv35466 active35466 tree35466 = true := by decide +kernel

def env35467 : List Nat := [2,4,8,16,32,17,8,256,16,53,292,49,269,33,1,262,49,1,53,0,260,33,16,2,269,17,292,48,48,1,304,33,256,32,33,17]

theorem envBound35467 : H12AffineFastState.Bounded env35467 := by
  intro p hp
  have h : env35467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35464_35467 : H12AffineEnvironment.transform 9 53 env35464 = env35467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35464 == env35467) = true)

theorem identity35467 : scanCanonicalize (H12AffineFastState.compose env35467 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35467 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35468 : List Nat := [2,4,8,16,32,17,8,5,16,53,33,49,8,33,1,3,49,1,53,0,1,33,16,2,8,17,33,48,48,1,53,33,5,32,33,17]

theorem envBound35468 : H12AffineFastState.Bounded env35468 := by
  intro p hp
  have h : env35468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35467_35468 : H12AffineEnvironment.transform 7 5 env35467 = env35468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35467 == env35468) = true)

def leafEnv35468 : List Nat := [2,4,8,16,32,17,8,5,16,53,33,49,8,33,1,3,49,1,53,0,1,33,16,2,53,8,1,17,33,48,48,1,53,33,5,32,4,3,33,17,1,1,0]

def active35468 : List Nat := [0,1,2,3,4]

def tree35468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35468 : H12WitnessSearch.Good tree35468 := H12GlobalWitnessIndex.good

theorem leafIdentity35468 : H12AffineFastState.composeSystem env35468 rootObs = leafEnv35468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35468 rootObs == leafEnv35468) = true)

theorem terminalChecked35468 : H12PackedTerminal.terminalCheckFast leafEnv35468 active35468 tree35468 = true := by decide +kernel

def env35469 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2836,1,262,2820,2341,1024,0,3588,33,16,2,269,17,2048,2821,3888,2341,1285,33,256,32,2836,513]

theorem envBound35469 : H12AffineFastState.Bounded env35469 := by
  intro p hp
  have h : env35469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35455_35469 : H12AffineEnvironment.transform 11 3889 env35455 = env35469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env35455 == env35469) = true)

def env35470 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1044,1,262,1028,1573,1024,0,260,33,16,2,269,17,1792,1029,48,1573,1285,33,256,32,1044,513]

theorem envBound35470 : H12AffineFastState.Bounded env35470 := by
  intro p hp
  have h : env35470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35469_35470 : H12AffineEnvironment.transform 10 1792 env35469 = env35470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env35469 == env35470) = true)

theorem identity35470 : scanCanonicalize (H12AffineFastState.compose env35470 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound35470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35471 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1076,49,269,1044,1,262,1028,1297,1024,0,260,33,16,2,269,17,1076,1029,48,1297,1285,33,256,32,1044,309]

theorem envBound35471 : H12AffineFastState.Bounded env35471 := by
  intro p hp
  have h : env35471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35470_35471 : H12AffineEnvironment.transform 8 308 env35470 = env35471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env35470 == env35471) = true)

def env35472 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,269,32,1,262,48,293,52,0,260,33,16,2,269,17,0,49,48,293,305,33,256,32,32,309]

theorem envBound35472 : H12AffineFastState.Bounded env35472 := by
  intro p hp
  have h : env35472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35471_35472 : H12AffineEnvironment.transform 9 52 env35471 = env35472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35471 == env35472) = true)

theorem identity35472 : scanCanonicalize (H12AffineFastState.compose env35472 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35473 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,269,32,1,262,43,293,47,0,260,33,11,2,269,10,0,42,43,293,298,33,256,32,32,302]

theorem envBound35473 : H12AffineFastState.Bounded env35473 := by
  intro p hp
  have h : env35473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35472_35473 : H12AffineEnvironment.transform 3 11 env35472 = env35473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35472 == env35473) = true)

def leafEnv35473 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,269,32,1,262,43,293,47,0,260,33,11,2,298,269,1,10,0,42,43,293,298,33,256,32,4,262,32,302,1,260,0]

def active35473 : List Nat := [0,1,2,4,7]

def tree35473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35473 : H12WitnessSearch.Good tree35473 := H12GlobalWitnessIndex.good

theorem leafIdentity35473 : H12AffineFastState.composeSystem env35473 rootObs = leafEnv35473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35473 rootObs == leafEnv35473) = true)

theorem terminalChecked35473 : H12PackedTerminal.terminalCheckFast leafEnv35473 active35473 tree35473 = true := by decide +kernel

def env35474 : List Nat := [2,4,8,16,32,17,8,256,308,53,1,49,269,33,1,262,49,292,53,0,260,33,16,2,269,17,1,48,48,292,304,33,256,32,33,309]

theorem envBound35474 : H12AffineFastState.Bounded env35474 := by
  intro p hp
  have h : env35474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35471_35474 : H12AffineEnvironment.transform 9 53 env35471 = env35474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35471 == env35474) = true)

theorem identity35474 : scanCanonicalize (H12AffineFastState.compose env35474 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35475 : List Nat := [2,4,8,16,0,17,8,256,276,21,1,17,269,1,1,262,17,260,21,0,260,1,16,2,269,17,1,16,16,260,272,1,256,0,1,277]

theorem envBound35475 : H12AffineFastState.Bounded env35475 := by
  intro p hp
  have h : env35475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35474_35475 : H12AffineEnvironment.transform 4 0 env35474 = env35475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35474 == env35475) = true)

def leafEnv35475 : List Nat := [2,4,8,16,0,17,8,256,276,21,1,17,269,1,1,262,17,260,21,0,260,1,16,2,272,269,1,17,1,16,16,260,272,1,256,0,4,262,1,277,1,260,0]

def active35475 : List Nat := [0,1,2,3,7]

def tree35475 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35475 : H12WitnessSearch.Good tree35475 := H12GlobalWitnessIndex.good

theorem leafIdentity35475 : H12AffineFastState.composeSystem env35475 rootObs = leafEnv35475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35475 rootObs == leafEnv35475) = true)

theorem terminalChecked35475 : H12PackedTerminal.terminalCheckFast leafEnv35475 active35475 tree35475 = true := by decide +kernel

def env35476 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1045,1,262,1029,1572,1024,0,261,33,16,2,269,17,1793,1028,49,1572,1285,33,256,32,1045,513]

theorem envBound35476 : H12AffineFastState.Bounded env35476 := by
  intro p hp
  have h : env35476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35469_35476 : H12AffineEnvironment.transform 10 1793 env35469 = env35476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env35469 == env35476) = true)

theorem identity35476 : scanCanonicalize (H12AffineFastState.compose env35476 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound35476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35477 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,48,269,561,1,262,545,0,548,0,261,33,16,2,269,17,293,544,49,0,801,33,256,32,561,513]

theorem envBound35477 : H12AffineFastState.Bounded env35477 := by
  intro p hp
  have h : env35477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35476_35477 : H12AffineEnvironment.transform 9 548 env35476 = env35477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env35476 == env35477) = true)

def env35478 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,48,269,33,1,262,49,0,52,0,261,33,16,2,269,17,293,48,49,0,305,33,256,32,33,17]

theorem envBound35478 : H12AffineFastState.Bounded env35478 := by
  intro p hp
  have h : env35478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35477_35478 : H12AffineEnvironment.transform 8 16 env35477 = env35478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35477 == env35478) = true)

theorem identity35478 : scanCanonicalize (H12AffineFastState.compose env35478 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35478 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35479 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,269,33,1,262,43,0,46,0,261,33,10,2,269,11,293,42,43,0,299,33,256,32,33,11]

theorem envBound35479 : H12AffineFastState.Bounded env35479 := by
  intro p hp
  have h : env35479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35478_35479 : H12AffineEnvironment.transform 3 10 env35478 = env35479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35478 == env35479) = true)

def leafEnv35479 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,269,33,1,262,43,0,46,0,261,33,10,2,299,269,1,11,293,42,43,0,299,33,256,32,4,262,33,11,1,261,0]

def active35479 : List Nat := [0,1,2,4,7]

def tree35479 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35479 : H12WitnessSearch.Good tree35479 := H12GlobalWitnessIndex.good

theorem leafIdentity35479 : H12AffineFastState.composeSystem env35479 rootObs = leafEnv35479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35479 rootObs == leafEnv35479) = true)

theorem terminalChecked35479 : H12PackedTerminal.terminalCheckFast leafEnv35479 active35479 tree35479 = true := by decide +kernel

def env35480 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,269,32,1,262,48,0,53,0,261,33,16,2,269,17,293,49,49,0,304,33,256,32,32,16]

theorem envBound35480 : H12AffineFastState.Bounded env35480 := by
  intro p hp
  have h : env35480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35477_35480 : H12AffineEnvironment.transform 8 17 env35477 = env35480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35477 == env35480) = true)

theorem identity35480 : scanCanonicalize (H12AffineFastState.compose env35480 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35480 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35481 : List Nat := [2,4,8,16,32,17,8,5,17,53,32,48,8,32,1,3,48,0,53,0,0,33,16,2,8,17,32,49,49,0,53,33,5,32,32,16]

theorem envBound35481 : H12AffineFastState.Bounded env35481 := by
  intro p hp
  have h : env35481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35480_35481 : H12AffineEnvironment.transform 7 5 env35480 = env35481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35480 == env35481) = true)

def leafEnv35481 : List Nat := [2,4,8,16,32,17,8,5,17,53,32,48,8,32,1,3,48,0,53,0,0,33,16,2,53,8,1,17,32,49,49,0,53,33,5,32,4,3,32,16,1,0,0]

def active35481 : List Nat := [0,1,2,3,4]

def tree35481 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35481 : H12WitnessSearch.Good tree35481 := H12GlobalWitnessIndex.good

theorem leafIdentity35481 : H12AffineFastState.composeSystem env35481 rootObs = leafEnv35481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35481 rootObs == leafEnv35481) = true)

theorem terminalChecked35481 : H12PackedTerminal.terminalCheckFast leafEnv35481 active35481 tree35481 = true := by decide +kernel

def env35482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10281,1024,32769,2097152,4194304,41413,2,8328,64,4302890,2196622,2159765,43048,75223,6383042,256,2188650,2196686,513]

theorem envBound35482 : H12AffineFastState.Bounded env35482 := by
  intro p hp
  have h : env35482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35446_35482 : H12AffineEnvironment.transform 17 10281 env35446 = env35482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35446 == env35482) = true)

theorem identity35482 : scanCanonicalize (H12AffineFastState.compose env35482 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35482 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env35483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16536,10281,1024,8540,2097152,4194304,152,2,8328,64,4262263,2172371,2119112,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound35483 : H12AffineFastState.Bounded env35483 := by
  intro p hp
  have h : env35483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35482_35483 : H12AffineEnvironment.transform 14 8541 env35482 = env35483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35482 == env35483) = true)

theorem identity35483 : scanCanonicalize (H12AffineFastState.compose env35483 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound35483 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8323,16536,10281,1024,8540,2097152,4194304,152,2,8328,64,4205044,2098512,2119112,2421,1364,6309185,256,2115049,2098448,513]

theorem envBound35484 : H12AffineFastState.Bounded env35484 := by
  intro p hp
  have h : env35484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35483_35484 : H12AffineEnvironment.transform 15 8323 env35483 = env35484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env35483 == env35484) = true)

theorem identity35484 : scanCanonicalize (H12AffineFastState.compose env35484 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound35484 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env35485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4248,8541,8323,4096,10281,1024,8540,2097152,4194304,152,2,8328,64,4205044,2098512,2098512,2421,1364,6297049,256,2102641,2098448,513]

theorem envBound35485 : H12AffineFastState.Bounded env35485 := by
  intro p hp
  have h : env35485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35484_35485 : H12AffineEnvironment.transform 13 4248 env35484 = env35485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env35484 == env35485) = true)

theorem identity35485 : scanCanonicalize (H12AffineFastState.compose env35485 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 2110589) := by decide +kernel

theorem selectedBound35485 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env35486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4248,8541,8323,4096,10281,1024,8540,2097152,2110589,152,2,8328,64,2104713,2098512,2098512,2421,1364,8612,256,2102641,2098448,513]

theorem envBound35486 : H12AffineFastState.Bounded env35486 := by
  intro p hp
  have h : env35486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35485_35486 : H12AffineEnvironment.transform 21 2110589 env35485 = env35486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2110589 env35485 == env35486) = true)

theorem identity35486 : scanCanonicalize (H12AffineFastState.compose env35486 (packedSelected [1,2,3,4,6,7,8,9,10,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound35486 : packedSelected [1,2,3,4,6,7,8,9,10,24,27] rootPS < 2^1333 := by decide +kernel

def env35487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4248,137,343,4096,2557,1024,136,2097152,2102697,152,2,348,64,2104713,2098512,2098512,2421,1364,112,256,2102641,2098448,513]

theorem envBound35487 : H12AffineFastState.Bounded env35487 := by
  intro p hp
  have h : env35487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35486_35487 : H12AffineEnvironment.transform 12 468 env35486 = env35487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env35486 == env35487) = true)

def env35488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound35488 : H12AffineFastState.Bounded env35488 := by
  intro p hp
  have h : env35488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35417_35488 : H12AffineEnvironment.transform 18 1025 env35417 = env35488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env35417 == env35488) = true)

theorem identity35488 : scanCanonicalize (H12AffineFastState.compose env35488 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213316) := by decide +kernel

theorem selectedBound35488 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213316,8328,64,12878148,2278857,10507600,8830976,8570196,6431876,257,10651112,10642509,8643203]

theorem envBound35489 : H12AffineFastState.Bounded env35489 := by
  intro p hp
  have h : env35489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35488_35489 : H12AffineEnvironment.transform 23 213316 env35488 = env35489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213316 env35488 == env35489) = true)

def env35490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281672,213316,8328,64,6705548,2278857,165272,2363592,2102684,6431876,257,21792,46213,2175563]

theorem envBound35490 : H12AffineFastState.Bounded env35490 := by
  intro p hp
  have h : env35490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35489_35490 : H12AffineEnvironment.transform 22 2281672 env35489 = env35490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281672 env35489 == env35490) = true)

def env35491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590740,2098513,17664,2363592,2102684,6349852,257,21792,46213,2175563]

theorem envBound35491 : H12AffineFastState.Bounded env35491 := by
  intro p hp
  have h : env35491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35490_35491 : H12AffineEnvironment.transform 16 49304 env35490 = env35491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env35490 == env35491) = true)

def env35492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144660,2098513,17664,2363592,2102684,2411676,257,21792,46213,2175563]

theorem envBound35492 : H12AffineFastState.Bounded env35492 := by
  intro p hp
  have h : env35492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35491_35492 : H12AffineEnvironment.transform 21 272512 env35491 = env35492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35491 == env35492) = true)

theorem identity35492 : scanCanonicalize (H12AffineFastState.compose env35492 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound35492 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77898,272512,73754,98780,8328,64,100830,79131,17664,336002,75222,392406,257,21792,46213,513]

theorem envBound35493 : H12AffineFastState.Bounded env35493 := by
  intro p hp
  have h : env35493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35492_35493 : H12AffineEnvironment.transform 20 77898 env35492 = env35493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env35492 == env35493) = true)

def env35494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272392,73754,98644,8192,64,100694,79131,17664,335882,75102,392286,257,21792,46093,513]

theorem envBound35494 : H12AffineFastState.Bounded env35494 := by
  intro p hp
  have h : env35494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35493_35494 : H12AffineEnvironment.transform 6 8 env35493 = env35494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35493 == env35494) = true)

theorem identity35494 : scanCanonicalize (H12AffineFastState.compose env35494 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound35494 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,262144,1025,32769,36929,272392,32785,8543,8192,64,10589,38160,17664,294913,34133,285781,257,21792,46093,513]

theorem envBound35495 : H12AffineFastState.Bounded env35495 := by
  intro p hp
  have h : env35495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35494_35495 : H12AffineEnvironment.transform 15 40971 env35494 = env35495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env35494 == env35495) = true)

theorem identity35495 : scanCanonicalize (H12AffineFastState.compose env35495 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 63544) := by decide +kernel

theorem selectedBound35495 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,63544,1025,32769,36929,53296,32785,8543,8192,64,10589,38160,17664,30777,34133,42093,257,21792,46093,513]

theorem envBound35496 : H12AffineFastState.Bounded env35496 := by
  intro p hp
  have h : env35496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35495_35496 : H12AffineEnvironment.transform 17 63544 env35495 = env35496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63544 env35495 == env35496) = true)

theorem identity35496 : scanCanonicalize (H12AffineFastState.compose env35496 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound35496 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,9547,17744,32120,1025,1345,5377,21872,1361,8543,8192,64,10589,4176,17664,30777,21,8493,257,21792,12621,513]

theorem envBound35497 : H12AffineFastState.Bounded env35497 := by
  intro p hp
  have h : env35497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35496_35497 : H12AffineEnvironment.transform 14 1344 env35496 = env35497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env35496 == env35497) = true)

theorem identity35497 : scanCanonicalize (H12AffineFastState.compose env35497 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound35497 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env35498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,1344,9547,13624,3344,1025,1345,5377,9496,1361,8543,8192,64,10589,4176,13672,2129,21,8493,257,9544,12621,513]

theorem envBound35498 : H12AffineFastState.Bounded env35498 := by
  intro p hp
  have h : env35498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35497_35498 : H12AffineEnvironment.transform 13 12392 env35497 = env35498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env35497 == env35498) = true)

theorem identity35498 : scanCanonicalize (H12AffineFastState.compose env35498 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound35498 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,5236,1344,343,4388,3344,1025,1345,5377,260,1361,1347,1052,64,3393,4176,4468,2129,21,1329,257,340,5457,513]

theorem envBound35499 : H12AffineFastState.Bounded env35499 := by
  intro p hp
  have h : env35499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35498_35499 : H12AffineEnvironment.transform 12 1052 env35498 = env35499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env35498 == env35499) = true)

theorem identity35499 : scanCanonicalize (H12AffineFastState.compose env35499 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35499 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env35500 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1052,5236,1077,34,4177,3173,1025,1076,5236,113,1060,1078,1052,64,3124,4176,4097,2129,21,1092,116,33,5156,513]

theorem envBound35500 : H12AffineFastState.Bounded env35500 := by
  intro p hp
  have h : env35500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35499_35500 : H12AffineEnvironment.transform 7 117 env35499 = env35500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35499 == env35500) = true)

theorem identity35500 : scanCanonicalize (H12AffineFastState.compose env35500 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound35500 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env35501 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,121,4113,80,34,4177,2048,100,81,4113,113,65,83,121,64,2129,4176,4097,2129,21,33,116,33,4161,513]

theorem envBound35501 : H12AffineFastState.Bounded env35501 := by
  intro p hp
  have h : env35501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35500_35501 : H12AffineEnvironment.transform 9 101 env35500 = env35501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env35500 == env35501) = true)

theorem identity35501 : scanCanonicalize (H12AffineFastState.compose env35501 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35501 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35502 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,0,34,4097,2048,52,1,4113,33,17,3,41,16,2049,4096,4097,2049,21,33,36,33,4113,513]

theorem envBound35502 : H12AffineFastState.Bounded env35502 := by
  intro p hp
  have h : env35502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35501_35502 : H12AffineEnvironment.transform 5 16 env35501 = env35502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35501 == env35502) = true)

theorem identity35502 : scanCanonicalize (H12AffineFastState.compose env35502 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35502 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35503 : List Nat := [2,4,8,16,32,16,8,37,17,53,2048,4096,41,4113,0,34,4097,2048,52,1,4113,33,17,3,41,16,2049,4096,4097,2049,21,33,36,33,4113,16]

theorem envBound35503 : H12AffineFastState.Bounded env35503 := by
  intro p hp
  have h : env35503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35502_35503 : H12AffineEnvironment.transform 8 17 env35502 = env35503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35502 == env35503) = true)

theorem identity35503 : scanCanonicalize (H12AffineFastState.compose env35503 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound35503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35504 : List Nat := [2,4,8,16,32,16,8,37,17,53,2048,2059,41,2074,0,34,2058,2048,52,1,2074,33,17,3,41,16,2049,2059,2058,2049,21,33,36,33,2074,16]

theorem envBound35504 : H12AffineFastState.Bounded env35504 := by
  intro p hp
  have h : env35504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35503_35504 : H12AffineEnvironment.transform 11 2059 env35503 = env35504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env35503 == env35504) = true)

theorem identity35504 : scanCanonicalize (H12AffineFastState.compose env35504 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound35504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35505 : List Nat := [2,4,8,16,32,16,8,37,17,53,58,49,41,32,0,34,48,58,52,1,32,33,17,3,41,16,59,49,48,59,21,33,36,33,32,16]

theorem envBound35505 : H12AffineFastState.Bounded env35505 := by
  intro p hp
  have h : env35505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35504_35505 : H12AffineEnvironment.transform 10 58 env35504 = env35505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env35504 == env35505) = true)

theorem identity35505 : scanCanonicalize (H12AffineFastState.compose env35505 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35505 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35506 : List Nat := [2,4,8,16,11,16,8,14,17,30,17,26,2,11,0,9,27,17,31,1,11,10,17,3,2,16,16,26,27,16,21,10,15,10,11,16]

theorem envBound35506 : H12AffineFastState.Bounded env35506 := by
  intro p hp
  have h : env35506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35505_35506 : H12AffineEnvironment.transform 4 11 env35505 = env35506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35505 == env35506) = true)

def env35507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272393,73754,98645,8193,64,100695,79131,17664,335883,75103,392287,257,21792,46092,513]

theorem envBound35507 : H12AffineFastState.Bounded env35507 := by
  intro p hp
  have h : env35507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35493_35507 : H12AffineEnvironment.transform 6 9 env35493 = env35507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35493 == env35507) = true)

theorem identity35507 : scanCanonicalize (H12AffineFastState.compose env35507 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35507 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1025,32769,77898,41341,73754,98645,8193,64,100695,79131,17664,108927,75103,95531,257,21792,46092,513]

theorem envBound35508 : H12AffineFastState.Bounded env35508 := by
  intro p hp
  have h : env35508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35507_35508 : H12AffineEnvironment.transform 17 35188 env35507 = env35508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35507 == env35508) = true)

theorem identity35508 : scanCanonicalize (H12AffineFastState.compose env35508 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound35508 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env35509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,49169,35188,1025,32769,45341,41341,41293,2,8193,64,2048,46156,17664,10280,41992,62588,257,21792,46092,513]

theorem envBound35509 : H12AffineFastState.Bounded env35509 := by
  intro p hp
  have h : env35509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35508_35509 : H12AffineEnvironment.transform 15 33111 env35508 = env35509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env35508 == env35509) = true)

theorem identity35509 : scanCanonicalize (H12AffineFastState.compose env35509 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35509 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33111,49169,35188,1025,32769,36928,32800,32784,2,348,64,2048,38161,17664,2421,34133,54561,257,21792,38225,513]

theorem envBound35510 : H12AffineFastState.Bounded env35510 := by
  intro p hp
  have h : env35510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35509_35510 : H12AffineEnvironment.transform 12 349 env35509 = env35510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35509 == env35510) = true)

theorem identity35510 : scanCanonicalize (H12AffineFastState.compose env35510 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35510 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env35511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,343,16401,2420,1025,1,4160,32,16,2,348,64,2048,5393,17664,2421,1365,21793,257,21792,5457,513]

theorem envBound35511 : H12AffineFastState.Bounded env35511 := by
  intro p hp
  have h : env35511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35510_35511 : H12AffineEnvironment.transform 14 0 env35510 = env35511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35510 == env35511) = true)

theorem identity35511 : scanCanonicalize (H12AffineFastState.compose env35511 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 6453) := by decide +kernel

theorem selectedBound35511 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,6453,0,343,6436,2420,1025,1,4160,32,16,2,348,64,2048,5393,7221,2421,1365,3092,257,3093,5457,513]

theorem envBound35512 : H12AffineFastState.Bounded env35512 := by
  intro p hp
  have h : env35512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35511_35512 : H12AffineEnvironment.transform 13 6453 env35511 = env35512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6453 env35511 == env35512) = true)

theorem identity35512 : scanCanonicalize (H12AffineFastState.compose env35512 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound35512 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env35513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,5156,0,343,5173,1125,1025,1,4160,32,16,2,348,64,1297,5393,4388,1124,1365,261,257,260,5457,513]

theorem envBound35513 : H12AffineFastState.Bounded env35513 := by
  intro p hp
  have h : env35513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35512_35513 : H12AffineEnvironment.transform 10 1297 env35512 = env35513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env35512 == env35513) = true)

theorem identity35513 : scanCanonicalize (H12AffineFastState.compose env35513 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound35513 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1