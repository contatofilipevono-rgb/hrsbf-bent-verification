import H12CloudChart1Data178

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound45371 : H12AffineFastState.Bounded env45371 := by
  intro p hp
  have h : env45371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45370_45371 : H12AffineEnvironment.transform 9 548 env45370 = env45371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env45370 == env45371) = true)

def env45372 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,41,33,1,34,48,2049,53,0,32,33,16,2,41,17,2048,49,49,2049,21,32,36,33,33,17]

theorem envBound45372 : H12AffineFastState.Bounded env45372 := by
  intro p hp
  have h : env45372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45371_45372 : H12AffineEnvironment.transform 8 16 env45371 = env45372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45371 == env45372) = true)

theorem identity45372 : scanCanonicalize (H12AffineFastState.compose env45372 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound45372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45373 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,41,33,1,34,48,27,53,0,32,33,16,2,41,17,26,49,49,27,21,32,36,33,33,17]

theorem envBound45373 : H12AffineFastState.Bounded env45373 := by
  intro p hp
  have h : env45373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45372_45373 : H12AffineEnvironment.transform 10 26 env45372 = env45373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env45372 == env45373) = true)

def leafEnv45373 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,41,33,1,34,48,27,53,0,32,33,16,2,20,41,1,17,26,49,49,27,21,32,36,33,5,34,33,17,1,32,0]

def active45373 : List Nat := [0,1,2,3,4]

def tree45373 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45373 : H12WitnessSearch.Good tree45373 := H12GlobalWitnessIndex.good

theorem leafIdentity45373 : H12AffineFastState.composeSystem env45373 rootObs = leafEnv45373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45373 rootObs == leafEnv45373) = true)

theorem terminalChecked45373 : H12PackedTerminal.terminalCheckFast leafEnv45373 active45373 tree45373 = true := by decide +kernel

def env45374 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,41,32,1,34,49,2049,52,0,32,33,16,2,41,17,2048,48,49,2049,20,32,36,33,32,16]

theorem envBound45374 : H12AffineFastState.Bounded env45374 := by
  intro p hp
  have h : env45374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45371_45374 : H12AffineEnvironment.transform 8 17 env45371 = env45374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45371 == env45374) = true)

theorem identity45374 : scanCanonicalize (H12AffineFastState.compose env45374 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound45374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45375 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,48,41,32,1,34,49,32,52,0,32,33,16,2,41,17,33,48,49,32,20,32,36,33,32,16]

theorem envBound45375 : H12AffineFastState.Bounded env45375 := by
  intro p hp
  have h : env45375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45374_45375 : H12AffineEnvironment.transform 10 33 env45374 = env45375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env45374 == env45375) = true)

def leafEnv45375 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,48,41,32,1,34,49,32,52,0,32,33,16,2,21,41,1,17,33,48,49,32,20,32,36,33,5,34,32,16,1,32,0]

def active45375 : List Nat := [0,1,2,3,4]

def tree45375 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45375 : H12WitnessSearch.Good tree45375 := H12GlobalWitnessIndex.good

theorem leafIdentity45375 : H12AffineFastState.composeSystem env45375 rootObs = leafEnv45375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45375 rootObs == leafEnv45375) = true)

theorem terminalChecked45375 : H12PackedTerminal.terminalCheckFast leafEnv45375 active45375 tree45375 = true := by decide +kernel

def env45376 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1044,1,34,1029,2049,1025,0,33,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound45376 : H12AffineFastState.Bounded env45376 := by
  intro p hp
  have h : env45376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45369_45376 : H12AffineEnvironment.transform 11 49 env45369 = env45376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45369 == env45376) = true)

theorem identity45376 : scanCanonicalize (H12AffineFastState.compose env45376 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45377 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,49,41,1044,1,34,1029,2049,1025,0,33,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,17]

theorem envBound45377 : H12AffineFastState.Bounded env45377 := by
  intro p hp
  have h : env45377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45376_45377 : H12AffineEnvironment.transform 8 16 env45376 = env45377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45376 == env45377) = true)

def env45378 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,41,32,1,34,49,2049,53,0,33,33,16,2,41,17,2048,48,48,2049,21,32,36,33,32,17]

theorem envBound45378 : H12AffineFastState.Bounded env45378 := by
  intro p hp
  have h : env45378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45377_45378 : H12AffineEnvironment.transform 9 52 env45377 = env45378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45377 == env45378) = true)

theorem identity45378 : scanCanonicalize (H12AffineFastState.compose env45378 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound45378 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45379 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,41,32,1,34,49,27,53,0,33,33,16,2,41,17,26,48,48,27,21,32,36,33,32,17]

theorem envBound45379 : H12AffineFastState.Bounded env45379 := by
  intro p hp
  have h : env45379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45378_45379 : H12AffineEnvironment.transform 10 26 env45378 = env45379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env45378 == env45379) = true)

def leafEnv45379 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,41,32,1,34,49,27,53,0,33,33,16,2,20,41,1,17,26,48,48,27,21,32,36,33,5,34,32,17,1,33,0]

def active45379 : List Nat := [0,1,2,3,4]

def tree45379 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45379 : H12WitnessSearch.Good tree45379 := H12GlobalWitnessIndex.good

theorem leafIdentity45379 : H12AffineFastState.composeSystem env45379 rootObs = leafEnv45379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45379 rootObs == leafEnv45379) = true)

theorem terminalChecked45379 : H12PackedTerminal.terminalCheckFast leafEnv45379 active45379 tree45379 = true := by decide +kernel

def env45380 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,41,33,1,34,48,2049,52,0,33,33,16,2,41,17,2048,49,48,2049,20,32,36,33,33,17]

theorem envBound45380 : H12AffineFastState.Bounded env45380 := by
  intro p hp
  have h : env45380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45377_45380 : H12AffineEnvironment.transform 9 53 env45377 = env45380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45377 == env45380) = true)

theorem identity45380 : scanCanonicalize (H12AffineFastState.compose env45380 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound45380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45381 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,49,41,33,1,34,48,33,52,0,33,33,16,2,41,17,32,49,48,33,20,32,36,33,33,17]

theorem envBound45381 : H12AffineFastState.Bounded env45381 := by
  intro p hp
  have h : env45381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45380_45381 : H12AffineEnvironment.transform 10 32 env45380 = env45381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env45380 == env45381) = true)

def leafEnv45381 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,49,41,33,1,34,48,33,52,0,33,33,16,2,21,41,1,17,32,49,48,33,20,32,36,33,5,34,33,17,1,33,0]

def active45381 : List Nat := [0,1,2,3,4]

def tree45381 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45381 : H12WitnessSearch.Good tree45381 := H12GlobalWitnessIndex.good

theorem leafIdentity45381 : H12AffineFastState.composeSystem env45381 rootObs = leafEnv45381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45381 rootObs == leafEnv45381) = true)

theorem terminalChecked45381 : H12PackedTerminal.terminalCheckFast leafEnv45381 active45381 tree45381 = true := by decide +kernel

def env45382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180225,2114882,8328,64,6636867,115150,2266449,262145,2294099,4268163,257,213486,237642,2238084]

theorem envBound45382 : H12AffineFastState.Bounded env45382 := by
  intro p hp
  have h : env45382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45247_45382 : H12AffineEnvironment.transform 22 180225 env45247 = env45382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env45247 == env45382) = true)

def env45383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,169234,8328,64,4691219,115150,17665,262145,119043,4268163,257,213486,237642,63188]

theorem envBound45383 : H12AffineFastState.Bounded env45383 := by
  intro p hp
  have h : env45383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45382_45383 : H12AffineEnvironment.transform 20 184400 env45382 = env45383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env45382 == env45383) = true)

def env45384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,169234,8328,64,245139,115150,17665,262145,119043,329731,257,213486,237642,63188]

theorem envBound45384 : H12AffineFastState.Bounded env45384 := by
  intro p hp
  have h : env45384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45383_45384 : H12AffineEnvironment.transform 21 272512 env45383 = env45384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45383 == env45384) = true)

theorem identity45384 : scanCanonicalize (H12AffineFastState.compose env45384 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound45384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58517,272512,62660,41431,8328,64,100694,115150,17665,262145,119043,329731,257,95531,103567,63188]

theorem envBound45385 : H12AffineFastState.Bounded env45385 := by
  intro p hp
  have h : env45385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45384_45385 : H12AffineEnvironment.transform 16 13509 env45384 = env45385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env45384 == env45385) = true)

def env45386 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58517,272512,62612,41351,8328,16,100614,115102,17665,262145,119043,329731,257,95531,103567,63108]

theorem envBound45386 : H12AffineFastState.Bounded env45386 := by
  intro p hp
  have h : env45386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45385_45386 : H12AffineEnvironment.transform 5 16 env45385 = env45386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45385 == env45386) = true)

theorem identity45386 : scanCanonicalize (H12AffineFastState.compose env45386 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound45386 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env45387 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,100522,1025,32769,58517,106538,62612,41351,8328,16,100614,115102,17665,100523,119043,32937,257,95531,103567,63108]

theorem envBound45387 : H12AffineFastState.Bounded env45387 := by
  intro p hp
  have h : env45387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45386_45387 : H12AffineEnvironment.transform 17 100522 env45386 = env45387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env45386 == env45387) = true)

theorem identity45387 : scanCanonicalize (H12AffineFastState.compose env45387 (packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound45387 : packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env45388 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,65536,13461,100522,1025,32769,45340,106538,41245,41351,8328,16,100614,103447,4232,100523,99466,32937,257,73890,103567,41741]

theorem envBound45388 : H12AffineFastState.Bounded env45388 := by
  intro p hp
  have h : env45388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45387_45388 : H12AffineEnvironment.transform 13 5513 env45387 = env45388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env45387 == env45388) = true)

theorem identity45388 : scanCanonicalize (H12AffineFastState.compose env45388 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound45388 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env45389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,40970,13461,10400,1025,32769,45340,32,41245,41351,8328,16,10508,13341,4232,10401,9344,32937,257,32936,13445,41741]

theorem envBound45389 : H12AffineFastState.Bounded env45389 := by
  intro p hp
  have h : env45389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45388_45389 : H12AffineEnvironment.transform 15 40970 env45388 = env45389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env45388 == env45389) = true)

theorem identity45389 : scanCanonicalize (H12AffineFastState.compose env45389 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound45389 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env45390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,0,8202,13461,10400,1025,1,12572,32,8477,8583,8328,16,10508,13341,4232,10401,9344,169,257,168,13445,8973]

theorem envBound45390 : H12AffineFastState.Bounded env45390 := by
  intro p hp
  have h : env45390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45389_45390 : H12AffineEnvironment.transform 14 0 env45389 = env45390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env45389 == env45390) = true)

theorem identity45390 : scanCanonicalize (H12AffineFastState.compose env45390 (packedSelected [0,2,7,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 5253) := by decide +kernel

theorem selectedBound45390 : packedSelected [0,2,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5253,5513,0,5263,16,7205,1025,1,1433,32,5528,5378,5133,16,7561,152,4232,7204,4101,169,257,168,0,6024]

theorem envBound45391 : H12AffineFastState.Bounded env45391 := by
  intro p hp
  have h : env45391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45390_45391 : H12AffineEnvironment.transform 12 5253 env45390 = env45391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5253 env45390 == env45391) = true)

theorem identity45391 : scanCanonicalize (H12AffineFastState.compose env45391 (packedSelected [0,1,2,4,6,7,8,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound45391 : packedSelected [0,1,2,4,6,7,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1297,4096,5253,5513,0,5263,16,4404,1025,1,1433,32,5528,5378,5133,16,4248,152,4232,4405,4101,169,257,168,0,6024]

theorem envBound45392 : H12AffineFastState.Bounded env45392 := by
  intro p hp
  have h : env45392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45391_45392 : H12AffineEnvironment.transform 10 1297 env45391 = env45392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env45391 == env45392) = true)

theorem identity45392 : scanCanonicalize (H12AffineFastState.compose env45392 (packedSelected [1,2,3,4,5,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound45392 : packedSelected [1,2,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env45393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1297,17,1172,1432,0,1182,16,293,1025,1,1433,32,1417,1299,1052,16,137,152,153,292,20,169,257,168,0,1945]

theorem envBound45393 : H12AffineFastState.Bounded env45393 := by
  intro p hp
  have h : env45393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45392_45393 : H12AffineEnvironment.transform 11 17 env45392 = env45393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45392 == env45393) = true)

theorem identity45393 : scanCanonicalize (H12AffineFastState.compose env45393 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45393 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45394 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1297,17,1053,1297,0,1047,16,293,1025,1,1296,32,1280,1299,1052,16,0,17,16,292,20,32,257,33,0,1808]

theorem envBound45394 : H12AffineFastState.Bounded env45394 := by
  intro p hp
  have h : env45394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45393_45394 : H12AffineEnvironment.transform 6 9 env45393 = env45394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45393 == env45394) = true)

theorem identity45394 : scanCanonicalize (H12AffineFastState.compose env45394 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45394 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env45395 : List Nat := [2,4,8,16,32,16,9,256,512,52,293,17,41,293,0,35,16,293,53,1,292,32,308,295,40,16,0,17,16,292,20,32,257,33,0,804]

theorem envBound45395 : H12AffineFastState.Bounded env45395 := by
  intro p hp
  have h : env45395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45394_45395 : H12AffineEnvironment.transform 9 52 env45394 = env45395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45394 == env45395) = true)

theorem identity45395 : scanCanonicalize (H12AffineFastState.compose env45395 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound45395 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45396 : List Nat := [2,4,8,16,32,16,9,256,0,52,293,17,41,293,0,35,16,293,53,1,292,32,308,295,40,16,0,17,16,292,20,32,257,33,0,292]

theorem envBound45396 : H12AffineFastState.Bounded env45396 := by
  intro p hp
  have h : env45396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45395_45396 : H12AffineEnvironment.transform 8 0 env45395 = env45396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env45395 == env45396) = true)

theorem identity45396 : scanCanonicalize (H12AffineFastState.compose env45396 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45396 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env45397 : List Nat := [2,4,8,16,32,16,9,37,0,52,0,17,41,0,0,35,16,0,53,1,1,32,17,2,40,16,0,17,16,1,20,32,36,33,0,1]

theorem envBound45397 : H12AffineFastState.Bounded env45397 := by
  intro p hp
  have h : env45397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45396_45397 : H12AffineEnvironment.transform 7 37 env45396 = env45397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45396 == env45397) = true)

def env45398 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58517,272512,62613,41350,8328,17,100615,115103,17665,262145,119043,329731,257,95531,103567,63109]

theorem envBound45398 : H12AffineFastState.Bounded env45398 := by
  intro p hp
  have h : env45398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45385_45398 : H12AffineEnvironment.transform 5 17 env45385 = env45398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45385 == env45398) = true)

theorem identity45398 : scanCanonicalize (H12AffineFastState.compose env45398 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23724) := by decide +kernel

theorem selectedBound45398 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env45399 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,23724,1025,32769,58517,29740,62613,41350,8328,17,100615,115103,17665,23725,119043,87215,257,95531,103567,63109]

theorem envBound45399 : H12AffineFastState.Bounded env45399 := by
  intro p hp
  have h : env45399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45398_45399 : H12AffineEnvironment.transform 17 23724 env45398 = env45399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23724 env45398 == env45399) = true)

theorem identity45399 : scanCanonicalize (H12AffineFastState.compose env45399 (packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound45399 : packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS < 2^1333 := by decide +kernel

def env45400 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,13460,23724,1025,29829,4113,29740,17,21762,8328,17,97667,79131,17665,23725,75143,87215,257,95531,90123,513]

theorem envBound45400 : H12AffineFastState.Bounded env45400 := by
  intro p hp
  have h : env45400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45399_45400 : H12AffineEnvironment.transform 14 29828 env45399 = env45400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env45399 == env45400) = true)

theorem identity45400 : scanCanonicalize (H12AffineFastState.compose env45400 (packedSelected [1,2,4,5,6,8,9,14,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound45400 : packedSelected [1,2,4,5,6,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env45401 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,262,13460,23724,1025,29829,4113,29740,17,21762,8328,17,31877,13341,17665,23725,9345,21929,257,29741,24845,513]

theorem envBound45401 : H12AffineFastState.Bounded env45401 := by
  intro p hp
  have h : env45401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45400_45401 : H12AffineEnvironment.transform 15 262 env45400 = env45401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env45400 == env45401) = true)

theorem identity45401 : scanCanonicalize (H12AffineFastState.compose env45401 (packedSelected [2,6,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45401 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env45402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,262,13460,2476,1025,8581,4113,8492,17,2,8328,17,10629,13341,4097,2477,9345,169,257,8493,13325,513]

theorem envBound45402 : H12AffineFastState.Bounded env45402 := by
  intro p hp
  have h : env45402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45401_45402 : H12AffineEnvironment.transform 13 5376 env45401 = env45402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45401 == env45402) = true)

theorem identity45402 : scanCanonicalize (H12AffineFastState.compose env45402 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45402 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5376,136,262,5528,2476,1025,137,4113,32,17,2,388,17,2185,5393,4097,2477,1421,169,257,33,5377,513]

theorem envBound45403 : H12AffineFastState.Bounded env45403 := by
  intro p hp
  have h : env45403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45402_45403 : H12AffineEnvironment.transform 12 268 env45402 = env45403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45402 == env45403) = true)

theorem identity45403 : scanCanonicalize (H12AffineFastState.compose env45403 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound45403 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45404 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3328,268,2048,136,262,2200,2476,1025,137,3345,32,17,2,388,17,2185,2065,3329,2477,1421,169,257,33,2049,513]

theorem envBound45404 : H12AffineFastState.Bounded env45404 := by
  intro p hp
  have h : env45404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45403_45404 : H12AffineEnvironment.transform 11 3328 env45403 = env45404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env45403 == env45404) = true)

theorem identity45404 : scanCanonicalize (H12AffineFastState.compose env45404 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound45404 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env45405 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3245,161,2048,136,171,2200,2049,1025,137,3260,32,17,2,41,17,2185,2065,3244,2048,1056,169,172,33,2049,513]

theorem envBound45405 : H12AffineFastState.Bounded env45405 := by
  intro p hp
  have h : env45405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45404_45405 : H12AffineEnvironment.transform 7 173 env45404 = env45405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env45404 == env45405) = true)

theorem identity45405 : scanCanonicalize (H12AffineFastState.compose env45405 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound45405 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env45406 : List Nat := [2,4,8,16,32,17,128,173,512,188,2048,2065,161,2048,136,171,2200,2049,189,137,2048,32,17,2,41,17,2185,2065,2064,2048,156,169,172,33,2049,513]

theorem envBound45406 : H12AffineFastState.Bounded env45406 := by
  intro p hp
  have h : env45406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45405_45406 : H12AffineEnvironment.transform 9 188 env45405 = env45406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env45405 == env45406) = true)

theorem identity45406 : scanCanonicalize (H12AffineFastState.compose env45406 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45406 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45407 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2065,41,2048,0,35,2064,2049,53,1,2048,32,17,2,41,17,2049,2065,2064,2048,20,33,36,33,2049,513]

theorem envBound45407 : H12AffineFastState.Bounded env45407 := by
  intro p hp
  have h : env45407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45406_45407 : H12AffineEnvironment.transform 6 8 env45406 = env45407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45406 == env45407) = true)

theorem identity45407 : scanCanonicalize (H12AffineFastState.compose env45407 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45408 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,17,41,0,0,35,16,1,53,1,0,32,17,2,41,17,1,17,16,0,20,33,36,33,1,513]

theorem envBound45408 : H12AffineFastState.Bounded env45408 := by
  intro p hp
  have h : env45408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45407_45408 : H12AffineEnvironment.transform 10 0 env45407 = env45408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45407 == env45408) = true)

theorem identity45408 : scanCanonicalize (H12AffineFastState.compose env45408 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound45408 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45409 : List Nat := [2,4,8,16,32,17,8,37,59,52,0,17,41,0,0,35,16,1,53,1,0,32,17,2,41,17,1,17,16,0,20,33,36,33,1,58]

theorem envBound45409 : H12AffineFastState.Bounded env45409 := by
  intro p hp
  have h : env45409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45408_45409 : H12AffineEnvironment.transform 8 59 env45408 = env45409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env45408 == env45409) = true)

def env45410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,169234,8328,64,245138,115150,17665,262145,119043,329730,257,213486,237642,63188]

theorem envBound45410 : H12AffineFastState.Bounded env45410 := by
  intro p hp
  have h : env45410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45383_45410 : H12AffineEnvironment.transform 21 272513 env45383 = env45410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45383 == env45410) = true)

theorem identity45410 : scanCanonicalize (H12AffineFastState.compose env45410 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound45410 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140421,272513,144596,156103,8328,64,215367,79131,17665,262145,75222,329730,257,213486,218271,513]

theorem envBound45411 : H12AffineFastState.Bounded env45411 := by
  intro p hp
  have h : env45411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45410_45411 : H12AffineEnvironment.transform 14 29909 env45410 = env45411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env45410 == env45411) = true)

def env45412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272393,144476,155983,8192,64,215367,79131,17665,262145,75102,329730,257,213350,218135,513]

theorem envBound45412 : H12AffineFastState.Bounded env45412 := by
  intro p hp
  have h : env45412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45411_45412 : H12AffineEnvironment.transform 6 8 env45411 = env45412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45411 == env45412) = true)

def env45413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272392,144477,155982,8193,64,215367,79131,17665,262145,75103,329730,257,213351,218134,513]

theorem envBound45413 : H12AffineFastState.Bounded env45413 := by
  intro p hp
  have h : env45413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45411_45413 : H12AffineEnvironment.transform 6 9 env45411 = env45413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45411 == env45413) = true)

theorem identity45413 : scanCanonicalize (H12AffineFastState.compose env45413 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound45413 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1025,29789,82966,272392,87111,65876,8193,64,10589,79131,17665,262145,75103,329730,257,8573,13324,513]

theorem envBound45414 : H12AffineFastState.Bounded env45414 := by
  intro p hp
  have h : env45414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45413_45414 : H12AffineEnvironment.transform 16 90138 env45413 = env45414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env45413 == env45414) = true)

theorem identity45414 : scanCanonicalize (H12AffineFastState.compose env45414 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound45414 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21510,13340,262144,1025,29789,4112,272392,65,21842,8193,64,10589,24861,17665,262145,29017,285700,257,8573,13324,513]

theorem envBound45415 : H12AffineFastState.Bounded env45415 := by
  intro p hp
  have h : env45415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45414_45415 : H12AffineEnvironment.transform 15 21510 env45414 = env45415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env45414 == env45415) = true)

theorem identity45415 : scanCanonicalize (H12AffineFastState.compose env45415 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 11292) := by decide +kernel

theorem selectedBound45415 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env45416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21510,13340,11292,1025,29789,4112,1044,65,21842,8193,64,10589,24861,17665,11293,29017,28696,257,8573,13324,513]

theorem envBound45416 : H12AffineFastState.Bounded env45416 := by
  intro p hp
  have h : env45416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45415_45416 : H12AffineEnvironment.transform 17 11292 env45415 = env45416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11292 env45415 == env45416) = true)

theorem identity45416 : scanCanonicalize (H12AffineFastState.compose env45416 (packedSelected [18,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45416 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45417 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,8192,16384,28777,20531,12329,10281,52,28776,4112,33,65,20839,8193,64,10589,24861,16692,10280,29017,28696,257,8573,12345,513]

theorem envBound45417 : H12AffineFastState.Bounded env45417 := by
  intro p hp
  have h : env45417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45416_45417 : H12AffineEnvironment.transform 9 53 env45416 = env45417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45416 == env45417) = true)

theorem identity45417 : scanCanonicalize (H12AffineFastState.compose env45417 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound45417 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env45418 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2404,8192,16384,26893,18775,10573,10281,52,26892,2420,33,65,18435,8193,64,10589,24861,16692,10280,26685,27004,257,8573,10589,513]

theorem envBound45418 : H12AffineFastState.Bounded env45418 := by
  intro p hp
  have h : env45418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45417_45418 : H12AffineEnvironment.transform 11 2404 env45417 = env45418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env45417 == env45418) = true)

theorem identity45418 : scanCanonicalize (H12AffineFastState.compose env45418 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45418 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45419 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2404,268,16384,18433,18775,2113,2341,52,18432,2420,33,65,18435,269,64,2129,16401,16692,2340,18737,18544,257,113,2129,513]

theorem envBound45419 : H12AffineFastState.Bounded env45419 := by
  intro p hp
  have h : env45419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45418_45419 : H12AffineEnvironment.transform 12 268 env45418 = env45419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45418 == env45419) = true)

theorem identity45419 : scanCanonicalize (H12AffineFastState.compose env45419 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound45419 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45420 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2404,268,2048,1,343,2113,2341,52,0,2420,33,65,3,269,64,2129,2065,2356,2340,305,112,257,113,2129,513]

theorem envBound45420 : H12AffineFastState.Bounded env45420 := by
  intro p hp
  have h : env45420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45419_45420 : H12AffineEnvironment.transform 13 2048 env45419 = env45420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env45419 == env45420) = true)

def env45421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,169235,8328,64,4691218,115150,17664,262145,119042,4268163,257,213486,237642,63189]

theorem envBound45421 : H12AffineFastState.Bounded env45421 := by
  intro p hp
  have h : env45421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45382_45421 : H12AffineEnvironment.transform 20 184401 env45382 = env45421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env45382 == env45421) = true)

def env45422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,169235,8328,64,245138,115150,17664,262145,119042,329731,257,213486,237642,63189]

theorem envBound45422 : H12AffineFastState.Bounded env45422 := by
  intro p hp
  have h : env45422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45421_45422 : H12AffineEnvironment.transform 21 272512 env45421 = env45422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45421 == env45422) = true)

theorem identity45422 : scanCanonicalize (H12AffineFastState.compose env45422 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound45422 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272512,17,21763,8328,64,97666,115150,17664,262145,119042,329731,257,98814,90202,63189]

theorem envBound45423 : H12AffineFastState.Bounded env45423 := by
  intro p hp
  have h : env45423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45422_45423 : H12AffineEnvironment.transform 16 49168 env45422 = env45423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45422 == env45423) = true)

def env45424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21763,8192,64,97546,115014,17664,262145,119042,329731,257,98678,90202,63069]

theorem envBound45424 : H12AffineFastState.Bounded env45424 := by
  intro p hp
  have h : env45424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45423_45424 : H12AffineEnvironment.transform 6 8 env45423 = env45424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45423 == env45424) = true)

theorem identity45424 : scanCanonicalize (H12AffineFastState.compose env45424 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45424 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,32,17,21763,8192,64,97546,115014,17664,10281,119042,73771,257,98678,90202,63069]

theorem envBound45425 : H12AffineFastState.Bounded env45425 := by
  intro p hp
  have h : env45425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45424_45425 : H12AffineEnvironment.transform 17 10280 env45424 = env45425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45424 == env45425) = true)

theorem identity45425 : scanCanonicalize (H12AffineFastState.compose env45425 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound45425 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env45426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,65536,5441,10280,1025,21840,4161,32,17,21763,8192,64,97546,70679,17664,10281,66643,73771,257,87079,90202,8972]

theorem envBound45426 : H12AffineFastState.Bounded env45426 := by
  intro p hp
  have h : env45426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45425_45426 : H12AffineEnvironment.transform 14 21841 env45425 = env45426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env45425 == env45426) = true)

theorem identity45426 : scanCanonicalize (H12AffineFastState.compose env45426 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45426 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env45427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21841,65536,5441,2420,1025,21840,4161,32,17,21763,348,64,89174,70679,17664,2421,66643,65911,257,87079,82182,592]

theorem envBound45427 : H12AffineFastState.Bounded env45427 := by
  intro p hp
  have h : env45427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45426_45427 : H12AffineEnvironment.transform 12 348 env45426 = env45427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45426 == env45427) = true)

theorem identity45427 : scanCanonicalize (H12AffineFastState.compose env45427 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound45427 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env45428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,1,65536,5441,2420,1025,0,4161,32,17,83,348,64,67846,70679,4176,2421,66643,65911,257,65911,70742,592]

theorem envBound45428 : H12AffineFastState.Bounded env45428 := by
  intro p hp
  have h : env45428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45427_45428 : H12AffineEnvironment.transform 13 5456 env45427 = env45428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env45427 == env45428) = true)

theorem identity45428 : scanCanonicalize (H12AffineFastState.compose env45428 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 6423) := by decide +kernel

theorem selectedBound45428 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,1,6423,5441,2420,1025,0,4161,32,17,83,348,64,4113,3328,4176,2421,7492,6240,257,6240,3393,592]

theorem envBound45429 : H12AffineFastState.Bounded env45429 := by
  intro p hp
  have h : env45429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45428_45429 : H12AffineEnvironment.transform 15 6423 env45428 = env45429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6423 env45428 == env45429) = true)

theorem identity45429 : scanCanonicalize (H12AffineFastState.compose env45429 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45429 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env45430 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,6423,5392,2341,1025,0,4112,32,17,2,269,17,4113,3328,4097,2340,7445,6193,257,6193,3344,513]

theorem envBound45430 : H12AffineFastState.Bounded env45430 := by
  intro p hp
  have h : env45430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45429_45430 : H12AffineEnvironment.transform 5 17 env45429 = env45430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45429 == env45430) = true)

theorem identity45430 : scanCanonicalize (H12AffineFastState.compose env45430 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound45430 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45431 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,269,3344,1,262,3329,2341,1025,0,2049,32,17,2,269,17,2048,3328,2064,2340,1284,32,257,32,3344,513]

theorem envBound45431 : H12AffineFastState.Bounded env45431 := by
  intro p hp
  have h : env45431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45430_45431 : H12AffineEnvironment.transform 11 2065 env45430 = env45431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env45430 == env45431) = true)

theorem identity45431 : scanCanonicalize (H12AffineFastState.compose env45431 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1312) := by decide +kernel

theorem selectedBound45431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45432 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1312,1329,269,48,1,262,33,1029,1025,0,1313,32,17,2,269,17,1312,32,1328,1028,1284,32,257,32,48,513]

theorem envBound45432 : H12AffineFastState.Bounded env45432 := by
  intro p hp
  have h : env45432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45431_45432 : H12AffineEnvironment.transform 10 1312 env45431 = env45432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1312 env45431 == env45432) = true)

theorem identity45432 : scanCanonicalize (H12AffineFastState.compose env45432 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound45432 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45433 : List Nat := [2,4,8,16,32,17,8,256,49,1024,1312,1329,269,48,1,262,33,1029,1025,0,1313,32,17,2,269,17,1312,32,1328,1028,1284,32,257,32,48,48]

theorem envBound45433 : H12AffineFastState.Bounded env45433 := by
  intro p hp
  have h : env45433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45432_45433 : H12AffineEnvironment.transform 8 49 env45432 = env45433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env45432 == env45433) = true)

theorem identity45433 : scanCanonicalize (H12AffineFastState.compose env45433 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45433 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45434 : List Nat := [2,4,8,16,32,17,8,256,49,272,48,33,269,48,1,262,33,277,273,0,49,32,17,2,269,17,48,32,32,276,20,32,257,32,48,48]

theorem envBound45434 : H12AffineFastState.Bounded env45434 := by
  intro p hp
  have h : env45434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45433_45434 : H12AffineEnvironment.transform 9 272 env45433 = env45434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45433 == env45434) = true)

theorem identity45434 : scanCanonicalize (H12AffineFastState.compose env45434 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45435 : List Nat := [2,4,8,16,1,17,8,256,16,272,17,0,269,17,1,262,0,277,273,0,16,1,17,2,269,17,17,1,1,276,20,1,257,1,17,17]

theorem envBound45435 : H12AffineFastState.Bounded env45435 := by
  intro p hp
  have h : env45435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45434_45435 : H12AffineEnvironment.transform 4 1 env45434 = env45435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45434 == env45435) = true)

def env45436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21763,8193,64,97547,115015,17664,262145,119042,329731,257,98679,90202,63068]

theorem envBound45436 : H12AffineFastState.Bounded env45436 := by
  intro p hp
  have h : env45436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45423_45436 : H12AffineEnvironment.transform 6 9 env45423 = env45436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45423 == env45436) = true)

theorem identity45436 : scanCanonicalize (H12AffineFastState.compose env45436 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45436 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,4161,41340,17,21763,8193,64,97547,115015,17664,35188,119042,98678,257,98679,90202,63068]

theorem envBound45437 : H12AffineFastState.Bounded env45437 := by
  intro p hp
  have h : env45437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45436_45437 : H12AffineEnvironment.transform 17 35189 env45436 = env45437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45436 == env45437) = true)

theorem identity45437 : scanCanonicalize (H12AffineFastState.compose env45437 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound45437 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env45438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21875,49168,35189,1025,32769,4161,41340,17,21763,8193,64,10360,37940,17664,35188,33905,54277,257,54276,13609,63068]

theorem envBound45438 : H12AffineFastState.Bounded env45438 := by
  intro p hp
  have h : env45438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45437_45438 : H12AffineEnvironment.transform 15 21875 env45437 = env45438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env45437 == env45438) = true)

theorem identity45438 : scanCanonicalize (H12AffineFastState.compose env45438 (packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound45438 : packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env45439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,21875,13341,32120,1025,29708,4161,21873,17,21763,8193,64,10360,24633,17664,32121,28796,8200,257,8201,13609,593]

theorem envBound45439 : H12AffineFastState.Bounded env45439 := by
  intro p hp
  have h : env45439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45438_45439 : H12AffineEnvironment.transform 14 29709 env45438 = env45439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env45438 == env45439) = true)

theorem identity45439 : scanCanonicalize (H12AffineFastState.compose env45439 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound45439 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8232,342,13341,10589,1025,8233,4161,340,17,294,8193,64,10360,13340,4389,10588,9305,8200,257,8201,13609,593]

theorem envBound45440 : H12AffineFastState.Bounded env45440 := by
  intro p hp
  have h : env45440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45439_45440 : H12AffineEnvironment.transform 13 5157 env45439 = env45440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env45439 == env45440) = true)

theorem identity45440 : scanCanonicalize (H12AffineFastState.compose env45440 (packedSelected [0,3,5,7,10,12,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45440 : packedSelected [0,3,5,7,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env45441 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5157,8232,114,13341,10361,1025,8233,4161,112,17,2,8193,64,10360,13340,4097,10360,9305,8200,37,8201,13325,593]

theorem envBound45441 : H12AffineFastState.Bounded env45441 := by
  intro p hp
  have h : env45441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45440_45441 : H12AffineEnvironment.transform 7 36 env45440 = env45441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45440 == env45441) = true)

theorem identity45441 : scanCanonicalize (H12AffineFastState.compose env45441 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound45441 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45442 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5157,80,114,5221,2049,1025,81,4161,112,17,2,121,64,2048,5220,4097,2048,1057,112,37,113,5237,593]

theorem envBound45442 : H12AffineFastState.Bounded env45442 := by
  intro p hp
  have h : env45442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45441_45442 : H12AffineEnvironment.transform 12 120 env45441 = env45442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env45441 == env45442) = true)

theorem identity45442 : scanCanonicalize (H12AffineFastState.compose env45442 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound45442 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45443 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,1060,120,1,80,114,65,2049,1025,81,1125,112,17,2,121,64,2048,64,1061,2048,1057,112,37,113,81,593]

theorem envBound45443 : H12AffineFastState.Bounded env45443 := by
  intro p hp
  have h : env45443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45442_45443 : H12AffineEnvironment.transform 11 1060 env45442 = env45443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env45442 == env45443) = true)

theorem identity45443 : scanCanonicalize (H12AffineFastState.compose env45443 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45443 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env45444 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1,1060,120,1,80,114,65,0,1025,81,1125,112,17,2,121,64,1,64,1061,1,1057,112,37,113,81,593]

theorem envBound45444 : H12AffineFastState.Bounded env45444 := by
  intro p hp
  have h : env45444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45443_45444 : H12AffineEnvironment.transform 10 1 env45443 = env45444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45443 == env45444) = true)

theorem identity45444 : scanCanonicalize (H12AffineFastState.compose env45444 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45444 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45445 : List Nat := [2,4,8,16,32,64,9,36,512,52,1,16,120,1,80,114,65,0,53,81,81,112,17,2,121,64,1,64,17,1,21,112,37,113,81,593]

theorem envBound45445 : H12AffineFastState.Bounded env45445 := by
  intro p hp
  have h : env45445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45444_45445 : H12AffineEnvironment.transform 9 52 env45444 = env45445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45444 == env45445) = true)

theorem identity45445 : scanCanonicalize (H12AffineFastState.compose env45445 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45445 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45446 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,16,40,1,0,34,17,0,53,1,1,32,17,2,41,16,1,16,17,1,21,32,37,33,1,513]

theorem envBound45446 : H12AffineFastState.Bounded env45446 := by
  intro p hp
  have h : env45446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45445_45446 : H12AffineEnvironment.transform 5 16 env45445 = env45446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45445 == env45446) = true)

theorem identity45446 : scanCanonicalize (H12AffineFastState.compose env45446 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45447 : List Nat := [2,4,8,1,32,1,9,36,512,37,1,1,40,1,0,34,0,0,36,1,1,32,0,2,41,1,1,1,0,1,4,32,37,33,1,513]

theorem envBound45447 : H12AffineFastState.Bounded env45447 := by
  intro p hp
  have h : env45447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45446_45447 : H12AffineEnvironment.transform 3 1 env45446 = env45447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45446 == env45447) = true)

theorem identity45447 : scanCanonicalize (H12AffineFastState.compose env45447 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45448 : List Nat := [2,4,3,1,32,1,2,36,512,37,1,1,35,1,0,34,0,0,36,1,1,32,0,2,34,1,1,1,0,1,4,32,37,33,1,513]

theorem envBound45448 : H12AffineFastState.Bounded env45448 := by
  intro p hp
  have h : env45448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45447_45448 : H12AffineEnvironment.transform 2 3 env45447 = env45448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45447 == env45448) = true)

def env45449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,169235,8328,64,245139,115150,17664,262145,119042,329730,257,213486,237642,63189]

theorem envBound45449 : H12AffineFastState.Bounded env45449 := by
  intro p hp
  have h : env45449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45421_45449 : H12AffineEnvironment.transform 21 272513 env45421 = env45449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45421 == env45449) = true)

def env45450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180225,169235,8192,64,245019,115014,17664,262145,119042,329730,257,213350,237642,63069]

theorem envBound45450 : H12AffineFastState.Bounded env45450 := by
  intro p hp
  have h : env45450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45449_45450 : H12AffineEnvironment.transform 6 8 env45449 = env45450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45449 == env45450) = true)

def env45451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21763,8192,64,97547,115014,17664,262145,119042,329730,257,98678,90202,63069]

theorem envBound45451 : H12AffineFastState.Bounded env45451 := by
  intro p hp
  have h : env45451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45450_45451 : H12AffineEnvironment.transform 16 49168 env45450 = env45451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45450 == env45451) = true)

theorem identity45451 : scanCanonicalize (H12AffineFastState.compose env45451 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45451 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,33,17,21763,8192,64,97547,115014,17664,10281,119042,73770,257,98678,90202,63069]

theorem envBound45452 : H12AffineFastState.Bounded env45452 := by
  intro p hp
  have h : env45452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45451_45452 : H12AffineEnvironment.transform 17 10280 env45451 = env45452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45451 == env45452) = true)

theorem identity45452 : scanCanonicalize (H12AffineFastState.compose env45452 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound45452 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env45453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,10280,1025,32769,4161,33,17,21763,8192,64,43276,5441,17664,10281,1285,62509,257,21873,46173,63069]

theorem envBound45453 : H12AffineFastState.Bounded env45453 := by
  intro p hp
  have h : env45453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45452_45453 : H12AffineEnvironment.transform 15 54279 env45452 = env45453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env45452 == env45453) = true)

theorem identity45453 : scanCanonicalize (H12AffineFastState.compose env45453 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45453 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env45454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54279,49168,2421,1025,32769,4161,33,17,21763,349,64,34897,5441,17664,2420,1285,54640,257,21873,38144,55040]

theorem envBound45454 : H12AffineFastState.Bounded env45454 := by
  intro p hp
  have h : env45454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45453_45454 : H12AffineEnvironment.transform 12 349 env45453 = env45454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45453 == env45454) = true)

theorem identity45454 : scanCanonicalize (H12AffineFastState.compose env45454 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound45454 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env45455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,32768,33111,38208,2421,1025,32769,4161,33,17,83,349,64,34897,5441,4176,2420,1285,32800,257,33,38144,33360]

theorem envBound45455 : H12AffineFastState.Bounded env45455 := by
  intro p hp
  have h : env45455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45454_45455 : H12AffineEnvironment.transform 13 5456 env45454 = env45455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env45454 == env45455) = true)

theorem identity45455 : scanCanonicalize (H12AffineFastState.compose env45455 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound45455 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,262,5393,2421,1025,80,4161,33,17,83,349,64,2048,5441,4176,2420,1285,113,257,33,5457,513]

theorem envBound45456 : H12AffineFastState.Bounded env45456 := by
  intro p hp
  have h : env45456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45455_45456 : H12AffineEnvironment.transform 14 81 env45455 = env45456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env45455 == env45456) = true)

theorem identity45456 : scanCanonicalize (H12AffineFastState.compose env45456 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45456 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45457 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1025,1,4112,33,17,2,268,17,2048,5392,4097,2341,1285,32,257,33,5376,513]

theorem envBound45457 : H12AffineFastState.Bounded env45457 := by
  intro p hp
  have h : env45457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45456_45457 : H12AffineEnvironment.transform 5 17 env45456 = env45457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45456 == env45457) = true)

theorem identity45457 : scanCanonicalize (H12AffineFastState.compose env45457 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound45457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45458 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1028,268,261,0,262,277,2340,1025,1,1044,33,17,2,268,17,2048,276,1029,2341,1285,32,257,33,260,513]

theorem envBound45458 : H12AffineFastState.Bounded env45458 := by
  intro p hp
  have h : env45458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45457_45458 : H12AffineEnvironment.transform 11 1028 env45457 = env45458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env45457 == env45458) = true)

theorem identity45458 : scanCanonicalize (H12AffineFastState.compose env45458 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45458 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45459 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,16,268,261,0,262,277,2340,21,1,0,33,17,2,268,17,2048,276,17,2341,273,32,257,33,260,513]

theorem envBound45459 : H12AffineFastState.Bounded env45459 := by
  intro p hp
  have h : env45459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45458_45459 : H12AffineEnvironment.transform 9 20 env45458 = env45459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45458 == env45459) = true)

theorem identity45459 : scanCanonicalize (H12AffineFastState.compose env45459 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound45459 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45460 : List Nat := [2,4,8,16,32,17,8,256,512,20,512,16,268,261,0,262,277,804,21,1,0,33,17,2,268,17,512,276,17,805,273,32,257,33,260,513]

theorem envBound45460 : H12AffineFastState.Bounded env45460 := by
  intro p hp
  have h : env45460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45459_45460 : H12AffineEnvironment.transform 10 512 env45459 = env45460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env45459 == env45460) = true)

theorem identity45460 : scanCanonicalize (H12AffineFastState.compose env45460 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound45460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45461 : List Nat := [2,4,8,16,32,17,8,53,512,20,512,16,57,48,0,51,32,529,21,1,0,33,17,2,57,17,512,33,17,528,36,32,52,33,49,513]

theorem envBound45461 : H12AffineFastState.Bounded env45461 := by
  intro p hp
  have h : env45461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45460_45461 : H12AffineEnvironment.transform 7 53 env45460 = env45461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env45460 == env45461) = true)

theorem identity45461 : scanCanonicalize (H12AffineFastState.compose env45461 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45461 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env45462 : List Nat := [2,4,8,16,32,17,8,53,17,20,17,16,57,48,0,51,32,0,21,1,0,33,17,2,57,17,17,33,17,1,36,32,52,33,49,16]

theorem envBound45462 : H12AffineFastState.Bounded env45462 := by
  intro p hp
  have h : env45462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45461_45462 : H12AffineEnvironment.transform 8 17 env45461 = env45462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45461 == env45462) = true)

theorem identity45462 : scanCanonicalize (H12AffineFastState.compose env45462 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45462 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env45463 : List Nat := [2,4,8,16,16,17,8,5,17,20,17,16,9,0,0,3,16,0,21,1,0,17,17,2,9,17,17,17,17,1,20,16,4,17,1,16]

theorem envBound45463 : H12AffineFastState.Bounded env45463 := by
  intro p hp
  have h : env45463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45462_45463 : H12AffineEnvironment.transform 4 16 env45462 = env45463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45462 == env45463) = true)

def env45464 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,16,21762,8192,64,97546,115014,17664,262145,119042,329730,257,98679,90203,63069]

theorem envBound45464 : H12AffineFastState.Bounded env45464 := by
  intro p hp
  have h : env45464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45450_45464 : H12AffineEnvironment.transform 16 49169 env45450 = env45464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45450 == env45464) = true)

theorem identity45464 : scanCanonicalize (H12AffineFastState.compose env45464 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound45464 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env45465 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,76078,1025,32769,4160,65831,16,21762,8192,64,97546,115014,17664,76079,119042,8492,257,98679,90203,63069]

theorem envBound45465 : H12AffineFastState.Bounded env45465 := by
  intro p hp
  have h : env45465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45464_45465 : H12AffineEnvironment.transform 17 76078 env45464 = env45465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env45464 == env45465) = true)

theorem identity45465 : scanCanonicalize (H12AffineFastState.compose env45465 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound45465 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env45466 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,49169,10361,1025,32769,4160,112,16,21762,8192,64,31837,49169,17664,10360,53333,8492,257,32800,24844,63069]

theorem envBound45466 : H12AffineFastState.Bounded env45466 := by
  intro p hp
  have h : env45466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45465_45466 : H12AffineEnvironment.transform 15 343 env45465 = env45466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env45465 == env45466) = true)

theorem identity45466 : scanCanonicalize (H12AffineFastState.compose env45466 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound45466 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,343,5441,10361,1025,21841,4160,112,16,21762,8192,64,31837,5441,17664,10360,1285,8492,257,21872,24844,8973]

theorem envBound45467 : H12AffineFastState.Bounded env45467 := by
  intro p hp
  have h : env45467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45466_45467 : H12AffineEnvironment.transform 14 21840 env45466 = env45467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env45466 == env45467) = true)

theorem identity45467 : scanCanonicalize (H12AffineFastState.compose env45467 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound45467 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env45468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,343,5441,10361,1025,8541,4160,112,16,8462,8192,64,2129,5441,12556,10360,1285,8492,257,8572,5376,8973]

theorem envBound45468 : H12AffineFastState.Bounded env45468 := by
  intro p hp
  have h : env45468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45467_45468 : H12AffineEnvironment.transform 13 13324 env45467 = env45468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env45467 == env45468) = true)

theorem identity45468 : scanCanonicalize (H12AffineFastState.compose env45468 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45468 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env45469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,343,5441,2421,1025,81,4160,112,16,2,268,64,2129,5441,4096,2420,1285,32,257,112,5376,513]

theorem envBound45469 : H12AffineFastState.Bounded env45469 := by
  intro p hp
  have h : env45469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45468_45469 : H12AffineEnvironment.transform 12 268 env45468 = env45469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45468 == env45469) = true)

def env45470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180225,169235,8193,64,245018,115015,17664,262145,119042,329730,257,213351,237642,63068]

theorem envBound45470 : H12AffineFastState.Bounded env45470 := by
  intro p hp
  have h : env45470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45449_45470 : H12AffineEnvironment.transform 6 9 env45449 = env45470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45449 == env45470) = true)

def env45471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21763,8193,64,97546,115015,17664,262145,119042,329730,257,98679,90202,63068]

theorem envBound45471 : H12AffineFastState.Bounded env45471 := by
  intro p hp
  have h : env45471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45470_45471 : H12AffineEnvironment.transform 16 49168 env45470 = env45471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45470 == env45471) = true)

theorem identity45471 : scanCanonicalize (H12AffineFastState.compose env45471 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45471 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,4161,41341,17,21763,8193,64,97546,115015,17664,35188,119042,98679,257,98679,90202,63068]

theorem envBound45472 : H12AffineFastState.Bounded env45472 := by
  intro p hp
  have h : env45472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45471_45472 : H12AffineEnvironment.transform 17 35189 env45471 = env45472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45471 == env45472) = true)

theorem identity45472 : scanCanonicalize (H12AffineFastState.compose env45472 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound45472 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env45473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8575,49168,35189,1025,32769,4161,41341,17,21763,8193,64,23669,57400,17664,35188,61565,40968,257,40968,16677,63068]

theorem envBound45473 : H12AffineFastState.Bounded env45473 := by
  intro p hp
  have h : env45473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45472_45473 : H12AffineEnvironment.transform 15 8575 env45472 = env45473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env45472 == env45473) = true)

theorem identity45473 : scanCanonicalize (H12AffineFastState.compose env45473 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45473 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env45474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,34,49168,35189,1025,32769,4161,32800,17,21763,348,64,23669,49509,17664,35188,53536,33109,257,33109,16677,55041]

theorem envBound45474 : H12AffineFastState.Bounded env45474 := by
  intro p hp
  have h : env45474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45473_45474 : H12AffineEnvironment.transform 12 349 env45473 = env45474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45473 == env45474) = true)

theorem identity45474 : scanCanonicalize (H12AffineFastState.compose env45474 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound45474 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,34,5392,23669,1025,21761,4161,21792,17,21763,348,64,23669,5221,17664,23668,1056,21589,257,21589,16677,513]

theorem envBound45475 : H12AffineFastState.Bounded env45475 := by
  intro p hp
  have h : env45475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45474_45475 : H12AffineEnvironment.transform 14 21760 env45474 = env45475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env45474 == env45475) = true)

theorem identity45475 : scanCanonicalize (H12AffineFastState.compose env45475 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound45475 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45476 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,16384,20837,34,4469,22544,100,20836,4161,20805,17,20838,348,64,22544,4096,16741,22545,69,20528,257,20528,16677,513]

theorem envBound45476 : H12AffineFastState.Bounded env45476 := by
  intro p hp
  have h : env45476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45475_45476 : H12AffineEnvironment.transform 9 101 env45475 = env45476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env45475 == env45476) = true)

theorem identity45476 : scanCanonicalize (H12AffineFastState.compose env45476 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound45476 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env45477 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4404,81,34,4469,2340,100,80,4161,113,17,82,348,64,2340,4096,4177,2341,69,260,257,260,4113,513]

theorem envBound45477 : H12AffineFastState.Bounded env45477 := by
  intro p hp
  have h : env45477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45476_45477 : H12AffineEnvironment.transform 13 4404 env45476 = env45477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env45476 == env45477) = true)

theorem identity45477 : scanCanonicalize (H12AffineFastState.compose env45477 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45477 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45478 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,40,4161,81,34,4096,2129,100,80,4161,113,17,82,41,64,2129,4096,4177,2128,69,113,116,113,4113,513]

theorem envBound45478 : H12AffineFastState.Bounded env45478 := by
  intro p hp
  have h : env45478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45477_45478 : H12AffineEnvironment.transform 7 117 env45477 = env45478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45477 == env45478) = true)

theorem identity45478 : scanCanonicalize (H12AffineFastState.compose env45478 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound45478 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env45479 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,593,40,528,81,34,593,2129,100,80,528,113,17,82,41,64,2129,593,512,2128,69,113,116,113,576,513]

theorem envBound45479 : H12AffineFastState.Bounded env45479 := by
  intro p hp
  have h : env45479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45478_45479 : H12AffineEnvironment.transform 11 593 env45478 = env45479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env45478 == env45479) = true)

theorem identity45479 : scanCanonicalize (H12AffineFastState.compose env45479 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45479 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45480 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,593,8,528,81,2,593,2129,68,80,528,81,17,82,9,64,2129,593,512,2128,69,81,84,81,576,513]

theorem envBound45480 : H12AffineFastState.Bounded env45480 := by
  intro p hp
  have h : env45480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45479_45480 : H12AffineEnvironment.transform 4 0 env45479 = env45480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45479 == env45480) = true)

theorem identity45480 : scanCanonicalize (H12AffineFastState.compose env45480 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound45480 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45481 : List Nat := [2,4,8,16,0,64,9,85,512,69,64,593,8,528,81,2,593,17,68,80,528,81,17,82,9,64,17,593,512,16,69,81,84,81,576,513]

theorem envBound45481 : H12AffineFastState.Bounded env45481 := by
  intro p hp
  have h : env45481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45480_45481 : H12AffineEnvironment.transform 10 64 env45480 = env45481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env45480 == env45481) = true)

theorem identity45481 : scanCanonicalize (H12AffineFastState.compose env45481 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45481 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env45482 : List Nat := [2,4,8,16,0,64,9,85,16,69,64,65,8,0,81,2,65,17,68,80,0,81,17,82,9,64,17,65,16,16,69,81,84,81,80,17]

theorem envBound45482 : H12AffineFastState.Bounded env45482 := by
  intro p hp
  have h : env45482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45481_45482 : H12AffineEnvironment.transform 8 16 env45481 = env45482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45481 == env45482) = true)

theorem identity45482 : scanCanonicalize (H12AffineFastState.compose env45482 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45482 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45483 : List Nat := [2,4,8,1,0,64,9,68,1,69,64,65,8,0,64,2,65,0,68,65,0,64,0,67,9,64,0,65,1,1,69,64,69,64,65,0]

theorem envBound45483 : H12AffineFastState.Bounded env45483 := by
  intro p hp
  have h : env45483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45482_45483 : H12AffineEnvironment.transform 3 1 env45482 = env45483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45482 == env45483) = true)

def env45484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,16,21762,8193,64,97547,115015,17664,262145,119042,329730,257,98678,90203,63068]

theorem envBound45484 : H12AffineFastState.Bounded env45484 := by
  intro p hp
  have h : env45484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45470_45484 : H12AffineEnvironment.transform 16 49169 env45470 = env45484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45470 == env45484) = true)

theorem identity45484 : scanCanonicalize (H12AffineFastState.compose env45484 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45484 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24909,262144,1025,8541,4160,272392,16,21762,8193,64,97547,90139,17664,262145,94302,329730,257,73770,90203,22272]

theorem envBound45485 : H12AffineFastState.Bounded env45485 := by
  intro p hp
  have h : env45485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45484_45485 : H12AffineEnvironment.transform 14 8540 env45484 = env45485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45484 == env45485) = true)

theorem identity45485 : scanCanonicalize (H12AffineFastState.compose env45485 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound45485 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24909,97407,1025,8541,4160,87159,16,21762,8193,64,97547,90139,17664,97406,94302,29821,257,73770,90203,22272]

theorem envBound45486 : H12AffineFastState.Bounded env45486 := by
  intro p hp
  have h : env45486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45485_45486 : H12AffineEnvironment.transform 17 97407 env45485 = env45486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env45485 == env45486) = true)

theorem identity45486 : scanCanonicalize (H12AffineFastState.compose env45486 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound45486 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,24909,10281,1025,8541,4160,33,16,21762,8193,64,10589,13389,17664,10280,9224,29821,257,29820,13325,22272]

theorem envBound45487 : H12AffineFastState.Bounded env45487 := by
  intro p hp
  have h : env45487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45486_45487 : H12AffineEnvironment.transform 15 21590 env45486 = env45487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env45486 == env45487) = true)

theorem identity45487 : scanCanonicalize (H12AffineFastState.compose env45487 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound45487 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env45488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,8540,9499,4096,10281,1025,8541,4160,33,16,9295,8193,64,10589,13389,13389,10280,9224,1328,257,1329,13325,9805]

theorem envBound45488 : H12AffineFastState.Bounded env45488 := by
  intro p hp
  have h : env45488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45487_45488 : H12AffineEnvironment.transform 13 12621 env45487 = env45488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env45487 == env45488) = true)

theorem identity45488 : scanCanonicalize (H12AffineFastState.compose env45488 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45488 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env45489 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,12392,8313,9278,4096,10281,1025,8312,4160,33,16,9295,8193,64,10360,13389,13389,10280,9224,1045,36,1044,13325,9805]

theorem envBound45489 : H12AffineFastState.Bounded env45489 := by
  intro p hp
  have h : env45489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45488_45489 : H12AffineEnvironment.transform 7 37 env45488 = env45489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45488 == env45489) = true)

theorem identity45489 : scanCanonicalize (H12AffineFastState.compose env45489 (packedSelected [2,6,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45489 : packedSelected [2,6,11,15] rootPS < 2^1333 := by decide +kernel

def env45490 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,4096,8192,12392,8313,8282,4096,10281,101,8312,4160,33,16,8235,8193,64,10360,12329,12329,10280,8300,113,36,112,12393,8745]

theorem envBound45490 : H12AffineFastState.Bounded env45490 := by
  intro p hp
  have h : env45490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45489_45490 : H12AffineEnvironment.transform 9 100 env45489 = env45490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45489 == env45490) = true)

theorem identity45490 : scanCanonicalize (H12AffineFastState.compose env45490 (packedSelected [0,2,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound45490 : packedSelected [0,2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45491 : List Nat := [2,4,8,16,32,64,9,37,80,100,2048,4096,8192,12392,8313,8282,4096,10281,101,8312,4160,33,16,8235,8193,64,10360,12329,12329,10280,8300,113,36,112,12393,8313]

theorem envBound45491 : H12AffineFastState.Bounded env45491 := by
  intro p hp
  have h : env45491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45490_45491 : H12AffineEnvironment.transform 8 80 env45490 = env45491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env45490 == env45491) = true)

theorem identity45491 : scanCanonicalize (H12AffineFastState.compose env45491 (packedSelected [3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound45491 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env45492 : List Nat := [2,4,8,16,32,64,9,37,80,100,2048,2065,8192,10361,8313,8282,2065,10281,101,8312,2129,33,16,8235,8193,64,10360,10296,10296,10280,8300,113,36,112,10360,8313]

theorem envBound45492 : H12AffineFastState.Bounded env45492 := by
  intro p hp
  have h : env45492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45491_45492 : H12AffineEnvironment.transform 11 2065 env45491 = env45492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env45491 == env45492) = true)

theorem identity45492 : scanCanonicalize (H12AffineFastState.compose env45492 (packedSelected [0,1,2,3,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45492 : packedSelected [0,1,2,3,6,10] rootPS < 2^1333 := by decide +kernel

def env45493 : List Nat := [2,4,8,16,32,64,9,37,80,100,2048,2065,41,2128,80,115,2065,2048,101,81,2129,33,16,2,40,64,2129,2065,2065,2049,69,113,36,112,2129,80]

theorem envBound45493 : H12AffineFastState.Bounded env45493 := by
  intro p hp
  have h : env45493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45492_45493 : H12AffineEnvironment.transform 12 41 env45492 = env45493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45492 == env45493) = true)

theorem identity45493 : scanCanonicalize (H12AffineFastState.compose env45493 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound45493 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45494 : List Nat := [2,4,8,16,32,64,9,37,80,100,31,14,41,79,80,115,14,31,101,81,78,33,16,2,40,64,78,14,14,30,69,113,36,112,78,80]

theorem envBound45494 : H12AffineFastState.Bounded env45494 := by
  intro p hp
  have h : env45494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45493_45494 : H12AffineEnvironment.transform 10 31 env45493 = env45494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env45493 == env45494) = true)

theorem identity45494 : scanCanonicalize (H12AffineFastState.compose env45494 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound45494 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45495 : List Nat := [2,4,8,16,30,64,9,27,80,90,31,14,23,79,80,77,14,31,91,81,78,31,16,2,22,64,78,14,14,30,69,79,26,78,78,80]

theorem envBound45495 : H12AffineFastState.Bounded env45495 := by
  intro p hp
  have h : env45495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45494_45495 : H12AffineEnvironment.transform 4 30 env45494 = env45495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env45494 == env45495) = true)

def env45496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound45496 : H12AffineFastState.Bounded env45496 := by
  intro p hp
  have h : env45496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44621_45496 : H12AffineEnvironment.transform 25 65 env44621 = env45496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env44621 == env45496) = true)

def env45497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound45497 : H12AffineFastState.Bounded env45497 := by
  intro p hp
  have h : env45497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45496_45497 : H12AffineEnvironment.transform 26 30393344 env45496 = env45497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env45496 == env45497) = true)

def env45498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound45498 : H12AffineFastState.Bounded env45498 := by
  intro p hp
  have h : env45498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45497_45498 : H12AffineEnvironment.transform 18 1024 env45497 = env45498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env45497 == env45498) = true)

theorem identity45498 : scanCanonicalize (H12AffineFastState.compose env45498 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 509986) := by decide +kernel

theorem selectedBound45498 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,509986,16777216,8328,65,20973602,18973837,2596211,67618,17189939,23160256,256,19270799,19328299,17263588]

theorem envBound45499 : H12AffineFastState.Bounded env45499 := by
  intro p hp
  have h : env45499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45498_45499 : H12AffineEnvironment.transform 22 509986 env45498 = env45499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 509986 env45498 == env45499) = true)

def env45500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509986,16777216,8328,65,16959642,18973837,2596211,67618,17189939,19113336,256,19270799,19328299,17263588]

theorem envBound45500 : H12AffineFastState.Bounded env45500 := by
  intro p hp
  have h : env45500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45499_45500 : H12AffineEnvironment.transform 21 180408 env45499 = env45500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env45499 == env45500) = true)

def env45501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509986,498992,8328,65,349610,2496957,2596211,67618,119043,2373704,256,2199999,2191387,63188]

theorem envBound45501 : H12AffineFastState.Bounded env45501 := by
  intro p hp
  have h : env45501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45500_45501 : H12AffineEnvironment.transform 23 498992 env45500 = env45501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env45500 == env45501) = true)

def env45502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509986,498992,8328,65,349610,395773,494899,67618,119043,272392,256,98815,90203,63188]

theorem envBound45502 : H12AffineFastState.Bounded env45502 := by
  intro p hp
  have h : env45502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45501_45502 : H12AffineEnvironment.transform 20 4160 env45501 = env45502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45501 == env45502) = true)

theorem identity45502 : scanCanonicalize (H12AffineFastState.compose env45502 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45502 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,180408,452648,441658,8328,65,292256,395773,437561,10280,61705,272392,256,41461,16465,63188]

theorem envBound45503 : H12AffineFastState.Bounded env45503 := by
  intro p hp
  have h : env45503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45502_45503 : H12AffineEnvironment.transform 15 8202 env45502 = env45503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45502 == env45503) = true)

def env45504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,32768,250,131072,262144,1024,32769,4160,180408,444632,433610,120,65,283984,395773,429513,2264,53753,264440,256,33029,16465,54820]

theorem envBound45504 : H12AffineFastState.Bounded env45504 := by
  intro p hp
  have h : env45504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45503_45504 : H12AffineEnvironment.transform 12 240 env45503 = env45504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env45503 == env45504) = true)

theorem identity45504 : scanCanonicalize (H12AffineFastState.compose env45504 (packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 182336) := by decide +kernel

theorem selectedBound45504 : packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env45505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,32768,250,131072,182336,1024,32769,4160,180408,152,21898,120,65,171280,49597,17801,2264,53753,180408,256,33029,16465,54820]

theorem envBound45505 : H12AffineFastState.Bounded env45505 := by
  intro p hp
  have h : env45505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45504_45505 : H12AffineEnvironment.transform 17 182336 env45504 = env45505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182336 env45504 == env45505) = true)

theorem identity45505 : scanCanonicalize (H12AffineFastState.compose env45505 (packedSelected [0,2,6,8,11,12,14,16,19,20,23,26,27,28,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound45505 : packedSelected [0,2,6,8,11,12,14,16,19,20,23,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env45506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21897,250,131072,138697,1024,21896,4160,136497,152,21898,120,65,149657,5172,17801,2264,1136,136497,256,21644,16465,941]

theorem envBound45506 : H12AffineFastState.Bounded env45506 := by
  intro p hp
  have h : env45506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45505_45506 : H12AffineEnvironment.transform 14 21897 env45505 = env45506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env45505 == env45506) = true)

theorem identity45506 : scanCanonicalize (H12AffineFastState.compose env45506 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound45506 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env45507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21897,250,5309,2420,1024,21896,4160,396,152,21898,120,65,23588,5172,17801,2264,1136,396,256,21644,16465,941]

theorem envBound45507 : H12AffineFastState.Bounded env45507 := by
  intro p hp
  have h : env45507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45506_45507 : H12AffineEnvironment.transform 16 5309 env45506 = env45507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env45506 == env45507) = true)

theorem identity45507 : scanCanonicalize (H12AffineFastState.compose env45507 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound45507 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env45508 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,240,16384,21541,250,5309,2264,1024,21540,4160,32,152,21542,120,65,23588,5172,17445,2264,1136,32,172,21644,16465,513]

theorem envBound45508 : H12AffineFastState.Bounded env45508 := by
  intro p hp
  have h : env45508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45507_45508 : H12AffineEnvironment.transform 7 172 env45507 = env45508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env45507 == env45508) = true)

theorem identity45508 : scanCanonicalize (H12AffineFastState.compose env45508 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound45508 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45509 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,240,5292,137,250,5309,2264,1024,136,4160,32,152,138,120,65,2184,5172,4233,2264,1136,32,172,32,5373,513]

theorem envBound45509 : H12AffineFastState.Bounded env45509 := by
  intro p hp
  have h : env45509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45508_45509 : H12AffineEnvironment.transform 13 5292 env45508 = env45509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env45508 == env45509) = true)

theorem identity45509 : scanCanonicalize (H12AffineFastState.compose env45509 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound45509 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env45510 : List Nat := [2,4,8,16,32,64,128,172,512,1024,136,4096,240,5292,137,250,5309,80,1024,136,4160,32,152,138,120,65,0,5172,4233,80,1136,32,172,32,5373,513]

theorem envBound45510 : H12AffineFastState.Bounded env45510 := by
  intro p hp
  have h : env45510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45509_45510 : H12AffineEnvironment.transform 10 136 env45509 = env45510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env45509 == env45510) = true)

theorem identity45510 : scanCanonicalize (H12AffineFastState.compose env45510 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound45510 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env45511 : List Nat := [2,4,8,16,32,64,128,172,512,237,136,4096,240,4161,137,250,4176,80,237,136,4160,32,152,138,120,65,0,4313,4233,80,157,32,172,32,4112,513]

theorem envBound45511 : H12AffineFastState.Bounded env45511 := by
  intro p hp
  have h : env45511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45510_45511 : H12AffineEnvironment.transform 9 237 env45510 = env45511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env45510 == env45511) = true)

theorem identity45511 : scanCanonicalize (H12AffineFastState.compose env45511 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound45511 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env45512 : List Nat := [2,4,8,16,32,64,128,172,512,237,136,65,240,0,137,250,17,80,237,136,1,32,152,138,120,65,0,152,200,80,157,32,172,32,81,513]

theorem envBound45512 : H12AffineFastState.Bounded env45512 := by
  intro p hp
  have h : env45512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45511_45512 : H12AffineEnvironment.transform 11 65 env45511 = env45512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env45511 == env45512) = true)

def env45513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,32768,251,131072,262144,1024,32769,4160,180408,444633,433611,121,65,283985,395773,429512,2265,53752,264441,256,33028,16465,54821]

theorem envBound45513 : H12AffineFastState.Bounded env45513 := by
  intro p hp
  have h : env45513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45503_45513 : H12AffineEnvironment.transform 12 241 env45503 = env45513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env45503 == env45513) = true)

theorem identity45513 : scanCanonicalize (H12AffineFastState.compose env45513 (packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 182473) := by decide +kernel

theorem selectedBound45513 : packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env45514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,32768,251,131072,182473,1024,32769,4160,180408,16,21762,121,65,171416,49460,17665,2265,53752,180272,256,33028,16465,54821]

theorem envBound45514 : H12AffineFastState.Bounded env45514 := by
  intro p hp
  have h : env45514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45513_45514 : H12AffineEnvironment.transform 17 182473 env45513 = env45514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182473 env45513 == env45514) = true)

theorem identity45514 : scanCanonicalize (H12AffineFastState.compose env45514 (packedSelected [3,4,6,7,8,15,16,17,19,20,22,24,27,28,41] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45514 : packedSelected [3,4,6,7,8,15,16,17,19,20,22,24,27,28,41] rootPS < 2^1333 := by decide +kernel

def env45515 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,16384,32768,251,131072,182473,1024,32769,4160,180408,16,21623,121,65,171245,49217,17524,2265,53389,180272,117,32881,16465,54821]

theorem envBound45515 : H12AffineFastState.Bounded env45515 := by
  intro p hp
  have h : env45515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45514_45515 : H12AffineEnvironment.transform 7 117 env45514 = env45515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45514 == env45515) = true)

theorem identity45515 : scanCanonicalize (H12AffineFastState.compose env45515 (packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,17,19,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49352) := by decide +kernel

theorem selectedBound45515 : packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,17,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env45516 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,16384,32768,251,49352,2049,1024,32769,4160,112,16,21623,121,65,23589,49217,17524,2265,53389,248,117,32881,16465,54821]

theorem envBound45516 : H12AffineFastState.Bounded env45516 := by
  intro p hp
  have h : env45516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45515_45516 : H12AffineEnvironment.transform 16 49352 env45515 = env45516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49352 env45515 == env45516) = true)

theorem identity45516 : scanCanonicalize (H12AffineFastState.compose env45516 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound45516 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env45517 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,16384,137,251,16449,2049,1024,136,4160,112,16,21623,121,65,23589,16584,17524,2265,20484,248,117,248,16465,22188]

theorem envBound45517 : H12AffineFastState.Bounded env45517 := by
  intro p hp
  have h : env45517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45516_45517 : H12AffineEnvironment.transform 14 137 env45516 = env45517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env45516 == env45517) = true)

theorem identity45517 : scanCanonicalize (H12AffineFastState.compose env45517 (packedSelected [3,5,6,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound45517 : packedSelected [3,5,6,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env45518 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,3109,241,16384,137,251,16449,2049,1024,136,3173,112,16,18514,121,65,16384,16584,17524,2265,19489,248,117,248,16465,19081]

theorem envBound45518 : H12AffineFastState.Bounded env45518 := by
  intro p hp
  have h : env45518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45517_45518 : H12AffineEnvironment.transform 11 3109 env45517 = env45518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env45517 == env45518) = true)

theorem identity45518 : scanCanonicalize (H12AffineFastState.compose env45518 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45518 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45519 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,120,16384,0,114,16449,2049,1024,1,3173,112,16,18514,121,65,16384,16449,17524,2128,19489,113,117,113,16465,18944]

theorem envBound45519 : H12AffineFastState.Bounded env45519 := by
  intro p hp
  have h : env45519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45518_45519 : H12AffineEnvironment.transform 6 9 env45518 = env45519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45518 == env45519) = true)

theorem identity45519 : scanCanonicalize (H12AffineFastState.compose env45519 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45519 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45520 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,41,16384,0,35,16400,2049,1024,1,3124,33,16,18435,40,16,16384,16400,17445,2049,19489,32,36,32,16384,18944]

theorem envBound45520 : H12AffineFastState.Bounded env45520 := by
  intro p hp
  have h : env45520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45519_45520 : H12AffineEnvironment.transform 5 17 env45519 = env45520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45519 == env45520) = true)

theorem identity45520 : scanCanonicalize (H12AffineFastState.compose env45520 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound45520 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45521 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,41,2049,0,35,2065,2049,1024,1,3124,33,16,2,40,16,2049,2065,3108,2049,1056,32,36,32,2049,513]

theorem envBound45521 : H12AffineFastState.Bounded env45521 := by
  intro p hp
  have h : env45521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45520_45521 : H12AffineEnvironment.transform 13 2049 env45520 = env45521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env45520 == env45521) = true)

theorem identity45521 : scanCanonicalize (H12AffineFastState.compose env45521 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound45521 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45522 : List Nat := [2,4,8,16,32,17,9,36,512,36,2048,2049,41,2049,0,35,2065,2049,36,1,2064,33,16,2,40,16,2049,2065,2048,2049,4,32,36,32,2049,513]

theorem envBound45522 : H12AffineFastState.Bounded env45522 := by
  intro p hp
  have h : env45522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45521_45522 : H12AffineEnvironment.transform 9 36 env45521 = env45522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env45521 == env45522) = true)

theorem identity45522 : scanCanonicalize (H12AffineFastState.compose env45522 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45522 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45523 : List Nat := [2,4,8,11,32,10,9,36,512,36,2048,2049,41,2049,0,35,2058,2049,36,1,2059,33,11,2,40,11,2049,2058,2048,2049,4,32,36,32,2049,513]

theorem envBound45523 : H12AffineFastState.Bounded env45523 := by
  intro p hp
  have h : env45523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45522_45523 : H12AffineEnvironment.transform 3 11 env45522 = env45523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45522 == env45523) = true)

theorem identity45523 : scanCanonicalize (H12AffineFastState.compose env45523 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound45523 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45524 : List Nat := [2,4,8,11,32,10,9,36,512,36,43,42,41,42,0,35,33,42,36,1,32,33,11,2,40,11,42,33,43,42,4,32,36,32,42,513]

theorem envBound45524 : H12AffineFastState.Bounded env45524 := by
  intro p hp
  have h : env45524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45523_45524 : H12AffineEnvironment.transform 10 43 env45523 = env45524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env45523 == env45524) = true)

theorem identity45524 : scanCanonicalize (H12AffineFastState.compose env45524 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound45524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45525 : List Nat := [2,4,8,11,32,10,9,36,47,36,43,42,41,42,0,35,33,42,36,1,32,33,11,2,40,11,42,33,43,42,4,32,36,32,42,46]

theorem envBound45525 : H12AffineFastState.Bounded env45525 := by
  intro p hp
  have h : env45525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45524_45525 : H12AffineEnvironment.transform 8 47 env45524 = env45525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env45524 == env45525) = true)

theorem identity45525 : scanCanonicalize (H12AffineFastState.compose env45525 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45525 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45526 : List Nat := [2,4,3,0,32,1,2,36,36,36,32,33,34,33,0,35,33,33,36,1,32,33,0,2,35,0,33,33,32,33,4,32,36,32,33,37]

theorem envBound45526 : H12AffineFastState.Bounded env45526 := by
  intro p hp
  have h : env45526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45525_45526 : H12AffineEnvironment.transform 2 3 env45525 = env45526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45525 == env45526) = true)

theorem identity45526 : scanCanonicalize (H12AffineFastState.compose env45526 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound45526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45527 : List Nat := [2,4,3,0,2,1,2,6,6,6,2,3,0,3,0,1,3,3,6,1,2,3,0,2,1,0,3,3,2,3,4,2,6,2,3,7]

theorem envBound45527 : H12AffineFastState.Bounded env45527 := by
  intro p hp
  have h : env45527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45526_45527 : H12AffineEnvironment.transform 4 2 env45526 = env45527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env45526 == env45527) = true)

def env45528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509986,498992,8328,65,349610,395772,494898,67618,119043,272393,256,98814,90202,63188]

theorem envBound45528 : H12AffineFastState.Bounded env45528 := by
  intro p hp
  have h : env45528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45501_45528 : H12AffineEnvironment.transform 20 4161 env45501 = env45528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45501 == env45528) = true)

theorem identity45528 : scanCanonicalize (H12AffineFastState.compose env45528 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound45528 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180408,16,21762,8328,65,171416,115150,17664,67618,119043,254011,256,98814,90202,63188]

theorem envBound45529 : H12AffineFastState.Bounded env45529 := by
  intro p hp
  have h : env45529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45528_45529 : H12AffineEnvironment.transform 17 247858 env45528 = env45529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env45528 == env45529) = true)

def env45530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180272,16,21762,8192,65,171280,115014,17664,67618,119043,254011,256,98678,90202,63068]

theorem envBound45530 : H12AffineFastState.Bounded env45530 := by
  intro p hp
  have h : env45530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45529_45530 : H12AffineEnvironment.transform 6 8 env45529 = env45530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45529 == env45530) = true)

theorem identity45530 : scanCanonicalize (H12AffineFastState.compose env45530 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound45530 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1024,32769,4161,73770,16,21762,8192,65,97546,115014,17664,67618,119043,33,256,98678,90202,63068]

theorem envBound45531 : H12AffineFastState.Bounded env45531 := by
  intro p hp
  have h : env45531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45530_45531 : H12AffineEnvironment.transform 16 122906 env45530 = env45531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env45530 == env45531) = true)

theorem identity45531 : scanCanonicalize (H12AffineFastState.compose env45531 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound45531 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env45532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,46157,10280,1024,32769,4161,29821,16,21762,8192,65,10589,38161,17664,23669,34132,33,256,54561,13325,63068]

theorem envBound45532 : H12AffineFastState.Bounded env45532 := by
  intro p hp
  have h : env45532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45531_45532 : H12AffineEnvironment.transform 15 21591 env45531 = env45532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env45531 == env45532) = true)

theorem identity45532 : scanCanonicalize (H12AffineFastState.compose env45532 (packedSelected [0,3,4,5,7,10,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound45532 : packedSelected [0,3,4,5,7,10,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8203,46157,10280,1024,32769,4161,33,16,8542,8192,65,10589,38161,12636,10281,34132,33,256,41341,13325,33280]

theorem envBound45533 : H12AffineFastState.Bounded env45533 := by
  intro p hp
  have h : env45533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45532_45533 : H12AffineEnvironment.transform 13 13404 env45532 = env45533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env45532 == env45533) = true)

theorem identity45533 : scanCanonicalize (H12AffineFastState.compose env45533 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45533 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45534 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,32768,8203,46109,10280,1024,32769,4113,33,16,8462,8192,17,10509,38161,12556,10281,34052,33,256,41261,13325,33280]

theorem envBound45534 : H12AffineFastState.Bounded env45534 := by
  intro p hp
  have h : env45534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45533_45534 : H12AffineEnvironment.transform 5 16 env45533 = env45534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45533 == env45534) = true)

theorem identity45534 : scanCanonicalize (H12AffineFastState.compose env45534 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 14621) := by decide +kernel

theorem selectedBound45534 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env45535 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,14621,8203,3328,10280,1024,14620,4113,33,16,8462,8192,17,10509,11276,12556,10281,15385,33,256,6192,13325,15133]

theorem envBound45535 : H12AffineFastState.Bounded env45535 := by
  intro p hp
  have h : env45535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45534_45535 : H12AffineEnvironment.transform 14 14621 env45534 = env45535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14621 env45534 == env45535) = true)

theorem identity45535 : scanCanonicalize (H12AffineFastState.compose env45535 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 3841) := by decide +kernel

theorem selectedBound45535 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env45536 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3841,8192,11021,9756,8203,3328,10280,1024,9757,3856,33,16,8462,8192,17,10509,11276,11789,10281,8984,33,256,1841,11020,9244]

theorem envBound45536 : H12AffineFastState.Bounded env45536 := by
  intro p hp
  have h : env45536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45535_45536 : H12AffineEnvironment.transform 11 3841 env45535 = env45536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3841 env45535 == env45536) = true)

theorem identity45536 : scanCanonicalize (H12AffineFastState.compose env45536 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound45536 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env45537 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,512,8192,9740,9756,8203,1,9513,1024,9757,529,33,16,8462,8192,17,9228,8461,8972,9512,8984,33,256,1841,9741,9244]

theorem envBound45537 : H12AffineFastState.Bounded env45537 := by
  intro p hp
  have h : env45537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45536_45537 : H12AffineEnvironment.transform 10 1281 env45536 = env45537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env45536 == env45537) = true)

theorem identity45537 : scanCanonicalize (H12AffineFastState.compose env45537 (packedSelected [2,4,5,7,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45537 : packedSelected [2,4,5,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env45538 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,512,268,1792,1808,263,1,1061,1024,1809,529,33,16,2,268,17,1280,1,512,1060,532,33,256,1841,1793,1296]

theorem envBound45538 : H12AffineFastState.Bounded env45538 := by
  intro p hp
  have h : env45538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45537_45538 : H12AffineEnvironment.transform 12 268 env45537 = env45538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45537 == env45538) = true)

theorem identity45538 : scanCanonicalize (H12AffineFastState.compose env45538 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound45538 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45539 : List Nat := [2,4,8,16,32,16,8,256,512,564,821,512,268,308,292,263,1,529,564,293,529,33,16,2,268,17,820,1,512,528,532,33,256,261,309,804]

theorem envBound45539 : H12AffineFastState.Bounded env45539 := by
  intro p hp
  have h : env45539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45538_45539 : H12AffineEnvironment.transform 9 564 env45538 = env45539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env45538 == env45539) = true)

def env45540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180273,16,21762,8193,65,171281,115015,17664,67618,119043,254011,256,98679,90202,63069]

theorem envBound45540 : H12AffineFastState.Bounded env45540 := by
  intro p hp
  have h : env45540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45529_45540 : H12AffineEnvironment.transform 6 9 env45529 = env45540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45529 == env45540) = true)

theorem identity45540 : scanCanonicalize (H12AffineFastState.compose env45540 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound45540 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,35189,1024,32769,4161,98678,16,21762,8193,65,121942,115015,17664,67618,119043,41340,256,98679,90202,63069]

theorem envBound45541 : H12AffineFastState.Bounded env45541 := by
  intro p hp
  have h : env45541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45540_45541 : H12AffineEnvironment.transform 16 82247 env45540 = env45541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env45540 == env45541) = true)

theorem identity45541 : scanCanonicalize (H12AffineFastState.compose env45541 (packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound45541 : packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env45542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8313,65536,82247,10508,1024,8312,4161,73999,16,21762,8193,65,97327,90430,17664,67618,94586,261,256,73998,90202,22052]

theorem envBound45542 : H12AffineFastState.Bounded env45542 := by
  intro p hp
  have h : env45542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45541_45542 : H12AffineEnvironment.transform 14 8313 env45541 = env45542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env45541 == env45542) = true)

theorem identity45542 : scanCanonicalize (H12AffineFastState.compose env45542 (packedSelected [0,1,2,3,4,7,8,10,11,12,14,15,19,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45542 : packedSelected [0,1,2,3,4,7,8,10,11,12,14,15,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8313,65536,70727,10508,1024,8312,4161,73999,16,2,8193,65,76079,78910,4096,67618,74874,261,256,73998,79194,804]

theorem envBound45543 : H12AffineFastState.Bounded env45543 := by
  intro p hp
  have h : env45543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45542_45543 : H12AffineEnvironment.transform 13 5376 env45542 = env45543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45542 == env45543) = true)

theorem identity45543 : scanCanonicalize (H12AffineFastState.compose env45543 (packedSelected [0,1,2,7,8,10,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45543 : packedSelected [0,1,2,7,8,10,15,18] rootPS < 2^1333 := by decide +kernel

def env45544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,80,65536,70727,2341,1024,81,4161,65830,16,2,40,65,67846,70679,4096,67618,66643,261,256,65831,71027,804]

theorem envBound45544 : H12AffineFastState.Bounded env45544 := by
  intro p hp
  have h : env45544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45543_45544 : H12AffineEnvironment.transform 12 41 env45543 = env45544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45543 == env45544) = true)

theorem identity45544 : scanCanonicalize (H12AffineFastState.compose env45544 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45544 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env45545 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5157,80,65536,70727,2048,1024,81,4161,65539,16,2,40,65,67619,70679,4096,67618,66643,32,37,65538,70742,513]

theorem envBound45545 : H12AffineFastState.Bounded env45545 := by
  intro p hp
  have h : env45545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45544_45545 : H12AffineEnvironment.transform 7 37 env45544 = env45545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45544 == env45545) = true)

theorem identity45545 : scanCanonicalize (H12AffineFastState.compose env45545 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45545 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45546 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,65536,70678,2048,1024,0,4112,65539,16,2,40,16,67619,70679,4096,67618,66562,32,37,65538,70663,513]

theorem envBound45546 : H12AffineFastState.Bounded env45546 := by
  intro p hp
  have h : env45546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45545_45546 : H12AffineEnvironment.transform 5 17 env45545 = env45546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45545 == env45546) = true)

theorem identity45546 : scanCanonicalize (H12AffineFastState.compose env45546 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound45546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45547 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,35,5173,2048,1024,0,4112,32,16,2,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound45547 : H12AffineFastState.Bounded env45547 := by
  intro p hp
  have h : env45547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45546_45547 : H12AffineEnvironment.transform 15 35 env45546 = env45547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env45546 == env45547) = true)

theorem identity45547 : scanCanonicalize (H12AffineFastState.compose env45547 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45548 : List Nat := [2,4,8,1,32,0,9,37,512,1024,2048,4096,41,5157,1,35,5156,2048,1024,0,4097,32,1,2,40,1,2048,5157,4096,2049,1057,32,37,33,5156,513]

theorem envBound45548 : H12AffineFastState.Bounded env45548 := by
  intro p hp
  have h : env45548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45547_45548 : H12AffineEnvironment.transform 3 1 env45547 = env45548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45547 == env45548) = true)

theorem identity45548 : scanCanonicalize (H12AffineFastState.compose env45548 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound45548 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45549 : List Nat := [2,4,8,1,32,0,9,37,512,1024,2048,3119,41,2058,1,35,2059,2048,1024,0,3118,32,1,2,40,1,2048,2058,3119,2049,1057,32,37,33,2059,513]

theorem envBound45549 : H12AffineFastState.Bounded env45549 := by
  intro p hp
  have h : env45549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45548_45549 : H12AffineEnvironment.transform 11 3119 env45548 = env45549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env45548 == env45549) = true)

theorem identity45549 : scanCanonicalize (H12AffineFastState.compose env45549 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound45549 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45550 : List Nat := [2,4,8,1,32,0,9,37,512,1024,1028,43,41,1038,1,35,1039,1028,1024,0,42,32,1,2,40,1,1028,1038,43,1029,1057,32,37,33,1039,513]

theorem envBound45550 : H12AffineFastState.Bounded env45550 := by
  intro p hp
  have h : env45550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45549_45550 : H12AffineEnvironment.transform 10 1028 env45549 = env45550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env45549 == env45550) = true)

def env45551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509986,498993,8328,65,349611,2496956,2596211,67618,119042,2373705,256,2199998,2191386,63189]

theorem envBound45551 : H12AffineFastState.Bounded env45551 := by
  intro p hp
  have h : env45551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45500_45551 : H12AffineEnvironment.transform 23 498993 env45500 = env45551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env45500 == env45551) = true)

def env45552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509986,498993,8328,65,349611,395772,494899,67618,119042,272393,256,98814,90202,63189]

theorem envBound45552 : H12AffineFastState.Bounded env45552 := by
  intro p hp
  have h : env45552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45551_45552 : H12AffineEnvironment.transform 20 4160 env45551 = env45552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45551 == env45552) = true)

theorem identity45552 : scanCanonicalize (H12AffineFastState.compose env45552 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound45552 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4160,180408,62660,41431,8328,65,158029,79130,45525,67618,119042,201967,256,98814,90202,63189]

theorem envBound45553 : H12AffineFastState.Bounded env45553 := by
  intro p hp
  have h : env45553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45552_45553 : H12AffineEnvironment.transform 17 212198 env45552 = env45553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env45552 == env45553) = true)

theorem identity45553 : scanCanonicalize (H12AffineFastState.compose env45553 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound45553 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212198,1024,29909,4160,144492,16,21763,8328,65,158029,79130,17665,67618,75222,201967,256,95530,90202,513]

theorem envBound45554 : H12AffineFastState.Bounded env45554 := by
  intro p hp
  have h : env45554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45553_45554 : H12AffineEnvironment.transform 14 29908 env45553 = env45554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env45553 == env45554) = true)

theorem identity45554 : scanCanonicalize (H12AffineFastState.compose env45554 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound45554 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env45555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79250,2420,1024,29909,4160,66046,16,21763,8328,65,89311,79130,17665,67618,75222,8573,256,95530,90202,513]

theorem envBound45555 : H12AffineFastState.Bounded env45555 := by
  intro p hp
  have h : env45555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45554_45555 : H12AffineEnvironment.transform 16 79250 env45554 = env45555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env45554 == env45555) = true)

theorem identity45555 : scanCanonicalize (H12AffineFastState.compose env45555 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45555 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env45556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,65536,70862,2420,1024,21897,4160,66046,16,21763,468,65,89311,70726,17665,67618,66698,33,256,87158,82182,513]

theorem envBound45556 : H12AffineFastState.Bounded env45556 := by
  intro p hp
  have h : env45556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45555_45556 : H12AffineEnvironment.transform 12 348 env45555 = env45556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45555 == env45556) = true)

theorem identity45556 : scanCanonicalize (H12AffineFastState.compose env45556 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound45556 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env45557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,21726,16400,2420,1024,21897,4160,21792,16,21763,468,65,2049,16536,17665,23804,20564,33,256,168,5592,513]

theorem envBound45557 : H12AffineFastState.Bounded env45557 := by
  intro p hp
  have h : env45557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45556_45557 : H12AffineEnvironment.transform 15 21726 env45556 = env45557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env45556 == env45557) = true)

theorem identity45557 : scanCanonicalize (H12AffineFastState.compose env45557 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound45557 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5592,80,262,5576,2420,1024,81,4160,248,16,219,468,65,2049,5440,4313,2340,1420,33,256,168,5592,513]

theorem envBound45558 : H12AffineFastState.Bounded env45558 := by
  intro p hp
  have h : env45558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45557_45558 : H12AffineEnvironment.transform 13 5592 env45557 = env45558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env45557 == env45558) = true)

theorem identity45558 : scanCanonicalize (H12AffineFastState.compose env45558 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45558 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45559 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,0,262,5528,2340,1024,1,4112,168,16,139,388,17,2049,5392,4233,2340,1420,33,256,168,5512,513]

theorem envBound45559 : H12AffineFastState.Bounded env45559 := by
  intro p hp
  have h : env45559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45558_45559 : H12AffineEnvironment.transform 5 16 env45558 = env45559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45558 == env45559) = true)

theorem identity45559 : scanCanonicalize (H12AffineFastState.compose env45559 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound45559 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45560 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1442,4096,268,5512,0,262,5528,1158,1024,1,4112,168,16,139,388,17,1443,5392,4233,1158,1420,33,256,168,5512,513]

theorem envBound45560 : H12AffineFastState.Bounded env45560 := by
  intro p hp
  have h : env45560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45559_45560 : H12AffineEnvironment.transform 10 1442 env45559 = env45560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env45559 == env45560) = true)

theorem identity45560 : scanCanonicalize (H12AffineFastState.compose env45560 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45560 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45561 : List Nat := [2,4,8,16,32,16,128,256,512,53,407,4096,268,4541,0,262,4525,179,53,1,4112,168,16,139,388,17,406,4389,4233,179,441,33,256,168,4541,513]

theorem envBound45561 : H12AffineFastState.Bounded env45561 := by
  intro p hp
  have h : env45561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45560_45561 : H12AffineEnvironment.transform 9 53 env45560 = env45561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45560 == env45561) = true)

theorem identity45561 : scanCanonicalize (H12AffineFastState.compose env45561 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 169) := by decide +kernel

theorem selectedBound45561 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45562 : List Nat := [2,4,8,16,32,16,128,256,512,53,407,169,268,276,0,262,260,179,53,1,185,168,16,139,388,17,406,396,32,179,441,33,256,168,276,513]

theorem envBound45562 : H12AffineFastState.Bounded env45562 := by
  intro p hp
  have h : env45562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45561_45562 : H12AffineEnvironment.transform 11 169 env45561 = env45562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 169 env45561 == env45562) = true)

theorem identity45562 : scanCanonicalize (H12AffineFastState.compose env45562 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45562 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45563 : List Nat := [2,4,8,10,32,10,128,256,512,47,397,169,268,270,0,262,260,169,47,1,163,168,10,139,388,11,396,396,32,169,419,33,256,168,270,513]

theorem envBound45563 : H12AffineFastState.Bounded env45563 := by
  intro p hp
  have h : env45563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45562_45563 : H12AffineEnvironment.transform 3 10 env45562 = env45563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45562 == env45563) = true)

theorem identity45563 : scanCanonicalize (H12AffineFastState.compose env45563 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45563 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env45564 : List Nat := [2,4,2,0,32,0,128,256,512,37,391,163,262,260,0,262,260,163,37,1,163,162,0,129,388,1,390,390,32,163,419,33,256,162,260,513]

theorem envBound45564 : H12AffineFastState.Bounded env45564 := by
  intro p hp
  have h : env45564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45563_45564 : H12AffineEnvironment.transform 2 2 env45563 = env45564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45563 == env45564) = true)

theorem identity45564 : scanCanonicalize (H12AffineFastState.compose env45564 (packedSelected [0,2,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound45564 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env45565 : List Nat := [2,4,2,0,32,0,2,256,512,37,261,33,262,260,0,262,260,33,37,1,33,32,0,3,262,1,260,260,32,33,289,33,256,32,260,513]

theorem envBound45565 : H12AffineFastState.Bounded env45565 := by
  intro p hp
  have h : env45565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45564_45565 : H12AffineEnvironment.transform 6 2 env45564 = env45565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env45564 == env45565) = true)

theorem identity45565 : scanCanonicalize (H12AffineFastState.compose env45565 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound45565 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45566 : List Nat := [2,4,2,0,32,0,2,256,6,37,261,33,262,260,0,262,260,33,37,1,33,32,0,3,262,1,260,260,32,33,289,33,256,32,260,7]

theorem envBound45566 : H12AffineFastState.Bounded env45566 := by
  intro p hp
  have h : env45566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45565_45566 : H12AffineEnvironment.transform 8 6 env45565 = env45566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env45565 == env45566) = true)

def env45567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509986,498993,8328,65,349611,395773,494898,67618,119042,272392,256,98815,90203,63189]

theorem envBound45567 : H12AffineFastState.Bounded env45567 := by
  intro p hp
  have h : env45567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45551_45567 : H12AffineEnvironment.transform 20 4161 env45551 = env45567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45551 == env45567) = true)

theorem identity45567 : scanCanonicalize (H12AffineFastState.compose env45567 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound45567 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,180408,400636,412143,8328,65,295285,395773,416236,56572,1500,272392,256,21793,46213,63189]

theorem envBound45568 : H12AffineFastState.Bounded env45568 := by
  intro p hp
  have h : env45568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45567_45568 : H12AffineEnvironment.transform 15 54494 env45567 = env45568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env45567 == env45568) = true)

def env45569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180272,400500,412007,8192,65,295285,395637,416100,56436,1364,272392,256,21793,46093,63069]

theorem envBound45569 : H12AffineFastState.Bounded env45569 := by
  intro p hp
  have h : env45569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45568_45569 : H12AffineEnvironment.transform 6 8 env45568 = env45569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45568 == env45569) = true)

theorem identity45569 : scanCanonicalize (H12AffineFastState.compose env45569 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound45569 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env45570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,131072,262144,1024,21760,4161,136497,400500,412007,8192,65,283764,395637,416100,2421,1364,272392,256,21793,24844,9052]

theorem envBound45570 : H12AffineFastState.Bounded env45570 := by
  intro p hp
  have h : env45570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45569_45570 : H12AffineEnvironment.transform 14 21761 env45569 = env45570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env45569 == env45570) = true)

theorem identity45570 : scanCanonicalize (H12AffineFastState.compose env45570 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound45570 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,131072,146745,1024,21760,4161,136497,8525,29790,8192,65,158029,13388,25693,2421,1364,136497,256,21793,24844,9052]

theorem envBound45571 : H12AffineFastState.Bounded env45571 := by
  intro p hp
  have h : env45571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45570_45571 : H12AffineEnvironment.transform 17 146745 env45570 = env45571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env45570 == env45571) = true)

theorem identity45571 : scanCanonicalize (H12AffineFastState.compose env45571 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound45571 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env45572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,24909,23668,1024,21760,4161,29820,8525,29790,8192,65,2048,13388,25693,2421,1364,29820,256,21793,24844,9052]

theorem envBound45572 : H12AffineFastState.Bounded env45572 := by
  intro p hp
  have h : env45572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45571_45572 : H12AffineEnvironment.transform 16 24909 env45571 = env45572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env45571 == env45572) = true)

theorem identity45572 : scanCanonicalize (H12AffineFastState.compose env45572 (packedSelected [6,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound45572 : packedSelected [6,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env45573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8233,343,5221,10588,1024,8232,4161,340,8525,374,8192,65,2048,13388,4469,2421,1364,340,256,8201,5156,9052]

theorem envBound45573 : H12AffineFastState.Bounded env45573 := by
  intro p hp
  have h : env45573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45572_45573 : H12AffineEnvironment.transform 13 13608 env45572 = env45573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env45572 == env45573) = true)

theorem identity45573 : scanCanonicalize (H12AffineFastState.compose env45573 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45573 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45574 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,8233,34,5221,10281,1024,8232,4161,33,8248,3,8192,65,2048,13388,4096,2048,1057,33,117,8201,5156,8745]

theorem envBound45574 : H12AffineFastState.Bounded env45574 := by
  intro p hp
  have h : env45574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45573_45574 : H12AffineEnvironment.transform 7 117 env45573 = env45574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45573 == env45574) = true)

theorem identity45574 : scanCanonicalize (H12AffineFastState.compose env45574 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound45574 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45575 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1100,4113,1125,34,5221,3173,1024,1124,4161,33,1140,3,1100,65,2048,4096,4096,2048,1057,33,117,1093,5156,1637]

theorem envBound45575 : H12AffineFastState.Bounded env45575 := by
  intro p hp
  have h : env45575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45574_45575 : H12AffineEnvironment.transform 12 1100 env45574 = env45575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env45574 == env45575) = true)

theorem identity45575 : scanCanonicalize (H12AffineFastState.compose env45575 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound45575 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env45576 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,41,4113,0,34,4096,2048,101,1,4161,33,17,3,41,65,2048,4096,4096,2048,68,33,117,32,4161,512]

theorem envBound45576 : H12AffineFastState.Bounded env45576 := by
  intro p hp
  have h : env45576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45575_45576 : H12AffineEnvironment.transform 9 101 env45575 = env45576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env45575 == env45576) = true)

theorem identity45576 : scanCanonicalize (H12AffineFastState.compose env45576 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45576 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45577 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,0,34,4096,2048,53,1,4113,33,17,3,41,17,2048,4096,4096,2048,20,33,37,32,4113,512]

theorem envBound45577 : H12AffineFastState.Bounded env45577 := by
  intro p hp
  have h : env45577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45576_45577 : H12AffineEnvironment.transform 5 16 env45576 = env45577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45576 == env45577) = true)

theorem identity45577 : scanCanonicalize (H12AffineFastState.compose env45577 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound45577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45578 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2065,41,2048,0,34,2065,2048,53,1,2048,33,17,3,41,17,2048,2065,2065,2048,20,33,37,32,2048,512]

theorem envBound45578 : H12AffineFastState.Bounded env45578 := by
  intro p hp
  have h : env45578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45577_45578 : H12AffineEnvironment.transform 11 2065 env45577 = env45578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env45577 == env45578) = true)

theorem identity45578 : scanCanonicalize (H12AffineFastState.compose env45578 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound45578 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45579 : List Nat := [2,4,8,16,14,16,8,11,512,27,2048,2065,7,2048,0,12,2065,2048,27,1,2048,15,17,3,7,17,2048,2065,2065,2048,20,15,11,14,2048,512]

theorem envBound45579 : H12AffineFastState.Bounded env45579 := by
  intro p hp
  have h : env45579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45578_45579 : H12AffineEnvironment.transform 4 14 env45578 = env45579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env45578 == env45579) = true)

theorem identity45579 : scanCanonicalize (H12AffineFastState.compose env45579 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound45579 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45580 : List Nat := [2,4,7,16,1,16,7,4,512,20,2048,2065,7,2048,0,3,2065,2048,20,1,2048,0,17,3,7,17,2048,2065,2065,2048,20,0,4,1,2048,512]

theorem envBound45580 : H12AffineFastState.Bounded env45580 := by
  intro p hp
  have h : env45580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45579_45580 : H12AffineEnvironment.transform 2 7 env45579 = env45580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env45579 == env45580) = true)

theorem identity45580 : scanCanonicalize (H12AffineFastState.compose env45580 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound45580 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45581 : List Nat := [2,4,7,16,1,16,7,4,512,20,512,529,7,512,0,3,529,512,20,1,512,0,17,3,7,17,512,529,529,512,20,0,4,1,512,512]

theorem envBound45581 : H12AffineFastState.Bounded env45581 := by
  intro p hp
  have h : env45581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45580_45581 : H12AffineEnvironment.transform 10 512 env45580 = env45581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env45580 == env45581) = true)

theorem identity45581 : scanCanonicalize (H12AffineFastState.compose env45581 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45581 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45582 : List Nat := [2,4,7,1,1,1,7,4,512,5,512,512,7,512,0,3,512,512,5,1,512,0,0,3,7,0,512,512,512,512,5,0,4,1,512,512]

theorem envBound45582 : H12AffineFastState.Bounded env45582 := by
  intro p hp
  have h : env45582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45581_45582 : H12AffineEnvironment.transform 3 1 env45581 = env45582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45581 == env45582) = true)

def env45583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180273,400501,412006,8193,65,295285,395636,416101,56437,1365,272392,256,21793,46092,63068]

theorem envBound45583 : H12AffineFastState.Bounded env45583 := by
  intro p hp
  have h : env45583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45568_45583 : H12AffineEnvironment.transform 6 9 env45568 = env45583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45568 == env45583) = true)

theorem identity45583 : scanCanonicalize (H12AffineFastState.compose env45583 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound45583 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env45584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16692,262144,1024,32769,4161,33029,286017,264274,8193,65,295285,280640,268369,56437,1365,272392,256,21793,46092,63068]

theorem envBound45584 : H12AffineFastState.Bounded env45584 := by
  intro p hp
  have h : env45584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45583_45584 : H12AffineEnvironment.transform 16 16692 env45583 = env45584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env45583 == env45584) = true)

theorem identity45584 : scanCanonicalize (H12AffineFastState.compose env45584 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound45584 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env45585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30042,16692,262144,1024,8460,4161,8200,286017,264274,8193,65,270456,280640,268369,32120,1365,272392,256,21793,5377,22353]

theorem envBound45585 : H12AffineFastState.Bounded env45585 := by
  intro p hp
  have h : env45585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45584_45585 : H12AffineEnvironment.transform 14 8461 env45584 = env45585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env45584 == env45585) = true)

theorem identity45585 : scanCanonicalize (H12AffineFastState.compose env45585 (packedSelected [1,3,8,10,12,15,18,19,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45585 : packedSelected [1,3,8,10,12,15,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,8283,5173,262144,1024,8460,4161,8200,264256,264274,8193,65,270456,269633,268369,10361,1365,272392,256,32,5377,592]

theorem envBound45586 : H12AffineFastState.Bounded env45586 := by
  intro p hp
  have h : env45586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45585_45586 : H12AffineEnvironment.transform 13 5377 env45585 = env45586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45585 == env45586) = true)

theorem identity45586 : scanCanonicalize (H12AffineFastState.compose env45586 (packedSelected [0,2,4,6,7,9,11,14,16,17,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound45586 : packedSelected [0,2,4,6,7,9,11,14,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,8283,5173,10508,1024,8460,4161,8200,8524,8542,8193,65,2420,13389,12637,10361,1365,260,256,32,5377,592]

theorem envBound45587 : H12AffineFastState.Bounded env45587 := by
  intro p hp
  have h : env45587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45586_45587 : H12AffineEnvironment.transform 17 10508 env45586 = env45587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env45586 == env45587) = true)

theorem identity45587 : scanCanonicalize (H12AffineFastState.compose env45587 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45587 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env45588 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,8232,8283,5173,10281,1024,8233,4161,8200,8297,8315,8193,65,2129,13389,12408,10361,1136,33,37,32,5156,592]

theorem envBound45588 : H12AffineFastState.Bounded env45588 := by
  intro p hp
  have h : env45588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45587_45588 : H12AffineEnvironment.transform 7 37 env45587 = env45588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45587 == env45588) = true)

theorem identity45588 : scanCanonicalize (H12AffineFastState.compose env45588 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound45588 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45589 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1100,5156,1124,1047,5173,3173,1024,1125,4161,1092,1061,1079,1101,65,2129,4097,5172,3125,1136,33,37,32,5156,592]

theorem envBound45589 : H12AffineFastState.Bounded env45589 := by
  intro p hp
  have h : env45589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45588_45589 : H12AffineEnvironment.transform 12 1100 env45588 = env45589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env45588 == env45589) = true)

theorem identity45589 : scanCanonicalize (H12AffineFastState.compose env45589 (packedSelected [2,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45589 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env45590 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,4096,40,4160,0,115,4177,2049,100,1,4161,32,65,83,41,65,2129,4097,4176,2129,20,33,37,32,4160,592]

theorem envBound45590 : H12AffineFastState.Bounded env45590 := by
  intro p hp
  have h : env45590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45589_45590 : H12AffineEnvironment.transform 9 100 env45589 = env45590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45589 == env45590) = true)

theorem identity45590 : scanCanonicalize (H12AffineFastState.compose env45590 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound45590 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env45591 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,65,40,1,0,115,16,2049,100,1,0,32,65,83,41,65,2129,64,17,2129,20,33,37,32,1,592]

theorem envBound45591 : H12AffineFastState.Bounded env45591 := by
  intro p hp
  have h : env45591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45590_45591 : H12AffineEnvironment.transform 11 65 env45590 = env45591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env45590 == env45591) = true)

theorem identity45591 : scanCanonicalize (H12AffineFastState.compose env45591 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45592 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,16,40,1,0,34,16,2049,53,1,0,32,16,2,41,16,2048,17,17,2048,20,33,37,32,1,513]

theorem envBound45592 : H12AffineFastState.Bounded env45592 := by
  intro p hp
  have h : env45592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45591_45592 : H12AffineEnvironment.transform 5 17 env45591 = env45592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45591 == env45592) = true)

theorem identity45592 : scanCanonicalize (H12AffineFastState.compose env45592 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound45592 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45593 : List Nat := [2,4,8,16,32,17,9,37,512,53,32,16,40,1,0,34,16,33,53,1,0,32,16,2,41,16,32,17,17,32,20,33,37,32,1,513]

theorem envBound45593 : H12AffineFastState.Bounded env45593 := by
  intro p hp
  have h : env45593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45592_45593 : H12AffineEnvironment.transform 10 32 env45592 = env45593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env45592 == env45593) = true)

theorem identity45593 : scanCanonicalize (H12AffineFastState.compose env45593 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45593 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45594 : List Nat := [2,4,8,1,32,0,9,37,512,36,32,1,40,1,0,34,1,33,36,1,0,32,1,2,41,1,32,0,0,32,5,33,37,32,1,513]

theorem envBound45594 : H12AffineFastState.Bounded env45594 := by
  intro p hp
  have h : env45594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45593_45594 : H12AffineEnvironment.transform 3 1 env45593 = env45594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45593 == env45594) = true)

def env45595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509986,16777216,8328,65,16959643,18973837,2596211,67618,17189939,19113337,256,19270799,19328299,17263588]

theorem envBound45595 : H12AffineFastState.Bounded env45595 := by
  intro p hp
  have h : env45595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45499_45595 : H12AffineEnvironment.transform 21 180409 env45499 = env45595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env45499 == env45595) = true)

def env45596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509986,498992,8328,65,349611,2496957,2596211,67618,119043,2373705,256,2199999,2191387,63188]

theorem envBound45596 : H12AffineFastState.Bounded env45596 := by
  intro p hp
  have h : env45596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45595_45596 : H12AffineEnvironment.transform 23 498992 env45595 = env45596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env45595 == env45596) = true)

def env45597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509986,498992,8328,65,349611,395773,494899,67618,119043,272393,256,98815,90203,63188]

theorem envBound45597 : H12AffineFastState.Bounded env45597 := by
  intro p hp
  have h : env45597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45596_45597 : H12AffineEnvironment.transform 20 4160 env45596 = env45597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45596 == env45597) = true)

theorem identity45597 : scanCanonicalize (H12AffineFastState.compose env45597 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound45597 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180409,73754,95496,8328,65,245139,57797,91403,67618,119043,180273,256,98815,90203,63188]

theorem envBound45598 : H12AffineFastState.Bounded env45598 := by
  intro p hp
  have h : env45598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45597_45598 : H12AffineEnvironment.transform 17 190520 env45597 = env45598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env45597 == env45598) = true)

def env45599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10400,1024,32769,4160,33,73754,95496,8328,65,97547,57797,91403,67618,119043,169,256,98815,90203,63188]

theorem envBound45599 : H12AffineFastState.Bounded env45599 := by
  intro p hp
  have h : env45599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45598_45599 : H12AffineEnvironment.transform 16 49304 env45598 = env45599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env45598 == env45599) = true)

theorem identity45599 : scanCanonicalize (H12AffineFastState.compose env45599 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45599 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env45600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49304,10400,1024,32769,4160,33,16,21762,8328,65,23809,57797,17665,10280,61705,169,256,41461,16465,63188]

theorem envBound45600 : H12AffineFastState.Bounded env45600 := by
  intro p hp
  have h : env45600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45599_45600 : H12AffineEnvironment.transform 15 8202 env45599 = env45600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45599 == env45600) = true)

theorem identity45600 : scanCanonicalize (H12AffineFastState.compose env45600 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45600 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env45601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8202,38296,10400,1024,32769,4160,33,16,2,8328,65,2049,46277,4097,10280,41993,169,256,41461,5457,41940]

theorem envBound45601 : H12AffineFastState.Bounded env45601 := by
  intro p hp
  have h : env45601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45600_45601 : H12AffineEnvironment.transform 13 5376 env45600 = env45601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45600 == env45601) = true)

theorem identity45601 : scanCanonicalize (H12AffineFastState.compose env45601 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8692) := by decide +kernel

theorem selectedBound45601 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env45602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8692,8202,13420,10400,1024,8693,4160,33,16,2,8328,65,2049,5425,4097,10280,1533,169,256,1,5457,544]

theorem envBound45602 : H12AffineFastState.Bounded env45602 := by
  intro p hp
  have h : env45602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45601_45602 : H12AffineEnvironment.transform 14 8692 env45601 = env45602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env45601 == env45602) = true)

theorem identity45602 : scanCanonicalize (H12AffineFastState.compose env45602 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 500) := by decide +kernel

theorem selectedBound45602 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env45603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,500,5376,0,510,5528,2388,1024,1,4160,33,16,2,380,65,2049,5425,4097,2524,1533,169,256,1,5457,544]

theorem envBound45603 : H12AffineFastState.Bounded env45603 := by
  intro p hp
  have h : env45603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45602_45603 : H12AffineEnvironment.transform 12 500 env45602 = env45603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 500 env45602 == env45603) = true)

theorem identity45603 : scanCanonicalize (H12AffineFastState.compose env45603 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound45603 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env45604 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,300,5376,0,294,5440,2388,1024,1,4160,33,16,2,380,65,2049,5425,4097,2308,1317,113,256,1,5457,544]

theorem envBound45604 : H12AffineFastState.Bounded env45604 := by
  intro p hp
  have h : env45604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45603_45604 : H12AffineEnvironment.transform 6 88 env45603 = env45604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45603 == env45604) = true)

theorem identity45604 : scanCanonicalize (H12AffineFastState.compose env45604 (packedSelected [1,3,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound45604 : packedSelected [1,3,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env45605 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2609,300,3889,0,294,3953,2388,1024,1,2673,33,16,2,380,65,2049,3840,2608,2308,1317,113,256,1,3936,544]

theorem envBound45605 : H12AffineFastState.Bounded env45605 := by
  intro p hp
  have h : env45605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45604_45605 : H12AffineEnvironment.transform 11 2609 env45604 = env45605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env45604 == env45605) = true)

theorem identity45605 : scanCanonicalize (H12AffineFastState.compose env45605 (packedSelected [1,3,4,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1360) := by decide +kernel

theorem selectedBound45605 : packedSelected [1,3,4,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env45606 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1360,1889,300,609,0,294,545,1028,1024,1,1825,33,16,2,380,65,1361,592,1888,1108,1317,113,256,1,560,544]

theorem envBound45606 : H12AffineFastState.Bounded env45606 := by
  intro p hp
  have h : env45606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45605_45606 : H12AffineEnvironment.transform 10 1360 env45605 = env45606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1360 env45605 == env45606) = true)

theorem identity45606 : scanCanonicalize (H12AffineFastState.compose env45606 (packedSelected [1,2,6,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound45606 : packedSelected [1,2,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45607 : List Nat := [2,4,8,16,32,64,88,100,512,1024,1076,1541,72,609,0,66,545,1028,1024,1,1605,33,16,2,24,65,1077,592,1540,1108,1089,113,100,1,560,544]

theorem envBound45607 : H12AffineFastState.Bounded env45607 := by
  intro p hp
  have h : env45607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45606_45607 : H12AffineEnvironment.transform 7 100 env45606 = env45607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env45606 == env45607) = true)

theorem identity45607 : scanCanonicalize (H12AffineFastState.compose env45607 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound45607 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env45608 : List Nat := [2,4,8,16,32,64,88,100,512,84,96,593,72,609,0,66,545,80,84,1,529,33,16,2,24,65,97,592,592,0,21,113,100,1,560,544]

theorem envBound45608 : H12AffineFastState.Bounded env45608 := by
  intro p hp
  have h : env45608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45607_45608 : H12AffineEnvironment.transform 9 84 env45607 = env45608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env45607 == env45608) = true)

theorem identity45608 : scanCanonicalize (H12AffineFastState.compose env45608 (packedSelected [1,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound45608 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env45609 : List Nat := [2,4,8,16,32,64,88,100,49,84,96,96,72,80,0,66,16,80,84,1,32,33,16,2,24,65,97,97,97,0,21,113,100,1,1,17]

theorem envBound45609 : H12AffineFastState.Bounded env45609 := by
  intro p hp
  have h : env45609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45608_45609 : H12AffineEnvironment.transform 8 49 env45608 = env45609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env45608 == env45609) = true)

theorem identity45609 : scanCanonicalize (H12AffineFastState.compose env45609 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45609 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45610 : List Nat := [2,4,8,16,32,17,9,53,49,5,49,49,25,1,0,19,16,1,5,1,32,33,16,2,24,16,48,48,48,0,21,32,53,1,1,17]

theorem envBound45610 : H12AffineFastState.Bounded env45610 := by
  intro p hp
  have h : env45610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45609_45610 : H12AffineEnvironment.transform 5 17 env45609 = env45610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45609 == env45610) = true)

theorem identity45610 : scanCanonicalize (H12AffineFastState.compose env45610 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45610 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45611 : List Nat := [2,4,8,16,17,17,9,4,0,5,0,0,25,1,0,19,16,1,5,1,17,16,16,2,24,16,1,1,1,0,21,17,4,1,1,17]

theorem envBound45611 : H12AffineFastState.Bounded env45611 := by
  intro p hp
  have h : env45611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45610_45611 : H12AffineEnvironment.transform 4 17 env45610 = env45611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45610 == env45611) = true)

theorem identity45611 : scanCanonicalize (H12AffineFastState.compose env45611 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45611 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45612 : List Nat := [2,4,8,0,1,1,9,4,0,5,0,0,9,1,0,3,0,1,5,1,1,0,0,2,8,0,1,1,1,0,5,1,4,1,1,1]

theorem envBound45612 : H12AffineFastState.Bounded env45612 := by
  intro p hp
  have h : env45612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45611_45612 : H12AffineEnvironment.transform 3 0 env45611 = env45612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45611 == env45612) = true)

def env45613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10401,1024,32769,4160,32,73754,95496,8328,65,97546,57797,91403,67618,119043,168,256,98815,90203,63188]

theorem envBound45613 : H12AffineFastState.Bounded env45613 := by
  intro p hp
  have h : env45613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45598_45613 : H12AffineEnvironment.transform 16 49305 env45598 = env45613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env45598 == env45613) = true)

theorem identity45613 : scanCanonicalize (H12AffineFastState.compose env45613 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound45613 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env45614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29743,49305,10401,1024,32769,4160,32,21557,295,8328,65,2341,57797,4388,31757,42284,168,256,62928,5236,63188]

theorem envBound45614 : H12AffineFastState.Bounded env45614 := by
  intro p hp
  have h : env45614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45613_45614 : H12AffineEnvironment.transform 15 29743 env45613 = env45614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env45613 == env45614) = true)

theorem identity45614 : scanCanonicalize (H12AffineFastState.compose env45614 (packedSelected [3,4,5,9,11,12,14,15,20,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound45614 : packedSelected [3,4,5,9,11,12,14,15,20,31,32] rootPS < 2^1333 := by decide +kernel

def env45615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21540,29743,5309,10401,1024,21541,4160,32,21557,295,8328,65,2341,13793,4388,31757,28936,168,256,8692,5236,8944]

theorem envBound45615 : H12AffineFastState.Bounded env45615 := by
  intro p hp
  have h : env45615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45614_45615 : H12AffineEnvironment.transform 14 21540 env45614 = env45615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env45614 == env45615) = true)

theorem identity45615 : scanCanonicalize (H12AffineFastState.compose env45615 (packedSelected [2,6,9,11,14,17,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45615 : packedSelected [2,6,9,11,14,17,22,23] rootPS < 2^1333 := by decide +kernel

def env45616 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21540,29743,5309,10401,1024,21541,4112,32,21557,295,8328,17,2341,13745,4388,31757,28936,168,256,8612,5156,8864]

theorem envBound45616 : H12AffineFastState.Bounded env45616 := by
  intro p hp
  have h : env45616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45615_45616 : H12AffineEnvironment.transform 5 16 env45615 = env45616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45615 == env45616) = true)

theorem identity45616 : scanCanonicalize (H12AffineFastState.compose env45616 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound45616 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env45617 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8232,35,5309,10401,1024,8233,4112,32,8249,295,8328,17,2341,13745,4388,2049,1284,168,256,8612,5156,8864]

theorem envBound45617 : H12AffineFastState.Bounded env45617 := by
  intro p hp
  have h : env45617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45616_45617 : H12AffineEnvironment.transform 13 13324 env45616 = env45617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env45616 == env45617) = true)

theorem identity45617 : scanCanonicalize (H12AffineFastState.compose env45617 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45617 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45618 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,292,35,5309,2477,1024,293,4112,32,309,295,388,17,2341,5309,4388,2049,1284,168,256,168,5156,940]

theorem envBound45618 : H12AffineFastState.Bounded env45618 := by
  intro p hp
  have h : env45618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45617_45618 : H12AffineEnvironment.transform 12 268 env45617 = env45618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45617 == env45618) = true)

theorem identity45618 : scanCanonicalize (H12AffineFastState.compose env45618 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound45618 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env45619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1060,268,292,292,35,153,2477,1024,293,1076,32,309,295,388,17,2341,153,1280,2049,1284,168,256,168,0,940]

theorem envBound45619 : H12AffineFastState.Bounded env45619 := by
  intro p hp
  have h : env45619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45618_45619 : H12AffineEnvironment.transform 11 1060 env45618 = env45619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env45618 == env45619) = true)

theorem identity45619 : scanCanonicalize (H12AffineFastState.compose env45619 (packedSelected [1,3,5,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45619 : packedSelected [1,3,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env45620 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,1060,40,0,0,35,153,2185,1024,1,1076,32,17,3,160,17,2049,153,1060,2049,1056,168,36,168,0,648]

theorem envBound45620 : H12AffineFastState.Bounded env45620 := by
  intro p hp
  have h : env45620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45619_45620 : H12AffineEnvironment.transform 7 36 env45619 = env45620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45619 == env45620) = true)

theorem identity45620 : scanCanonicalize (H12AffineFastState.compose env45620 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound45620 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45621 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1077,1060,40,0,0,35,153,1212,1024,1,1076,32,17,3,160,17,1076,153,1060,1076,1056,168,36,168,0,648]

theorem envBound45621 : H12AffineFastState.Bounded env45621 := by
  intro p hp
  have h : env45621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45620_45621 : H12AffineEnvironment.transform 10 1077 env45620 = env45621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env45620 == env45621) = true)

theorem identity45621 : scanCanonicalize (H12AffineFastState.compose env45621 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45621 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45622 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,17,40,0,0,35,153,137,53,1,1,32,17,3,160,17,1,153,17,1,21,168,36,168,0,648]

theorem envBound45622 : H12AffineFastState.Bounded env45622 := by
  intro p hp
  have h : env45622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45621_45622 : H12AffineEnvironment.transform 9 53 env45621 = env45622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45621 == env45622) = true)

theorem identity45622 : scanCanonicalize (H12AffineFastState.compose env45622 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45622 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45623 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,40,0,0,35,17,1,53,1,1,32,17,3,40,17,1,17,17,1,21,32,36,32,0,512]

theorem envBound45623 : H12AffineFastState.Bounded env45623 := by
  intro p hp
  have h : env45623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45622_45623 : H12AffineEnvironment.transform 6 8 env45622 = env45623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45622 == env45623) = true)

theorem identity45623 : scanCanonicalize (H12AffineFastState.compose env45623 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45623 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45624 : List Nat := [2,4,8,0,32,0,8,36,512,37,0,1,40,0,0,35,1,1,37,1,1,32,1,3,40,1,1,1,1,1,5,32,36,32,0,512]

theorem envBound45624 : H12AffineFastState.Bounded env45624 := by
  intro p hp
  have h : env45624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1