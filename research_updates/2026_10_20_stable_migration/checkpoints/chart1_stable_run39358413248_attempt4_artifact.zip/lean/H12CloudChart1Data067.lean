import H12CloudChart1Data066

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity16883 : scanCanonicalize (H12AffineFastState.compose env16883 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16883 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10280,1025,8540,4160,112,17,2,8192,65,10508,5393,4097,2421,1364,112,257,32,5457,513]

theorem envBound16884 : H12AffineFastState.Bounded env16884 := by
  intro p hp
  have h : env16884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16883_16884 : H12AffineEnvironment.transform 13 5376 env16883 = env16884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16883 == env16884) = true)

theorem identity16884 : scanCanonicalize (H12AffineFastState.compose env16884 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16885 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,5393,10280,1025,8461,4113,33,17,2,8192,16,10508,5393,4097,2340,1285,33,257,32,5376,513]

theorem envBound16885 : H12AffineFastState.Bounded env16885 := by
  intro p hp
  have h : env16885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16884_16885 : H12AffineEnvironment.transform 5 17 env16884 = env16885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16884 == env16885) = true)

theorem identity16885 : scanCanonicalize (H12AffineFastState.compose env16885 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound16885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16886 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,8192,309,8460,8203,292,10280,1025,8461,1060,33,17,2,8192,16,10508,292,1076,2340,1285,33,257,32,309,513]

theorem envBound16886 : H12AffineFastState.Bounded env16886 := by
  intro p hp
  have h : env16886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16885_16886 : H12AffineEnvironment.transform 11 1077 env16885 = env16886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env16885 == env16886) = true)

theorem identity16886 : scanCanonicalize (H12AffineFastState.compose env16886 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound16886 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16887 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,2083,309,2351,2088,292,11,1025,2350,1060,33,17,2,2083,16,303,292,1076,2340,1285,33,257,32,309,513]

theorem envBound16887 : H12AffineFastState.Bounded env16887 := by
  intro p hp
  have h : env16887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16886_16887 : H12AffineEnvironment.transform 12 2083 env16886 = env16887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env16886 == env16887) = true)

theorem identity16887 : scanCanonicalize (H12AffineFastState.compose env16887 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound16887 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16888 : List Nat := [2,4,8,16,32,17,8,256,512,1024,303,1077,268,309,0,263,292,11,1025,1,1060,33,17,2,268,16,303,292,1076,11,1285,33,257,32,309,513]

theorem envBound16888 : H12AffineFastState.Bounded env16888 := by
  intro p hp
  have h : env16888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16887_16888 : H12AffineEnvironment.transform 10 303 env16887 = env16888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env16887 == env16888) = true)

def env16889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98645,8193,65,4340844,5393,17665,179513,1365,4256861,257,21792,46093,74250]

theorem envBound16889 : H12AffineFastState.Bounded env16889 := by
  intro p hp
  have h : env16889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16878_16889 : H12AffineEnvironment.transform 6 9 env16878 = env16889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16878 == env16889) = true)

theorem identity16889 : scanCanonicalize (H12AffineFastState.compose env16889 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound16889 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,32040,1025,32769,4160,4194304,17,3,8193,65,4340844,5393,17665,179513,1365,4256861,257,21792,46093,41820]

theorem envBound16890 : H12AffineFastState.Bounded env16890 := by
  intro p hp
  have h : env16890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16889_16890 : H12AffineEnvironment.transform 15 33110 env16889 = env16890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env16889 == env16890) = true)

theorem identity16890 : scanCanonicalize (H12AffineFastState.compose env16890 (packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16890 : packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env16891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32040,1025,8540,4160,4194304,17,3,8193,65,4340844,5393,17665,138340,1365,4216064,257,21792,5456,513]

theorem envBound16891 : H12AffineFastState.Bounded env16891 := by
  intro p hp
  have h : env16891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16890_16891 : H12AffineEnvironment.transform 14 8541 env16890 = env16891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16890 == env16891) = true)

theorem identity16891 : scanCanonicalize (H12AffineFastState.compose env16891 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16891 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,32040,1025,8540,4160,4194304,17,3,8193,65,4226172,5393,17665,23668,1365,4216064,257,21792,5456,513]

theorem envBound16892 : H12AffineFastState.Bounded env16892 := by
  intro p hp
  have h : env16892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16891_16892 : H12AffineEnvironment.transform 16 16400 env16891 = env16892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16891 == env16892) = true)

theorem identity16892 : scanCanonicalize (H12AffineFastState.compose env16892 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16892 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16893 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,8541,8203,16400,30777,272,8540,4160,4194304,17,3,8193,65,4225389,4096,16400,22885,68,4214801,257,20529,4161,513]

theorem envBound16893 : H12AffineFastState.Bounded env16893 := by
  intro p hp
  have h : env16893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16892_16893 : H12AffineEnvironment.transform 9 273 env16892 = env16893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16892 == env16893) = true)

theorem identity16893 : scanCanonicalize (H12AffineFastState.compose env16893 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound16893 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16894 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4452,8541,8203,4468,10589,272,8540,4160,4194304,17,3,8193,65,4204553,4096,4468,2049,68,4194677,257,341,4161,513]

theorem envBound16894 : H12AffineFastState.Bounded env16894 := by
  intro p hp
  have h : env16894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16893_16894 : H12AffineEnvironment.transform 13 4452 env16893 = env16894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env16893 == env16894) = true)

theorem identity16894 : scanCanonicalize (H12AffineFastState.compose env16894 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound16894 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env16895 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4452,8541,8203,4468,10589,272,8540,4160,33,17,3,8193,65,10280,4096,4468,2049,68,340,257,341,4161,513]

theorem envBound16895 : H12AffineFastState.Bounded env16895 := by
  intro p hp
  have h : env16895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16894_16895 : H12AffineEnvironment.transform 21 33 env16894 = env16895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env16894 == env16895) = true)

theorem identity16895 : scanCanonicalize (H12AffineFastState.compose env16895 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16895 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16896 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,8192,4161,8312,8203,4177,10360,53,8313,4160,33,17,3,8193,65,10280,4096,4177,2049,68,113,36,112,4161,513]

theorem envBound16896 : H12AffineFastState.Bounded env16896 := by
  intro p hp
  have h : env16896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16895_16896 : H12AffineEnvironment.transform 7 37 env16895 = env16896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16895 == env16896) = true)

theorem identity16896 : scanCanonicalize (H12AffineFastState.compose env16896 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound16896 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16897 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,6248,4161,6160,6243,4177,4112,53,6161,4160,33,17,3,6249,65,4160,4096,4177,2049,68,113,36,112,4161,513]

theorem envBound16897 : H12AffineFastState.Bounded env16897 := by
  intro p hp
  have h : env16897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16896_16897 : H12AffineEnvironment.transform 12 6248 env16896 = env16897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env16896 == env16897) = true)

theorem identity16897 : scanCanonicalize (H12AffineFastState.compose env16897 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound16897 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env16898 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,49,2137,112,2081,2130,96,33,53,2080,113,33,17,3,2136,65,113,49,96,2049,68,113,36,112,112,513]

theorem envBound16898 : H12AffineFastState.Bounded env16898 := by
  intro p hp
  have h : env16898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16897_16898 : H12AffineEnvironment.transform 11 49 env16897 = env16898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env16897 == env16898) = true)

theorem identity16898 : scanCanonicalize (H12AffineFastState.compose env16898 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound16898 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env16899 : List Nat := [2,4,8,16,32,64,9,37,512,52,112,49,41,112,81,34,96,33,53,80,113,33,17,3,40,65,113,49,96,113,68,113,36,112,112,513]

theorem envBound16899 : H12AffineFastState.Bounded env16899 := by
  intro p hp
  have h : env16899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16898_16899 : H12AffineEnvironment.transform 10 112 env16898 = env16899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env16898 == env16899) = true)

def env16900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,16,98780,8328,65,4340964,5392,17665,179512,1501,4256860,257,21792,46212,74251]

theorem envBound16900 : H12AffineFastState.Bounded env16900 := by
  intro p hp
  have h : env16900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16877_16900 : H12AffineEnvironment.transform 20 4161 env16877 = env16900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env16877 == env16900) = true)

theorem identity16900 : scanCanonicalize (H12AffineFastState.compose env16900 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21928) := by decide +kernel

theorem selectedBound16900 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,21928,16,98780,8328,65,158028,5392,17665,179512,1501,41460,257,21792,46212,74251]

theorem envBound16901 : H12AffineFastState.Bounded env16901 := by
  intro p hp
  have h : env16901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16900_16901 : H12AffineEnvironment.transform 21 21928 env16900 = env16901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21928 env16900 == env16901) = true)

theorem identity16901 : scanCanonicalize (H12AffineFastState.compose env16901 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16901 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env16902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4161,21928,16,41430,8328,65,158028,5392,17665,179512,1501,41460,257,21792,46212,513]

theorem envBound16902 : H12AffineFastState.Bounded env16902 := by
  intro p hp
  have h : env16902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16901_16902 : H12AffineEnvironment.transform 15 8202 env16901 = env16902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16901 == env16902) = true)

theorem identity16902 : scanCanonicalize (H12AffineFastState.compose env16902 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound16902 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env16903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32040,1025,32769,4161,21928,16,41430,8328,65,10589,5392,17665,64809,1501,41460,257,21792,46212,513]

theorem envBound16903 : H12AffineFastState.Bounded env16903 := by
  intro p hp
  have h : env16903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16902_16903 : H12AffineEnvironment.transform 16 16401 env16902 = env16903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16902 == env16903) = true)

def env16904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433957,8393985,10507600,8568105,2102685,12645453,257,21793,46213,2175563]

theorem envBound16904 : H12AffineFastState.Bounded env16904 := by
  intro p hp
  have h : env16904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16823_16904 : H12AffineEnvironment.transform 17 32041 env16823 = env16904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env16823 == env16904) = true)

def env16905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101328,98780,8328,65,6433957,2098513,17664,2272633,2102685,6349853,257,21793,46213,2175563]

theorem envBound16905 : H12AffineFastState.Bounded env16905 := by
  intro p hp
  have h : env16905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16904_16905 : H12AffineEnvironment.transform 22 2101328 env16904 = env16905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env16904 == env16905) = true)

def env16906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,16,98780,8328,65,4340965,5393,17664,179513,1501,4256861,257,21793,46213,74251]

theorem envBound16906 : H12AffineFastState.Bounded env16906 := by
  intro p hp
  have h : env16906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16905_16906 : H12AffineEnvironment.transform 20 4160 env16905 = env16906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16905 == env16906) = true)

theorem identity16906 : scanCanonicalize (H12AffineFastState.compose env16906 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95651) := by decide +kernel

theorem selectedBound16906 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95651,16,98780,8328,65,215366,5393,17664,179513,1501,98814,257,21793,46213,74251]

theorem envBound16907 : H12AffineFastState.Bounded env16907 := by
  intro p hp
  have h : env16907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16906_16907 : H12AffineEnvironment.transform 21 95651 env16906 = env16907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95651 env16906 == env16907) = true)

def env16908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95531,16,98644,8192,65,215366,5393,17664,179513,1365,98678,257,21793,46093,74251]

theorem envBound16908 : H12AffineFastState.Bounded env16908 := by
  intro p hp
  have h : env16908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16907_16908 : H12AffineEnvironment.transform 6 8 env16907 = env16908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16907 == env16908) = true)

theorem identity16908 : scanCanonicalize (H12AffineFastState.compose env16908 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound16908 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32041,1025,32769,4160,32,16,62559,8192,65,146509,5393,17664,179513,1365,62589,257,21793,46093,22272]

theorem envBound16909 : H12AffineFastState.Bounded env16909 := by
  intro p hp
  have h : env16909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16908_16909 : H12AffineEnvironment.transform 15 29963 env16908 = env16909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env16908 == env16909) = true)

theorem identity16909 : scanCanonicalize (H12AffineFastState.compose env16909 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound16909 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env16910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,46156,32041,1025,32769,4160,32,16,62559,8192,65,34817,5393,17664,2421,1365,62589,257,21793,46093,22272]

theorem envBound16910 : H12AffineFastState.Bounded env16910 := by
  intro p hp
  have h : env16910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16909_16910 : H12AffineEnvironment.transform 16 46156 env16909 = env16910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env16909 == env16910) = true)

theorem identity16910 : scanCanonicalize (H12AffineFastState.compose env16910 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound16910 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,16401,32041,1025,29788,4160,32,16,2,8192,65,31836,5393,17664,2421,1365,32,257,21793,16464,22272]

theorem envBound16911 : H12AffineFastState.Bounded env16911 := by
  intro p hp
  have h : env16911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16910_16911 : H12AffineEnvironment.transform 14 29789 env16910 = env16911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env16910 == env16911) = true)

theorem identity16911 : scanCanonicalize (H12AffineFastState.compose env16911 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound16911 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env16912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,293,115,13673,2129,1025,292,4160,32,16,2,8192,65,2340,5393,12408,2421,1365,32,257,8281,13608,8824]

theorem envBound16912 : H12AffineFastState.Bounded env16912 := by
  intro p hp
  have h : env16912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16911_16912 : H12AffineEnvironment.transform 13 13688 env16911 = env16912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env16911 == env16912) = true)

theorem identity16912 : scanCanonicalize (H12AffineFastState.compose env16912 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16912 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16913 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,13405,0,115,13388,2129,1025,1,4160,32,16,2,8192,65,2049,5172,12408,2128,1136,32,36,8281,13325,8824]

theorem envBound16913 : H12AffineFastState.Bounded env16913 := by
  intro p hp
  have h : env16913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16912_16913 : H12AffineEnvironment.transform 7 37 env16912 = env16913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16912 == env16913) = true)

theorem identity16913 : scanCanonicalize (H12AffineFastState.compose env16913 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16913 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env16914 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5236,0,115,5221,2129,1025,1,4160,32,16,2,41,65,2049,5172,4177,2128,1136,32,36,112,5156,593]

theorem envBound16914 : H12AffineFastState.Bounded env16914 := by
  intro p hp
  have h : env16914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16913_16914 : H12AffineEnvironment.transform 12 41 env16913 = env16914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16913 == env16914) = true)

theorem identity16914 : scanCanonicalize (H12AffineFastState.compose env16914 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound16914 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env16915 : List Nat := [2,4,8,16,32,64,8,37,512,1024,81,4096,41,5236,0,115,5221,0,1025,1,4160,32,16,2,41,65,80,5172,4177,1,1136,32,36,112,5156,593]

theorem envBound16915 : H12AffineFastState.Bounded env16915 := by
  intro p hp
  have h : env16915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16914_16915 : H12AffineEnvironment.transform 10 81 env16914 = env16915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env16914 == env16915) = true)

theorem identity16915 : scanCanonicalize (H12AffineFastState.compose env16915 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound16915 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env16916 : List Nat := [2,4,8,16,32,64,8,37,512,1024,81,16,41,1124,0,115,1141,0,1025,1,80,32,16,2,41,65,80,1060,65,1,1136,32,36,112,1076,593]

theorem envBound16916 : H12AffineFastState.Bounded env16916 := by
  intro p hp
  have h : env16916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16915_16916 : H12AffineEnvironment.transform 11 16 env16915 = env16916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env16915 == env16916) = true)

theorem identity16916 : scanCanonicalize (H12AffineFastState.compose env16916 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16916 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16917 : List Nat := [2,4,8,16,32,17,8,37,512,1024,0,16,41,1077,0,34,1060,0,1025,1,1,32,16,2,41,16,1,1060,16,1,1057,32,36,33,1076,512]

theorem envBound16917 : H12AffineFastState.Bounded env16917 := by
  intro p hp
  have h : env16917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16916_16917 : H12AffineEnvironment.transform 5 17 env16916 = env16917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16916 == env16917) = true)

theorem identity16917 : scanCanonicalize (H12AffineFastState.compose env16917 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16918 : List Nat := [2,4,8,16,16,17,8,21,512,1024,0,16,25,1029,0,18,1044,0,1025,1,1,16,16,2,25,16,1,1044,16,1,1041,16,20,17,1028,512]

theorem envBound16918 : H12AffineFastState.Bounded env16918 := by
  intro p hp
  have h : env16918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16917_16918 : H12AffineEnvironment.transform 4 16 env16917 = env16918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16917 == env16918) = true)

theorem identity16918 : scanCanonicalize (H12AffineFastState.compose env16918 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound16918 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16919 : List Nat := [2,4,8,16,16,17,8,21,512,533,0,16,25,528,0,18,513,0,532,1,1,16,16,2,25,16,1,513,16,1,516,16,20,17,529,512]

theorem envBound16919 : H12AffineFastState.Bounded env16919 := by
  intro p hp
  have h : env16919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16918_16919 : H12AffineEnvironment.transform 9 533 env16918 = env16919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env16918 == env16919) = true)

theorem identity16919 : scanCanonicalize (H12AffineFastState.compose env16919 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16919 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16920 : List Nat := [2,4,8,1,1,0,8,4,512,516,0,1,8,513,0,3,513,0,517,1,1,1,1,2,8,1,1,513,1,1,516,1,5,0,512,512]

theorem envBound16920 : H12AffineFastState.Bounded env16920 := by
  intro p hp
  have h : env16920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16919_16920 : H12AffineEnvironment.transform 3 1 env16919 = env16920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16919 == env16920) = true)

def env16921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95530,16,98645,8193,65,215366,5393,17664,179513,1364,98679,257,21793,46092,74251]

theorem envBound16921 : H12AffineFastState.Bounded env16921 := by
  intro p hp
  have h : env16921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16907_16921 : H12AffineEnvironment.transform 6 9 env16907 = env16921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16907 == env16921) = true)

theorem identity16921 : scanCanonicalize (H12AffineFastState.compose env16921 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound16921 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4160,41341,16,21762,8193,65,171281,5393,17664,179513,1364,21792,257,21793,46092,63068]

theorem envBound16922 : H12AffineFastState.Bounded env16922 := by
  intro p hp
  have h : env16922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16921_16922 : H12AffineEnvironment.transform 15 54359 env16921 = env16922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env16921 == env16922) = true)

theorem identity16922 : scanCanonicalize (H12AffineFastState.compose env16922 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound16922 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env16923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,57677,32041,1025,32769,4160,41341,16,21762,8193,65,31836,5393,17664,23668,1364,21792,257,21793,46092,63068]

theorem envBound16923 : H12AffineFastState.Bounded env16923 := by
  intro p hp
  have h : env16923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16922_16923 : H12AffineEnvironment.transform 16 57677 env16922 = env16923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env16922 == env16923) = true)

theorem identity16923 : scanCanonicalize (H12AffineFastState.compose env16923 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound16923 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env16924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,21794,24632,32041,1025,372,4160,8200,16,21762,8193,65,31836,5393,17664,23668,1364,21792,257,21793,13689,30505]

theorem envBound16924 : H12AffineFastState.Bounded env16924 := by
  intro p hp
  have h : env16924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16923_16924 : H12AffineEnvironment.transform 14 373 env16923 = env16924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env16923 == env16924) = true)

theorem identity16924 : scanCanonicalize (H12AffineFastState.compose env16924 (packedSelected [2,4,9,11,16,23] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound16924 : packedSelected [2,4,9,11,16,23] rootPS < 2^1333 := by decide +kernel

def env16925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,373,262,13340,10509,1025,372,4160,8200,16,294,8193,65,10360,5393,4388,2128,1364,260,257,261,13689,8973]

theorem envBound16925 : H12AffineFastState.Bounded env16925 := by
  intro p hp
  have h : env16925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16924_16925 : H12AffineEnvironment.transform 13 5156 env16924 = env16925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env16924 == env16925) = true)

theorem identity16925 : scanCanonicalize (H12AffineFastState.compose env16925 (packedSelected [3,4,5,6,9,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16925 : packedSelected [3,4,5,6,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env16926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5156,373,262,5393,2048,1025,372,4160,261,16,294,268,65,2421,5393,4388,2128,1364,260,257,261,5236,512]

theorem envBound16926 : H12AffineFastState.Bounded env16926 := by
  intro p hp
  have h : env16926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16925_16926 : H12AffineEnvironment.transform 12 269 env16925 = env16926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16925 == env16926) = true)

theorem identity16926 : scanCanonicalize (H12AffineFastState.compose env16926 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16926 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16927 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5156,80,35,5172,2048,1025,81,4160,32,16,3,41,65,2128,5172,4097,2128,1137,33,36,32,5236,512]

theorem envBound16927 : H12AffineFastState.Bounded env16927 := by
  intro p hp
  have h : env16927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16926_16927 : H12AffineEnvironment.transform 7 37 env16926 = env16927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16926 == env16927) = true)

theorem identity16927 : scanCanonicalize (H12AffineFastState.compose env16927 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound16927 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env16928 : List Nat := [2,4,8,16,32,64,9,37,512,1024,523,4096,40,5156,80,35,5172,523,1025,81,4160,32,16,3,41,65,603,5172,4097,603,1137,33,36,32,5236,512]

theorem envBound16928 : H12AffineFastState.Bounded env16928 := by
  intro p hp
  have h : env16928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16927_16928 : H12AffineEnvironment.transform 10 523 env16927 = env16928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env16927 == env16928) = true)

theorem identity16928 : scanCanonicalize (H12AffineFastState.compose env16928 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound16928 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env16929 : List Nat := [2,4,8,16,32,49,9,37,512,1024,523,4096,40,5156,33,35,5172,523,1025,32,4145,32,16,3,41,48,554,5172,4097,554,1024,33,36,32,5125,512]

theorem envBound16929 : H12AffineFastState.Bounded env16929 := by
  intro p hp
  have h : env16929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16928_16929 : H12AffineEnvironment.transform 5 49 env16928 = env16929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env16928 == env16929) = true)

theorem identity16929 : scanCanonicalize (H12AffineFastState.compose env16929 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16929 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16930 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,4096,9,5125,0,2,5141,523,1025,1,4112,1,16,3,8,17,523,5141,4097,523,1024,0,5,1,5125,512]

theorem envBound16930 : H12AffineFastState.Bounded env16930 := by
  intro p hp
  have h : env16930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16929_16930 : H12AffineEnvironment.transform 4 1 env16929 = env16930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16929 == env16930) = true)

theorem identity16930 : scanCanonicalize (H12AffineFastState.compose env16930 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound16930 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16931 : List Nat := [2,4,8,16,1,16,9,4,512,20,523,4096,9,4113,0,2,4097,523,21,1,4112,1,16,3,8,17,523,4097,4097,523,20,0,5,1,4113,512]

theorem envBound16931 : H12AffineFastState.Bounded env16931 := by
  intro p hp
  have h : env16931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16930_16931 : H12AffineEnvironment.transform 9 20 env16930 = env16931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16930 == env16931) = true)

theorem identity16931 : scanCanonicalize (H12AffineFastState.compose env16931 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 31) := by decide +kernel

theorem selectedBound16931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16932 : List Nat := [2,4,8,16,1,16,9,4,512,20,523,31,9,14,0,2,30,523,21,1,15,1,16,3,8,17,523,30,30,523,20,0,5,1,14,512]

theorem envBound16932 : H12AffineFastState.Bounded env16932 := by
  intro p hp
  have h : env16932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16931_16932 : H12AffineEnvironment.transform 11 31 env16931 = env16932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 31 env16931 == env16932) = true)

theorem identity16932 : scanCanonicalize (H12AffineFastState.compose env16932 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound16932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16933 : List Nat := [2,4,5,16,1,16,4,4,512,20,518,18,4,3,0,2,19,518,21,1,2,1,16,3,5,17,518,19,19,518,20,0,5,1,3,512]

theorem envBound16933 : H12AffineFastState.Bounded env16933 := by
  intro p hp
  have h : env16933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16932_16933 : H12AffineEnvironment.transform 2 5 env16932 = env16933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env16932 == env16933) = true)

theorem identity16933 : scanCanonicalize (H12AffineFastState.compose env16933 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound16933 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16934 : List Nat := [2,4,5,16,1,16,4,4,4,20,2,18,4,3,0,2,19,2,21,1,2,1,16,3,5,17,2,19,19,2,20,0,5,1,3,4]

theorem envBound16934 : H12AffineFastState.Bounded env16934 := by
  intro p hp
  have h : env16934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16933_16934 : H12AffineEnvironment.transform 8 4 env16933 = env16934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env16933 == env16934) = true)

def env16935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98780,8328,65,4340964,5392,17664,179512,1500,4256860,257,21793,46213,74250]

theorem envBound16935 : H12AffineFastState.Bounded env16935 := by
  intro p hp
  have h : env16935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16905_16935 : H12AffineEnvironment.transform 20 4161 env16905 = env16935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env16905 == env16935) = true)

theorem identity16935 : scanCanonicalize (H12AffineFastState.compose env16935 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16935 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41431,8328,65,4340964,5392,17664,179512,1500,4256860,257,21793,46213,513]

theorem envBound16936 : H12AffineFastState.Bounded env16936 := by
  intro p hp
  have h : env16936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16935_16936 : H12AffineEnvironment.transform 15 8203 env16935 = env16936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16935 == env16936) = true)

theorem identity16936 : scanCanonicalize (H12AffineFastState.compose env16936 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41381) := by decide +kernel

theorem selectedBound16936 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env16937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41381,17,41431,8328,65,171329,5392,17664,179512,1500,22009,257,21793,46213,513]

theorem envBound16937 : H12AffineFastState.Bounded env16937 := by
  intro p hp
  have h : env16937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16936_16937 : H12AffineEnvironment.transform 21 41381 env16936 = env16937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41381 env16936 == env16937) = true)

def env16938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41261,17,41311,8192,65,171329,5392,17664,179512,1364,21873,257,21793,46093,513]

theorem envBound16938 : H12AffineFastState.Bounded env16938 := by
  intro p hp
  have h : env16938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16937_16938 : H12AffineEnvironment.transform 6 8 env16937 = env16938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16937 == env16938) = true)

theorem identity16938 : scanCanonicalize (H12AffineFastState.compose env16938 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound16938 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env16939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,21873,17,21763,8192,65,157981,5392,17664,149860,1364,21873,257,21793,16465,513]

theorem envBound16939 : H12AffineFastState.Bounded env16939 := by
  intro p hp
  have h : env16939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16938_16939 : H12AffineEnvironment.transform 14 29788 env16938 = env16939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env16938 == env16939) = true)

theorem identity16939 : scanCanonicalize (H12AffineFastState.compose env16939 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound16939 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env16940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16401,32041,1025,29789,4161,21873,17,21763,8192,65,10508,5392,17664,2421,1364,21873,257,21793,16465,513]

theorem envBound16940 : H12AffineFastState.Bounded env16940 := by
  intro p hp
  have h : env16940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16939_16940 : H12AffineEnvironment.transform 16 16401 env16939 = env16940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16939 == env16940) = true)

theorem identity16940 : scanCanonicalize (H12AffineFastState.compose env16940 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound16940 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10280,1025,8540,4161,112,17,2,8192,65,10508,5392,4097,2421,1364,112,257,32,5456,513]

theorem envBound16941 : H12AffineFastState.Bounded env16941 := by
  intro p hp
  have h : env16941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16940_16941 : H12AffineEnvironment.transform 13 5377 env16940 = env16941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16940 == env16941) = true)

theorem identity16941 : scanCanonicalize (H12AffineFastState.compose env16941 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16941 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16942 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,5392,10280,1025,8461,4112,33,17,2,8192,16,10508,5392,4097,2340,1285,33,257,32,5377,513]

theorem envBound16942 : H12AffineFastState.Bounded env16942 := by
  intro p hp
  have h : env16942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16941_16942 : H12AffineEnvironment.transform 5 17 env16941 = env16942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16941 == env16942) = true)

theorem identity16942 : scanCanonicalize (H12AffineFastState.compose env16942 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound16942 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16943 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,8192,309,8460,8203,292,10280,1025,8461,1060,33,17,2,8192,16,10508,292,1077,2340,1285,33,257,32,309,513]

theorem envBound16943 : H12AffineFastState.Bounded env16943 := by
  intro p hp
  have h : env16943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16942_16943 : H12AffineEnvironment.transform 11 1076 env16942 = env16943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env16942 == env16943) = true)

theorem identity16943 : scanCanonicalize (H12AffineFastState.compose env16943 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound16943 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16944 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,2082,309,2350,2089,292,10,1025,2351,1060,33,17,2,2082,16,302,292,1077,2340,1285,33,257,32,309,513]

theorem envBound16944 : H12AffineFastState.Bounded env16944 := by
  intro p hp
  have h : env16944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16943_16944 : H12AffineEnvironment.transform 12 2082 env16943 = env16944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env16943 == env16944) = true)

theorem identity16944 : scanCanonicalize (H12AffineFastState.compose env16944 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound16944 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16945 : List Nat := [2,4,8,16,32,17,8,256,512,1024,302,1076,268,309,0,263,292,10,1025,1,1060,33,17,2,268,16,302,292,1077,10,1285,33,257,32,309,513]

theorem envBound16945 : H12AffineFastState.Bounded env16945 := by
  intro p hp
  have h : env16945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16944_16945 : H12AffineEnvironment.transform 10 302 env16944 = env16945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env16944 == env16945) = true)

def env16946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41260,17,41310,8193,65,171329,5392,17664,179512,1365,21872,257,21793,46092,513]

theorem envBound16946 : H12AffineFastState.Bounded env16946 := by
  intro p hp
  have h : env16946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16937_16946 : H12AffineEnvironment.transform 6 9 env16937 = env16946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16937 == env16946) = true)

theorem identity16946 : scanCanonicalize (H12AffineFastState.compose env16946 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16946 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32041,1025,8540,4161,113,17,3,8193,65,146460,5392,17664,138341,1365,21872,257,21793,5457,513]

theorem envBound16947 : H12AffineFastState.Bounded env16947 := by
  intro p hp
  have h : env16947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16946_16947 : H12AffineEnvironment.transform 14 8541 env16946 = env16947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16946 == env16947) = true)

theorem identity16947 : scanCanonicalize (H12AffineFastState.compose env16947 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16947 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,32041,1025,8540,4161,113,17,3,8193,65,31756,5392,17664,23669,1365,21872,257,21793,5457,513]

theorem envBound16948 : H12AffineFastState.Bounded env16948 := by
  intro p hp
  have h : env16948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16947_16948 : H12AffineEnvironment.transform 16 16400 env16947 = env16948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16947 == env16948) = true)

theorem identity16948 : scanCanonicalize (H12AffineFastState.compose env16948 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound16948 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,8541,8203,13673,2128,1025,8540,4161,113,17,3,8193,65,2421,5392,12409,10508,1365,8201,257,8280,5457,513]

theorem envBound16949 : H12AffineFastState.Bounded env16949 := by
  intro p hp
  have h : env16949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16948_16949 : H12AffineEnvironment.transform 13 13689 env16948 = env16949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env16948 == env16949) = true)

theorem identity16949 : scanCanonicalize (H12AffineFastState.compose env16949 (packedSelected [5,8,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound16949 : packedSelected [5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env16950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5457,373,35,5441,2128,1025,372,4161,113,17,3,41,65,2421,5392,4177,2340,1365,33,257,112,5457,513]

theorem envBound16950 : H12AffineFastState.Bounded env16950 := by
  intro p hp
  have h : env16950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16949_16950 : H12AffineEnvironment.transform 12 40 env16949 = env16950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env16949 == env16950) = true)

theorem identity16950 : scanCanonicalize (H12AffineFastState.compose env16950 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound16950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16951 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,40,4144,373,35,4128,2128,352,372,4161,113,17,3,41,65,2421,4209,4177,2340,52,33,257,112,4144,513]

theorem envBound16951 : H12AffineFastState.Bounded env16951 := by
  intro p hp
  have h : env16951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16950_16951 : H12AffineEnvironment.transform 9 353 env16950 = env16951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env16950 == env16951) = true)

theorem identity16951 : scanCanonicalize (H12AffineFastState.compose env16951 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16951 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16952 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,40,4144,293,35,4128,2048,304,292,4113,33,17,3,41,17,2341,4129,4097,2340,52,33,257,32,4144,513]

theorem envBound16952 : H12AffineFastState.Bounded env16952 := by
  intro p hp
  have h : env16952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16951_16952 : H12AffineEnvironment.transform 5 16 env16951 = env16952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16951 == env16952) = true)

theorem identity16952 : scanCanonicalize (H12AffineFastState.compose env16952 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound16952 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16953 : List Nat := [2,4,8,16,32,16,9,256,512,305,261,4096,40,4144,293,35,4128,261,304,292,4113,33,17,3,41,17,32,4129,4097,33,52,33,257,32,4144,513]

theorem envBound16953 : H12AffineFastState.Bounded env16953 := by
  intro p hp
  have h : env16953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16952_16953 : H12AffineEnvironment.transform 10 261 env16952 = env16953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env16952 == env16953) = true)

theorem identity16953 : scanCanonicalize (H12AffineFastState.compose env16953 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 789) := by decide +kernel

theorem selectedBound16953 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env16954 : List Nat := [2,4,8,16,32,16,9,256,512,305,261,789,40,805,293,35,821,261,304,292,772,33,17,3,41,17,32,820,788,33,52,33,257,32,805,513]

theorem envBound16954 : H12AffineFastState.Bounded env16954 := by
  intro p hp
  have h : env16954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16953_16954 : H12AffineEnvironment.transform 11 789 env16953 = env16954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 789 env16953 == env16954) = true)

theorem identity16954 : scanCanonicalize (H12AffineFastState.compose env16954 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16954 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16955 : List Nat := [2,4,8,16,32,16,9,5,512,52,0,528,40,544,32,35,560,0,53,33,513,33,17,3,41,17,32,561,529,33,52,33,4,32,544,513]

theorem envBound16955 : H12AffineFastState.Bounded env16955 := by
  intro p hp
  have h : env16955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16954_16955 : H12AffineEnvironment.transform 7 5 env16954 = env16955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16954 == env16955) = true)

def env16956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101329,98781,8328,65,6433957,2098512,17665,2272632,2102685,6349852,257,21793,46213,2175563]

theorem envBound16956 : H12AffineFastState.Bounded env16956 := by
  intro p hp
  have h : env16956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16904_16956 : H12AffineEnvironment.transform 22 2101329 env16904 = env16956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env16904 == env16956) = true)

def env16957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,17,98781,8328,65,4340965,5392,17665,179512,1501,4256860,257,21793,46213,74251]

theorem envBound16957 : H12AffineFastState.Bounded env16957 := by
  intro p hp
  have h : env16957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16956_16957 : H12AffineEnvironment.transform 20 4160 env16956 = env16957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16956 == env16957) = true)

theorem identity16957 : scanCanonicalize (H12AffineFastState.compose env16957 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound16957 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32041,1025,32769,4160,4194304,17,21763,8328,65,4340965,5392,17665,179512,1501,4256860,257,21793,46213,63189]

theorem envBound16958 : H12AffineFastState.Bounded env16958 := by
  intro p hp
  have h : env16958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16957_16958 : H12AffineEnvironment.transform 15 54494 env16957 = env16958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env16957 == env16958) = true)

def env16959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4160,4194304,17,21763,8192,65,4340845,5392,17665,179512,1365,4256860,257,21793,46093,63069]

theorem envBound16959 : H12AffineFastState.Bounded env16959 := by
  intro p hp
  have h : env16959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16958_16959 : H12AffineEnvironment.transform 6 8 env16958 = env16959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16958 == env16959) = true)

theorem identity16959 : scanCanonicalize (H12AffineFastState.compose env16959 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound16959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4160,4194304,17,21763,8192,65,4340845,5392,17665,149860,1365,4194304,257,21793,16465,513]

theorem envBound16960 : H12AffineFastState.Bounded env16960 := by
  intro p hp
  have h : env16960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16959_16960 : H12AffineEnvironment.transform 14 29788 env16959 = env16960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env16959 == env16960) = true)

theorem identity16960 : scanCanonicalize (H12AffineFastState.compose env16960 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound16960 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env16961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4160,147504,17,21763,8192,65,31837,5392,17665,149860,1365,147504,257,21793,16465,513]

theorem envBound16961 : H12AffineFastState.Bounded env16961 := by
  intro p hp
  have h : env16961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16960_16961 : H12AffineEnvironment.transform 21 147504 env16960 = env16961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env16960 == env16961) = true)

theorem identity16961 : scanCanonicalize (H12AffineFastState.compose env16961 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound16961 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env16962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16400,32041,1025,29789,4160,32,17,21763,8192,65,31837,5392,17665,2420,1365,32,257,21793,16465,513]

theorem envBound16962 : H12AffineFastState.Bounded env16962 := by
  intro p hp
  have h : env16962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16961_16962 : H12AffineEnvironment.transform 16 16400 env16961 = env16962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env16961 == env16962) = true)

theorem identity16962 : scanCanonicalize (H12AffineFastState.compose env16962 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound16962 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,13388,2421,1025,1,4160,32,17,8543,8192,65,2049,5392,12637,2420,1365,32,257,8573,13325,513]

theorem envBound16963 : H12AffineFastState.Bounded env16963 := by
  intro p hp
  have h : env16963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16962_16963 : H12AffineEnvironment.transform 13 13404 env16962 = env16963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env16962 == env16963) = true)

theorem identity16963 : scanCanonicalize (H12AffineFastState.compose env16963 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound16963 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env16964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,0,1095,4097,2421,1025,1,4160,32,17,1298,1101,65,2049,5392,5392,2420,1365,32,257,1328,4160,513]

theorem envBound16964 : H12AffineFastState.Bounded env16964 := by
  intro p hp
  have h : env16964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16963_16964 : H12AffineEnvironment.transform 12 1101 env16963 = env16964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env16963 == env16964) = true)

theorem identity16964 : scanCanonicalize (H12AffineFastState.compose env16964 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16964 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16965 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4113,0,342,4097,2421,272,1,4160,32,17,3,348,65,2049,4097,4097,2420,68,32,257,33,4160,513]

theorem envBound16965 : H12AffineFastState.Bounded env16965 := by
  intro p hp
  have h : env16965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16964_16965 : H12AffineEnvironment.transform 9 273 env16964 = env16965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16964 == env16965) = true)

theorem identity16965 : scanCanonicalize (H12AffineFastState.compose env16965 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound16965 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16966 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,96,348,113,0,342,97,2421,272,1,32,32,17,3,348,65,2049,97,97,2420,68,32,257,33,32,513]

theorem envBound16966 : H12AffineFastState.Bounded env16966 := by
  intro p hp
  have h : env16966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16965_16966 : H12AffineEnvironment.transform 11 96 env16965 = env16966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env16965 == env16966) = true)

theorem identity16966 : scanCanonicalize (H12AffineFastState.compose env16966 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound16966 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16967 : List Nat := [2,4,8,16,32,64,8,256,512,273,815,96,348,113,0,342,97,602,272,1,32,32,17,3,348,65,814,97,97,603,68,32,257,33,32,513]

theorem envBound16967 : H12AffineFastState.Bounded env16967 := by
  intro p hp
  have h : env16967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16966_16967 : H12AffineEnvironment.transform 10 815 env16966 = env16967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env16966 == env16967) = true)

theorem identity16967 : scanCanonicalize (H12AffineFastState.compose env16967 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound16967 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16968 : List Nat := [2,4,8,16,32,64,8,84,512,69,635,96,8,113,0,2,97,602,68,1,32,32,17,3,8,65,634,97,97,603,68,32,85,33,32,513]

theorem envBound16968 : H12AffineFastState.Bounded env16968 := by
  intro p hp
  have h : env16968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16967_16968 : H12AffineEnvironment.transform 7 84 env16967 = env16968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env16967 == env16968) = true)

theorem identity16968 : scanCanonicalize (H12AffineFastState.compose env16968 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16968 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env16969 : List Nat := [2,4,8,16,32,64,8,84,32,69,91,96,8,113,0,2,97,122,68,1,32,32,17,3,8,65,90,97,97,123,68,32,85,33,32,33]

theorem envBound16969 : H12AffineFastState.Bounded env16969 := by
  intro p hp
  have h : env16969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16968_16969 : H12AffineEnvironment.transform 8 32 env16968 = env16969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16968 == env16969) = true)

theorem identity16969 : scanCanonicalize (H12AffineFastState.compose env16969 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16969 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16970 : List Nat := [2,4,3,16,32,64,3,84,32,69,80,96,3,113,0,2,97,113,68,1,32,32,17,3,3,65,81,97,97,112,68,32,85,33,32,33]

theorem envBound16970 : H12AffineFastState.Bounded env16970 := by
  intro p hp
  have h : env16970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16969_16970 : H12AffineEnvironment.transform 2 3 env16969 = env16970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16969 == env16970) = true)

theorem identity16970 : scanCanonicalize (H12AffineFastState.compose env16970 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound16970 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16971 : List Nat := [2,4,3,5,32,64,3,65,32,69,69,96,3,100,0,2,97,100,68,1,32,32,4,3,3,65,68,97,97,101,68,32,64,33,32,33]

theorem envBound16971 : H12AffineFastState.Bounded env16971 := by
  intro p hp
  have h : env16971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16970_16971 : H12AffineEnvironment.transform 3 5 env16970 = env16971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env16970 == env16971) = true)

theorem identity16971 : scanCanonicalize (H12AffineFastState.compose env16971 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound16971 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16972 : List Nat := [2,1,3,0,32,64,3,65,32,64,64,96,3,97,0,2,97,97,65,1,32,32,1,3,3,65,65,97,97,96,65,32,64,33,32,33]

theorem envBound16972 : H12AffineFastState.Bounded env16972 := by
  intro p hp
  have h : env16972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16971_16972 : H12AffineEnvironment.transform 1 1 env16971 = env16972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env16971 == env16972) = true)

theorem identity16972 : scanCanonicalize (H12AffineFastState.compose env16972 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound16972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16973 : List Nat := [2,1,3,0,2,64,3,65,2,64,64,66,3,67,0,2,67,67,65,1,2,2,1,3,3,65,65,67,67,66,65,2,64,3,2,3]

theorem envBound16973 : H12AffineFastState.Bounded env16973 := by
  intro p hp
  have h : env16973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16972_16973 : H12AffineEnvironment.transform 4 2 env16972 = env16973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env16972 == env16973) = true)

theorem identity16973 : scanCanonicalize (H12AffineFastState.compose env16973 (packedSelected [4,12] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound16973 : packedSelected [4,12] rootPS < 2^1333 := by decide +kernel

def env16974 : List Nat := [2,1,3,0,2,2,3,3,2,2,2,0,3,1,0,2,1,1,3,1,2,2,1,3,3,3,3,1,1,0,3,2,2,3,2,3]

theorem envBound16974 : H12AffineFastState.Bounded env16974 := by
  intro p hp
  have h : env16974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16973_16974 : H12AffineEnvironment.transform 5 2 env16973 = env16974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env16973 == env16974) = true)

theorem identity16974 : scanCanonicalize (H12AffineFastState.compose env16974 (packedSelected [15] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound16974 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env16975 : List Nat := [1,1,0,0,1,1,0,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,1,0,1,0]

theorem envBound16975 : H12AffineFastState.Bounded env16975 := by
  intro p hp
  have h : env16975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16974_16975 : H12AffineEnvironment.transform 0 1 env16974 = env16975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env16974 == env16975) = true)

def env16976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4160,4194304,17,21763,8193,65,4340844,5392,17665,179512,1364,4256860,257,21793,46092,63068]

theorem envBound16976 : H12AffineFastState.Bounded env16976 := by
  intro p hp
  have h : env16976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16958_16976 : H12AffineEnvironment.transform 6 9 env16958 = env16976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16958 == env16976) = true)

theorem identity16976 : scanCanonicalize (H12AffineFastState.compose env16976 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16976 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,131072,10281,1025,32769,4160,4194304,17,3,8193,65,4340844,5392,4097,179512,1364,4235612,257,33,46092,41820]

theorem envBound16977 : H12AffineFastState.Bounded env16977 := by
  intro p hp
  have h : env16977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16976_16977 : H12AffineEnvironment.transform 13 5376 env16976 = env16977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16976 == env16977) = true)

theorem identity16977 : scanCanonicalize (H12AffineFastState.compose env16977 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound16977 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,5393,10281,1025,32769,4160,4194304,17,3,8193,65,4204925,5392,4097,43049,1364,4235612,257,33,46092,41820]

theorem envBound16978 : H12AffineFastState.Bounded env16978 := by
  intro p hp
  have h : env16978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16977_16978 : H12AffineEnvironment.transform 16 5393 env16977 = env16978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env16977 == env16978) = true)

theorem identity16978 : scanCanonicalize (H12AffineFastState.compose env16978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound16978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9292,9499,5393,10281,1025,9293,4160,4194304,17,3,8193,65,4204925,5392,4097,3173,1364,4195600,257,33,4160,1808]

theorem envBound16979 : H12AffineFastState.Bounded env16979 := by
  intro p hp
  have h : env16979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16978_16979 : H12AffineEnvironment.transform 14 9292 env16978 = env16979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env16978 == env16979) = true)

theorem identity16979 : scanCanonicalize (H12AffineFastState.compose env16979 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound16979 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env16980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9292,9499,5393,10281,1025,9293,4160,8201,17,3,8193,65,2420,5392,4097,3173,1364,9497,257,33,4160,1808]

theorem envBound16980 : H12AffineFastState.Bounded env16980 := by
  intro p hp
  have h : env16980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16979_16980 : H12AffineEnvironment.transform 21 8201 env16979 = env16980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env16979 == env16980) = true)

theorem identity16980 : scanCanonicalize (H12AffineFastState.compose env16980 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16980 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env16981 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,9292,9278,5172,10281,1025,9293,4160,8201,17,3,8193,65,2129,5173,4097,3173,1137,9276,36,33,4160,1589]

theorem envBound16981 : H12AffineFastState.Bounded env16981 := by
  intro p hp
  have h : env16981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16980_16981 : H12AffineEnvironment.transform 7 37 env16980 = env16981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16980 == env16981) = true)

def env16982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,16,98781,8328,65,4340964,5393,17665,179513,1500,4256861,257,21793,46213,74250]

theorem envBound16982 : H12AffineFastState.Bounded env16982 := by
  intro p hp
  have h : env16982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16956_16982 : H12AffineEnvironment.transform 20 4161 env16956 = env16982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env16956 == env16982) = true)

theorem identity16982 : scanCanonicalize (H12AffineFastState.compose env16982 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound16982 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98678,16,98781,8328,65,245138,5393,17665,179513,1500,95531,257,21793,46213,74250]

theorem envBound16983 : H12AffineFastState.Bounded env16983 := by
  intro p hp
  have h : env16983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16982_16983 : H12AffineEnvironment.transform 21 98678 env16982 = env16983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env16982 == env16983) = true)

def env16984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98678,16,98645,8192,65,245018,5393,17665,179513,1364,95531,257,21793,46093,74250]

theorem envBound16984 : H12AffineFastState.Bounded env16984 := by
  intro p hp
  have h : env16984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16983_16984 : H12AffineEnvironment.transform 6 8 env16983 = env16984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16983 == env16984) = true)

theorem identity16984 : scanCanonicalize (H12AffineFastState.compose env16984 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound16984 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,32041,1025,32769,4161,62588,16,62559,8192,65,182288,5393,17665,179513,1364,33,257,21793,46093,22272]

theorem envBound16985 : H12AffineFastState.Bounded env16985 := by
  intro p hp
  have h : env16985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16984_16985 : H12AffineEnvironment.transform 15 29962 env16984 = env16985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env16984 == env16985) = true)

theorem identity16985 : scanCanonicalize (H12AffineFastState.compose env16985 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound16985 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env16986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,13388,32041,1025,32769,4161,62588,16,62559,8192,65,64604,5393,17665,35189,1364,33,257,21793,46093,22272]

theorem envBound16986 : H12AffineFastState.Bounded env16986 := by
  intro p hp
  have h : env16986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16985_16986 : H12AffineEnvironment.transform 16 13388 env16985 = env16986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env16985 == env16986) = true)

theorem identity16986 : scanCanonicalize (H12AffineFastState.compose env16986 (packedSelected [1,4,8,9,11,14,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound16986 : packedSelected [1,4,8,9,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env16987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,8282,13388,10361,1025,32769,4161,41260,16,41231,8192,65,43276,5393,4177,35189,1364,33,257,113,46093,592]

theorem envBound16987 : H12AffineFastState.Bounded env16987 := by
  intro p hp
  have h : env16987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16986_16987 : H12AffineEnvironment.transform 13 5456 env16986 = env16987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env16986 == env16987) = true)

theorem identity16987 : scanCanonicalize (H12AffineFastState.compose env16987 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16987 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env16988 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,8202,13340,10281,1025,32769,4113,41260,16,41231,8192,17,43276,5393,4097,35109,1284,33,257,33,46093,512]

theorem envBound16988 : H12AffineFastState.Bounded env16988 := by
  intro p hp
  have h : env16988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16987_16988 : H12AffineEnvironment.transform 5 16 env16987 = env16988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16987 == env16988) = true)

theorem identity16988 : scanCanonicalize (H12AffineFastState.compose env16988 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound16988 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16989 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32,8202,13340,10281,1025,33,4113,8460,16,8495,8192,17,10540,5393,4097,2309,1284,33,257,33,13357,512]

theorem envBound16989 : H12AffineFastState.Bounded env16989 := by
  intro p hp
  have h : env16989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16988_16989 : H12AffineEnvironment.transform 14 32 env16988 = env16989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env16988 == env16989) = true)

theorem identity16989 : scanCanonicalize (H12AffineFastState.compose env16989 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound16989 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16990 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,5376,32,1047,4097,3124,1025,33,4113,1297,16,1330,1053,17,3377,5393,4097,2309,1284,33,257,33,4144,512]

theorem envBound16990 : H12AffineFastState.Bounded env16990 := by
  intro p hp
  have h : env16990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16989_16990 : H12AffineEnvironment.transform 12 1053 env16989 = env16990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env16989 == env16990) = true)

theorem identity16990 : scanCanonicalize (H12AffineFastState.compose env16990 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound16990 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16991 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3328,1053,2048,32,1047,3329,3124,1025,33,3345,1297,16,1330,1053,17,3377,2065,3329,2309,1284,33,257,33,3376,512]

theorem envBound16991 : H12AffineFastState.Bounded env16991 := by
  intro p hp
  have h : env16991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16990_16991 : H12AffineEnvironment.transform 11 3328 env16990 = env16991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env16990 == env16991) = true)

theorem identity16991 : scanCanonicalize (H12AffineFastState.compose env16991 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16991 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env16992 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,3328,1053,2048,1,1047,3329,3093,1025,0,3345,1297,16,1299,1053,17,3344,2065,3329,2309,1284,0,257,0,3345,512]

theorem envBound16992 : H12AffineFastState.Bounded env16992 := by
  intro p hp
  have h : env16992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16991_16992 : H12AffineEnvironment.transform 4 1 env16991 = env16992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16991 == env16992) = true)

theorem identity16992 : scanCanonicalize (H12AffineFastState.compose env16992 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound16992 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env16993 : List Nat := [2,4,8,16,1,16,8,256,512,21,2048,2325,8,2048,1,2,2324,2048,20,0,2308,260,16,262,8,17,2309,2065,2324,2309,273,0,257,0,2308,512]

theorem envBound16993 : H12AffineFastState.Bounded env16993 := by
  intro p hp
  have h : env16993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16992_16993 : H12AffineEnvironment.transform 9 21 env16992 = env16993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16992 == env16993) = true)

theorem identity16993 : scanCanonicalize (H12AffineFastState.compose env16993 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16993 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16994 : List Nat := [2,4,8,16,1,16,8,256,512,21,0,277,8,0,1,2,276,0,20,0,260,260,16,262,8,17,261,17,276,261,273,0,257,0,260,512]

theorem envBound16994 : H12AffineFastState.Bounded env16994 := by
  intro p hp
  have h : env16994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16993_16994 : H12AffineEnvironment.transform 10 0 env16993 = env16994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16993 == env16994) = true)

theorem identity16994 : scanCanonicalize (H12AffineFastState.compose env16994 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16994 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env16995 : List Nat := [2,4,8,16,1,16,8,5,512,21,0,16,8,0,1,2,17,0,20,0,1,1,16,3,8,17,0,17,17,0,20,0,4,0,1,512]

theorem envBound16995 : H12AffineFastState.Bounded env16995 := by
  intro p hp
  have h : env16995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16994_16995 : H12AffineEnvironment.transform 7 5 env16994 = env16995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16994 == env16995) = true)

theorem identity16995 : scanCanonicalize (H12AffineFastState.compose env16995 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound16995 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16996 : List Nat := [2,0,8,16,1,16,8,1,512,17,0,16,8,0,1,2,17,0,16,0,1,1,16,3,8,17,0,17,17,0,16,0,0,0,1,512]

theorem envBound16996 : H12AffineFastState.Bounded env16996 := by
  intro p hp
  have h : env16996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16995_16996 : H12AffineEnvironment.transform 1 0 env16995 = env16996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env16995 == env16996) = true)

theorem identity16996 : scanCanonicalize (H12AffineFastState.compose env16996 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound16996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16997 : List Nat := [2,0,8,8,1,8,8,1,512,9,0,8,8,0,1,2,9,0,8,0,1,1,8,3,8,9,0,9,9,0,8,0,0,0,1,512]

theorem envBound16997 : H12AffineFastState.Bounded env16997 := by
  intro p hp
  have h : env16997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16996_16997 : H12AffineEnvironment.transform 3 8 env16996 = env16997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env16996 == env16997) = true)

theorem identity16997 : scanCanonicalize (H12AffineFastState.compose env16997 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound16997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16998 : List Nat := [2,0,0,0,1,0,0,1,512,1,0,0,0,0,1,2,1,0,0,0,1,1,0,3,0,1,0,1,1,0,0,0,0,0,1,512]

theorem envBound16998 : H12AffineFastState.Bounded env16998 := by
  intro p hp
  have h : env16998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16997_16998 : H12AffineEnvironment.transform 2 0 env16997 = env16998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env16997 == env16998) = true)

theorem identity16998 : scanCanonicalize (H12AffineFastState.compose env16998 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound16998 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16999 : List Nat := [0,0,0,0,1,0,0,1,512,1,0,0,0,0,1,0,1,0,0,0,1,1,0,1,0,1,0,1,1,0,0,0,0,0,1,512]

theorem envBound16999 : H12AffineFastState.Bounded env16999 := by
  intro p hp
  have h : env16999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16998_16999 : H12AffineEnvironment.transform 0 0 env16998 = env16999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env16998 == env16999) = true)

theorem identity16999 : scanCanonicalize (H12AffineFastState.compose env16999 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16999 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17000 : List Nat := [0,0,0,0,1,0,0,1,1,1,0,0,0,0,1,0,1,0,0,0,1,1,0,1,0,1,0,1,1,0,0,0,0,0,1,1]

theorem envBound17000 : H12AffineFastState.Bounded env17000 := by
  intro p hp
  have h : env17000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16999_17000 : H12AffineEnvironment.transform 8 1 env16999 = env17000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16999 == env17000) = true)

def env17001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98678,16,98644,8193,65,245019,5393,17665,179513,1365,95531,257,21793,46092,74250]

theorem envBound17001 : H12AffineFastState.Bounded env17001 := by
  intro p hp
  have h : env17001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16983_17001 : H12AffineEnvironment.transform 6 9 env16983 = env17001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16983 == env17001) = true)

theorem identity17001 : scanCanonicalize (H12AffineFastState.compose env17001 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound17001 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4161,21792,16,21762,8193,65,158029,5393,17665,179513,1365,41341,257,21793,46092,63068]

theorem envBound17002 : H12AffineFastState.Bounded env17002 := by
  intro p hp
  have h : env17002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17001_17002 : H12AffineEnvironment.transform 15 54358 env17001 = env17002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env17001 == env17002) = true)

theorem identity17002 : scanCanonicalize (H12AffineFastState.compose env17002 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound17002 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,21792,16,21762,8193,65,158029,5393,17665,149860,1365,21792,257,21793,16465,513]

theorem envBound17003 : H12AffineFastState.Bounded env17003 := by
  intro p hp
  have h : env17003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17002_17003 : H12AffineEnvironment.transform 14 29789 env17002 = env17003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env17002 == env17003) = true)

theorem identity17003 : scanCanonicalize (H12AffineFastState.compose env17003 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 17664) := by decide +kernel

theorem selectedBound17003 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,17664,32041,1025,29788,4161,21792,16,21762,8193,65,11341,5393,17665,3172,1365,21792,257,21793,16465,513]

theorem envBound17004 : H12AffineFastState.Bounded env17004 := by
  intro p hp
  have h : env17004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17003_17004 : H12AffineEnvironment.transform 16 17664 env17003 = env17004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17664 env17003 == env17004) = true)

theorem identity17004 : scanCanonicalize (H12AffineFastState.compose env17004 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17004 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env17005 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29789,8203,17445,31756,1025,29788,4161,21509,16,21543,8193,65,11341,5172,17444,3172,1136,21509,36,21508,16465,513]

theorem envBound17005 : H12AffineFastState.Bounded env17005 := by
  intro p hp
  have h : env17005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17004_17005 : H12AffineEnvironment.transform 7 37 env17004 = env17005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17004 == env17005) = true)

theorem identity17005 : scanCanonicalize (H12AffineFastState.compose env17005 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17005 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env17006 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,4096,8192,16384,29789,8203,17413,31756,1025,29788,4161,21509,16,21511,8193,65,11341,5140,17412,3140,1104,21509,4,21508,16465,513]

theorem envBound17006 : H12AffineFastState.Bounded env17006 := by
  intro p hp
  have h : env17006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17005_17006 : H12AffineEnvironment.transform 4 0 env17005 = env17006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17005 == env17006) = true)

theorem identity17006 : scanCanonicalize (H12AffineFastState.compose env17006 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound17006 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env17007 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,4096,8192,16384,28744,8203,16400,30745,20,28745,4161,20496,16,20498,8193,65,10328,4097,16401,2129,69,20496,4,20497,16465,513]

theorem envBound17007 : H12AffineFastState.Bounded env17007 := by
  intro p hp
  have h : env17007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17006_17007 : H12AffineEnvironment.transform 9 21 env17006 = env17007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17006 == env17007) = true)

theorem identity17007 : scanCanonicalize (H12AffineFastState.compose env17007 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4105) := by decide +kernel

theorem selectedBound17007 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17008 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,4096,4105,16384,16449,4098,16400,18448,20,16448,4161,20496,16,20498,4104,65,6225,4097,16401,2129,69,20496,4,20497,16465,513]

theorem envBound17008 : H12AffineFastState.Bounded env17008 := by
  intro p hp
  have h : env17008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17007_17008 : H12AffineEnvironment.transform 12 4105 env17007 = env17008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4105 env17007 == env17008) = true)

theorem identity17008 : scanCanonicalize (H12AffineFastState.compose env17008 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound17008 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17009 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,513,520,16384,16449,515,16400,18448,20,16448,576,16913,16,16915,521,65,2640,512,16401,2129,69,16913,4,16912,16465,513]

theorem envBound17009 : H12AffineFastState.Bounded env17009 := by
  intro p hp
  have h : env17009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17008_17009 : H12AffineEnvironment.transform 11 513 env17008 = env17009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env17008 == env17009) = true)

def env17010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound17010 : H12AffineFastState.Bounded env17010 := by
  intro p hp
  have h : env17010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15679_17010 : H12AffineEnvironment.transform 29 155254785 env15679 = env17010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env15679 == env17010) = true)

def env17011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound17011 : H12AffineFastState.Bounded env17011 := by
  intro p hp
  have h : env17011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17010_17011 : H12AffineEnvironment.transform 25 64 env17010 = env17011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env17010 == env17011) = true)

def env17012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound17012 : H12AffineFastState.Bounded env17012 := by
  intro p hp
  have h : env17012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17011_17012 : H12AffineEnvironment.transform 26 30393344 env17011 = env17012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env17011 == env17012) = true)

def env17013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound17013 : H12AffineFastState.Bounded env17013 := by
  intro p hp
  have h : env17013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17012_17013 : H12AffineEnvironment.transform 18 1024 env17012 = env17013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17012 == env17013) = true)

theorem identity17013 : scanCanonicalize (H12AffineFastState.compose env17013 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound17013 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,8388608,16777216,8328,64,29843925,18949465,10507601,8806868,25241029,23160256,256,27354488,27337993,25166355]

theorem envBound17014 : H12AffineFastState.Bounded env17014 := by
  intro p hp
  have h : env17014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17013_17014 : H12AffineEnvironment.transform 14 8661 env17013 = env17014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env17013 == env17014) = true)

def env17015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,147456,16777216,8328,64,21307861,18949465,2233681,270804,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound17015 : H12AffineFastState.Bounded env17015 := by
  intro p hp
  have h : env17015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17014_17015 : H12AffineEnvironment.transform 22 147456 env17014 = env17015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env17014 == env17015) = true)

def env17016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1024,8660,2097152,4194304,147456,16777216,8328,64,21039477,18949465,2233681,2420,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound17016 : H12AffineFastState.Bounded env17016 := by
  intro p hp
  have h : env17016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17015_17016 : H12AffineEnvironment.transform 17 10400 env17015 = env17016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17015 == env17016) = true)

theorem identity17016 : scanCanonicalize (H12AffineFastState.compose env17016 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound17016 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1024,8660,2097152,4194304,147456,138,8328,64,4262399,2172371,2233681,2420,222543,6382922,256,2303474,2319747,148121]

theorem envBound17017 : H12AffineFastState.Bounded env17017 := by
  intro p hp
  have h : env17017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17016_17017 : H12AffineEnvironment.transform 23 138 env17016 = env17017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env17016 == env17017) = true)

theorem identity17017 : scanCanonicalize (H12AffineFastState.compose env17017 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17017 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env17018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,131072,10400,1024,8660,2097152,4194304,147456,138,8328,64,4204925,2098513,2233681,2420,148941,6309320,256,2229616,2245889,148121]

theorem envBound17018 : H12AffineFastState.Bounded env17018 := by
  intro p hp
  have h : env17018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17017_17018 : H12AffineEnvironment.transform 15 8322 env17017 = env17018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17017 == env17018) = true)

theorem identity17018 : scanCanonicalize (H12AffineFastState.compose env17018 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17018 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env17019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,131072,10400,1024,8660,2097152,32,147456,138,8328,64,10589,2098513,2233681,2420,148941,2115048,256,2229616,2245889,148121]

theorem envBound17019 : H12AffineFastState.Bounded env17019 := by
  intro p hp
  have h : env17019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17018_17019 : H12AffineEnvironment.transform 21 32 env17018 = env17019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17018 == env17019) = true)

theorem identity17019 : scanCanonicalize (H12AffineFastState.compose env17019 (packedSelected [0,2,3,5,6,10,11,12,14,15,16,17,18,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 12512) := by decide +kernel

theorem selectedBound17019 : packedSelected [0,2,3,5,6,10,11,12,14,15,16,17,18,20,27] rootPS < 2^1333 := by decide +kernel

def env17020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,131072,10400,1024,8660,12512,32,147456,138,8328,64,10589,13745,140721,2420,148941,29960,256,144784,161249,148121]

theorem envBound17020 : H12AffineFastState.Bounded env17020 := by
  intro p hp
  have h : env17020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17019_17020 : H12AffineEnvironment.transform 20 12512 env17019 = env17020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12512 env17019 == env17020) = true)

theorem identity17020 : scanCanonicalize (H12AffineFastState.compose env17020 (packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,16,17,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound17020 : packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,16,17,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env17021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,5309,10400,1024,8660,12512,32,21693,138,8328,64,10589,13745,12556,2420,20848,29960,256,8493,24924,22052]

theorem envBound17021 : H12AffineFastState.Bounded env17021 := by
  intro p hp
  have h : env17021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17020_17021 : H12AffineEnvironment.transform 16 5309 env17020 = env17021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env17020 == env17021) = true)

theorem identity17021 : scanCanonicalize (H12AffineFastState.compose env17021 (packedSelected [10,12,14,15,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound17021 : packedSelected [10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env17022 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,8313,8322,5309,10400,1024,8312,12512,32,21693,138,8328,64,10481,13341,12448,2264,20700,29860,172,8321,24816,22052]

theorem envBound17022 : H12AffineFastState.Bounded env17022 := by
  intro p hp
  have h : env17022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17021_17022 : H12AffineEnvironment.transform 7 172 env17021 = env17022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env17021 == env17022) = true)

theorem identity17022 : scanCanonicalize (H12AffineFastState.compose env17022 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17022 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env17023 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,13405,8313,8322,5309,10400,1024,8312,12512,32,8416,138,8328,64,10481,13341,12448,2264,9345,249,172,8321,5293,8825]

theorem envBound17023 : H12AffineFastState.Bounded env17023 := by
  intro p hp
  have h : env17023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17022_17023 : H12AffineEnvironment.transform 13 13405 env17022 = env17023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17022 == env17023) = true)

theorem identity17023 : scanCanonicalize (H12AffineFastState.compose env17023 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17023 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env17024 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13405,8313,8203,5172,10281,1024,8312,12393,32,8297,3,8193,64,10360,13341,12329,2129,9224,112,37,8200,5156,8825]

theorem envBound17024 : H12AffineFastState.Bounded env17024 := by
  intro p hp
  have h : env17024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17023_17024 : H12AffineEnvironment.transform 6 9 env17023 = env17024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17023 == env17024) = true)

theorem identity17024 : scanCanonicalize (H12AffineFastState.compose env17024 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17024 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env17025 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,8233,8203,5172,10281,1024,8232,12345,32,8249,3,8193,16,10280,13341,12329,2049,9224,32,37,8200,5156,8745]

theorem envBound17025 : H12AffineFastState.Bounded env17025 := by
  intro p hp
  have h : env17025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17024_17025 : H12AffineEnvironment.transform 5 16 env17024 = env17025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17024 == env17025) = true)

theorem identity17025 : scanCanonicalize (H12AffineFastState.compose env17025 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound17025 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env17026 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,34,5172,2048,1024,1,4112,32,16,3,40,16,2049,5172,4096,2049,1057,32,37,33,5156,512]

theorem envBound17026 : H12AffineFastState.Bounded env17026 := by
  intro p hp
  have h : env17026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17025_17026 : H12AffineEnvironment.transform 12 41 env17025 = env17026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env17025 == env17026) = true)

theorem identity17026 : scanCanonicalize (H12AffineFastState.compose env17026 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17027 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5125,0,3,5141,2048,1024,1,4112,1,16,3,9,16,2049,5141,4096,2049,1024,1,4,0,5125,512]

theorem envBound17027 : H12AffineFastState.Bounded env17027 := by
  intro p hp
  have h : env17027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17026_17027 : H12AffineEnvironment.transform 4 1 env17026 = env17027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17026 == env17027) = true)

def env17028 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1045,0,3,1029,2048,1024,1,0,1,16,3,9,16,2049,1029,16,2049,1024,1,4,0,1045,512]

theorem envBound17028 : H12AffineFastState.Bounded env17028 := by
  intro p hp
  have h : env17028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17027_17028 : H12AffineEnvironment.transform 11 16 env17027 = env17028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17027 == env17028) = true)

def env17029 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,1,0,3,17,2048,20,1,0,1,16,3,9,16,2049,17,16,2049,20,1,4,0,1,512]

theorem envBound17029 : H12AffineFastState.Bounded env17029 := by
  intro p hp
  have h : env17029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17028_17029 : H12AffineEnvironment.transform 9 20 env17028 = env17029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17028 == env17029) = true)

theorem identity17029 : scanCanonicalize (H12AffineFastState.compose env17029 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound17029 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17030 : List Nat := [2,4,8,16,1,16,9,4,30,20,2048,16,8,1,0,3,17,2048,20,1,0,1,16,3,9,16,2049,17,16,2049,20,1,4,0,1,30]

theorem envBound17030 : H12AffineFastState.Bounded env17030 := by
  intro p hp
  have h : env17030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17029_17030 : H12AffineEnvironment.transform 8 30 env17029 = env17030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env17029 == env17030) = true)

def leafEnv17030 : List Nat := [2,4,8,16,1,16,9,4,30,20,2048,16,8,1,0,3,17,2048,20,1,0,1,16,3,20,9,1,16,2049,17,16,2049,20,1,4,0,4,2,1,30,1,0,0]

def active17030 : List Nat := [0,1,2,3,10]

def tree17030 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17030 : H12WitnessSearch.Good tree17030 := H12GlobalWitnessIndex.good

theorem leafIdentity17030 : H12AffineFastState.composeSystem env17030 rootObs = leafEnv17030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17030 rootObs == leafEnv17030) = true)

theorem terminalChecked17030 : H12PackedTerminal.terminalCheckFast leafEnv17030 active17030 tree17030 = true := by decide +kernel

def env17031 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,0,0,3,16,2048,21,1,0,1,16,3,9,16,2049,16,16,2049,21,1,4,0,0,512]

theorem envBound17031 : H12AffineFastState.Bounded env17031 := by
  intro p hp
  have h : env17031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17028_17031 : H12AffineEnvironment.transform 9 21 env17028 = env17031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env17028 == env17031) = true)

theorem identity17031 : scanCanonicalize (H12AffineFastState.compose env17031 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound17031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17032 : List Nat := [2,4,8,4,1,4,9,4,512,1,2048,4,8,0,0,3,4,2048,1,1,0,1,4,3,9,4,2049,4,4,2049,1,1,4,0,0,512]

theorem envBound17032 : H12AffineFastState.Bounded env17032 := by
  intro p hp
  have h : env17032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17031_17032 : H12AffineEnvironment.transform 3 4 env17031 = env17032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env17031 == env17032) = true)

def leafEnv17032 : List Nat := [2,4,8,4,1,4,9,4,512,1,2048,4,8,0,0,3,4,2048,1,1,0,1,4,3,1,9,1,4,2049,4,4,2049,1,1,4,0,4,2,0,512,1,0,0]

def active17032 : List Nat := [0,1,2,8,10]

def tree17032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17032 : H12WitnessSearch.Good tree17032 := H12GlobalWitnessIndex.good

theorem leafIdentity17032 : H12AffineFastState.composeSystem env17032 rootObs = leafEnv17032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17032 rootObs == leafEnv17032) = true)

theorem terminalChecked17032 : H12PackedTerminal.terminalCheckFast leafEnv17032 active17032 tree17032 = true := by decide +kernel

def env17033 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1044,0,3,1028,2048,1024,1,1,1,16,3,9,16,2049,1028,17,2049,1024,1,4,0,1044,512]

theorem envBound17033 : H12AffineFastState.Bounded env17033 := by
  intro p hp
  have h : env17033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17027_17033 : H12AffineEnvironment.transform 11 17 env17027 = env17033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env17027 == env17033) = true)

theorem identity17033 : scanCanonicalize (H12AffineFastState.compose env17033 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound17033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17034 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,0,0,3,16,2048,20,1,1,1,16,3,9,16,2049,16,17,2049,20,1,4,0,0,512]

theorem envBound17034 : H12AffineFastState.Bounded env17034 := by
  intro p hp
  have h : env17034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17033_17034 : H12AffineEnvironment.transform 9 20 env17033 = env17034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17033 == env17034) = true)

theorem identity17034 : scanCanonicalize (H12AffineFastState.compose env17034 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound17034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17035 : List Nat := [2,4,8,16,1,16,9,4,31,20,2048,17,8,0,0,3,16,2048,20,1,1,1,16,3,9,16,2049,16,17,2049,20,1,4,0,0,31]

theorem envBound17035 : H12AffineFastState.Bounded env17035 := by
  intro p hp
  have h : env17035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17034_17035 : H12AffineEnvironment.transform 8 31 env17034 = env17035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env17034 == env17035) = true)

def leafEnv17035 : List Nat := [2,4,8,16,1,16,9,4,31,20,2048,17,8,0,0,3,16,2048,20,1,1,1,16,3,20,9,1,16,2049,16,17,2049,20,1,4,0,4,2,0,31,1,1,0]

def active17035 : List Nat := [0,1,2,3,10]

def tree17035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17035 : H12WitnessSearch.Good tree17035 := H12GlobalWitnessIndex.good

theorem leafIdentity17035 : H12AffineFastState.composeSystem env17035 rootObs = leafEnv17035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17035 rootObs == leafEnv17035) = true)

theorem terminalChecked17035 : H12PackedTerminal.terminalCheckFast leafEnv17035 active17035 tree17035 = true := by decide +kernel

def env17036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1024,8660,2097152,4194304,147456,16777216,8328,64,21039476,18949465,2233681,2421,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound17036 : H12AffineFastState.Bounded env17036 := by
  intro p hp
  have h : env17036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17015_17036 : H12AffineEnvironment.transform 17 10401 env17015 = env17036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17015 == env17036) = true)

theorem identity17036 : scanCanonicalize (H12AffineFastState.compose env17036 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 147610) := by decide +kernel

theorem selectedBound17036 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1024,8660,2097152,4194304,147456,147610,8328,64,4409838,2319811,2233681,2421,75103,6497626,256,2188770,2172307,649]

theorem envBound17037 : H12AffineFastState.Bounded env17037 := by
  intro p hp
  have h : env17037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17036_17037 : H12AffineEnvironment.transform 23 147610 env17036 = env17037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147610 env17036 == env17037) = true)

theorem identity17037 : scanCanonicalize (H12AffineFastState.compose env17037 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17037 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,147474,8192,64,4409702,2319691,2233681,2421,75103,6497626,256,2188650,2172187,513]

theorem envBound17038 : H12AffineFastState.Bounded env17038 := by
  intro p hp
  have h : env17038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17037_17038 : H12AffineEnvironment.transform 6 8 env17037 = env17038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17037 == env17038) = true)

theorem identity17038 : scanCanonicalize (H12AffineFastState.compose env17038 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound17038 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env17039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,25629,4194304,147456,147474,8192,64,4409702,196950,160076,2421,75103,4407623,256,65911,82182,513]

theorem envBound17039 : H12AffineFastState.Bounded env17039 := by
  intro p hp
  have h : env17039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17038_17039 : H12AffineEnvironment.transform 20 25629 env17038 = env17039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env17038 == env17039) = true)

theorem identity17039 : scanCanonicalize (H12AffineFastState.compose env17039 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound17039 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env17040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,25629,4194304,16,2,8192,64,4262262,82246,12636,2421,75103,4260183,256,65911,82182,513]

theorem envBound17040 : H12AffineFastState.Bounded env17040 := by
  intro p hp
  have h : env17040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17039_17040 : H12AffineEnvironment.transform 16 16400 env17039 = env17040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17039 == env17040) = true)

theorem identity17040 : scanCanonicalize (H12AffineFastState.compose env17040 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound17040 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env17041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,25629,8572,16,2,8192,64,75786,82246,12636,2421,75103,73771,256,65911,82182,513]

theorem envBound17041 : H12AffineFastState.Bounded env17041 := by
  intro p hp
  have h : env17041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17040_17041 : H12AffineEnvironment.transform 21 8572 env17040 = env17041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env17040 == env17041) = true)

theorem identity17041 : scanCanonicalize (H12AffineFastState.compose env17041 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound17041 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env17042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,16400,10281,1024,8540,25629,8572,16,2,8192,64,10588,16400,12636,2421,9225,8573,256,33,16464,513]

theorem envBound17042 : H12AffineFastState.Bounded env17042 := by
  intro p hp
  have h : env17042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17041_17042 : H12AffineEnvironment.transform 15 342 env17041 = env17042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env17041 == env17042) = true)

theorem identity17042 : scanCanonicalize (H12AffineFastState.compose env17042 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 8525) := by decide +kernel

theorem selectedBound17042 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env17043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8525,8541,342,8541,10281,1024,8540,1360,8572,16,2,8192,64,10588,8541,12636,2421,9225,8573,256,33,8477,513]

theorem envBound17043 : H12AffineFastState.Bounded env17043 := by
  intro p hp
  have h : env17043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17042_17043 : H12AffineEnvironment.transform 13 8525 env17042 = env17043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8525 env17042 == env17043) = true)

theorem identity17043 : scanCanonicalize (H12AffineFastState.compose env17043 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17043 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16,0,342,0,2420,1024,1,1360,33,16,2,349,64,2049,0,4097,2421,1364,32,256,33,64,513]

theorem envBound17044 : H12AffineFastState.Bounded env17044 := by
  intro p hp
  have h : env17044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17043_17044 : H12AffineEnvironment.transform 12 349 env17043 = env17044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17043 == env17044) = true)

theorem identity17044 : scanCanonicalize (H12AffineFastState.compose env17044 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound17044 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2350,349,16,0,342,0,2420,1024,1,1360,33,16,2,349,64,2049,0,2351,2421,1364,32,256,33,64,513]

theorem envBound17045 : H12AffineFastState.Bounded env17045 := by
  intro p hp
  have h : env17045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17044_17045 : H12AffineEnvironment.transform 11 2350 env17044 = env17045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env17044 == env17045) = true)

theorem identity17045 : scanCanonicalize (H12AffineFastState.compose env17045 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17045 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17046 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2350,268,16,0,263,0,2341,1024,1,1281,33,16,2,268,17,2049,0,2351,2340,1285,32,256,33,17,513]

theorem envBound17046 : H12AffineFastState.Bounded env17046 := by
  intro p hp
  have h : env17046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17045_17046 : H12AffineEnvironment.transform 5 17 env17045 = env17046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17045 == env17046) = true)

theorem identity17046 : scanCanonicalize (H12AffineFastState.compose env17046 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17046 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17047 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2350,268,16,0,263,0,2341,53,1,308,33,16,2,268,17,2049,0,2351,2340,304,32,256,33,17,513]

theorem envBound17047 : H12AffineFastState.Bounded env17047 := by
  intro p hp
  have h : env17047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17046_17047 : H12AffineEnvironment.transform 9 53 env17046 = env17047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17046 == env17047) = true)

theorem identity17047 : scanCanonicalize (H12AffineFastState.compose env17047 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 291) := by decide +kernel

theorem selectedBound17047 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17048 : List Nat := [2,4,8,16,32,17,8,256,291,53,2048,2350,268,16,0,263,0,2341,53,1,308,33,16,2,268,17,2049,0,2351,2340,304,32,256,33,17,290]

theorem envBound17048 : H12AffineFastState.Bounded env17048 := by
  intro p hp
  have h : env17048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17047_17048 : H12AffineEnvironment.transform 8 291 env17047 = env17048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 291 env17047 == env17048) = true)

theorem identity17048 : scanCanonicalize (H12AffineFastState.compose env17048 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound17048 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17049 : List Nat := [2,4,8,16,32,17,8,14,45,53,2048,2080,2,16,0,9,0,2091,53,1,58,33,16,2,2,17,2049,0,2081,2090,62,32,14,33,17,44]

theorem envBound17049 : H12AffineFastState.Bounded env17049 := by
  intro p hp
  have h : env17049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17048_17049 : H12AffineEnvironment.transform 7 14 env17048 = env17049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env17048 == env17049) = true)

theorem identity17049 : scanCanonicalize (H12AffineFastState.compose env17049 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17049 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env17050 : List Nat := [2,4,8,16,16,17,8,14,29,5,2048,2064,2,16,0,9,0,2075,5,1,10,17,16,2,2,17,2049,0,2065,2074,14,16,14,17,17,28]

theorem envBound17050 : H12AffineFastState.Bounded env17050 := by
  intro p hp
  have h : env17050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17049_17050 : H12AffineEnvironment.transform 4 16 env17049 = env17050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17049 == env17050) = true)

def env17051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,147457,16777216,8328,64,21307860,18949465,2233680,270805,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound17051 : H12AffineFastState.Bounded env17051 := by
  intro p hp
  have h : env17051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17014_17051 : H12AffineEnvironment.transform 22 147457 env17014 = env17051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env17014 == env17051) = true)

theorem identity17051 : scanCanonicalize (H12AffineFastState.compose env17051 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound17051 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,147457,147475,8328,64,4678087,2319690,2233680,270805,75223,6497747,256,2188650,2172187,513]

theorem envBound17052 : H12AffineFastState.Bounded env17052 := by
  intro p hp
  have h : env17052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17051_17052 : H12AffineEnvironment.transform 23 147475 env17051 = env17052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env17051 == env17052) = true)

def env17053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1024,8660,2097152,4194304,147457,147475,8328,64,4409703,2319690,2233680,2421,75223,6497747,256,2188650,2172187,513]

theorem envBound17053 : H12AffineFastState.Bounded env17053 := by
  intro p hp
  have h : env17053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17052_17053 : H12AffineEnvironment.transform 17 10400 env17052 = env17053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17052 == env17053) = true)

theorem identity17053 : scanCanonicalize (H12AffineFastState.compose env17053 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound17053 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1024,8660,2097152,4194304,152,138,8328,64,4262398,2172371,2119113,2421,75223,6382922,256,2188650,2172187,513]

theorem envBound17054 : H12AffineFastState.Bounded env17054 := by
  intro p hp
  have h : env17054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17053_17054 : H12AffineEnvironment.transform 16 16537 env17053 = env17054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env17053 == env17054) = true)

theorem identity17054 : scanCanonicalize (H12AffineFastState.compose env17054 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound17054 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env17055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,16537,10400,1024,8660,2097152,4194304,152,138,8328,64,4204925,2098512,2119113,2421,1364,6309321,256,2115049,2098584,513]

theorem envBound17055 : H12AffineFastState.Bounded env17055 := by
  intro p hp
  have h : env17055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17054_17055 : H12AffineEnvironment.transform 15 8323 env17054 = env17055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env17054 == env17055) = true)

theorem identity17055 : scanCanonicalize (H12AffineFastState.compose env17055 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17055 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env17056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8661,8323,4232,10400,1024,8660,2097152,4194304,152,138,8328,64,4204925,2098512,2098648,2421,1364,6297048,256,2102776,2098584,513]

theorem envBound17056 : H12AffineFastState.Bounded env17056 := by
  intro p hp
  have h : env17056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17055_17056 : H12AffineEnvironment.transform 13 4113 env17055 = env17056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env17055 == env17056) = true)

theorem identity17056 : scanCanonicalize (H12AffineFastState.compose env17056 (packedSelected [1,5,10,11,12,15,17,23,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 2101661) := by decide +kernel

theorem selectedBound17056 : packedSelected [1,5,10,11,12,15,17,23,24,28] rootPS < 2^1333 := by decide +kernel

def env17057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8661,8323,4232,10400,1024,8660,2097152,2101661,152,138,8328,64,2111712,2098512,2098648,2421,1364,1093,256,2102776,2098584,513]

theorem envBound17057 : H12AffineFastState.Bounded env17057 := by
  intro p hp
  have h : env17057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17056_17057 : H12AffineEnvironment.transform 21 2101661 env17056 = env17057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101661 env17056 == env17057) = true)

theorem identity17057 : scanCanonicalize (H12AffineFastState.compose env17057 (packedSelected [1,2,5,6,10,11,12,14,17,23] rootPS)) = affineNative (2^(20+1) ^^^ 429) := by decide +kernel

theorem selectedBound17057 : packedSelected [1,2,5,6,10,11,12,14,17,23] rootPS < 2^1333 := by decide +kernel

def env17058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8661,8323,4232,10400,1024,8660,429,4144,152,138,8328,64,14669,1277,1141,2421,1364,1093,256,5205,1077,513]

theorem envBound17058 : H12AffineFastState.Bounded env17058 := by
  intro p hp
  have h : env17058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17057_17058 : H12AffineEnvironment.transform 20 429 env17057 = env17058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 429 env17057 == env17058) = true)

theorem identity17058 : scanCanonicalize (H12AffineFastState.compose env17058 (packedSelected [3,4,5,7,9,10,11,18,27] rootPS)) = affineNative (2^(12+1) ^^^ 4200) := by decide +kernel

theorem selectedBound17058 : packedSelected [3,4,5,7,9,10,11,18,27] rootPS < 2^1333 := by decide +kernel

def env17059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,4200,4113,4541,4331,4232,6344,1024,4540,429,4144,152,138,4320,64,2341,1277,1141,2421,1364,1093,256,5205,1077,513]

theorem envBound17059 : H12AffineFastState.Bounded env17059 := by
  intro p hp
  have h : env17059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17058_17059 : H12AffineEnvironment.transform 12 4200 env17058 = env17059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4200 env17058 == env17059) = true)

theorem identity17059 : scanCanonicalize (H12AffineFastState.compose env17059 (packedSelected [0,1,2,4,5,6,7,8,9,12,14,24] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound17059 : packedSelected [0,1,2,4,5,6,7,8,9,12,14,24] rootPS < 2^1333 := by decide +kernel

def env17060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1061,1101,1076,1432,1230,1197,3309,1024,1433,429,1045,152,138,1221,64,2341,1277,1141,2421,1364,1093,256,112,1077,513]

theorem envBound17060 : H12AffineFastState.Bounded env17060 := by
  intro p hp
  have h : env17060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17059_17060 : H12AffineEnvironment.transform 11 1061 env17059 = env17060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env17059 == env17060) = true)

theorem identity17060 : scanCanonicalize (H12AffineFastState.compose env17060 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound17060 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,292,1061,1101,1076,1432,1230,1197,1481,1024,1433,429,1045,152,138,1221,64,1,1277,1141,81,1364,1093,256,112,1077,513]

theorem envBound17061 : H12AffineFastState.Bounded env17061 := by
  intro p hp
  have h : env17061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17060_17061 : H12AffineEnvironment.transform 10 292 env17060 = env17061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env17060 == env17061) = true)

theorem identity17061 : scanCanonicalize (H12AffineFastState.compose env17061 (packedSelected [0,1,2,5,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound17061 : packedSelected [0,1,2,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env17062 : List Nat := [2,4,8,16,32,64,128,256,512,409,292,444,468,429,1,343,308,80,409,0,429,396,152,138,348,64,1,356,492,81,205,476,256,112,428,513]

theorem envBound17062 : H12AffineFastState.Bounded env17062 := by
  intro p hp
  have h : env17062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17061_17062 : H12AffineEnvironment.transform 9 409 env17061 = env17062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env17061 == env17062) = true)

def env17063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1024,8660,2097152,4194304,147457,147475,8328,64,4409702,2319690,2233680,2420,75223,6497747,256,2188650,2172187,513]

theorem envBound17063 : H12AffineFastState.Bounded env17063 := by
  intro p hp
  have h : env17063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17052_17063 : H12AffineEnvironment.transform 17 10401 env17052 = env17063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17052 == env17063) = true)

theorem identity17063 : scanCanonicalize (H12AffineFastState.compose env17063 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17063 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,147475,8192,64,4409702,2319690,2233680,2420,75103,6497627,256,2188650,2172187,513]

theorem envBound17064 : H12AffineFastState.Bounded env17064 := by
  intro p hp
  have h : env17064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17063_17064 : H12AffineEnvironment.transform 6 8 env17063 = env17064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17063 == env17064) = true)

def env17065 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147457,147475,8192,16,4409654,2319642,2233600,2340,75023,6497547,256,2188602,2172187,513]

theorem envBound17065 : H12AffineFastState.Bounded env17065 := by
  intro p hp
  have h : env17065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17064_17065 : H12AffineEnvironment.transform 5 16 env17064 = env17065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17064 == env17065) = true)

theorem identity17065 : scanCanonicalize (H12AffineFastState.compose env17065 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 213303) := by decide +kernel

theorem selectedBound17065 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env17066 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,213303,147457,147475,8192,16,2049,2319642,2233600,2340,75023,2122812,256,2188602,2172187,513]

theorem envBound17066 : H12AffineFastState.Bounded env17066 := by
  intro p hp
  have h : env17066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17065_17066 : H12AffineEnvironment.transform 21 213303 env17065 = env17066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213303 env17065 == env17066) = true)

theorem identity17066 : scanCanonicalize (H12AffineFastState.compose env17066 (packedSelected [1,2,6,8,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17066 : packedSelected [1,2,6,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17067 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,2097152,213303,147457,147475,269,16,2049,2311191,2233600,2340,66562,2114865,256,2180151,2163734,513]

theorem envBound17067 : H12AffineFastState.Bounded env17067 := by
  intro p hp
  have h : env17067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17066_17067 : H12AffineEnvironment.transform 12 269 env17066 = env17067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17066 == env17067) = true)

theorem identity17067 : scanCanonicalize (H12AffineFastState.compose env17067 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 132352) := by decide +kernel

theorem selectedBound17067 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17068 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,132352,213303,147457,147475,269,16,2049,82199,4096,2340,66562,147505,256,213303,196886,513]

theorem envBound17068 : H12AffineFastState.Bounded env17068 := by
  intro p hp
  have h : env17068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17067_17068 : H12AffineEnvironment.transform 20 132352 env17067 = env17068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132352 env17067 == env17068) = true)

theorem identity17068 : scanCanonicalize (H12AffineFastState.compose env17068 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound17068 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17069 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,65536,16401,2340,1024,1,17681,65830,16,2,269,16,2049,82199,4096,2340,66562,32,256,65830,82183,513]

theorem envBound17069 : H12AffineFastState.Bounded env17069 := by
  intro p hp
  have h : env17069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17068_17069 : H12AffineEnvironment.transform 16 16401 env17068 = env17069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17068 == env17069) = true)

theorem identity17069 : scanCanonicalize (H12AffineFastState.compose env17069 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(15+1) ^^^ 24371) := by decide +kernel

theorem selectedBound17069 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env17070 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,24371,16401,2340,1024,1,17681,24085,16,2,269,16,2049,7716,4096,2340,23345,32,256,24085,7732,513]

theorem envBound17070 : H12AffineFastState.Bounded env17070 := by
  intro p hp
  have h : env17070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17069_17070 : H12AffineEnvironment.transform 15 24371 env17069 = env17070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24371 env17069 == env17070) = true)

theorem identity17070 : scanCanonicalize (H12AffineFastState.compose env17070 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 7732) := by decide +kernel

theorem selectedBound17070 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env17071 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7732,0,263,7717,2340,1024,1,6949,33,16,2,269,16,2049,7716,4096,2340,1285,32,256,33,7732,513]

theorem envBound17071 : H12AffineFastState.Bounded env17071 := by
  intro p hp
  have h : env17071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17070_17071 : H12AffineEnvironment.transform 13 7732 env17070 = env17071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7732 env17070 == env17071) = true)

theorem identity17071 : scanCanonicalize (H12AffineFastState.compose env17071 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound17071 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,276,269,3872,0,263,3889,2340,1024,1,2609,33,16,2,269,16,2049,3888,276,2340,1285,32,256,33,3872,513]

theorem envBound17072 : H12AffineFastState.Bounded env17072 := by
  intro p hp
  have h : env17072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17071_17072 : H12AffineEnvironment.transform 11 276 env17071 = env17072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env17071 == env17072) = true)

theorem identity17072 : scanCanonicalize (H12AffineFastState.compose env17072 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound17072 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17073 : List Nat := [2,4,8,16,32,16,8,256,512,298,2048,276,269,2570,0,263,2587,2340,298,1,2609,33,16,2,269,16,2049,2586,276,2340,47,32,256,33,2570,513]

theorem envBound17073 : H12AffineFastState.Bounded env17073 := by
  intro p hp
  have h : env17073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17072_17073 : H12AffineEnvironment.transform 9 298 env17072 = env17073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env17072 == env17073) = true)

theorem identity17073 : scanCanonicalize (H12AffineFastState.compose env17073 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound17073 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17074 : List Nat := [2,4,8,16,32,16,8,256,58,298,2048,276,269,2096,0,263,2081,2340,298,1,2059,33,16,2,269,16,2049,2080,276,2340,47,32,256,33,2096,59]

theorem envBound17074 : H12AffineFastState.Bounded env17074 := by
  intro p hp
  have h : env17074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17073_17074 : H12AffineEnvironment.transform 8 58 env17073 = env17074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env17073 == env17074) = true)

theorem identity17074 : scanCanonicalize (H12AffineFastState.compose env17074 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound17074 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17075 : List Nat := [2,4,3,16,32,16,3,256,49,289,2048,276,262,2096,0,263,2081,2340,289,1,2048,33,16,2,262,16,2049,2080,276,2340,36,32,256,33,2096,48]

theorem envBound17075 : H12AffineFastState.Bounded env17075 := by
  intro p hp
  have h : env17075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17074_17075 : H12AffineEnvironment.transform 2 3 env17074 = env17075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env17074 == env17075) = true)

theorem identity17075 : scanCanonicalize (H12AffineFastState.compose env17075 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound17075 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17076 : List Nat := [2,4,3,16,32,16,3,256,49,289,48,276,262,0,0,263,17,276,289,1,48,33,16,2,262,16,49,16,276,276,36,32,256,33,0,48]

theorem envBound17076 : H12AffineFastState.Bounded env17076 := by
  intro p hp
  have h : env17076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17075_17076 : H12AffineEnvironment.transform 10 48 env17075 = env17076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env17075 == env17076) = true)

theorem identity17076 : scanCanonicalize (H12AffineFastState.compose env17076 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound17076 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env17077 : List Nat := [2,4,3,16,32,16,3,20,49,53,48,0,18,0,0,19,17,0,53,1,48,33,16,2,18,16,49,16,0,0,36,32,20,33,0,48]

theorem envBound17077 : H12AffineFastState.Bounded env17077 := by
  intro p hp
  have h : env17077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17076_17077 : H12AffineEnvironment.transform 7 20 env17076 = env17077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env17076 == env17077) = true)

theorem identity17077 : scanCanonicalize (H12AffineFastState.compose env17077 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound17077 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17078 : List Nat := [2,4,3,7,32,7,3,3,38,34,39,0,5,0,0,4,6,0,34,1,39,33,7,2,5,7,38,7,0,0,36,32,3,33,0,39]

theorem envBound17078 : H12AffineFastState.Bounded env17078 := by
  intro p hp
  have h : env17078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17077_17078 : H12AffineEnvironment.transform 3 7 env17077 = env17078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env17077 == env17078) = true)

def env17079 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147457,147475,8192,17,4409655,2319643,2233601,2341,75022,6497546,256,2188603,2172187,513]

theorem envBound17079 : H12AffineFastState.Bounded env17079 := by
  intro p hp
  have h : env17079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17064_17079 : H12AffineEnvironment.transform 5 17 env17064 = env17079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17064 == env17079) = true)

theorem identity17079 : scanCanonicalize (H12AffineFastState.compose env17079 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound17079 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env17080 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,8493,147457,147475,8192,17,223258,2319643,2233601,2341,75022,2294823,256,2188603,2172187,513]

theorem envBound17080 : H12AffineFastState.Bounded env17080 := by
  intro p hp
  have h : env17080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17079_17080 : H12AffineEnvironment.transform 21 8493 env17079 = env17080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env17079 == env17080) = true)

theorem identity17080 : scanCanonicalize (H12AffineFastState.compose env17080 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 197638) := by decide +kernel

theorem selectedBound17080 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17081 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,197638,8493,147457,147475,8192,17,223258,24861,69895,2341,75022,33,256,155965,139549,513]

theorem envBound17081 : H12AffineFastState.Bounded env17081 := by
  intro p hp
  have h : env17081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17080_17081 : H12AffineEnvironment.transform 20 197638 env17080 = env17081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197638 env17080 == env17081) = true)

theorem identity17081 : scanCanonicalize (H12AffineFastState.compose env17081 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound17081 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env17082 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24860,10281,1024,8461,91418,8493,8477,8463,8192,17,67846,24861,69895,2341,75022,33,256,33,16385,513]

theorem envBound17082 : H12AffineFastState.Bounded env17082 := by
  intro p hp
  have h : env17082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17081_17082 : H12AffineEnvironment.transform 16 24860 env17081 = env17082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env17081 == env17082) = true)

theorem identity17082 : scanCanonicalize (H12AffineFastState.compose env17082 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17082 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17083 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,65536,16400,2341,1024,1,82966,33,17,3,268,17,67846,16401,69895,2341,66562,33,256,33,16385,513]

theorem envBound17083 : H12AffineFastState.Bounded env17083 := by
  intro p hp
  have h : env17083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17082_17083 : H12AffineEnvironment.transform 12 268 env17082 = env17083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17082 == env17083) = true)

theorem identity17083 : scanCanonicalize (H12AffineFastState.compose env17083 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17083 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17084 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16400,2341,1024,1,17681,33,17,3,268,17,2049,16401,4096,2341,1285,33,256,33,16385,513]

theorem envBound17084 : H12AffineFastState.Bounded env17084 := by
  intro p hp
  have h : env17084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17083_17084 : H12AffineEnvironment.transform 15 263 env17083 = env17084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17083 == env17084) = true)

theorem identity17084 : scanCanonicalize (H12AffineFastState.compose env17084 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17084 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17085 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4113,33,17,3,268,17,2049,5393,4096,2341,1285,33,256,33,5377,513]

theorem envBound17085 : H12AffineFastState.Bounded env17085 := by
  intro p hp
  have h : env17085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17084_17085 : H12AffineEnvironment.transform 13 5376 env17084 = env17085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17084 == env17085) = true)

theorem identity17085 : scanCanonicalize (H12AffineFastState.compose env17085 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2879) := by decide +kernel

theorem selectedBound17085 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17086 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2879,268,3647,0,263,3631,2341,1024,1,2862,33,17,3,268,17,2049,3630,2879,2341,1285,33,256,33,3646,513]

theorem envBound17086 : H12AffineFastState.Bounded env17086 := by
  intro p hp
  have h : env17086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17085_17086 : H12AffineEnvironment.transform 11 2879 env17085 = env17086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2879 env17085 == env17086) = true)

theorem identity17086 : scanCanonicalize (H12AffineFastState.compose env17086 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17086 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17087 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,2619,8,3647,0,3,3631,2081,1024,1,2602,33,17,3,8,17,2049,3630,2619,2081,1025,33,4,33,3646,513]

theorem envBound17087 : H12AffineFastState.Bounded env17087 := by
  intro p hp
  have h : env17087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17086_17087 : H12AffineEnvironment.transform 7 4 env17086 = env17087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17086 == env17087) = true)

theorem identity17087 : scanCanonicalize (H12AffineFastState.compose env17087 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound17087 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17088 : List Nat := [2,4,8,16,32,17,8,4,512,1024,1566,1061,8,33,0,3,49,1599,1024,1,1076,33,17,3,8,17,1567,48,1061,1599,1025,33,4,33,32,513]

theorem envBound17088 : H12AffineFastState.Bounded env17088 := by
  intro p hp
  have h : env17088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17087_17088 : H12AffineEnvironment.transform 10 1566 env17087 = env17088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env17087 == env17088) = true)

theorem identity17088 : scanCanonicalize (H12AffineFastState.compose env17088 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound17088 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17089 : List Nat := [2,4,8,16,32,17,8,4,512,543,1,570,8,33,0,3,49,32,543,1,555,33,17,3,8,17,0,48,570,32,542,33,4,33,32,513]

theorem envBound17089 : H12AffineFastState.Bounded env17089 := by
  intro p hp
  have h : env17089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17088_17089 : H12AffineEnvironment.transform 9 543 env17088 = env17089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env17088 == env17089) = true)

theorem identity17089 : scanCanonicalize (H12AffineFastState.compose env17089 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17089 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env17090 : List Nat := [2,4,8,16,1,17,8,4,512,543,1,539,8,0,0,3,16,1,543,1,522,0,17,3,8,17,0,17,539,1,542,0,4,0,1,513]

theorem envBound17090 : H12AffineFastState.Bounded env17090 := by
  intro p hp
  have h : env17090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17089_17090 : H12AffineEnvironment.transform 4 1 env17089 = env17090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17089 == env17090) = true)

theorem identity17090 : scanCanonicalize (H12AffineFastState.compose env17090 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound17090 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17091 : List Nat := [2,4,8,14,1,15,8,4,512,513,1,517,8,0,0,3,14,1,513,1,522,0,15,3,8,15,0,15,517,1,512,0,4,0,1,513]

theorem envBound17091 : H12AffineFastState.Bounded env17091 := by
  intro p hp
  have h : env17091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17090_17091 : H12AffineEnvironment.transform 3 14 env17090 = env17091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env17090 == env17091) = true)

theorem identity17091 : scanCanonicalize (H12AffineFastState.compose env17091 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound17091 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17092 : List Nat := [2,4,8,14,1,15,8,4,8,9,1,13,8,0,0,3,14,1,9,1,2,0,15,3,8,15,0,15,13,1,8,0,4,0,1,9]

theorem envBound17092 : H12AffineFastState.Bounded env17092 := by
  intro p hp
  have h : env17092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17091_17092 : H12AffineEnvironment.transform 8 8 env17091 = env17092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env17091 == env17092) = true)

def env17093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound17093 : H12AffineFastState.Bounded env17093 := by
  intro p hp
  have h : env17093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17012_17093 : H12AffineEnvironment.transform 18 1025 env17012 = env17093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17012 == env17093) = true)

theorem identity17093 : scanCanonicalize (H12AffineFastState.compose env17093 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8601940) := by decide +kernel

theorem selectedBound17093 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8601940,8328,64,4489557,10667481,10507601,8830976,181572,14820500,257,2262520,2253917,254611]

theorem envBound17094 : H12AffineFastState.Bounded env17094 := by
  intro p hp
  have h : env17094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17093_17094 : H12AffineEnvironment.transform 23 8601940 env17093 = env17094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8601940 env17093 == env17094) = true)

def env17095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,8388608,8601940,8328,64,4489557,8393985,8553865,8830976,181572,12645452,257,21792,46213,254611]

theorem envBound17095 : H12AffineFastState.Bounded env17095 := by
  intro p hp
  have h : env17095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17094_17095 : H12AffineEnvironment.transform 20 184536 env17094 = env17095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env17094 == env17095) = true)

def env17096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,98780,8328,64,4489557,185737,17665,262280,181572,4338884,257,21792,46213,254611]

theorem envBound17096 : H12AffineFastState.Bounded env17096 := by
  intro p hp
  have h : env17096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17095_17096 : H12AffineEnvironment.transform 22 180360 env17095 = env17096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env17095 == env17096) = true)

def env17097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,98780,8328,64,43477,185737,17665,262280,181572,400452,257,21792,46213,254611]

theorem envBound17097 : H12AffineFastState.Bounded env17097 := by
  intro p hp
  have h : env17097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17096_17097 : H12AffineEnvironment.transform 21 272512 env17096 = env17097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17096 == env17097) = true)

theorem identity17097 : scanCanonicalize (H12AffineFastState.compose env17097 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound17097 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4161,272512,17,98780,8328,64,43477,5392,17665,262280,1501,318685,257,21792,46213,74250]

theorem envBound17098 : H12AffineFastState.Bounded env17098 := by
  intro p hp
  have h : env17098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17097_17098 : H12AffineEnvironment.transform 16 49305 env17097 = env17098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env17097 == env17098) = true)

theorem identity17098 : scanCanonicalize (H12AffineFastState.compose env17098 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17098 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,4161,272512,17,41431,8328,64,43477,5392,17665,262280,1501,318685,257,21792,46213,513]

theorem envBound17099 : H12AffineFastState.Bounded env17099 := by
  intro p hp
  have h : env17099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17098_17099 : H12AffineEnvironment.transform 15 8203 env17098 = env17099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17098 == env17099) = true)

def env17100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,98780,8328,64,43476,185737,17665,262280,181572,400453,257,21792,46213,254611]

theorem envBound17100 : H12AffineFastState.Bounded env17100 := by
  intro p hp
  have h : env17100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17096_17100 : H12AffineEnvironment.transform 21 272513 env17096 = env17100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17096 == env17100) = true)

def env17101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180224,98644,8192,64,43356,185601,17665,262144,181572,400453,257,21792,46093,254491]

theorem envBound17101 : H12AffineFastState.Bounded env17101 := by
  intro p hp
  have h : env17101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17100_17101 : H12AffineEnvironment.transform 6 8 env17100 = env17101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17100 == env17101) = true)

theorem identity17101 : scanCanonicalize (H12AffineFastState.compose env17101 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound17101 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,36928,272393,32784,98644,8192,64,43356,38161,17665,262144,34132,285781,257,21792,46093,107019]

theorem envBound17102 : H12AffineFastState.Bounded env17102 := by
  intro p hp
  have h : env17102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17101_17102 : H12AffineEnvironment.transform 16 16400 env17101 = env17102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17101 == env17102) = true)

theorem identity17102 : scanCanonicalize (H12AffineFastState.compose env17102 (packedSelected [0,1,4,7,19,22,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound17102 : packedSelected [0,1,4,7,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env17103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,2421,1025,32769,36928,8572,32784,98644,8192,64,43356,38161,17665,2421,34132,21792,257,21792,46093,107019]

theorem envBound17103 : H12AffineFastState.Bounded env17103 := by
  intro p hp
  have h : env17103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17102_17103 : H12AffineEnvironment.transform 17 2421 env17102 = env17103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env17102 == env17103) = true)

theorem identity17103 : scanCanonicalize (H12AffineFastState.compose env17103 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17103 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,2421,1025,1,4160,8572,16,65876,8192,64,10588,5393,17665,2421,1364,21792,257,21792,13325,74251]

theorem envBound17104 : H12AffineFastState.Bounded env17104 := by
  intro p hp
  have h : env17104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17103_17104 : H12AffineEnvironment.transform 14 0 env17103 = env17104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17103 == env17104) = true)

theorem identity17104 : scanCanonicalize (H12AffineFastState.compose env17104 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound17104 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,342,16400,2421,1025,1,4160,8572,16,2,8192,64,10588,5393,17665,2421,1364,21792,257,21792,13325,9053]

theorem envBound17105 : H12AffineFastState.Bounded env17105 := by
  intro p hp
  have h : env17105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17104_17105 : H12AffineEnvironment.transform 15 342 env17104 = env17105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env17104 == env17105) = true)

theorem identity17105 : scanCanonicalize (H12AffineFastState.compose env17105 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound17105 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,0,342,5220,2421,1025,1,4160,8572,16,2,8192,64,10588,5393,4469,2421,1364,340,257,340,13325,9053]

theorem envBound17106 : H12AffineFastState.Bounded env17106 := by
  intro p hp
  have h : env17106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17105_17106 : H12AffineEnvironment.transform 13 5236 env17105 = env17106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env17105 == env17106) = true)

theorem identity17106 : scanCanonicalize (H12AffineFastState.compose env17106 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound17106 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env17107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,8192,5236,0,342,5220,81,1025,1,4160,8572,16,2,8192,64,8312,5393,4469,81,1364,340,257,340,13325,9053]

theorem envBound17107 : H12AffineFastState.Bounded env17107 := by
  intro p hp
  have h : env17107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17106_17107 : H12AffineEnvironment.transform 10 292 env17106 = env17107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env17106 == env17107) = true)

theorem identity17107 : scanCanonicalize (H12AffineFastState.compose env17107 (packedSelected [0,1,2,4,7,8,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound17107 : packedSelected [0,1,2,4,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env17108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,309,8192,1345,0,342,1361,81,1025,1,373,8572,16,2,8192,64,8312,1060,64,81,1364,340,257,340,9528,9053]

theorem envBound17108 : H12AffineFastState.Bounded env17108 := by
  intro p hp
  have h : env17108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17107_17108 : H12AffineEnvironment.transform 11 309 env17107 = env17108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env17107 == env17108) = true)

theorem identity17108 : scanCanonicalize (H12AffineFastState.compose env17108 (packedSelected [5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17108 : packedSelected [5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env17109 : List Nat := [2,4,8,16,32,64,8,256,512,101,292,309,8192,292,0,342,308,81,100,1,373,8572,16,2,8192,64,8312,65,64,81,305,340,257,340,8541,9053]

theorem envBound17109 : H12AffineFastState.Bounded env17109 := by
  intro p hp
  have h : env17109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17108_17109 : H12AffineEnvironment.transform 9 101 env17108 = env17109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17108 == env17109) = true)

theorem identity17109 : scanCanonicalize (H12AffineFastState.compose env17109 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17109 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env17110 : List Nat := [2,4,8,16,32,64,8,256,512,101,292,309,348,292,0,342,308,81,100,1,373,32,16,2,348,64,292,65,64,81,305,340,257,340,1,513]

theorem envBound17110 : H12AffineFastState.Bounded env17110 := by
  intro p hp
  have h : env17110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17109_17110 : H12AffineEnvironment.transform 12 348 env17109 = env17110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17109 == env17110) = true)

theorem identity17110 : scanCanonicalize (H12AffineFastState.compose env17110 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17110 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17111 : List Nat := [2,4,8,16,32,64,8,116,512,101,80,65,40,80,0,34,64,81,100,1,1,32,16,2,40,64,80,65,64,81,69,32,117,32,1,513]

theorem envBound17111 : H12AffineFastState.Bounded env17111 := by
  intro p hp
  have h : env17111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17110_17111 : H12AffineEnvironment.transform 7 116 env17110 = env17111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17110 == env17111) = true)

theorem identity17111 : scanCanonicalize (H12AffineFastState.compose env17111 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound17111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17112 : List Nat := [2,4,8,16,32,64,8,116,49,101,80,65,40,80,0,34,64,81,100,1,1,32,16,2,40,64,80,65,64,81,69,32,117,32,1,48]

theorem envBound17112 : H12AffineFastState.Bounded env17112 := by
  intro p hp
  have h : env17112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17111_17112 : H12AffineEnvironment.transform 8 49 env17111 = env17112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env17111 == env17112) = true)

theorem identity17112 : scanCanonicalize (H12AffineFastState.compose env17112 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound17112 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17113 : List Nat := [2,4,8,16,32,32,8,20,49,5,48,33,40,48,0,34,32,49,4,1,1,32,16,2,40,32,48,33,32,49,37,32,21,32,1,48]

theorem envBound17113 : H12AffineFastState.Bounded env17113 := by
  intro p hp
  have h : env17113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17112_17113 : H12AffineEnvironment.transform 5 32 env17112 = env17113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env17112 == env17113) = true)

theorem identity17113 : scanCanonicalize (H12AffineFastState.compose env17113 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17114 : List Nat := [2,4,8,16,17,17,8,20,0,5,1,16,25,1,0,19,17,0,4,1,1,17,16,2,25,17,1,16,17,0,20,17,21,17,1,1]

theorem envBound17114 : H12AffineFastState.Bounded env17114 := by
  intro p hp
  have h : env17114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17113_17114 : H12AffineEnvironment.transform 4 17 env17113 = env17114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17113 == env17114) = true)

def env17115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180225,98645,8193,64,43357,185600,17665,262145,181572,400453,257,21792,46092,254490]

theorem envBound17115 : H12AffineFastState.Bounded env17115 := by
  intro p hp
  have h : env17115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17100_17115 : H12AffineEnvironment.transform 6 9 env17100 = env17115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17100 == env17115) = true)

theorem identity17115 : scanCanonicalize (H12AffineFastState.compose env17115 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound17115 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272392,73754,98645,8193,64,43357,79131,17665,262145,75103,392286,257,21792,46092,513]

theorem envBound17116 : H12AffineFastState.Bounded env17116 := by
  intro p hp
  have h : env17116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17115_17116 : H12AffineEnvironment.transform 16 122907 env17115 = env17116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env17115 == env17116) = true)

theorem identity17116 : scanCanonicalize (H12AffineFastState.compose env17116 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound17116 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67618,1025,32769,77898,73770,73754,98645,8193,64,43357,79131,17665,67619,75103,62588,257,21792,46092,513]

theorem envBound17117 : H12AffineFastState.Bounded env17117 := by
  intro p hp
  have h : env17117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17116_17117 : H12AffineEnvironment.transform 17 67618 env17116 = env17117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env17116 == env17117) = true)

theorem identity17117 : scanCanonicalize (H12AffineFastState.compose env17117 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound17117 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env17118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,65536,70679,67618,1025,29709,77898,73770,73754,95577,8193,64,23889,79131,17665,67619,75103,112,257,21792,16384,513]

theorem envBound17118 : H12AffineFastState.Bounded env17118 := by
  intro p hp
  have h : env17118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17117_17118 : H12AffineEnvironment.transform 14 29708 env17117 = env17118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env17117 == env17118) = true)

theorem identity17118 : scanCanonicalize (H12AffineFastState.compose env17118 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound17118 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env17119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,65536,70679,67618,1025,0,77898,73770,73754,65876,8193,64,10588,79131,12556,67619,75103,112,257,8493,13325,513]

theorem envBound17119 : H12AffineFastState.Bounded env17119 := by
  intro p hp
  have h : env17119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17118_17119 : H12AffineEnvironment.transform 13 13325 env17118 = env17119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env17118 == env17119) = true)

theorem identity17119 : scanCanonicalize (H12AffineFastState.compose env17119 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17119 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env17120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,1,65536,70679,67618,1025,0,69958,65830,65814,65876,269,64,2128,70679,4096,67619,66643,112,257,33,5377,513]

theorem envBound17120 : H12AffineFastState.Bounded env17120 := by
  intro p hp
  have h : env17120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17119_17120 : H12AffineEnvironment.transform 12 268 env17119 = env17120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17119 == env17120) = true)

theorem identity17120 : scanCanonicalize (H12AffineFastState.compose env17120 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound17120 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,1,343,5440,2421,1025,0,4113,113,65,3,269,64,2128,5440,4096,2420,1284,112,257,33,5377,513]

theorem envBound17121 : H12AffineFastState.Bounded env17121 := by
  intro p hp
  have h : env17121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17120_17121 : H12AffineEnvironment.transform 15 343 env17120 = env17121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env17120 == env17121) = true)

theorem identity17121 : scanCanonicalize (H12AffineFastState.compose env17121 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17121 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17122 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1025,0,4113,32,16,3,269,17,2049,5393,4096,2341,1284,33,257,33,5377,513]

theorem envBound17122 : H12AffineFastState.Bounded env17122 := by
  intro p hp
  have h : env17122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17121_17122 : H12AffineEnvironment.transform 5 17 env17121 = env17122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17121 == env17122) = true)

theorem identity17122 : scanCanonicalize (H12AffineFastState.compose env17122 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17123 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,1,262,4389,2340,53,0,4113,32,16,3,269,17,2049,4389,4096,2341,304,33,257,33,4405,513]

theorem envBound17123 : H12AffineFastState.Bounded env17123 := by
  intro p hp
  have h : env17123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17122_17123 : H12AffineEnvironment.transform 9 52 env17122 = env17123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17122 == env17123) = true)

theorem identity17123 : scanCanonicalize (H12AffineFastState.compose env17123 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17124 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4112,1,35,4096,2049,53,0,4113,32,16,3,40,17,2049,4096,4096,2048,21,33,36,33,4112,513]

theorem envBound17124 : H12AffineFastState.Bounded env17124 := by
  intro p hp
  have h : env17124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17123_17124 : H12AffineEnvironment.transform 7 37 env17123 = env17124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17123 == env17124) = true)

theorem identity17124 : scanCanonicalize (H12AffineFastState.compose env17124 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound17124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17125 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2576,41,2560,1,35,2576,2049,53,0,2561,32,16,3,40,17,2049,2576,2576,2048,21,33,36,33,2560,513]

theorem envBound17125 : H12AffineFastState.Bounded env17125 := by
  intro p hp
  have h : env17125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17124_17125 : H12AffineEnvironment.transform 11 2576 env17124 = env17125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env17124 == env17125) = true)

theorem identity17125 : scanCanonicalize (H12AffineFastState.compose env17125 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound17125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17126 : List Nat := [2,4,8,16,32,17,9,37,512,52,59,555,41,571,1,35,555,58,53,0,570,32,16,3,40,17,58,555,555,59,21,33,36,33,571,513]

theorem envBound17126 : H12AffineFastState.Bounded env17126 := by
  intro p hp
  have h : env17126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17125_17126 : H12AffineEnvironment.transform 10 59 env17125 = env17126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env17125 == env17126) = true)

theorem identity17126 : scanCanonicalize (H12AffineFastState.compose env17126 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound17126 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17127 : List Nat := [2,4,8,16,26,17,9,31,512,14,1,529,19,513,1,25,529,0,15,0,512,26,16,3,18,17,0,529,529,1,21,27,30,27,513,513]

theorem envBound17127 : H12AffineFastState.Bounded env17127 := by
  intro p hp
  have h : env17127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17126_17127 : H12AffineEnvironment.transform 4 26 env17126 = env17127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env17126 == env17127) = true)

theorem identity17127 : scanCanonicalize (H12AffineFastState.compose env17127 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17127 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17128 : List Nat := [2,4,8,16,26,17,9,31,0,14,1,17,19,1,1,25,17,0,15,0,0,26,16,3,18,17,0,17,17,1,21,27,30,27,1,1]

theorem envBound17128 : H12AffineFastState.Bounded env17128 := by
  intro p hp
  have h : env17128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17127_17128 : H12AffineEnvironment.transform 8 0 env17127 = env17128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17127 == env17128) = true)

def env17129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,98781,8328,64,4489557,185736,17664,262281,181572,4338885,257,21792,46213,254611]

theorem envBound17129 : H12AffineFastState.Bounded env17129 := by
  intro p hp
  have h : env17129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17095_17129 : H12AffineEnvironment.transform 22 180361 env17095 = env17129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env17095 == env17129) = true)

def env17130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,98781,8328,64,43477,185736,17664,262281,181572,400453,257,21792,46213,254611]

theorem envBound17130 : H12AffineFastState.Bounded env17130 := by
  intro p hp
  have h : env17130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17129_17130 : H12AffineEnvironment.transform 21 272512 env17129 = env17130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17129 == env17130) = true)

theorem identity17130 : scanCanonicalize (H12AffineFastState.compose env17130 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound17130 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58517,272512,62660,98781,8328,64,43477,57797,17664,262281,61705,272392,257,21792,46213,120542]

theorem envBound17131 : H12AffineFastState.Bounded env17131 := by
  intro p hp
  have h : env17131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17130_17131 : H12AffineEnvironment.transform 16 13389 env17130 = env17131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env17130 == env17131) = true)

def env17132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58517,168,62660,98781,8328,64,43477,57797,17664,10401,61705,32,257,21792,46213,120542]

theorem envBound17132 : H12AffineFastState.Bounded env17132 := by
  intro p hp
  have h : env17132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17131_17132 : H12AffineEnvironment.transform 17 10280 env17131 = env17132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env17131 == env17132) = true)

theorem identity17132 : scanCanonicalize (H12AffineFastState.compose env17132 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound17132 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env17133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,32768,65536,4232,3309,1025,32769,49232,168,53249,98781,1101,64,36112,50432,17664,3172,54732,32,257,21792,36928,120542]

theorem envBound17133 : H12AffineFastState.Bounded env17133 := by
  intro p hp
  have h : env17133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17132_17133 : H12AffineEnvironment.transform 12 1221 env17132 = env17133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env17132 == env17133) = true)

theorem identity17133 : scanCanonicalize (H12AffineFastState.compose env17133 (packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 1480) := by decide +kernel

theorem selectedBound17133 : packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env17134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,1480,65536,4232,3309,1025,1481,17816,168,21961,66581,1101,64,2264,16584,17664,3172,20484,32,257,21792,5512,86806]

theorem envBound17134 : H12AffineFastState.Bounded env17134 := by
  intro p hp
  have h : env17134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17133_17134 : H12AffineEnvironment.transform 14 1480 env17133 = env17134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1480 env17133 == env17134) = true)

theorem identity17134 : scanCanonicalize (H12AffineFastState.compose env17134 (packedSelected [0,3,5,9,10,11,16,17,19,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound17134 : packedSelected [0,3,5,9,10,11,16,17,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env17135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,1480,21794,4232,3309,1025,1481,17816,168,21961,20791,1101,64,2264,16584,17664,3172,20484,32,257,21792,5512,1588]

theorem envBound17135 : H12AffineFastState.Bounded env17135 := by
  intro p hp
  have h : env17135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17134_17135 : H12AffineEnvironment.transform 15 21794 env17134 = env17135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env17134 == env17135) = true)

theorem identity17135 : scanCanonicalize (H12AffineFastState.compose env17135 (packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound17135 : packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env17136 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,389,16384,136,20578,4232,2477,321,137,16600,168,20617,20791,269,64,2264,16584,16448,2340,20484,32,257,20576,4296,884]

theorem envBound17136 : H12AffineFastState.Bounded env17136 := by
  intro p hp
  have h : env17136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17135_17136 : H12AffineEnvironment.transform 9 320 env17135 = env17136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env17135 == env17136) = true)

theorem identity17136 : scanCanonicalize (H12AffineFastState.compose env17136 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound17136 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env17137 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,389,4541,136,479,4232,2477,321,137,4453,168,308,138,269,64,2264,4469,4605,2340,441,32,257,477,4296,884]

end H12CloudChart1