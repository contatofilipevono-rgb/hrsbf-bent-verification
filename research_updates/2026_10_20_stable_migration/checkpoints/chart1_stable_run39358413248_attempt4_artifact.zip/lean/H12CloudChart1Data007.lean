import H12CloudChart1Data006

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound1705 : H12AffineFastState.Bounded env1705 := by
  intro p hp
  have h : env1705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1704_1705 : H12AffineEnvironment.transform 7 4 env1704 = env1705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1704 == env1705) = true)

theorem identity1705 : scanCanonicalize (H12AffineFastState.compose env1705 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3767) := by decide +kernel

theorem selectedBound1705 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1706 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,3767,8432,8314,3662,2265,1025,8432,7695,32,184,139,8328,232,2296,3766,4345,2081,1024,1,5,1,3662,513]

theorem envBound1706 : H12AffineFastState.Bounded env1706 := by
  intro p hp
  have h : env1706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1705_1706 : H12AffineEnvironment.transform 13 3767 env1705 = env1706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3767 env1705 == env1706) = true)

theorem identity1706 : scanCanonicalize (H12AffineFastState.compose env1706 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1751) := by decide +kernel

theorem selectedBound1706 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1707 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1751,4096,8192,96,8432,8314,153,1550,1025,8432,4312,32,184,139,8328,232,1583,97,4345,1782,1024,1,5,1,153,513]

theorem envBound1707 : H12AffineFastState.Bounded env1707 := by
  intro p hp
  have h : env1707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1706_1707 : H12AffineEnvironment.transform 10 1751 env1706 = env1707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1751 env1706 == env1707) = true)

theorem identity1707 : scanCanonicalize (H12AffineFastState.compose env1707 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound1707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1708 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1751,4096,1156,96,1140,1278,153,1550,1025,1140,4312,32,184,139,1036,232,1583,97,4345,1782,1024,1,5,1,153,513]

theorem envBound1708 : H12AffineFastState.Bounded env1708 := by
  intro p hp
  have h : env1708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1707_1708 : H12AffineEnvironment.transform 12 1156 env1707 = env1708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env1707 == env1708) = true)

theorem identity1708 : scanCanonicalize (H12AffineFastState.compose env1708 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1751) := by decide +kernel

theorem selectedBound1708 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env1709 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1751,1751,1156,96,1140,1278,153,1550,1025,1140,1551,32,184,139,1036,232,1583,97,1582,1782,1024,1,5,1,153,513]

theorem envBound1709 : H12AffineFastState.Bounded env1709 := by
  intro p hp
  have h : env1709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1708_1709 : H12AffineEnvironment.transform 11 1751 env1708 = env1709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1751 env1708 == env1709) = true)

theorem identity1709 : scanCanonicalize (H12AffineFastState.compose env1709 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 646) := by decide +kernel

theorem selectedBound1709 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1710 : List Nat := [2,4,8,16,32,64,128,4,512,646,81,81,514,96,754,632,153,136,647,754,137,32,184,139,650,232,169,97,168,112,646,1,5,1,153,513]

theorem envBound1710 : H12AffineFastState.Bounded env1710 := by
  intro p hp
  have h : env1710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1709_1710 : H12AffineEnvironment.transform 9 646 env1709 = env1710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 646 env1709 == env1710) = true)

theorem identity1710 : scanCanonicalize (H12AffineFastState.compose env1710 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1710 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1711 : List Nat := [2,4,8,16,32,64,120,4,512,638,81,81,514,96,522,632,97,112,639,522,113,32,64,115,626,16,81,97,80,112,638,1,5,1,97,513]

theorem envBound1711 : H12AffineFastState.Bounded env1711 := by
  intro p hp
  have h : env1711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1710_1711 : H12AffineEnvironment.transform 6 120 env1710 = env1711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1710 == env1711) = true)

theorem identity1711 : scanCanonicalize (H12AffineFastState.compose env1711 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound1711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1712 : List Nat := [2,4,8,16,32,64,120,4,123,5,81,81,121,96,113,3,97,112,4,113,113,32,64,115,9,16,81,97,80,112,5,1,5,1,97,122]

theorem envBound1712 : H12AffineFastState.Bounded env1712 := by
  intro p hp
  have h : env1712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1711_1712 : H12AffineEnvironment.transform 8 123 env1711 = env1712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env1711 == env1712) = true)

theorem identity1712 : scanCanonicalize (H12AffineFastState.compose env1712 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound1712 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1713 : List Nat := [2,4,8,16,32,49,9,4,10,5,32,32,8,17,0,3,16,1,4,0,0,32,49,2,9,16,32,16,33,1,5,1,5,1,16,11]

theorem envBound1713 : H12AffineFastState.Bounded env1713 := by
  intro p hp
  have h : env1713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1712_1713 : H12AffineEnvironment.transform 5 49 env1712 = env1713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env1712 == env1713) = true)

theorem identity1713 : scanCanonicalize (H12AffineFastState.compose env1713 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound1713 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1714 : List Nat := [2,4,8,16,0,17,9,4,10,5,0,0,8,17,0,3,16,1,4,0,0,0,17,2,9,16,0,16,1,1,5,1,5,1,16,11]

theorem envBound1714 : H12AffineFastState.Bounded env1714 := by
  intro p hp
  have h : env1714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1713_1714 : H12AffineEnvironment.transform 4 0 env1713 = env1714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env1713 == env1714) = true)

theorem identity1714 : scanCanonicalize (H12AffineFastState.compose env1714 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound1714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1715 : List Nat := [2,4,8,7,0,6,9,4,10,5,0,0,8,6,0,3,7,1,4,0,0,0,6,2,9,7,0,7,1,1,5,1,5,1,7,11]

theorem envBound1715 : H12AffineFastState.Bounded env1715 := by
  intro p hp
  have h : env1715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1714_1715 : H12AffineEnvironment.transform 3 7 env1714 = env1715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env1714 == env1715) = true)

theorem identity1715 : scanCanonicalize (H12AffineFastState.compose env1715 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound1715 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1716 : List Nat := [2,4,0,7,0,6,1,4,2,5,0,0,0,6,0,3,7,1,4,0,0,0,6,2,1,7,0,7,1,1,5,1,5,1,7,3]

theorem envBound1716 : H12AffineFastState.Bounded env1716 := by
  intro p hp
  have h : env1716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1715_1716 : H12AffineEnvironment.transform 2 0 env1715 = env1716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env1715 == env1716) = true)

theorem identity1716 : scanCanonicalize (H12AffineFastState.compose env1716 (packedSelected [12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound1716 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env1717 : List Nat := [2,2,0,1,0,0,1,2,2,3,0,0,0,0,0,3,1,1,2,0,0,0,0,2,1,1,0,1,1,1,3,1,3,1,1,3]

theorem envBound1717 : H12AffineFastState.Bounded env1717 := by
  intro p hp
  have h : env1717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1716_1717 : H12AffineEnvironment.transform 1 2 env1716 = env1717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env1716 == env1717) = true)

def env1718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2081,16852469,4341976,257,1,131073,16925299]

theorem envBound1718 : H12AffineFastState.Bounded env1718 := by
  intro p hp
  have h : env1718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1695_1718 : H12AffineEnvironment.transform 34 131073 env1695 = env1718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1695 == env1718) = true)

theorem identity1718 : scanCanonicalize (H12AffineFastState.compose env1718 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4284780) := by decide +kernel

theorem selectedBound1718 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,4284780,8328,147473,409816,16385,151552,2081,4211865,4341976,257,1,131073,4399903]

theorem envBound1719 : H12AffineFastState.Bounded env1719 := by
  intro p hp
  have h : env1719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1718_1719 : H12AffineEnvironment.transform 23 4284780 env1718 = env1719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4284780 env1718 == env1719) = true)

theorem identity1719 : scanCanonicalize (H12AffineFastState.compose env1719 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound1719 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,293,147521,90185,8328,147473,409816,16385,151552,2081,17852,147965,257,1,131073,205370]

theorem envBound1720 : H12AffineFastState.Bounded env1720 := by
  intro p hp
  have h : env1720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1719_1720 : H12AffineEnvironment.transform 21 293 env1719 = env1720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env1719 == env1720) = true)

def env1721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16892,262144,1025,8692,2097152,293,445,90185,8328,493,262436,16385,4604,2081,17852,1,257,1,16893,91078]

theorem envBound1721 : H12AffineFastState.Bounded env1721 := by
  intro p hp
  have h : env1721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1720_1721 : H12AffineEnvironment.transform 16 16892 env1720 = env1721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1720 == env1721) = true)

theorem identity1721 : scanCanonicalize (H12AffineFastState.compose env1721 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound1721 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,65536,325,262144,1025,8692,2097152,293,445,73968,8328,493,262436,184,4604,2081,1285,1,257,1,324,74623]

theorem envBound1722 : H12AffineFastState.Bounded env1722 := by
  intro p hp
  have h : env1722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1721_1722 : H12AffineEnvironment.transform 13 185 env1721 = env1722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env1721 == env1722) = true)

theorem identity1722 : scanCanonicalize (H12AffineFastState.compose env1722 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound1722 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env1723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,65536,325,2265,1025,8692,2097152,293,445,73968,8328,493,2557,184,4604,2081,1285,1,257,1,324,74623]

theorem envBound1723 : H12AffineFastState.Bounded env1723 := by
  intro p hp
  have h : env1723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1722_1723 : H12AffineEnvironment.transform 17 2265 env1722 = env1723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env1722 == env1723) = true)

theorem identity1723 : scanCanonicalize (H12AffineFastState.compose env1723 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound1723 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env1724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,8314,325,2265,1025,8692,2097152,293,445,138,8328,493,2557,184,4604,2081,1285,1,257,1,324,773]

theorem envBound1724 : H12AffineFastState.Bounded env1724 := by
  intro p hp
  have h : env1724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1723_1724 : H12AffineEnvironment.transform 15 8314 env1723 = env1724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env1723 == env1724) = true)

theorem identity1724 : scanCanonicalize (H12AffineFastState.compose env1724 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11690) := by decide +kernel

theorem selectedBound1724 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8692,8314,325,2265,1025,8692,11690,293,445,138,8328,493,2557,184,4604,2081,1285,1,257,1,324,773]

theorem envBound1725 : H12AffineFastState.Bounded env1725 := by
  intro p hp
  have h : env1725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1724_1725 : H12AffineEnvironment.transform 20 11690 env1724 = env1725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11690 env1724 == env1725) = true)

theorem identity1725 : scanCanonicalize (H12AffineFastState.compose env1725 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3369) := by decide +kernel

theorem selectedBound1725 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env1726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3369,185,3293,3411,325,2265,1025,3293,131,293,445,138,3489,493,2557,184,4604,2081,1285,1,257,1,324,773]

theorem envBound1726 : H12AffineFastState.Bounded env1726 := by
  intro p hp
  have h : env1726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1725_1726 : H12AffineEnvironment.transform 12 3369 env1725 = env1726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3369 env1725 == env1726) = true)

theorem identity1726 : scanCanonicalize (H12AffineFastState.compose env1726 (packedSelected [0,1,2,5,6,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1726 : packedSelected [0,1,2,5,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env1727 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,3117,185,3293,3159,65,2265,1025,3293,131,33,185,138,3237,233,2297,184,4344,2081,1025,1,5,1,64,513]

theorem envBound1727 : H12AffineFastState.Bounded env1727 := by
  intro p hp
  have h : env1727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1726_1727 : H12AffineEnvironment.transform 7 4 env1726 = env1727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1726 == env1727) = true)

theorem identity1727 : scanCanonicalize (H12AffineFastState.compose env1727 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1709) := by decide +kernel

theorem selectedBound1727 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env1728 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1709,4096,640,185,624,762,65,1652,1025,624,131,33,185,138,520,233,1620,184,4344,1676,1025,1,5,1,64,513]

theorem envBound1728 : H12AffineFastState.Bounded env1728 := by
  intro p hp
  have h : env1728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1727_1728 : H12AffineEnvironment.transform 10 1709 env1727 = env1728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1709 env1727 == env1728) = true)

theorem identity1728 : scanCanonicalize (H12AffineFastState.compose env1728 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound1728 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1729 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1709,1677,640,185,624,762,65,1652,1025,624,131,33,185,138,520,233,1620,184,1653,1676,1025,1,5,1,64,513]

theorem envBound1729 : H12AffineFastState.Bounded env1729 := by
  intro p hp
  have h : env1729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1728_1729 : H12AffineEnvironment.transform 11 1677 env1728 = env1729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env1728 == env1729) = true)

theorem identity1729 : scanCanonicalize (H12AffineFastState.compose env1729 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound1729 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1730 : List Nat := [2,4,8,16,32,64,24,4,512,1024,1589,1557,536,33,624,610,65,1652,1025,624,27,33,33,18,520,113,1620,32,1653,1556,1025,1,5,1,64,513]

theorem envBound1730 : H12AffineFastState.Bounded env1730 := by
  intro p hp
  have h : env1730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1729_1730 : H12AffineEnvironment.transform 6 24 env1729 = env1730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env1729 == env1730) = true)

theorem identity1730 : scanCanonicalize (H12AffineFastState.compose env1730 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound1730 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1731 : List Nat := [2,4,8,16,32,64,24,4,512,622,91,123,536,33,624,610,65,26,623,624,27,33,33,18,520,113,58,32,27,122,623,1,5,1,64,513]

theorem envBound1731 : H12AffineFastState.Bounded env1731 := by
  intro p hp
  have h : env1731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1730_1731 : H12AffineEnvironment.transform 9 622 env1730 = env1731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env1730 == env1731) = true)

theorem identity1731 : scanCanonicalize (H12AffineFastState.compose env1731 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound1731 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env1732 : List Nat := [2,4,8,16,32,59,24,4,512,533,32,0,536,33,523,537,58,26,532,523,27,33,33,18,520,10,58,32,27,1,532,1,5,1,59,513]

theorem envBound1732 : H12AffineFastState.Bounded env1732 := by
  intro p hp
  have h : env1732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1731_1732 : H12AffineEnvironment.transform 5 59 env1731 = env1732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env1731 == env1732) = true)

theorem identity1732 : scanCanonicalize (H12AffineFastState.compose env1732 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound1732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1733 : List Nat := [2,4,8,16,32,59,24,4,33,52,32,0,57,33,42,56,58,26,53,42,27,33,33,18,41,10,58,32,27,1,53,1,5,1,59,32]

theorem envBound1733 : H12AffineFastState.Bounded env1733 := by
  intro p hp
  have h : env1733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1732_1733 : H12AffineEnvironment.transform 8 33 env1732 = env1733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env1732 == env1733) = true)

theorem identity1733 : scanCanonicalize (H12AffineFastState.compose env1733 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound1733 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1734 : List Nat := [2,4,8,16,20,15,24,4,21,0,20,0,13,21,30,12,14,26,1,30,27,21,21,18,29,10,14,20,27,1,1,1,5,1,15,20]

theorem envBound1734 : H12AffineFastState.Bounded env1734 := by
  intro p hp
  have h : env1734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1733_1734 : H12AffineEnvironment.transform 4 20 env1733 = env1734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env1733 == env1734) = true)

def env1735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,16893,262144,1025,8692,2097152,293,444,90185,8328,492,262437,16385,4605,2081,17852,0,257,1,16892,91079]

theorem envBound1735 : H12AffineFastState.Bounded env1735 := by
  intro p hp
  have h : env1735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1720_1735 : H12AffineEnvironment.transform 16 16893 env1720 = env1735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1720 == env1735) = true)

theorem identity1735 : scanCanonicalize (H12AffineFastState.compose env1735 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1735 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8575,16893,262144,1025,8692,2097152,293,444,16694,8328,492,262437,16385,4605,2081,17852,0,257,1,16892,17080]

theorem envBound1736 : H12AffineFastState.Bounded env1736 := by
  intro p hp
  have h : env1736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1735_1736 : H12AffineEnvironment.transform 15 8575 env1735 = env1736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1735 == env1736) = true)

def env1737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2081,17375733,13108377,525568,1,34359738368,25691698]

theorem envBound1737 : H12AffineFastState.Bounded env1737 := by
  intro p hp
  have h : env1737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1575_1737 : H12AffineEnvironment.transform 14 8693 env1575 = env1737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1575 == env1737) = true)

theorem identity1737 : scanCanonicalize (H12AffineFastState.compose env1737 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound1737 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913970,8328,8914001,9176216,16385,151552,2081,8463815,13108377,525568,1,34359738368,512]

theorem envBound1738 : H12AffineFastState.Bounded env1738 := by
  intro p hp
  have h : env1738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1737_1738 : H12AffineEnvironment.transform 23 8913970 env1737 = env1738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env1737 == env1738) = true)

theorem identity1738 : scanCanonicalize (H12AffineFastState.compose env1738 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525345) := by decide +kernel

theorem selectedBound1738 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,525345,8388608,8913970,8328,8914001,9176216,16385,151552,2081,8463815,8388792,525568,1,34359738368,512]

theorem envBound1739 : H12AffineFastState.Bounded env1739 := by
  intro p hp
  have h : env1739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1738_1739 : H12AffineEnvironment.transform 21 525345 env1738 = env1739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525345 env1738 == env1739) = true)

theorem identity1739 : scanCanonicalize (H12AffineFastState.compose env1739 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75135) := by decide +kernel

theorem selectedBound1739 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,8388608,8462669,8328,8462638,8724967,16385,151552,2081,8463815,8388792,73855,1,34359738368,512]

theorem envBound1740 : H12AffineFastState.Bounded env1740 := by
  intro p hp
  have h : env1740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1739_1740 : H12AffineEnvironment.transform 18 75135 env1739 = env1740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75135 env1739 == env1740) = true)

theorem identity1740 : scanCanonicalize (H12AffineFastState.compose env1740 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound1740 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,8388608,8462669,8328,8462638,8724967,16385,151552,2081,8463815,8388792,73855,1,131332,512]

theorem envBound1741 : H12AffineFastState.Bounded env1741 := by
  intro p hp
  have h : env1741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1740_1741 : H12AffineEnvironment.transform 34 131332 env1740 = env1741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env1740 == env1741) = true)

def env1742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,184,74229,8328,74134,336223,16385,151552,2081,75135,0,73855,1,131332,512]

theorem envBound1742 : H12AffineFastState.Bounded env1742 := by
  intro p hp
  have h : env1742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1741_1742 : H12AffineEnvironment.transform 22 184 env1741 = env1742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1741 == env1742) = true)

theorem identity1742 : scanCanonicalize (H12AffineFastState.compose env1742 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1742 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1743 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,74882,8200,2097152,73891,184,73736,8328,73835,336034,16385,151552,2081,74882,0,73855,1,131321,512]

theorem envBound1743 : H12AffineFastState.Bounded env1743 := by
  intro p hp
  have h : env1743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1742_1743 : H12AffineEnvironment.transform 7 253 env1742 = env1743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1742 == env1743) = true)

def env1744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,185,74228,8328,74135,336222,16385,151552,2081,75134,1,73855,1,131332,512]

theorem envBound1744 : H12AffineFastState.Bounded env1744 := by
  intro p hp
  have h : env1744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1741_1744 : H12AffineEnvironment.transform 22 185 env1741 = env1744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1741 == env1744) = true)

theorem identity1744 : scanCanonicalize (H12AffineFastState.compose env1744 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223322) := by decide +kernel

theorem selectedBound1744 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,223322,75135,8693,2097152,74078,185,74228,8328,74135,149764,16385,151552,2081,75134,1,73855,1,131332,512]

theorem envBound1745 : H12AffineFastState.Bounded env1745 := by
  intro p hp
  have h : env1745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1744_1745 : H12AffineEnvironment.transform 17 223322 env1744 = env1745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223322 env1744 == env1745) = true)

def env1746 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74883,8201,2097152,73890,185,73736,8328,73835,149752,16385,151552,2081,74882,1,73855,1,131320,512]

theorem envBound1746 : H12AffineFastState.Bounded env1746 := by
  intro p hp
  have h : env1746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1745_1746 : H12AffineEnvironment.transform 7 252 env1745 = env1746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1745 == env1746) = true)

theorem identity1746 : scanCanonicalize (H12AffineFastState.compose env1746 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151552) := by decide +kernel

theorem selectedBound1746 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1747 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74883,8201,151552,73890,185,73736,8328,73835,149752,16385,151552,2081,74882,1,73855,1,131320,512]

theorem envBound1747 : H12AffineFastState.Bounded env1747 := by
  intro p hp
  have h : env1747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1746_1747 : H12AffineEnvironment.transform 20 151552 env1746 = env1747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151552 env1746 == env1747) = true)

theorem identity1747 : scanCanonicalize (H12AffineFastState.compose env1747 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound1747 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1748 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,90235,2081,74883,8201,77947,73890,185,73736,8328,73835,75907,16385,77947,2081,74882,1,73855,1,90243,512]

theorem envBound1748 : H12AffineFastState.Bounded env1748 := by
  intro p hp
  have h : env1748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1747_1748 : H12AffineEnvironment.transform 16 90235 env1747 = env1748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env1747 == env1748) = true)

theorem identity1748 : scanCanonicalize (H12AffineFastState.compose env1748 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1748 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1749 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,8323,16632,2081,1024,8201,4344,33,185,139,8328,232,2048,16385,4344,2081,1025,1,252,1,16384,512]

theorem envBound1749 : H12AffineFastState.Bounded env1749 := by
  intro p hp
  have h : env1749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1748_1749 : H12AffineEnvironment.transform 15 8323 env1748 = env1749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1748 == env1749) = true)

theorem identity1749 : scanCanonicalize (H12AffineFastState.compose env1749 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound1749 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1750 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8201,8323,5261,2081,1024,8201,4344,33,185,139,8328,232,2048,5236,4344,2081,1025,1,252,1,5237,512]

theorem envBound1750 : H12AffineFastState.Bounded env1750 := by
  intro p hp
  have h : env1750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1749_1750 : H12AffineEnvironment.transform 13 5237 env1749 = env1750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env1749 == env1750) = true)

theorem identity1750 : scanCanonicalize (H12AffineFastState.compose env1750 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound1750 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1751 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,8192,603,8201,8323,675,2081,1024,8201,1750,33,185,139,8328,232,2048,602,1750,2081,1025,1,252,1,603,512]

theorem envBound1751 : H12AffineFastState.Bounded env1751 := by
  intro p hp
  have h : env1751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1750_1751 : H12AffineEnvironment.transform 11 1582 env1750 = env1751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env1750 == env1751) = true)

theorem identity1751 : scanCanonicalize (H12AffineFastState.compose env1751 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3823) := by decide +kernel

theorem selectedBound1751 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1752 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,3823,603,3814,3692,675,2081,1024,3814,1750,33,185,139,3687,232,2048,602,1750,2081,1025,1,252,1,603,512]

theorem envBound1752 : H12AffineFastState.Bounded env1752 := by
  intro p hp
  have h : env1752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1751_1752 : H12AffineEnvironment.transform 12 3823 env1751 = env1752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3823 env1751 == env1752) = true)

theorem identity1752 : scanCanonicalize (H12AffineFastState.compose env1752 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1752 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1753 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,554,2795,603,2786,2664,675,2081,4,2786,722,33,185,139,2659,232,2048,602,722,2081,5,1,252,1,603,512]

theorem envBound1753 : H12AffineFastState.Bounded env1753 := by
  intro p hp
  have h : env1753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1752_1753 : H12AffineEnvironment.transform 9 4 env1752 = env1753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1752 == env1753) = true)

theorem identity1753 : scanCanonicalize (H12AffineFastState.compose env1753 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1753 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1754 : List Nat := [2,4,8,16,32,64,120,4,512,4,2048,554,2579,603,2586,2664,603,2081,4,2586,554,33,65,115,2659,16,2048,602,554,2081,5,1,4,1,603,512]

theorem envBound1754 : H12AffineFastState.Bounded env1754 := by
  intro p hp
  have h : env1754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1753_1754 : H12AffineEnvironment.transform 6 120 env1753 = env1754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1753 == env1754) = true)

theorem identity1754 : scanCanonicalize (H12AffineFastState.compose env1754 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound1754 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1755 : List Nat := [2,4,8,16,32,64,120,4,512,4,609,554,114,603,123,9,603,576,4,123,554,33,65,115,2,16,609,602,554,576,5,1,4,1,603,512]

theorem envBound1755 : H12AffineFastState.Bounded env1755 := by
  intro p hp
  have h : env1755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1754_1755 : H12AffineEnvironment.transform 10 609 env1754 = env1755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env1754 == env1755) = true)

theorem identity1755 : scanCanonicalize (H12AffineFastState.compose env1755 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound1755 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1756 : List Nat := [2,4,8,16,26,64,66,4,512,4,603,528,72,603,65,9,603,576,4,65,528,27,65,73,2,16,603,602,528,576,5,1,4,1,603,512]

theorem envBound1756 : H12AffineFastState.Bounded env1756 := by
  intro p hp
  have h : env1756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1755_1756 : H12AffineEnvironment.transform 4 26 env1755 = env1756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env1755 == env1756) = true)

def env1757 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74882,8200,2097152,73891,185,73737,8328,73834,149753,16385,151552,2081,74883,1,73855,1,131321,512]

theorem envBound1757 : H12AffineFastState.Bounded env1757 := by
  intro p hp
  have h : env1757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1745_1757 : H12AffineEnvironment.transform 7 253 env1745 = env1757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1745 == env1757) = true)

theorem identity1757 : scanCanonicalize (H12AffineFastState.compose env1757 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78034) := by decide +kernel

theorem selectedBound1757 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1758 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74882,8200,78034,73891,185,73737,8328,73834,149753,16385,151552,2081,74883,1,73855,1,131321,512]

theorem envBound1758 : H12AffineFastState.Bounded env1758 := by
  intro p hp
  have h : env1758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1757_1758 : H12AffineEnvironment.transform 20 78034 env1757 = env1758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78034 env1757 == env1758) = true)

theorem identity1758 : scanCanonicalize (H12AffineFastState.compose env1758 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound1758 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1759 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7694,8200,65536,131072,210516,74882,8200,78034,73891,185,73737,8328,73834,136951,7695,134670,2081,74883,1,73855,1,131321,512]

theorem envBound1759 : H12AffineFastState.Bounded env1759 := by
  intro p hp
  have h : env1759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1758_1759 : H12AffineEnvironment.transform 13 7694 env1758 = env1759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env1758 == env1759) = true)

def env1760 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,131072,205376,74882,8200,74950,73891,185,73737,8328,73834,131811,2587,134670,2081,74883,1,73855,1,131321,512]

theorem envBound1760 : H12AffineFastState.Bounded env1760 := by
  intro p hp
  have h : env1760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1759_1760 : H12AffineEnvironment.transform 11 1044 env1759 = env1760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1759 == env1760) = true)

def env1761 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76384,2080,74882,8200,74950,73891,185,73737,8328,73834,75907,2587,74862,2081,74883,1,73855,1,76441,512]

theorem envBound1761 : H12AffineFastState.Bounded env1761 := by
  intro p hp
  have h : env1761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1760_1761 : H12AffineEnvironment.transform 16 76384 env1760 = env1761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1760 == env1761) = true)

theorem identity1761 : scanCanonicalize (H12AffineFastState.compose env1761 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1761 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1762 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2586,3614,65536,66678,2080,68244,3614,68304,69301,185,69151,3742,69244,67221,2587,68216,2081,68245,1,69225,1,66703,512]

theorem envBound1762 : H12AffineFastState.Bounded env1762 := by
  intro p hp
  have h : env1762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1761_1762 : H12AffineEnvironment.transform 12 3606 env1761 = env1762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1761 == env1762) = true)

theorem identity1762 : scanCanonicalize (H12AffineFastState.compose env1762 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1762 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1763 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2586,3614,3732,2786,2080,1024,3614,1092,33,185,139,3742,232,2049,2587,1260,2081,1025,1,253,1,2587,512]

theorem envBound1763 : H12AffineFastState.Bounded env1763 := by
  intro p hp
  have h : env1763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1762_1763 : H12AffineEnvironment.transform 15 3732 env1762 = env1763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1762 == env1763) = true)

theorem identity1763 : scanCanonicalize (H12AffineFastState.compose env1763 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1763 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1764 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,64,2626,2586,2634,2752,2786,2080,84,2634,16,33,185,139,2762,232,2049,2587,184,2081,85,1,253,1,2587,512]

theorem envBound1764 : H12AffineFastState.Bounded env1764 := by
  intro p hp
  have h : env1764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1763_1764 : H12AffineEnvironment.transform 9 84 env1763 = env1764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1763 == env1764) = true)

theorem identity1764 : scanCanonicalize (H12AffineFastState.compose env1764 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1764 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1765 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,64,2626,2586,2634,2664,2634,2080,84,2634,16,33,17,35,2658,64,2049,2587,16,2081,85,1,85,1,2587,512]

theorem envBound1765 : H12AffineFastState.Bounded env1765 := by
  intro p hp
  have h : env1765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1764_1765 : H12AffineEnvironment.transform 6 40 env1764 = env1765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1764 == env1765) = true)

def env1766 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,64,2626,2586,2634,2648,2634,2064,84,2634,16,17,17,19,2642,64,2049,2587,16,2065,85,1,85,1,2587,512]

theorem envBound1766 : H12AffineFastState.Bounded env1766 := by
  intro p hp
  have h : env1766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1765_1766 : H12AffineEnvironment.transform 4 16 env1765 = env1766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1765 == env1766) = true)

def env1767 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,64,578,538,586,600,586,16,84,586,16,17,17,19,594,64,1,539,16,17,85,1,85,1,539,512]

theorem envBound1767 : H12AffineFastState.Bounded env1767 := by
  intro p hp
  have h : env1767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1766_1767 : H12AffineEnvironment.transform 10 0 env1766 = env1767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1766 == env1767) = true)

theorem identity1767 : scanCanonicalize (H12AffineFastState.compose env1767 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1768 : List Nat := [2,4,8,16,16,64,24,85,6,84,0,64,68,28,76,94,76,16,84,76,16,17,17,19,84,64,1,29,16,17,85,1,85,1,29,6]

theorem envBound1768 : H12AffineFastState.Bounded env1768 := by
  intro p hp
  have h : env1768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1767_1768 : H12AffineEnvironment.transform 8 6 env1767 = env1768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1767 == env1768) = true)

def env1769 : List Nat := [2,4,8,16,16,0,24,21,6,20,0,0,4,28,12,30,12,16,20,12,16,17,17,19,20,0,1,29,16,17,21,1,21,1,29,6]

theorem envBound1769 : H12AffineFastState.Bounded env1769 := by
  intro p hp
  have h : env1769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1768_1769 : H12AffineEnvironment.transform 5 0 env1768 = env1769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1768 == env1769) = true)

def leafEnv1769 : List Nat := [2,4,8,16,16,0,24,21,6,20,0,0,4,28,12,30,12,16,20,12,16,17,17,19,20,20,1,0,1,29,16,17,21,1,21,1,5,15,29,6,1,17,0]

def active1769 : List Nat := [0,1,2,3]

def tree1769 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1769 : H12WitnessSearch.Good tree1769 := H12GlobalWitnessIndex.good

theorem leafIdentity1769 : H12AffineFastState.composeSystem env1769 rootObs = leafEnv1769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1769 rootObs == leafEnv1769) = true)

theorem terminalChecked1769 : H12PackedTerminal.terminalCheckFast leafEnv1769 active1769 tree1769 = true := by decide +kernel

def env1770 : List Nat := [2,4,8,16,16,1,24,20,6,21,0,1,5,28,13,31,13,16,21,13,16,17,17,19,21,1,1,29,16,17,20,1,20,1,29,6]

theorem envBound1770 : H12AffineFastState.Bounded env1770 := by
  intro p hp
  have h : env1770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1768_1770 : H12AffineEnvironment.transform 5 1 env1768 = env1770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1768 == env1770) = true)

theorem identity1770 : scanCanonicalize (H12AffineFastState.compose env1770 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1771 : List Nat := [2,4,8,12,12,1,4,8,6,9,0,1,5,0,13,3,13,12,9,13,12,13,13,15,9,1,1,1,12,13,8,1,8,1,1,6]

theorem envBound1771 : H12AffineFastState.Bounded env1771 := by
  intro p hp
  have h : env1771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1770_1771 : H12AffineEnvironment.transform 3 12 env1770 = env1771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1770 == env1771) = true)

def leafEnv1771 : List Nat := [2,4,8,12,12,1,4,8,6,9,0,1,5,0,13,3,13,12,9,13,12,13,13,15,9,9,1,1,1,1,12,13,8,1,8,1,5,14,1,6,1,13,0]

def active1771 : List Nat := [0,1,2]

def tree1771 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1771 : H12WitnessSearch.Good tree1771 := H12GlobalWitnessIndex.good

theorem leafIdentity1771 : H12AffineFastState.composeSystem env1771 rootObs = leafEnv1771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1771 rootObs == leafEnv1771) = true)

theorem terminalChecked1771 : H12PackedTerminal.terminalCheckFast leafEnv1771 active1771 tree1771 = true := by decide +kernel

def env1772 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,64,579,539,587,601,587,17,84,587,16,17,17,19,595,64,0,538,16,16,85,1,85,1,538,512]

theorem envBound1772 : H12AffineFastState.Bounded env1772 := by
  intro p hp
  have h : env1772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1766_1772 : H12AffineEnvironment.transform 10 1 env1766 = env1772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1766 == env1772) = true)

theorem identity1772 : scanCanonicalize (H12AffineFastState.compose env1772 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1772 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1773 : List Nat := [2,4,8,16,16,64,24,85,22,84,1,64,85,13,93,79,93,17,84,93,16,17,17,19,69,64,0,12,16,16,85,1,85,1,12,22]

theorem envBound1773 : H12AffineFastState.Bounded env1773 := by
  intro p hp
  have h : env1773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1772_1773 : H12AffineEnvironment.transform 8 22 env1772 = env1773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1772 == env1773) = true)

def env1774 : List Nat := [2,4,8,16,16,0,24,21,22,20,1,0,21,13,29,15,29,17,20,29,16,17,17,19,5,0,0,12,16,16,21,1,21,1,12,22]

theorem envBound1774 : H12AffineFastState.Bounded env1774 := by
  intro p hp
  have h : env1774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1773_1774 : H12AffineEnvironment.transform 5 0 env1773 = env1774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1773 == env1774) = true)

theorem identity1774 : scanCanonicalize (H12AffineFastState.compose env1774 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1775 : List Nat := [2,4,5,16,16,0,21,21,22,20,1,0,21,0,16,2,16,17,20,16,16,17,17,19,5,0,0,1,16,16,21,1,21,1,1,22]

theorem envBound1775 : H12AffineFastState.Bounded env1775 := by
  intro p hp
  have h : env1775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1774_1775 : H12AffineEnvironment.transform 2 5 env1774 = env1775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1774 == env1775) = true)

def leafEnv1775 : List Nat := [2,4,5,16,16,0,21,21,22,20,1,0,21,0,16,2,16,17,20,16,16,17,17,19,20,5,1,0,0,1,16,16,21,1,21,1,5,19,1,22,1,17,0]

def active1775 : List Nat := [0,1,3]

def tree1775 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1775 : H12WitnessSearch.Good tree1775 := H12GlobalWitnessIndex.good

theorem leafIdentity1775 : H12AffineFastState.composeSystem env1775 rootObs = leafEnv1775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1775 rootObs == leafEnv1775) = true)

theorem terminalChecked1775 : H12PackedTerminal.terminalCheckFast leafEnv1775 active1775 tree1775 = true := by decide +kernel

def env1776 : List Nat := [2,4,8,16,16,1,24,20,22,21,1,1,20,13,28,14,28,17,21,28,16,17,17,19,4,1,0,12,16,16,20,1,20,1,12,22]

theorem envBound1776 : H12AffineFastState.Bounded env1776 := by
  intro p hp
  have h : env1776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1773_1776 : H12AffineEnvironment.transform 5 1 env1773 = env1776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1773 == env1776) = true)

def leafEnv1776 : List Nat := [2,4,8,16,16,1,24,20,22,21,1,1,20,13,28,14,28,17,21,28,16,17,17,19,21,4,1,1,0,12,16,16,20,1,20,1,5,31,12,22,1,17,0]

def active1776 : List Nat := [0,1,2,3]

def tree1776 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1776 : H12WitnessSearch.Good tree1776 := H12GlobalWitnessIndex.good

theorem leafIdentity1776 : H12AffineFastState.composeSystem env1776 rootObs = leafEnv1776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1776 rootObs == leafEnv1776) = true)

theorem terminalChecked1776 : H12PackedTerminal.terminalCheckFast leafEnv1776 active1776 tree1776 = true := by decide +kernel

def env1777 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,64,2626,2586,2634,2649,2634,2065,84,2634,16,16,17,18,2643,64,2049,2587,16,2064,85,1,85,1,2587,512]

theorem envBound1777 : H12AffineFastState.Bounded env1777 := by
  intro p hp
  have h : env1777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1765_1777 : H12AffineEnvironment.transform 4 17 env1765 = env1777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1765 == env1777) = true)

def env1778 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,64,578,538,586,601,586,17,84,586,16,16,17,18,595,64,1,539,16,16,85,1,85,1,539,512]

theorem envBound1778 : H12AffineFastState.Bounded env1778 := by
  intro p hp
  have h : env1778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1777_1778 : H12AffineEnvironment.transform 10 0 env1777 = env1778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1777 == env1778) = true)

theorem identity1778 : scanCanonicalize (H12AffineFastState.compose env1778 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound1778 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1779 : List Nat := [2,4,8,16,17,12,25,25,512,24,0,12,526,538,518,533,518,17,24,518,16,16,17,18,543,12,1,539,16,16,25,1,25,1,539,512]

theorem envBound1779 : H12AffineFastState.Bounded env1779 := by
  intro p hp
  have h : env1779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1778_1779 : H12AffineEnvironment.transform 5 12 env1778 = env1779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env1778 == env1779) = true)

def env1780 : List Nat := [2,4,4,16,17,0,21,21,512,20,0,0,514,534,518,533,518,17,20,518,16,16,17,18,531,0,1,535,16,16,21,1,21,1,535,512]

theorem envBound1780 : H12AffineFastState.Bounded env1780 := by
  intro p hp
  have h : env1780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1779_1780 : H12AffineEnvironment.transform 2 4 env1779 = env1780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1779 == env1780) = true)

def leafEnv1780 : List Nat := [2,4,4,16,17,0,21,21,512,20,0,0,514,534,518,533,518,17,20,518,16,16,17,18,20,531,1,0,1,535,16,16,21,1,21,1,5,517,535,512,1,17,0]

def active1780 : List Nat := [0,1,3,8]

def tree1780 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1780 : H12WitnessSearch.Good tree1780 := H12GlobalWitnessIndex.good

theorem leafIdentity1780 : H12AffineFastState.composeSystem env1780 rootObs = leafEnv1780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1780 rootObs == leafEnv1780) = true)

theorem terminalChecked1780 : H12PackedTerminal.terminalCheckFast leafEnv1780 active1780 tree1780 = true := by decide +kernel

def env1781 : List Nat := [2,4,5,16,17,1,20,20,512,21,0,1,515,535,518,533,518,17,21,518,16,16,17,18,530,1,1,534,16,16,20,1,20,1,534,512]

theorem envBound1781 : H12AffineFastState.Bounded env1781 := by
  intro p hp
  have h : env1781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1779_1781 : H12AffineEnvironment.transform 2 5 env1779 = env1781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1779 == env1781) = true)

theorem identity1781 : scanCanonicalize (H12AffineFastState.compose env1781 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1782 : List Nat := [2,4,5,16,17,1,20,20,22,21,0,1,21,1,16,3,16,17,21,16,16,16,17,18,4,1,1,0,16,16,20,1,20,1,0,22]

theorem envBound1782 : H12AffineFastState.Bounded env1782 := by
  intro p hp
  have h : env1782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1781_1782 : H12AffineEnvironment.transform 8 22 env1781 = env1782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1781 == env1782) = true)

def leafEnv1782 : List Nat := [2,4,5,16,17,1,20,20,22,21,0,1,21,1,16,3,16,17,21,16,16,16,17,18,21,4,1,1,1,0,16,16,20,1,20,1,5,19,0,22,1,17,0]

def active1782 : List Nat := [0,1,3]

def tree1782 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1782 : H12WitnessSearch.Good tree1782 := H12GlobalWitnessIndex.good

theorem leafIdentity1782 : H12AffineFastState.composeSystem env1782 rootObs = leafEnv1782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1782 rootObs == leafEnv1782) = true)

theorem terminalChecked1782 : H12PackedTerminal.terminalCheckFast leafEnv1782 active1782 tree1782 = true := by decide +kernel

def env1783 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,64,579,539,587,600,587,16,84,587,16,16,17,18,594,64,0,538,16,17,85,1,85,1,538,512]

theorem envBound1783 : H12AffineFastState.Bounded env1783 := by
  intro p hp
  have h : env1783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1777_1783 : H12AffineEnvironment.transform 10 1 env1777 = env1783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1777 == env1783) = true)

theorem identity1783 : scanCanonicalize (H12AffineFastState.compose env1783 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound1783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1784 : List Nat := [2,4,8,16,17,28,25,9,512,8,1,28,543,539,535,516,535,16,8,535,16,16,17,18,526,28,0,538,16,17,9,1,9,1,538,512]

theorem envBound1784 : H12AffineFastState.Bounded env1784 := by
  intro p hp
  have h : env1784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1783_1784 : H12AffineEnvironment.transform 5 28 env1783 = env1784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env1783 == env1784) = true)

def env1785 : List Nat := [2,4,8,12,13,0,5,9,512,8,1,0,515,519,523,516,523,12,8,523,12,12,13,14,526,0,0,518,12,13,9,1,9,1,518,512]

theorem envBound1785 : H12AffineFastState.Bounded env1785 := by
  intro p hp
  have h : env1785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1784_1785 : H12AffineEnvironment.transform 3 12 env1784 = env1785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1784 == env1785) = true)

theorem identity1785 : scanCanonicalize (H12AffineFastState.compose env1785 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1786 : List Nat := [2,4,8,12,13,0,5,9,6,8,1,0,5,1,13,2,13,12,8,13,12,12,13,14,8,0,0,0,12,13,9,1,9,1,0,6]

theorem envBound1786 : H12AffineFastState.Bounded env1786 := by
  intro p hp
  have h : env1786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1785_1786 : H12AffineEnvironment.transform 8 6 env1785 = env1786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1785 == env1786) = true)

def leafEnv1786 : List Nat := [2,4,8,12,13,0,5,9,6,8,1,0,5,1,13,2,13,12,8,13,12,12,13,14,8,8,1,0,0,0,12,13,9,1,9,1,5,14,0,6,1,13,0]

def active1786 : List Nat := [0,1,2]

def tree1786 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1786 : H12WitnessSearch.Good tree1786 := H12GlobalWitnessIndex.good

theorem leafIdentity1786 : H12AffineFastState.composeSystem env1786 rootObs = leafEnv1786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1786 rootObs == leafEnv1786) = true)

theorem terminalChecked1786 : H12PackedTerminal.terminalCheckFast leafEnv1786 active1786 tree1786 = true := by decide +kernel

def env1787 : List Nat := [2,4,8,13,12,1,4,9,512,8,1,1,514,518,522,516,522,13,8,522,13,13,12,15,526,1,0,519,13,12,9,1,9,1,519,512]

theorem envBound1787 : H12AffineFastState.Bounded env1787 := by
  intro p hp
  have h : env1787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1784_1787 : H12AffineEnvironment.transform 3 13 env1784 = env1787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1784 == env1787) = true)

def leafEnv1787 : List Nat := [2,4,8,13,12,1,4,9,512,8,1,1,514,518,522,516,522,13,8,522,13,13,12,15,8,526,1,1,0,519,13,12,9,1,9,1,5,521,519,512,1,12,0]

def active1787 : List Nat := [0,1,2,8]

def tree1787 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1787 : H12WitnessSearch.Good tree1787 := H12GlobalWitnessIndex.good

theorem leafIdentity1787 : H12AffineFastState.composeSystem env1787 rootObs = leafEnv1787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1787 rootObs == leafEnv1787) = true)

theorem terminalChecked1787 : H12PackedTerminal.terminalCheckFast leafEnv1787 active1787 tree1787 = true := by decide +kernel

def env1788 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76385,2081,74882,8200,74950,73891,185,73737,8328,73834,75906,2587,74863,2081,74883,1,73855,1,76440,512]

theorem envBound1788 : H12AffineFastState.Bounded env1788 := by
  intro p hp
  have h : env1788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1760_1788 : H12AffineEnvironment.transform 16 76385 env1760 = env1788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1760 == env1788) = true)

theorem identity1788 : scanCanonicalize (H12AffineFastState.compose env1788 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound1788 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1789 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,99,10754,2081,9441,8200,9381,8384,185,8298,8328,8201,10465,2587,9228,2081,9440,1,8220,1,11003,512]

theorem envBound1789 : H12AffineFastState.Bounded env1789 := by
  intro p hp
  have h : env1789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1788_1789 : H12AffineEnvironment.transform 15 99 env1788 = env1789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env1788 == env1789) = true)

def env1790 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,131072,205377,74882,8200,74951,73891,185,73737,8328,73834,131810,2586,134670,2081,74883,1,73855,1,131321,512]

theorem envBound1790 : H12AffineFastState.Bounded env1790 := by
  intro p hp
  have h : env1790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1759_1790 : H12AffineEnvironment.transform 11 1045 env1759 = env1790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1759 == env1790) = true)

def env1791 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76384,2081,74882,8200,74951,73891,185,73737,8328,73834,75906,2586,74862,2081,74883,1,73855,1,76441,512]

theorem envBound1791 : H12AffineFastState.Bounded env1791 := by
  intro p hp
  have h : env1791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1790_1791 : H12AffineEnvironment.transform 16 76384 env1790 = env1791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1790 == env1791) = true)

theorem identity1791 : scanCanonicalize (H12AffineFastState.compose env1791 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound1791 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1792 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,225,2587,233,65536,68225,2081,66659,233,66598,65602,185,65768,105,65675,67683,2586,66703,2081,66658,1,65694,1,68216,512]

theorem envBound1792 : H12AffineFastState.Bounded env1792 := by
  intro p hp
  have h : env1792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1791_1792 : H12AffineEnvironment.transform 12 225 env1791 = env1792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env1791 == env1792) = true)

def env1793 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76385,2080,74882,8200,74951,73891,185,73737,8328,73834,75907,2586,74863,2081,74883,1,73855,1,76440,512]

theorem envBound1793 : H12AffineFastState.Bounded env1793 := by
  intro p hp
  have h : env1793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1790_1793 : H12AffineEnvironment.transform 16 76385 env1790 = env1793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1790 == env1793) = true)

theorem identity1793 : scanCanonicalize (H12AffineFastState.compose env1793 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1793 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1794 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,3732,9461,2080,10774,8200,10835,11831,185,11933,8328,12030,9751,2586,11003,2081,10775,1,12011,1,9228,512]

theorem envBound1794 : H12AffineFastState.Bounded env1794 := by
  intro p hp
  have h : env1794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1793_1794 : H12AffineEnvironment.transform 15 3732 env1793 = env1794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1793 == env1794) = true)

theorem identity1794 : scanCanonicalize (H12AffineFastState.compose env1794 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1794 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1795 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2587,3614,3732,2787,2080,1024,3614,1093,33,185,139,3742,232,2049,2586,1261,2081,1025,1,253,1,2586,512]

theorem envBound1795 : H12AffineFastState.Bounded env1795 := by
  intro p hp
  have h : env1795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1794_1795 : H12AffineEnvironment.transform 12 3606 env1794 = env1795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1794 == env1795) = true)

theorem identity1795 : scanCanonicalize (H12AffineFastState.compose env1795 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1795 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1796 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2626,2587,2634,2752,2787,2080,84,2634,17,33,185,139,2762,232,2049,2586,185,2081,85,1,253,1,2586,512]

theorem envBound1796 : H12AffineFastState.Bounded env1796 := by
  intro p hp
  have h : env1796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1795_1796 : H12AffineEnvironment.transform 9 84 env1795 = env1796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1795 == env1796) = true)

theorem identity1796 : scanCanonicalize (H12AffineFastState.compose env1796 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1796 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1797 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,65,2626,2587,2634,2664,2635,2080,84,2634,17,33,17,35,2658,64,2049,2586,17,2081,85,1,85,1,2586,512]

theorem envBound1797 : H12AffineFastState.Bounded env1797 := by
  intro p hp
  have h : env1797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1796_1797 : H12AffineEnvironment.transform 6 40 env1796 = env1797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1796 == env1797) = true)

def env1798 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,65,2626,2587,2634,2648,2635,2064,84,2634,17,17,17,19,2642,64,2049,2586,17,2065,85,1,85,1,2586,512]

theorem envBound1798 : H12AffineFastState.Bounded env1798 := by
  intro p hp
  have h : env1798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1797_1798 : H12AffineEnvironment.transform 4 16 env1797 = env1798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1797 == env1798) = true)

def env1799 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,65,578,539,586,600,587,16,84,586,17,17,17,19,594,64,1,538,17,17,85,1,85,1,538,512]

theorem envBound1799 : H12AffineFastState.Bounded env1799 := by
  intro p hp
  have h : env1799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1798_1799 : H12AffineEnvironment.transform 10 0 env1798 = env1799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1798 == env1799) = true)

theorem identity1799 : scanCanonicalize (H12AffineFastState.compose env1799 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1799 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1800 : List Nat := [2,4,5,16,16,64,21,85,512,84,0,65,578,534,583,597,582,16,84,583,17,17,17,19,594,64,1,535,17,17,85,1,85,1,535,512]

theorem envBound1800 : H12AffineFastState.Bounded env1800 := by
  intro p hp
  have h : env1800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1799_1800 : H12AffineEnvironment.transform 2 5 env1799 = env1800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1799 == env1800) = true)

def env1801 : List Nat := [2,4,5,16,16,0,21,21,512,20,0,1,514,534,519,533,518,16,20,519,17,17,17,19,530,0,1,535,17,17,21,1,21,1,535,512]

theorem envBound1801 : H12AffineFastState.Bounded env1801 := by
  intro p hp
  have h : env1801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1800_1801 : H12AffineEnvironment.transform 5 0 env1800 = env1801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1800 == env1801) = true)

theorem identity1801 : scanCanonicalize (H12AffineFastState.compose env1801 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1802 : List Nat := [2,4,5,16,16,0,21,21,23,20,0,1,21,1,16,2,17,16,20,16,17,17,17,19,5,0,1,0,17,17,21,1,21,1,0,23]

theorem envBound1802 : H12AffineFastState.Bounded env1802 := by
  intro p hp
  have h : env1802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1801_1802 : H12AffineEnvironment.transform 8 23 env1801 = env1802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1801 == env1802) = true)

def leafEnv1802 : List Nat := [2,4,5,16,16,0,21,21,23,20,0,1,21,1,16,2,17,16,20,16,17,17,17,19,20,5,1,0,1,0,17,17,21,1,21,1,5,19,0,23,1,16,0]

def active1802 : List Nat := [0,1,3]

def tree1802 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1802 : H12WitnessSearch.Good tree1802 := H12GlobalWitnessIndex.good

theorem leafIdentity1802 : H12AffineFastState.composeSystem env1802 rootObs = leafEnv1802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1802 rootObs == leafEnv1802) = true)

theorem terminalChecked1802 : H12PackedTerminal.terminalCheckFast leafEnv1802 active1802 tree1802 = true := by decide +kernel

def env1803 : List Nat := [2,4,5,16,16,1,21,20,512,21,0,0,515,534,518,532,519,16,21,518,17,17,17,19,531,1,1,535,17,17,20,1,20,1,535,512]

theorem envBound1803 : H12AffineFastState.Bounded env1803 := by
  intro p hp
  have h : env1803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1800_1803 : H12AffineEnvironment.transform 5 1 env1800 = env1803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1800 == env1803) = true)

def leafEnv1803 : List Nat := [2,4,5,16,16,1,21,20,512,21,0,0,515,534,518,532,519,16,21,518,17,17,17,19,21,531,1,1,1,535,17,17,20,1,20,1,5,517,535,512,1,16,0]

def active1803 : List Nat := [0,1,3,8]

def tree1803 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1803 : H12WitnessSearch.Good tree1803 := H12GlobalWitnessIndex.good

theorem leafIdentity1803 : H12AffineFastState.composeSystem env1803 rootObs = leafEnv1803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1803 rootObs == leafEnv1803) = true)

theorem terminalChecked1803 : H12PackedTerminal.terminalCheckFast leafEnv1803 active1803 tree1803 = true := by decide +kernel

def env1804 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,65,579,538,587,601,586,17,84,587,17,17,17,19,595,64,0,539,17,16,85,1,85,1,539,512]

theorem envBound1804 : H12AffineFastState.Bounded env1804 := by
  intro p hp
  have h : env1804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1798_1804 : H12AffineEnvironment.transform 10 1 env1798 = env1804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1798 == env1804) = true)

theorem identity1804 : scanCanonicalize (H12AffineFastState.compose env1804 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1805 : List Nat := [2,4,8,12,12,64,4,73,512,72,1,65,579,518,587,581,586,13,72,587,13,13,13,15,591,64,0,519,13,12,73,1,73,1,519,512]

theorem envBound1805 : H12AffineFastState.Bounded env1805 := by
  intro p hp
  have h : env1805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1804_1805 : H12AffineEnvironment.transform 3 12 env1804 = env1805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1804 == env1805) = true)

def env1806 : List Nat := [2,4,8,12,12,0,4,9,512,8,1,1,515,518,523,517,522,13,8,523,13,13,13,15,527,0,0,519,13,12,9,1,9,1,519,512]

theorem envBound1806 : H12AffineFastState.Bounded env1806 := by
  intro p hp
  have h : env1806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1805_1806 : H12AffineEnvironment.transform 5 0 env1805 = env1806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1805 == env1806) = true)

def leafEnv1806 : List Nat := [2,4,8,12,12,0,4,9,512,8,1,1,515,518,523,517,522,13,8,523,13,13,13,15,8,527,1,0,0,519,13,12,9,1,9,1,5,520,519,512,1,12,0]

def active1806 : List Nat := [0,1,2,8]

def tree1806 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1806 : H12WitnessSearch.Good tree1806 := H12GlobalWitnessIndex.good

theorem leafIdentity1806 : H12AffineFastState.composeSystem env1806 rootObs = leafEnv1806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1806 rootObs == leafEnv1806) = true)

theorem terminalChecked1806 : H12PackedTerminal.terminalCheckFast leafEnv1806 active1806 tree1806 = true := by decide +kernel

def env1807 : List Nat := [2,4,8,12,12,1,4,8,512,9,1,0,514,518,522,516,523,13,9,522,13,13,13,15,526,1,0,519,13,12,8,1,8,1,519,512]

theorem envBound1807 : H12AffineFastState.Bounded env1807 := by
  intro p hp
  have h : env1807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1805_1807 : H12AffineEnvironment.transform 5 1 env1805 = env1807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1805 == env1807) = true)

theorem identity1807 : scanCanonicalize (H12AffineFastState.compose env1807 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1808 : List Nat := [2,4,8,12,12,1,4,8,7,9,1,0,5,1,13,3,12,13,9,13,13,13,13,15,9,1,0,0,13,12,8,1,8,1,0,7]

theorem envBound1808 : H12AffineFastState.Bounded env1808 := by
  intro p hp
  have h : env1808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1807_1808 : H12AffineEnvironment.transform 8 7 env1807 = env1808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1807 == env1808) = true)

def leafEnv1808 : List Nat := [2,4,8,12,12,1,4,8,7,9,1,0,5,1,13,3,12,13,9,13,13,13,13,15,9,9,1,1,0,0,13,12,8,1,8,1,5,14,0,7,1,12,0]

def active1808 : List Nat := [0,1,2]

def tree1808 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1808 : H12WitnessSearch.Good tree1808 := H12GlobalWitnessIndex.good

theorem leafIdentity1808 : H12AffineFastState.composeSystem env1808 rootObs = leafEnv1808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1808 rootObs == leafEnv1808) = true)

theorem terminalChecked1808 : H12PackedTerminal.terminalCheckFast leafEnv1808 active1808 tree1808 = true := by decide +kernel

def env1809 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,65,2626,2587,2634,2649,2635,2065,84,2634,17,16,17,18,2643,64,2049,2586,17,2064,85,1,85,1,2586,512]

theorem envBound1809 : H12AffineFastState.Bounded env1809 := by
  intro p hp
  have h : env1809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1797_1809 : H12AffineEnvironment.transform 4 17 env1797 = env1809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1797 == env1809) = true)

def env1810 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,65,578,539,586,601,587,17,84,586,17,16,17,18,595,64,1,538,17,16,85,1,85,1,538,512]

theorem envBound1810 : H12AffineFastState.Bounded env1810 := by
  intro p hp
  have h : env1810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1809_1810 : H12AffineEnvironment.transform 10 0 env1809 = env1810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1809 == env1810) = true)

theorem identity1810 : scanCanonicalize (H12AffineFastState.compose env1810 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound1810 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1811 : List Nat := [2,4,8,16,17,64,25,85,71,84,0,65,5,92,13,30,12,17,84,13,17,16,17,18,20,64,1,93,17,16,85,1,85,1,93,71]

theorem envBound1811 : H12AffineFastState.Bounded env1811 := by
  intro p hp
  have h : env1811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1810_1811 : H12AffineEnvironment.transform 8 71 env1810 = env1811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env1810 == env1811) = true)

def env1812 : List Nat := [2,4,8,16,17,0,25,21,7,20,0,1,5,28,13,30,12,17,20,13,17,16,17,18,20,0,1,29,17,16,21,1,21,1,29,7]

theorem envBound1812 : H12AffineFastState.Bounded env1812 := by
  intro p hp
  have h : env1812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1811_1812 : H12AffineEnvironment.transform 5 0 env1811 = env1812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1811 == env1812) = true)

theorem identity1812 : scanCanonicalize (H12AffineFastState.compose env1812 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1812 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1813 : List Nat := [2,4,8,12,13,0,5,9,7,8,0,1,5,0,13,2,12,13,8,13,13,12,13,14,8,0,1,1,13,12,9,1,9,1,1,7]

theorem envBound1813 : H12AffineFastState.Bounded env1813 := by
  intro p hp
  have h : env1813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1812_1813 : H12AffineEnvironment.transform 3 12 env1812 = env1813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1812 == env1813) = true)

def leafEnv1813 : List Nat := [2,4,8,12,13,0,5,9,7,8,0,1,5,0,13,2,12,13,8,13,13,12,13,14,8,8,1,0,1,1,13,12,9,1,9,1,5,14,1,7,1,12,0]

def active1813 : List Nat := [0,1,2]

def tree1813 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1813 : H12WitnessSearch.Good tree1813 := H12GlobalWitnessIndex.good

theorem leafIdentity1813 : H12AffineFastState.composeSystem env1813 rootObs = leafEnv1813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1813 rootObs == leafEnv1813) = true)

theorem terminalChecked1813 : H12PackedTerminal.terminalCheckFast leafEnv1813 active1813 tree1813 = true := by decide +kernel

def env1814 : List Nat := [2,4,8,16,17,1,25,20,6,21,0,0,5,29,13,30,12,17,21,13,17,16,17,18,20,1,1,28,17,16,20,1,20,1,28,6]

theorem envBound1814 : H12AffineFastState.Bounded env1814 := by
  intro p hp
  have h : env1814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1811_1814 : H12AffineEnvironment.transform 5 1 env1811 = env1814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1811 == env1814) = true)

def leafEnv1814 : List Nat := [2,4,8,16,17,1,25,20,6,21,0,0,5,29,13,30,12,17,21,13,17,16,17,18,21,20,1,1,1,28,17,16,20,1,20,1,5,14,28,6,1,16,0]

def active1814 : List Nat := [0,1,2,3]

def tree1814 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1814 : H12WitnessSearch.Good tree1814 := H12GlobalWitnessIndex.good

theorem leafIdentity1814 : H12AffineFastState.composeSystem env1814 rootObs = leafEnv1814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1814 rootObs == leafEnv1814) = true)

theorem terminalChecked1814 : H12PackedTerminal.terminalCheckFast leafEnv1814 active1814 tree1814 = true := by decide +kernel

def env1815 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,65,579,538,587,600,586,16,84,587,17,16,17,18,594,64,0,539,17,17,85,1,85,1,539,512]

theorem envBound1815 : H12AffineFastState.Bounded env1815 := by
  intro p hp
  have h : env1815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1809_1815 : H12AffineEnvironment.transform 10 1 env1809 = env1815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1809 == env1815) = true)

theorem identity1815 : scanCanonicalize (H12AffineFastState.compose env1815 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound1815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1816 : List Nat := [2,4,8,16,17,64,25,85,86,84,1,65,21,76,29,14,28,16,84,29,17,16,17,18,4,64,0,77,17,17,85,1,85,1,77,86]

theorem envBound1816 : H12AffineFastState.Bounded env1816 := by
  intro p hp
  have h : env1816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1815_1816 : H12AffineEnvironment.transform 8 86 env1815 = env1816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env1815 == env1816) = true)

def env1817 : List Nat := [2,4,8,16,17,0,25,21,22,20,1,1,21,12,29,14,28,16,20,29,17,16,17,18,4,0,0,13,17,17,21,1,21,1,13,22]

theorem envBound1817 : H12AffineFastState.Bounded env1817 := by
  intro p hp
  have h : env1817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1816_1817 : H12AffineEnvironment.transform 5 0 env1816 = env1817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1816 == env1817) = true)

def leafEnv1817 : List Nat := [2,4,8,16,17,0,25,21,22,20,1,1,21,12,29,14,28,16,20,29,17,16,17,18,20,4,1,0,0,13,17,17,21,1,21,1,5,30,13,22,1,16,0]

def active1817 : List Nat := [0,1,2,3]

def tree1817 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1817 : H12WitnessSearch.Good tree1817 := H12GlobalWitnessIndex.good

theorem leafIdentity1817 : H12AffineFastState.composeSystem env1817 rootObs = leafEnv1817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1817 rootObs == leafEnv1817) = true)

theorem terminalChecked1817 : H12PackedTerminal.terminalCheckFast leafEnv1817 active1817 tree1817 = true := by decide +kernel

def env1818 : List Nat := [2,4,8,16,17,1,25,20,23,21,1,0,21,13,29,14,28,16,21,29,17,16,17,18,4,1,0,12,17,17,20,1,20,1,12,23]

theorem envBound1818 : H12AffineFastState.Bounded env1818 := by
  intro p hp
  have h : env1818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1816_1818 : H12AffineEnvironment.transform 5 1 env1816 = env1818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1816 == env1818) = true)

theorem identity1818 : scanCanonicalize (H12AffineFastState.compose env1818 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1819 : List Nat := [2,4,5,16,17,1,20,20,23,21,1,0,21,0,16,3,17,16,21,16,17,16,17,18,4,1,0,1,17,17,20,1,20,1,1,23]

theorem envBound1819 : H12AffineFastState.Bounded env1819 := by
  intro p hp
  have h : env1819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1818_1819 : H12AffineEnvironment.transform 2 5 env1818 = env1819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1818 == env1819) = true)

def leafEnv1819 : List Nat := [2,4,5,16,17,1,20,20,23,21,1,0,21,0,16,3,17,16,21,16,17,16,17,18,21,4,1,1,0,1,17,17,20,1,20,1,5,19,1,23,1,16,0]

def active1819 : List Nat := [0,1,3]

def tree1819 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1819 : H12WitnessSearch.Good tree1819 := H12GlobalWitnessIndex.good

theorem leafIdentity1819 : H12AffineFastState.composeSystem env1819 rootObs = leafEnv1819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1819 rootObs == leafEnv1819) = true)

theorem terminalChecked1819 : H12PackedTerminal.terminalCheckFast leafEnv1819 active1819 tree1819 = true := by decide +kernel

def env1820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,268453921,92374097,281601388,525568,268451841,34359738368,25733063]

theorem envBound1820 : H12AffineFastState.Bounded env1820 := by
  intro p hp
  have h : env1820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans780_1820 : H12AffineEnvironment.transform 29 268453921 env780 = env1820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 268453921 env780 == env1820) = true)

def env1821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,268435456,268570625,268453921,17399809,281601388,525568,268451841,34359738368,25733063]

theorem envBound1821 : H12AffineFastState.Bounded env1821 := by
  intro p hp
  have h : env1821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1820_1821 : H12AffineEnvironment.transform 25 8914000 env1820 = env1821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env1820 == env1821) = true)

def env1822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2081,17399809,13149548,525568,1,34359738368,25733063]

theorem envBound1822 : H12AffineFastState.Bounded env1822 := by
  intro p hp
  have h : env1822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1821_1822 : H12AffineEnvironment.transform 27 16384 env1821 = env1822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env1821 == env1822) = true)

def env1823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2081,17375733,13108376,525568,1,34359738368,25691699]

theorem envBound1823 : H12AffineFastState.Bounded env1823 := by
  intro p hp
  have h : env1823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1822_1823 : H12AffineEnvironment.transform 14 8692 env1822 = env1823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env1822 == env1823) = true)

def env1824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147520,16777216,8328,672784,935128,16384,151553,2081,17375733,4867288,525568,1,34359738368,17450611]

theorem envBound1824 : H12AffineFastState.Bounded env1824 := by
  intro p hp
  have h : env1824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1823_1824 : H12AffineEnvironment.transform 22 147520 env1823 = env1824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env1823 == env1824) = true)

def env1825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,34359738368,16925299]

theorem envBound1825 : H12AffineFastState.Bounded env1825 := by
  intro p hp
  have h : env1825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1824_1825 : H12AffineEnvironment.transform 18 1024 env1824 = env1825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1824 == env1825) = true)

def env1826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,131072,16925299]

theorem envBound1826 : H12AffineFastState.Bounded env1826 := by
  intro p hp
  have h : env1826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1825_1826 : H12AffineEnvironment.transform 34 131072 env1825 = env1826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1825 == env1826) = true)

theorem identity1826 : scanCanonicalize (H12AffineFastState.compose env1826 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound1826 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16794934,4341976,256,1,131072,16925299]

theorem envBound1827 : H12AffineFastState.Bounded env1827 := by
  intro p hp
  have h : env1827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1826_1827 : H12AffineEnvironment.transform 15 24771 env1826 = env1827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env1826 == env1827) = true)

theorem identity1827 : scanCanonicalize (H12AffineFastState.compose env1827 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 292) := by decide +kernel

theorem selectedBound1827 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,131072,262144,1024,8692,2097152,292,147520,16777216,8328,147472,409816,16384,151553,2081,16794934,147964,256,1,131072,16925299]

theorem envBound1828 : H12AffineFastState.Bounded env1828 := by
  intro p hp
  have h : env1828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1827_1828 : H12AffineEnvironment.transform 21 292 env1827 = env1828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292 env1827 == env1828) = true)

def env1829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,16892,262144,1024,8692,2097152,292,444,16777216,8328,492,262436,16384,4605,2081,16794934,0,256,1,16892,16778127]

theorem envBound1829 : H12AffineFastState.Bounded env1829 := by
  intro p hp
  have h : env1829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1828_1829 : H12AffineEnvironment.transform 16 16892 env1828 = env1829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1828 == env1829) = true)

theorem identity1829 : scanCanonicalize (H12AffineFastState.compose env1829 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound1829 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,444,8692,8575,64,262144,1024,8692,2097152,292,444,16777216,8328,492,262436,444,4605,2081,16778378,0,256,1,64,16778127]

theorem envBound1830 : H12AffineFastState.Bounded env1830 := by
  intro p hp
  have h : env1830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1829_1830 : H12AffineEnvironment.transform 13 444 env1829 = env1830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env1829 == env1830) = true)

def env1831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,16893,262144,1024,8692,2097152,292,445,16777216,8328,493,262437,16384,4604,2081,16794934,1,256,1,16893,16778126]

theorem envBound1831 : H12AffineFastState.Bounded env1831 := by
  intro p hp
  have h : env1831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1828_1831 : H12AffineEnvironment.transform 16 16893 env1828 = env1831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1828 == env1831) = true)

theorem identity1831 : scanCanonicalize (H12AffineFastState.compose env1831 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 16434) := by decide +kernel

theorem selectedBound1831 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,16893,262144,1024,8692,2097152,292,445,16434,8328,493,262437,16384,4604,2081,1284,1,256,1,16893,17340]

theorem envBound1832 : H12AffineFastState.Bounded env1832 := by
  intro p hp
  have h : env1832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1831_1832 : H12AffineEnvironment.transform 23 16434 env1831 = env1832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 16434 env1831 == env1832) = true)

theorem identity1832 : scanCanonicalize (H12AffineFastState.compose env1832 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound1832 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env1833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,16893,2264,1024,8692,2097152,292,445,16434,8328,493,2557,16384,4604,2081,1284,1,256,1,16893,17340]

theorem envBound1833 : H12AffineFastState.Bounded env1833 := by
  intro p hp
  have h : env1833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1832_1833 : H12AffineEnvironment.transform 17 2264 env1832 = env1833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env1832 == env1833) = true)

theorem identity1833 : scanCanonicalize (H12AffineFastState.compose env1833 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound1833 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env1834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8692,8315,325,2264,1024,8692,2097152,292,445,138,8328,493,2557,184,4604,2081,1284,1,256,1,325,772]

theorem envBound1834 : H12AffineFastState.Bounded env1834 := by
  intro p hp
  have h : env1834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1833_1834 : H12AffineEnvironment.transform 13 184 env1833 = env1834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env1833 == env1834) = true)

theorem identity1834 : scanCanonicalize (H12AffineFastState.compose env1834 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11690) := by decide +kernel

theorem selectedBound1834 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8692,8315,325,2264,1024,8692,11690,292,445,138,8328,493,2557,184,4604,2081,1284,1,256,1,325,772]

theorem envBound1835 : H12AffineFastState.Bounded env1835 := by
  intro p hp
  have h : env1835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1834_1835 : H12AffineEnvironment.transform 20 11690 env1834 = env1835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11690 env1834 == env1835) = true)

theorem identity1835 : scanCanonicalize (H12AffineFastState.compose env1835 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3117) := by decide +kernel

theorem selectedBound1835 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env1836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3117,184,3545,3158,325,2264,1024,3545,391,292,445,138,3237,493,2557,184,4604,2081,1284,1,256,1,325,772]

theorem envBound1836 : H12AffineFastState.Bounded env1836 := by
  intro p hp
  have h : env1836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1835_1836 : H12AffineEnvironment.transform 12 3117 env1835 = env1836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3117 env1835 == env1836) = true)

def env1837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,131073,16925299]

theorem envBound1837 : H12AffineFastState.Bounded env1837 := by
  intro p hp
  have h : env1837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1825_1837 : H12AffineEnvironment.transform 34 131073 env1825 = env1837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1825 == env1837) = true)

theorem identity1837 : scanCanonicalize (H12AffineFastState.compose env1837 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 94403) := by decide +kernel

theorem selectedBound1837 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,94403,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,131073,16925299]

theorem envBound1838 : H12AffineFastState.Bounded env1838 := by
  intro p hp
  have h : env1838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1837_1838 : H12AffineEnvironment.transform 20 94403 env1837 = env1838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 94403 env1837 == env1838) = true)

theorem identity1838 : scanCanonicalize (H12AffineFastState.compose env1838 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1838 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,20664,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16778638,4341976,256,1,131073,16925299]

theorem envBound1839 : H12AffineFastState.Bounded env1839 := by
  intro p hp
  have h : env1839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1838_1839 : H12AffineEnvironment.transform 15 8315 env1838 = env1839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1838 == env1839) = true)

def env1840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,20664,147672,147520,16777216,8328,147472,409816,16384,151553,2081,16778638,0,256,1,131073,16925299]

theorem envBound1840 : H12AffineFastState.Bounded env1840 := by
  intro p hp
  have h : env1840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1839_1840 : H12AffineEnvironment.transform 21 147672 env1839 = env1840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1839 == env1840) = true)

theorem identity1840 : scanCanonicalize (H12AffineFastState.compose env1840 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1840 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1841 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8432,8315,131072,262144,1024,8432,20664,147672,147520,16777216,8328,147472,409816,16384,151553,2081,16778378,0,4,1,131073,16925299]

theorem envBound1841 : H12AffineFastState.Bounded env1841 := by
  intro p hp
  have h : env1841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1840_1841 : H12AffineEnvironment.transform 7 4 env1840 = env1841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1840 == env1841) = true)

def env1842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,20664,147673,147520,16777216,8328,147472,409816,16384,151553,2081,16778638,1,256,1,131073,16925299]

theorem envBound1842 : H12AffineFastState.Bounded env1842 := by
  intro p hp
  have h : env1842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1839_1842 : H12AffineEnvironment.transform 21 147673 env1839 = env1842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1839 == env1842) = true)

theorem identity1842 : scanCanonicalize (H12AffineFastState.compose env1842 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147831) := by decide +kernel

theorem selectedBound1842 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,20664,147673,147520,147831,8328,147472,409816,16384,151553,2081,148729,1,256,1,131073,772]

theorem envBound1843 : H12AffineFastState.Bounded env1843 := by
  intro p hp
  have h : env1843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1842_1843 : H12AffineEnvironment.transform 23 147831 env1842 = env1843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147831 env1842 == env1843) = true)

theorem identity1843 : scanCanonicalize (H12AffineFastState.compose env1843 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1843 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,2525,1024,8692,20664,147673,147520,147831,8328,147472,149765,16384,151553,2081,148729,1,256,1,131073,772]

theorem envBound1844 : H12AffineFastState.Bounded env1844 := by
  intro p hp
  have h : env1844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1843_1844 : H12AffineEnvironment.transform 17 2525 env1843 = env1844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1843 == env1844) = true)

theorem identity1844 : scanCanonicalize (H12AffineFastState.compose env1844 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1844 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env1845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,16633,2525,1024,8692,20664,32,185,398,8328,233,2556,16384,4344,2081,1024,1,256,1,16632,772]

theorem envBound1845 : H12AffineFastState.Bounded env1845 := by
  intro p hp
  have h : env1845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1844_1845 : H12AffineEnvironment.transform 16 16633 env1844 = env1845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1844 == env1845) = true)

theorem identity1845 : scanCanonicalize (H12AffineFastState.compose env1845 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1845 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env1846 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8315,16633,2264,1024,8433,20664,32,185,139,8328,233,2297,16384,4344,2081,1024,1,5,1,16632,513]

theorem envBound1846 : H12AffineFastState.Bounded env1846 := by
  intro p hp
  have h : env1846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1845_1846 : H12AffineEnvironment.transform 7 5 env1845 = env1846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1845 == env1846) = true)

theorem identity1846 : scanCanonicalize (H12AffineFastState.compose env1846 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3766) := by decide +kernel

theorem selectedBound1846 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1847 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,3766,8433,8315,3663,2264,1024,8433,7694,32,185,139,8328,233,2297,3766,4344,2081,1024,1,5,1,3662,513]

theorem envBound1847 : H12AffineFastState.Bounded env1847 := by
  intro p hp
  have h : env1847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1846_1847 : H12AffineEnvironment.transform 13 3766 env1846 = env1847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3766 env1846 == env1847) = true)

theorem identity1847 : scanCanonicalize (H12AffineFastState.compose env1847 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1847 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1848 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1750,4096,8192,96,8433,8315,153,1550,1024,8433,4312,32,185,139,8328,233,1583,96,4344,1783,1024,1,5,1,152,513]

theorem envBound1848 : H12AffineFastState.Bounded env1848 := by
  intro p hp
  have h : env1848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1847_1848 : H12AffineEnvironment.transform 10 1750 env1847 = env1848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1750 env1847 == env1848) = true)

theorem identity1848 : scanCanonicalize (H12AffineFastState.compose env1848 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound1848 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1849 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1750,4096,1156,96,1141,1279,153,1550,1024,1141,4312,32,185,139,1036,233,1583,96,4344,1783,1024,1,5,1,152,513]

theorem envBound1849 : H12AffineFastState.Bounded env1849 := by
  intro p hp
  have h : env1849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1848_1849 : H12AffineEnvironment.transform 12 1156 env1848 = env1849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env1848 == env1849) = true)

theorem identity1849 : scanCanonicalize (H12AffineFastState.compose env1849 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1751) := by decide +kernel

theorem selectedBound1849 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env1850 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1750,1751,1156,96,1141,1279,153,1550,1024,1141,1551,32,185,139,1036,233,1583,96,1583,1783,1024,1,5,1,152,513]

theorem envBound1850 : H12AffineFastState.Bounded env1850 := by
  intro p hp
  have h : env1850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1849_1850 : H12AffineEnvironment.transform 11 1751 env1849 = env1850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1751 env1849 == env1850) = true)

theorem identity1850 : scanCanonicalize (H12AffineFastState.compose env1850 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 646) := by decide +kernel

theorem selectedBound1850 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1851 : List Nat := [2,4,8,16,32,64,128,5,512,646,80,81,514,96,755,633,153,136,646,755,137,32,185,139,650,233,169,96,169,113,646,1,5,1,152,513]

theorem envBound1851 : H12AffineFastState.Bounded env1851 := by
  intro p hp
  have h : env1851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1850_1851 : H12AffineEnvironment.transform 9 646 env1850 = env1851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 646 env1850 == env1851) = true)

theorem identity1851 : scanCanonicalize (H12AffineFastState.compose env1851 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1851 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1852 : List Nat := [2,4,8,16,32,64,120,5,512,638,80,81,514,96,523,633,97,112,638,523,113,32,65,115,626,17,81,96,81,113,638,1,5,1,96,513]

theorem envBound1852 : H12AffineFastState.Bounded env1852 := by
  intro p hp
  have h : env1852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1851_1852 : H12AffineEnvironment.transform 6 120 env1851 = env1852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1851 == env1852) = true)

theorem identity1852 : scanCanonicalize (H12AffineFastState.compose env1852 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound1852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1853 : List Nat := [2,4,8,16,32,64,120,5,107,21,80,81,105,96,96,18,97,112,21,96,113,32,65,115,25,17,81,96,81,113,21,1,5,1,96,106]

theorem envBound1853 : H12AffineFastState.Bounded env1853 := by
  intro p hp
  have h : env1853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1852_1853 : H12AffineEnvironment.transform 8 107 env1852 = env1853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env1852 == env1853) = true)

theorem identity1853 : scanCanonicalize (H12AffineFastState.compose env1853 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound1853 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1854 : List Nat := [2,4,8,0,32,64,104,5,107,5,64,65,105,96,96,2,97,96,5,96,97,32,65,99,9,1,65,96,65,97,5,1,5,1,96,106]

theorem envBound1854 : H12AffineFastState.Bounded env1854 := by
  intro p hp
  have h : env1854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1853_1854 : H12AffineEnvironment.transform 3 0 env1853 = env1854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env1853 == env1854) = true)

theorem identity1854 : scanCanonicalize (H12AffineFastState.compose env1854 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound1854 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1855 : List Nat := [2,4,8,0,32,32,8,5,11,5,32,33,9,0,0,2,1,0,5,0,1,32,33,3,9,1,33,0,33,1,5,1,5,1,0,10]

theorem envBound1855 : H12AffineFastState.Bounded env1855 := by
  intro p hp
  have h : env1855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1854_1855 : H12AffineEnvironment.transform 5 32 env1854 = env1855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env1854 == env1855) = true)

theorem identity1855 : scanCanonicalize (H12AffineFastState.compose env1855 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound1855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1856 : List Nat := [2,4,8,0,2,2,8,5,11,5,2,3,9,0,0,2,1,0,5,0,1,2,3,3,9,1,3,0,3,1,5,1,5,1,0,10]

theorem envBound1856 : H12AffineFastState.Bounded env1856 := by
  intro p hp
  have h : env1856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1855_1856 : H12AffineEnvironment.transform 4 2 env1855 = env1856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env1855 == env1856) = true)

theorem identity1856 : scanCanonicalize (H12AffineFastState.compose env1856 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound1856 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1857 : List Nat := [1,4,8,0,1,1,8,5,8,5,1,0,9,0,0,1,1,0,5,0,1,1,0,0,9,1,0,0,0,1,5,1,5,1,0,9]

theorem envBound1857 : H12AffineFastState.Bounded env1857 := by
  intro p hp
  have h : env1857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1856_1857 : H12AffineEnvironment.transform 0 1 env1856 = env1857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env1856 == env1857) = true)

theorem identity1857 : scanCanonicalize (H12AffineFastState.compose env1857 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound1857 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1858 : List Nat := [1,0,8,0,1,1,8,1,8,1,1,0,9,0,0,1,1,0,1,0,1,1,0,0,9,1,0,0,0,1,1,1,1,1,0,9]

theorem envBound1858 : H12AffineFastState.Bounded env1858 := by
  intro p hp
  have h : env1858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1857_1858 : H12AffineEnvironment.transform 1 0 env1857 = env1858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env1857 == env1858) = true)

def env1859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2081,16852468,4341977,257,1,34359738368,16925298]

theorem envBound1859 : H12AffineFastState.Bounded env1859 := by
  intro p hp
  have h : env1859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1824_1859 : H12AffineEnvironment.transform 18 1025 env1824 = env1859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1824 == env1859) = true)

def env1860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2081,16852468,4341977,257,1,131072,16925298]

theorem envBound1860 : H12AffineFastState.Bounded env1860 := by
  intro p hp
  have h : env1860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1859_1860 : H12AffineEnvironment.transform 34 131072 env1859 = env1860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1859 == env1860) = true)

theorem identity1860 : scanCanonicalize (H12AffineFastState.compose env1860 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 91522) := by decide +kernel

theorem selectedBound1860 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,91522,262144,1025,8692,2097152,4194304,75202,16777216,8328,75155,337243,16384,79235,2081,16852468,4269403,257,1,91522,16852976]

theorem envBound1861 : H12AffineFastState.Bounded env1861 := by
  intro p hp
  have h : env1861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1860_1861 : H12AffineEnvironment.transform 16 91522 env1860 = env1861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91522 env1860 == env1861) = true)

theorem identity1861 : scanCanonicalize (H12AffineFastState.compose env1861 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 4268501) := by decide +kernel

theorem selectedBound1861 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,91522,262144,1025,8692,2097152,4194304,75202,4268501,8328,75155,337243,16384,79235,2081,4195361,4269403,257,1,91522,4195877]

theorem envBound1862 : H12AffineFastState.Bounded env1862 := by
  intro p hp
  have h : env1862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1861_1862 : H12AffineEnvironment.transform 23 4268501 env1861 = env1862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4268501 env1861 == env1862) = true)

theorem identity1862 : scanCanonicalize (H12AffineFastState.compose env1862 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 1061) := by decide +kernel

theorem selectedBound1862 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,91522,262144,1025,8692,2097152,1061,75202,75248,8328,75155,337243,16384,79235,2081,4,74110,257,1,91522,512]

theorem envBound1863 : H12AffineFastState.Bounded env1863 := by
  intro p hp
  have h : env1863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1862_1863 : H12AffineEnvironment.transform 21 1061 env1862 = env1863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1061 env1862 == env1863) = true)

theorem identity1863 : scanCanonicalize (H12AffineFastState.compose env1863 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1863 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1864 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,65536,90502,262144,5,8692,2097152,33,74182,74228,8328,74135,336223,16384,78215,2081,4,74110,257,1,90502,512]

theorem envBound1864 : H12AffineFastState.Bounded env1864 := by
  intro p hp
  have h : env1864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1863_1864 : H12AffineEnvironment.transform 9 4 env1863 = env1864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1863 == env1864) = true)

theorem identity1864 : scanCanonicalize (H12AffineFastState.compose env1864 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1864 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1865 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16632,262144,5,8692,2097152,33,184,138,8328,233,262177,16384,4345,2081,4,0,257,1,16632,512]

theorem envBound1865 : H12AffineFastState.Bounded env1865 := by
  intro p hp
  have h : env1865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1864_1865 : H12AffineEnvironment.transform 15 8574 env1864 = env1865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1864 == env1865) = true)

theorem identity1865 : scanCanonicalize (H12AffineFastState.compose env1865 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound1865 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1866 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16632,2081,5,8692,2097152,33,184,138,8328,233,2048,16384,4345,2081,4,0,257,1,16632,512]

theorem envBound1866 : H12AffineFastState.Bounded env1866 := by
  intro p hp
  have h : env1866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1865_1866 : H12AffineEnvironment.transform 17 2081 env1865 = env1866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env1865 == env1866) = true)

theorem identity1866 : scanCanonicalize (H12AffineFastState.compose env1866 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound1866 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1867 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16632,2081,5,8200,2097152,33,184,138,8328,233,2048,16384,4345,2081,4,0,253,1,16632,512]

theorem envBound1867 : H12AffineFastState.Bounded env1867 := by
  intro p hp
  have h : env1867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1866_1867 : H12AffineEnvironment.transform 7 252 env1866 = env1867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1866 == env1867) = true)

theorem identity1867 : scanCanonicalize (H12AffineFastState.compose env1867 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26827) := by decide +kernel

theorem selectedBound1867 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env1868 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16632,2081,5,8200,26827,33,184,138,8328,233,2048,16384,4345,2081,4,0,253,1,16632,512]

theorem envBound1868 : H12AffineFastState.Bounded env1868 := by
  intro p hp
  have h : env1868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1867_1868 : H12AffineEnvironment.transform 20 26827 env1867 = env1868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26827 env1867 == env1868) = true)

theorem identity1868 : scanCanonicalize (H12AffineFastState.compose env1868 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12497) := by decide +kernel

theorem selectedBound1868 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1869 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12497,8200,8322,12329,2081,5,8200,6170,33,184,138,8328,233,2048,12497,4345,2081,4,0,253,1,12329,512]

theorem envBound1869 : H12AffineFastState.Bounded env1869 := by
  intro p hp
  have h : env1869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1868_1869 : H12AffineEnvironment.transform 13 12497 env1868 = env1869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12497 env1868 == env1869) = true)

theorem identity1869 : scanCanonicalize (H12AffineFastState.compose env1869 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound1869 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env1870 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2283,6202,2275,2153,6338,2081,5,2275,6170,33,184,138,2147,233,2048,6202,4345,2081,4,0,253,1,6338,512]

theorem envBound1870 : H12AffineFastState.Bounded env1870 := by
  intro p hp
  have h : env1870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1869_1870 : H12AffineEnvironment.transform 12 2283 env1869 = env1870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env1869 == env1870) = true)

theorem identity1870 : scanCanonicalize (H12AffineFastState.compose env1870 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2129) := by decide +kernel

theorem selectedBound1870 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env1871 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2129,2283,107,2275,2153,147,2081,5,2275,75,33,184,138,2147,233,2048,107,2216,2081,4,0,253,1,147,512]

theorem envBound1871 : H12AffineFastState.Bounded env1871 := by
  intro p hp
  have h : env1871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1870_1871 : H12AffineEnvironment.transform 11 2129 env1870 = env1871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2129 env1870 == env1871) = true)

theorem identity1871 : scanCanonicalize (H12AffineFastState.compose env1871 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound1871 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1872 : List Nat := [2,4,8,16,32,64,128,252,512,4,59,106,208,107,216,82,147,26,5,216,75,33,184,138,88,233,59,107,147,26,4,0,253,1,147,512]

theorem envBound1872 : H12AffineFastState.Bounded env1872 := by
  intro p hp
  have h : env1872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1871_1872 : H12AffineEnvironment.transform 10 59 env1871 = env1872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env1871 == env1872) = true)

theorem identity1872 : scanCanonicalize (H12AffineFastState.compose env1872 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound1872 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env1873 : List Nat := [2,4,8,16,32,42,128,150,512,4,59,0,186,1,178,56,147,26,5,178,33,33,184,138,50,131,59,1,147,26,4,0,151,1,147,512]

theorem envBound1873 : H12AffineFastState.Bounded env1873 := by
  intro p hp
  have h : env1873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1872_1873 : H12AffineEnvironment.transform 5 42 env1872 = env1873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env1872 == env1873) = true)

def env1874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2081,16852468,4341977,257,1,131073,16925298]

theorem envBound1874 : H12AffineFastState.Bounded env1874 := by
  intro p hp
  have h : env1874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1859_1874 : H12AffineEnvironment.transform 34 131073 env1859 = env1874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1859 == env1874) = true)

theorem identity1874 : scanCanonicalize (H12AffineFastState.compose env1874 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 226690) := by decide +kernel

theorem selectedBound1874 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,226690,4194304,147520,16777216,8328,147473,409817,16384,151553,2081,16852468,4341977,257,1,131073,16925298]

theorem envBound1875 : H12AffineFastState.Bounded env1875 := by
  intro p hp
  have h : env1875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1874_1875 : H12AffineEnvironment.transform 20 226690 env1874 = env1875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 226690 env1874 == env1875) = true)

theorem identity1875 : scanCanonicalize (H12AffineFastState.compose env1875 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 139) := by decide +kernel

theorem selectedBound1875 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,226690,4194304,147520,139,8328,147473,409817,16384,151553,2081,75135,4341977,257,1,131073,148217]

theorem envBound1876 : H12AffineFastState.Bounded env1876 := by
  intro p hp
  have h : env1876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1875_1876 : H12AffineEnvironment.transform 23 139 env1875 = env1876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 139 env1875 == env1876) = true)

def env1877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,226690,32,147520,139,8328,147473,409817,16384,151553,2081,75135,147705,257,1,131073,148217]

theorem envBound1877 : H12AffineFastState.Bounded env1877 := by
  intro p hp
  have h : env1877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1876_1877 : H12AffineEnvironment.transform 21 32 env1876 = env1877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env1876 == env1877) = true)

theorem identity1877 : scanCanonicalize (H12AffineFastState.compose env1877 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90503) := by decide +kernel

theorem selectedBound1877 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,90503,262144,1025,8692,5125,32,74183,139,8328,74134,336222,16384,78214,2081,75135,74110,257,1,90502,74622]

theorem envBound1878 : H12AffineFastState.Bounded env1878 := by
  intro p hp
  have h : env1878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1877_1878 : H12AffineEnvironment.transform 16 90503 env1877 = env1878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90503 env1877 == env1878) = true)

theorem identity1878 : scanCanonicalize (H12AffineFastState.compose env1878 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound1878 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env1879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8662,16465,262144,1025,8692,5125,32,17,139,8328,64,262280,16384,4176,2081,1193,168,257,1,16464,680]

theorem envBound1879 : H12AffineFastState.Bounded env1879 := by
  intro p hp
  have h : env1879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1878_1879 : H12AffineEnvironment.transform 15 8662 env1878 = env1879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env1878 == env1879) = true)

theorem identity1879 : scanCanonicalize (H12AffineFastState.compose env1879 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12724) := by decide +kernel

theorem selectedBound1879 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env1880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12724,8692,8662,12773,262144,1025,8692,5125,32,17,139,8328,64,262280,12724,4176,2081,1193,168,257,1,12772,680]

theorem envBound1880 : H12AffineFastState.Bounded env1880 := by
  intro p hp
  have h : env1880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1879_1880 : H12AffineEnvironment.transform 13 12724 env1879 = env1880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12724 env1879 == env1880) = true)

theorem identity1880 : scanCanonicalize (H12AffineFastState.compose env1880 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1880 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1881 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,12572,8540,8574,12621,262144,1025,8540,5125,32,17,35,8224,64,262176,12572,4176,2081,1025,0,257,1,12620,512]

theorem envBound1881 : H12AffineFastState.Bounded env1881 := by
  intro p hp
  have h : env1881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1880_1881 : H12AffineEnvironment.transform 6 40 env1880 = env1881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1880 == env1881) = true)

theorem identity1881 : scanCanonicalize (H12AffineFastState.compose env1881 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound1881 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1882 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,12572,8460,8494,12573,262144,1025,8460,5125,32,17,35,8224,16,262176,12572,4096,2081,1025,0,257,1,12572,512]

theorem envBound1882 : H12AffineFastState.Bounded env1882 := by
  intro p hp
  have h : env1882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1881_1882 : H12AffineEnvironment.transform 5 16 env1881 = env1882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env1881 == env1882) = true)

theorem identity1882 : scanCanonicalize (H12AffineFastState.compose env1882 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8983) := by decide +kernel

theorem selectedBound1882 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env1883 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,12572,8460,8494,12573,8983,1025,8460,5125,32,17,35,8224,16,9015,12572,4096,2081,1025,0,257,1,12572,512]

theorem envBound1883 : H12AffineFastState.Bounded env1883 := by
  intro p hp
  have h : env1883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1882_1883 : H12AffineEnvironment.transform 17 8983 env1882 = env1883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8983 env1882 == env1883) = true)

theorem identity1883 : scanCanonicalize (H12AffineFastState.compose env1883 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2870) := by decide +kernel

theorem selectedBound1883 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env1884 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,2870,6698,2618,2584,6699,2081,1025,2618,5125,32,17,35,2838,16,2049,6698,4096,2081,1025,0,257,1,6698,512]

theorem envBound1884 : H12AffineFastState.Bounded env1884 := by
  intro p hp
  have h : env1884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1883_1884 : H12AffineEnvironment.transform 12 2870 env1883 = env1884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2870 env1883 == env1884) = true)

theorem identity1884 : scanCanonicalize (H12AffineFastState.compose env1884 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound1884 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env1885 : List Nat := [2,4,8,16,32,16,40,256,512,1024,789,4096,35,4415,303,269,4414,820,1025,303,5125,32,17,35,3,16,788,4415,4096,820,1025,0,257,1,4415,512]

theorem envBound1885 : H12AffineFastState.Bounded env1885 := by
  intro p hp
  have h : env1885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1884_1885 : H12AffineEnvironment.transform 10 789 env1884 = env1885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env1884 == env1885) = true)

theorem identity1885 : scanCanonicalize (H12AffineFastState.compose env1885 (packedSelected [1,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound1885 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env1886 : List Nat := [2,4,8,16,32,16,40,256,309,1024,32,4096,35,4415,303,269,4414,1,1025,303,5125,32,17,35,3,16,33,4415,4096,1,1025,0,257,1,4415,309]

theorem envBound1886 : H12AffineFastState.Bounded env1886 := by
  intro p hp
  have h : env1886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1885_1886 : H12AffineEnvironment.transform 8 309 env1885 = env1886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env1885 == env1886) = true)

theorem identity1886 : scanCanonicalize (H12AffineFastState.compose env1886 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound1886 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env1887 : List Nat := [2,4,8,16,32,16,40,256,309,1024,32,1028,35,1339,303,269,1338,1,1025,303,1,32,17,35,3,16,33,1339,1028,1,1025,0,257,1,1339,309]

theorem envBound1887 : H12AffineFastState.Bounded env1887 := by
  intro p hp
  have h : env1887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1886_1887 : H12AffineEnvironment.transform 11 1028 env1886 = env1887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env1886 == env1887) = true)

theorem identity1887 : scanCanonicalize (H12AffineFastState.compose env1887 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound1887 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env1888 : List Nat := [2,4,8,16,1,16,9,256,276,1024,1,1028,2,1306,270,269,1307,1,1025,270,1,1,17,2,3,16,0,1306,1028,1,1025,0,257,1,1306,276]

theorem envBound1888 : H12AffineFastState.Bounded env1888 := by
  intro p hp
  have h : env1888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1887_1888 : H12AffineEnvironment.transform 4 1 env1887 = env1888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env1887 == env1888) = true)

theorem identity1888 : scanCanonicalize (H12AffineFastState.compose env1888 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1888 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1889 : List Nat := [2,4,8,16,1,16,9,4,16,1024,1,1028,2,1054,10,9,1055,1,1025,10,1,1,17,2,3,16,0,1054,1028,1,1025,0,5,1,1054,16]

theorem envBound1889 : H12AffineFastState.Bounded env1889 := by
  intro p hp
  have h : env1889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1888_1889 : H12AffineEnvironment.transform 7 4 env1888 = env1889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1888 == env1889) = true)

theorem identity1889 : scanCanonicalize (H12AffineFastState.compose env1889 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound1889 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1890 : List Nat := [2,4,3,16,1,16,2,4,16,1024,1,1028,2,1045,1,2,1044,1,1025,1,1,1,17,2,3,16,0,1045,1028,1,1025,0,5,1,1045,16]

theorem envBound1890 : H12AffineFastState.Bounded env1890 := by
  intro p hp
  have h : env1890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1889_1890 : H12AffineEnvironment.transform 2 3 env1889 = env1890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env1889 == env1890) = true)

theorem identity1890 : scanCanonicalize (H12AffineFastState.compose env1890 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1890 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1891 : List Nat := [2,4,3,1,1,1,2,4,1,1024,1,1028,2,1028,1,2,1029,1,1025,1,1,1,0,2,3,1,0,1028,1028,1,1025,0,5,1,1028,1]

theorem envBound1891 : H12AffineFastState.Bounded env1891 := by
  intro p hp
  have h : env1891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1890_1891 : H12AffineEnvironment.transform 3 1 env1890 = env1891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1890 == env1891) = true)

theorem identity1891 : scanCanonicalize (H12AffineFastState.compose env1891 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound1891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1892 : List Nat := [2,4,3,1,1,1,2,4,1,2,1,6,2,6,1,2,7,1,3,1,1,1,0,2,3,1,0,6,6,1,3,0,5,1,6,1]

theorem envBound1892 : H12AffineFastState.Bounded env1892 := by
  intro p hp
  have h : env1892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1891_1892 : H12AffineEnvironment.transform 9 2 env1891 = env1892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env1891 == env1892) = true)

def env1893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,226690,33,147520,139,8328,147473,409817,16384,151553,2081,75135,147704,257,1,131073,148217]

theorem envBound1893 : H12AffineFastState.Bounded env1893 := by
  intro p hp
  have h : env1893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1876_1893 : H12AffineEnvironment.transform 21 33 env1876 = env1893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env1876 == env1893) = true)

theorem identity1893 : scanCanonicalize (H12AffineFastState.compose env1893 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1893 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1025,8692,152828,33,147520,139,8328,147473,409817,16384,151553,2081,1025,147704,257,1,131073,148217]

theorem envBound1894 : H12AffineFastState.Bounded env1894 := by
  intro p hp
  have h : env1894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1893_1894 : H12AffineEnvironment.transform 15 8574 env1893 = env1894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1893 == env1894) = true)

theorem identity1894 : scanCanonicalize (H12AffineFastState.compose env1894 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1894 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1025,8692,5125,33,185,139,8328,232,262176,16384,4344,2081,1025,1,257,1,16632,512]

theorem envBound1895 : H12AffineFastState.Bounded env1895 := by
  intro p hp
  have h : env1895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1894_1895 : H12AffineEnvironment.transform 16 16633 env1894 = env1895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1894 == env1895) = true)

def env1896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147521,16777216,8328,672785,935129,16384,151553,2081,17375733,4867289,525568,1,34359738368,17450610]

theorem envBound1896 : H12AffineFastState.Bounded env1896 := by
  intro p hp
  have h : env1896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1823_1896 : H12AffineEnvironment.transform 22 147521 env1823 = env1896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env1823 == env1896) = true)

def env1897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2081,16852469,4341977,256,1,34359738368,16925298]

theorem envBound1897 : H12AffineFastState.Bounded env1897 := by
  intro p hp
  have h : env1897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1896_1897 : H12AffineEnvironment.transform 18 1024 env1896 = env1897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1896 == env1897) = true)

def env1898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2081,16852469,4341977,256,1,131072,16925298]

theorem envBound1898 : H12AffineFastState.Bounded env1898 := by
  intro p hp
  have h : env1898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1897_1898 : H12AffineEnvironment.transform 34 131072 env1897 = env1898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1897 == env1898) = true)

theorem identity1898 : scanCanonicalize (H12AffineFastState.compose env1898 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 12435) := by decide +kernel

theorem selectedBound1898 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,12435,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2081,16782694,4341977,256,1,131072,16925298]

theorem envBound1899 : H12AffineFastState.Bounded env1899 := by
  intro p hp
  have h : env1899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1898_1899 : H12AffineEnvironment.transform 15 12435 env1898 = env1899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12435 env1898 == env1899) = true)

theorem identity1899 : scanCanonicalize (H12AffineFastState.compose env1899 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 292) := by decide +kernel

theorem selectedBound1899 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,12435,131072,262144,1024,8692,2097152,292,147521,16777216,8328,147473,409817,16384,151553,2081,16782694,147965,256,1,131072,16925298]

theorem envBound1900 : H12AffineFastState.Bounded env1900 := by
  intro p hp
  have h : env1900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1899_1900 : H12AffineEnvironment.transform 21 292 env1899 = env1900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292 env1899 == env1900) = true)

def env1901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,12435,16892,262144,1024,8692,2097152,292,445,16777216,8328,493,262437,16384,4605,2081,16782694,1,256,1,16892,16778126]

theorem envBound1901 : H12AffineFastState.Bounded env1901 := by
  intro p hp
  have h : env1901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1900_1901 : H12AffineEnvironment.transform 16 16892 env1900 = env1901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1900 == env1901) = true)

theorem identity1901 : scanCanonicalize (H12AffineFastState.compose env1901 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 4194) := by decide +kernel

theorem selectedBound1901 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,12435,16892,262144,1024,8692,2097152,292,445,4194,8328,493,262437,16384,4605,2081,1284,1,256,1,16892,5100]

theorem envBound1902 : H12AffineFastState.Bounded env1902 := by
  intro p hp
  have h : env1902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1901_1902 : H12AffineEnvironment.transform 23 4194 env1901 = env1902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4194 env1901 == env1902) = true)

theorem identity1902 : scanCanonicalize (H12AffineFastState.compose env1902 (packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1902 : packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env1903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,12435,16892,2525,1024,8692,2097152,292,445,4194,8328,493,2296,16384,4605,2081,1284,1,256,1,16892,5100]

theorem envBound1903 : H12AffineFastState.Bounded env1903 := by
  intro p hp
  have h : env1903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1902_1903 : H12AffineEnvironment.transform 17 2525 env1902 = env1903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1902 == env1903) = true)

theorem identity1903 : scanCanonicalize (H12AffineFastState.compose env1903 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1903 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env1904 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8432,12435,16632,2265,1024,8432,2097152,32,185,4194,8328,233,2296,16384,4345,2081,1024,1,4,1,16632,4840]

theorem envBound1904 : H12AffineFastState.Bounded env1904 := by
  intro p hp
  have h : env1904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1903_1904 : H12AffineEnvironment.transform 7 4 env1903 = env1904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1903 == env1904) = true)

theorem identity1904 : scanCanonicalize (H12AffineFastState.compose env1904 (packedSelected [2,6,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound1904 : packedSelected [2,6,11,15,17] rootPS < 2^1333 := by decide +kernel

def env1905 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8432,8314,16632,2265,1024,8432,2097152,32,185,139,8328,233,2296,16384,16,2081,1024,1,4,1,16632,513]

theorem envBound1905 : H12AffineFastState.Bounded env1905 := by
  intro p hp
  have h : env1905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1904_1905 : H12AffineEnvironment.transform 11 233 env1904 = env1905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env1904 == env1905) = true)

theorem identity1905 : scanCanonicalize (H12AffineFastState.compose env1905 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(20+1) ^^^ 3766) := by decide +kernel

theorem selectedBound1905 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1906 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8432,8314,16632,2265,1024,8432,3766,32,185,139,8328,233,2296,16384,16,2081,1024,1,4,1,16632,513]

theorem envBound1906 : H12AffineFastState.Bounded env1906 := by
  intro p hp
  have h : env1906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1905_1906 : H12AffineEnvironment.transform 20 3766 env1905 = env1906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3766 env1905 == env1906) = true)

theorem identity1906 : scanCanonicalize (H12AffineFastState.compose env1906 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 2296) := by decide +kernel

theorem selectedBound1906 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1907 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,2296,8432,8314,2048,2265,1024,8432,3766,32,185,139,8328,233,2296,2296,16,2081,1024,1,4,1,2048,513]

theorem envBound1907 : H12AffineFastState.Bounded env1907 := by
  intro p hp
  have h : env1907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1906_1907 : H12AffineEnvironment.transform 13 2296 env1906 = env1907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2296 env1906 == env1907) = true)

theorem identity1907 : scanCanonicalize (H12AffineFastState.compose env1907 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1670) := by decide +kernel

theorem selectedBound1907 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1908 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1670,233,8192,1662,8432,8314,1670,1631,1024,8432,48,32,185,139,8328,233,1662,1662,16,1703,1024,1,4,1,1670,513]

theorem envBound1908 : H12AffineFastState.Bounded env1908 := by
  intro p hp
  have h : env1908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1907_1908 : H12AffineEnvironment.transform 10 1670 env1907 = env1908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1670 env1907 == env1908) = true)

theorem identity1908 : scanCanonicalize (H12AffineFastState.compose env1908 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1237) := by decide +kernel

theorem selectedBound1908 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1909 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1670,233,1237,1662,1061,1199,1670,1631,1024,1061,48,32,185,139,1117,233,1662,1662,16,1703,1024,1,4,1,1670,513]

theorem envBound1909 : H12AffineFastState.Bounded env1909 := by
  intro p hp
  have h : env1909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1908_1909 : H12AffineEnvironment.transform 12 1237 env1908 = env1909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1237 env1908 == env1909) = true)

theorem identity1909 : scanCanonicalize (H12AffineFastState.compose env1909 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound1909 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1910 : List Nat := [2,4,8,16,32,64,128,4,512,679,33,233,626,217,642,520,33,248,679,642,48,32,185,139,762,233,217,217,16,0,679,1,4,1,33,513]

theorem envBound1910 : H12AffineFastState.Bounded env1910 := by
  intro p hp
  have h : env1910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1909_1910 : H12AffineEnvironment.transform 9 679 env1909 = env1910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env1909 == env1910) = true)

theorem identity1910 : scanCanonicalize (H12AffineFastState.compose env1910 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound1910 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1911 : List Nat := [2,4,8,16,32,48,128,4,512,679,33,153,514,169,642,520,33,136,679,642,48,32,185,139,650,153,169,169,16,0,679,1,4,1,33,513]

theorem envBound1911 : H12AffineFastState.Bounded env1911 := by
  intro p hp
  have h : env1911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1910_1911 : H12AffineEnvironment.transform 5 48 env1910 = env1911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env1910 == env1911) = true)

theorem identity1911 : scanCanonicalize (H12AffineFastState.compose env1911 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound1911 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1912 : List Nat := [2,4,8,16,32,48,128,4,43,140,33,153,41,169,169,35,33,136,140,169,48,32,185,139,161,153,169,169,16,0,140,1,4,1,33,42]

theorem envBound1912 : H12AffineFastState.Bounded env1912 := by
  intro p hp
  have h : env1912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1911_1912 : H12AffineEnvironment.transform 8 43 env1911 = env1912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env1911 == env1912) = true)

theorem identity1912 : scanCanonicalize (H12AffineFastState.compose env1912 (packedSelected [1,6] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound1912 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env1913 : List Nat := [2,4,8,16,32,48,11,4,43,7,33,18,41,34,34,35,33,3,7,34,48,32,50,0,42,18,34,34,16,0,7,1,4,1,33,42]

theorem envBound1913 : H12AffineFastState.Bounded env1913 := by
  intro p hp
  have h : env1913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1912_1913 : H12AffineEnvironment.transform 6 11 env1912 = env1913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env1912 == env1913) = true)

theorem identity1913 : scanCanonicalize (H12AffineFastState.compose env1913 (packedSelected [1,11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound1913 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env1914 : List Nat := [1,4,8,16,32,48,8,4,40,4,33,17,41,33,33,32,33,0,4,33,48,32,49,0,41,17,33,33,16,0,4,1,4,1,33,41]

theorem envBound1914 : H12AffineFastState.Bounded env1914 := by
  intro p hp
  have h : env1914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1913_1914 : H12AffineEnvironment.transform 0 1 env1913 = env1914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env1913 == env1914) = true)

theorem identity1914 : scanCanonicalize (H12AffineFastState.compose env1914 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound1914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1915 : List Nat := [1,4,8,16,0,16,8,4,8,4,1,17,9,1,1,0,1,0,4,1,16,0,17,0,9,17,1,1,16,0,4,1,4,1,1,9]

theorem envBound1915 : H12AffineFastState.Bounded env1915 := by
  intro p hp
  have h : env1915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1914_1915 : H12AffineEnvironment.transform 4 0 env1914 = env1915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env1914 == env1915) = true)

theorem identity1915 : scanCanonicalize (H12AffineFastState.compose env1915 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1916 : List Nat := [1,4,8,12,0,12,8,4,8,4,1,13,9,1,1,0,1,0,4,1,12,0,13,0,9,13,1,1,12,0,4,1,4,1,1,9]

theorem envBound1916 : H12AffineFastState.Bounded env1916 := by
  intro p hp
  have h : env1916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1915_1916 : H12AffineEnvironment.transform 3 12 env1915 = env1916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1915 == env1916) = true)

theorem identity1916 : scanCanonicalize (H12AffineFastState.compose env1916 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1916 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env1917 : List Nat := [1,4,4,0,0,0,4,4,4,4,1,1,5,1,1,0,1,0,4,1,0,0,1,0,5,1,1,1,0,0,4,1,4,1,1,5]

theorem envBound1917 : H12AffineFastState.Bounded env1917 := by
  intro p hp
  have h : env1917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1916_1917 : H12AffineEnvironment.transform 2 4 env1916 = env1917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1916 == env1917) = true)

def env1918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,12435,16893,262144,1024,8692,2097152,292,444,16777216,8328,492,262436,16384,4604,2081,16782694,0,256,1,16893,16778127]

theorem envBound1918 : H12AffineFastState.Bounded env1918 := by
  intro p hp
  have h : env1918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1900_1918 : H12AffineEnvironment.transform 16 16893 env1900 = env1918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1900 == env1918) = true)

theorem identity1918 : scanCanonicalize (H12AffineFastState.compose env1918 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound1918 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,8692,8575,16893,262144,1024,8692,2097152,292,444,16777216,8328,492,262436,16384,16,2081,16778378,0,256,1,16893,16778127]

theorem envBound1919 : H12AffineFastState.Bounded env1919 := by
  intro p hp
  have h : env1919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1918_1919 : H12AffineEnvironment.transform 11 492 env1918 = env1919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env1918 == env1919) = true)

def env1920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147521,16777216,8328,147473,409817,16384,151553,2081,16852469,4341977,256,1,131073,16925298]

theorem envBound1920 : H12AffineFastState.Bounded env1920 := by
  intro p hp
  have h : env1920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1897_1920 : H12AffineEnvironment.transform 34 131073 env1897 = env1920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1897 == env1920) = true)

theorem identity1920 : scanCanonicalize (H12AffineFastState.compose env1920 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 73875) := by decide +kernel

theorem selectedBound1920 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,73875,4194304,147521,16777216,8328,147473,409817,16384,151553,2081,16852469,4341977,256,1,131073,16925298]

theorem envBound1921 : H12AffineFastState.Bounded env1921 := by
  intro p hp
  have h : env1921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1920_1921 : H12AffineEnvironment.transform 20 73875 env1920 = env1921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 73875 env1920 == env1921) = true)

theorem identity1921 : scanCanonicalize (H12AffineFastState.compose env1921 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1921 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,232,4194304,147521,16777216,8328,147473,409817,16384,151553,2081,16778638,4341977,256,1,131073,16925298]

theorem envBound1922 : H12AffineFastState.Bounded env1922 := by
  intro p hp
  have h : env1922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1921_1922 : H12AffineEnvironment.transform 15 8315 env1921 = env1922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1921 == env1922) = true)

def env1923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,232,147672,147521,16777216,8328,147473,409817,16384,151553,2081,16778638,1,256,1,131073,16925298]

theorem envBound1923 : H12AffineFastState.Bounded env1923 := by
  intro p hp
  have h : env1923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1922_1923 : H12AffineEnvironment.transform 21 147672 env1922 = env1923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1922 == env1923) = true)

theorem identity1923 : scanCanonicalize (H12AffineFastState.compose env1923 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147830) := by decide +kernel

theorem selectedBound1923 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,232,147672,147521,147830,8328,147473,409817,16384,151553,2081,148728,1,256,1,131073,772]

theorem envBound1924 : H12AffineFastState.Bounded env1924 := by
  intro p hp
  have h : env1924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1923_1924 : H12AffineEnvironment.transform 23 147830 env1923 = env1924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147830 env1923 == env1924) = true)

theorem identity1924 : scanCanonicalize (H12AffineFastState.compose env1924 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound1924 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,16632,262144,1024,8692,232,32,185,398,8328,233,262177,16384,4345,2081,1024,1,256,1,16633,772]

theorem envBound1925 : H12AffineFastState.Bounded env1925 := by
  intro p hp
  have h : env1925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1924_1925 : H12AffineEnvironment.transform 16 16632 env1924 = env1925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1924 == env1925) = true)

theorem identity1925 : scanCanonicalize (H12AffineFastState.compose env1925 (packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound1925 : packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env1926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,16632,2265,1024,8692,232,32,185,398,8328,233,2296,16384,4345,2081,1024,1,256,1,16633,772]

theorem envBound1926 : H12AffineFastState.Bounded env1926 := by
  intro p hp
  have h : env1926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1925_1926 : H12AffineEnvironment.transform 17 2265 env1925 = env1926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env1925 == env1926) = true)

theorem identity1926 : scanCanonicalize (H12AffineFastState.compose env1926 (packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound1926 : packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env1927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1084,16384,1480,1095,16632,2265,1024,1480,232,32,185,398,1204,233,2296,16384,4345,2081,1024,1,256,1,16633,772]

theorem envBound1927 : H12AffineFastState.Bounded env1927 := by
  intro p hp
  have h : env1927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1926_1927 : H12AffineEnvironment.transform 12 1084 env1926 = env1927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env1926 == env1927) = true)

theorem identity1927 : scanCanonicalize (H12AffineFastState.compose env1927 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound1927 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1928 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1084,16384,1125,1095,16632,2265,1024,1125,232,32,185,35,1204,233,2296,16384,4345,2081,1024,1,173,1,16633,681]

theorem envBound1928 : H12AffineFastState.Bounded env1928 := by
  intro p hp
  have h : env1928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1927_1928 : H12AffineEnvironment.transform 7 173 env1927 = env1928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env1927 == env1928) = true)

theorem identity1928 : scanCanonicalize (H12AffineFastState.compose env1928 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2096) := by decide +kernel

theorem selectedBound1928 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env1929 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1084,2096,1125,1095,2248,2265,1024,1125,232,32,185,35,1204,233,2296,2096,4345,2081,1024,1,173,1,2249,681]

theorem envBound1929 : H12AffineFastState.Bounded env1929 := by
  intro p hp
  have h : env1929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1928_1929 : H12AffineEnvironment.transform 13 2096 env1928 = env1929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2096 env1928 == env1929) = true)

theorem identity1929 : scanCanonicalize (H12AffineFastState.compose env1929 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound1929 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env1930 : List Nat := [2,4,8,16,32,64,128,173,512,221,2048,4096,225,2096,184,154,2248,2265,221,184,232,32,185,35,105,233,2296,2096,4345,2081,221,1,173,1,2249,681]

theorem envBound1930 : H12AffineFastState.Bounded env1930 := by
  intro p hp
  have h : env1930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1929_1930 : H12AffineEnvironment.transform 9 221 env1929 = env1930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env1929 == env1930) = true)

theorem identity1930 : scanCanonicalize (H12AffineFastState.compose env1930 (packedSelected [0,1,3,5,7,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 2129) := by decide +kernel

theorem selectedBound1930 : packedSelected [0,1,3,5,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env1931 : List Nat := [2,4,8,16,32,64,128,173,512,221,2048,2129,225,2096,184,154,2248,2265,221,184,232,32,185,35,105,233,2296,2096,2216,2081,221,1,173,1,2249,681]

theorem envBound1931 : H12AffineFastState.Bounded env1931 := by
  intro p hp
  have h : env1931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1930_1931 : H12AffineEnvironment.transform 11 2129 env1930 = env1931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2129 env1930 == env1931) = true)

theorem identity1931 : scanCanonicalize (H12AffineFastState.compose env1931 (packedSelected [0,1,2,4,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound1931 : packedSelected [0,1,2,4,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env1932 : List Nat := [2,4,8,16,32,64,128,173,512,221,65,16,225,113,184,154,137,152,221,184,232,32,185,35,105,233,185,113,233,96,221,1,173,1,136,681]

theorem envBound1932 : H12AffineFastState.Bounded env1932 := by
  intro p hp
  have h : env1932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1931_1932 : H12AffineEnvironment.transform 10 65 env1931 = env1932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env1931 == env1932) = true)

theorem identity1932 : scanCanonicalize (H12AffineFastState.compose env1932 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound1932 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env1933 : List Nat := [2,4,8,16,32,17,128,173,512,140,16,16,176,32,184,154,137,152,140,184,185,32,185,35,56,184,185,32,184,49,140,1,173,1,136,681]

theorem envBound1933 : H12AffineFastState.Bounded env1933 := by
  intro p hp
  have h : env1933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1932_1933 : H12AffineEnvironment.transform 5 17 env1932 = env1933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env1932 == env1933) = true)

theorem identity1933 : scanCanonicalize (H12AffineFastState.compose env1933 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound1933 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env1934 : List Nat := [2,4,8,16,29,17,128,144,512,140,16,16,141,29,133,154,137,152,140,133,132,29,132,30,5,133,132,29,133,12,140,1,144,1,136,660]

theorem envBound1934 : H12AffineFastState.Bounded env1934 := by
  intro p hp
  have h : env1934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1933_1934 : H12AffineEnvironment.transform 4 29 env1933 = env1934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env1933 == env1934) = true)

theorem identity1934 : scanCanonicalize (H12AffineFastState.compose env1934 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound1934 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env1935 : List Nat := [2,4,8,16,29,17,21,5,512,25,16,16,24,29,16,15,28,13,25,16,17,29,17,30,5,16,17,29,16,12,25,1,5,1,29,513]

theorem envBound1935 : H12AffineFastState.Bounded env1935 := by
  intro p hp
  have h : env1935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1934_1935 : H12AffineEnvironment.transform 6 21 env1934 = env1935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env1934 == env1935) = true)

theorem identity1935 : scanCanonicalize (H12AffineFastState.compose env1935 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1936 : List Nat := [2,4,8,16,29,17,21,5,6,25,16,16,24,29,16,15,28,13,25,16,17,29,17,30,5,16,17,29,16,12,25,1,5,1,29,7]

theorem envBound1936 : H12AffineFastState.Bounded env1936 := by
  intro p hp
  have h : env1936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1935_1936 : H12AffineEnvironment.transform 8 6 env1935 = env1936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1935 == env1936) = true)

theorem identity1936 : scanCanonicalize (H12AffineFastState.compose env1936 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1937 : List Nat := [2,4,8,13,0,12,8,5,6,4,13,13,5,0,13,15,1,13,4,13,12,0,12,3,5,13,12,0,13,12,4,1,5,1,0,7]

theorem envBound1937 : H12AffineFastState.Bounded env1937 := by
  intro p hp
  have h : env1937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1936_1937 : H12AffineEnvironment.transform 3 13 env1936 = env1937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1936 == env1937) = true)

theorem identity1937 : scanCanonicalize (H12AffineFastState.compose env1937 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound1937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1938 : List Nat := [2,1,8,8,0,9,8,0,3,1,8,8,0,0,8,10,1,8,1,8,9,0,9,3,0,8,9,0,8,9,1,1,0,1,0,2]

theorem envBound1938 : H12AffineFastState.Bounded env1938 := by
  intro p hp
  have h : env1938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1937_1938 : H12AffineEnvironment.transform 1 1 env1937 = env1938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env1937 == env1938) = true)

theorem identity1938 : scanCanonicalize (H12AffineFastState.compose env1938 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound1938 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env1939 : List Nat := [2,1,0,0,0,1,0,0,3,1,0,0,0,0,0,2,1,0,1,0,1,0,1,3,0,0,1,0,0,1,1,1,0,1,0,2]

theorem envBound1939 : H12AffineFastState.Bounded env1939 := by
  intro p hp
  have h : env1939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1938_1939 : H12AffineEnvironment.transform 2 0 env1938 = env1939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env1938 == env1939) = true)

def env1940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1024,8692,232,147673,147521,16777216,8328,147473,409817,16384,151553,2081,16778638,0,256,1,131073,16925298]

theorem envBound1940 : H12AffineFastState.Bounded env1940 := by
  intro p hp
  have h : env1940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1922_1940 : H12AffineEnvironment.transform 21 147673 env1922 = env1940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1922 == env1940) = true)

theorem identity1940 : scanCanonicalize (H12AffineFastState.compose env1940 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1940 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1941 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8432,8315,131072,262144,1024,8432,232,147673,147521,16777216,8328,147473,409817,16384,151553,2081,16778378,0,4,1,131073,16925298]

theorem envBound1941 : H12AffineFastState.Bounded env1941 := by
  intro p hp
  have h : env1941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1940_1941 : H12AffineEnvironment.transform 7 4 env1940 = env1941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1940 == env1941) = true)

def env1942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16384,151553,2081,16852468,4341976,257,1,34359738368,16925299]

theorem envBound1942 : H12AffineFastState.Bounded env1942 := by
  intro p hp
  have h : env1942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1896_1942 : H12AffineEnvironment.transform 18 1025 env1896 = env1942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1896 == env1942) = true)

def env1943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16384,151553,2081,16852468,4341976,257,1,131072,16925299]

theorem envBound1943 : H12AffineFastState.Bounded env1943 := by
  intro p hp
  have h : env1943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1942_1943 : H12AffineEnvironment.transform 34 131072 env1942 = env1943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1942 == env1943) = true)

theorem identity1943 : scanCanonicalize (H12AffineFastState.compose env1943 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 79314) := by decide +kernel

theorem selectedBound1943 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,79314,262144,1025,8692,2097152,4194304,95635,16777216,8328,95682,357642,16384,91603,2081,16852468,4289802,257,1,79314,16873377]

theorem envBound1944 : H12AffineFastState.Bounded env1944 := by
  intro p hp
  have h : env1944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1943_1944 : H12AffineEnvironment.transform 16 79314 env1943 = env1944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79314 env1943 == env1944) = true)

theorem identity1944 : scanCanonicalize (H12AffineFastState.compose env1944 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 4268500) := by decide +kernel

theorem selectedBound1944 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,79314,262144,1025,8692,2097152,4194304,95635,4268500,8328,95682,357642,16384,91603,2081,4195360,4289802,257,1,79314,4216437]

theorem envBound1945 : H12AffineFastState.Bounded env1945 := by
  intro p hp
  have h : env1945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1944_1945 : H12AffineEnvironment.transform 23 4268500 env1944 = env1945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4268500 env1944 == env1945) = true)

theorem identity1945 : scanCanonicalize (H12AffineFastState.compose env1945 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1945 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,5292,262144,1025,8692,2097152,4194304,21741,4194474,8328,21692,283764,16384,17581,2081,4195360,4215924,257,1,5292,4216437]

theorem envBound1946 : H12AffineFastState.Bounded env1946 := by
  intro p hp
  have h : env1946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1945_1946 : H12AffineEnvironment.transform 15 8574 env1945 = env1946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1945 == env1946) = true)

def env1947 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,8574,5124,262144,1025,8540,2097152,4194304,21573,4194306,8224,21524,283764,16384,17413,2081,4195360,4215924,257,1,5124,4216437]

theorem envBound1947 : H12AffineFastState.Bounded env1947 := by
  intro p hp
  have h : env1947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1946_1947 : H12AffineEnvironment.transform 6 40 env1946 = env1947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1946 == env1947) = true)

theorem identity1947 : scanCanonicalize (H12AffineFastState.compose env1947 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21620) := by decide +kernel

theorem selectedBound1947 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1948 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,8574,5124,262144,1025,8540,2097152,21620,21573,21622,8224,21524,283764,16384,17413,2081,20564,0,257,1,5124,513]

theorem envBound1948 : H12AffineFastState.Bounded env1948 := by
  intro p hp
  have h : env1948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1947_1948 : H12AffineEnvironment.transform 21 21620 env1947 = env1948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21620 env1947 == env1948) = true)

theorem identity1948 : scanCanonicalize (H12AffineFastState.compose env1948 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 17413) := by decide +kernel

theorem selectedBound1948 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1949 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,8574,5124,262144,1025,8540,17413,21620,21573,21622,8224,21524,283764,16384,17413,2081,20564,0,257,1,5124,513]

theorem envBound1949 : H12AffineFastState.Bounded env1949 := by
  intro p hp
  have h : env1949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1948_1949 : H12AffineEnvironment.transform 20 17413 env1948 = env1949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17413 env1948 == env1949) = true)

theorem identity1949 : scanCanonicalize (H12AffineFastState.compose env1949 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 5440) := by decide +kernel

theorem selectedBound1949 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1950 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5440,8540,8574,5124,262144,1025,8540,4421,308,261,310,8224,340,262452,5440,4421,2081,1300,0,257,1,5124,513]

theorem envBound1950 : H12AffineFastState.Bounded env1950 := by
  intro p hp
  have h : env1950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1949_1950 : H12AffineEnvironment.transform 13 5440 env1949 = env1950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5440 env1949 == env1950) = true)

theorem identity1950 : scanCanonicalize (H12AffineFastState.compose env1950 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound1950 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env1951 : List Nat := [2,4,8,16,32,1,40,256,512,1024,2048,4096,8192,5377,8477,8511,5124,262144,1025,8477,4356,308,261,310,8224,277,262452,5377,4356,2081,1300,0,257,1,5124,513]

theorem envBound1951 : H12AffineFastState.Bounded env1951 := by
  intro p hp
  have h : env1951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1950_1951 : H12AffineEnvironment.transform 5 1 env1950 = env1951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1950 == env1951) = true)

theorem identity1951 : scanCanonicalize (H12AffineFastState.compose env1951 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 284) := by decide +kernel

theorem selectedBound1951 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1952 : List Nat := [2,4,8,16,32,1,40,256,512,1024,2048,4096,284,5377,1,35,5124,262144,1025,1,4356,308,261,310,316,277,262452,5377,4356,2081,1300,0,257,1,5124,513]

theorem envBound1952 : H12AffineFastState.Bounded env1952 := by
  intro p hp
  have h : env1952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1951_1952 : H12AffineEnvironment.transform 12 284 env1951 = env1952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 284 env1951 == env1952) = true)

theorem identity1952 : scanCanonicalize (H12AffineFastState.compose env1952 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound1952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1953 : List Nat := [2,4,8,16,32,1,40,20,512,1024,2048,4096,8,5141,1,35,5124,262144,1025,1,4112,32,17,34,40,1,262176,5141,4112,2081,1024,0,21,1,5124,513]

theorem envBound1953 : H12AffineFastState.Bounded env1953 := by
  intro p hp
  have h : env1953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1952_1953 : H12AffineEnvironment.transform 7 20 env1952 = env1953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env1952 == env1953) = true)

def env1954 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,8574,5125,262144,1025,8541,2097152,4194304,21572,4194307,8225,21525,283764,16384,17412,2081,4195360,4215924,257,1,5125,4216437]

theorem envBound1954 : H12AffineFastState.Bounded env1954 := by
  intro p hp
  have h : env1954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1