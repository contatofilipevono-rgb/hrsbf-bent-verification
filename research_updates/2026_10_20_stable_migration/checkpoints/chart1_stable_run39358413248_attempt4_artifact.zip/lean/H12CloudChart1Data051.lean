import H12CloudChart1Data050

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans12747_12782 : H12AffineEnvironment.transform 21 272513 env12747 = env12782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12747 == env12782) = true)

theorem identity12782 : scanCanonicalize (H12AffineFastState.compose env12782 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound12782 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,120014,98780,8328,64,245139,115150,17664,464078,119042,329730,256,21792,46212,63188]

theorem envBound12783 : H12AffineFastState.Bounded env12783 := by
  intro p hp
  have h : env12783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12782_12783 : H12AffineEnvironment.transform 20 115870 env12782 = env12783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env12782 == env12783) = true)

def env12784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,119878,98644,8192,64,245019,115014,17664,463942,119042,329730,256,21792,46092,63068]

theorem envBound12784 : H12AffineFastState.Bounded env12784 := by
  intro p hp
  have h : env12784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12783_12784 : H12AffineEnvironment.transform 6 8 env12783 = env12784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12783 == env12784) = true)

theorem identity12784 : scanCanonicalize (H12AffineFastState.compose env12784 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound12784 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,115734,147505,119878,98644,8192,64,245019,115014,17664,97406,119042,221242,256,21792,46092,63068]

theorem envBound12785 : H12AffineFastState.Bounded env12785 := by
  intro p hp
  have h : env12785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12784_12785 : H12AffineEnvironment.transform 17 157752 env12784 = env12785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env12784 == env12785) = true)

theorem identity12785 : scanCanonicalize (H12AffineFastState.compose env12785 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12785 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,146744,1024,32769,102678,136497,98630,98644,8192,64,245019,103494,4096,76158,99330,210234,256,32,46092,41820]

theorem envBound12786 : H12AffineFastState.Bounded env12786 := by
  intro p hp
  have h : env12786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12785_12786 : H12AffineEnvironment.transform 13 5376 env12785 = env12786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12785 == env12786) = true)

theorem identity12786 : scanCanonicalize (H12AffineFastState.compose env12786 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound12786 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79131,67619,1024,32769,102678,73770,98630,98644,8192,64,34816,103494,4096,76158,99330,33,256,32,46092,41820]

theorem envBound12787 : H12AffineFastState.Bounded env12787 := by
  intro p hp
  have h : env12787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12786_12787 : H12AffineEnvironment.transform 16 79131 env12786 = env12787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env12786 == env12787) = true)

theorem identity12787 : scanCanonicalize (H12AffineFastState.compose env12787 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12787 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,79131,67619,1024,8540,77899,73770,73755,73737,8192,64,10589,79131,4096,76158,75103,33,256,32,5457,513]

theorem envBound12788 : H12AffineFastState.Bounded env12788 := by
  intro p hp
  have h : env12788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12787_12788 : H12AffineEnvironment.transform 14 8541 env12787 = env12788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12787 == env12788) = true)

theorem identity12788 : scanCanonicalize (H12AffineFastState.compose env12788 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound12788 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,1094,12637,3173,1024,8540,13325,9324,9309,9295,8192,64,10589,12637,4096,11576,8473,33,256,32,5457,513]

theorem envBound12789 : H12AffineFastState.Bounded env12789 := by
  intro p hp
  have h : env12789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12788_12789 : H12AffineEnvironment.transform 15 1094 env12788 = env12789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env12788 == env12789) = true)

theorem identity12789 : scanCanonicalize (H12AffineFastState.compose env12789 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound12789 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1296,1094,5392,3173,1024,1297,4160,33,16,2,1101,64,3344,5392,4096,2421,1364,33,256,32,5457,513]

theorem envBound12790 : H12AffineFastState.Bounded env12790 := by
  intro p hp
  have h : env12790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12789_12790 : H12AffineEnvironment.transform 12 1101 env12789 = env12790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env12789 == env12790) = true)

theorem identity12790 : scanCanonicalize (H12AffineFastState.compose env12790 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 629) := by decide +kernel

theorem selectedBound12790 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12791 : List Nat := [2,4,8,16,32,64,8,256,512,629,2048,4096,568,4981,869,563,4965,2576,629,868,4160,33,16,2,568,64,2917,4965,4096,2421,801,33,256,32,4900,513]

theorem envBound12791 : H12AffineFastState.Bounded env12791 := by
  intro p hp
  have h : env12791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12790_12791 : H12AffineEnvironment.transform 9 629 env12790 = env12791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 629 env12790 == env12791) = true)

theorem identity12791 : scanCanonicalize (H12AffineFastState.compose env12791 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 357) := by decide +kernel

theorem selectedBound12791 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12792 : List Nat := [2,4,8,16,32,64,8,256,357,272,2048,4096,349,4112,0,342,4096,2421,272,1,4160,33,16,2,349,64,2048,4096,4096,2421,68,33,256,32,4161,356]

theorem envBound12792 : H12AffineFastState.Bounded env12792 := by
  intro p hp
  have h : env12792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12791_12792 : H12AffineEnvironment.transform 8 357 env12791 = env12792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 357 env12791 == env12792) = true)

theorem identity12792 : scanCanonicalize (H12AffineFastState.compose env12792 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound12792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12793 : List Nat := [2,4,8,16,32,64,8,101,0,117,2048,4096,56,4112,0,51,4096,2064,117,1,4160,33,16,2,56,64,2048,4096,4096,2064,68,33,101,32,4161,1]

theorem envBound12793 : H12AffineFastState.Bounded env12793 := by
  intro p hp
  have h : env12793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12792_12793 : H12AffineEnvironment.transform 7 101 env12792 = env12793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env12792 == env12793) = true)

theorem identity12793 : scanCanonicalize (H12AffineFastState.compose env12793 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12793 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12794 : List Nat := [2,4,8,0,32,64,8,101,0,101,2048,4096,40,4096,0,35,4096,2048,101,1,4160,33,0,2,40,64,2048,4096,4096,2048,68,33,101,32,4161,1]

theorem envBound12794 : H12AffineFastState.Bounded env12794 := by
  intro p hp
  have h : env12794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12793_12794 : H12AffineEnvironment.transform 3 0 env12793 = env12794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12793 == env12794) = true)

theorem identity12794 : scanCanonicalize (H12AffineFastState.compose env12794 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound12794 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12795 : List Nat := [2,4,8,0,32,64,8,101,0,101,97,4096,40,4096,0,35,4096,97,101,1,4160,33,0,2,40,64,97,4096,4096,97,68,33,101,32,4161,1]

theorem envBound12795 : H12AffineFastState.Bounded env12795 := by
  intro p hp
  have h : env12795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12794_12795 : H12AffineEnvironment.transform 10 97 env12794 = env12795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env12794 == env12795) = true)

theorem identity12795 : scanCanonicalize (H12AffineFastState.compose env12795 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound12795 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12796 : List Nat := [2,4,8,0,32,64,8,101,0,101,97,0,40,0,0,35,0,97,101,1,64,33,0,2,40,64,97,0,0,97,68,33,101,32,65,1]

theorem envBound12796 : H12AffineFastState.Bounded env12796 := by
  intro p hp
  have h : env12796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12795_12796 : H12AffineEnvironment.transform 11 0 env12795 = env12796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env12795 == env12796) = true)

theorem identity12796 : scanCanonicalize (H12AffineFastState.compose env12796 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound12796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12797 : List Nat := [2,4,8,0,32,0,8,37,0,37,33,0,40,0,0,35,0,33,37,1,0,33,0,2,40,0,33,0,0,33,4,33,37,32,1,1]

theorem envBound12797 : H12AffineFastState.Bounded env12797 := by
  intro p hp
  have h : env12797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12796_12797 : H12AffineEnvironment.transform 5 0 env12796 = env12797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env12796 == env12797) = true)

theorem identity12797 : scanCanonicalize (H12AffineFastState.compose env12797 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12797 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env12798 : List Nat := [2,4,8,0,1,0,8,4,0,4,0,0,9,0,0,2,0,0,4,1,0,0,0,2,9,0,0,0,0,0,4,0,4,1,1,1]

theorem envBound12798 : H12AffineFastState.Bounded env12798 := by
  intro p hp
  have h : env12798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12797_12798 : H12AffineEnvironment.transform 4 1 env12797 = env12798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12797 == env12798) = true)

def env12799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,119879,98645,8193,64,245018,115015,17664,463943,119042,329730,256,21792,46093,63069]

theorem envBound12799 : H12AffineFastState.Bounded env12799 := by
  intro p hp
  have h : env12799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12783_12799 : H12AffineEnvironment.transform 6 9 env12783 = env12799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12783 == env12799) = true)

theorem identity12799 : scanCanonicalize (H12AffineFastState.compose env12799 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound12799 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1024,32769,115735,62588,119879,98645,8193,64,245018,115015,17664,247859,119042,119926,256,21792,46093,63069]

theorem envBound12800 : H12AffineFastState.Bounded env12800 := by
  intro p hp
  have h : env12800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12799_12800 : H12AffineEnvironment.transform 17 56436 env12799 = env12800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env12799 == env12800) = true)

def env12801 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,77899,32,73755,95497,8193,64,215366,79131,17664,212079,75102,73770,256,21792,16465,513]

theorem envBound12801 : H12AffineFastState.Bounded env12801 := by
  intro p hp
  have h : env12801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12800_12801 : H12AffineEnvironment.transform 14 29788 env12800 = env12801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env12800 == env12801) = true)

theorem identity12801 : scanCanonicalize (H12AffineFastState.compose env12801 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12801 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env12802 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,131072,10280,1024,29708,77850,32,73755,95497,8193,17,215319,79131,17664,212030,75023,73770,256,21792,16384,513]

theorem envBound12802 : H12AffineFastState.Bounded env12802 := by
  intro p hp
  have h : env12802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12801_12802 : H12AffineEnvironment.transform 5 17 env12801 = env12802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12801 == env12802) = true)

theorem identity12802 : scanCanonicalize (H12AffineFastState.compose env12802 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound12802 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env12803 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,5393,10280,1024,29708,77850,32,73755,95497,8193,17,89094,79131,17664,76079,75023,73770,256,21792,16384,513]

theorem envBound12803 : H12AffineFastState.Bounded env12803 := by
  intro p hp
  have h : env12803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12802_12803 : H12AffineEnvironment.transform 16 5393 env12802 = env12803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env12802 == env12803) = true)

theorem identity12803 : scanCanonicalize (H12AffineFastState.compose env12803 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12803 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env12804 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,65536,5393,2341,1024,21761,69911,32,65814,87044,268,17,89094,70678,17664,67618,66562,65831,256,21792,16384,513]

theorem envBound12804 : H12AffineFastState.Bounded env12804 := by
  intro p hp
  have h : env12804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12803_12804 : H12AffineEnvironment.transform 12 269 env12803 = env12804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12803 == env12804) = true)

def env12805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,77898,33,73754,95496,8193,64,215367,79130,17664,212078,75103,73771,256,21792,16464,512]

theorem envBound12805 : H12AffineFastState.Bounded env12805 := by
  intro p hp
  have h : env12805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12800_12805 : H12AffineEnvironment.transform 14 29789 env12800 = env12805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env12800 == env12805) = true)

theorem identity12805 : scanCanonicalize (H12AffineFastState.compose env12805 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 90399) := by decide +kernel

theorem selectedBound12805 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env12806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90399,10281,1024,29788,77898,33,73754,95496,8193,64,10328,79130,17664,23921,75103,73771,256,21792,16464,512]

theorem envBound12806 : H12AffineFastState.Bounded env12806 := by
  intro p hp
  have h : env12806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12805_12806 : H12AffineEnvironment.transform 16 90399 env12805 = env12806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90399 env12805 == env12806) = true)

theorem identity12806 : scanCanonicalize (H12AffineFastState.compose env12806 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12806 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16660,10281,1024,29788,4161,33,17,21763,8193,64,10328,5393,17664,23921,1364,32,256,21792,16464,512]

theorem envBound12807 : H12AffineFastState.Bounded env12807 := by
  intro p hp
  have h : env12807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12806_12807 : H12AffineEnvironment.transform 15 8203 env12806 = env12807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12806 == env12807) = true)

theorem identity12807 : scanCanonicalize (H12AffineFastState.compose env12807 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound12807 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env12808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2129,15372,8203,2373,10281,1024,15373,4161,33,17,7506,8193,64,10328,5393,3409,5408,1364,32,256,7537,2049,512]

theorem envBound12808 : H12AffineFastState.Bounded env12808 := by
  intro p hp
  have h : env12808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12807_12808 : H12AffineEnvironment.transform 13 2129 env12807 = env12808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env12807 == env12808) = true)

theorem identity12808 : scanCanonicalize (H12AffineFastState.compose env12808 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound12808 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,2129,6500,1379,2373,3393,1024,6501,4161,33,17,7506,1385,64,3376,5393,3409,5408,1364,32,256,7537,2049,512]

theorem envBound12809 : H12AffineFastState.Bounded env12809 := by
  intro p hp
  have h : env12809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12808_12809 : H12AffineEnvironment.transform 12 1384 env12808 = env12809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env12808 == env12809) = true)

theorem identity12809 : scanCanonicalize (H12AffineFastState.compose env12809 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12809 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env12810 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1052,2129,6160,1047,2097,3125,1024,6161,4161,33,17,7206,1053,64,3140,5221,3109,5204,1056,32,116,7173,2049,512]

theorem envBound12810 : H12AffineFastState.Bounded env12810 := by
  intro p hp
  have h : env12810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12809_12810 : H12AffineEnvironment.transform 7 116 env12809 = env12810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12809 == env12810) = true)

theorem identity12810 : scanCanonicalize (H12AffineFastState.compose env12810 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound12810 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env12811 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2064,1052,2129,0,1047,2097,3125,1024,1,2129,33,17,1078,1053,64,3140,3189,3109,3140,1056,32,116,1045,2049,512]

theorem envBound12811 : H12AffineFastState.Bounded env12811 := by
  intro p hp
  have h : env12811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12810_12811 : H12AffineEnvironment.transform 11 2064 env12810 = env12811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env12810 == env12811) = true)

theorem identity12811 : scanCanonicalize (H12AffineFastState.compose env12811 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound12811 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12812 : List Nat := [2,4,8,16,32,48,9,4,512,1024,2048,2064,1052,2081,0,1047,2097,3125,1024,1,2081,33,17,1078,1053,48,3124,3077,3109,3124,1056,32,4,1045,2049,512]

theorem envBound12812 : H12AffineFastState.Bounded env12812 := by
  intro p hp
  have h : env12812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12811_12812 : H12AffineEnvironment.transform 5 48 env12811 = env12812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12811 == env12812) = true)

theorem identity12812 : scanCanonicalize (H12AffineFastState.compose env12812 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12812 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env12813 : List Nat := [2,4,3,16,32,48,2,4,512,1024,2048,2064,1047,2081,0,1047,2097,3125,1024,1,2081,33,17,1078,1046,48,3124,3077,3109,3124,1056,32,4,1045,2049,512]

theorem envBound12813 : H12AffineFastState.Bounded env12813 := by
  intro p hp
  have h : env12813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12812_12813 : H12AffineEnvironment.transform 2 3 env12812 = env12813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12812 == env12813) = true)

theorem identity12813 : scanCanonicalize (H12AffineFastState.compose env12813 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12813 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env12814 : List Nat := [2,4,3,0,32,32,2,4,512,1024,2048,2048,1031,2081,0,1031,2081,3109,1024,1,2081,33,1,1062,1030,32,3108,3077,3109,3108,1056,32,4,1029,2049,512]

theorem envBound12814 : H12AffineFastState.Bounded env12814 := by
  intro p hp
  have h : env12814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12813_12814 : H12AffineEnvironment.transform 3 0 env12813 = env12814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12813 == env12814) = true)

theorem identity12814 : scanCanonicalize (H12AffineFastState.compose env12814 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound12814 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env12815 : List Nat := [2,4,3,0,4,4,2,4,512,1024,2048,2048,1031,2053,0,1031,2053,3073,1024,1,2053,5,1,1026,1030,4,3072,3077,3073,3072,1028,4,4,1029,2049,512]

theorem envBound12815 : H12AffineFastState.Bounded env12815 := by
  intro p hp
  have h : env12815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12814_12815 : H12AffineEnvironment.transform 4 4 env12814 = env12815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env12814 == env12815) = true)

theorem identity12815 : scanCanonicalize (H12AffineFastState.compose env12815 (packedSelected [0,1,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound12815 : packedSelected [0,1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env12816 : List Nat := [2,4,3,0,4,4,2,4,512,0,2048,2048,7,2053,0,7,2053,2049,0,1,2053,5,1,2,6,4,2048,2053,2049,2048,4,4,4,5,2049,512]

theorem envBound12816 : H12AffineFastState.Bounded env12816 := by
  intro p hp
  have h : env12816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12815_12816 : H12AffineEnvironment.transform 9 0 env12815 = env12816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env12815 == env12816) = true)

def env12817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98781,8328,64,6705548,2098513,17665,2543697,2102684,6349852,256,21792,46212,2175562]

theorem envBound12817 : H12AffineFastState.Bounded env12817 := by
  intro p hp
  have h : env12817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12746_12817 : H12AffineEnvironment.transform 22 2101329 env12746 = env12817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env12746 == env12817) = true)

def env12818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98781,8328,64,2259212,2098513,17665,2543697,2102684,2411676,256,21792,46212,2175562]

theorem envBound12818 : H12AffineFastState.Bounded env12818 := by
  intro p hp
  have h : env12818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12817_12818 : H12AffineEnvironment.transform 21 272512 env12817 = env12818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12817 == env12818) = true)

theorem identity12818 : scanCanonicalize (H12AffineFastState.compose env12818 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12818 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272512,2101329,41431,8328,64,2259212,2098513,17665,2543697,2102684,2411676,256,21792,46212,2101824]

theorem envBound12819 : H12AffineFastState.Bounded env12819 := by
  intro p hp
  have h : env12819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12818_12819 : H12AffineEnvironment.transform 15 8202 env12818 = env12819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12818 == env12819) = true)

def env12820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272392,2101329,41311,8192,64,2259212,2098513,17665,2543697,2102548,2411540,256,21792,46092,2101824]

theorem envBound12820 : H12AffineFastState.Bounded env12820 := by
  intro p hp
  have h : env12820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12819_12820 : H12AffineEnvironment.transform 6 8 env12819 = env12820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12819 == env12820) = true)

theorem identity12820 : scanCanonicalize (H12AffineFastState.compose env12820 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound12820 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,5441,262144,1024,32769,2097152,272392,2101329,41311,8192,64,2124877,2098513,17665,2409744,2102548,2411540,256,21792,46092,2101824]

theorem envBound12821 : H12AffineFastState.Bounded env12821 := by
  intro p hp
  have h : env12821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12820_12821 : H12AffineEnvironment.transform 16 5441 env12820 = env12821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env12820 == env12821) = true)

theorem identity12821 : scanCanonicalize (H12AffineFastState.compose env12821 (packedSelected [0,1,9,10,22,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound12821 : packedSelected [0,1,9,10,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env12822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8202,5441,262144,1024,29708,2097152,272392,2101329,21842,8192,64,2124877,2098513,17665,2371869,2102548,2373657,256,21792,16385,2101824]

theorem envBound12822 : H12AffineFastState.Bounded env12822 := by
  intro p hp
  have h : env12822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12821_12822 : H12AffineEnvironment.transform 14 29709 env12821 = env12822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env12821 == env12822) = true)

theorem identity12822 : scanCanonicalize (H12AffineFastState.compose env12822 (packedSelected [1,5,8,11,17,18,19,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12822 : packedSelected [1,5,8,11,17,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env12823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,8202,5441,262144,1024,8540,2097152,272392,2101329,2,8192,64,2111773,2098513,4177,2371869,2102548,2373657,256,112,5457,2101824]

theorem envBound12823 : H12AffineFastState.Bounded env12823 := by
  intro p hp
  have h : env12823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12822_12823 : H12AffineEnvironment.transform 13 5456 env12822 = env12823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12822 == env12823) = true)

theorem identity12823 : scanCanonicalize (H12AffineFastState.compose env12823 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 268353) := by decide +kernel

theorem selectedBound12823 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env12824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,8202,5441,262144,1024,8540,268353,272392,264208,2,8192,64,270684,269584,4177,10588,265557,8280,256,112,5457,264705]

theorem envBound12824 : H12AffineFastState.Bounded env12824 := by
  intro p hp
  have h : env12824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12823_12824 : H12AffineEnvironment.transform 20 268353 env12823 = env12824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268353 env12823 == env12824) = true)

theorem identity12824 : scanCanonicalize (H12AffineFastState.compose env12824 (packedSelected [2,3,4,5,9,10,12,14,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound12824 : packedSelected [2,3,4,5,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env12825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,8202,5441,2129,1024,8540,4112,8281,65,2,8192,64,10509,5441,4177,10588,1284,8280,256,112,5457,592]

theorem envBound12825 : H12AffineFastState.Bounded env12825 := by
  intro p hp
  have h : env12825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12824_12825 : H12AffineEnvironment.transform 17 2129 env12824 = env12825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env12824 == env12825) = true)

theorem identity12825 : scanCanonicalize (H12AffineFastState.compose env12825 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12825 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5456,373,34,5441,2129,1024,372,4112,113,65,2,40,64,2341,5441,4177,2420,1284,112,256,112,5457,592]

theorem envBound12826 : H12AffineFastState.Bounded env12826 := by
  intro p hp
  have h : env12826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12825_12826 : H12AffineEnvironment.transform 12 40 env12825 = env12826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12825 == env12826) = true)

theorem identity12826 : scanCanonicalize (H12AffineFastState.compose env12826 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12826 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env12827 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,40,4452,373,34,4469,2129,52,372,4112,113,65,2,40,64,2341,4469,4177,2420,304,112,256,112,4453,592]

theorem envBound12827 : H12AffineFastState.Bounded env12827 := by
  intro p hp
  have h : env12827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12826_12827 : H12AffineEnvironment.transform 9 52 env12826 = env12827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12826 == env12827) = true)

def env12828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,2097152,272393,2101329,41310,8193,64,2259212,2098513,17665,2543697,2102549,2411541,256,21792,46093,2101824]

theorem envBound12828 : H12AffineFastState.Bounded env12828 := by
  intro p hp
  have h : env12828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12819_12828 : H12AffineEnvironment.transform 6 9 env12819 = env12828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12819 == env12828) = true)

theorem identity12828 : scanCanonicalize (H12AffineFastState.compose env12828 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound12828 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,2097152,272393,2101329,41310,8193,64,2149648,2098513,17665,2384973,2102549,2411541,256,21792,46093,2101824]

theorem envBound12829 : H12AffineFastState.Bounded env12829 := by
  intro p hp
  have h : env12829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12828_12829 : H12AffineEnvironment.transform 16 46108 env12828 = env12829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env12828 == env12829) = true)

theorem identity12829 : scanCanonicalize (H12AffineFastState.compose env12829 (packedSelected [0,1,9,10,22,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound12829 : packedSelected [0,1,9,10,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env12830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4161,272393,16,41310,8193,64,56657,5392,17665,291852,1364,318548,256,21792,46093,513]

theorem envBound12830 : H12AffineFastState.Bounded env12830 := by
  intro p hp
  have h : env12830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12829_12830 : H12AffineEnvironment.transform 20 4161 env12829 = env12830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12829 == env12830) = true)

theorem identity12830 : scanCanonicalize (H12AffineFastState.compose env12830 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound12830 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env12831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16448,262144,1024,29789,4161,272393,16,21762,8193,64,10509,5392,17665,291852,1364,272392,256,21792,16465,513]

theorem envBound12831 : H12AffineFastState.Bounded env12831 := by
  intro p hp
  have h : env12831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12830_12831 : H12AffineEnvironment.transform 14 29788 env12830 = env12831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env12830 == env12831) = true)

theorem identity12831 : scanCanonicalize (H12AffineFastState.compose env12831 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound12831 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16448,2421,1024,29789,4161,8572,16,21762,8193,64,10509,5392,17665,32121,1364,8573,256,21792,16465,513]

theorem envBound12832 : H12AffineFastState.Bounded env12832 := by
  intro p hp
  have h : env12832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12831_12832 : H12AffineEnvironment.transform 17 2421 env12831 = env12832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env12831 == env12832) = true)

theorem identity12832 : scanCanonicalize (H12AffineFastState.compose env12832 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12832 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,262,16448,2421,1024,21841,4161,112,16,21762,269,64,2049,5392,17665,23669,1364,113,256,21792,16465,513]

theorem envBound12833 : H12AffineFastState.Bounded env12833 := by
  intro p hp
  have h : env12833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12832_12833 : H12AffineEnvironment.transform 12 268 env12832 = env12833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12832 == env12833) = true)

theorem identity12833 : scanCanonicalize (H12AffineFastState.compose env12833 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12833 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12834 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,262,16401,2340,1024,21760,4112,33,16,21762,269,17,2049,5392,17665,23588,1285,32,256,21792,16384,513]

theorem envBound12834 : H12AffineFastState.Bounded env12834 := by
  intro p hp
  have h : env12834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12833_12834 : H12AffineEnvironment.transform 5 17 env12833 = env12834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12833 == env12834) = true)

def env12835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98781,8328,64,2259213,2098513,17665,2543697,2102684,2411677,256,21792,46212,2175562]

theorem envBound12835 : H12AffineFastState.Bounded env12835 := by
  intro p hp
  have h : env12835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12817_12835 : H12AffineEnvironment.transform 21 272513 env12817 = env12835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12817 == env12835) = true)

theorem identity12835 : scanCanonicalize (H12AffineFastState.compose env12835 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound12835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272513,73754,98781,8328,64,215366,79130,17665,516122,75223,392406,256,21792,46212,513]

theorem envBound12836 : H12AffineFastState.Bounded env12836 := by
  intro p hp
  have h : env12836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12835_12836 : H12AffineEnvironment.transform 20 77899 env12835 = env12836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env12835 == env12836) = true)

def env12837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272393,73754,98645,8192,64,215366,79130,17665,516122,75103,392286,256,21792,46092,513]

theorem envBound12837 : H12AffineFastState.Bounded env12837 := by
  intro p hp
  have h : env12837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12836_12837 : H12AffineEnvironment.transform 6 8 env12836 = env12837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12836 == env12837) = true)

theorem identity12837 : scanCanonicalize (H12AffineFastState.compose env12837 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound12837 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,77899,272393,73754,98645,8192,64,10589,79130,17665,294913,75103,392286,256,21792,46092,513]

theorem envBound12838 : H12AffineFastState.Bounded env12838 := by
  intro p hp
  have h : env12838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12837_12838 : H12AffineEnvironment.transform 16 90139 env12837 = env12838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env12837 == env12838) = true)

theorem identity12838 : scanCanonicalize (H12AffineFastState.compose env12838 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12838 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env12839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4160,272393,17,41310,8192,64,10589,5393,17665,294913,1364,318549,256,21792,46092,513]

theorem envBound12839 : H12AffineFastState.Bounded env12839 := by
  intro p hp
  have h : env12839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12838_12839 : H12AffineEnvironment.transform 15 8203 env12838 = env12839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12838 == env12839) = true)

theorem identity12839 : scanCanonicalize (H12AffineFastState.compose env12839 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound12839 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1024,32769,4160,41341,17,41310,8192,64,10589,5393,17665,2421,1364,21793,256,21792,46092,513]

theorem envBound12840 : H12AffineFastState.Bounded env12840 := by
  intro p hp
  have h : env12840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12839_12840 : H12AffineEnvironment.transform 17 35188 env12839 = env12840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env12839 == env12840) = true)

theorem identity12840 : scanCanonicalize (H12AffineFastState.compose env12840 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound12840 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,8203,16400,3125,1024,1344,4160,9276,17,9247,8192,64,10589,5393,17665,2421,1364,21793,256,21792,12621,513]

theorem envBound12841 : H12AffineFastState.Bounded env12841 := by
  intro p hp
  have h : env12841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12840_12841 : H12AffineEnvironment.transform 14 1345 env12840 = env12841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env12840 == env12841) = true)

theorem identity12841 : scanCanonicalize (H12AffineFastState.compose env12841 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound12841 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,1345,8203,5221,3125,1024,1344,4160,9276,17,9247,8192,64,10589,5393,4468,2421,1364,340,256,341,12621,513]

theorem envBound12842 : H12AffineFastState.Bounded env12842 := by
  intro p hp
  have h : env12842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12841_12842 : H12AffineEnvironment.transform 13 5237 env12841 = env12842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env12841 == env12842) = true)

theorem identity12842 : scanCanonicalize (H12AffineFastState.compose env12842 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound12842 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12843 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4113,293,8203,4097,2129,100,292,4160,8280,17,8315,8192,64,10589,4469,4468,2421,304,340,256,341,12621,513]

theorem envBound12843 : H12AffineFastState.Bounded env12843 := by
  intro p hp
  have h : env12843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12842_12843 : H12AffineEnvironment.transform 9 100 env12842 = env12843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env12842 == env12843) = true)

theorem identity12843 : scanCanonicalize (H12AffineFastState.compose env12843 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound12843 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12844 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,64,8192,81,293,8203,65,2129,100,292,0,8280,17,8315,8192,64,10589,309,308,2421,304,340,256,341,8461,513]

theorem envBound12844 : H12AffineFastState.Bounded env12844 := by
  intro p hp
  have h : env12844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12843_12844 : H12AffineEnvironment.transform 11 64 env12843 = env12844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env12843 == env12844) = true)

theorem identity12844 : scanCanonicalize (H12AffineFastState.compose env12844 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12844 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12845 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,17,8192,0,293,8203,16,2048,53,292,0,8201,17,8234,8192,17,10508,309,308,2340,304,261,256,260,8461,513]

theorem envBound12845 : H12AffineFastState.Bounded env12845 := by
  intro p hp
  have h : env12845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12844_12845 : H12AffineEnvironment.transform 5 17 env12844 = env12845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12844 == env12845) = true)

theorem identity12845 : scanCanonicalize (H12AffineFastState.compose env12845 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound12845 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12846 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,17,41,0,293,34,16,2048,53,292,0,32,17,3,41,17,2341,309,308,2340,304,261,256,260,292,513]

theorem envBound12846 : H12AffineFastState.Bounded env12846 := by
  intro p hp
  have h : env12846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12845_12846 : H12AffineEnvironment.transform 12 41 env12845 = env12846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env12845 == env12846) = true)

theorem identity12846 : scanCanonicalize (H12AffineFastState.compose env12846 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12846 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env12847 : List Nat := [2,4,8,16,32,17,8,256,512,53,1,17,41,0,293,34,16,1,53,292,0,32,17,3,41,17,292,309,308,293,304,261,256,260,292,513]

theorem envBound12847 : H12AffineFastState.Bounded env12847 := by
  intro p hp
  have h : env12847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12846_12847 : H12AffineEnvironment.transform 10 1 env12846 = env12847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12846 == env12847) = true)

def env12848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,272392,73754,98644,8193,64,215366,79130,17665,516122,75102,392287,256,21792,46093,513]

theorem envBound12848 : H12AffineFastState.Bounded env12848 := by
  intro p hp
  have h : env12848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12836_12848 : H12AffineEnvironment.transform 6 9 env12836 = env12848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12836 == env12848) = true)

def env12849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,32,73754,98644,8193,64,215366,79130,17665,247858,75102,119927,256,21792,46093,513]

theorem envBound12849 : H12AffineFastState.Bounded env12849 := by
  intro p hp
  have h : env12849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12848_12849 : H12AffineEnvironment.transform 17 10280 env12848 = env12849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12848 == env12849) = true)

def env12850 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,32,73754,98564,8193,16,215318,79130,17665,247858,75022,119847,256,21792,46093,513]

theorem envBound12850 : H12AffineFastState.Bounded env12850 := by
  intro p hp
  have h : env12850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12849_12850 : H12AffineEnvironment.transform 5 16 env12849 = env12850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12849 == env12850) = true)

theorem identity12850 : scanCanonicalize (H12AffineFastState.compose env12850 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound12850 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env12851 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1024,32769,77851,32,73754,98564,8193,16,43277,79130,17665,10281,75022,119847,256,21792,46093,513]

theorem envBound12851 : H12AffineFastState.Bounded env12851 := by
  intro p hp
  have h : env12851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12850_12851 : H12AffineEnvironment.transform 16 122907 env12850 = env12851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env12850 == env12851) = true)

theorem identity12851 : scanCanonicalize (H12AffineFastState.compose env12851 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound12851 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env12852 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,65536,103447,10280,1024,32769,77851,32,73754,98564,8193,16,43277,79130,12557,10281,75022,106539,256,8492,46093,513]

theorem envBound12852 : H12AffineFastState.Bounded env12852 := by
  intro p hp
  have h : env12852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12851_12852 : H12AffineEnvironment.transform 13 13324 env12851 = env12852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env12851 == env12852) = true)

theorem identity12852 : scanCanonicalize (H12AffineFastState.compose env12852 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12852 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env12853 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,8203,46108,10280,1024,32769,4112,32,17,41231,8193,16,43277,5393,12557,10281,1285,32800,256,8492,46093,513]

theorem envBound12853 : H12AffineFastState.Bounded env12853 := by
  intro p hp
  have h : env12853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12852_12853 : H12AffineEnvironment.transform 15 8203 env12852 = env12853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12852 == env12853) = true)

theorem identity12853 : scanCanonicalize (H12AffineFastState.compose env12853 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12853 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12854 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,262,38161,2341,1024,32769,4112,32,17,32770,268,16,34816,5393,4096,2340,1285,32800,256,33,38144,513]

theorem envBound12854 : H12AffineFastState.Bounded env12854 := by
  intro p hp
  have h : env12854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12853_12854 : H12AffineEnvironment.transform 12 269 env12853 = env12854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12853 == env12854) = true)

theorem identity12854 : scanCanonicalize (H12AffineFastState.compose env12854 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12854 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12855 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5393,2341,1024,1,4112,32,17,2,268,16,2048,5393,4096,2340,1285,32,256,33,5376,513]

theorem envBound12855 : H12AffineFastState.Bounded env12855 := by
  intro p hp
  have h : env12855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12854_12855 : H12AffineEnvironment.transform 14 0 env12854 = env12855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12854 == env12855) = true)

theorem identity12855 : scanCanonicalize (H12AffineFastState.compose env12855 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound12855 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12856 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1061,269,292,0,262,308,2341,1024,1,1077,32,17,2,268,16,2048,308,1061,2340,1285,32,256,33,293,513]

theorem envBound12856 : H12AffineFastState.Bounded env12856 := by
  intro p hp
  have h : env12856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12855_12856 : H12AffineEnvironment.transform 11 1061 env12855 = env12856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env12855 == env12856) = true)

theorem identity12856 : scanCanonicalize (H12AffineFastState.compose env12856 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12856 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12857 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,308,269,292,0,262,308,2341,273,1,292,32,17,2,268,16,2048,308,308,2340,20,32,256,33,293,513]

theorem envBound12857 : H12AffineFastState.Bounded env12857 := by
  intro p hp
  have h : env12857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12856_12857 : H12AffineEnvironment.transform 9 273 env12856 = env12857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12856 == env12857) = true)

theorem identity12857 : scanCanonicalize (H12AffineFastState.compose env12857 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound12857 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12858 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,308,269,292,0,262,308,1,273,1,292,32,17,2,268,16,292,308,308,0,20,32,256,33,293,513]

theorem envBound12858 : H12AffineFastState.Bounded env12858 := by
  intro p hp
  have h : env12858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12857_12858 : H12AffineEnvironment.transform 10 292 env12857 = env12858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env12857 == env12858) = true)

def env12859 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,32,73754,98565,8193,17,215319,79130,17665,247858,75023,119846,256,21792,46093,513]

theorem envBound12859 : H12AffineFastState.Bounded env12859 := by
  intro p hp
  have h : env12859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12849_12859 : H12AffineEnvironment.transform 5 17 env12849 = env12859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12849 == env12859) = true)

theorem identity12859 : scanCanonicalize (H12AffineFastState.compose env12859 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound12859 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env12860 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1024,32769,77850,32,73754,98565,8193,17,75786,79130,17665,108847,75023,119846,256,21792,46093,513]

theorem envBound12860 : H12AffineFastState.Bounded env12860 := by
  intro p hp
  have h : env12860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12859_12860 : H12AffineEnvironment.transform 16 24861 env12859 = env12860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env12859 == env12860) = true)

theorem identity12860 : scanCanonicalize (H12AffineFastState.compose env12860 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12860 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env12861 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,13340,10280,1024,32769,77850,32,73754,98565,8193,17,75786,79130,4096,108847,75023,98599,256,33,46093,513]

theorem envBound12861 : H12AffineFastState.Bounded env12861 := by
  intro p hp
  have h : env12861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12860_12861 : H12AffineEnvironment.transform 13 5377 env12860 = env12861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12860 == env12861) = true)

theorem identity12861 : scanCanonicalize (H12AffineFastState.compose env12861 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound12861 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12862 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33031,13340,10280,1024,32769,45341,32,41245,2,8193,17,43277,46109,4096,10280,41992,32,256,33,46093,513]

theorem envBound12862 : H12AffineFastState.Bounded env12862 := by
  intro p hp
  have h : env12862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12861_12862 : H12AffineEnvironment.transform 15 33031 env12861 = env12862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env12861 == env12862) = true)

def env12863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,33,73754,98644,8193,64,215366,79130,17665,247859,75102,119926,256,21792,46093,513]

theorem envBound12863 : H12AffineFastState.Bounded env12863 := by
  intro p hp
  have h : env12863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12848_12863 : H12AffineEnvironment.transform 17 10281 env12848 = env12863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12848 == env12863) = true)

theorem identity12863 : scanCanonicalize (H12AffineFastState.compose env12863 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12863 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1024,32769,4161,33,16,41310,8193,64,158028,5392,17665,190521,1364,62588,256,21792,46093,513]

theorem envBound12864 : H12AffineFastState.Bounded env12864 := by
  intro p hp
  have h : env12864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12863_12864 : H12AffineEnvironment.transform 15 8202 env12863 = env12864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12863 == env12864) = true)

theorem identity12864 : scanCanonicalize (H12AffineFastState.compose env12864 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27741) := by decide +kernel

theorem selectedBound12864 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env12865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,27741,10281,1024,32769,4161,33,16,41310,8193,64,1297,5392,17665,33892,1364,62588,256,21792,46093,513]

theorem envBound12865 : H12AffineFastState.Bounded env12865 := by
  intro p hp
  have h : env12865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12864_12865 : H12AffineEnvironment.transform 16 27741 env12864 = env12865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27741 env12864 == env12865) = true)

theorem identity12865 : scanCanonicalize (H12AffineFastState.compose env12865 (packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound12865 : packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env12866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,19572,2048,1024,32769,4161,33,16,33143,40,64,1297,5392,17665,33892,1364,54357,256,21792,37924,513]

theorem envBound12866 : H12AffineFastState.Bounded env12866 := by
  intro p hp
  have h : env12866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12865_12866 : H12AffineEnvironment.transform 12 41 env12865 = env12866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env12865 == env12866) = true)

theorem identity12866 : scanCanonicalize (H12AffineFastState.compose env12866 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 3376) := by decide +kernel

theorem selectedBound12866 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env12867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,3376,35,19572,2048,1024,3377,4161,33,16,3143,40,64,1297,5392,17665,2388,1364,22885,256,21792,6420,513]

theorem envBound12867 : H12AffineFastState.Bounded env12867 := by
  intro p hp
  have h : env12867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12866_12867 : H12AffineEnvironment.transform 14 3376 env12866 = env12867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3376 env12866 == env12867) = true)

theorem identity12867 : scanCanonicalize (H12AffineFastState.compose env12867 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 6208) := by decide +kernel

theorem selectedBound12867 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env12868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,6208,3376,35,5172,2048,1024,3377,4161,33,16,3143,40,64,1297,5392,7489,2388,1364,293,256,3424,6420,513]

theorem envBound12868 : H12AffineFastState.Bounded env12868 := by
  intro p hp
  have h : env12868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12867_12868 : H12AffineEnvironment.transform 13 6208 env12867 = env12868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6208 env12867 == env12868) = true)

theorem identity12868 : scanCanonicalize (H12AffineFastState.compose env12868 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound12868 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,41,4112,1376,35,5172,80,1024,1377,4161,33,16,1047,40,64,1297,5392,5393,260,1364,293,256,1328,4420,513]

theorem envBound12869 : H12AffineFastState.Bounded env12869 := by
  intro p hp
  have h : env12869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12868_12869 : H12AffineEnvironment.transform 10 80 env12868 = env12869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env12868 == env12869) = true)

theorem identity12869 : scanCanonicalize (H12AffineFastState.compose env12869 (packedSelected [2,3,4,5,6,9,12,19] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound12869 : packedSelected [2,3,4,5,6,9,12,19] rootPS < 2^1333 := by decide +kernel

def env12870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,324,41,340,1376,35,1392,80,1024,1377,261,33,16,1047,40,64,1297,1108,1109,260,1364,293,256,1328,0,513]

theorem envBound12870 : H12AffineFastState.Bounded env12870 := by
  intro p hp
  have h : env12870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12869_12870 : H12AffineEnvironment.transform 11 324 env12869 = env12870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env12869 == env12870) = true)

theorem identity12870 : scanCanonicalize (H12AffineFastState.compose env12870 (packedSelected [6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12870 : packedSelected [6,7,9] rootPS < 2^1333 := by decide +kernel

def env12871 : List Nat := [2,4,8,16,32,64,9,256,33,1024,80,324,41,340,1376,35,1392,80,1024,1377,261,33,16,1047,40,64,1297,1108,1109,260,1364,293,256,1328,0,32]

theorem envBound12871 : H12AffineFastState.Bounded env12871 := by
  intro p hp
  have h : env12871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12870_12871 : H12AffineEnvironment.transform 8 33 env12870 = env12871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12870 == env12871) = true)

theorem identity12871 : scanCanonicalize (H12AffineFastState.compose env12871 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound12871 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env12872 : List Nat := [2,4,8,16,32,64,9,85,33,1024,80,17,41,1,1077,35,1061,80,1024,1076,80,33,16,1047,40,64,1092,1108,1109,81,1025,112,85,1125,0,32]

theorem envBound12872 : H12AffineFastState.Bounded env12872 := by
  intro p hp
  have h : env12872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12871_12872 : H12AffineEnvironment.transform 7 85 env12871 = env12872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env12871 == env12872) = true)

def env12873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6705549,8393985,10507600,8830976,2102685,12645452,256,21793,46213,2175563]

theorem envBound12873 : H12AffineFastState.Bounded env12873 := by
  intro p hp
  have h : env12873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12745_12873 : H12AffineEnvironment.transform 23 10588557 env12745 = env12873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env12745 == env12873) = true)

def env12874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98781,8328,64,6705549,2098513,17664,2543696,2102685,6349852,256,21793,46213,2175563]

theorem envBound12874 : H12AffineFastState.Bounded env12874 := by
  intro p hp
  have h : env12874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12873_12874 : H12AffineEnvironment.transform 22 2101328 env12873 = env12874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env12873 == env12874) = true)

def env12875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98781,8328,64,2259213,2098513,17664,2543696,2102685,2411676,256,21793,46213,2175563]

theorem envBound12875 : H12AffineFastState.Bounded env12875 := by
  intro p hp
  have h : env12875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12874_12875 : H12AffineEnvironment.transform 21 272512 env12874 = env12875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12874 == env12875) = true)

theorem identity12875 : scanCanonicalize (H12AffineFastState.compose env12875 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound12875 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,272512,16,98781,8328,64,158029,5393,17664,442384,1501,318684,256,21793,46213,74251]

theorem envBound12876 : H12AffineFastState.Bounded env12876 := by
  intro p hp
  have h : env12876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12875_12876 : H12AffineEnvironment.transform 20 4160 env12875 = env12876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12875 == env12876) = true)

theorem identity12876 : scanCanonicalize (H12AffineFastState.compose env12876 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12876 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env12877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,272512,16,41431,8328,64,158029,5393,17664,442384,1501,318684,256,21793,46213,513]

theorem envBound12877 : H12AffineFastState.Bounded env12877 := by
  intro p hp
  have h : env12877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12876_12877 : H12AffineEnvironment.transform 15 8202 env12876 = env12877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12876 == env12877) = true)

theorem identity12877 : scanCanonicalize (H12AffineFastState.compose env12877 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound12877 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4160,272512,16,41431,8328,64,56656,5393,17664,291853,1501,318684,256,21793,46213,513]

theorem envBound12878 : H12AffineFastState.Bounded env12878 := by
  intro p hp
  have h : env12878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12877_12878 : H12AffineEnvironment.transform 16 46109 env12877 = env12878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env12877 == env12878) = true)

def env12879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4160,272392,16,41311,8192,64,56656,5393,17664,291853,1365,318548,256,21793,46093,513]

theorem envBound12879 : H12AffineFastState.Bounded env12879 := by
  intro p hp
  have h : env12879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12878_12879 : H12AffineEnvironment.transform 6 8 env12878 = env12879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12878 == env12879) = true)

theorem identity12879 : scanCanonicalize (H12AffineFastState.compose env12879 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,5440,262144,1024,8540,4160,272392,16,2,8192,64,31757,5393,17664,291853,1365,294153,256,21793,5456,513]

theorem envBound12880 : H12AffineFastState.Bounded env12880 := by
  intro p hp
  have h : env12880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12879_12880 : H12AffineEnvironment.transform 14 8541 env12879 = env12880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12879 == env12880) = true)

theorem identity12880 : scanCanonicalize (H12AffineFastState.compose env12880 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 23888) := by decide +kernel

theorem selectedBound12880 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,5440,23888,1024,8540,4160,30040,16,2,8192,64,31757,5393,17664,10589,1365,8281,256,21793,5456,513]

theorem envBound12881 : H12AffineFastState.Bounded env12881 := by
  intro p hp
  have h : env12881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12880_12881 : H12AffineEnvironment.transform 17 23888 env12880 = env12881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23888 env12880 == env12881) = true)

theorem identity12881 : scanCanonicalize (H12AffineFastState.compose env12881 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12881 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12882 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,8202,4176,22592,272,8540,4160,28744,16,2,8192,64,31005,4097,16400,10589,69,8281,256,20529,4160,513]

theorem envBound12882 : H12AffineFastState.Bounded env12882 := by
  intro p hp
  have h : env12882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12881_12882 : H12AffineEnvironment.transform 9 272 env12881 = env12882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12881 == env12882) = true)

theorem identity12882 : scanCanonicalize (H12AffineFastState.compose env12882 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound12882 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12883 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12393,8541,8202,4176,10281,272,8540,4160,33,16,2,8192,64,2420,4097,12409,10589,69,8281,256,8280,4160,513]

theorem envBound12883 : H12AffineFastState.Bounded env12883 := by
  intro p hp
  have h : env12883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12882_12883 : H12AffineEnvironment.transform 13 12393 env12882 = env12883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env12882 == env12883) = true)

theorem identity12883 : scanCanonicalize (H12AffineFastState.compose env12883 (packedSelected [0,3,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12883 : packedSelected [0,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env12884 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4161,373,34,4176,2049,272,372,4160,33,16,2,40,64,2420,4097,4177,2421,69,113,256,112,4160,513]

theorem envBound12884 : H12AffineFastState.Bounded env12884 := by
  intro p hp
  have h : env12884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12883_12884 : H12AffineEnvironment.transform 12 40 env12883 = env12884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12883 == env12884) = true)

def env12885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46109,262144,1024,32769,4160,272393,16,41310,8193,64,56656,5393,17664,291853,1364,318549,256,21793,46092,513]

theorem envBound12885 : H12AffineFastState.Bounded env12885 := by
  intro p hp
  have h : env12885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12878_12885 : H12AffineEnvironment.transform 6 9 env12878 = env12885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12878 == env12885) = true)

theorem identity12885 : scanCanonicalize (H12AffineFastState.compose env12885 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound12885 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env12886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16448,262144,1024,29788,4160,272393,16,21763,8193,64,10509,5393,17664,291853,1364,272392,256,21793,16465,513]

theorem envBound12886 : H12AffineFastState.Bounded env12886 := by
  intro p hp
  have h : env12886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12885_12886 : H12AffineEnvironment.transform 14 29789 env12885 = env12886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env12885 == env12886) = true)

theorem identity12886 : scanCanonicalize (H12AffineFastState.compose env12886 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound12886 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16448,2421,1024,29788,4160,8572,16,21763,8193,64,10509,5393,17664,32120,1364,8573,256,21793,16465,513]

theorem envBound12887 : H12AffineFastState.Bounded env12887 := by
  intro p hp
  have h : env12887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12886_12887 : H12AffineEnvironment.transform 17 2421 env12886 = env12887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env12886 == env12887) = true)

theorem identity12887 : scanCanonicalize (H12AffineFastState.compose env12887 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12887 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12888 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,16401,2340,1024,29709,4113,8493,16,21763,8193,17,10509,5393,17664,32041,1285,8492,256,21793,16384,513]

theorem envBound12888 : H12AffineFastState.Bounded env12888 := by
  intro p hp
  have h : env12888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12887_12888 : H12AffineEnvironment.transform 5 17 env12887 = env12888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12887 == env12888) = true)

theorem identity12888 : scanCanonicalize (H12AffineFastState.compose env12888 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12888 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env12889 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,28728,8202,16401,2340,52,28729,4113,8493,16,20791,8193,17,10509,4389,16692,31005,305,8492,256,20757,16384,513]

theorem envBound12889 : H12AffineFastState.Bounded env12889 := by
  intro p hp
  have h : env12889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12888_12889 : H12AffineEnvironment.transform 9 52 env12888 = env12889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12888 == env12889) = true)

theorem identity12889 : scanCanonicalize (H12AffineFastState.compose env12889 (packedSelected [0,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 14621) := by decide +kernel

theorem selectedBound12889 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env12890 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,14621,2341,8202,14604,2340,52,2340,4113,8493,16,10282,8193,17,10509,4389,14377,0,305,8492,256,10248,14621,513]

theorem envBound12890 : H12AffineFastState.Bounded env12890 := by
  intro p hp
  have h : env12890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12889_12890 : H12AffineEnvironment.transform 13 14621 env12889 = env12890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14621 env12889 == env12890) = true)

theorem identity12890 : scanCanonicalize (H12AffineFastState.compose env12890 (packedSelected [6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound12890 : packedSelected [6,7,9] rootPS < 2^1333 := by decide +kernel

def env12891 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,2316,4113,2341,2310,4096,2340,52,2340,4113,2081,16,294,2317,17,1,4389,4389,0,305,2080,256,260,4113,513]

theorem envBound12891 : H12AffineFastState.Bounded env12891 := by
  intro p hp
  have h : env12891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12890_12891 : H12AffineEnvironment.transform 12 2316 env12890 = env12891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env12890 == env12891) = true)

theorem identity12891 : scanCanonicalize (H12AffineFastState.compose env12891 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound12891 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12892 : List Nat := [2,4,8,16,32,17,9,256,512,52,292,4096,40,4113,1,34,4096,0,52,0,4113,261,16,294,41,17,1,4389,4389,0,305,260,256,260,4113,513]

theorem envBound12892 : H12AffineFastState.Bounded env12892 := by
  intro p hp
  have h : env12892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12891_12892 : H12AffineEnvironment.transform 10 292 env12891 = env12892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env12891 == env12892) = true)

theorem identity12892 : scanCanonicalize (H12AffineFastState.compose env12892 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12892 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12893 : List Nat := [2,4,8,16,32,17,9,37,512,52,1,4096,40,4113,1,34,4096,0,52,0,4113,32,16,3,41,17,1,4096,4096,0,20,33,37,33,4113,513]

theorem envBound12893 : H12AffineFastState.Bounded env12893 := by
  intro p hp
  have h : env12893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12892_12893 : H12AffineEnvironment.transform 7 37 env12892 = env12893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12892 == env12893) = true)

theorem identity12893 : scanCanonicalize (H12AffineFastState.compose env12893 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound12893 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12894 : List Nat := [2,4,8,16,17,17,9,20,512,5,1,4096,25,4113,1,19,4096,0,5,0,4113,17,16,3,24,17,1,4096,4096,0,20,16,20,16,4113,513]

theorem envBound12894 : H12AffineFastState.Bounded env12894 := by
  intro p hp
  have h : env12894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12893_12894 : H12AffineEnvironment.transform 4 17 env12893 = env12894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env12893 == env12894) = true)

theorem identity12894 : scanCanonicalize (H12AffineFastState.compose env12894 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12895 : List Nat := [2,4,8,16,17,17,9,20,512,5,1,16,25,1,1,19,16,0,5,0,1,17,16,3,24,17,1,16,16,0,20,16,20,16,1,513]

theorem envBound12895 : H12AffineFastState.Bounded env12895 := by
  intro p hp
  have h : env12895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12894_12895 : H12AffineEnvironment.transform 11 16 env12894 = env12895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12894 == env12895) = true)

def env12896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98781,8328,64,2259212,2098513,17664,2543696,2102685,2411677,256,21793,46213,2175563]

theorem envBound12896 : H12AffineFastState.Bounded env12896 := by
  intro p hp
  have h : env12896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12874_12896 : H12AffineEnvironment.transform 21 272513 env12874 = env12896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12874 == env12896) = true)

def env12897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272393,2101328,98645,8192,64,2259212,2098513,17664,2543696,2102549,2411541,256,21793,46093,2175563]

theorem envBound12897 : H12AffineFastState.Bounded env12897 := by
  intro p hp
  have h : env12897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12896_12897 : H12AffineEnvironment.transform 6 8 env12896 = env12897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12896 == env12897) = true)

theorem identity12897 : scanCanonicalize (H12AffineFastState.compose env12897 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 225370) := by decide +kernel

theorem selectedBound12897 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,225370,272393,221194,98645,8192,64,67926,226571,17664,368650,222543,506959,256,21793,46093,147985]

theorem envBound12898 : H12AffineFastState.Bounded env12898 := by
  intro p hp
  have h : env12898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12897_12898 : H12AffineEnvironment.transform 20 225370 env12897 = env12898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 225370 env12897 == env12898) = true)

theorem identity12898 : scanCanonicalize (H12AffineFastState.compose env12898 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound12898 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1024,32769,225370,41341,221194,98645,8192,64,67926,226571,17664,76158,222543,210235,256,21793,46093,147985]

theorem envBound12899 : H12AffineFastState.Bounded env12899 := by
  intro p hp
  have h : env12899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12898_12899 : H12AffineEnvironment.transform 17 35188 env12898 = env12899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env12898 == env12899) = true)

theorem identity12899 : scanCanonicalize (H12AffineFastState.compose env12899 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound12899 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1024,32769,4161,41341,17,98645,8192,64,67926,5392,17664,76158,1364,21792,256,21793,46093,74250]

theorem envBound12900 : H12AffineFastState.Bounded env12900 := by
  intro p hp
  have h : env12900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12899_12900 : H12AffineEnvironment.transform 16 90139 env12899 = env12900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env12899 == env12900) = true)

theorem identity12900 : scanCanonicalize (H12AffineFastState.compose env12900 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12900 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1024,32769,4161,41341,17,41310,8192,64,10589,5392,17664,2421,1364,21792,256,21793,46093,513]

theorem envBound12901 : H12AffineFastState.Bounded env12901 := by
  intro p hp
  have h : env12901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12900_12901 : H12AffineEnvironment.transform 15 8203 env12900 = env12901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12900 == env12901) = true)

theorem identity12901 : scanCanonicalize (H12AffineFastState.compose env12901 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound12901 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1344,8203,16400,3124,1024,1345,4161,9277,17,9246,8192,64,10589,5392,17664,2421,1364,21792,256,21793,12621,513]

theorem envBound12902 : H12AffineFastState.Bounded env12902 := by
  intro p hp
  have h : env12902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12901_12902 : H12AffineEnvironment.transform 14 1344 env12901 = env12902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env12901 == env12902) = true)

theorem identity12902 : scanCanonicalize (H12AffineFastState.compose env12902 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound12902 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,1344,8203,12408,3124,1024,1345,4161,9277,17,9246,8192,64,10589,5392,13672,2421,1364,9544,256,9545,12621,513]

theorem envBound12903 : H12AffineFastState.Bounded env12903 := by
  intro p hp
  have h : env12903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12902_12903 : H12AffineEnvironment.transform 13 12392 env12902 = env12903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env12902 == env12903) = true)

theorem identity12903 : scanCanonicalize (H12AffineFastState.compose env12903 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound12903 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,4112,1344,115,4096,3124,1024,1345,4161,1093,17,1126,120,64,2341,5392,5392,2421,1364,1328,256,1329,4405,513]

theorem envBound12904 : H12AffineFastState.Bounded env12904 := by
  intro p hp
  have h : env12904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12903_12904 : H12AffineEnvironment.transform 12 120 env12903 = env12904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env12903 == env12904) = true)

theorem identity12904 : scanCanonicalize (H12AffineFastState.compose env12904 (packedSelected [5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound12904 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env12905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2405,120,2421,1344,115,2405,3124,1024,1345,2340,1093,17,1126,120,64,2341,3189,3189,2421,1364,1328,256,1329,2128,513]

theorem envBound12905 : H12AffineFastState.Bounded env12905 := by
  intro p hp
  have h : env12905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12904_12905 : H12AffineEnvironment.transform 11 2405 env12904 = env12905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env12904 == env12905) = true)

theorem identity12905 : scanCanonicalize (H12AffineFastState.compose env12905 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound12905 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env12906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1076,1361,120,1345,1344,115,1361,0,1024,1345,1296,1093,17,1126,120,64,1297,65,65,1345,1364,1328,256,1329,1124,513]

theorem envBound12906 : H12AffineFastState.Bounded env12906 := by
  intro p hp
  have h : env12906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12905_12906 : H12AffineEnvironment.transform 10 1076 env12905 = env12906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env12905 == env12906) = true)

theorem identity12906 : scanCanonicalize (H12AffineFastState.compose env12906 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12906 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12907 : List Nat := [2,4,8,16,32,64,8,256,512,53,1,356,120,372,373,115,356,0,53,372,293,112,17,83,120,64,292,65,65,372,353,261,256,260,81,513]

theorem envBound12907 : H12AffineFastState.Bounded env12907 := by
  intro p hp
  have h : env12907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12906_12907 : H12AffineEnvironment.transform 9 53 env12906 = env12907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12906 == env12907) = true)

theorem identity12907 : scanCanonicalize (H12AffineFastState.compose env12907 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12907 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12908 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,17,120,1,0,115,17,0,53,1,80,112,17,83,120,64,81,65,65,1,20,112,117,113,81,513]

theorem envBound12908 : H12AffineFastState.Bounded env12908 := by
  intro p hp
  have h : env12908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12907_12908 : H12AffineEnvironment.transform 7 117 env12907 = env12908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12907 == env12908) = true)

def env12909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272392,2101328,98644,8193,64,2259212,2098513,17664,2543696,2102548,2411540,256,21793,46092,2175563]

theorem envBound12909 : H12AffineFastState.Bounded env12909 := by
  intro p hp
  have h : env12909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12896_12909 : H12AffineEnvironment.transform 6 9 env12896 = env12909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12896 == env12909) = true)

def env12910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,272392,16,98644,8193,64,158028,5393,17664,442384,1364,318548,256,21793,46092,74251]

theorem envBound12910 : H12AffineFastState.Bounded env12910 := by
  intro p hp
  have h : env12910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12909_12910 : H12AffineEnvironment.transform 20 4160 env12909 = env12910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12909 == env12910) = true)

theorem identity12910 : scanCanonicalize (H12AffineFastState.compose env12910 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12910 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,272392,16,41310,8193,64,158028,5393,17664,442384,1364,318548,256,21793,46092,513]

theorem envBound12911 : H12AffineFastState.Bounded env12911 := by
  intro p hp
  have h : env12911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12910_12911 : H12AffineEnvironment.transform 15 8202 env12910 = env12911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12910 == env12911) = true)

theorem identity12911 : scanCanonicalize (H12AffineFastState.compose env12911 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound12911 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46108,262144,1024,32769,4160,272392,16,41310,8193,64,56656,5393,17664,291852,1364,318548,256,21793,46092,513]

theorem envBound12912 : H12AffineFastState.Bounded env12912 := by
  intro p hp
  have h : env12912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12911_12912 : H12AffineEnvironment.transform 16 46108 env12911 = env12912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env12911 == env12912) = true)

theorem identity12912 : scanCanonicalize (H12AffineFastState.compose env12912 (packedSelected [0,1,5,7,8,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12912 : packedSelected [0,1,5,7,8,20,24] rootPS < 2^1333 := by decide +kernel

def env12913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,38208,262144,1024,32769,4160,264532,16,32770,349,64,56656,5393,17664,283984,1364,318548,256,21793,38224,513]

theorem envBound12913 : H12AffineFastState.Bounded env12913 := by
  intro p hp
  have h : env12913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12912_12913 : H12AffineEnvironment.transform 12 348 env12912 = env12913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12912 == env12913) = true)

theorem identity12913 : scanCanonicalize (H12AffineFastState.compose env12913 (packedSelected [1,3,4,5,8,9,10,14,20,26] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound12913 : packedSelected [1,3,4,5,8,9,10,14,20,26] rootPS < 2^1333 := by decide +kernel

def env12914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,38208,56437,1024,32769,4160,54561,16,32770,349,64,56656,5393,17664,35109,1364,33,256,21793,38224,513]

theorem envBound12914 : H12AffineFastState.Bounded env12914 := by
  intro p hp
  have h : env12914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12913_12914 : H12AffineEnvironment.transform 17 56437 env12913 = env12914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env12913 == env12914) = true)

theorem identity12914 : scanCanonicalize (H12AffineFastState.compose env12914 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound12914 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env12915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,342,16401,2340,1024,21840,4160,112,16,21843,349,64,2049,5393,17664,23668,1364,33,256,21793,16385,513]

theorem envBound12915 : H12AffineFastState.Bounded env12915 := by
  intro p hp
  have h : env12915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12914_12915 : H12AffineEnvironment.transform 14 21841 env12914 = env12915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env12914 == env12915) = true)

theorem identity12915 : scanCanonicalize (H12AffineFastState.compose env12915 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3841) := by decide +kernel

theorem selectedBound12915 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3841,348,16384,19024,342,16401,2340,1024,19025,3905,112,16,19026,349,64,2049,2576,17664,17269,1364,33,256,18976,16385,513]

theorem envBound12916 : H12AffineFastState.Bounded env12916 := by
  intro p hp
  have h : env12916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12915_12916 : H12AffineEnvironment.transform 11 3841 env12915 = env12916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3841 env12915 == env12916) = true)

theorem identity12916 : scanCanonicalize (H12AffineFastState.compose env12916 (packedSelected [2,4,6,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 528) := by decide +kernel

theorem selectedBound12916 : packedSelected [2,4,6,7,10] rootPS < 2^1333 := by decide +kernel

def env12917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3841,348,528,2112,342,513,2340,1024,2113,3905,112,16,2114,349,64,2049,2576,1808,357,1364,33,256,2096,529,513]

theorem envBound12917 : H12AffineFastState.Bounded env12917 := by
  intro p hp
  have h : env12917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12916_12917 : H12AffineEnvironment.transform 13 528 env12916 = env12917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 528 env12916 == env12917) = true)

theorem identity12917 : scanCanonicalize (H12AffineFastState.compose env12917 (packedSelected [5,6,8,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound12917 : packedSelected [5,6,8,11,18] rootPS < 2^1333 := by decide +kernel

def env12918 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3669,8,528,2112,2,513,2160,1024,2113,3605,112,16,2114,9,64,2049,2576,1604,49,1024,33,84,2096,529,513]

theorem envBound12918 : H12AffineFastState.Bounded env12918 := by
  intro p hp
  have h : env12918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12917_12918 : H12AffineEnvironment.transform 7 84 env12917 = env12918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env12917 == env12918) = true)

theorem identity12918 : scanCanonicalize (H12AffineFastState.compose env12918 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12918 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12919 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,3589,8,528,2064,2,513,2080,1024,2065,3605,32,16,2066,9,16,2049,2576,1556,49,1024,33,4,2096,529,513]

theorem envBound12919 : H12AffineFastState.Bounded env12919 := by
  intro p hp
  have h : env12919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12918_12919 : H12AffineEnvironment.transform 5 16 env12918 = env12919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12918 == env12919) = true)

theorem identity12919 : scanCanonicalize (H12AffineFastState.compose env12919 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound12919 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env12920 : List Nat := [2,4,8,16,32,16,9,4,512,1024,16,1557,8,528,0,2,513,48,1024,1,1541,32,16,2,9,16,17,512,1556,49,1024,33,4,32,529,513]

theorem envBound12920 : H12AffineFastState.Bounded env12920 := by
  intro p hp
  have h : env12920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12919_12920 : H12AffineEnvironment.transform 10 16 env12919 = env12920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env12919 == env12920) = true)

theorem identity12920 : scanCanonicalize (H12AffineFastState.compose env12920 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound12920 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12921 : List Nat := [2,4,8,16,32,16,9,4,512,20,16,513,8,528,0,2,513,48,20,1,529,32,16,2,9,16,17,512,512,49,20,33,4,32,529,513]

theorem envBound12921 : H12AffineFastState.Bounded env12921 := by
  intro p hp
  have h : env12921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12920_12921 : H12AffineEnvironment.transform 9 20 env12920 = env12921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12920 == env12921) = true)

theorem identity12921 : scanCanonicalize (H12AffineFastState.compose env12921 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12921 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12922 : List Nat := [2,4,8,16,1,16,9,4,512,20,16,513,8,528,0,2,513,17,20,1,529,1,16,2,9,16,17,512,512,16,20,0,4,1,529,513]

theorem envBound12922 : H12AffineFastState.Bounded env12922 := by
  intro p hp
  have h : env12922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12921_12922 : H12AffineEnvironment.transform 4 1 env12921 = env12922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12921 == env12922) = true)

theorem identity12922 : scanCanonicalize (H12AffineFastState.compose env12922 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound12922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12923 : List Nat := [2,4,8,16,1,16,9,4,16,20,16,17,8,0,0,2,17,17,20,1,1,1,16,2,9,16,17,16,16,16,20,0,4,1,1,17]

theorem envBound12923 : H12AffineFastState.Bounded env12923 := by
  intro p hp
  have h : env12923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12922_12923 : H12AffineEnvironment.transform 8 16 env12922 = env12923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env12922 == env12923) = true)

def env12924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,272392,17,98644,8193,64,158029,5392,17664,442385,1365,318549,256,21793,46092,74250]

theorem envBound12924 : H12AffineFastState.Bounded env12924 := by
  intro p hp
  have h : env12924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12909_12924 : H12AffineEnvironment.transform 20 4161 env12909 = env12924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12909 == env12924) = true)

theorem identity12924 : scanCanonicalize (H12AffineFastState.compose env12924 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound12924 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,67619,1024,32769,4161,73771,17,98644,8193,64,158029,5392,17664,247858,1365,119926,256,21793,46092,74250]

theorem envBound12925 : H12AffineFastState.Bounded env12925 := by
  intro p hp
  have h : env12925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12924_12925 : H12AffineEnvironment.transform 17 67619 env12924 = env12925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env12924 == env12925) = true)

theorem identity12925 : scanCanonicalize (H12AffineFastState.compose env12925 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12925 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env12926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1024,32769,4161,32,17,41311,8193,64,158029,5392,17664,190521,1365,62589,256,21793,46092,513]

theorem envBound12926 : H12AffineFastState.Bounded env12926 := by
  intro p hp
  have h : env12926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12925_12926 : H12AffineEnvironment.transform 15 8203 env12925 = env12926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12925 == env12926) = true)

theorem identity12926 : scanCanonicalize (H12AffineFastState.compose env12926 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12926 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env12927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1024,32769,4161,32,17,41311,8193,64,146509,5392,4096,179513,1365,41341,256,33,46092,513]

theorem envBound12927 : H12AffineFastState.Bounded env12927 := by
  intro p hp
  have h : env12927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12926_12927 : H12AffineEnvironment.transform 13 5376 env12926 = env12927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12926 == env12927) = true)

theorem identity12927 : scanCanonicalize (H12AffineFastState.compose env12927 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound12927 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,13340,10280,1024,32769,4161,32,17,41311,8193,64,2129,5392,4096,35109,1365,41341,256,33,46092,513]

theorem envBound12928 : H12AffineFastState.Bounded env12928 := by
  intro p hp
  have h : env12928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12927_12928 : H12AffineEnvironment.transform 16 13340 env12927 = env12928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env12927 == env12928) = true)

def env12929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98780,8328,64,6705549,2098512,17665,2543697,2102685,6349853,256,21793,46213,2175563]

theorem envBound12929 : H12AffineFastState.Bounded env12929 := by
  intro p hp
  have h : env12929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12873_12929 : H12AffineEnvironment.transform 22 2101329 env12873 = env12929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env12873 == env12929) = true)

def env12930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98780,8328,64,2259213,2098512,17665,2543697,2102685,2411677,256,21793,46213,2175563]

theorem envBound12930 : H12AffineFastState.Bounded env12930 := by
  intro p hp
  have h : env12930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12929_12930 : H12AffineEnvironment.transform 21 272512 env12929 = env12930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12929 == env12930) = true)

theorem identity12930 : scanCanonicalize (H12AffineFastState.compose env12930 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound12930 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,272512,62660,98780,8328,64,171416,57797,17665,406724,61704,272392,256,21793,46213,120542]

theorem envBound12931 : H12AffineFastState.Bounded env12931 := by
  intro p hp
  have h : env12931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12930_12931 : H12AffineEnvironment.transform 20 58517 env12930 = env12931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env12930 == env12931) = true)

def env12932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,272392,62540,98644,8192,64,171280,57677,17665,406604,61704,272392,256,21793,46093,120406]

theorem envBound12932 : H12AffineFastState.Bounded env12932 := by
  intro p hp
  have h : env12932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12931_12932 : H12AffineEnvironment.transform 6 8 env12931 = env12932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12931 == env12932) = true)

theorem identity12932 : scanCanonicalize (H12AffineFastState.compose env12932 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 244846) := by decide +kernel

theorem selectedBound12932 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env12933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,244846,1024,32769,58397,234598,62540,98644,8192,64,171280,57677,17665,100386,61704,234598,256,21793,46093,120406]

theorem envBound12933 : H12AffineFastState.Bounded env12933 := by
  intro p hp
  have h : env12933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12932_12933 : H12AffineEnvironment.transform 17 244846 env12932 = env12933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 244846 env12932 == env12933) = true)

theorem identity12933 : scanCanonicalize (H12AffineFastState.compose env12933 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound12933 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,79130,35188,1024,32769,58397,41340,62540,98644,8192,64,108554,57677,17665,100386,61704,41340,256,21793,46093,120406]

theorem envBound12934 : H12AffineFastState.Bounded env12934 := by
  intro p hp
  have h : env12934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12933_12934 : H12AffineEnvironment.transform 16 79130 env12933 = env12934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env12933 == env12934) = true)

theorem identity12934 : scanCanonicalize (H12AffineFastState.compose env12934 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound12934 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env12935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,65536,79130,35188,1024,32769,37173,41340,33124,98644,8192,64,108554,37989,12329,100386,33824,41340,256,8201,46093,107390]

theorem envBound12935 : H12AffineFastState.Bounded env12935 := by
  intro p hp
  have h : env12935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12934_12935 : H12AffineEnvironment.transform 13 13608 env12934 = env12935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env12934 == env12935) = true)

theorem identity12935 : scanCanonicalize (H12AffineFastState.compose env12935 (packedSelected [1,3,4,5,9,10,12,14,15,19,20,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound12935 : packedSelected [1,3,4,5,9,10,12,14,15,19,20,28,31] rootPS < 2^1333 := by decide +kernel

def env12936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,33110,46156,35188,1024,32769,37173,41340,33124,2,8192,64,10588,37989,12329,2420,33824,41340,256,8201,46093,8744]

theorem envBound12936 : H12AffineFastState.Bounded env12936 := by
  intro p hp
  have h : env12936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12935_12936 : H12AffineEnvironment.transform 15 33110 env12935 = env12936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env12935 == env12936) = true)

theorem identity12936 : scanCanonicalize (H12AffineFastState.compose env12936 (packedSelected [0,1,2,3,6,7,11,16,17,18,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12936 : packedSelected [0,1,2,3,6,7,11,16,17,18,24,28] rootPS < 2^1333 := by decide +kernel

def env12937 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13324,32768,32882,46156,34896,1024,32769,36881,41048,32832,2,8192,64,10360,37989,12329,2128,33824,41048,36,8201,46093,8744]

theorem envBound12937 : H12AffineFastState.Bounded env12937 := by
  intro p hp
  have h : env12937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12936_12937 : H12AffineEnvironment.transform 7 36 env12936 = env12937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12936 == env12937) = true)

theorem identity12937 : scanCanonicalize (H12AffineFastState.compose env12937 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12937 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12938 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5156,32768,32882,37988,34896,1024,32769,36881,32880,32832,2,40,64,2128,37989,4097,2128,33824,32880,36,33,37925,512]

theorem envBound12938 : H12AffineFastState.Bounded env12938 := by
  intro p hp
  have h : env12938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12937_12938 : H12AffineEnvironment.transform 12 40 env12937 = env12938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12937 == env12938) = true)

theorem identity12938 : scanCanonicalize (H12AffineFastState.compose env12938 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound12938 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12939 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5156,32,82,5188,2160,1024,33,4145,80,96,2,40,64,2128,5189,4097,2128,1024,80,36,33,5125,512]

theorem envBound12939 : H12AffineFastState.Bounded env12939 := by
  intro p hp
  have h : env12939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12938_12939 : H12AffineEnvironment.transform 14 32 env12938 = env12939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env12938 == env12939) = true)

def env12940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,272393,62541,98645,8193,64,171281,57676,17665,406605,61704,272392,256,21793,46092,120407]

theorem envBound12940 : H12AffineFastState.Bounded env12940 := by
  intro p hp
  have h : env12940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12931_12940 : H12AffineEnvironment.transform 6 9 env12931 = env12940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12931 == env12940) = true)

theorem identity12940 : scanCanonicalize (H12AffineFastState.compose env12940 (packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12940 : packedSelected [0,3,4,7,10,12,15,16,17,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env12941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,33,62541,98645,8193,64,171281,57676,17665,138341,61704,32,256,21793,46092,120407]

theorem envBound12941 : H12AffineFastState.Bounded env12941 := by
  intro p hp
  have h : env12941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12940_12941 : H12AffineEnvironment.transform 17 10280 env12940 = env12941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12940 == env12941) = true)

theorem identity12941 : scanCanonicalize (H12AffineFastState.compose env12941 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound12941 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,58396,33,62541,21763,8193,64,171281,57676,17665,138341,61704,32,256,21793,46092,513]

theorem envBound12942 : H12AffineFastState.Bounded env12942 := by
  intro p hp
  have h : env12942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12941_12942 : H12AffineEnvironment.transform 15 54358 env12941 = env12942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env12941 == env12942) = true)

theorem identity12942 : scanCanonicalize (H12AffineFastState.compose env12942 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound12942 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env12943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49216,10280,1024,32769,58396,33,62541,21763,8193,64,23889,57676,17665,56357,61704,32,256,21793,46092,513]

theorem envBound12943 : H12AffineFastState.Bounded env12943 := by
  intro p hp
  have h : env12943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12942_12943 : H12AffineEnvironment.transform 16 49216 env12942 = env12943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env12942 == env12943) = true)

theorem identity12943 : scanCanonicalize (H12AffineFastState.compose env12943 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12943 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env12944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21591,16449,10280,1024,0,25629,33,29772,21763,8193,64,23889,24909,17665,23588,28937,32,256,21793,13325,513]

theorem envBound12944 : H12AffineFastState.Bounded env12944 := by
  intro p hp
  have h : env12944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12943_12944 : H12AffineEnvironment.transform 14 1 env12943 = env12944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12943 == env12944) = true)

theorem identity12944 : scanCanonicalize (H12AffineFastState.compose env12944 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12944 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env12945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8202,13340,10280,1024,0,4160,33,17,8542,8193,64,10508,5392,12636,10361,1364,32,256,8572,13325,513]

theorem envBound12945 : H12AffineFastState.Bounded env12945 := by
  intro p hp
  have h : env12945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12944_12945 : H12AffineEnvironment.transform 13 13405 env12944 = env12945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12944 == env12945) = true)

theorem identity12945 : scanCanonicalize (H12AffineFastState.compose env12945 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12946 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8202,13340,10280,1024,0,4113,33,17,8463,8193,17,10508,5392,12557,10280,1285,32,256,8493,13325,513]

theorem envBound12946 : H12AffineFastState.Bounded env12946 := by
  intro p hp
  have h : env12946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12945_12946 : H12AffineEnvironment.transform 5 17 env12945 = env12946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12945 == env12946) = true)

theorem identity12946 : scanCanonicalize (H12AffineFastState.compose env12946 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12946 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12947 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,8192,13324,1,8202,13340,10280,1024,0,4113,33,17,8202,8193,17,10249,5141,12296,10280,1024,32,5,8232,13325,513]

theorem envBound12947 : H12AffineFastState.Bounded env12947 := by
  intro p hp
  have h : env12947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12946_12947 : H12AffineEnvironment.transform 7 5 env12946 = env12947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12946 == env12947) = true)

theorem identity12947 : scanCanonicalize (H12AffineFastState.compose env12947 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound12947 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env12948 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1566,4096,8192,13324,1,8202,13340,9782,1024,0,4113,33,17,8202,8193,17,9751,5141,12296,9782,1024,32,5,8232,13325,513]

theorem envBound12948 : H12AffineFastState.Bounded env12948 := by
  intro p hp
  have h : env12948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12947_12948 : H12AffineEnvironment.transform 10 1566 env12947 = env12948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env12947 == env12948) = true)

theorem identity12948 : scanCanonicalize (H12AffineFastState.compose env12948 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound12948 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env12949 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1566,4096,41,5157,1,35,5173,1567,1024,0,4113,33,17,35,40,17,1598,5141,4129,1567,1024,32,5,1,5156,513]

theorem envBound12949 : H12AffineFastState.Bounded env12949 := by
  intro p hp
  have h : env12949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12948_12949 : H12AffineEnvironment.transform 12 41 env12948 = env12949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env12948 == env12949) = true)

theorem identity12949 : scanCanonicalize (H12AffineFastState.compose env12949 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12949 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env12950 : List Nat := [2,4,8,16,0,17,9,5,512,1024,1566,4096,9,5125,1,3,5141,1567,1024,0,4113,1,17,3,8,17,1566,5141,4097,1567,1024,0,5,1,5124,513]

theorem envBound12950 : H12AffineFastState.Bounded env12950 := by
  intro p hp
  have h : env12950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12949_12950 : H12AffineEnvironment.transform 4 0 env12949 = env12950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12949 == env12950) = true)

theorem identity12950 : scanCanonicalize (H12AffineFastState.compose env12950 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound12950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12951 : List Nat := [2,4,8,16,0,17,9,5,512,20,522,4096,9,4113,1,3,4097,523,20,0,4113,1,17,3,8,17,522,4097,4097,523,20,0,5,1,4112,513]

theorem envBound12951 : H12AffineFastState.Bounded env12951 := by
  intro p hp
  have h : env12951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12950_12951 : H12AffineEnvironment.transform 9 20 env12950 = env12951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12950 == env12951) = true)

theorem identity12951 : scanCanonicalize (H12AffineFastState.compose env12951 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound12951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12952 : List Nat := [2,0,8,16,0,17,9,1,512,16,522,4096,9,4113,1,3,4097,523,16,0,4113,1,17,3,8,17,522,4097,4097,523,16,0,1,1,4112,513]

theorem envBound12952 : H12AffineFastState.Bounded env12952 := by
  intro p hp
  have h : env12952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12951_12952 : H12AffineEnvironment.transform 1 0 env12951 = env12952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env12951 == env12952) = true)

theorem identity12952 : scanCanonicalize (H12AffineFastState.compose env12952 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 19) := by decide +kernel

theorem selectedBound12952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12953 : List Nat := [2,0,8,16,0,17,9,1,512,16,522,19,9,2,1,3,18,523,16,0,2,1,17,3,8,17,522,18,18,523,16,0,1,1,3,513]

theorem envBound12953 : H12AffineFastState.Bounded env12953 := by
  intro p hp
  have h : env12953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12952_12953 : H12AffineEnvironment.transform 11 19 env12952 = env12953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 19 env12952 == env12953) = true)

def env12954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98780,8328,64,2259212,2098512,17665,2543697,2102685,2411676,256,21793,46213,2175563]

theorem envBound12954 : H12AffineFastState.Bounded env12954 := by
  intro p hp
  have h : env12954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12929_12954 : H12AffineEnvironment.transform 21 272513 env12929 = env12954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12929 == env12954) = true)

theorem identity12954 : scanCanonicalize (H12AffineFastState.compose env12954 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound12954 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,2101329,95496,8328,64,2259212,2098512,17665,2499717,2102685,2373704,256,21793,16465,2175563]

theorem envBound12955 : H12AffineFastState.Bounded env12955 := by
  intro p hp
  have h : env12955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12954_12955 : H12AffineEnvironment.transform 14 29908 env12954 = env12955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env12954 == env12955) = true)

def env12956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,272513,2101329,73736,8328,64,2239500,2098512,4097,2499717,2102685,2373704,256,33,5457,2175563]

theorem envBound12956 : H12AffineFastState.Bounded env12956 := by
  intro p hp
  have h : env12956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12955_12956 : H12AffineEnvironment.transform 13 5376 env12955 = env12956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12955 == env12956) = true)

def env12957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,4160,272513,17,73736,8328,64,146508,5392,4097,406725,1501,272392,256,33,5457,74251]

theorem envBound12957 : H12AffineFastState.Bounded env12957 := by
  intro p hp
  have h : env12957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12956_12957 : H12AffineEnvironment.transform 20 4160 env12956 = env12957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12956 == env12957) = true)

theorem identity12957 : scanCanonicalize (H12AffineFastState.compose env12957 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound12957 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,67618,1024,8661,4160,73891,17,73736,8328,64,146508,5392,4097,212199,1501,73770,256,33,5457,74251]

theorem envBound12958 : H12AffineFastState.Bounded env12958 := by
  intro p hp
  have h : env12958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12957_12958 : H12AffineEnvironment.transform 17 67618 env12957 = env12958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env12957 == env12958) = true)

theorem identity12958 : scanCanonicalize (H12AffineFastState.compose env12958 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound12958 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,294,131072,2308,1024,8661,4160,8581,17,8494,8328,64,146508,5392,4097,146881,1501,8460,256,33,5457,9005]

theorem envBound12959 : H12AffineFastState.Bounded env12959 := by
  intro p hp
  have h : env12959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12958_12959 : H12AffineEnvironment.transform 15 294 env12958 = env12959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env12958 == env12959) = true)

theorem identity12959 : scanCanonicalize (H12AffineFastState.compose env12959 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13373) := by decide +kernel

theorem selectedBound12959 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,294,13373,2308,1024,8661,4160,8581,17,8494,8328,64,2161,5392,4097,2556,1501,8460,256,33,5457,9005]

theorem envBound12960 : H12AffineFastState.Bounded env12960 := by
  intro p hp
  have h : env12960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12959_12960 : H12AffineEnvironment.transform 16 13373 env12959 = env12960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13373 env12959 == env12960) = true)

theorem identity12960 : scanCanonicalize (H12AffineFastState.compose env12960 (packedSelected [2,6,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12960 : packedSelected [2,6,16,20] rootPS < 2^1333 := by decide +kernel

def env12961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,294,13373,2308,1024,8541,4160,8461,17,8494,8192,64,2161,5392,4097,2420,1365,8460,256,33,5457,9005]

theorem envBound12961 : H12AffineFastState.Bounded env12961 := by
  intro p hp
  have h : env12961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12960_12961 : H12AffineEnvironment.transform 6 8 env12960 = env12961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12960 == env12961) = true)

theorem identity12961 : scanCanonicalize (H12AffineFastState.compose env12961 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound12961 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5376,113,294,5392,2308,1024,112,4160,32,17,3,301,64,2161,5392,4097,2420,1365,33,256,33,5457,512]

theorem envBound12962 : H12AffineFastState.Bounded env12962 := by
  intro p hp
  have h : env12962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12961_12962 : H12AffineEnvironment.transform 12 301 env12961 = env12962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env12961 == env12962) = true)

theorem identity12962 : scanCanonicalize (H12AffineFastState.compose env12962 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound12962 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12963 : List Nat := [2,4,8,16,32,64,8,256,512,353,2048,4096,301,4193,113,294,4209,2308,353,112,4160,32,17,3,301,64,2161,4209,4097,2420,52,33,256,33,4144,512]

theorem envBound12963 : H12AffineFastState.Bounded env12963 := by
  intro p hp
  have h : env12963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12962_12963 : H12AffineEnvironment.transform 9 353 env12962 = env12963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env12962 == env12963) = true)

theorem identity12963 : scanCanonicalize (H12AffineFastState.compose env12963 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound12963 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12964 : List Nat := [2,4,8,16,32,64,8,256,512,353,2048,2350,301,2383,113,294,2399,2308,353,112,2414,32,17,3,301,64,2161,2399,2351,2420,52,33,256,33,2334,512]

theorem envBound12964 : H12AffineFastState.Bounded env12964 := by
  intro p hp
  have h : env12964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12963_12964 : H12AffineEnvironment.transform 11 2350 env12963 = env12964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env12963 == env12964) = true)

theorem identity12964 : scanCanonicalize (H12AffineFastState.compose env12964 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound12964 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env12965 : List Nat := [2,4,8,16,32,64,8,256,512,353,80,382,301,287,113,294,271,340,353,112,318,32,17,3,301,64,33,271,383,292,52,33,256,33,334,512]

theorem envBound12965 : H12AffineFastState.Bounded env12965 := by
  intro p hp
  have h : env12965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12964_12965 : H12AffineEnvironment.transform 10 80 env12964 = env12965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env12964 == env12965) = true)

theorem identity12965 : scanCanonicalize (H12AffineFastState.compose env12965 (packedSelected [2,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound12965 : packedSelected [2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12966 : List Nat := [2,4,8,16,32,64,8,78,512,47,80,48,99,81,113,104,65,26,47,112,112,32,17,3,99,64,33,65,49,106,52,33,78,33,0,512]

theorem envBound12966 : H12AffineFastState.Bounded env12966 := by
  intro p hp
  have h : env12966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12965_12966 : H12AffineEnvironment.transform 7 78 env12965 = env12966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env12965 == env12966) = true)

theorem identity12966 : scanCanonicalize (H12AffineFastState.compose env12966 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound12966 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12967 : List Nat := [2,4,8,16,32,32,8,46,512,47,48,48,3,49,17,8,33,26,47,16,16,32,17,3,3,32,33,33,49,10,52,33,46,33,0,512]

theorem envBound12967 : H12AffineFastState.Bounded env12967 := by
  intro p hp
  have h : env12967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12966_12967 : H12AffineEnvironment.transform 5 32 env12966 = env12967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env12966 == env12967) = true)

theorem identity12967 : scanCanonicalize (H12AffineFastState.compose env12967 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12967 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env12968 : List Nat := [2,4,8,1,32,32,8,46,512,47,33,33,3,32,0,8,33,11,47,1,1,32,0,3,3,32,33,33,32,10,37,33,46,33,0,512]

theorem envBound12968 : H12AffineFastState.Bounded env12968 := by
  intro p hp
  have h : env12968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12967_12968 : H12AffineEnvironment.transform 3 1 env12967 = env12968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12967 == env12968) = true)

theorem identity12968 : scanCanonicalize (H12AffineFastState.compose env12968 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound12968 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12969 : List Nat := [2,2,8,1,32,32,8,40,512,41,33,33,3,32,0,8,33,11,41,1,1,32,0,3,3,32,33,33,32,10,35,33,40,33,0,512]

theorem envBound12969 : H12AffineFastState.Bounded env12969 := by
  intro p hp
  have h : env12969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12968_12969 : H12AffineEnvironment.transform 1 2 env12968 = env12969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env12968 == env12969) = true)

theorem identity12969 : scanCanonicalize (H12AffineFastState.compose env12969 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12970 : List Nat := [2,2,8,1,1,1,8,9,512,8,0,0,3,1,0,8,0,11,8,1,1,1,0,3,3,1,0,0,1,10,2,0,9,0,0,512]

theorem envBound12970 : H12AffineFastState.Bounded env12970 := by
  intro p hp
  have h : env12970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12969_12970 : H12AffineEnvironment.transform 4 1 env12969 = env12970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12969 == env12970) = true)

theorem identity12970 : scanCanonicalize (H12AffineFastState.compose env12970 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12970 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12971 : List Nat := [2,2,3,1,1,1,3,2,512,3,0,0,3,1,0,3,0,0,3,1,1,1,0,3,3,1,0,0,1,1,2,0,2,0,0,512]

theorem envBound12971 : H12AffineFastState.Bounded env12971 := by
  intro p hp
  have h : env12971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12970_12971 : H12AffineEnvironment.transform 2 3 env12970 = env12971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12970 == env12971) = true)

theorem identity12971 : scanCanonicalize (H12AffineFastState.compose env12971 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12972 : List Nat := [0,0,1,1,1,1,1,0,512,1,0,0,1,1,0,1,0,0,1,1,1,1,0,1,1,1,0,0,1,1,0,0,0,0,0,512]

theorem envBound12972 : H12AffineFastState.Bounded env12972 := by
  intro p hp
  have h : env12972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12971_12972 : H12AffineEnvironment.transform 0 0 env12971 = env12972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12971 == env12972) = true)

def env12973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,4161,272513,16,73736,8328,64,146509,5393,4097,406724,1500,272393,256,33,5457,74250]

theorem envBound12973 : H12AffineFastState.Bounded env12973 := by
  intro p hp
  have h : env12973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12956_12973 : H12AffineEnvironment.transform 20 4161 env12956 = env12973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12956 == env12973) = true)

theorem identity12973 : scanCanonicalize (H12AffineFastState.compose env12973 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12973 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8322,131072,262144,1024,8661,4161,272513,16,138,8328,64,146509,5393,4097,406724,1500,272393,256,33,5457,648]

theorem envBound12974 : H12AffineFastState.Bounded env12974 := by
  intro p hp
  have h : env12974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12973_12974 : H12AffineEnvironment.transform 15 8322 env12973 = env12974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12973 == env12974) = true)

theorem identity12974 : scanCanonicalize (H12AffineFastState.compose env12974 (packedSelected [2,9,16,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound12974 : packedSelected [2,9,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8322,131072,2185,1024,8661,4161,8200,16,138,8328,64,146509,5393,4097,146509,1500,8320,256,33,5457,648]

theorem envBound12975 : H12AffineFastState.Bounded env12975 := by
  intro p hp
  have h : env12975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12974_12975 : H12AffineEnvironment.transform 17 2185 env12974 = env12975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env12974 == env12975) = true)

theorem identity12975 : scanCanonicalize (H12AffineFastState.compose env12975 (packedSelected [6,11,14,23] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound12975 : packedSelected [6,11,14,23] rootPS < 2^1333 := by decide +kernel

def env12976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5376,373,35,131072,2185,1024,372,4161,169,16,138,41,64,138476,5393,4097,138476,1500,33,256,33,5457,648]

theorem envBound12976 : H12AffineFastState.Bounded env12976 := by
  intro p hp
  have h : env12976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12975_12976 : H12AffineEnvironment.transform 12 161 env12975 = env12976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env12975 == env12976) = true)

theorem identity12976 : scanCanonicalize (H12AffineFastState.compose env12976 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12976 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,373,35,131072,2048,1024,372,4161,32,16,3,41,64,138341,5393,4097,138341,1365,33,256,33,5457,513]

theorem envBound12977 : H12AffineFastState.Bounded env12977 := by
  intro p hp
  have h : env12977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12976_12977 : H12AffineEnvironment.transform 6 9 env12976 = env12977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12976 == env12977) = true)

theorem identity12977 : scanCanonicalize (H12AffineFastState.compose env12977 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound12977 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,373,35,5393,2048,1024,372,4161,32,16,3,41,64,2420,5393,4097,2420,1365,33,256,33,5457,513]

theorem envBound12978 : H12AffineFastState.Bounded env12978 := by
  intro p hp
  have h : env12978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12977_12978 : H12AffineEnvironment.transform 16 5393 env12977 = env12978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env12977 == env12978) = true)

theorem identity12978 : scanCanonicalize (H12AffineFastState.compose env12978 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound12978 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12979 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,40,4453,373,35,4468,2048,101,372,4161,32,16,3,41,64,2420,4468,4097,2420,304,33,256,33,4404,513]

theorem envBound12979 : H12AffineFastState.Bounded env12979 := by
  intro p hp
  have h : env12979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12978_12979 : H12AffineEnvironment.transform 9 101 env12978 = env12979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env12978 == env12979) = true)

theorem identity12979 : scanCanonicalize (H12AffineFastState.compose env12979 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2927) := by decide +kernel

theorem selectedBound12979 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12980 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2927,40,2570,373,35,2587,2048,101,372,2862,32,16,3,41,64,2420,2587,2926,2420,304,33,256,33,2651,513]

theorem envBound12980 : H12AffineFastState.Bounded env12980 := by
  intro p hp
  have h : env12980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12979_12980 : H12AffineEnvironment.transform 11 2927 env12979 = env12980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2927 env12979 == env12980) = true)

theorem identity12980 : scanCanonicalize (H12AffineFastState.compose env12980 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound12980 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env12981 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,538,40,895,373,35,878,373,101,372,603,32,16,3,41,64,1,878,539,1,304,33,256,33,814,513]

theorem envBound12981 : H12AffineFastState.Bounded env12981 := by
  intro p hp
  have h : env12981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12980_12981 : H12AffineEnvironment.transform 10 373 env12980 = env12981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env12980 == env12981) = true)

theorem identity12981 : scanCanonicalize (H12AffineFastState.compose env12981 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12981 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env12982 : List Nat := [2,4,8,16,32,64,9,116,512,101,1,538,40,523,1,35,538,1,101,0,603,32,16,3,41,64,1,538,539,1,68,33,116,33,602,513]

theorem envBound12982 : H12AffineFastState.Bounded env12982 := by
  intro p hp
  have h : env12982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12981_12982 : H12AffineEnvironment.transform 7 116 env12981 = env12982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12981 == env12982) = true)

theorem identity12982 : scanCanonicalize (H12AffineFastState.compose env12982 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound12982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12983 : List Nat := [2,4,1,16,32,64,0,116,512,101,1,531,33,514,1,35,531,1,101,0,594,32,16,3,32,64,1,531,530,1,68,33,116,33,595,513]

theorem envBound12983 : H12AffineFastState.Bounded env12983 := by
  intro p hp
  have h : env12983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12982_12983 : H12AffineEnvironment.transform 2 1 env12982 = env12983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env12982 == env12983) = true)

theorem identity12983 : scanCanonicalize (H12AffineFastState.compose env12983 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound12983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12984 : List Nat := [2,4,1,16,32,64,0,116,3,101,1,16,33,1,1,35,16,1,101,0,81,32,16,3,32,64,1,16,17,1,68,33,116,33,80,2]

theorem envBound12984 : H12AffineFastState.Bounded env12984 := by
  intro p hp
  have h : env12984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12983_12984 : H12AffineEnvironment.transform 8 3 env12983 = env12984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env12983 == env12984) = true)

theorem identity12984 : scanCanonicalize (H12AffineFastState.compose env12984 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound12984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12985 : List Nat := [2,4,1,16,23,64,0,67,3,82,1,16,22,1,1,20,16,1,82,0,81,23,16,3,23,64,1,16,17,1,68,22,67,22,80,2]

theorem envBound12985 : H12AffineFastState.Bounded env12985 := by
  intro p hp
  have h : env12985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12984_12985 : H12AffineEnvironment.transform 4 23 env12984 = env12985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env12984 == env12985) = true)

theorem identity12985 : scanCanonicalize (H12AffineFastState.compose env12985 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound12985 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12986 : List Nat := [2,4,1,6,1,64,0,67,3,68,1,6,0,1,1,2,6,1,68,0,71,1,6,3,1,64,1,6,7,1,68,0,67,0,70,2]

theorem envBound12986 : H12AffineFastState.Bounded env12986 := by
  intro p hp
  have h : env12986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12985_12986 : H12AffineEnvironment.transform 3 6 env12985 = env12986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env12985 == env12986) = true)

def env12987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,272513,2101329,73737,8328,64,2239501,2098512,4096,2499717,2102685,2373704,256,32,5456,2175563]

theorem envBound12987 : H12AffineFastState.Bounded env12987 := by
  intro p hp
  have h : env12987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12955_12987 : H12AffineEnvironment.transform 13 5377 env12955 = env12987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12955 == env12987) = true)

def env12988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,4160,272513,17,73737,8328,64,146509,5392,4096,406725,1501,272392,256,32,5456,74251]

theorem envBound12988 : H12AffineFastState.Bounded env12988 := by
  intro p hp
  have h : env12988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12987_12988 : H12AffineEnvironment.transform 20 4160 env12987 = env12988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12987 == env12988) = true)

theorem identity12988 : scanCanonicalize (H12AffineFastState.compose env12988 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound12988 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,67755,1024,8660,4160,73770,17,73737,8328,64,146509,5392,4096,212078,1501,73891,256,32,5456,74251]

theorem envBound12989 : H12AffineFastState.Bounded env12989 := by
  intro p hp
  have h : env12989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12988_12989 : H12AffineEnvironment.transform 17 67755 env12988 = env12989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env12988 == env12989) = true)

theorem identity12989 : scanCanonicalize (H12AffineFastState.compose env12989 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound12989 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,88,5377,397,65536,131072,67755,1024,396,4160,65650,17,65617,208,64,138261,5392,4096,203830,1501,65787,256,32,5456,66131]

theorem envBound12990 : H12AffineFastState.Bounded env12990 := by
  intro p hp
  have h : env12990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12989_12990 : H12AffineEnvironment.transform 12 88 env12989 = env12990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env12989 == env12990) = true)

theorem identity12990 : scanCanonicalize (H12AffineFastState.compose env12990 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound12990 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env12991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,88,5377,397,65536,5392,67755,1024,396,4160,65650,17,65617,208,64,2309,5392,4096,67878,1501,65787,256,32,5456,66131]

theorem envBound12991 : H12AffineFastState.Bounded env12991 := by
  intro p hp
  have h : env12991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12990_12991 : H12AffineEnvironment.transform 16 5392 env12990 = env12991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env12990 == env12991) = true)

theorem identity12991 : scanCanonicalize (H12AffineFastState.compose env12991 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12991 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env12992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5377,260,65536,5392,67618,1024,261,4160,65650,17,65617,89,64,2309,5392,4096,67878,1364,65650,256,32,5456,66131]

theorem envBound12992 : H12AffineFastState.Bounded env12992 := by
  intro p hp
  have h : env12992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12991_12992 : H12AffineEnvironment.transform 6 9 env12991 = env12992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12991 == env12992) = true)

theorem identity12992 : scanCanonicalize (H12AffineFastState.compose env12992 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound12992 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env12993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5377,260,262,5392,2340,1024,261,4160,372,17,343,89,64,2309,5392,4096,2080,1364,372,256,32,5456,853]

theorem envBound12993 : H12AffineFastState.Bounded env12993 := by
  intro p hp
  have h : env12993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12992_12993 : H12AffineEnvironment.transform 15 262 env12992 = env12993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env12992 == env12993) = true)

theorem identity12993 : scanCanonicalize (H12AffineFastState.compose env12993 (packedSelected [2,4,5,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound12993 : packedSelected [2,4,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env12994 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,88,4452,260,262,4469,2340,101,261,4160,372,17,343,89,64,2309,4469,4096,2080,305,372,256,32,4405,853]

theorem envBound12994 : H12AffineFastState.Bounded env12994 := by
  intro p hp
  have h : env12994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12993_12994 : H12AffineEnvironment.transform 9 101 env12993 = env12994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env12993 == env12994) = true)

theorem identity12994 : scanCanonicalize (H12AffineFastState.compose env12994 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound12994 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env12995 : List Nat := [2,4,8,16,32,64,9,85,512,101,2048,4096,88,4145,81,83,4128,2161,101,80,4160,33,17,2,89,64,2128,4128,4096,2080,100,33,85,32,4192,512]

theorem envBound12995 : H12AffineFastState.Bounded env12995 := by
  intro p hp
  have h : env12995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12994_12995 : H12AffineEnvironment.transform 7 85 env12994 = env12995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env12994 == env12995) = true)

theorem identity12995 : scanCanonicalize (H12AffineFastState.compose env12995 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12995 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12996 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,4096,88,4113,81,83,4096,2129,69,80,4160,1,17,2,89,64,2128,4096,4096,2048,68,1,85,0,4160,512]

theorem envBound12996 : H12AffineFastState.Bounded env12996 := by
  intro p hp
  have h : env12996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12995_12996 : H12AffineEnvironment.transform 4 0 env12995 = env12996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12995 == env12996) = true)

theorem identity12996 : scanCanonicalize (H12AffineFastState.compose env12996 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound12996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12997 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,88,0,81,83,17,2129,69,80,81,1,17,2,89,64,2128,17,17,2048,68,1,85,0,81,512]

theorem envBound12997 : H12AffineFastState.Bounded env12997 := by
  intro p hp
  have h : env12997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12996_12997 : H12AffineEnvironment.transform 11 17 env12996 = env12997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12996 == env12997) = true)

theorem identity12997 : scanCanonicalize (H12AffineFastState.compose env12997 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12997 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12998 : List Nat := [2,4,8,16,0,64,9,85,512,69,1,17,88,0,81,83,17,80,69,80,81,1,17,2,89,64,81,17,17,1,68,1,85,0,81,512]

theorem envBound12998 : H12AffineFastState.Bounded env12998 := by
  intro p hp
  have h : env12998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12997_12998 : H12AffineEnvironment.transform 10 1 env12997 = env12998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12997 == env12998) = true)

theorem identity12998 : scanCanonicalize (H12AffineFastState.compose env12998 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 95) := by decide +kernel

theorem selectedBound12998 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12999 : List Nat := [2,4,8,16,0,64,9,85,95,69,1,17,88,0,81,83,17,80,69,80,81,1,17,2,89,64,81,17,17,1,68,1,85,0,81,95]

theorem envBound12999 : H12AffineFastState.Bounded env12999 := by
  intro p hp
  have h : env12999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12998_12999 : H12AffineEnvironment.transform 8 95 env12998 = env12999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 95 env12998 == env12999) = true)

def env13000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,4161,272513,16,73737,8328,64,146508,5393,4096,406724,1500,272393,256,32,5456,74250]

theorem envBound13000 : H12AffineFastState.Bounded env13000 := by
  intro p hp
  have h : env13000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12987_13000 : H12AffineEnvironment.transform 20 4161 env12987 = env13000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12987 == env13000) = true)

theorem identity13000 : scanCanonicalize (H12AffineFastState.compose env13000 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13000 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,131072,262144,1024,8660,4161,272513,16,2,8328,64,146508,5393,4096,406724,1500,272393,256,32,5456,513]

theorem envBound13001 : H12AffineFastState.Bounded env13001 := by
  intro p hp
  have h : env13001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13000_13001 : H12AffineEnvironment.transform 15 8203 env13000 = env13001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13000 == env13001) = true)

theorem identity13001 : scanCanonicalize (H12AffineFastState.compose env13001 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound13001 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env13002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,131072,146745,1024,8660,4161,136632,16,2,8328,64,146508,5393,4096,2557,1500,136496,256,32,5456,513]

theorem envBound13002 : H12AffineFastState.Bounded env13002 := by
  intro p hp
  have h : env13002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13001_13002 : H12AffineEnvironment.transform 17 146745 env13001 = env13002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env13001 == env13002) = true)

theorem identity13002 : scanCanonicalize (H12AffineFastState.compose env13002 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound13002 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,5393,10280,1024,8660,4161,169,16,2,8328,64,10589,5393,4096,2557,1500,33,256,32,5456,513]

theorem envBound13003 : H12AffineFastState.Bounded env13003 := by
  intro p hp
  have h : env13003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13002_13003 : H12AffineEnvironment.transform 16 5393 env13002 = env13003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env13002 == env13003) = true)

theorem identity13003 : scanCanonicalize (H12AffineFastState.compose env13003 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13003 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,342,5393,2421,1024,137,4161,169,16,2,469,64,2048,5393,4096,2557,1500,33,256,32,5456,513]

theorem envBound13004 : H12AffineFastState.Bounded env13004 := by
  intro p hp
  have h : env13004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13003_13004 : H12AffineEnvironment.transform 12 349 env13003 = env13004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13003 == env13004) = true)

theorem identity13004 : scanCanonicalize (H12AffineFastState.compose env13004 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5393,2421,1024,1,4161,33,16,2,349,64,2048,5393,4096,2421,1364,33,256,32,5456,513]

theorem envBound13005 : H12AffineFastState.Bounded env13005 := by
  intro p hp
  have h : env13005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13004_13005 : H12AffineEnvironment.transform 6 8 env13004 = env13005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13004 == env13005) = true)

theorem identity13005 : scanCanonicalize (H12AffineFastState.compose env13005 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13005 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13006 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,4096,349,5377,0,342,5393,2421,1024,1,4161,33,16,2,349,64,2048,5393,4096,2421,1364,33,256,32,5456,0]

theorem envBound13006 : H12AffineFastState.Bounded env13006 := by
  intro p hp
  have h : env13006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13005_13006 : H12AffineEnvironment.transform 8 1 env13005 = env13006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13005 == env13006) = true)

theorem identity13006 : scanCanonicalize (H12AffineFastState.compose env13006 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound13006 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13007 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1124,349,357,0,342,373,2421,1024,1,1061,33,16,2,349,64,2048,373,1124,2421,1364,33,256,32,308,0]

theorem envBound13007 : H12AffineFastState.Bounded env13007 := by
  intro p hp
  have h : env13007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13006_13007 : H12AffineEnvironment.transform 11 1124 env13006 = env13007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env13006 == env13007) = true)

theorem identity13007 : scanCanonicalize (H12AffineFastState.compose env13007 (packedSelected [2,11] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound13007 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13008 : List Nat := [2,4,8,16,32,64,8,101,1,1024,2048,1124,56,0,0,51,16,2064,1024,1,1061,33,16,2,56,64,2048,16,1124,2064,1073,33,101,32,81,0]

theorem envBound13008 : H12AffineFastState.Bounded env13008 := by
  intro p hp
  have h : env13008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13007_13008 : H12AffineEnvironment.transform 7 101 env13007 = env13008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env13007 == env13008) = true)

theorem identity13008 : scanCanonicalize (H12AffineFastState.compose env13008 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13008 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13009 : List Nat := [2,4,8,16,32,64,8,101,1,101,2048,1,56,0,0,51,16,2064,101,1,64,33,16,2,56,64,2048,16,1,2064,84,33,101,32,81,0]

theorem envBound13009 : H12AffineFastState.Bounded env13009 := by
  intro p hp
  have h : env13009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13008_13009 : H12AffineEnvironment.transform 9 101 env13008 = env13009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13008 == env13009) = true)

theorem identity13009 : scanCanonicalize (H12AffineFastState.compose env13009 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13009 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env13010 : List Nat := [2,4,8,16,32,64,8,101,1,101,0,1,56,0,0,51,16,16,101,1,64,33,16,2,56,64,0,16,1,16,84,33,101,32,81,0]

theorem envBound13010 : H12AffineFastState.Bounded env13010 := by
  intro p hp
  have h : env13010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13009_13010 : H12AffineEnvironment.transform 10 0 env13009 = env13010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13009 == env13010) = true)

theorem identity13010 : scanCanonicalize (H12AffineFastState.compose env13010 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13010 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13011 : List Nat := [2,4,8,16,32,17,8,52,1,52,0,1,56,0,0,51,16,16,52,1,17,33,16,2,56,17,0,16,1,16,5,33,52,32,0,0]

theorem envBound13011 : H12AffineFastState.Bounded env13011 := by
  intro p hp
  have h : env13011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13010_13011 : H12AffineEnvironment.transform 5 17 env13010 = env13011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13010 == env13011) = true)

theorem identity13011 : scanCanonicalize (H12AffineFastState.compose env13011 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13011 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env13012 : List Nat := [2,4,8,1,32,0,8,37,1,37,0,1,41,0,0,34,1,1,37,1,0,33,1,2,41,0,0,1,1,1,5,33,37,32,0,0]

theorem envBound13012 : H12AffineFastState.Bounded env13012 := by
  intro p hp
  have h : env13012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13011_13012 : H12AffineEnvironment.transform 3 1 env13011 = env13012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13011 == env13012) = true)

theorem identity13012 : scanCanonicalize (H12AffineFastState.compose env13012 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13012 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13013 : List Nat := [2,4,8,1,1,0,8,4,1,4,0,1,8,0,0,3,1,1,4,1,0,0,1,2,8,0,0,1,1,1,5,0,4,1,0,0]

theorem envBound13013 : H12AffineFastState.Bounded env13013 := by
  intro p hp
  have h : env13013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13012_13013 : H12AffineEnvironment.transform 4 1 env13012 = env13013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13012 == env13013) = true)

def env13014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound13014 : H12AffineFastState.Bounded env13014 := by
  intro p hp
  have h : env13014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12744_13014 : H12AffineEnvironment.transform 18 1025 env12744 = env13014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12744 == env13014) = true)

theorem identity13014 : scanCanonicalize (H12AffineFastState.compose env13014 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642689) := by decide +kernel

theorem selectedBound13014 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642689,8328,64,4464768,10642444,10507600,8830977,156817,14845248,257,2237484,2278793,213830]

theorem envBound13015 : H12AffineFastState.Bounded env13015 := by
  intro p hp
  have h : env13015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13014_13015 : H12AffineEnvironment.transform 23 8642689 env13014 = env13015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642689 env13014 == env13015) = true)

def env13016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,8388608,8642689,8328,64,4464768,8393984,8528988,8830977,156817,12645452,257,21792,46213,213830]

theorem envBound13016 : H12AffineFastState.Bounded env13016 := by
  intro p hp
  have h : env13016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13015_13016 : H12AffineEnvironment.transform 20 160012 env13015 = env13016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160012 env13015 == env13016) = true)

def env13017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169352,95497,8328,64,4464768,163976,45524,284041,156817,4350404,257,21792,46213,213830]

theorem envBound13017 : H12AffineFastState.Bounded env13017 := by
  intro p hp
  have h : env13017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13016_13017 : H12AffineEnvironment.transform 22 169352 env13016 = env13017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env13016 == env13017) = true)

def env13018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169352,95497,8328,64,2048,163976,45524,284041,156817,411972,257,21792,46213,213830]

theorem envBound13018 : H12AffineFastState.Bounded env13018 := by
  intro p hp
  have h : env13018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13017_13018 : H12AffineEnvironment.transform 21 272512 env13017 = env13018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13017 == env13018) = true)

theorem identity13018 : scanCanonicalize (H12AffineFastState.compose env13018 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound13018 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,58517,272512,17,95497,8328,64,2048,5393,45524,284041,61704,318685,257,21792,46213,120543]

theorem envBound13019 : H12AffineFastState.Bounded env13019 := by
  intro p hp
  have h : env13019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13018_13019 : H12AffineEnvironment.transform 16 38297 env13018 = env13019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env13018 == env13019) = true)

def env13020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,17,95497,8192,64,2048,5393,45404,283905,61704,318549,257,21792,46093,120407]

theorem envBound13020 : H12AffineFastState.Bounded env13020 := by
  intro p hp
  have h : env13020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13019_13020 : H12AffineEnvironment.transform 6 8 env13019 = env13020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13019 == env13020) = true)

theorem identity13020 : scanCanonicalize (H12AffineFastState.compose env13020 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound13020 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130174,1025,32769,58397,119926,17,95497,8192,64,2048,5393,45404,108927,61704,73771,257,21792,46093,120407]

theorem envBound13021 : H12AffineFastState.Bounded env13021 := by
  intro p hp
  have h : env13021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13020_13021 : H12AffineEnvironment.transform 17 130174 env13020 = env13021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env13020 == env13021) = true)

theorem identity13021 : scanCanonicalize (H12AffineFastState.compose env13021 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound13021 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env13022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,38161,43048,1025,32769,58397,32800,17,8543,8192,64,2048,5393,45404,64809,61704,29821,257,21792,46093,33281]

theorem envBound13022 : H12AffineFastState.Bounded env13022 := by
  intro p hp
  have h : env13022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13021_13022 : H12AffineEnvironment.transform 15 21590 env13021 = env13022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env13021 == env13022) = true)

theorem identity13022 : scanCanonicalize (H12AffineFastState.compose env13022 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13022 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env13023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,343,38161,43048,1025,32769,45340,32800,17,8543,8192,64,2048,5393,45404,43048,41993,8572,257,33,46093,33281]

theorem envBound13023 : H12AffineFastState.Bounded env13023 := by
  intro p hp
  have h : env13023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13022_13023 : H12AffineEnvironment.transform 13 5377 env13022 = env13023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13022 == env13023) = true)

theorem identity13023 : scanCanonicalize (H12AffineFastState.compose env13023 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13023 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env13024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,343,13388,2421,1025,8540,4161,8573,17,8543,8192,64,2048,5393,4097,2421,1364,8572,257,33,5456,9052]

theorem envBound13024 : H12AffineFastState.Bounded env13024 := by
  intro p hp
  have h : env13024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13023_13024 : H12AffineEnvironment.transform 14 8541 env13023 = env13024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13023 == env13024) = true)

theorem identity13024 : scanCanonicalize (H12AffineFastState.compose env13024 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound13024 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5432,5377,5221,343,372,2421,1025,5220,4161,5189,17,5223,5432,64,2048,5393,4097,2421,1364,5188,257,33,5456,5732]

theorem envBound13025 : H12AffineFastState.Bounded env13025 := by
  intro p hp
  have h : env13025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13024_13025 : H12AffineEnvironment.transform 12 5432 env13024 = env13025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env13024 == env13025) = true)

theorem identity13025 : scanCanonicalize (H12AffineFastState.compose env13025 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound13025 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,41,16,372,343,372,2421,1025,373,1360,340,17,374,41,64,2048,0,1296,2421,1364,341,257,33,65,885]

theorem envBound13026 : H12AffineFastState.Bounded env13026 := by
  intro p hp
  have h : env13026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13025_13026 : H12AffineEnvironment.transform 11 1297 env13025 = env13026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env13025 == env13026) = true)

theorem identity13026 : scanCanonicalize (H12AffineFastState.compose env13026 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13026 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13027 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1124,41,16,1,34,1,2048,1025,0,1061,33,17,3,41,64,2048,0,1125,2048,1057,32,116,33,65,512]

theorem envBound13027 : H12AffineFastState.Bounded env13027 := by
  intro p hp
  have h : env13027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13026_13027 : H12AffineEnvironment.transform 7 117 env13026 = env13027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13026 == env13027) = true)

theorem identity13027 : scanCanonicalize (H12AffineFastState.compose env13027 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound13027 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13028 : List Nat := [2,4,8,16,32,64,8,117,113,1024,2048,1124,41,16,1,34,1,2048,1025,0,1061,33,17,3,41,64,2048,0,1125,2048,1057,32,116,33,65,113]

theorem envBound13028 : H12AffineFastState.Bounded env13028 := by
  intro p hp
  have h : env13028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13027_13028 : H12AffineEnvironment.transform 8 113 env13027 = env13028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env13027 == env13028) = true)

theorem identity13028 : scanCanonicalize (H12AffineFastState.compose env13028 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound13028 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13029 : List Nat := [2,4,8,16,32,48,8,5,1,1024,2048,1044,41,16,1,34,1,2048,1025,0,1061,33,17,3,41,48,2048,0,1045,2048,1057,32,4,33,49,1]

theorem envBound13029 : H12AffineFastState.Bounded env13029 := by
  intro p hp
  have h : env13029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13028_13029 : H12AffineEnvironment.transform 5 48 env13028 = env13029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env13028 == env13029) = true)

theorem identity13029 : scanCanonicalize (H12AffineFastState.compose env13029 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13029 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13030 : List Nat := [2,4,8,16,1,17,8,5,1,1024,2048,1044,8,16,1,3,1,2048,1025,0,1028,0,17,3,8,17,2048,0,1045,2048,1024,1,4,0,16,1]

theorem envBound13030 : H12AffineFastState.Bounded env13030 := by
  intro p hp
  have h : env13030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13029_13030 : H12AffineEnvironment.transform 4 1 env13029 = env13030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13029 == env13030) = true)

theorem identity13030 : scanCanonicalize (H12AffineFastState.compose env13030 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound13030 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13031 : List Nat := [2,4,8,16,1,17,8,5,1,20,2048,0,8,16,1,3,1,2048,21,0,16,0,17,3,8,17,2048,0,1,2048,20,1,4,0,16,1]

theorem envBound13031 : H12AffineFastState.Bounded env13031 := by
  intro p hp
  have h : env13031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13030_13031 : H12AffineEnvironment.transform 9 20 env13030 = env13031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13030 == env13031) = true)

theorem identity13031 : scanCanonicalize (H12AffineFastState.compose env13031 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13032 : List Nat := [2,4,8,16,1,17,8,5,1,20,0,0,8,16,1,3,1,0,21,0,16,0,17,3,8,17,0,0,1,0,20,1,4,0,16,1]

theorem envBound13032 : H12AffineFastState.Bounded env13032 := by
  intro p hp
  have h : env13032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13031_13032 : H12AffineEnvironment.transform 10 0 env13031 = env13032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13031 == env13032) = true)

theorem identity13032 : scanCanonicalize (H12AffineFastState.compose env13032 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound13032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13033 : List Nat := [2,4,6,16,1,17,6,5,1,20,0,0,6,16,1,3,1,0,21,0,16,0,17,3,6,17,0,0,1,0,20,1,4,0,16,1]

theorem envBound13033 : H12AffineFastState.Bounded env13033 := by
  intro p hp
  have h : env13033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13032_13033 : H12AffineEnvironment.transform 2 6 env13032 = env13033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env13032 == env13033) = true)

theorem identity13033 : scanCanonicalize (H12AffineFastState.compose env13033 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13033 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13034 : List Nat := [2,4,6,0,1,1,6,5,1,4,0,0,6,0,1,3,1,0,5,0,0,0,1,3,6,1,0,0,1,0,4,1,4,0,0,1]

theorem envBound13034 : H12AffineFastState.Bounded env13034 := by
  intro p hp
  have h : env13034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13033_13034 : H12AffineEnvironment.transform 3 0 env13033 = env13034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13033 == env13034) = true)

def env13035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,17,95497,8193,64,2048,5393,45405,283904,61704,318548,257,21792,46092,120406]

theorem envBound13035 : H12AffineFastState.Bounded env13035 := by
  intro p hp
  have h : env13035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13019_13035 : H12AffineEnvironment.transform 6 9 env13019 = env13035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13019 == env13035) = true)

theorem identity13035 : scanCanonicalize (H12AffineFastState.compose env13035 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound13035 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89378,1025,32769,58396,95531,17,95497,8193,64,2048,5393,45405,67618,61704,98678,257,21792,46092,120406]

theorem envBound13036 : H12AffineFastState.Bounded env13036 := by
  intro p hp
  have h : env13036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13035_13036 : H12AffineEnvironment.transform 17 89378 env13035 = env13036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env13035 == env13036) = true)

theorem identity13036 : scanCanonicalize (H12AffineFastState.compose env13036 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound13036 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env13037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29823,38160,10589,1025,32769,58396,340,17,374,8193,64,2048,5393,45405,31837,61704,62729,257,21792,46092,41513]

theorem envBound13037 : H12AffineFastState.Bounded env13037 := by
  intro p hp
  have h : env13037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13036_13037 : H12AffineEnvironment.transform 15 29823 env13036 = env13037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env13036 == env13037) = true)

theorem identity13037 : scanCanonicalize (H12AffineFastState.compose env13037 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13037 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env13038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21795,38160,2049,1025,32769,50496,340,17,374,349,64,2048,5393,36865,23809,53332,54357,257,21792,38224,33653]

theorem envBound13038 : H12AffineFastState.Bounded env13038 := by
  intro p hp
  have h : env13038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13037_13038 : H12AffineEnvironment.transform 12 348 env13037 = env13038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13037 == env13038) = true)

theorem identity13038 : scanCanonicalize (H12AffineFastState.compose env13038 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound13038 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,372,21795,5220,2049,1025,373,17460,340,17,374,349,64,2048,5393,4469,23809,20768,21793,257,21792,5156,513]

end H12CloudChart1