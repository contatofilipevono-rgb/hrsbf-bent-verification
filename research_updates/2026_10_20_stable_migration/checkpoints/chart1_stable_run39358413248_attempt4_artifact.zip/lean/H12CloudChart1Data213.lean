import H12CloudChart1Data212

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env53932 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,269,1045,1,263,1028,1572,1024,0,260,33,16,3,268,17,1793,1029,48,1572,1285,32,256,33,1045,513]

theorem envBound53932 : H12AffineFastState.Bounded env53932 := by
  intro p hp
  have h : env53932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53926_53932 : H12AffineEnvironment.transform 10 1793 env53926 = env53932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53926 == env53932) = true)

theorem identity53932 : scanCanonicalize (H12AffineFastState.compose env53932 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53933 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,49,269,32,1,263,49,529,53,0,260,33,16,3,268,17,820,48,48,529,304,32,256,33,32,513]

theorem envBound53933 : H12AffineFastState.Bounded env53933 := by
  intro p hp
  have h : env53933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53932_53933 : H12AffineEnvironment.transform 9 53 env53932 = env53933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53932 == env53933) = true)

def env53934 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,269,2837,1,263,2820,2341,1024,0,3588,33,16,3,268,17,2048,2821,3888,2341,1285,32,256,33,2837,513]

theorem envBound53934 : H12AffineFastState.Bounded env53934 := by
  intro p hp
  have h : env53934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53925_53934 : H12AffineEnvironment.transform 11 3889 env53925 = env53934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env53925 == env53934) = true)

def env53935 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,269,1045,1,263,1028,1573,1024,0,260,33,16,3,268,17,1792,1029,48,1573,1285,32,256,33,1045,513]

theorem envBound53935 : H12AffineFastState.Bounded env53935 := by
  intro p hp
  have h : env53935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53934_53935 : H12AffineEnvironment.transform 10 1792 env53934 = env53935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env53934 == env53935) = true)

theorem identity53935 : scanCanonicalize (H12AffineFastState.compose env53935 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53936 : List Nat := [2,4,8,16,32,17,9,256,512,273,529,49,269,260,1,263,277,820,273,0,260,33,16,3,268,17,529,276,48,820,20,32,256,33,260,513]

theorem envBound53936 : H12AffineFastState.Bounded env53936 := by
  intro p hp
  have h : env53936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53935_53936 : H12AffineEnvironment.transform 9 273 env53935 = env53936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53935 == env53936) = true)

def env53937 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,41,32,1,35,49,528,53,0,32,33,16,3,40,17,529,48,48,528,20,32,36,33,32,513]

theorem envBound53937 : H12AffineFastState.Bounded env53937 := by
  intro p hp
  have h : env53937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53936_53937 : H12AffineEnvironment.transform 7 36 env53936 = env53937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53936 == env53937) = true)

def env53938 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,49,40,33,1,34,48,529,52,0,33,33,16,3,41,17,529,49,48,529,20,32,37,33,33,513]

theorem envBound53938 : H12AffineFastState.Bounded env53938 := by
  intro p hp
  have h : env53938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53936_53938 : H12AffineEnvironment.transform 7 37 env53936 = env53938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53936 == env53938) = true)

theorem identity53938 : scanCanonicalize (H12AffineFastState.compose env53938 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound53938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53939 : List Nat := [2,4,8,16,32,17,9,37,42,52,59,49,40,33,1,34,48,59,52,0,33,33,16,3,41,17,59,49,48,59,20,32,37,33,33,43]

theorem envBound53939 : H12AffineFastState.Bounded env53939 := by
  intro p hp
  have h : env53939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53938_53939 : H12AffineEnvironment.transform 8 42 env53938 = env53939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env53938 == env53939) = true)

def leafEnv53939 : List Nat := [2,4,8,16,32,17,9,37,42,52,59,49,40,33,1,34,48,59,52,0,33,33,16,3,20,41,1,17,59,49,48,59,20,32,37,33,4,35,33,43,1,33,0]

def active53939 : List Nat := [0,1,2,3,4]

def tree53939 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53939 : H12WitnessSearch.Good tree53939 := H12GlobalWitnessIndex.good

theorem leafIdentity53939 : H12AffineFastState.composeSystem env53939 rootObs = leafEnv53939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53939 rootObs == leafEnv53939) = true)

theorem terminalChecked53939 : H12PackedTerminal.terminalCheckFast leafEnv53939 active53939 tree53939 = true := by decide +kernel

def env53940 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,269,1044,1,263,1029,1572,1024,0,261,33,16,3,268,17,1793,1028,49,1572,1285,32,256,33,1044,513]

theorem envBound53940 : H12AffineFastState.Bounded env53940 := by
  intro p hp
  have h : env53940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53934_53940 : H12AffineEnvironment.transform 10 1793 env53934 = env53940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env53934 == env53940) = true)

def env53941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58397,272392,16,41310,8193,64,10509,57677,45404,294993,1364,272393,256,41340,16465,513]

theorem envBound53941 : H12AffineFastState.Bounded env53941 := by
  intro p hp
  have h : env53941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53919_53941 : H12AffineEnvironment.transform 16 16449 env53919 = env53941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env53919 == env53941) = true)

theorem identity53941 : scanCanonicalize (H12AffineFastState.compose env53941 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound53941 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,10281,1024,32769,58397,33,16,41310,8193,64,10509,57677,45404,43128,1364,32,256,41340,16465,513]

theorem envBound53942 : H12AffineFastState.Bounded env53942 := by
  intro p hp
  have h : env53942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53941_53942 : H12AffineEnvironment.transform 17 10281 env53941 = env53942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53941 == env53942) = true)

theorem identity53942 : scanCanonicalize (H12AffineFastState.compose env53942 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound53942 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env53943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,2129,8202,16449,10281,1024,2128,27724,33,16,10511,8193,64,10509,26908,14605,8233,1364,32,256,10541,16465,513]

theorem envBound53943 : H12AffineFastState.Bounded env53943 := by
  intro p hp
  have h : env53943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53942_53943 : H12AffineEnvironment.transform 14 2129 env53942 = env53943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env53942 == env53943) = true)

theorem identity53943 : scanCanonicalize (H12AffineFastState.compose env53943 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound53943 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,2129,5127,16449,7204,1024,2128,22593,33,16,7426,5132,64,7424,23825,3328,5156,1364,32,256,7456,16465,513]

theorem envBound53944 : H12AffineFastState.Bounded env53944 := by
  intro p hp
  have h : env53944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53943_53944 : H12AffineEnvironment.transform 12 5133 env53943 = env53944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env53943 == env53944) = true)

theorem identity53944 : scanCanonicalize (H12AffineFastState.compose env53944 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound53944 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env53945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,3100,16384,2129,3094,16449,1077,1024,2128,16464,33,16,1299,3101,64,1297,17664,3328,3125,1364,32,256,1329,16465,513]

theorem envBound53945 : H12AffineFastState.Bounded env53945 := by
  intro p hp
  have h : env53945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53944_53945 : H12AffineEnvironment.transform 11 2065 env53944 = env53945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env53944 == env53945) = true)

theorem identity53945 : scanCanonicalize (H12AffineFastState.compose env53945 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53945 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53946 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,3100,16384,2049,3094,16401,1077,1024,2048,16384,33,16,1299,3101,16,1297,17664,3328,3125,1284,32,256,1329,16385,513]

theorem envBound53946 : H12AffineFastState.Bounded env53946 := by
  intro p hp
  have h : env53946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53945_53946 : H12AffineEnvironment.transform 5 16 env53945 = env53946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53945 == env53946) = true)

theorem identity53946 : scanCanonicalize (H12AffineFastState.compose env53946 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound53946 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53947 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,3100,2308,2049,3094,2325,1077,1024,2048,2308,33,16,1299,3101,16,1297,3076,3328,3125,1284,32,256,1329,2309,513]

theorem envBound53947 : H12AffineFastState.Bounded env53947 := by
  intro p hp
  have h : env53947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53946_53947 : H12AffineEnvironment.transform 13 2308 env53946 = env53947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env53946 == env53947) = true)

theorem identity53947 : scanCanonicalize (H12AffineFastState.compose env53947 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound53947 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53948 : List Nat := [2,4,8,16,32,16,9,256,512,1024,276,261,1288,16,277,1282,1,1077,1024,276,16,33,16,1299,1289,16,1297,1296,1044,1313,1284,32,256,1329,17,513]

theorem envBound53948 : H12AffineFastState.Bounded env53948 := by
  intro p hp
  have h : env53948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53947_53948 : H12AffineEnvironment.transform 10 276 env53947 = env53948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env53947 == env53948) = true)

theorem identity53948 : scanCanonicalize (H12AffineFastState.compose env53948 (packedSelected [1,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound53948 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env53949 : List Nat := [2,4,8,16,32,16,9,256,512,37,276,261,301,16,277,295,1,16,37,276,16,33,16,310,300,16,308,309,49,260,289,32,256,276,17,513]

theorem envBound53949 : H12AffineFastState.Bounded env53949 := by
  intro p hp
  have h : env53949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53948_53949 : H12AffineEnvironment.transform 9 37 env53948 = env53949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env53948 == env53949) = true)

theorem identity53949 : scanCanonicalize (H12AffineFastState.compose env53949 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53949 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53950 : List Nat := [2,4,8,16,32,16,9,4,512,37,16,1,41,16,17,35,1,16,37,16,16,33,16,50,40,16,48,49,49,0,37,32,4,16,17,513]

theorem envBound53950 : H12AffineFastState.Bounded env53950 := by
  intro p hp
  have h : env53950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53949_53950 : H12AffineEnvironment.transform 7 4 env53949 = env53950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53949 == env53950) = true)

theorem identity53950 : scanCanonicalize (H12AffineFastState.compose env53950 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53950 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53951 : List Nat := [2,4,8,16,32,16,9,4,16,37,16,1,41,16,17,35,1,16,37,16,16,33,16,50,40,16,48,49,49,0,37,32,4,16,17,17]

theorem envBound53951 : H12AffineFastState.Bounded env53951 := by
  intro p hp
  have h : env53951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53950_53951 : H12AffineEnvironment.transform 8 16 env53950 = env53951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53950 == env53951) = true)

theorem identity53951 : scanCanonicalize (H12AffineFastState.compose env53951 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53952 : List Nat := [2,4,8,16,16,16,9,4,16,21,16,1,25,16,17,19,1,16,21,16,16,17,16,2,24,16,0,1,1,0,21,16,4,16,17,17]

theorem envBound53952 : H12AffineFastState.Bounded env53952 := by
  intro p hp
  have h : env53952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53951_53952 : H12AffineEnvironment.transform 4 16 env53951 = env53952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53951 == env53952) = true)

theorem identity53952 : scanCanonicalize (H12AffineFastState.compose env53952 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53953 : List Nat := [2,4,8,0,0,0,9,4,0,5,0,1,9,0,1,3,1,0,5,0,0,1,0,2,8,0,0,1,1,0,5,0,4,0,1,1]

theorem envBound53953 : H12AffineFastState.Bounded env53953 := by
  intro p hp
  have h : env53953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53952_53953 : H12AffineEnvironment.transform 3 0 env53952 = env53953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53952 == env53953) = true)

def env53954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8193,64,4677966,2172251,2118976,442385,75102,6407191,256,2188651,2196550,513]

theorem envBound53954 : H12AffineFastState.Bounded env53954 := by
  intro p hp
  have h : env53954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53880_53954 : H12AffineEnvironment.transform 22 17 env53880 = env53954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env53880 == env53954) = true)

theorem identity53954 : scanCanonicalize (H12AffineFastState.compose env53954 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound53954 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41311,8193,64,4456789,2172251,2118976,368650,75102,6407191,256,2188651,2196550,513]

theorem envBound53955 : H12AffineFastState.Bounded env53955 := by
  intro p hp
  have h : env53955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53954_53955 : H12AffineEnvironment.transform 16 90139 env53954 = env53955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env53954 == env53955) = true)

theorem identity53955 : scanCanonicalize (H12AffineFastState.compose env53955 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound53955 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,262144,1024,32769,2097152,4194304,17,41311,8193,64,4456789,2139148,2118976,270685,41993,6309184,256,2155580,2098449,513]

theorem envBound53956 : H12AffineFastState.Bounded env53956 := by
  intro p hp
  have h : env53956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53955_53956 : H12AffineEnvironment.transform 15 33111 env53955 = env53956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env53955 == env53956) = true)

theorem identity53956 : scanCanonicalize (H12AffineFastState.compose env53956 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53956 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env53957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,2097152,4194304,17,41311,8193,64,4204925,2139148,2118976,2421,41993,6309184,256,2155580,2098449,513]

theorem envBound53957 : H12AffineFastState.Bounded env53957 := by
  intro p hp
  have h : env53957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53956_53957 : H12AffineEnvironment.transform 17 10280 env53956 = env53957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53956 == env53957) = true)

theorem identity53957 : scanCanonicalize (H12AffineFastState.compose env53957 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound53957 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,2097152,32,17,41311,8193,64,10589,2139148,2118976,2421,41993,2114912,256,2155580,2098449,513]

theorem envBound53958 : H12AffineFastState.Bounded env53958 := by
  intro p hp
  have h : env53958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53957_53958 : H12AffineEnvironment.transform 21 32 env53957 = env53958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env53957 == env53958) = true)

theorem identity53958 : scanCanonicalize (H12AffineFastState.compose env53958 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound53958 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,25629,32,17,41311,8193,64,10589,49169,12637,2421,41993,8573,256,32801,24844,513]

theorem envBound53959 : H12AffineFastState.Bounded env53959 := by
  intro p hp
  have h : env53959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53958_53959 : H12AffineEnvironment.transform 20 25629 env53958 = env53959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env53958 == env53959) = true)

theorem identity53959 : scanCanonicalize (H12AffineFastState.compose env53959 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53959 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,343,24908,10280,1024,1,25629,32,17,8543,8193,64,10589,16401,12637,2421,9225,8573,256,33,24844,513]

theorem envBound53960 : H12AffineFastState.Bounded env53960 := by
  intro p hp
  have h : env53960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53959_53960 : H12AffineEnvironment.transform 14 0 env53959 = env53960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53959 == env53960) = true)

theorem identity53960 : scanCanonicalize (H12AffineFastState.compose env53960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,343,16401,2421,1024,1,17728,32,17,2,348,64,2048,16401,4096,2421,1364,32,256,33,16465,513]

theorem envBound53961 : H12AffineFastState.Bounded env53961 := by
  intro p hp
  have h : env53961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53960_53961 : H12AffineEnvironment.transform 12 349 env53960 = env53961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53960 == env53961) = true)

theorem identity53961 : scanCanonicalize (H12AffineFastState.compose env53961 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5748) := by decide +kernel

theorem selectedBound53961 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5748,0,343,5733,2421,1024,1,4916,32,17,2,348,64,2048,5733,4096,2421,1364,32,256,33,5669,513]

theorem envBound53962 : H12AffineFastState.Bounded env53962 := by
  intro p hp
  have h : env53962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53961_53962 : H12AffineEnvironment.transform 13 5748 env53961 = env53962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5748 env53961 == env53962) = true)

def env53963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound53963 : H12AffineFastState.Bounded env53963 := by
  intro p hp
  have h : env53963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53843_53963 : H12AffineEnvironment.transform 18 1025 env53843 = env53963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env53843 == env53963) = true)

theorem identity53963 : scanCanonicalize (H12AffineFastState.compose env53963 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound53963 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655366,18973836,10507601,8749382,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound53964 : H12AffineFastState.Bounded env53964 := by
  intro p hp
  have h : env53964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53963_53964 : H12AffineEnvironment.transform 16 82247 env53963 = env53964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env53963 == env53964) = true)

def env53965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623434,8393984,10507601,8749382,2102684,12645453,257,21793,46212,2175563]

theorem envBound53965 : H12AffineFastState.Bounded env53965 := by
  intro p hp
  have h : env53965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53964_53965 : H12AffineEnvironment.transform 23 10588556 env53964 = env53965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env53964 == env53965) = true)

def env53966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623434,2098512,17665,2461974,2102684,6349853,257,21793,46212,2175563]

theorem envBound53966 : H12AffineFastState.Bounded env53966 := by
  intro p hp
  have h : env53966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53965_53966 : H12AffineEnvironment.transform 22 2101328 env53965 = env53966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env53965 == env53966) = true)

def env53967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177098,2098512,17665,2461974,2102684,2411677,257,21793,46212,2175563]

theorem envBound53967 : H12AffineFastState.Bounded env53967 := by
  intro p hp
  have h : env53967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53966_53967 : H12AffineEnvironment.transform 21 272512 env53966 = env53967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53966 == env53967) = true)

theorem identity53967 : scanCanonicalize (H12AffineFastState.compose env53967 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound53967 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38296,262144,1025,32769,2097152,272512,2101328,21763,8328,64,2157717,2098512,17665,2377161,2102684,2411677,257,21793,46212,2156180]

theorem envBound53968 : H12AffineFastState.Bounded env53968 := by
  intro p hp
  have h : env53968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53967_53968 : H12AffineEnvironment.transform 15 54495 env53967 = env53968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env53967 == env53968) = true)

def env53969 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,262144,1025,32769,2097152,272512,2101248,21763,8328,16,2157717,2098432,17665,2377113,2102684,2411677,257,21793,46212,2156180]

theorem envBound53969 : H12AffineFastState.Bounded env53969 := by
  intro p hp
  have h : env53969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53968_53969 : H12AffineEnvironment.transform 5 16 env53968 = env53969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53968 == env53969) = true)

def env53970 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23808,1025,32769,2097152,30080,2101248,21763,8328,16,2157717,2098432,17665,2103449,2102684,2134429,257,21793,46212,2156180]

theorem envBound53970 : H12AffineFastState.Bounded env53970 := by
  intro p hp
  have h : env53970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53969_53970 : H12AffineEnvironment.transform 17 23808 env53969 = env53970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env53969 == env53970) = true)

theorem identity53970 : scanCanonicalize (H12AffineFastState.compose env53970 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 4540) := by decide +kernel

theorem selectedBound53970 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env53971 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23808,1025,32769,4540,30080,444,21763,8328,16,64809,5308,17665,2341,1056,32801,257,21793,46212,63272]

theorem envBound53971 : H12AffineFastState.Bounded env53971 := by
  intro p hp
  have h : env53971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53970_53971 : H12AffineEnvironment.transform 20 4540 env53970 = env53971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4540 env53970 == env53971) = true)

theorem identity53971 : scanCanonicalize (H12AffineFastState.compose env53971 (packedSelected [1,4,5,8,9,14,16,18,19,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound53971 : packedSelected [1,4,5,8,9,14,16,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,32768,40971,38296,10628,1025,32769,4540,260,444,8583,8328,16,35245,5308,12677,2341,1056,32801,257,8613,46212,33708]

theorem envBound53972 : H12AffineFastState.Bounded env53972 := by
  intro p hp
  have h : env53972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53971_53972 : H12AffineEnvironment.transform 13 13444 env53971 = env53972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env53971 == env53972) = true)

theorem identity53972 : scanCanonicalize (H12AffineFastState.compose env53972 (packedSelected [0,3,4,5,7,10,12,15,17,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound53972 : packedSelected [0,3,4,5,7,10,12,15,17,22] rootPS < 2^1333 := by decide +kernel

def env53973 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,13444,32768,40971,37941,10281,1025,32769,4113,169,17,8234,8328,16,34816,5308,12328,2184,1056,32801,172,8200,46212,33281]

theorem envBound53973 : H12AffineFastState.Bounded env53973 := by
  intro p hp
  have h : env53973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53972_53973 : H12AffineEnvironment.transform 7 173 env53972 = env53973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53972 == env53973) = true)

theorem identity53973 : scanCanonicalize (H12AffineFastState.compose env53973 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53973 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53974 : List Nat := [2,4,8,16,32,16,128,173,512,21,2048,4096,8192,12433,32768,40971,36896,10281,20,32769,4113,169,17,8234,8328,16,34816,4265,12328,2184,53,32801,172,8200,45201,33281]

theorem envBound53974 : H12AffineFastState.Bounded env53974 := by
  intro p hp
  have h : env53974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53973_53974 : H12AffineEnvironment.transform 9 21 env53973 = env53974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53973 == env53974) = true)

theorem identity53974 : scanCanonicalize (H12AffineFastState.compose env53974 (packedSelected [0,2,7,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound53974 : packedSelected [0,2,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env53975 : List Nat := [2,4,8,16,32,16,128,173,512,21,2048,4096,8192,12433,8200,3,12328,10281,20,8201,4113,169,17,8234,8328,16,10248,4265,12328,2184,53,8233,172,8200,4249,8713]

theorem envBound53975 : H12AffineFastState.Bounded env53975 := by
  intro p hp
  have h : env53975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53974_53975 : H12AffineEnvironment.transform 14 8200 env53974 = env53975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env53974 == env53975) = true)

theorem identity53975 : scanCanonicalize (H12AffineFastState.compose env53975 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound53975 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53976 : List Nat := [2,4,8,16,32,16,128,173,512,21,2048,4096,161,4144,169,3,4233,2184,20,168,4113,169,17,139,41,16,2217,4265,4233,2184,53,136,172,169,4249,680]

theorem envBound53976 : H12AffineFastState.Bounded env53976 := by
  intro p hp
  have h : env53976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53975_53976 : H12AffineEnvironment.transform 12 161 env53975 = env53976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env53975 == env53976) = true)

theorem identity53976 : scanCanonicalize (H12AffineFastState.compose env53976 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound53976 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env53977 : List Nat := [2,4,8,16,32,16,41,4,512,21,2048,4096,8,4144,0,3,4128,2081,20,1,4113,0,17,34,41,16,2048,4096,4128,2081,53,33,5,0,4144,513]

theorem envBound53977 : H12AffineFastState.Bounded env53977 := by
  intro p hp
  have h : env53977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53976_53977 : H12AffineEnvironment.transform 6 41 env53976 = env53977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env53976 == env53977) = true)

theorem identity53977 : scanCanonicalize (H12AffineFastState.compose env53977 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound53977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53978 : List Nat := [2,4,8,16,32,16,41,4,512,21,2048,33,8,17,0,3,1,2081,20,1,48,0,17,34,41,16,2048,33,1,2081,53,33,5,0,17,513]

theorem envBound53978 : H12AffineFastState.Bounded env53978 := by
  intro p hp
  have h : env53978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53977_53978 : H12AffineEnvironment.transform 11 33 env53977 = env53978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env53977 == env53978) = true)

theorem identity53978 : scanCanonicalize (H12AffineFastState.compose env53978 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound53978 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53979 : List Nat := [2,4,8,16,32,16,41,4,32,21,2048,33,8,17,0,3,1,2081,20,1,48,0,17,34,41,16,2048,33,1,2081,53,33,5,0,17,33]

theorem envBound53979 : H12AffineFastState.Bounded env53979 := by
  intro p hp
  have h : env53979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53978_53979 : H12AffineEnvironment.transform 8 32 env53978 = env53979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env53978 == env53979) = true)

theorem identity53979 : scanCanonicalize (H12AffineFastState.compose env53979 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53979 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53980 : List Nat := [2,4,8,16,1,16,8,4,1,21,2048,0,8,17,0,3,1,2048,20,1,17,0,17,3,8,16,2048,0,1,2048,20,0,5,0,17,0]

theorem envBound53980 : H12AffineFastState.Bounded env53980 := by
  intro p hp
  have h : env53980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53979_53980 : H12AffineEnvironment.transform 4 1 env53979 = env53980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53979 == env53980) = true)

theorem identity53980 : scanCanonicalize (H12AffineFastState.compose env53980 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound53980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53981 : List Nat := [2,4,8,16,1,16,8,4,1,21,16,0,8,17,0,3,1,16,20,1,17,0,17,3,8,16,16,0,1,16,20,0,5,0,17,0]

theorem envBound53981 : H12AffineFastState.Bounded env53981 := by
  intro p hp
  have h : env53981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53980_53981 : H12AffineEnvironment.transform 10 16 env53980 = env53981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env53980 == env53981) = true)

theorem identity53981 : scanCanonicalize (H12AffineFastState.compose env53981 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53981 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53982 : List Nat := [2,4,8,10,1,10,8,4,1,15,10,0,8,11,0,3,1,10,14,1,11,0,11,3,8,10,10,0,1,10,14,0,5,0,11,0]

theorem envBound53982 : H12AffineFastState.Bounded env53982 := by
  intro p hp
  have h : env53982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53981_53982 : H12AffineEnvironment.transform 3 10 env53981 = env53982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53981 == env53982) = true)

def env53983 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23809,1025,32769,2097152,30081,2101248,21763,8328,16,2157717,2098432,17665,2103448,2102684,2134428,257,21793,46212,2156180]

theorem envBound53983 : H12AffineFastState.Bounded env53983 := by
  intro p hp
  have h : env53983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53969_53983 : H12AffineEnvironment.transform 17 23809 env53969 = env53983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env53969 == env53983) = true)

theorem identity53983 : scanCanonicalize (H12AffineFastState.compose env53983 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound53983 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env53984 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23809,1025,32769,4405,30081,309,21763,8328,16,64928,5173,17665,2477,1193,32937,257,21793,46212,63393]

theorem envBound53984 : H12AffineFastState.Bounded env53984 := by
  intro p hp
  have h : env53984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53983_53984 : H12AffineEnvironment.transform 20 4405 env53983 = env53984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env53983 == env53984) = true)

theorem identity53984 : scanCanonicalize (H12AffineFastState.compose env53984 (packedSelected [0,4,5,7,12,15,18,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53984 : packedSelected [0,4,5,7,12,15,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53985 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,54415,38296,23809,1025,32769,4405,21644,309,21763,389,16,56493,5173,17665,2477,1193,32937,257,21793,38281,54956]

theorem envBound53985 : H12AffineFastState.Bounded env53985 := by
  intro p hp
  have h : env53985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53984_53985 : H12AffineEnvironment.transform 12 269 env53984 = env53985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53984 == env53985) = true)

theorem identity53985 : scanCanonicalize (H12AffineFastState.compose env53985 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound53985 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53986 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,137,21510,5393,23809,1025,136,4405,21644,309,21763,389,16,23588,5173,17665,2477,1193,32,257,21793,5376,22053]

theorem envBound53986 : H12AffineFastState.Bounded env53986 := by
  intro p hp
  have h : env53986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53985_53986 : H12AffineEnvironment.transform 14 137 env53985 = env53986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env53985 == env53986) = true)

theorem identity53986 : scanCanonicalize (H12AffineFastState.compose env53986 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53986 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env53987 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,16384,137,21510,5172,23588,1025,136,4112,21644,16,21542,160,16,23588,5173,17444,2184,1193,32,36,21508,5157,22053]

theorem envBound53987 : H12AffineFastState.Bounded env53987 := by
  intro p hp
  have h : env53987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53986_53987 : H12AffineEnvironment.transform 7 37 env53986 = env53987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53986 == env53987) = true)

theorem identity53987 : scanCanonicalize (H12AffineFastState.compose env53987 (packedSelected [1,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound53987 : packedSelected [1,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env53988 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,3124,137,6194,5172,4112,1025,136,4112,6328,16,6162,160,16,4112,5173,2064,2184,1193,32,36,6192,5157,6673]

theorem envBound53988 : H12AffineFastState.Bounded env53988 := by
  intro p hp
  have h : env53988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53987_53988 : H12AffineEnvironment.transform 13 3124 env53987 = env53988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env53987 == env53988) = true)

theorem identity53988 : scanCanonicalize (H12AffineFastState.compose env53988 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53988 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env53989 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,3124,1,6194,5172,4112,1025,0,4112,6192,16,6162,40,16,4112,5173,2064,2048,1057,32,36,6192,5157,6673]

theorem envBound53989 : H12AffineFastState.Bounded env53989 := by
  intro p hp
  have h : env53989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53988_53989 : H12AffineEnvironment.transform 6 8 env53988 = env53989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53988 == env53989) = true)

def env53990 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,262144,1025,32769,2097152,272512,2101249,21763,8328,17,2157717,2098433,17665,2377112,2102684,2411677,257,21793,46212,2156180]

theorem envBound53990 : H12AffineFastState.Bounded env53990 := by
  intro p hp
  have h : env53990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53968_53990 : H12AffineEnvironment.transform 5 17 env53968 = env53990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53968 == env53990) = true)

theorem identity53990 : scanCanonicalize (H12AffineFastState.compose env53990 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound53990 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env53991 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,262144,1025,32769,58397,272512,62492,21763,8328,17,2184,57628,17665,303493,61825,272512,257,21793,46212,649]

theorem envBound53991 : H12AffineFastState.Bounded env53991 := by
  intro p hp
  have h : env53991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53990_53991 : H12AffineEnvironment.transform 20 58397 env53990 = env53991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env53990 == env53991) = true)

theorem identity53991 : scanCanonicalize (H12AffineFastState.compose env53991 (packedSelected [1,3,5,12,15,17,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound53991 : packedSelected [1,3,5,12,15,17,26,28] rootPS < 2^1333 := by decide +kernel

def env53992 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,32160,1025,32769,58397,21792,62492,21763,8328,17,2184,57628,17665,56357,61825,21792,257,21793,46212,649]

theorem envBound53992 : H12AffineFastState.Bounded env53992 := by
  intro p hp
  have h : env53992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53991_53992 : H12AffineEnvironment.transform 17 32160 env53991 = env53992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env53991 == env53992) = true)

theorem identity53992 : scanCanonicalize (H12AffineFastState.compose env53992 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound53992 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env53993 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21897,263,16401,32160,1025,21896,12692,21792,8597,21763,8328,17,2184,13461,17665,2476,9224,21792,257,21793,24845,649]

theorem envBound53993 : H12AffineFastState.Bounded env53993 := by
  intro p hp
  have h : env53993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53992_53993 : H12AffineEnvironment.transform 14 21897 env53992 = env53993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env53992 == env53993) = true)

theorem identity53993 : scanCanonicalize (H12AffineFastState.compose env53993 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53993 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env53994 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,137,263,5393,10400,1025,136,12692,32,8597,3,8328,17,2184,13461,4097,2476,9224,32,257,33,13325,649]

theorem envBound53994 : H12AffineFastState.Bounded env53994 := by
  intro p hp
  have h : env53994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53993_53994 : H12AffineEnvironment.transform 13 5376 env53993 = env53994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53993 == env53994) = true)

theorem identity53994 : scanCanonicalize (H12AffineFastState.compose env53994 (packedSelected [3,4,5,6,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound53994 : packedSelected [3,4,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env53995 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1212,8192,444,137,263,429,10400,1025,136,9512,32,8597,3,8328,17,2184,8233,1213,2476,9224,32,257,33,8369,649]

theorem envBound53995 : H12AffineFastState.Bounded env53995 := by
  intro p hp
  have h : env53995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53994_53995 : H12AffineEnvironment.transform 11 1212 env53994 = env53995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env53994 == env53995) = true)

theorem identity53995 : scanCanonicalize (H12AffineFastState.compose env53995 (packedSelected [0,2,4,7,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound53995 : packedSelected [0,2,4,7,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env53996 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1212,389,444,137,263,429,2341,1025,136,1197,32,16,3,269,17,2184,428,1213,2476,1421,32,257,33,308,649]

theorem envBound53996 : H12AffineFastState.Bounded env53996 := by
  intro p hp
  have h : env53996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53995_53996 : H12AffineEnvironment.transform 12 389 env53995 = env53996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env53995 == env53996) = true)

theorem identity53996 : scanCanonicalize (H12AffineFastState.compose env53996 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound53996 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53997 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,1212,389,444,137,263,429,1077,1025,136,1197,32,16,3,269,17,1432,428,1213,1212,1421,32,257,33,308,649]

theorem envBound53997 : H12AffineFastState.Bounded env53997 := by
  intro p hp
  have h : env53997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53996_53997 : H12AffineEnvironment.transform 10 1296 env53996 = env53997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env53996 == env53997) = true)

theorem identity53997 : scanCanonicalize (H12AffineFastState.compose env53997 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound53997 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env53998 : List Nat := [2,4,8,16,32,17,128,256,152,1024,1296,1212,389,444,137,263,429,1077,1025,136,1197,32,16,3,269,17,1432,428,1213,1212,1421,32,257,33,308,17]

theorem envBound53998 : H12AffineFastState.Bounded env53998 := by
  intro p hp
  have h : env53998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53997_53998 : H12AffineEnvironment.transform 8 152 env53997 = env53998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env53997 == env53998) = true)

theorem identity53998 : scanCanonicalize (H12AffineFastState.compose env53998 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound53998 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env53999 : List Nat := [2,4,8,16,32,17,128,189,152,1024,1197,1212,56,1,137,186,16,1077,1025,136,1197,32,16,3,176,17,1061,17,1213,1212,1072,32,188,33,137,17]

theorem envBound53999 : H12AffineFastState.Bounded env53999 := by
  intro p hp
  have h : env53999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53998_53999 : H12AffineEnvironment.transform 7 189 env53998 = env53999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env53998 == env53999) = true)

theorem identity53999 : scanCanonicalize (H12AffineFastState.compose env53999 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53999 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54000 : List Nat := [2,4,8,16,32,17,8,53,16,1024,1061,1076,56,1,1,50,16,1077,1025,0,1061,32,16,3,56,17,1061,17,1077,1076,1072,32,52,33,1,17]

theorem envBound54000 : H12AffineFastState.Bounded env54000 := by
  intro p hp
  have h : env54000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53999_54000 : H12AffineEnvironment.transform 6 8 env53999 = env54000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53999 == env54000) = true)

theorem identity54000 : scanCanonicalize (H12AffineFastState.compose env54000 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound54000 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54001 : List Nat := [2,4,8,16,32,17,8,53,16,36,1,16,56,1,1,50,16,17,37,0,1,32,16,3,56,17,1,17,17,16,20,32,52,33,1,17]

theorem envBound54001 : H12AffineFastState.Bounded env54001 := by
  intro p hp
  have h : env54001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54000_54001 : H12AffineEnvironment.transform 9 36 env54000 = env54001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env54000 == env54001) = true)

theorem identity54001 : scanCanonicalize (H12AffineFastState.compose env54001 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54002 : List Nat := [2,4,8,16,11,17,8,30,16,15,1,16,19,1,1,25,16,17,14,0,1,11,16,3,19,17,1,17,17,16,20,11,31,10,1,17]

theorem envBound54002 : H12AffineFastState.Bounded env54002 := by
  intro p hp
  have h : env54002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54001_54002 : H12AffineEnvironment.transform 4 11 env54001 = env54002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54001 == env54002) = true)

def env54003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177099,2098512,17665,2461974,2102684,2411676,257,21793,46212,2175563]

theorem envBound54003 : H12AffineFastState.Bounded env54003 := by
  intro p hp
  have h : env54003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53966_54003 : H12AffineEnvironment.transform 21 272513 env53966 = env54003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53966 == env54003) = true)

theorem identity54003 : scanCanonicalize (H12AffineFastState.compose env54003 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound54003 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115870,272513,120014,98780,8328,64,64725,115150,17665,284040,119042,329730,257,21793,46212,63189]

theorem envBound54004 : H12AffineFastState.Bounded env54004 := by
  intro p hp
  have h : env54004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54003_54004 : H12AffineEnvironment.transform 20 115870 env54003 = env54004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env54003 == env54004) = true)

def env54005 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115870,272513,119966,98700,8328,16,64645,115102,17665,284040,119042,329730,257,21793,46212,63109]

theorem envBound54005 : H12AffineFastState.Bounded env54005 := by
  intro p hp
  have h : env54005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54004_54005 : H12AffineEnvironment.transform 5 16 env54004 = env54005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54004 == env54005) = true)

theorem identity54005 : scanCanonicalize (H12AffineFastState.compose env54005 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound54005 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54006 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,122146,1025,32769,115870,128419,119966,98700,8328,16,64645,115102,17665,100522,119042,54560,257,21793,46212,63109]

theorem envBound54006 : H12AffineFastState.Bounded env54006 := by
  intro p hp
  have h : env54006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54005_54006 : H12AffineEnvironment.transform 17 122146 env54005 = env54006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env54005 == env54006) = true)

theorem identity54006 : scanCanonicalize (H12AffineFastState.compose env54006 (packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound54006 : packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54007 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,76199,1025,29828,77851,65830,73755,95497,8328,16,2048,79131,17665,97327,75143,8613,257,21793,16385,512]

theorem envBound54007 : H12AffineFastState.Bounded env54007 := by
  intro p hp
  have h : env54007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54006_54007 : H12AffineEnvironment.transform 14 29829 env54006 = env54007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env54006 == env54007) = true)

theorem identity54007 : scanCanonicalize (H12AffineFastState.compose env54007 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound54007 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54008 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,398,16537,10281,1025,29828,12693,168,8597,29831,8328,16,2048,13461,17665,32161,9225,8613,257,21793,16385,512]

theorem envBound54008 : H12AffineFastState.Bounded env54008 := by
  intro p hp
  have h : env54008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54007_54008 : H12AffineEnvironment.transform 15 398 env54007 = env54008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env54007 == env54008) = true)

theorem identity54008 : scanCanonicalize (H12AffineFastState.compose env54008 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound54008 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54009 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5124,8321,398,5277,10281,1025,8320,12693,168,8597,8323,8328,16,2048,13461,4357,10661,9225,8613,257,293,5125,512]

theorem envBound54009 : H12AffineFastState.Bounded env54009 := by
  intro p hp
  have h : env54009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54008_54009 : H12AffineEnvironment.transform 13 5124 env54008 = env54009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env54008 == env54009) = true)

theorem identity54009 : scanCanonicalize (H12AffineFastState.compose env54009 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1425) := by decide +kernel

theorem selectedBound54009 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env54010 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1425,5124,1296,398,5277,3512,1025,1297,5124,168,1028,1298,1305,16,2048,4356,4357,3124,408,1076,257,293,5125,512]

theorem envBound54010 : H12AffineFastState.Bounded env54010 := by
  intro p hp
  have h : env54010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54009_54010 : H12AffineEnvironment.transform 12 1425 env54009 = env54010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1425 env54009 == env54010) = true)

theorem identity54010 : scanCanonicalize (H12AffineFastState.compose env54010 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54010 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env54011 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,129,4372,0,398,4493,2216,273,1,4372,168,276,2,9,16,2048,4356,4357,2340,408,292,257,293,4373,512]

theorem envBound54011 : H12AffineFastState.Bounded env54011 := by
  intro p hp
  have h : env54011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54010_54011 : H12AffineEnvironment.transform 9 272 env54010 = env54011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54010 == env54011) = true)

theorem identity54011 : scanCanonicalize (H12AffineFastState.compose env54011 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54011 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54012 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8,4372,0,263,4356,2081,273,1,4372,33,276,2,9,16,2048,4356,4357,2340,273,292,257,293,4373,512]

theorem envBound54012 : H12AffineFastState.Bounded env54012 := by
  intro p hp
  have h : env54012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54011_54012 : H12AffineEnvironment.transform 6 9 env54011 = env54012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54011 == env54012) = true)

theorem identity54012 : scanCanonicalize (H12AffineFastState.compose env54012 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54012 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54013 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,8,4144,0,35,4128,2081,53,1,4144,33,48,2,9,16,2048,4128,4129,2048,53,0,37,1,4145,512]

theorem envBound54013 : H12AffineFastState.Bounded env54013 := by
  intro p hp
  have h : env54013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54012_54013 : H12AffineEnvironment.transform 7 36 env54012 = env54013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54012 == env54013) = true)

theorem identity54013 : scanCanonicalize (H12AffineFastState.compose env54013 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound54013 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54014 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,8,2081,0,35,2097,2081,53,1,2081,33,48,2,9,16,2048,2097,2096,2048,53,0,37,1,2080,512]

theorem envBound54014 : H12AffineFastState.Bounded env54014 := by
  intro p hp
  have h : env54014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54013_54014 : H12AffineEnvironment.transform 11 2065 env54013 = env54014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env54013 == env54014) = true)

theorem identity54014 : scanCanonicalize (H12AffineFastState.compose env54014 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54014 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env54015 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,16,8,32,0,35,48,32,53,1,32,33,48,2,9,16,1,48,49,1,53,0,37,1,33,512]

theorem envBound54015 : H12AffineFastState.Bounded env54015 := by
  intro p hp
  have h : env54015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54014_54015 : H12AffineEnvironment.transform 10 1 env54014 = env54015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54014 == env54015) = true)

theorem identity54015 : scanCanonicalize (H12AffineFastState.compose env54015 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54015 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env54016 : List Nat := [2,4,8,1,32,1,9,36,512,37,1,1,8,32,0,35,33,32,36,1,32,33,33,2,9,1,1,33,32,1,36,0,37,1,33,512]

theorem envBound54016 : H12AffineFastState.Bounded env54016 := by
  intro p hp
  have h : env54016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54015_54016 : H12AffineEnvironment.transform 3 1 env54015 = env54016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54015 == env54016) = true)

theorem identity54016 : scanCanonicalize (H12AffineFastState.compose env54016 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54017 : List Nat := [2,4,8,1,0,1,9,4,512,5,1,1,8,0,0,3,1,0,4,1,0,1,1,2,9,1,1,1,0,1,4,0,5,1,1,512]

theorem envBound54017 : H12AffineFastState.Bounded env54017 := by
  intro p hp
  have h : env54017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54016_54017 : H12AffineEnvironment.transform 4 0 env54016 = env54017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54016 == env54017) = true)

theorem identity54017 : scanCanonicalize (H12AffineFastState.compose env54017 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54017 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54018 : List Nat := [2,0,8,1,0,1,9,0,512,1,1,1,8,0,0,3,1,0,0,1,0,1,1,2,9,1,1,1,0,1,0,0,1,1,1,512]

theorem envBound54018 : H12AffineFastState.Bounded env54018 := by
  intro p hp
  have h : env54018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54017_54018 : H12AffineEnvironment.transform 1 0 env54017 = env54018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54017 == env54018) = true)

theorem identity54018 : scanCanonicalize (H12AffineFastState.compose env54018 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54019 : List Nat := [1,0,8,1,0,1,9,0,512,1,1,1,8,0,0,0,1,0,0,1,0,1,1,1,9,1,1,1,0,1,0,0,1,1,1,512]

theorem envBound54019 : H12AffineFastState.Bounded env54019 := by
  intro p hp
  have h : env54019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54018_54019 : H12AffineEnvironment.transform 0 1 env54018 = env54019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54018 == env54019) = true)

theorem identity54019 : scanCanonicalize (H12AffineFastState.compose env54019 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54019 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54020 : List Nat := [1,0,0,1,0,1,1,0,512,1,1,1,0,0,0,0,1,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,1,1,1,512]

theorem envBound54020 : H12AffineFastState.Bounded env54020 := by
  intro p hp
  have h : env54020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54019_54020 : H12AffineEnvironment.transform 2 0 env54019 = env54020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54019 == env54020) = true)

def env54021 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115870,272513,119967,98701,8328,17,64644,115103,17665,284040,119042,329730,257,21793,46212,63108]

theorem envBound54021 : H12AffineFastState.Bounded env54021 := by
  intro p hp
  have h : env54021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54004_54021 : H12AffineEnvironment.transform 5 17 env54004 = env54021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54004 == env54021) = true)

theorem identity54021 : scanCanonicalize (H12AffineFastState.compose env54021 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound54021 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54022 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,64808,1025,32769,115870,54697,119967,98701,8328,17,64644,115103,17665,43168,119042,128298,257,21793,46212,63108]

theorem envBound54022 : H12AffineFastState.Bounded env54022 := by
  intro p hp
  have h : env54022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54021_54022 : H12AffineEnvironment.transform 17 64808 env54021 = env54022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env54021 == env54022) = true)

theorem identity54022 : scanCanonicalize (H12AffineFastState.compose env54022 (packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound54022 : packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54023 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,64808,1025,32769,4112,54697,17,21763,8328,17,64644,5393,17665,43168,1420,8612,257,21793,46212,63108]

theorem envBound54023 : H12AffineFastState.Bounded env54023 := by
  intro p hp
  have h : env54023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54022_54023 : H12AffineEnvironment.transform 15 54414 env54022 = env54023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env54022 == env54023) = true)

theorem identity54023 : scanCanonicalize (H12AffineFastState.compose env54023 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound54023 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env54024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,21511,5393,32161,1025,136,4112,21792,17,21763,8328,17,31757,5393,17665,10281,1420,8612,257,21793,13325,30221]

theorem envBound54024 : H12AffineFastState.Bounded env54024 := by
  intro p hp
  have h : env54024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54023_54024 : H12AffineEnvironment.transform 14 137 env54023 = env54024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env54023 == env54024) = true)

theorem identity54024 : scanCanonicalize (H12AffineFastState.compose env54024 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54024 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env54025 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,137,21511,5393,23724,1025,136,4112,21792,17,21763,389,17,23808,5393,17665,2340,1420,169,257,21793,5376,22272]

theorem envBound54025 : H12AffineFastState.Bounded env54025 := by
  intro p hp
  have h : env54025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54024_54025 : H12AffineEnvironment.transform 12 269 env54024 = env54025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54024 == env54025) = true)

theorem identity54025 : scanCanonicalize (H12AffineFastState.compose env54025 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54025 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54026 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,137,263,5393,2476,1025,136,4112,32,17,3,389,17,2048,5393,4097,2340,1420,169,257,33,5376,512]

theorem envBound54026 : H12AffineFastState.Bounded env54026 := by
  intro p hp
  have h : env54026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54025_54026 : H12AffineEnvironment.transform 13 5376 env54025 = env54026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54025 == env54026) = true)

theorem identity54026 : scanCanonicalize (H12AffineFastState.compose env54026 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound54026 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54027 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,269,5376,33,263,5393,2308,1025,32,4112,32,17,3,301,17,2048,5393,4097,2340,1316,1,257,33,5376,512]

theorem envBound54027 : H12AffineFastState.Bounded env54027 := by
  intro p hp
  have h : env54027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54026_54027 : H12AffineEnvironment.transform 6 40 env54026 = env54027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env54026 == env54027) = true)

theorem identity54027 : scanCanonicalize (H12AffineFastState.compose env54027 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound54027 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env54028 : List Nat := [2,4,8,16,32,17,40,256,512,1024,1809,4096,269,5376,33,263,5393,1557,1025,32,4112,32,17,3,301,17,1809,5393,4097,1589,1316,1,257,33,5376,512]

theorem envBound54028 : H12AffineFastState.Bounded env54028 := by
  intro p hp
  have h : env54028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54027_54028 : H12AffineEnvironment.transform 10 1809 env54027 = env54028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env54027 == env54028) = true)

theorem identity54028 : scanCanonicalize (H12AffineFastState.compose env54028 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound54028 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54029 : List Nat := [2,4,8,16,32,17,40,256,512,62,815,4096,269,4414,33,263,4399,555,63,32,4112,32,17,3,301,17,815,4399,4097,523,282,1,257,33,4414,512]

theorem envBound54029 : H12AffineFastState.Bounded env54029 := by
  intro p hp
  have h : env54029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54028_54029 : H12AffineEnvironment.transform 9 62 env54028 = env54029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env54028 == env54029) = true)

theorem identity54029 : scanCanonicalize (H12AffineFastState.compose env54029 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound54029 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env54030 : List Nat := [2,4,8,16,32,17,40,63,512,62,528,4096,50,4097,33,56,4112,555,63,32,4112,32,17,3,18,17,528,4112,4097,523,37,1,62,33,4097,512]

theorem envBound54030 : H12AffineFastState.Bounded env54030 := by
  intro p hp
  have h : env54030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54029_54030 : H12AffineEnvironment.transform 7 63 env54029 = env54030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env54029 == env54030) = true)

theorem identity54030 : scanCanonicalize (H12AffineFastState.compose env54030 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54030 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env54031 : List Nat := [2,4,8,11,32,10,40,36,512,37,523,4096,41,4097,33,35,4107,555,36,32,4107,32,10,3,9,10,523,4107,4097,523,37,1,37,33,4097,512]

theorem envBound54031 : H12AffineFastState.Bounded env54031 := by
  intro p hp
  have h : env54031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54030_54031 : H12AffineEnvironment.transform 3 11 env54030 = env54031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54030 == env54031) = true)

def env54032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623434,2098513,17664,2461975,2102684,6349852,257,21793,46212,2175563]

theorem envBound54032 : H12AffineFastState.Bounded env54032 := by
  intro p hp
  have h : env54032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53965_54032 : H12AffineEnvironment.transform 22 2101329 env53965 = env54032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env53965 == env54032) = true)

def env54033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177098,2098513,17664,2461975,2102684,2411676,257,21793,46212,2175563]

theorem envBound54033 : H12AffineFastState.Bounded env54033 := by
  intro p hp
  have h : env54033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54032_54033 : H12AffineEnvironment.transform 21 272512 env54032 = env54033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54032 == env54033) = true)

theorem identity54033 : scanCanonicalize (H12AffineFastState.compose env54033 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54033 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,2097152,272512,2101329,41431,8328,64,2103360,2098513,17664,2404637,2102684,2411676,257,21793,46212,2101825]

theorem envBound54034 : H12AffineFastState.Bounded env54034 := by
  intro p hp
  have h : env54034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54033_54034 : H12AffineEnvironment.transform 15 8202 env54033 = env54034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54033 == env54034) = true)

theorem identity54034 : scanCanonicalize (H12AffineFastState.compose env54034 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309472) := by decide +kernel

theorem selectedBound54034 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,309472,272512,305329,41431,8328,64,303264,310705,17664,2557,306556,29820,257,21793,46212,305825]

theorem envBound54035 : H12AffineFastState.Bounded env54035 := by
  intro p hp
  have h : env54035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54034_54035 : H12AffineEnvironment.transform 20 309472 env54034 = env54035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309472 env54034 == env54035) = true)

theorem identity54035 : scanCanonicalize (H12AffineFastState.compose env54035 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54035 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env54036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,262144,1025,32769,301501,264669,297452,32906,469,64,295421,302316,17664,2557,298017,21793,257,21793,38361,297980]

theorem envBound54036 : H12AffineFastState.Bounded env54036 := by
  intro p hp
  have h : env54036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54035_54036 : H12AffineEnvironment.transform 12 349 env54035 = env54036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54035 == env54036) = true)

theorem identity54036 : scanCanonicalize (H12AffineFastState.compose env54036 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54036 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,32768,343,5393,262144,1025,32769,301501,264669,297452,32906,469,64,295421,302316,4097,2557,298017,32,257,32,38361,297980]

theorem envBound54037 : H12AffineFastState.Bounded env54037 := by
  intro p hp
  have h : env54037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54036_54037 : H12AffineEnvironment.transform 13 5377 env54036 = env54037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54036 == env54037) = true)

theorem identity54037 : scanCanonicalize (H12AffineFastState.compose env54037 (packedSelected [0,2,7,9,11,16,17,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound54037 : packedSelected [0,2,7,9,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env54038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,373,343,5393,262144,1025,372,268488,264669,264345,511,469,64,262280,269721,4097,2557,265556,32,257,32,5292,264841]

theorem envBound54038 : H12AffineFastState.Bounded env54038 := by
  intro p hp
  have h : env54038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54037_54038 : H12AffineEnvironment.transform 14 373 env54037 = env54038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env54037 == env54038) = true)

theorem identity54038 : scanCanonicalize (H12AffineFastState.compose env54038 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54038 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env54039 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5236,0,34,5220,262144,1025,1,268488,264360,264345,138,160,64,262280,269548,4097,2184,265249,32,116,32,5292,264841]

theorem envBound54039 : H12AffineFastState.Bounded env54039 := by
  intro p hp
  have h : env54039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54038_54039 : H12AffineEnvironment.transform 7 117 env54038 = env54039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54038 == env54039) = true)

theorem identity54039 : scanCanonicalize (H12AffineFastState.compose env54039 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54039 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54040 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,0,34,5172,262144,1025,1,268440,264360,264345,138,160,16,262280,269500,4097,2184,265249,32,36,32,5292,264841]

theorem envBound54040 : H12AffineFastState.Bounded env54040 := by
  intro p hp
  have h : env54040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54039_54040 : H12AffineEnvironment.transform 5 16 env54039 = env54040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54039 == env54040) = true)

theorem identity54040 : scanCanonicalize (H12AffineFastState.compose env54040 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 137) := by decide +kernel

theorem selectedBound54040 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env54041 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,0,34,5172,137,1025,1,6161,2081,2064,138,160,16,1,7221,4097,2184,3240,32,36,32,5292,2560]

theorem envBound54041 : H12AffineFastState.Bounded env54041 := by
  intro p hp
  have h : env54041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54040_54041 : H12AffineEnvironment.transform 17 137 env54040 = env54041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137 env54040 == env54041) = true)

theorem identity54041 : scanCanonicalize (H12AffineFastState.compose env54041 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound54041 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env54042 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1180,4096,40,5156,0,34,5172,137,1025,1,5261,1213,1164,138,160,16,1,4265,4097,1044,52,32,36,32,5292,1692]

theorem envBound54042 : H12AffineFastState.Bounded env54042 := by
  intro p hp
  have h : env54042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54041_54042 : H12AffineEnvironment.transform 10 1180 env54041 = env54042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env54041 == env54042) = true)

theorem identity54042 : scanCanonicalize (H12AffineFastState.compose env54042 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound54042 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env54043 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1180,1181,40,185,0,34,169,137,1025,1,16,1213,1164,138,160,16,1,1076,1180,1044,52,32,36,32,49,1692]

theorem envBound54043 : H12AffineFastState.Bounded env54043 := by
  intro p hp
  have h : env54043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54042_54043 : H12AffineEnvironment.transform 11 1181 env54042 = env54043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env54042 == env54043) = true)

theorem identity54043 : scanCanonicalize (H12AffineFastState.compose env54043 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54043 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env54044 : List Nat := [2,4,8,0,32,0,128,37,512,1024,1164,1165,40,169,0,34,169,137,1025,1,0,1197,1164,138,160,0,1,1060,1164,1028,36,32,36,32,33,1676]

theorem envBound54044 : H12AffineFastState.Bounded env54044 := by
  intro p hp
  have h : env54044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54043_54044 : H12AffineEnvironment.transform 3 0 env54043 = env54044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54043 == env54044) = true)

theorem identity54044 : scanCanonicalize (H12AffineFastState.compose env54044 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound54044 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env54045 : List Nat := [2,4,8,0,32,0,128,37,512,37,169,168,40,169,0,34,169,137,36,1,0,136,169,138,160,0,1,1,169,33,36,32,36,32,33,681]

theorem envBound54045 : H12AffineFastState.Bounded env54045 := by
  intro p hp
  have h : env54045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54044_54045 : H12AffineEnvironment.transform 9 37 env54044 = env54045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env54044 == env54045) = true)

theorem identity54045 : scanCanonicalize (H12AffineFastState.compose env54045 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54045 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env54046 : List Nat := [2,4,8,0,32,0,8,37,512,37,33,32,40,33,0,34,33,1,36,1,0,0,33,2,40,0,1,1,33,33,36,32,36,32,33,545]

theorem envBound54046 : H12AffineFastState.Bounded env54046 := by
  intro p hp
  have h : env54046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54045_54046 : H12AffineEnvironment.transform 6 8 env54045 = env54046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54045 == env54046) = true)

theorem identity54046 : scanCanonicalize (H12AffineFastState.compose env54046 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54046 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54047 : List Nat := [2,4,8,0,0,0,8,5,512,5,1,0,8,1,0,2,1,1,4,1,0,0,1,2,8,0,1,1,1,1,4,0,4,0,1,513]

theorem envBound54047 : H12AffineFastState.Bounded env54047 := by
  intro p hp
  have h : env54047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54046_54047 : H12AffineEnvironment.transform 4 0 env54046 = env54047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54046 == env54047) = true)

theorem identity54047 : scanCanonicalize (H12AffineFastState.compose env54047 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound54047 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54048 : List Nat := [2,1,8,0,0,0,8,0,512,0,1,0,8,1,0,2,1,1,1,1,0,0,1,2,8,0,1,1,1,1,1,0,1,0,1,513]

theorem envBound54048 : H12AffineFastState.Bounded env54048 := by
  intro p hp
  have h : env54048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54047_54048 : H12AffineEnvironment.transform 1 1 env54047 = env54048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env54047 == env54048) = true)

theorem identity54048 : scanCanonicalize (H12AffineFastState.compose env54048 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound54048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54049 : List Nat := [2,1,8,0,0,0,8,0,2,0,1,0,8,1,0,2,1,1,1,1,0,0,1,2,8,0,1,1,1,1,1,0,1,0,1,3]

theorem envBound54049 : H12AffineFastState.Bounded env54049 := by
  intro p hp
  have h : env54049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54048_54049 : H12AffineEnvironment.transform 8 2 env54048 = env54049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env54048 == env54049) = true)

theorem identity54049 : scanCanonicalize (H12AffineFastState.compose env54049 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54049 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54050 : List Nat := [2,1,2,0,0,0,2,0,2,0,1,0,2,1,0,2,1,1,1,1,0,0,1,2,2,0,1,1,1,1,1,0,1,0,1,3]

theorem envBound54050 : H12AffineFastState.Bounded env54050 := by
  intro p hp
  have h : env54050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54049_54050 : H12AffineEnvironment.transform 2 2 env54049 = env54050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54049 == env54050) = true)

def env54051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177099,2098513,17664,2461975,2102684,2411677,257,21793,46212,2175563]

theorem envBound54051 : H12AffineFastState.Bounded env54051 := by
  intro p hp
  have h : env54051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54032_54051 : H12AffineEnvironment.transform 21 272513 env54032 = env54051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54032 == env54051) = true)

theorem identity54051 : scanCanonicalize (H12AffineFastState.compose env54051 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound54051 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272513,73755,98781,8328,64,2049,79131,17664,303453,75222,392407,257,21793,46212,513]

theorem envBound54052 : H12AffineFastState.Bounded env54052 := by
  intro p hp
  have h : env54052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54051_54052 : H12AffineEnvironment.transform 20 77898 env54051 = env54052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env54051 == env54052) = true)

theorem identity54052 : scanCanonicalize (H12AffineFastState.compose env54052 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound54052 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env54053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,67618,1025,32769,77898,73891,73755,98781,8328,64,2049,79131,17664,108927,75222,62709,257,21793,46212,513]

theorem envBound54053 : H12AffineFastState.Bounded env54053 := by
  intro p hp
  have h : env54053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54052_54053 : H12AffineEnvironment.transform 17 67618 env54052 = env54053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env54052 == env54053) = true)

theorem identity54053 : scanCanonicalize (H12AffineFastState.compose env54053 (packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54053 : packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env54054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,82247,67618,1025,32769,69910,66047,65863,98781,468,64,2049,70727,17664,100387,66698,54697,257,21793,38360,513]

theorem envBound54054 : H12AffineFastState.Bounded env54054 := by
  intro p hp
  have h : env54054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54053_54054 : H12AffineEnvironment.transform 12 348 env54053 = env54054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54053 == env54054) = true)

def env54055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82247,67618,1025,32769,69910,65911,65863,98645,348,64,2049,70727,17664,100387,66562,54561,257,21793,38224,513]

theorem envBound54055 : H12AffineFastState.Bounded env54055 := by
  intro p hp
  have h : env54055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54054_54055 : H12AffineEnvironment.transform 6 8 env54054 = env54055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54054 == env54055) = true)

theorem identity54055 : scanCanonicalize (H12AffineFastState.compose env54055 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound54055 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env54056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,21510,5441,23588,1025,32769,17680,21873,21825,54611,348,64,2049,16449,17664,56357,20484,54561,257,21793,38224,513]

theorem envBound54056 : H12AffineFastState.Bounded env54056 := by
  intro p hp
  have h : env54056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54055_54056 : H12AffineEnvironment.transform 15 21510 env54055 = env54056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env54055 == env54056) = true)

theorem identity54056 : scanCanonicalize (H12AffineFastState.compose env54056 (packedSelected [1,2,6,8,10,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound54056 : packedSelected [1,2,6,8,10,14,15] rootPS < 2^1333 := by decide +kernel

def env54057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,293,32768,5411,5441,7425,1025,32769,1077,5204,5220,38006,348,64,2049,356,1061,40192,4385,37892,257,5124,38224,513]

theorem envBound54057 : H12AffineFastState.Bounded env54057 := by
  intro p hp
  have h : env54057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54056_54057 : H12AffineEnvironment.transform 13 293 env54056 = env54057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env54056 == env54057) = true)

theorem identity54057 : scanCanonicalize (H12AffineFastState.compose env54057 (packedSelected [1,2,6,8,10,11,12,23] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound54057 : packedSelected [1,2,6,8,10,11,12,23] rootPS < 2^1333 := by decide +kernel

def env54058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,348,293,32768,342,308,2420,1025,32769,1077,33,17,32771,348,64,2049,356,1061,35189,1364,32881,257,113,33061,513]

theorem envBound54058 : H12AffineFastState.Bounded env54058 := by
  intro p hp
  have h : env54058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54057_54058 : H12AffineEnvironment.transform 11 1141 env54057 = env54058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env54057 == env54058) = true)

theorem identity54058 : scanCanonicalize (H12AffineFastState.compose env54058 (packedSelected [4,7] rootPS)) = affineNative (2^(14+1) ^^^ 3636) := by decide +kernel

theorem selectedBound54058 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env54059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,348,293,3636,342,308,2420,1025,3637,1077,33,17,3639,348,64,2049,356,1061,1857,1364,3653,257,113,3857,513]

theorem envBound54059 : H12AffineFastState.Bounded env54059 := by
  intro p hp
  have h : env54059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54058_54059 : H12AffineEnvironment.transform 14 3636 env54058 = env54059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3636 env54058 == env54059) = true)

theorem identity54059 : scanCanonicalize (H12AffineFastState.compose env54059 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1621) := by decide +kernel

theorem selectedBound54059 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env54060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1621,1141,348,293,97,342,308,1825,1025,96,1077,33,17,98,348,64,1620,356,1061,1857,1364,16,257,113,324,513]

theorem envBound54060 : H12AffineFastState.Bounded env54060 := by
  intro p hp
  have h : env54060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54059_54060 : H12AffineEnvironment.transform 10 1621 env54059 = env54060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1621 env54059 == env54060) = true)

theorem identity54060 : scanCanonicalize (H12AffineFastState.compose env54060 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound54060 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env54061 : List Nat := [2,4,8,16,32,32,8,256,512,1024,1589,1045,316,293,1,310,308,1825,1025,0,1077,33,17,2,316,32,1588,260,1061,1825,1332,16,257,17,292,513]

theorem envBound54061 : H12AffineFastState.Bounded env54061 := by
  intro p hp
  have h : env54061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54060_54061 : H12AffineEnvironment.transform 5 32 env54060 = env54061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env54060 == env54061) = true)

theorem identity54061 : scanCanonicalize (H12AffineFastState.compose env54061 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54062 : List Nat := [2,4,8,16,1,1,8,256,512,1024,1556,1045,285,260,1,279,277,1792,1025,0,1044,0,17,2,285,1,1557,260,1028,1792,1301,16,257,17,261,513]

theorem envBound54062 : H12AffineFastState.Bounded env54062 := by
  intro p hp
  have h : env54062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54061_54062 : H12AffineEnvironment.transform 4 1 env54061 = env54062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54061 == env54062) = true)

theorem identity54062 : scanCanonicalize (H12AffineFastState.compose env54062 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound54062 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54063 : List Nat := [2,4,8,16,1,1,8,256,512,532,0,513,285,260,1,279,277,276,533,0,512,0,17,2,285,1,1,260,528,276,769,16,257,17,261,513]

theorem envBound54063 : H12AffineFastState.Bounded env54063 := by
  intro p hp
  have h : env54063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54062_54063 : H12AffineEnvironment.transform 9 532 env54062 = env54063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env54062 == env54063) = true)

theorem identity54063 : scanCanonicalize (H12AffineFastState.compose env54063 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound54063 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54064 : List Nat := [2,4,8,16,1,1,8,256,276,256,0,277,285,260,1,279,277,276,257,0,276,0,17,2,285,1,1,260,260,276,21,16,257,17,261,277]

theorem envBound54064 : H12AffineFastState.Bounded env54064 := by
  intro p hp
  have h : env54064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54063_54064 : H12AffineEnvironment.transform 8 276 env54063 = env54064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54063 == env54064) = true)

def env54065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,67618,1025,32769,69910,65910,65863,98644,349,64,2049,70727,17664,100387,66563,54560,257,21793,38225,513]

theorem envBound54065 : H12AffineFastState.Bounded env54065 := by
  intro p hp
  have h : env54065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54054_54065 : H12AffineEnvironment.transform 6 9 env54054 = env54065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54054 == env54065) = true)

theorem identity54065 : scanCanonicalize (H12AffineFastState.compose env54065 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound54065 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33111,49168,35189,1025,32769,36929,32801,32784,3,349,64,2049,38160,17664,2420,34132,54560,257,21793,38225,513]

theorem envBound54066 : H12AffineFastState.Bounded env54066 := by
  intro p hp
  have h : env54066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54065_54066 : H12AffineEnvironment.transform 15 33111 env54065 = env54066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env54065 == env54066) = true)

theorem identity54066 : scanCanonicalize (H12AffineFastState.compose env54066 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54066 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,343,16400,2421,1025,1,4161,33,16,3,349,64,2049,5392,17664,2420,1364,21792,257,21793,5457,513]

theorem envBound54067 : H12AffineFastState.Bounded env54067 := by
  intro p hp
  have h : env54067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54066_54067 : H12AffineEnvironment.transform 14 0 env54066 = env54067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54066 == env54067) = true)

theorem identity54067 : scanCanonicalize (H12AffineFastState.compose env54067 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54067 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54068 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,262,16400,2340,1025,1,4112,33,16,3,268,17,2049,5392,17664,2341,1285,21792,257,21793,5376,513]

theorem envBound54068 : H12AffineFastState.Bounded env54068 := by
  intro p hp
  have h : env54068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54067_54068 : H12AffineEnvironment.transform 5 17 env54067 = env54068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54067 == env54068) = true)

theorem identity54068 : scanCanonicalize (H12AffineFastState.compose env54068 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54068 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54069 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,0,262,16400,2340,273,1,4112,33,16,3,268,17,2049,4096,16400,2341,21,20528,257,20529,4112,513]

theorem envBound54069 : H12AffineFastState.Bounded env54069 := by
  intro p hp
  have h : env54069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54068_54069 : H12AffineEnvironment.transform 9 272 env54068 = env54069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54068 == env54069) = true)

theorem identity54069 : scanCanonicalize (H12AffineFastState.compose env54069 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound54069 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54070 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,4113,0,262,4097,2340,273,1,4112,33,16,3,268,17,2049,4096,4097,2341,21,33,257,32,4112,513]

theorem envBound54070 : H12AffineFastState.Bounded env54070 := by
  intro p hp
  have h : env54070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54069_54070 : H12AffineEnvironment.transform 13 4113 env54069 = env54070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env54069 == env54070) = true)

theorem identity54070 : scanCanonicalize (H12AffineFastState.compose env54070 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54070 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54071 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4113,0,34,4097,2048,53,1,4112,33,16,3,40,17,2049,4096,4097,2049,21,33,37,32,4112,513]

theorem envBound54071 : H12AffineFastState.Bounded env54071 := by
  intro p hp
  have h : env54071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54070_54071 : H12AffineEnvironment.transform 7 36 env54070 = env54071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54070 == env54071) = true)

theorem identity54071 : scanCanonicalize (H12AffineFastState.compose env54071 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54072 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,8,4113,0,3,4097,2048,20,1,4112,0,16,3,9,17,2049,4096,4097,2049,21,0,4,1,4112,513]

theorem envBound54072 : H12AffineFastState.Bounded env54072 := by
  intro p hp
  have h : env54072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54071_54072 : H12AffineEnvironment.transform 4 1 env54071 = env54072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54071 == env54072) = true)

theorem identity54072 : scanCanonicalize (H12AffineFastState.compose env54072 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound54072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54073 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,512,8,529,0,3,513,2048,20,1,528,0,16,3,9,17,2049,512,513,2049,21,0,4,1,528,513]

theorem envBound54073 : H12AffineFastState.Bounded env54073 := by
  intro p hp
  have h : env54073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54072_54073 : H12AffineEnvironment.transform 11 512 env54072 = env54073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env54072 == env54073) = true)

theorem identity54073 : scanCanonicalize (H12AffineFastState.compose env54073 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound54073 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54074 : List Nat := [2,4,8,16,1,17,9,5,512,21,528,512,8,529,0,3,513,528,20,1,528,0,16,3,9,17,529,512,513,529,21,0,4,1,528,513]

theorem envBound54074 : H12AffineFastState.Bounded env54074 := by
  intro p hp
  have h : env54074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54073_54074 : H12AffineEnvironment.transform 10 528 env54073 = env54074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env54073 == env54074) = true)

def env54075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623435,8393985,10507601,8749382,2102685,12645452,257,21792,46213,2175562]

theorem envBound54075 : H12AffineFastState.Bounded env54075 := by
  intro p hp
  have h : env54075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53964_54075 : H12AffineEnvironment.transform 23 10588557 env53964 = env54075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env53964 == env54075) = true)

def env54076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623435,2098513,17665,2461974,2102685,6349852,257,21792,46213,2175562]

theorem envBound54076 : H12AffineFastState.Bounded env54076 := by
  intro p hp
  have h : env54076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54075_54076 : H12AffineEnvironment.transform 22 2101328 env54075 = env54076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env54075 == env54076) = true)

def env54077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177099,2098513,17665,2461974,2102685,2411676,257,21792,46213,2175562]

theorem envBound54077 : H12AffineFastState.Bounded env54077 := by
  intro p hp
  have h : env54077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54076_54077 : H12AffineEnvironment.transform 21 272512 env54076 = env54077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54076 == env54077) = true)

theorem identity54077 : scanCanonicalize (H12AffineFastState.compose env54077 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound54077 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,272512,17,98781,8328,64,75786,5392,17665,360791,1500,318685,257,21792,46213,74251]

theorem envBound54078 : H12AffineFastState.Bounded env54078 := by
  intro p hp
  have h : env54078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54077_54078 : H12AffineEnvironment.transform 20 4161 env54077 = env54078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54077 == env54078) = true)

theorem identity54078 : scanCanonicalize (H12AffineFastState.compose env54078 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54078 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,4161,272512,17,41431,8328,64,2048,5392,17665,303453,1500,318685,257,21792,46213,513]

theorem envBound54079 : H12AffineFastState.Bounded env54079 := by
  intro p hp
  have h : env54079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54078_54079 : H12AffineEnvironment.transform 15 8202 env54078 = env54079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54078 == env54079) = true)

theorem identity54079 : scanCanonicalize (H12AffineFastState.compose env54079 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound54079 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env54080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,35325,1025,32769,4161,41341,17,41431,8328,64,2048,5392,17665,10400,1500,21792,257,21792,46213,513]

theorem envBound54080 : H12AffineFastState.Bounded env54080 := by
  intro p hp
  have h : env54080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54079_54080 : H12AffineEnvironment.transform 17 35325 env54079 = env54080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env54079 == env54080) = true)

theorem identity54080 : scanCanonicalize (H12AffineFastState.compose env54080 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54080 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,35325,1025,32769,4161,32800,17,32906,469,64,2048,5392,17665,2557,1500,21792,257,21792,38360,513]

theorem envBound54081 : H12AffineFastState.Bounded env54081 := by
  intro p hp
  have h : env54081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54080_54081 : H12AffineEnvironment.transform 12 349 env54080 = env54081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54080 == env54081) = true)

theorem identity54081 : scanCanonicalize (H12AffineFastState.compose env54081 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54081 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,32768,343,5392,35325,1025,32769,4161,32800,17,32906,469,64,2048,5392,4097,2557,1500,32,257,32,38360,513]

theorem envBound54082 : H12AffineFastState.Bounded env54082 := by
  intro p hp
  have h : env54082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54081_54082 : H12AffineEnvironment.transform 13 5376 env54081 = env54082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54081 == env54082) = true)

theorem identity54082 : scanCanonicalize (H12AffineFastState.compose env54082 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound54082 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env54083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,508,343,5392,2049,1025,509,4161,476,17,374,469,64,2048,5392,4097,2557,1500,32,257,32,5156,513]

theorem envBound54083 : H12AffineFastState.Bounded env54083 := by
  intro p hp
  have h : env54083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54082_54083 : H12AffineEnvironment.transform 14 508 env54082 = env54083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env54082 == env54083) = true)

theorem identity54083 : scanCanonicalize (H12AffineFastState.compose env54083 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound54083 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54084 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,0,171,5356,2049,1025,1,4161,32,17,138,41,64,2048,5356,4097,2049,1056,32,253,32,5156,513]

theorem envBound54084 : H12AffineFastState.Bounded env54084 := by
  intro p hp
  have h : env54084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54083_54084 : H12AffineEnvironment.transform 7 252 env54083 = env54084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env54083 == env54084) = true)

theorem identity54084 : scanCanonicalize (H12AffineFastState.compose env54084 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound54084 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54085 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,0,161,1276,0,171,1260,2049,1025,1,65,32,17,138,41,64,2048,1260,1,2049,1056,32,253,32,1060,513]

theorem envBound54085 : H12AffineFastState.Bounded env54085 := by
  intro p hp
  have h : env54085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54084_54085 : H12AffineEnvironment.transform 11 0 env54084 = env54085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env54084 == env54085) = true)

theorem identity54085 : scanCanonicalize (H12AffineFastState.compose env54085 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound54085 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54086 : List Nat := [2,4,8,16,32,64,128,252,512,1024,217,0,161,1276,0,171,1260,216,1025,1,65,32,17,138,41,64,217,1260,1,216,1056,32,253,32,1060,513]

theorem envBound54086 : H12AffineFastState.Bounded env54086 := by
  intro p hp
  have h : env54086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54085_54086 : H12AffineEnvironment.transform 10 217 env54085 = env54086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env54085 == env54086) = true)

theorem identity54086 : scanCanonicalize (H12AffineFastState.compose env54086 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound54086 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env54087 : List Nat := [2,4,8,16,32,64,128,252,512,62,217,0,161,194,0,171,210,216,63,1,65,32,17,138,41,64,217,210,1,216,30,32,253,32,26,513]

theorem envBound54087 : H12AffineFastState.Bounded env54087 := by
  intro p hp
  have h : env54087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54086_54087 : H12AffineEnvironment.transform 9 62 env54086 = env54087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env54086 == env54087) = true)

theorem identity54087 : scanCanonicalize (H12AffineFastState.compose env54087 (packedSelected [1,2,3,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound54087 : packedSelected [1,2,3,11,12] rootPS < 2^1333 := by decide +kernel

def env54088 : List Nat := [2,4,8,16,32,64,88,36,512,62,1,0,121,26,0,115,10,0,63,1,65,32,17,82,41,64,1,10,1,0,30,32,37,32,26,513]

theorem envBound54088 : H12AffineFastState.Bounded env54088 := by
  intro p hp
  have h : env54088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54087_54088 : H12AffineEnvironment.transform 6 88 env54087 = env54088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54087 == env54088) = true)

theorem identity54088 : scanCanonicalize (H12AffineFastState.compose env54088 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54089 : List Nat := [2,4,8,16,32,0,24,36,512,62,1,0,57,26,0,51,10,0,63,1,1,32,17,18,41,0,1,10,1,0,30,32,37,32,26,513]

theorem envBound54089 : H12AffineFastState.Bounded env54089 := by
  intro p hp
  have h : env54089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54088_54089 : H12AffineEnvironment.transform 5 0 env54088 = env54089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54088 == env54089) = true)

theorem identity54089 : scanCanonicalize (H12AffineFastState.compose env54089 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54089 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54090 : List Nat := [2,4,8,16,17,0,24,21,512,15,1,0,8,26,0,2,10,0,14,1,1,17,17,18,24,0,1,10,1,0,30,17,20,17,26,513]

theorem envBound54090 : H12AffineFastState.Bounded env54090 := by
  intro p hp
  have h : env54090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54089_54090 : H12AffineEnvironment.transform 4 17 env54089 = env54090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54089 == env54090) = true)

theorem identity54090 : scanCanonicalize (H12AffineFastState.compose env54090 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54090 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54091 : List Nat := [2,4,8,11,10,0,3,14,512,15,1,0,8,1,0,2,10,0,14,1,1,10,10,9,3,0,1,10,1,0,5,10,15,10,1,513]

theorem envBound54091 : H12AffineFastState.Bounded env54091 := by
  intro p hp
  have h : env54091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54090_54091 : H12AffineEnvironment.transform 3 11 env54090 = env54091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54090 == env54091) = true)

theorem identity54091 : scanCanonicalize (H12AffineFastState.compose env54091 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54091 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54092 : List Nat := [1,4,8,8,9,0,0,13,512,12,1,0,8,1,0,1,9,0,13,1,1,9,9,9,0,0,1,9,1,0,5,9,12,9,1,513]

theorem envBound54092 : H12AffineFastState.Bounded env54092 := by
  intro p hp
  have h : env54092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54091_54092 : H12AffineEnvironment.transform 0 1 env54091 = env54092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54091 == env54092) = true)

theorem identity54092 : scanCanonicalize (H12AffineFastState.compose env54092 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54092 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54093 : List Nat := [1,4,0,0,1,0,0,5,512,4,1,0,0,1,0,1,1,0,5,1,1,1,1,1,0,0,1,1,1,0,5,1,4,1,1,513]

theorem envBound54093 : H12AffineFastState.Bounded env54093 := by
  intro p hp
  have h : env54093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54092_54093 : H12AffineEnvironment.transform 2 0 env54092 = env54093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54092 == env54093) = true)

theorem identity54093 : scanCanonicalize (H12AffineFastState.compose env54093 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound54093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54094 : List Nat := [1,4,0,0,1,0,0,5,5,4,1,0,0,1,0,1,1,0,5,1,1,1,1,1,0,0,1,1,1,0,5,1,4,1,1,4]

theorem envBound54094 : H12AffineFastState.Bounded env54094 := by
  intro p hp
  have h : env54094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54093_54094 : H12AffineEnvironment.transform 8 5 env54093 = env54094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env54093 == env54094) = true)

def env54095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177098,2098513,17665,2461974,2102685,2411677,257,21792,46213,2175562]

theorem envBound54095 : H12AffineFastState.Bounded env54095 := by
  intro p hp
  have h : env54095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54076_54095 : H12AffineEnvironment.transform 21 272513 env54076 = env54095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54076 == env54095) = true)

def env54096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272393,2101328,98645,8192,64,2177098,2098513,17665,2461974,2102549,2411541,257,21792,46093,2175562]

theorem envBound54096 : H12AffineFastState.Bounded env54096 := by
  intro p hp
  have h : env54096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54095_54096 : H12AffineEnvironment.transform 6 8 env54095 = env54096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54095 == env54096) = true)

def env54097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,272393,16,98645,8192,64,75786,5393,17665,360790,1365,318549,257,21792,46093,74250]

theorem envBound54097 : H12AffineFastState.Bounded env54097 := by
  intro p hp
  have h : env54097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54096_54097 : H12AffineEnvironment.transform 20 4160 env54096 = env54097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54096 == env54097) = true)

theorem identity54097 : scanCanonicalize (H12AffineFastState.compose env54097 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound54097 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,56356,1025,32769,4160,62509,16,98645,8192,64,75786,5393,17665,89458,1365,113,257,21792,46093,74250]

theorem envBound54098 : H12AffineFastState.Bounded env54098 := by
  intro p hp
  have h : env54098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54097_54098 : H12AffineEnvironment.transform 17 56356 env54097 = env54098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env54097 == env54098) = true)

theorem identity54098 : scanCanonicalize (H12AffineFastState.compose env54098 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound54098 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62810,46109,56356,1025,32769,4160,62509,16,29711,8192,64,56656,5393,17665,43048,1365,113,257,21792,46093,55120]

theorem envBound54099 : H12AffineFastState.Bounded env54099 := by
  intro p hp
  have h : env54099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54098_54099 : H12AffineEnvironment.transform 15 62810 env54098 = env54099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env54098 == env54099) = true)

theorem identity54099 : scanCanonicalize (H12AffineFastState.compose env54099 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound54099 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env54100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,8203,24908,2421,1025,21840,4160,8572,16,29711,8192,64,2049,5393,17665,32121,1365,113,257,21792,24924,513]

theorem envBound54100 : H12AffineFastState.Bounded env54100 := by
  intro p hp
  have h : env54100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54099_54100 : H12AffineEnvironment.transform 14 21841 env54099 = env54100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env54099 == env54100) = true)

theorem identity54100 : scanCanonicalize (H12AffineFastState.compose env54100 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54100 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21841,343,16400,2421,1025,21840,4160,32,16,21843,348,64,2049,5393,17665,23589,1365,113,257,21792,16384,513]

theorem envBound54101 : H12AffineFastState.Bounded env54101 := by
  intro p hp
  have h : env54101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54100_54101 : H12AffineEnvironment.transform 12 348 env54100 = env54101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54100 == env54101) = true)

theorem identity54101 : scanCanonicalize (H12AffineFastState.compose env54101 (packedSelected [3,4,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 3172) := by decide +kernel

theorem selectedBound54101 : packedSelected [3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env54102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,3172,6453,343,3188,2421,1025,6452,4160,32,16,6455,348,64,2049,5393,2405,4161,1365,113,257,6468,3172,513]

theorem envBound54102 : H12AffineFastState.Bounded env54102 := by
  intro p hp
  have h : env54102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54101_54102 : H12AffineEnvironment.transform 13 3172 env54101 = env54102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3172 env54101 == env54102) = true)

theorem identity54102 : scanCanonicalize (H12AffineFastState.compose env54102 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54102 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54103 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,348,2129,6453,343,2113,2421,52,6452,4160,32,16,6455,348,64,2049,4388,2405,4161,352,113,257,6468,2129,513]

theorem envBound54103 : H12AffineFastState.Bounded env54103 := by
  intro p hp
  have h : env54103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54102_54103 : H12AffineEnvironment.transform 9 53 env54102 = env54103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54102 == env54103) = true)

theorem identity54103 : scanCanonicalize (H12AffineFastState.compose env54103 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54103 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54104 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,41,2129,6208,34,2113,2048,52,6209,4160,32,16,6210,41,64,2049,4177,2064,4161,21,113,116,6193,2129,513]

theorem envBound54104 : H12AffineFastState.Bounded env54104 := by
  intro p hp
  have h : env54104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54103_54104 : H12AffineEnvironment.transform 7 117 env54103 = env54104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54103 == env54104) = true)

theorem identity54104 : scanCanonicalize (H12AffineFastState.compose env54104 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound54104 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env54105 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,64,41,2129,2048,34,2113,2048,52,2049,0,32,16,2050,41,64,2049,17,2064,1,21,113,116,2161,2129,513]

theorem envBound54105 : H12AffineFastState.Bounded env54105 := by
  intro p hp
  have h : env54105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54104_54105 : H12AffineEnvironment.transform 11 64 env54104 = env54105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env54104 == env54105) = true)

theorem identity54105 : scanCanonicalize (H12AffineFastState.compose env54105 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54105 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54106 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,16,41,2049,2048,34,2065,2048,52,2049,0,32,16,2050,41,16,2049,17,2064,1,21,33,36,2081,2049,513]

theorem envBound54106 : H12AffineFastState.Bounded env54106 := by
  intro p hp
  have h : env54106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54105_54106 : H12AffineEnvironment.transform 5 16 env54105 = env54106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54105 == env54106) = true)

theorem identity54106 : scanCanonicalize (H12AffineFastState.compose env54106 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54106 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54107 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,0,1,34,16,1,52,0,0,32,16,3,41,16,0,17,17,1,21,33,36,32,0,513]

theorem envBound54107 : H12AffineFastState.Bounded env54107 := by
  intro p hp
  have h : env54107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54106_54107 : H12AffineEnvironment.transform 10 1 env54106 = env54107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54106 == env54107) = true)

theorem identity54107 : scanCanonicalize (H12AffineFastState.compose env54107 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54108 : List Nat := [2,4,8,16,32,16,8,37,16,53,1,16,41,0,1,34,16,1,52,0,0,32,16,3,41,16,0,17,17,1,21,33,36,32,0,17]

theorem envBound54108 : H12AffineFastState.Bounded env54108 := by
  intro p hp
  have h : env54108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54107_54108 : H12AffineEnvironment.transform 8 16 env54107 = env54108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54107 == env54108) = true)

theorem identity54108 : scanCanonicalize (H12AffineFastState.compose env54108 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54109 : List Nat := [2,4,8,10,32,10,8,37,10,47,1,10,41,0,1,34,10,1,46,0,0,32,10,3,41,10,0,11,11,1,15,33,36,32,0,11]

theorem envBound54109 : H12AffineFastState.Bounded env54109 := by
  intro p hp
  have h : env54109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54108_54109 : H12AffineEnvironment.transform 3 10 env54108 = env54109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54108 == env54109) = true)

def env54110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,272393,17,98645,8192,64,75787,5392,17665,360791,1364,318548,257,21792,46093,74251]

theorem envBound54110 : H12AffineFastState.Bounded env54110 := by
  intro p hp
  have h : env54110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54096_54110 : H12AffineEnvironment.transform 20 4161 env54096 = env54110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54096 == env54110) = true)

theorem identity54110 : scanCanonicalize (H12AffineFastState.compose env54110 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54110 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,4161,33,17,98645,8192,64,75787,5392,17665,108927,1364,62588,257,21792,46093,74251]

theorem envBound54111 : H12AffineFastState.Bounded env54111 := by
  intro p hp
  have h : env54111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54110_54111 : H12AffineEnvironment.transform 17 10280 env54110 = env54111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54110 == env54111) = true)

theorem identity54111 : scanCanonicalize (H12AffineFastState.compose env54111 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54111 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82247,2420,1025,32769,4161,33,17,98645,348,64,67927,5392,17665,100387,1364,54560,257,21792,38225,66391]

theorem envBound54112 : H12AffineFastState.Bounded env54112 := by
  intro p hp
  have h : env54112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54111_54112 : H12AffineEnvironment.transform 12 348 env54111 = env54112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54111 == env54112) = true)

theorem identity54112 : scanCanonicalize (H12AffineFastState.compose env54112 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound54112 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env54113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,16401,2420,1025,32769,4161,33,17,32771,348,64,2049,5392,17665,35189,1364,54560,257,21792,38225,513]

theorem envBound54113 : H12AffineFastState.Bounded env54113 := by
  intro p hp
  have h : env54113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54112_54113 : H12AffineEnvironment.transform 15 342 env54112 = env54113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env54112 == env54113) = true)

theorem identity54113 : scanCanonicalize (H12AffineFastState.compose env54113 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound54113 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,342,16401,2420,1025,21760,4161,33,17,21762,348,64,2049,5392,17665,23668,1364,33,257,21792,16464,513]

theorem envBound54114 : H12AffineFastState.Bounded env54114 := by
  intro p hp
  have h : env54114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54113_54114 : H12AffineEnvironment.transform 14 21761 env54113 = env54114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env54113 == env54114) = true)

theorem identity54114 : scanCanonicalize (H12AffineFastState.compose env54114 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54114 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54115 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,262,16401,2340,1025,21760,4113,33,17,21762,268,16,2049,5392,17665,23588,1284,33,257,21792,16384,513]

theorem envBound54115 : H12AffineFastState.Bounded env54115 := by
  intro p hp
  have h : env54115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54114_54115 : H12AffineEnvironment.transform 5 16 env54114 = env54115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54114 == env54115) = true)

theorem identity54115 : scanCanonicalize (H12AffineFastState.compose env54115 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5684) := by decide +kernel

theorem selectedBound54115 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54116 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5684,821,262,5669,2340,1025,820,4113,33,17,822,268,16,2049,5392,4917,2576,1284,33,257,788,5684,513]

theorem envBound54116 : H12AffineFastState.Bounded env54116 := by
  intro p hp
  have h : env54116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54115_54116 : H12AffineEnvironment.transform 13 5684 env54115 = env54116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5684 env54115 == env54116) = true)

theorem identity54116 : scanCanonicalize (H12AffineFastState.compose env54116 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound54116 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env54117 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,268,2308,821,262,2325,2340,1025,820,3873,33,17,822,268,16,2049,2592,3077,2576,1284,33,257,788,2308,513]

theorem envBound54117 : H12AffineFastState.Bounded env54117 := by
  intro p hp
  have h : env54117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54116_54117 : H12AffineEnvironment.transform 11 3888 env54116 = env54117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env54116 == env54117) = true)

theorem identity54117 : scanCanonicalize (H12AffineFastState.compose env54117 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound54117 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env54118 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1029,821,268,1281,821,262,1296,1313,1025,820,804,33,17,822,268,16,1028,1573,0,1557,1284,33,257,788,1281,513]

theorem envBound54118 : H12AffineFastState.Bounded env54118 := by
  intro p hp
  have h : env54118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54117_54118 : H12AffineEnvironment.transform 10 1029 env54117 = env54118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env54117 == env54118) = true)

theorem identity54118 : scanCanonicalize (H12AffineFastState.compose env54118 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound54118 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env54119 : List Nat := [2,4,8,16,32,16,8,256,308,1024,1029,1,268,1281,1,262,1296,1313,1025,0,16,33,17,2,268,16,1028,1297,0,1313,1284,33,257,32,1281,309]

theorem envBound54119 : H12AffineFastState.Bounded env54119 := by
  intro p hp
  have h : env54119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54118_54119 : H12AffineEnvironment.transform 8 308 env54118 = env54119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env54118 == env54119) = true)

theorem identity54119 : scanCanonicalize (H12AffineFastState.compose env54119 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54120 : List Nat := [2,4,8,16,32,16,8,21,33,1024,1029,1,25,1044,1,19,1029,1076,1025,0,16,33,17,2,25,16,1028,1028,0,1076,1041,33,20,32,1044,32]

theorem envBound54120 : H12AffineFastState.Bounded env54120 := by
  intro p hp
  have h : env54120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54119_54120 : H12AffineEnvironment.transform 7 21 env54119 = env54120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54119 == env54120) = true)

theorem identity54120 : scanCanonicalize (H12AffineFastState.compose env54120 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound54120 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54121 : List Nat := [2,4,8,16,32,16,8,21,33,21,16,1,25,1,1,19,16,33,20,0,16,33,17,2,25,16,17,17,0,33,4,33,20,32,1,32]

theorem envBound54121 : H12AffineFastState.Bounded env54121 := by
  intro p hp
  have h : env54121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54120_54121 : H12AffineEnvironment.transform 9 21 env54120 = env54121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env54120 == env54121) = true)

theorem identity54121 : scanCanonicalize (H12AffineFastState.compose env54121 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54121 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54122 : List Nat := [2,4,8,1,32,1,8,4,33,4,1,1,8,1,1,2,1,33,5,0,1,33,0,2,8,1,0,0,0,33,4,33,5,32,1,32]

theorem envBound54122 : H12AffineFastState.Bounded env54122 := by
  intro p hp
  have h : env54122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54121_54122 : H12AffineEnvironment.transform 3 1 env54121 = env54122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54121 == env54122) = true)

theorem identity54122 : scanCanonicalize (H12AffineFastState.compose env54122 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54122 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54123 : List Nat := [2,4,8,1,1,1,8,4,0,4,1,1,8,1,1,2,1,0,5,0,1,0,0,2,8,1,0,0,0,0,4,0,5,1,1,1]

theorem envBound54123 : H12AffineFastState.Bounded env54123 := by
  intro p hp
  have h : env54123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54122_54123 : H12AffineEnvironment.transform 4 1 env54122 = env54123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54122 == env54123) = true)

def env54124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272392,2101328,98644,8193,64,2177098,2098513,17665,2461974,2102548,2411540,257,21792,46092,2175562]

theorem envBound54124 : H12AffineFastState.Bounded env54124 := by
  intro p hp
  have h : env54124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54095_54124 : H12AffineEnvironment.transform 6 9 env54095 = env54124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54095 == env54124) = true)

theorem identity54124 : scanCanonicalize (H12AffineFastState.compose env54124 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound54124 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env54125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,12572,272392,8524,98644,8193,64,67926,13389,17665,368650,9224,326920,257,21792,46092,66390]

theorem envBound54125 : H12AffineFastState.Bounded env54125 := by
  intro p hp
  have h : env54125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54124_54125 : H12AffineEnvironment.transform 20 12572 env54124 = env54125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env54124 == env54125) = true)

theorem identity54125 : scanCanonicalize (H12AffineFastState.compose env54125 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound54125 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57676,262144,1025,32769,12572,272392,8524,8543,8193,64,43357,13389,17665,262145,9224,326920,257,21792,46092,41821]

theorem envBound54126 : H12AffineFastState.Bounded env54126 := by
  intro p hp
  have h : env54126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54125_54126 : H12AffineEnvironment.transform 15 40971 env54125 = env54126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env54125 == env54126) = true)

theorem identity54126 : scanCanonicalize (H12AffineFastState.compose env54126 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound54126 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env54127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57676,2421,1025,32769,12572,8573,8524,8543,8193,64,43357,13389,17665,2420,9224,62589,257,21792,46092,41821]

theorem envBound54127 : H12AffineFastState.Bounded env54127 := by
  intro p hp
  have h : env54127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54126_54127 : H12AffineEnvironment.transform 17 2421 env54126 = env54127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env54126 == env54127) = true)

theorem identity54127 : scanCanonicalize (H12AffineFastState.compose env54127 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,24908,2421,1025,1,12572,8573,8524,8543,8193,64,10589,13389,17665,2420,9224,29821,257,21792,13324,9053]

theorem envBound54128 : H12AffineFastState.Bounded env54128 := by
  intro p hp
  have h : env54128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54127_54128 : H12AffineEnvironment.transform 14 0 env54127 = env54128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54127 == env54128) = true)

theorem identity54128 : scanCanonicalize (H12AffineFastState.compose env54128 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound54128 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,0,115,16692,2421,1025,1,4452,261,308,295,121,64,2341,5173,17665,2420,1136,21509,257,21792,5236,805]

theorem envBound54129 : H12AffineFastState.Bounded env54129 := by
  intro p hp
  have h : env54129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54128_54129 : H12AffineEnvironment.transform 12 120 env54128 = env54129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env54128 == env54129) = true)

theorem identity54129 : scanCanonicalize (H12AffineFastState.compose env54129 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54129 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54130 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,0,115,16400,2129,1025,1,4160,33,16,3,121,64,2049,5173,17445,2128,1136,21509,37,21508,5236,513]

theorem envBound54130 : H12AffineFastState.Bounded env54130 := by
  intro p hp
  have h : env54130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54129_54130 : H12AffineEnvironment.transform 7 36 env54129 = env54130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54129 == env54130) = true)

theorem identity54130 : scanCanonicalize (H12AffineFastState.compose env54130 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound54130 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54131 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5236,0,115,5220,2129,1025,1,4160,33,16,3,121,64,2049,5173,4177,2128,1136,113,37,112,5236,513]

theorem envBound54131 : H12AffineFastState.Bounded env54131 := by
  intro p hp
  have h : env54131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54130_54131 : H12AffineEnvironment.transform 13 5236 env54130 = env54131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env54130 == env54131) = true)

theorem identity54131 : scanCanonicalize (H12AffineFastState.compose env54131 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54132 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,0,35,5172,2049,1025,1,4112,33,16,3,41,16,2049,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound54132 : H12AffineFastState.Bounded env54132 := by
  intro p hp
  have h : env54132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54131_54132 : H12AffineEnvironment.transform 5 16 env54131 = env54132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54131 == env54132) = true)

theorem identity54132 : scanCanonicalize (H12AffineFastState.compose env54132 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound54132 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54133 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,4096,40,5156,0,35,5172,1077,1025,1,4112,33,16,3,41,16,1077,5173,4097,1076,1056,33,37,32,5156,513]

theorem envBound54133 : H12AffineFastState.Bounded env54133 := by
  intro p hp
  have h : env54133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54132_54133 : H12AffineEnvironment.transform 10 1076 env54132 = env54133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env54132 == env54133) = true)

theorem identity54133 : scanCanonicalize (H12AffineFastState.compose env54133 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound54133 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54134 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,1061,40,1,0,35,17,1077,1025,1,1077,33,16,3,41,16,1077,16,1060,1076,1056,33,37,32,1,513]

theorem envBound54134 : H12AffineFastState.Bounded env54134 := by
  intro p hp
  have h : env54134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54133_54134 : H12AffineEnvironment.transform 11 1061 env54133 = env54134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env54133 == env54134) = true)

theorem identity54134 : scanCanonicalize (H12AffineFastState.compose env54134 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54134 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54135 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,17,40,1,0,35,17,1,53,1,1,33,16,3,41,16,1,16,16,0,20,33,37,32,1,513]

theorem envBound54135 : H12AffineFastState.Bounded env54135 := by
  intro p hp
  have h : env54135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54134_54135 : H12AffineEnvironment.transform 9 52 env54134 = env54135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54134 == env54135) = true)

theorem identity54135 : scanCanonicalize (H12AffineFastState.compose env54135 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound54135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54136 : List Nat := [2,4,8,16,32,16,9,36,17,52,0,17,40,1,0,35,17,1,53,1,1,33,16,3,41,16,1,16,16,0,20,33,37,32,1,16]

theorem envBound54136 : H12AffineFastState.Bounded env54136 := by
  intro p hp
  have h : env54136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54135_54136 : H12AffineEnvironment.transform 8 17 env54135 = env54136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env54135 == env54136) = true)

theorem identity54136 : scanCanonicalize (H12AffineFastState.compose env54136 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound54136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54137 : List Nat := [2,4,8,16,26,16,9,30,17,14,0,17,18,1,0,25,17,1,15,1,1,27,16,3,19,16,1,16,16,0,20,27,31,26,1,16]

theorem envBound54137 : H12AffineFastState.Bounded env54137 := by
  intro p hp
  have h : env54137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54136_54137 : H12AffineEnvironment.transform 4 26 env54136 = env54137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env54136 == env54137) = true)

def env54138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623435,2098512,17664,2461975,2102685,6349853,257,21792,46213,2175562]

theorem envBound54138 : H12AffineFastState.Bounded env54138 := by
  intro p hp
  have h : env54138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54075_54138 : H12AffineEnvironment.transform 22 2101329 env54075 = env54138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env54075 == env54138) = true)

def env54139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177099,2098512,17664,2461975,2102685,2411677,257,21792,46213,2175562]

theorem envBound54139 : H12AffineFastState.Bounded env54139 := by
  intro p hp
  have h : env54139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54138_54139 : H12AffineEnvironment.transform 21 272512 env54138 = env54139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54138 == env54139) = true)

theorem identity54139 : scanCanonicalize (H12AffineFastState.compose env54139 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound54139 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,58517,272512,62660,98780,8328,64,122078,57797,17664,357762,61704,272392,257,21792,46213,120543]

theorem envBound54140 : H12AffineFastState.Bounded env54140 := by
  intro p hp
  have h : env54140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54139_54140 : H12AffineEnvironment.transform 20 58517 env54139 = env54140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env54139 == env54140) = true)

def env54141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,58517,168,62660,98780,8328,64,122078,57797,17664,89514,61704,32,257,21792,46213,120543]

theorem envBound54141 : H12AffineFastState.Bounded env54141 := by
  intro p hp
  have h : env54141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54140_54141 : H12AffineEnvironment.transform 17 10280 env54140 = env54141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54140 == env54141) = true)

theorem identity54141 : scanCanonicalize (H12AffineFastState.compose env54141 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound54141 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,70862,10280,1025,32769,45340,168,41293,98780,8328,64,100695,46156,4233,67619,42113,32,257,169,46213,99158]

theorem envBound54142 : H12AffineFastState.Bounded env54142 := by
  intro p hp
  have h : env54142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54141_54142 : H12AffineEnvironment.transform 13 5513 env54141 = env54142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env54141 == env54142) = true)

theorem identity54142 : scanCanonicalize (H12AffineFastState.compose env54142 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54142 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,70726,10280,1025,32769,45340,32,41293,98644,8192,64,100695,46156,4097,67619,41993,32,257,33,46093,99158]

theorem envBound54143 : H12AffineFastState.Bounded env54143 := by
  intro p hp
  have h : env54143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54142_54143 : H12AffineEnvironment.transform 6 8 env54142 = env54143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54142 == env54143) = true)

theorem identity54143 : scanCanonicalize (H12AffineFastState.compose env54143 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54143 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env54144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,13389,10280,1025,32769,45340,32,41293,41311,8192,64,43356,46156,4097,10280,41993,32,257,33,46093,41821]

theorem envBound54144 : H12AffineFastState.Bounded env54144 := by
  intro p hp
  have h : env54144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54143_54144 : H12AffineEnvironment.transform 15 8203 env54143 = env54144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54143 == env54144) = true)

theorem identity54144 : scanCanonicalize (H12AffineFastState.compose env54144 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound54144 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env54145 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,8192,5377,32768,8203,13373,10280,1025,32769,45340,32,41277,41263,8192,48,43308,46140,4097,10280,41993,32,257,33,46093,41773]

theorem envBound54145 : H12AffineFastState.Bounded env54145 := by
  intro p hp
  have h : env54145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54144_54145 : H12AffineEnvironment.transform 5 48 env54144 = env54145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env54144 == env54145) = true)

theorem identity54145 : scanCanonicalize (H12AffineFastState.compose env54145 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound54145 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54146 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,8192,5377,32,8203,13373,10280,1025,33,12604,32,8477,8463,8192,48,10508,13340,4097,10280,9257,32,257,33,13357,8973]

theorem envBound54146 : H12AffineFastState.Bounded env54146 := by
  intro p hp
  have h : env54146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54145_54146 : H12AffineEnvironment.transform 14 32 env54145 = env54146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env54145 == env54146) = true)

theorem identity54146 : scanCanonicalize (H12AffineFastState.compose env54146 (packedSelected [3,4,5,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound54146 : packedSelected [3,4,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54147 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,33,8192,1312,32,8203,9244,10280,1025,33,8477,32,8477,8463,8192,48,10508,9277,32,10280,9257,32,257,33,9228,8973]

theorem envBound54147 : H12AffineFastState.Bounded env54147 := by
  intro p hp
  have h : env54147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54146_54147 : H12AffineEnvironment.transform 11 33 env54146 = env54147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env54146 == env54147) = true)

theorem identity54147 : scanCanonicalize (H12AffineFastState.compose env54147 (packedSelected [0,1,4,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound54147 : packedSelected [0,1,4,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env54148 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,33,1337,1312,32,1330,293,3345,1025,33,1060,32,1060,1078,1337,48,3125,260,32,3345,272,32,257,33,309,1588]

theorem envBound54148 : H12AffineFastState.Bounded env54148 := by
  intro p hp
  have h : env54148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54147_54148 : H12AffineEnvironment.transform 12 1337 env54147 = env54148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env54147 == env54148) = true)

theorem identity54148 : scanCanonicalize (H12AffineFastState.compose env54148 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound54148 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env54149 : List Nat := [2,4,8,16,32,48,8,256,260,1024,2048,33,1337,1312,32,1330,293,3345,1025,33,1060,32,1060,1078,1337,48,3125,260,32,3345,272,32,257,33,309,1328]

theorem envBound54149 : H12AffineFastState.Bounded env54149 := by
  intro p hp
  have h : env54149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54148_54149 : H12AffineEnvironment.transform 8 260 env54148 = env54149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env54148 == env54149) = true)

theorem identity54149 : scanCanonicalize (H12AffineFastState.compose env54149 (packedSelected [2,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound54149 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env54150 : List Nat := [2,4,8,16,32,48,8,256,260,20,2048,33,301,308,32,294,293,2309,21,33,48,32,48,34,301,48,2081,260,32,2309,272,32,257,33,309,292]

theorem envBound54150 : H12AffineFastState.Bounded env54150 := by
  intro p hp
  have h : env54150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54149_54150 : H12AffineEnvironment.transform 9 20 env54149 = env54150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env54149 == env54150) = true)

theorem identity54150 : scanCanonicalize (H12AffineFastState.compose env54150 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54150 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env54151 : List Nat := [2,4,8,16,1,17,8,256,260,20,2048,0,268,277,1,263,260,2309,21,0,17,1,17,3,268,17,2048,260,1,2309,272,1,257,0,276,261]

theorem envBound54151 : H12AffineFastState.Bounded env54151 := by
  intro p hp
  have h : env54151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54150_54151 : H12AffineEnvironment.transform 4 1 env54150 = env54151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54150 == env54151) = true)

theorem identity54151 : scanCanonicalize (H12AffineFastState.compose env54151 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound54151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54152 : List Nat := [2,4,8,16,1,17,8,256,260,20,271,0,268,277,1,263,260,10,21,0,17,1,17,3,268,17,271,260,1,10,272,1,257,0,276,261]

theorem envBound54152 : H12AffineFastState.Bounded env54152 := by
  intro p hp
  have h : env54152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54151_54152 : H12AffineEnvironment.transform 10 271 env54151 = env54152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env54151 == env54152) = true)

theorem identity54152 : scanCanonicalize (H12AffineFastState.compose env54152 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54152 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54153 : List Nat := [2,4,4,16,1,17,4,256,260,20,259,0,256,277,1,263,260,6,21,0,17,1,17,3,256,17,259,260,1,6,272,1,257,0,276,261]

theorem envBound54153 : H12AffineFastState.Bounded env54153 := by
  intro p hp
  have h : env54153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54152_54153 : H12AffineEnvironment.transform 2 4 env54152 = env54153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54152 == env54153) = true)

def env54154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,58517,169,62660,98780,8328,64,122078,57797,17664,89515,61704,33,257,21792,46213,120543]

theorem envBound54154 : H12AffineFastState.Bounded env54154 := by
  intro p hp
  have h : env54154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54140_54154 : H12AffineEnvironment.transform 17 10281 env54140 = env54154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54140 == env54154) = true)

theorem identity54154 : scanCanonicalize (H12AffineFastState.compose env54154 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41462) := by decide +kernel

theorem selectedBound54154 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41462,57521,10281,1025,32769,58517,169,62660,8234,8328,64,32040,57797,17664,64605,61704,33,257,21792,46213,30505]

theorem envBound54155 : H12AffineFastState.Bounded env54155 := by
  intro p hp
  have h : env54155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54154_54155 : H12AffineEnvironment.transform 15 41462 env54154 = env54155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41462 env54154 == env54155) = true)

theorem identity54155 : scanCanonicalize (H12AffineFastState.compose env54155 (packedSelected [4,5,8,9,10,12,14,15,17,19,20,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound54155 : packedSelected [4,5,8,9,10,12,14,15,17,19,20,24,28] rootPS < 2^1333 := by decide +kernel

def env54156 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,8192,16384,32768,41462,57521,10281,457,32769,57693,169,61708,8234,8328,64,30944,57797,16584,63893,61704,33,257,20712,45389,29409]

theorem envBound54156 : H12AffineFastState.Bounded env54156 := by
  intro p hp
  have h : env54156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54155_54156 : H12AffineEnvironment.transform 9 456 env54155 = env54156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env54155 == env54156) = true)

theorem identity54156 : scanCanonicalize (H12AffineFastState.compose env54156 (packedSelected [0,2,4,6,9,10,11,12,15,17,18,19,20,26,27,31] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound54156 : packedSelected [0,2,4,6,9,10,11,12,15,17,18,19,20,26,27,31] rootPS < 2^1333 := by decide +kernel

def env54157 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,161,16384,32768,33111,49168,2184,457,32769,49660,169,53677,139,41,64,22593,49508,16584,55604,53673,33,257,20712,37356,21056]

theorem envBound54157 : H12AffineFastState.Bounded env54157 := by
  intro p hp
  have h : env54157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54156_54157 : H12AffineEnvironment.transform 12 161 env54156 = env54157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env54156 == env54157) = true)

theorem identity54157 : scanCanonicalize (H12AffineFastState.compose env54157 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4588) := by decide +kernel

theorem selectedBound54157 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env54158 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,161,4588,32768,33111,37372,2184,457,32769,36880,169,32833,139,41,64,2477,37000,4388,35032,32837,33,257,260,37356,940]

theorem envBound54158 : H12AffineFastState.Bounded env54158 := by
  intro p hp
  have h : env54158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54157_54158 : H12AffineEnvironment.transform 13 4588 env54157 = env54158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4588 env54157 == env54158) = true)

theorem identity54158 : scanCanonicalize (H12AffineFastState.compose env54158 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound54158 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env54159 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,161,4588,293,114,4313,2184,457,292,4405,169,356,139,41,64,2477,4525,4388,2557,352,33,257,260,4297,940]

theorem envBound54159 : H12AffineFastState.Bounded env54159 := by
  intro p hp
  have h : env54159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54158_54159 : H12AffineEnvironment.transform 14 293 env54158 = env54159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env54158 == env54159) = true)

theorem identity54159 : scanCanonicalize (H12AffineFastState.compose env54159 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54159 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54160 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,161,4541,293,35,4232,2184,408,292,4405,169,309,139,41,17,2477,4525,4388,2476,305,33,257,260,4248,940]

theorem envBound54160 : H12AffineFastState.Bounded env54160 := by
  intro p hp
  have h : env54160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54159_54160 : H12AffineEnvironment.transform 5 17 env54159 = env54160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54159 == env54160) = true)

theorem identity54160 : scanCanonicalize (H12AffineFastState.compose env54160 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54160 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54161 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,4096,161,4248,0,35,4232,2184,189,1,4112,169,16,139,41,17,2184,4232,4097,2185,20,33,36,33,4248,649]

theorem envBound54161 : H12AffineFastState.Bounded env54161 := by
  intro p hp
  have h : env54161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54160_54161 : H12AffineEnvironment.transform 7 37 env54160 = env54161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54160 == env54161) = true)

theorem identity54161 : scanCanonicalize (H12AffineFastState.compose env54161 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound54161 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54162 : List Nat := [2,4,8,16,32,17,128,37,512,188,37,4096,161,4248,0,35,4232,173,189,1,4112,169,16,139,41,17,173,4232,4097,172,20,33,36,33,4248,649]

theorem envBound54162 : H12AffineFastState.Bounded env54162 := by
  intro p hp
  have h : env54162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54161_54162 : H12AffineEnvironment.transform 10 37 env54161 = env54162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env54161 == env54162) = true)

theorem identity54162 : scanCanonicalize (H12AffineFastState.compose env54162 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound54162 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env54163 : List Nat := [2,4,8,16,32,17,128,37,512,188,37,538,161,642,0,35,658,173,189,1,522,169,16,139,41,17,173,658,539,172,20,33,36,33,642,649]

theorem envBound54163 : H12AffineFastState.Bounded env54163 := by
  intro p hp
  have h : env54163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54162_54163 : H12AffineEnvironment.transform 11 538 env54162 = env54163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env54162 == env54163) = true)

theorem identity54163 : scanCanonicalize (H12AffineFastState.compose env54163 (packedSelected [0,1,2,6] rootPS)) = affineNative (2^(8+1) ^^^ 165) := by decide +kernel

theorem selectedBound54163 : packedSelected [0,1,2,6] rootPS < 2^1333 := by decide +kernel

def env54164 : List Nat := [2,4,8,16,32,17,128,37,165,188,37,191,161,39,0,35,55,173,189,1,175,169,16,139,41,17,173,55,190,172,20,33,36,33,39,44]

theorem envBound54164 : H12AffineFastState.Bounded env54164 := by
  intro p hp
  have h : env54164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54163_54164 : H12AffineEnvironment.transform 8 165 env54163 = env54164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 165 env54163 == env54164) = true)

theorem identity54164 : scanCanonicalize (H12AffineFastState.compose env54164 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 12) := by decide +kernel

theorem selectedBound54164 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env54165 : List Nat := [2,4,8,16,32,17,12,37,41,48,37,51,45,39,0,35,55,33,49,1,35,37,16,7,41,17,33,55,50,32,20,33,36,33,39,44]

theorem envBound54165 : H12AffineFastState.Bounded env54165 := by
  intro p hp
  have h : env54165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54164_54165 : H12AffineEnvironment.transform 6 12 env54164 = env54165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 12 env54164 == env54165) = true)

theorem identity54165 : scanCanonicalize (H12AffineFastState.compose env54165 (packedSelected [1,2,8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54165 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env54166 : List Nat := [2,0,8,16,32,17,8,33,41,48,33,51,41,35,0,35,51,33,49,1,35,33,16,3,41,17,33,51,50,32,16,33,32,33,35,40]

theorem envBound54166 : H12AffineFastState.Bounded env54166 := by
  intro p hp
  have h : env54166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54165_54166 : H12AffineEnvironment.transform 1 0 env54165 = env54166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54165 == env54166) = true)

theorem identity54166 : scanCanonicalize (H12AffineFastState.compose env54166 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound54166 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54167 : List Nat := [2,0,8,16,2,17,8,3,11,18,3,17,11,1,0,1,17,3,19,1,1,3,16,3,11,17,3,17,16,2,16,3,2,3,1,10]

theorem envBound54167 : H12AffineFastState.Bounded env54167 := by
  intro p hp
  have h : env54167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54166_54167 : H12AffineEnvironment.transform 4 2 env54166 = env54167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env54166 == env54167) = true)

def env54168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177098,2098512,17664,2461975,2102685,2411676,257,21792,46213,2175562]

theorem envBound54168 : H12AffineFastState.Bounded env54168 := by
  intro p hp
  have h : env54168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54138_54168 : H12AffineEnvironment.transform 21 272513 env54138 = env54168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54138 == env54168) = true)

theorem identity54168 : scanCanonicalize (H12AffineFastState.compose env54168 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound54168 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82247,262144,1025,29908,2097152,272513,2101329,95497,8328,64,2177098,2098512,17664,2450882,2102685,2373705,257,21792,16464,2175562]

theorem envBound54169 : H12AffineFastState.Bounded env54169 := by
  intro p hp
  have h : env54169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54168_54169 : H12AffineEnvironment.transform 14 29909 env54168 = env54169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env54168 == env54169) = true)

def env54170 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,262144,1025,29828,2097152,272513,2101249,95497,8328,16,2177050,2098432,17664,2450834,2102685,2373657,257,21792,16384,2175514]

theorem envBound54170 : H12AffineFastState.Bounded env54170 := by
  intro p hp
  have h : env54170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54169_54170 : H12AffineEnvironment.transform 5 16 env54169 = env54170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54169 == env54170) = true)

theorem identity54170 : scanCanonicalize (H12AffineFastState.compose env54170 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound54170 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54171 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,76198,1025,29828,2097152,65831,2101249,95497,8328,16,2177050,2098432,17664,2116660,2102685,2167231,257,21792,16384,2175514]

theorem envBound54171 : H12AffineFastState.Bounded env54171 := by
  intro p hp
  have h : env54171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54170_54171 : H12AffineEnvironment.transform 17 76198 env54170 = env54171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env54170 == env54171) = true)

theorem identity54171 : scanCanonicalize (H12AffineFastState.compose env54171 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54171 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env54172 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,82199,76079,1025,29709,2097152,65831,2101249,95497,8193,16,2177050,2098432,17664,2116660,2102548,2167094,257,21792,16384,2175514]

theorem envBound54172 : H12AffineFastState.Bounded env54172 := by
  intro p hp
  have h : env54172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54171_54172 : H12AffineEnvironment.transform 6 9 env54171 = env54172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54171 == env54172) = true)

theorem identity54172 : scanCanonicalize (H12AffineFastState.compose env54172 (packedSelected [1,4,8,9,12,14,15,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound54172 : packedSelected [1,4,8,9,12,14,15,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54173 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,34,16693,10509,1025,29709,2097152,261,2101249,29995,8193,16,2111544,2098432,17664,2116660,2102548,2101524,257,21792,16384,2110008]

theorem envBound54173 : H12AffineFastState.Bounded env54173 := by
  intro p hp
  have h : env54173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54172_54173 : H12AffineEnvironment.transform 15 34 env54172 = env54173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env54172 == env54173) = true)

theorem identity54173 : scanCanonicalize (H12AffineFastState.compose env54173 (packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54173 : packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env54174 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,29708,34,16400,10280,1025,29709,2097152,32,2101249,29710,8193,16,2111544,2098213,17445,2116660,2102321,2101297,36,21509,16384,2110008]

theorem envBound54174 : H12AffineFastState.Bounded env54174 := by
  intro p hp
  have h : env54174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54173_54174 : H12AffineEnvironment.transform 7 37 env54173 = env54174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54173 == env54174) = true)

theorem identity54174 : scanCanonicalize (H12AffineFastState.compose env54174 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54174 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54175 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,16384,21540,34,16400,2048,1025,21541,2097152,32,2101249,21542,41,16,2103312,2098213,17445,2116660,2102321,2101297,36,21509,16384,2101776]

theorem envBound54175 : H12AffineFastState.Bounded env54175 := by
  intro p hp
  have h : env54175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54174_54175 : H12AffineEnvironment.transform 12 40 env54174 = env54175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54174 == env54175) = true)

theorem identity54175 : scanCanonicalize (H12AffineFastState.compose env54175 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound54175 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54176 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,2097152,32,2101249,2,41,16,2103312,2098213,4097,2103312,2102321,2101297,36,33,5156,2101776]

theorem envBound54176 : H12AffineFastState.Bounded env54176 := by
  intro p hp
  have h : env54176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54175_54176 : H12AffineEnvironment.transform 13 5156 env54175 = env54176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env54175 == env54176) = true)

theorem identity54176 : scanCanonicalize (H12AffineFastState.compose env54176 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 33) := by decide +kernel

theorem selectedBound54176 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54177 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,33,32,4128,2,41,16,6193,1028,4097,6193,5136,4112,36,33,5156,4657]

theorem envBound54177 : H12AffineFastState.Bounded env54177 := by
  intro p hp
  have h : env54177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54176_54177 : H12AffineEnvironment.transform 20 33 env54176 = env54177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 33 env54176 == env54177) = true)

theorem identity54177 : scanCanonicalize (H12AffineFastState.compose env54177 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3588) := by decide +kernel

theorem selectedBound54177 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env54178 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3588,40,2592,0,34,2608,2048,1025,1,33,32,3620,2,41,16,1589,1028,3589,1589,2580,3604,36,33,2592,3125]

theorem envBound54178 : H12AffineFastState.Bounded env54178 := by
  intro p hp
  have h : env54178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54177_54178 : H12AffineEnvironment.transform 11 3588 env54177 = env54178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3588 env54177 == env54178) = true)

theorem identity54178 : scanCanonicalize (H12AffineFastState.compose env54178 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54178 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54179 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,1540,40,544,0,34,560,0,1025,1,33,32,1572,2,41,16,1589,1028,1541,1589,532,1556,36,33,544,1077]

theorem envBound54179 : H12AffineFastState.Bounded env54179 := by
  intro p hp
  have h : env54179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54178_54179 : H12AffineEnvironment.transform 10 0 env54178 = env54179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54178 == env54179) = true)

theorem identity54179 : scanCanonicalize (H12AffineFastState.compose env54179 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54179 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env54180 : List Nat := [2,4,8,16,32,16,9,37,48,1024,0,1076,40,16,0,34,0,0,1025,1,33,32,1044,2,41,16,1029,1028,1077,1029,36,1060,36,33,16,1077]

theorem envBound54180 : H12AffineFastState.Bounded env54180 := by
  intro p hp
  have h : env54180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54179_54180 : H12AffineEnvironment.transform 8 48 env54179 = env54180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54179 == env54180) = true)

theorem identity54180 : scanCanonicalize (H12AffineFastState.compose env54180 (packedSelected [0,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound54180 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env54181 : List Nat := [2,4,8,16,32,16,9,37,48,37,0,17,40,16,0,34,0,0,36,1,33,32,49,2,41,16,32,33,16,32,36,1,36,33,16,16]

theorem envBound54181 : H12AffineFastState.Bounded env54181 := by
  intro p hp
  have h : env54181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54180_54181 : H12AffineEnvironment.transform 9 37 env54180 = env54181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env54180 == env54181) = true)

def env54182 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82198,262144,1025,29829,2097152,272513,2101248,95497,8328,17,2177051,2098433,17664,2450835,2102685,2373656,257,21792,16385,2175515]

theorem envBound54182 : H12AffineFastState.Bounded env54182 := by
  intro p hp
  have h : env54182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54169_54182 : H12AffineEnvironment.transform 5 17 env54169 = env54182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54169 == env54182) = true)

theorem identity54182 : scanCanonicalize (H12AffineFastState.compose env54182 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound54182 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54183 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82198,2477,1025,29829,2097152,8492,2101248,95497,8328,17,2177051,2098433,17664,2190398,2102685,2109877,257,21792,16385,2175515]

theorem envBound54183 : H12AffineFastState.Bounded env54183 := by
  intro p hp
  have h : env54183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54182_54183 : H12AffineEnvironment.transform 17 2477 env54182 = env54183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env54182 == env54183) = true)

theorem identity54183 : scanCanonicalize (H12AffineFastState.compose env54183 (packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54183 : packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS < 2^1333 := by decide +kernel

def env54184 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8203,24861,2477,1025,29829,2097152,8492,2101248,21762,8328,17,2103312,2098433,17664,2116661,2102685,2109877,257,21792,16385,2101776]

theorem envBound54184 : H12AffineFastState.Bounded env54184 := by
  intro p hp
  have h : env54184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54183_54184 : H12AffineEnvironment.transform 15 8203 env54183 = env54184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54183 == env54184) = true)

theorem identity54184 : scanCanonicalize (H12AffineFastState.compose env54184 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54184 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env54185 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,8203,13341,2477,1025,8581,2097152,8492,2101248,2,8328,17,2103312,2098433,4096,2103605,2102685,2109877,257,32,5377,2101776]

theorem envBound54185 : H12AffineFastState.Bounded env54185 := by
  intro p hp
  have h : env54185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54184_54185 : H12AffineEnvironment.transform 13 5376 env54184 = env54185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54184 == env54185) = true)

theorem identity54185 : scanCanonicalize (H12AffineFastState.compose env54185 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 4112) := by decide +kernel

theorem selectedBound54185 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1