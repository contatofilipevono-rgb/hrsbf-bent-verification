import H12CloudChart1Data132

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity33749 : scanCanonicalize (H12AffineFastState.compose env33749 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33749 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33750 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5172,2048,1024,1,4112,33,16,2,41,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound33750 : H12AffineFastState.Bounded env33750 := by
  intro p hp
  have h : env33750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33749_33750 : H12AffineEnvironment.transform 7 36 env33749 = env33750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33749 == env33750) = true)

def env33751 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,0,34,1028,2048,1024,1,32,33,16,2,41,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound33751 : H12AffineFastState.Bounded env33751 := by
  intro p hp
  have h : env33751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33750_33751 : H12AffineEnvironment.transform 11 48 env33750 = env33751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33750 == env33751) = true)

theorem identity33751 : scanCanonicalize (H12AffineFastState.compose env33751 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound33751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33752 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,48,41,1044,0,34,1028,1077,1024,1,32,33,16,2,41,16,1077,1028,48,1077,1056,33,36,32,1044,513]

theorem envBound33752 : H12AffineFastState.Bounded env33752 := by
  intro p hp
  have h : env33752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33751_33752 : H12AffineEnvironment.transform 10 1077 env33751 = env33752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env33751 == env33752) = true)

def env33753 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,41,32,0,34,48,1,52,1,32,33,16,2,41,16,1,48,48,1,20,33,36,32,32,513]

theorem envBound33753 : H12AffineFastState.Bounded env33753 := by
  intro p hp
  have h : env33753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33752_33753 : H12AffineEnvironment.transform 9 52 env33752 = env33753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33752 == env33753) = true)

def leafEnv33753 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,41,32,0,34,48,1,52,1,32,33,16,2,20,41,1,16,1,48,48,1,20,33,36,32,4,34,32,513,1,32,0]

def active33753 : List Nat := [0,1,2,3,4,8]

def tree33753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33753 : H12WitnessSearch.Good tree33753 := H12GlobalWitnessIndex.good

theorem leafIdentity33753 : H12AffineFastState.composeSystem env33753 rootObs = leafEnv33753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33753 rootObs == leafEnv33753) = true)

theorem terminalChecked33753 : H12PackedTerminal.terminalCheckFast leafEnv33753 active33753 tree33753 = true := by decide +kernel

def env33754 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,41,33,0,34,49,0,53,1,32,33,16,2,41,16,0,49,48,0,21,33,36,32,33,513]

theorem envBound33754 : H12AffineFastState.Bounded env33754 := by
  intro p hp
  have h : env33754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33752_33754 : H12AffineEnvironment.transform 9 53 env33752 = env33754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33752 == env33754) = true)

theorem identity33754 : scanCanonicalize (H12AffineFastState.compose env33754 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33755 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,48,41,33,0,34,49,0,53,1,32,33,16,2,41,16,0,49,48,0,21,33,36,32,33,43]

theorem envBound33755 : H12AffineFastState.Bounded env33755 := by
  intro p hp
  have h : env33755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33754_33755 : H12AffineEnvironment.transform 8 42 env33754 = env33755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33754 == env33755) = true)

def leafEnv33755 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,48,41,33,0,34,49,0,53,1,32,33,16,2,21,41,1,16,0,49,48,0,21,33,36,32,4,34,33,43,1,32,0]

def active33755 : List Nat := [0,1,2,3,4]

def tree33755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33755 : H12WitnessSearch.Good tree33755 := H12GlobalWitnessIndex.good

theorem leafIdentity33755 : H12AffineFastState.composeSystem env33755 rootObs = leafEnv33755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33755 rootObs == leafEnv33755) = true)

theorem terminalChecked33755 : H12PackedTerminal.terminalCheckFast leafEnv33755 active33755 tree33755 = true := by decide +kernel

def env33756 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,0,34,1029,2048,1024,1,33,33,16,2,41,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound33756 : H12AffineFastState.Bounded env33756 := by
  intro p hp
  have h : env33756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33750_33756 : H12AffineEnvironment.transform 11 49 env33750 = env33756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33750 == env33756) = true)

theorem identity33756 : scanCanonicalize (H12AffineFastState.compose env33756 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33757 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,49,41,1045,0,34,1029,0,1024,1,33,33,16,2,41,16,0,1029,49,0,1056,33,36,32,1045,513]

theorem envBound33757 : H12AffineFastState.Bounded env33757 := by
  intro p hp
  have h : env33757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33756_33757 : H12AffineEnvironment.transform 10 0 env33756 = env33757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33756 == env33757) = true)

def env33758 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,41,33,0,34,49,0,52,1,33,33,16,2,41,16,0,49,49,0,20,33,36,32,33,513]

theorem envBound33758 : H12AffineFastState.Bounded env33758 := by
  intro p hp
  have h : env33758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33757_33758 : H12AffineEnvironment.transform 9 52 env33757 = env33758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33757 == env33758) = true)

def leafEnv33758 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,41,33,0,34,49,0,52,1,33,33,16,2,20,41,1,16,0,49,49,0,20,33,36,32,4,34,33,513,1,33,0]

def active33758 : List Nat := [0,1,2,3,4,8]

def tree33758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33758 : H12WitnessSearch.Good tree33758 := H12GlobalWitnessIndex.good

theorem leafIdentity33758 : H12AffineFastState.composeSystem env33758 rootObs = leafEnv33758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33758 rootObs == leafEnv33758) = true)

theorem terminalChecked33758 : H12PackedTerminal.terminalCheckFast leafEnv33758 active33758 tree33758 = true := by decide +kernel

def env33759 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,49,41,32,0,34,48,0,53,1,33,33,16,2,41,16,0,48,49,0,21,33,36,32,32,513]

theorem envBound33759 : H12AffineFastState.Bounded env33759 := by
  intro p hp
  have h : env33759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33757_33759 : H12AffineEnvironment.transform 9 53 env33757 = env33759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33757 == env33759) = true)

theorem identity33759 : scanCanonicalize (H12AffineFastState.compose env33759 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33760 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,49,41,32,0,34,48,0,53,1,33,33,16,2,41,16,0,48,49,0,21,33,36,32,32,43]

theorem envBound33760 : H12AffineFastState.Bounded env33760 := by
  intro p hp
  have h : env33760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33759_33760 : H12AffineEnvironment.transform 8 42 env33759 = env33760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33759 == env33760) = true)

def leafEnv33760 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,49,41,32,0,34,48,0,53,1,33,33,16,2,21,41,1,16,0,48,49,0,21,33,36,32,4,34,32,43,1,33,0]

def active33760 : List Nat := [0,1,2,3,4]

def tree33760 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33760 : H12WitnessSearch.Good tree33760 := H12GlobalWitnessIndex.good

theorem leafIdentity33760 : H12AffineFastState.composeSystem env33760 rootObs = leafEnv33760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33760 rootObs == leafEnv33760) = true)

theorem terminalChecked33760 : H12PackedTerminal.terminalCheckFast leafEnv33760 active33760 tree33760 = true := by decide +kernel

def env33761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,17,98644,8328,64,4592709,5393,4233,431376,1365,4235613,256,33,46213,74371]

theorem envBound33761 : H12AffineFastState.Bounded env33761 := by
  intro p hp
  have h : env33761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33740_33761 : H12AffineEnvironment.transform 13 5377 env33740 = env33761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33740 == env33761) = true)

theorem identity33761 : scanCanonicalize (H12AffineFastState.compose env33761 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound33761 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,32,17,98644,8328,64,398437,5393,4233,431376,1365,41341,256,33,46213,74371]

theorem envBound33762 : H12AffineFastState.Bounded env33762 := by
  intro p hp
  have h : env33762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33761_33762 : H12AffineEnvironment.transform 21 32 env33761 = env33762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env33761 == env33762) = true)

def env33763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,17,98644,8192,64,398437,5393,4097,431376,1365,41341,256,33,46093,74251]

theorem envBound33763 : H12AffineFastState.Bounded env33763 := by
  intro p hp
  have h : env33763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33762_33763 : H12AffineEnvironment.transform 6 8 env33762 = env33763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33762 == env33763) = true)

theorem identity33763 : scanCanonicalize (H12AffineFastState.compose env33763 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33763 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,4161,32,17,98644,8192,64,146508,5393,4097,179513,1365,41341,256,33,46093,74251]

theorem envBound33764 : H12AffineFastState.Bounded env33764 := by
  intro p hp
  have h : env33764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33763_33764 : H12AffineEnvironment.transform 17 10281 env33763 = env33764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33763 == env33764) = true)

def env33765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98644,8193,64,398437,5393,4096,431376,1365,41341,256,33,46092,74250]

theorem envBound33765 : H12AffineFastState.Bounded env33765 := by
  intro p hp
  have h : env33765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33762_33765 : H12AffineEnvironment.transform 6 9 env33762 = env33765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33762 == env33765) = true)

theorem identity33765 : scanCanonicalize (H12AffineFastState.compose env33765 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound33765 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1024,32769,4160,32,17,98644,8193,64,171280,5393,4096,138341,1365,41341,256,33,46092,74250]

theorem envBound33766 : H12AffineFastState.Bounded env33766 := by
  intro p hp
  have h : env33766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33765_33766 : H12AffineEnvironment.transform 17 35189 env33765 = env33766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env33765 == env33766) = true)

theorem identity33766 : scanCanonicalize (H12AffineFastState.compose env33766 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33766 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,65536,131072,2420,1024,0,4160,32,17,65877,8193,64,138513,5393,4096,138341,1365,8572,256,33,13325,74250]

theorem envBound33767 : H12AffineFastState.Bounded env33767 := by
  intro p hp
  have h : env33767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33766_33767 : H12AffineEnvironment.transform 14 1 env33766 = env33767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33766 == env33767) = true)

theorem identity33767 : scanCanonicalize (H12AffineFastState.compose env33767 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound33767 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,65536,5393,2420,1024,0,4160,32,17,65877,8193,64,2048,5393,4096,2420,1365,8572,256,33,13325,74250]

theorem envBound33768 : H12AffineFastState.Bounded env33768 := by
  intro p hp
  have h : env33768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33767_33768 : H12AffineEnvironment.transform 16 5393 env33767 = env33768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33767 == env33768) = true)

theorem identity33768 : scanCanonicalize (H12AffineFastState.compose env33768 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33768 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,8203,5393,2420,1024,0,4160,32,17,8542,8193,64,2048,5393,4096,2420,1365,8572,256,33,13325,513]

theorem envBound33769 : H12AffineFastState.Bounded env33769 := by
  intro p hp
  have h : env33769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33768_33769 : H12AffineEnvironment.transform 15 8203 env33768 = env33769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33768 == env33769) = true)

theorem identity33769 : scanCanonicalize (H12AffineFastState.compose env33769 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound33769 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33770 : List Nat := [2,4,8,16,32,64,9,256,512,613,2048,4096,8192,4964,1,8203,4980,2420,613,0,4160,32,17,8542,8193,64,2048,4980,4096,2420,816,8572,256,33,12904,513]

theorem envBound33770 : H12AffineFastState.Bounded env33770 := by
  intro p hp
  have h : env33770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33769_33770 : H12AffineEnvironment.transform 9 613 env33769 = env33770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env33769 == env33770) = true)

def env33771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21776,98645,8328,64,4592708,16400,17801,431376,20565,4235613,256,21792,46213,96131]

theorem envBound33771 : H12AffineFastState.Bounded env33771 := by
  intro p hp
  have h : env33771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33739_33771 : H12AffineEnvironment.transform 20 17865 env33739 = env33771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env33739 == env33771) = true)

def env33772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,16,98645,8328,64,4592708,5392,4233,431376,1365,4235613,256,32,46213,74371]

theorem envBound33772 : H12AffineFastState.Bounded env33772 := by
  intro p hp
  have h : env33772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33771_33772 : H12AffineEnvironment.transform 13 5376 env33771 = env33772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33771 == env33772) = true)

theorem identity33772 : scanCanonicalize (H12AffineFastState.compose env33772 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33772 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4297,4194304,16,73736,8328,64,4592708,5392,4233,406605,1365,4194304,256,32,5592,74371]

theorem envBound33773 : H12AffineFastState.Bounded env33773 := by
  intro p hp
  have h : env33773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33772_33773 : H12AffineEnvironment.transform 14 8541 env33772 = env33773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33772 == env33773) = true)

def env33774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5392,262144,1024,8540,4297,4194304,16,73736,8328,64,4456788,5392,4233,270685,1365,4194304,256,32,5592,74371]

theorem envBound33774 : H12AffineFastState.Bounded env33774 := by
  intro p hp
  have h : env33774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33773_33774 : H12AffineEnvironment.transform 16 5392 env33773 = env33774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33773 == env33774) = true)

theorem identity33774 : scanCanonicalize (H12AffineFastState.compose env33774 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound33774 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5392,262144,1024,8540,4297,4194304,16,138,8328,64,4456788,5392,4233,270685,1365,4194304,256,32,5592,513]

theorem envBound33775 : H12AffineFastState.Bounded env33775 := by
  intro p hp
  have h : env33775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33774_33775 : H12AffineEnvironment.transform 15 8322 env33774 = env33775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env33774 == env33775) = true)

theorem identity33775 : scanCanonicalize (H12AffineFastState.compose env33775 (packedSelected [1,2,3,5,6,7,8,10,12,14,15,19,20,27,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound33775 : packedSelected [1,2,3,5,6,7,8,10,12,14,15,19,20,27,38,41] rootPS < 2^1333 := by decide +kernel

def env33776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5392,10280,1024,8540,4297,4194304,16,138,8328,64,4204924,5392,4233,2421,1365,4194304,256,32,5592,513]

theorem envBound33776 : H12AffineFastState.Bounded env33776 := by
  intro p hp
  have h : env33776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33775_33776 : H12AffineEnvironment.transform 17 10280 env33775 = env33776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33775 == env33776) = true)

theorem identity33776 : scanCanonicalize (H12AffineFastState.compose env33776 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound33776 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5392,10280,1024,8540,4297,8200,16,138,8328,64,2420,5392,4233,2421,1365,8200,256,32,5592,513]

theorem envBound33777 : H12AffineFastState.Bounded env33777 := by
  intro p hp
  have h : env33777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33776_33777 : H12AffineEnvironment.transform 21 8200 env33776 = env33777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env33776 == env33777) = true)

theorem identity33777 : scanCanonicalize (H12AffineFastState.compose env33777 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33777 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10280,1024,8540,4160,8200,16,3,8193,64,2420,5392,4096,2421,1365,8200,256,32,5457,513]

theorem envBound33778 : H12AffineFastState.Bounded env33778 := by
  intro p hp
  have h : env33778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33777_33778 : H12AffineEnvironment.transform 6 9 env33777 = env33778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33777 == env33778) = true)

theorem identity33778 : scanCanonicalize (H12AffineFastState.compose env33778 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33778 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33779 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8203,5392,10280,1024,8460,4112,8200,16,3,8193,16,2340,5392,4096,2341,1285,8200,256,32,5377,513]

theorem envBound33779 : H12AffineFastState.Bounded env33779 := by
  intro p hp
  have h : env33779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33778_33779 : H12AffineEnvironment.transform 5 16 env33778 = env33779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33778 == env33779) = true)

theorem identity33779 : scanCanonicalize (H12AffineFastState.compose env33779 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33779 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33780 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,4405,8461,8203,4389,10280,53,8460,4112,8200,16,3,8193,16,2340,4389,4096,2341,304,8200,256,32,4404,513]

theorem envBound33780 : H12AffineFastState.Bounded env33780 := by
  intro p hp
  have h : env33780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33779_33780 : H12AffineEnvironment.transform 9 53 env33779 = env33780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33779 == env33780) = true)

theorem identity33780 : scanCanonicalize (H12AffineFastState.compose env33780 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33780 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33781 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,4113,8233,8203,4097,10280,53,8232,4112,8200,16,3,8193,16,2048,4097,4096,2049,20,8200,36,32,4112,513]

theorem envBound33781 : H12AffineFastState.Bounded env33781 := by
  intro p hp
  have h : env33781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33780_33781 : H12AffineEnvironment.transform 7 36 env33780 = env33781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33780 == env33781) = true)

theorem identity33781 : scanCanonicalize (H12AffineFastState.compose env33781 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound33781 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33782 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,51,4113,26,56,4097,2075,53,27,4112,59,16,3,50,16,2048,4097,4096,2049,20,59,36,32,4112,513]

theorem envBound33782 : H12AffineFastState.Bounded env33782 := by
  intro p hp
  have h : env33782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33781_33782 : H12AffineEnvironment.transform 12 51 env33781 = env33782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env33781 == env33782) = true)

def env33783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5393,262144,1024,8540,4297,4194304,16,73736,8328,64,4456789,5392,4233,270684,1365,4194304,256,32,5592,74371]

theorem envBound33783 : H12AffineFastState.Bounded env33783 := by
  intro p hp
  have h : env33783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33773_33783 : H12AffineEnvironment.transform 16 5393 env33773 = env33783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33773 == env33783) = true)

def env33784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5393,10400,1024,8540,4297,4194304,16,73736,8328,64,4205045,5392,4233,2556,1365,4194304,256,32,5592,74371]

theorem envBound33784 : H12AffineFastState.Bounded env33784 := by
  intro p hp
  have h : env33784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33783_33784 : H12AffineEnvironment.transform 17 10400 env33783 = env33784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33783 == env33784) = true)

theorem identity33784 : scanCanonicalize (H12AffineFastState.compose env33784 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33784 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10400,1024,8540,4297,4194304,16,2,8328,64,4205045,5392,4233,2556,1365,4194304,256,32,5592,649]

theorem envBound33785 : H12AffineFastState.Bounded env33785 := by
  intro p hp
  have h : env33785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33784_33785 : H12AffineEnvironment.transform 15 8202 env33784 = env33785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33784 == env33785) = true)

theorem identity33785 : scanCanonicalize (H12AffineFastState.compose env33785 (packedSelected [0,7,9,11,14,16,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 8321) := by decide +kernel

theorem selectedBound33785 : packedSelected [0,7,9,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env33786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10400,1024,8540,4297,8321,16,2,8328,64,2420,5392,4233,2556,1365,8321,256,32,5592,649]

theorem envBound33786 : H12AffineFastState.Bounded env33786 := by
  intro p hp
  have h : env33786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33785_33786 : H12AffineEnvironment.transform 21 8321 env33785 = env33786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env33785 == env33786) = true)

theorem identity33786 : scanCanonicalize (H12AffineFastState.compose env33786 (packedSelected [0,2,4,6,7,9,14,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound33786 : packedSelected [0,2,4,6,7,9,14,16,20] rootPS < 2^1333 := by decide +kernel

def env33787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5376,509,170,5393,2048,1024,508,4297,33,16,2,40,64,2420,5392,4233,2556,1365,33,256,32,5592,649]

theorem envBound33787 : H12AffineFastState.Bounded env33787 := by
  intro p hp
  have h : env33787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33786_33787 : H12AffineEnvironment.transform 12 160 env33786 = env33787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env33786 == env33787) = true)

theorem identity33787 : scanCanonicalize (H12AffineFastState.compose env33787 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33787 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,372,35,5393,2048,1024,373,4160,33,16,2,40,64,2420,5392,4096,2421,1365,33,256,32,5457,512]

theorem envBound33788 : H12AffineFastState.Bounded env33788 := by
  intro p hp
  have h : env33788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33787_33788 : H12AffineEnvironment.transform 6 9 env33787 = env33788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33787 == env33788) = true)

theorem identity33788 : scanCanonicalize (H12AffineFastState.compose env33788 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound33788 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33789 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,41,5205,33,35,5188,2048,1024,32,4160,33,16,2,40,64,2081,5189,4096,2080,1024,33,85,32,5124,512]

theorem envBound33789 : H12AffineFastState.Bounded env33789 := by
  intro p hp
  have h : env33789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33788_33789 : H12AffineEnvironment.transform 7 85 env33788 = env33789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env33788 == env33789) = true)

theorem identity33789 : scanCanonicalize (H12AffineFastState.compose env33789 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound33789 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33790 : List Nat := [2,4,8,16,32,64,9,85,512,1024,32,4096,41,5205,33,35,5188,32,1024,32,4160,33,16,2,40,64,1,5189,4096,0,1024,33,85,32,5124,512]

theorem envBound33790 : H12AffineFastState.Bounded env33790 := by
  intro p hp
  have h : env33790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33789_33790 : H12AffineEnvironment.transform 10 32 env33789 = env33790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env33789 == env33790) = true)

theorem identity33790 : scanCanonicalize (H12AffineFastState.compose env33790 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33790 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33791 : List Nat := [2,4,8,16,1,64,9,85,512,1024,1,4096,8,5205,0,2,5188,1,1024,1,4160,0,16,2,9,64,1,5189,4096,0,1024,0,85,1,5124,512]

theorem envBound33791 : H12AffineFastState.Bounded env33791 := by
  intro p hp
  have h : env33791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33790_33791 : H12AffineEnvironment.transform 4 1 env33790 = env33791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33790 == env33791) = true)

theorem identity33791 : scanCanonicalize (H12AffineFastState.compose env33791 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound33791 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33792 : List Nat := [2,4,8,16,1,64,9,85,512,1024,1,1550,8,603,0,2,586,1,1024,1,1614,0,16,2,9,64,1,587,1550,0,1024,0,85,1,522,512]

theorem envBound33792 : H12AffineFastState.Bounded env33792 := by
  intro p hp
  have h : env33792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33791_33792 : H12AffineEnvironment.transform 11 1550 env33791 = env33792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env33791 == env33792) = true)

theorem identity33792 : scanCanonicalize (H12AffineFastState.compose env33792 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound33792 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env33793 : List Nat := [2,4,8,16,1,64,9,85,18,1024,1,1052,8,73,0,2,88,1,1024,1,1116,0,16,2,9,64,1,89,1052,0,1024,0,85,1,24,18]

theorem envBound33793 : H12AffineFastState.Bounded env33793 := by
  intro p hp
  have h : env33793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33792_33793 : H12AffineEnvironment.transform 8 18 env33792 = env33793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env33792 == env33793) = true)

theorem identity33793 : scanCanonicalize (H12AffineFastState.compose env33793 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 93) := by decide +kernel

theorem selectedBound33793 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33794 : List Nat := [2,4,8,16,1,64,9,85,18,93,1,65,8,73,0,2,88,1,93,1,1,0,16,2,9,64,1,89,65,0,93,0,85,1,24,18]

theorem envBound33794 : H12AffineFastState.Bounded env33794 := by
  intro p hp
  have h : env33794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33793_33794 : H12AffineEnvironment.transform 9 93 env33793 = env33794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 93 env33793 == env33794) = true)

theorem identity33794 : scanCanonicalize (H12AffineFastState.compose env33794 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33795 : List Nat := [2,3,8,16,1,64,9,82,18,90,1,65,8,73,0,2,88,1,90,1,1,0,16,2,9,64,1,89,65,0,90,0,82,1,24,18]

theorem envBound33795 : H12AffineFastState.Bounded env33795 := by
  intro p hp
  have h : env33795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33794_33795 : H12AffineEnvironment.transform 1 3 env33794 = env33795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33794 == env33795) = true)

theorem identity33795 : scanCanonicalize (H12AffineFastState.compose env33795 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound33795 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33796 : List Nat := [2,3,8,16,1,8,9,26,18,18,1,9,8,1,0,2,16,1,18,1,1,0,16,2,9,8,1,17,9,0,18,0,26,1,24,18]

theorem envBound33796 : H12AffineFastState.Bounded env33796 := by
  intro p hp
  have h : env33796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33795_33796 : H12AffineEnvironment.transform 5 8 env33795 = env33796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env33795 == env33796) = true)

def env33797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5393,10401,1024,8540,4297,4194304,16,73736,8328,64,4205044,5392,4233,2557,1365,4194304,256,32,5592,74371]

theorem envBound33797 : H12AffineFastState.Bounded env33797 := by
  intro p hp
  have h : env33797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33783_33797 : H12AffineEnvironment.transform 17 10401 env33783 = env33797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33783 == env33797) = true)

theorem identity33797 : scanCanonicalize (H12AffineFastState.compose env33797 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound33797 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5393,10401,1024,8540,4297,4194304,16,138,8328,64,4205044,5392,4233,2557,1365,4194304,256,32,5592,513]

theorem envBound33798 : H12AffineFastState.Bounded env33798 := by
  intro p hp
  have h : env33798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33797_33798 : H12AffineEnvironment.transform 15 8322 env33797 = env33798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env33797 == env33798) = true)

theorem identity33798 : scanCanonicalize (H12AffineFastState.compose env33798 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33798 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env33799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10281,1024,8540,4161,4194304,16,2,8192,64,4204924,5392,4097,2421,1365,4194304,256,32,5456,513]

theorem envBound33799 : H12AffineFastState.Bounded env33799 := by
  intro p hp
  have h : env33799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33798_33799 : H12AffineEnvironment.transform 6 8 env33798 = env33799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33798 == env33799) = true)

theorem identity33799 : scanCanonicalize (H12AffineFastState.compose env33799 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound33799 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10281,1024,8540,4161,33,16,2,8192,64,10589,5392,4097,2421,1365,33,256,32,5456,513]

theorem envBound33800 : H12AffineFastState.Bounded env33800 := by
  intro p hp
  have h : env33800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33799_33800 : H12AffineEnvironment.transform 21 33 env33799 = env33800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env33799 == env33800) = true)

theorem identity33800 : scanCanonicalize (H12AffineFastState.compose env33800 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound33800 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5376,32,375,5393,2388,1024,33,4161,33,16,2,381,64,2080,5392,4097,2421,1365,33,256,32,5456,513]

theorem envBound33801 : H12AffineFastState.Bounded env33801 := by
  intro p hp
  have h : env33801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33800_33801 : H12AffineEnvironment.transform 12 381 env33800 = env33801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env33800 == env33801) = true)

theorem identity33801 : scanCanonicalize (H12AffineFastState.compose env33801 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33801 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33802 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5376,0,343,5393,2388,1024,1,4161,1,16,2,349,64,2048,5392,4097,2389,1365,1,256,0,5456,513]

theorem envBound33802 : H12AffineFastState.Bounded env33802 := by
  intro p hp
  have h : env33802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33801_33802 : H12AffineEnvironment.transform 4 0 env33801 = env33802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33801 == env33802) = true)

theorem identity33802 : scanCanonicalize (H12AffineFastState.compose env33802 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 836) := by decide +kernel

theorem selectedBound33802 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33803 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,836,349,1604,0,343,1621,2388,1024,1,773,1,16,2,349,64,2048,1620,837,2389,1365,1,256,0,1556,513]

theorem envBound33803 : H12AffineFastState.Bounded env33803 := by
  intro p hp
  have h : env33803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33802_33803 : H12AffineEnvironment.transform 11 836 env33802 = env33803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 836 env33802 == env33803) = true)

theorem identity33803 : scanCanonicalize (H12AffineFastState.compose env33803 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound33803 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33804 : List Nat := [2,4,8,16,0,64,8,256,512,1024,528,836,349,1604,0,343,1621,836,1024,1,773,1,16,2,349,64,528,1620,837,837,1365,1,256,0,1556,513]

theorem envBound33804 : H12AffineFastState.Bounded env33804 := by
  intro p hp
  have h : env33804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33803_33804 : H12AffineEnvironment.transform 10 528 env33803 = env33804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env33803 == env33804) = true)

def env33805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,17,98645,8328,64,4592708,5393,4232,431376,1364,4235613,256,33,46213,74370]

theorem envBound33805 : H12AffineFastState.Bounded env33805 := by
  intro p hp
  have h : env33805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33771_33805 : H12AffineEnvironment.transform 13 5377 env33771 = env33805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33771 == env33805) = true)

theorem identity33805 : scanCanonicalize (H12AffineFastState.compose env33805 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41460) := by decide +kernel

theorem selectedBound33805 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,41460,17,98645,8328,64,439728,5393,4232,431376,1364,169,256,33,46213,74370]

theorem envBound33806 : H12AffineFastState.Bounded env33806 := by
  intro p hp
  have h : env33806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33805_33806 : H12AffineEnvironment.transform 21 41460 env33805 = env33806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41460 env33805 == env33806) = true)

def env33807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,41340,17,98645,8192,64,439608,5393,4096,431376,1364,33,256,33,46093,74250]

theorem envBound33807 : H12AffineFastState.Bounded env33807 := by
  intro p hp
  have h : env33807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33806_33807 : H12AffineEnvironment.transform 6 8 env33806 = env33807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33806 == env33807) = true)

theorem identity33807 : scanCanonicalize (H12AffineFastState.compose env33807 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33807 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,4160,41340,17,98645,8192,64,171281,5393,4096,179513,1364,33,256,33,46093,74250]

theorem envBound33808 : H12AffineFastState.Bounded env33808 := by
  intro p hp
  have h : env33808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33807_33808 : H12AffineEnvironment.transform 17 10281 env33807 = env33808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33807 == env33808) = true)

theorem identity33808 : scanCanonicalize (H12AffineFastState.compose env33808 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 103447) := by decide +kernel

theorem selectedBound33808 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103447,10281,1024,32769,4160,41340,17,98645,8192,64,67846,5393,4096,76078,1364,33,256,33,46093,74250]

theorem envBound33809 : H12AffineFastState.Bounded env33809 := by
  intro p hp
  have h : env33809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33808_33809 : H12AffineEnvironment.transform 16 103447 env33808 = env33809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103447 env33808 == env33809) = true)

theorem identity33809 : scanCanonicalize (H12AffineFastState.compose env33809 (packedSelected [0,1,5,7,8,9,12,14,15,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound33809 : packedSelected [0,1,5,7,8,9,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env33810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33031,5392,10281,1024,32769,4160,41340,17,82,8192,64,34817,5393,4096,43049,1364,33,256,33,46093,41741]

theorem envBound33810 : H12AffineFastState.Bounded env33810 := by
  intro p hp
  have h : env33810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33809_33810 : H12AffineEnvironment.transform 15 33031 env33809 = env33810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env33809 == env33810) = true)

theorem identity33810 : scanCanonicalize (H12AffineFastState.compose env33810 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound33810 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,32768,33031,5392,2341,1024,32769,4160,32880,17,82,268,64,34817,5393,4096,35109,1364,33,256,33,38145,33281]

theorem envBound33811 : H12AffineFastState.Bounded env33811 := by
  intro p hp
  have h : env33811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33810_33811 : H12AffineEnvironment.transform 12 268 env33810 = env33811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env33810 == env33811) = true)

theorem identity33811 : scanCanonicalize (H12AffineFastState.compose env33811 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound33811 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,343,5392,2341,1024,81,4160,32,17,82,268,64,2129,5393,4096,2421,1364,33,256,33,5457,593]

theorem envBound33812 : H12AffineFastState.Bounded env33812 := by
  intro p hp
  have h : env33812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33811_33812 : H12AffineEnvironment.transform 14 80 env33811 = env33812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env33811 == env33812) = true)

theorem identity33812 : scanCanonicalize (H12AffineFastState.compose env33812 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound33812 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33813 : List Nat := [2,4,8,16,32,43,8,256,512,1024,2048,4096,268,5377,59,316,5392,2341,1024,58,4139,32,17,57,268,43,2106,5393,4096,2334,1343,33,256,33,5434,570]

theorem envBound33813 : H12AffineFastState.Bounded env33813 := by
  intro p hp
  have h : env33813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33812_33813 : H12AffineEnvironment.transform 5 43 env33812 = env33813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env33812 == env33813) = true)

theorem identity33813 : scanCanonicalize (H12AffineFastState.compose env33813 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33813 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33814 : List Nat := [2,4,8,16,32,43,8,5,512,1024,2048,4096,9,5124,59,57,5141,2080,1024,58,4139,32,17,57,9,43,2106,5140,4096,2075,1082,33,5,33,5183,570]

theorem envBound33814 : H12AffineFastState.Bounded env33814 := by
  intro p hp
  have h : env33814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33813_33814 : H12AffineEnvironment.transform 7 5 env33813 = env33814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33813 == env33814) = true)

theorem identity33814 : scanCanonicalize (H12AffineFastState.compose env33814 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound33814 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env33815 : List Nat := [2,4,8,16,32,43,8,5,512,1024,1087,4096,9,5124,59,57,5141,1055,1024,58,4139,32,17,57,9,43,1029,5140,4096,1060,1082,33,5,33,5183,570]

theorem envBound33815 : H12AffineFastState.Bounded env33815 := by
  intro p hp
  have h : env33815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33814_33815 : H12AffineEnvironment.transform 10 1087 env33814 = env33815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env33814 == env33815) = true)

theorem identity33815 : scanCanonicalize (H12AffineFastState.compose env33815 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound33815 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env33816 : List Nat := [2,4,8,16,32,43,8,5,512,1024,1087,1060,9,32,59,57,49,1055,1024,58,1039,32,17,57,9,43,1029,48,1060,1060,1082,33,5,33,27,570]

theorem envBound33816 : H12AffineFastState.Bounded env33816 := by
  intro p hp
  have h : env33816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33815_33816 : H12AffineEnvironment.transform 11 1060 env33815 = env33816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env33815 == env33816) = true)

def env33817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,41341,17,98645,8193,64,439609,5393,4097,431376,1364,32,256,33,46092,74251]

theorem envBound33817 : H12AffineFastState.Bounded env33817 := by
  intro p hp
  have h : env33817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33806_33817 : H12AffineEnvironment.transform 6 9 env33806 = env33817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33806 == env33817) = true)

theorem identity33817 : scanCanonicalize (H12AffineFastState.compose env33817 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound33817 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1024,32769,4161,41341,17,98645,8193,64,146508,5393,4097,138341,1364,32,256,33,46092,74251]

theorem envBound33818 : H12AffineFastState.Bounded env33818 := by
  intro p hp
  have h : env33818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33817_33818 : H12AffineEnvironment.transform 17 35189 env33817 = env33818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env33817 == env33818) = true)

theorem identity33818 : scanCanonicalize (H12AffineFastState.compose env33818 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33818 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5392,35189,1024,32769,4161,41341,17,98645,8193,64,10588,5393,4097,2421,1364,32,256,33,46092,74251]

theorem envBound33819 : H12AffineFastState.Bounded env33819 := by
  intro p hp
  have h : env33819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33818_33819 : H12AffineEnvironment.transform 16 5392 env33818 = env33819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33818 == env33819) = true)

theorem identity33819 : scanCanonicalize (H12AffineFastState.compose env33819 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound33819 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,41051,5392,35189,1024,32769,4161,41341,17,8462,8193,64,10588,5393,4097,2421,1364,32,256,33,46092,33360]

theorem envBound33820 : H12AffineFastState.Bounded env33820 := by
  intro p hp
  have h : env33820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33819_33820 : H12AffineEnvironment.transform 15 41051 env33819 = env33820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env33819 == env33820) = true)

theorem identity33820 : scanCanonicalize (H12AffineFastState.compose env33820 (packedSelected [0,4,5,8,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound33820 : packedSelected [0,4,5,8,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env33821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,8203,5392,2341,1024,81,4161,8493,17,8462,8193,64,10588,5393,4097,2421,1364,32,256,33,13404,512]

theorem envBound33821 : H12AffineFastState.Bounded env33821 := by
  intro p hp
  have h : env33821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33820_33821 : H12AffineEnvironment.transform 14 80 env33820 = env33821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env33820 == env33821) = true)

theorem identity33821 : scanCanonicalize (H12AffineFastState.compose env33821 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33821 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env33822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,262,5392,2341,1024,81,4161,32,17,3,268,64,2129,5393,4097,2421,1364,32,256,33,5457,512]

theorem envBound33822 : H12AffineFastState.Bounded env33822 := by
  intro p hp
  have h : env33822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33821_33822 : H12AffineEnvironment.transform 12 269 env33821 = env33822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33821 == env33822) = true)

theorem identity33822 : scanCanonicalize (H12AffineFastState.compose env33822 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound33822 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33823 : List Nat := [2,4,8,16,32,64,9,256,512,880,2048,4096,269,4721,80,262,4704,2341,880,81,4161,32,17,3,268,64,2129,4705,4097,2421,548,32,256,33,4641,512]

theorem envBound33823 : H12AffineFastState.Bounded env33823 := by
  intro p hp
  have h : env33823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33822_33823 : H12AffineEnvironment.transform 9 880 env33822 = env33823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env33822 == env33823) = true)

theorem identity33823 : scanCanonicalize (H12AffineFastState.compose env33823 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound33823 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33824 : List Nat := [2,4,8,16,32,64,9,256,512,880,2048,2404,269,2837,80,262,2820,2341,880,81,2341,32,17,3,268,64,2129,2821,2405,2421,548,32,256,33,2885,512]

theorem envBound33824 : H12AffineFastState.Bounded env33824 := by
  intro p hp
  have h : env33824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33823_33824 : H12AffineEnvironment.transform 11 2404 env33823 = env33824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env33823 == env33824) = true)

theorem identity33824 : scanCanonicalize (H12AffineFastState.compose env33824 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33824 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33825 : List Nat := [2,4,8,16,1,64,9,256,512,849,2048,2373,269,2837,80,262,2820,2308,849,81,2308,1,17,3,268,64,2129,2821,2372,2388,517,1,256,0,2885,512]

theorem envBound33825 : H12AffineFastState.Bounded env33825 := by
  intro p hp
  have h : env33825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33824_33825 : H12AffineEnvironment.transform 4 1 env33824 = env33825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33824 == env33825) = true)

theorem identity33825 : scanCanonicalize (H12AffineFastState.compose env33825 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound33825 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env33826 : List Nat := [2,4,8,16,1,64,9,256,80,257,2048,2373,269,2373,80,262,2388,2308,257,81,2308,1,17,3,268,64,2129,2389,2372,2388,85,1,256,0,2325,80]

theorem envBound33826 : H12AffineFastState.Bounded env33826 := by
  intro p hp
  have h : env33826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33825_33826 : H12AffineEnvironment.transform 8 80 env33825 = env33826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env33825 == env33826) = true)

theorem identity33826 : scanCanonicalize (H12AffineFastState.compose env33826 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound33826 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env33827 : List Nat := [2,4,8,16,1,64,9,84,80,85,2048,2065,89,2065,80,82,2048,2128,85,81,2128,1,17,3,88,64,2129,2049,2064,2048,85,1,84,0,2113,80]

theorem envBound33827 : H12AffineFastState.Bounded env33827 := by
  intro p hp
  have h : env33827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33826_33827 : H12AffineEnvironment.transform 7 84 env33826 = env33827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env33826 == env33827) = true)

theorem identity33827 : scanCanonicalize (H12AffineFastState.compose env33827 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33827 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33828 : List Nat := [2,4,8,16,1,16,9,4,0,5,2048,2065,9,2065,0,2,2048,2048,5,1,2048,1,17,3,8,16,2049,2049,2064,2048,5,1,4,0,2065,0]

theorem envBound33828 : H12AffineFastState.Bounded env33828 := by
  intro p hp
  have h : env33828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33827_33828 : H12AffineEnvironment.transform 5 16 env33827 = env33828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33827 == env33828) = true)

theorem identity33828 : scanCanonicalize (H12AffineFastState.compose env33828 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound33828 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33829 : List Nat := [2,4,8,16,1,16,9,4,0,5,17,0,9,0,0,2,17,17,5,1,17,1,17,3,8,16,16,16,1,17,5,1,4,0,0,0]

theorem envBound33829 : H12AffineFastState.Bounded env33829 := by
  intro p hp
  have h : env33829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33828_33829 : H12AffineEnvironment.transform 10 17 env33828 = env33829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env33828 == env33829) = true)

theorem identity33829 : scanCanonicalize (H12AffineFastState.compose env33829 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33829 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env33830 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,0,9,0,0,2,0,0,5,1,0,1,0,3,8,1,1,1,1,0,5,1,4,0,0,0]

theorem envBound33830 : H12AffineFastState.Bounded env33830 := by
  intro p hp
  have h : env33830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33829_33830 : H12AffineEnvironment.transform 3 1 env33829 = env33830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33829 == env33830) = true)

theorem identity33830 : scanCanonicalize (H12AffineFastState.compose env33830 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound33830 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33831 : List Nat := [2,4,7,1,1,1,6,4,0,5,0,0,6,0,0,2,0,0,5,1,0,1,0,3,7,1,1,1,1,0,5,1,4,0,0,0]

theorem envBound33831 : H12AffineFastState.Bounded env33831 := by
  intro p hp
  have h : env33831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33830_33831 : H12AffineEnvironment.transform 2 7 env33830 = env33831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env33830 == env33831) = true)

def env33832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21777,2213020,8328,64,6705548,16400,2097217,431377,2102685,4235613,256,21793,46212,2175563]

theorem envBound33832 : H12AffineFastState.Bounded env33832 := by
  intro p hp
  have h : env33832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33738_33832 : H12AffineEnvironment.transform 22 21777 env33738 = env33832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21777 env33738 == env33832) = true)

def env33833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21777,98644,8328,64,4592708,16400,17801,431377,20565,4235613,256,21793,46212,96131]

theorem envBound33833 : H12AffineFastState.Bounded env33833 := by
  intro p hp
  have h : env33833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33832_33833 : H12AffineEnvironment.transform 20 17864 env33832 = env33833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env33832 == env33833) = true)

def env33834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,17,98644,8328,64,4592708,5392,4233,431377,1365,4235613,256,33,46212,74371]

theorem envBound33834 : H12AffineFastState.Bounded env33834 := by
  intro p hp
  have h : env33834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33833_33834 : H12AffineEnvironment.transform 13 5376 env33833 = env33834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33833 == env33834) = true)

theorem identity33834 : scanCanonicalize (H12AffineFastState.compose env33834 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound33834 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,73890,17,98644,8328,64,472294,5392,4233,431377,1365,98815,256,33,46212,74371]

theorem envBound33835 : H12AffineFastState.Bounded env33835 := by
  intro p hp
  have h : env33835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33834_33835 : H12AffineEnvironment.transform 21 73890 env33834 = env33835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env33834 == env33835) = true)

def env33836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,73770,17,98644,8192,64,472174,5392,4097,431377,1365,98679,256,33,46092,74251]

theorem envBound33836 : H12AffineFastState.Bounded env33836 := by
  intro p hp
  have h : env33836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33835_33836 : H12AffineEnvironment.transform 6 8 env33835 = env33836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33835 == env33836) = true)

theorem identity33836 : scanCanonicalize (H12AffineFastState.compose env33836 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33836 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4160,73770,17,98644,8192,64,203847,5392,4097,179512,1365,98679,256,33,46092,74251]

theorem envBound33837 : H12AffineFastState.Bounded env33837 := by
  intro p hp
  have h : env33837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33836_33837 : H12AffineEnvironment.transform 17 10281 env33836 = env33837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33836 == env33837) = true)

theorem identity33837 : scanCanonicalize (H12AffineFastState.compose env33837 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33837 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10281,1024,32769,4160,33,17,41311,8192,64,146508,5392,4097,179512,1365,41340,256,33,46092,512]

theorem envBound33838 : H12AffineFastState.Bounded env33838 := by
  intro p hp
  have h : env33838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33837_33838 : H12AffineEnvironment.transform 15 8203 env33837 = env33838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33837 == env33838) = true)

theorem identity33838 : scanCanonicalize (H12AffineFastState.compose env33838 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound33838 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1124,8203,131072,10281,1024,1125,4160,33,17,9531,8192,64,146508,5392,4097,145756,1365,9496,256,33,12392,512]

theorem envBound33839 : H12AffineFastState.Bounded env33839 := by
  intro p hp
  have h : env33839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33838_33839 : H12AffineEnvironment.transform 14 1124 env33838 = env33839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env33838 == env33839) = true)

theorem identity33839 : scanCanonicalize (H12AffineFastState.compose env33839 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 8248) := by decide +kernel

theorem selectedBound33839 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1124,8203,8248,10281,1024,1125,4160,33,17,9531,8192,64,7284,5392,4097,6500,1365,9496,256,33,12392,512]

theorem envBound33840 : H12AffineFastState.Bounded env33840 := by
  intro p hp
  have h : env33840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33839_33840 : H12AffineEnvironment.transform 16 8248 env33839 = env33840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8248 env33839 == env33840) = true)

theorem identity33840 : scanCanonicalize (H12AffineFastState.compose env33840 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound33840 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,1124,1095,1140,3173,1024,1125,4160,33,17,375,1100,64,7284,5392,4097,6500,1365,340,256,33,5156,512]

theorem envBound33841 : H12AffineFastState.Bounded env33841 := by
  intro p hp
  have h : env33841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33840_33841 : H12AffineEnvironment.transform 12 1100 env33840 = env33841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env33840 == env33841) = true)

theorem identity33841 : scanCanonicalize (H12AffineFastState.compose env33841 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound33841 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,4096,1100,5376,1124,1095,1140,1076,1024,1125,4160,33,17,375,1100,64,5157,5392,4097,4405,1365,340,256,33,5156,512]

theorem envBound33842 : H12AffineFastState.Bounded env33842 := by
  intro p hp
  have h : env33842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33841_33842 : H12AffineEnvironment.transform 10 81 env33841 = env33842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env33841 == env33842) = true)

theorem identity33842 : scanCanonicalize (H12AffineFastState.compose env33842 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound33842 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env33843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1281,1100,1,1124,1095,1140,1076,1024,1125,1345,33,17,375,1100,64,292,17,1280,1076,1365,340,256,33,293,512]

theorem envBound33843 : H12AffineFastState.Bounded env33843 := by
  intro p hp
  have h : env33843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33842_33843 : H12AffineEnvironment.transform 11 1281 env33842 = env33843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env33842 == env33843) = true)

theorem identity33843 : scanCanonicalize (H12AffineFastState.compose env33843 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound33843 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33844 : List Nat := [2,4,8,16,32,64,8,256,512,304,81,49,380,1,340,375,324,260,304,341,113,33,17,375,380,64,292,17,48,260,101,340,256,33,293,512]

theorem envBound33844 : H12AffineFastState.Bounded env33844 := by
  intro p hp
  have h : env33844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33843_33844 : H12AffineEnvironment.transform 9 304 env33843 = env33844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env33843 == env33844) = true)

theorem identity33844 : scanCanonicalize (H12AffineFastState.compose env33844 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound33844 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33845 : List Nat := [2,4,8,16,32,64,8,84,512,100,81,49,40,1,0,35,16,80,100,1,113,33,17,35,40,64,112,17,48,80,101,0,84,33,113,512]

theorem envBound33845 : H12AffineFastState.Bounded env33845 := by
  intro p hp
  have h : env33845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33844_33845 : H12AffineEnvironment.transform 7 84 env33844 = env33845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env33844 == env33845) = true)

theorem identity33845 : scanCanonicalize (H12AffineFastState.compose env33845 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33845 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33846 : List Nat := [2,4,8,16,32,0,8,20,512,36,17,49,40,1,0,35,16,16,36,1,49,33,17,35,40,0,48,17,48,16,37,0,20,33,49,512]

theorem envBound33846 : H12AffineFastState.Bounded env33846 := by
  intro p hp
  have h : env33846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33845_33846 : H12AffineEnvironment.transform 5 0 env33845 = env33846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33845 == env33846) = true)

theorem identity33846 : scanCanonicalize (H12AffineFastState.compose env33846 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33846 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33847 : List Nat := [2,4,8,16,32,0,8,20,1,36,17,49,40,1,0,35,16,16,36,1,49,33,17,35,40,0,48,17,48,16,37,0,20,33,49,1]

theorem envBound33847 : H12AffineFastState.Bounded env33847 := by
  intro p hp
  have h : env33847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33846_33847 : H12AffineEnvironment.transform 8 1 env33846 = env33847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33846 == env33847) = true)

theorem identity33847 : scanCanonicalize (H12AffineFastState.compose env33847 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33847 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33848 : List Nat := [2,4,8,16,1,0,8,20,1,5,17,16,9,1,0,2,16,16,5,1,16,0,17,2,9,0,17,17,17,16,4,0,20,0,16,1]

theorem envBound33848 : H12AffineFastState.Bounded env33848 := by
  intro p hp
  have h : env33848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33847_33848 : H12AffineEnvironment.transform 4 1 env33847 = env33848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33847 == env33848) = true)

theorem identity33848 : scanCanonicalize (H12AffineFastState.compose env33848 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound33848 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33849 : List Nat := [2,4,8,15,1,0,8,11,1,5,14,15,9,1,0,2,15,15,5,1,15,0,14,2,9,0,14,14,14,15,4,0,11,0,15,1]

theorem envBound33849 : H12AffineFastState.Bounded env33849 := by
  intro p hp
  have h : env33849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33848_33849 : H12AffineEnvironment.transform 3 15 env33848 = env33849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env33848 == env33849) = true)

theorem identity33849 : scanCanonicalize (H12AffineFastState.compose env33849 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound33849 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33850 : List Nat := [2,4,7,0,1,0,7,4,1,5,1,0,6,1,0,2,0,0,5,1,0,0,1,2,6,0,1,1,1,0,4,0,4,0,0,1]

theorem envBound33850 : H12AffineFastState.Bounded env33850 := by
  intro p hp
  have h : env33850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33849_33850 : H12AffineEnvironment.transform 2 7 env33849 = env33850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env33849 == env33850) = true)

def env33851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,73771,17,98644,8193,64,472175,5392,4096,431377,1365,98678,256,33,46093,74250]

theorem envBound33851 : H12AffineFastState.Bounded env33851 := by
  intro p hp
  have h : env33851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33835_33851 : H12AffineEnvironment.transform 6 9 env33835 = env33851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33835 == env33851) = true)

theorem identity33851 : scanCanonicalize (H12AffineFastState.compose env33851 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound33851 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1024,32769,4161,73771,17,98644,8193,64,245018,5392,4096,138340,1365,98678,256,33,46093,74250]

theorem envBound33852 : H12AffineFastState.Bounded env33852 := by
  intro p hp
  have h : env33852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33851_33852 : H12AffineEnvironment.transform 17 35189 env33851 = env33852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env33851 == env33852) = true)

theorem identity33852 : scanCanonicalize (H12AffineFastState.compose env33852 (packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 111946) := by decide +kernel

theorem selectedBound33852 : packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,111946,35189,1024,32769,4161,73771,17,98644,8193,64,2128,5392,4096,108846,1365,98678,256,33,46093,74250]

theorem envBound33853 : H12AffineFastState.Bounded env33853 := by
  intro p hp
  have h : env33853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33852_33853 : H12AffineEnvironment.transform 16 111946 env33852 = env33853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111946 env33852 == env33853) = true)

theorem identity33853 : scanCanonicalize (H12AffineFastState.compose env33853 (packedSelected [1,2,4,5,6,8,10,11,14,16,19,20,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound33853 : packedSelected [1,2,4,5,6,8,10,11,14,16,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env33854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8574,37940,35189,1024,32769,4161,341,17,41002,8193,64,2128,5392,4096,34896,1365,40968,256,33,46093,884]

theorem envBound33854 : H12AffineFastState.Bounded env33854 := by
  intro p hp
  have h : env33854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33853_33854 : H12AffineEnvironment.transform 15 8574 env33853 = env33854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env33853 == env33854) = true)

theorem identity33854 : scanCanonicalize (H12AffineFastState.compose env33854 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound33854 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env33855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,8574,5221,2340,1024,80,4161,341,17,8315,8193,64,2128,5392,4096,2049,1365,8281,256,33,13404,884]

theorem envBound33855 : H12AffineFastState.Bounded env33855 := by
  intro p hp
  have h : env33855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33854_33855 : H12AffineEnvironment.transform 14 81 env33854 = env33855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env33854 == env33855) = true)

theorem identity33855 : scanCanonicalize (H12AffineFastState.compose env33855 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33855 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33856 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,81,8203,5221,2129,1024,80,4161,32,17,8315,8193,64,2128,5221,4096,2049,1056,8281,117,33,13404,513]

theorem envBound33856 : H12AffineFastState.Bounded env33856 := by
  intro p hp
  have h : env33856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33855_33856 : H12AffineEnvironment.transform 7 117 env33855 = env33856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33855 == env33856) = true)

theorem identity33856 : scanCanonicalize (H12AffineFastState.compose env33856 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 5660) := by decide +kernel

theorem selectedBound33856 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33857 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,5660,5237,81,5655,5221,2129,1024,80,4161,32,17,5735,5661,64,2128,5221,4096,2049,1056,5701,117,33,576,513]

theorem envBound33857 : H12AffineFastState.Bounded env33857 := by
  intro p hp
  have h : env33857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33856_33857 : H12AffineEnvironment.transform 12 5660 env33856 = env33857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5660 env33856 == env33857) = true)

theorem identity33857 : scanCanonicalize (H12AffineFastState.compose env33857 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound33857 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33858 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1589,41,576,81,34,592,2129,1024,80,1652,32,17,82,40,64,2128,592,1589,2049,1056,112,117,33,576,513]

theorem envBound33858 : H12AffineFastState.Bounded env33858 := by
  intro p hp
  have h : env33858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33857_33858 : H12AffineEnvironment.transform 11 1589 env33857 = env33858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env33857 == env33858) = true)

def env33859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,16,98644,8328,64,4592708,5393,4232,431377,1364,4235613,256,32,46212,74370]

theorem envBound33859 : H12AffineFastState.Bounded env33859 := by
  intro p hp
  have h : env33859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33833_33859 : H12AffineEnvironment.transform 13 5377 env33833 = env33859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33833 == env33859) = true)

theorem identity33859 : scanCanonicalize (H12AffineFastState.compose env33859 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33859 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,4194304,16,41311,8328,64,4592708,5393,4232,431377,1364,4235613,256,32,46212,649]

theorem envBound33860 : H12AffineFastState.Bounded env33860 := by
  intro p hp
  have h : env33860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33859_33860 : H12AffineEnvironment.transform 15 8203 env33859 = env33860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33859 == env33860) = true)

theorem identity33860 : scanCanonicalize (H12AffineFastState.compose env33860 (packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS)) = affineNative (2^(21+1) ^^^ 297221) := by decide +kernel

theorem selectedBound33860 : packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env33861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,297221,16,41311,8328,64,171329,5393,4232,431377,1364,272472,256,32,46212,649]

theorem envBound33861 : H12AffineFastState.Bounded env33861 := by
  intro p hp
  have h : env33861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33860_33861 : H12AffineEnvironment.transform 21 297221 env33860 = env33861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297221 env33860 == env33861) = true)

def env33862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,297221,16,41311,8192,64,171329,5393,4096,431377,1364,272472,256,32,46092,513]

theorem envBound33862 : H12AffineFastState.Bounded env33862 := by
  intro p hp
  have h : env33862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33861_33862 : H12AffineEnvironment.transform 6 8 env33861 = env33862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33861 == env33862) = true)

theorem identity33862 : scanCanonicalize (H12AffineFastState.compose env33862 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33862 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env33863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4161,272472,16,2,8192,64,146460,5393,4096,406604,1364,272472,256,32,5457,513]

theorem envBound33863 : H12AffineFastState.Bounded env33863 := by
  intro p hp
  have h : env33863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33862_33863 : H12AffineEnvironment.transform 14 8541 env33862 = env33863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33862 == env33863) = true)

theorem identity33863 : scanCanonicalize (H12AffineFastState.compose env33863 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound33863 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10361,1024,8540,4161,33,16,2,8192,64,146460,5393,4096,138293,1364,33,256,32,5457,513]

theorem envBound33864 : H12AffineFastState.Bounded env33864 := by
  intro p hp
  have h : env33864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33863_33864 : H12AffineEnvironment.transform 17 10361 env33863 = env33864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env33863 == env33864) = true)

theorem identity33864 : scanCanonicalize (H12AffineFastState.compose env33864 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound33864 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13388,10361,1024,8540,4161,33,16,2,8192,64,2128,5393,4096,10361,1364,33,256,32,5457,513]

theorem envBound33865 : H12AffineFastState.Bounded env33865 := by
  intro p hp
  have h : env33865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33864_33865 : H12AffineEnvironment.transform 16 13388 env33864 = env33865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env33864 == env33865) = true)

theorem identity33865 : scanCanonicalize (H12AffineFastState.compose env33865 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33865 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33866 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,13340,10281,1024,8460,4113,33,16,2,8192,16,2048,5393,4096,10281,1284,33,256,32,5377,513]

theorem envBound33866 : H12AffineFastState.Bounded env33866 := by
  intro p hp
  have h : env33866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33865_33866 : H12AffineEnvironment.transform 5 16 env33865 = env33866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33865 == env33866) = true)

theorem identity33866 : scanCanonicalize (H12AffineFastState.compose env33866 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33866 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33867 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1024,1,4113,33,16,2,269,16,2048,5393,4096,2340,1284,33,256,32,5377,513]

theorem envBound33867 : H12AffineFastState.Bounded env33867 := by
  intro p hp
  have h : env33867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33866_33867 : H12AffineEnvironment.transform 12 269 env33866 = env33867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33866 == env33867) = true)

theorem identity33867 : scanCanonicalize (H12AffineFastState.compose env33867 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33867 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33868 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,34,5173,2048,1024,1,4113,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound33868 : H12AffineFastState.Bounded env33868 := by
  intro p hp
  have h : env33868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33867_33868 : H12AffineEnvironment.transform 7 36 env33867 = env33868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33867 == env33868) = true)

def env33869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4160,297221,16,41311,8193,64,171329,5393,4097,431377,1364,272472,256,32,46093,512]

theorem envBound33869 : H12AffineFastState.Bounded env33869 := by
  intro p hp
  have h : env33869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33861_33869 : H12AffineEnvironment.transform 6 9 env33861 = env33869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33861 == env33869) = true)

theorem identity33869 : scanCanonicalize (H12AffineFastState.compose env33869 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 171281) := by decide +kernel

theorem selectedBound33869 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,171281,1024,32769,4160,136212,16,41311,8193,64,171329,5393,4097,2048,1364,177481,256,32,46093,512]

theorem envBound33870 : H12AffineFastState.Bounded env33870 := by
  intro p hp
  have h : env33870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33869_33870 : H12AffineEnvironment.transform 17 171281 env33869 = env33870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171281 env33869 == env33870) = true)

theorem identity33870 : scanCanonicalize (H12AffineFastState.compose env33870 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33870 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146508,1024,8540,4160,136212,16,2,8193,64,146460,5393,4097,2048,1364,136212,256,32,5456,512]

theorem envBound33871 : H12AffineFastState.Bounded env33871 := by
  intro p hp
  have h : env33871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33870_33871 : H12AffineEnvironment.transform 14 8541 env33870 = env33871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33870 == env33871) = true)

theorem identity33871 : scanCanonicalize (H12AffineFastState.compose env33871 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound33871 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5377,113,295,131072,138592,1024,112,4160,136212,16,2,301,64,138544,5393,4097,2048,1364,136212,256,32,5456,512]

theorem envBound33872 : H12AffineFastState.Bounded env33872 := by
  intro p hp
  have h : env33872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33871_33872 : H12AffineEnvironment.transform 12 300 env33871 = env33872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env33871 == env33872) = true)

theorem identity33872 : scanCanonicalize (H12AffineFastState.compose env33872 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound33872 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5377,113,295,5172,2388,1024,112,4160,32,16,2,301,64,2308,5393,4097,2048,1364,32,256,32,5456,512]

theorem envBound33873 : H12AffineFastState.Bounded env33873 := by
  intro p hp
  have h : env33873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33872_33873 : H12AffineEnvironment.transform 16 5172 env33872 = env33873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env33872 == env33873) = true)

theorem identity33873 : scanCanonicalize (H12AffineFastState.compose env33873 (packedSelected [11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound33873 : packedSelected [11,12,15] rootPS < 2^1333 := by decide +kernel

def env33874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,4096,300,5377,113,295,5172,112,1024,112,4160,32,16,2,301,64,32,5393,4097,292,1364,32,256,32,5456,512]

theorem envBound33874 : H12AffineFastState.Bounded env33874 := by
  intro p hp
  have h : env33874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33873_33874 : H12AffineEnvironment.transform 10 292 env33873 = env33874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env33873 == env33874) = true)

theorem identity33874 : scanCanonicalize (H12AffineFastState.compose env33874 (packedSelected [2,4,9,11,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33874 : packedSelected [2,4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env33875 : List Nat := [2,4,8,16,0,64,9,256,512,1024,260,4096,268,5377,81,263,5140,80,1024,80,4160,0,16,2,269,64,0,5393,4097,260,1364,0,256,0,5456,512]

theorem envBound33875 : H12AffineFastState.Bounded env33875 := by
  intro p hp
  have h : env33875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33874_33875 : H12AffineEnvironment.transform 4 0 env33874 = env33875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33874 == env33875) = true)

theorem identity33875 : scanCanonicalize (H12AffineFastState.compose env33875 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33875 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env33876 : List Nat := [2,4,8,16,0,64,9,5,512,1024,1,4096,9,5124,81,2,5140,80,1024,80,4160,0,16,2,8,64,0,5140,4097,1,1105,0,5,0,5205,512]

theorem envBound33876 : H12AffineFastState.Bounded env33876 := by
  intro p hp
  have h : env33876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33875_33876 : H12AffineEnvironment.transform 7 5 env33875 = env33876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33875 == env33876) = true)

theorem identity33876 : scanCanonicalize (H12AffineFastState.compose env33876 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound33876 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33877 : List Nat := [2,4,8,16,0,64,9,5,512,1024,1,0,9,1028,81,2,1044,80,1024,80,64,0,16,2,8,64,0,1044,1,1,1105,0,5,0,1109,512]

theorem envBound33877 : H12AffineFastState.Bounded env33877 := by
  intro p hp
  have h : env33877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33876_33877 : H12AffineEnvironment.transform 11 0 env33876 = env33877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33876 == env33877) = true)

def env33878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21777,98645,8328,64,4592709,16400,17800,431377,20564,4235613,256,21793,46212,96130]

theorem envBound33878 : H12AffineFastState.Bounded env33878 := by
  intro p hp
  have h : env33878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33832_33878 : H12AffineEnvironment.transform 20 17865 env33832 = env33878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env33832 == env33878) = true)

def env33879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,17,98645,8328,64,4592709,5392,4232,431377,1364,4235613,256,33,46212,74370]

theorem envBound33879 : H12AffineFastState.Bounded env33879 := by
  intro p hp
  have h : env33879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33878_33879 : H12AffineEnvironment.transform 13 5376 env33878 = env33879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33878 == env33879) = true)

theorem identity33879 : scanCanonicalize (H12AffineFastState.compose env33879 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound33879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,98679,17,98645,8328,64,496946,5392,4232,431377,1364,73770,256,33,46212,74370]

theorem envBound33880 : H12AffineFastState.Bounded env33880 := by
  intro p hp
  have h : env33880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33879_33880 : H12AffineEnvironment.transform 21 98679 env33879 = env33880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env33879 == env33880) = true)

def env33881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,98679,17,98645,8192,64,496946,5392,4096,431377,1364,73770,256,33,46092,74250]

theorem envBound33881 : H12AffineFastState.Bounded env33881 := by
  intro p hp
  have h : env33881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33880_33881 : H12AffineEnvironment.transform 6 8 env33880 = env33881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33880 == env33881) = true)

theorem identity33881 : scanCanonicalize (H12AffineFastState.compose env33881 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33881 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4161,98679,17,98645,8192,64,245019,5392,4096,179512,1364,73770,256,33,46092,74250]

theorem envBound33882 : H12AffineFastState.Bounded env33882 := by
  intro p hp
  have h : env33882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33881_33882 : H12AffineEnvironment.transform 17 10281 env33881 = env33882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33881 == env33882) = true)

theorem identity33882 : scanCanonicalize (H12AffineFastState.compose env33882 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound33882 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5440,10281,1024,32769,4161,98679,17,98645,8192,64,108635,5392,4096,43128,1364,73770,256,33,46092,74250]

theorem envBound33883 : H12AffineFastState.Bounded env33883 := by
  intro p hp
  have h : env33883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33882_33883 : H12AffineEnvironment.transform 16 5440 env33882 = env33883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env33882 == env33883) = true)

theorem identity33883 : scanCanonicalize (H12AffineFastState.compose env33883 (packedSelected [4,9,12,14,15,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33883 : packedSelected [4,9,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env33884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,65536,5440,2421,1024,32769,4161,98679,17,98645,348,64,100615,5392,4096,35108,1364,65910,256,33,38224,66390]

theorem envBound33884 : H12AffineFastState.Bounded env33884 := by
  intro p hp
  have h : env33884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33883_33884 : H12AffineEnvironment.transform 12 348 env33883 = env33884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33883 == env33884) = true)

theorem identity33884 : scanCanonicalize (H12AffineFastState.compose env33884 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound33884 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33111,5440,2421,1024,32769,4161,32,17,2,348,64,2128,5392,4096,35108,1364,32801,256,33,38224,33281]

theorem envBound33885 : H12AffineFastState.Bounded env33885 := by
  intro p hp
  have h : env33885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33884_33885 : H12AffineEnvironment.transform 15 33111 env33884 = env33885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env33884 == env33885) = true)

theorem identity33885 : scanCanonicalize (H12AffineFastState.compose env33885 (packedSelected [0,1,2,3,5,7,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2373) := by decide +kernel

theorem selectedBound33885 : packedSelected [0,1,2,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env33886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2373,348,3141,32768,33111,3077,2421,1024,32769,2308,32,17,2,348,64,2128,3157,2373,35108,1364,32801,256,33,35861,33281]

theorem envBound33886 : H12AffineFastState.Bounded env33886 := by
  intro p hp
  have h : env33886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33885_33886 : H12AffineEnvironment.transform 11 2373 env33885 = env33886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2373 env33885 == env33886) = true)

theorem identity33886 : scanCanonicalize (H12AffineFastState.compose env33886 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound33886 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2373,348,3141,261,82,3077,2421,1024,260,2308,32,17,2,348,64,2128,3157,2373,2081,1364,292,256,33,3344,772]

theorem envBound33887 : H12AffineFastState.Bounded env33887 := by
  intro p hp
  have h : env33887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33886_33887 : H12AffineEnvironment.transform 14 261 env33886 = env33887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env33886 == env33887) = true)

theorem identity33887 : scanCanonicalize (H12AffineFastState.compose env33887 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33887 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env33888 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2325,268,3093,261,2,3077,2341,1024,260,2308,32,17,2,268,16,2048,3077,2325,2081,1284,292,256,33,3344,772]

theorem envBound33888 : H12AffineFastState.Bounded env33888 := by
  intro p hp
  have h : env33888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33887_33888 : H12AffineEnvironment.transform 5 16 env33887 = env33888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33887 == env33888) = true)

theorem identity33888 : scanCanonicalize (H12AffineFastState.compose env33888 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33888 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33889 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2325,268,2081,261,2,2097,2341,52,260,2308,32,17,2,268,16,2048,2097,2325,2081,304,292,256,33,2340,772]

theorem envBound33889 : H12AffineFastState.Bounded env33889 := by
  intro p hp
  have h : env33889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33888_33889 : H12AffineEnvironment.transform 9 52 env33888 = env33889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33888 == env33889) = true)

def env33890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,98679,17,98645,8193,64,496946,5392,4097,431377,1364,73770,256,33,46093,74251]

theorem envBound33890 : H12AffineFastState.Bounded env33890 := by
  intro p hp
  have h : env33890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33880_33890 : H12AffineEnvironment.transform 6 9 env33880 = env33890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33880 == env33890) = true)

theorem identity33890 : scanCanonicalize (H12AffineFastState.compose env33890 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound33890 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1024,32769,4160,98679,17,98645,8193,64,203847,5392,4097,138340,1364,73770,256,33,46093,74251]

theorem envBound33891 : H12AffineFastState.Bounded env33891 := by
  intro p hp
  have h : env33891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33890_33891 : H12AffineEnvironment.transform 17 35189 env33890 = env33891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env33890 == env33891) = true)

theorem identity33891 : scanCanonicalize (H12AffineFastState.compose env33891 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound33891 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,35189,1024,32769,4160,98679,17,98645,8193,64,67926,5392,4097,2421,1364,73770,256,33,46093,74251]

theorem envBound33892 : H12AffineFastState.Bounded env33892 := by
  intro p hp
  have h : env33892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33891_33892 : H12AffineEnvironment.transform 16 5393 env33891 = env33892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33891 == env33892) = true)

theorem identity33892 : scanCanonicalize (H12AffineFastState.compose env33892 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33892 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5393,35189,1024,32769,4160,41341,17,41311,8193,64,10588,5392,4097,2421,1364,32,256,33,46093,513]

theorem envBound33893 : H12AffineFastState.Bounded env33893 := by
  intro p hp
  have h : env33893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33892_33893 : H12AffineEnvironment.transform 15 8202 env33892 = env33893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33892 == env33893) = true)

theorem identity33893 : scanCanonicalize (H12AffineFastState.compose env33893 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound33893 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1345,8202,5393,3124,1024,1344,4160,9276,17,9246,8193,64,10588,5392,4097,2421,1364,32,256,33,12620,513]

theorem envBound33894 : H12AffineFastState.Bounded env33894 := by
  intro p hp
  have h : env33894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33893_33894 : H12AffineEnvironment.transform 14 1345 env33893 = env33894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env33893 == env33894) = true)

theorem identity33894 : scanCanonicalize (H12AffineFastState.compose env33894 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound33894 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,5376,1345,2082,5393,3124,1024,1344,4160,3092,17,3126,2089,64,372,5392,4097,2421,1364,32,256,33,6500,513]

theorem envBound33895 : H12AffineFastState.Bounded env33895 := by
  intro p hp
  have h : env33895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33894_33895 : H12AffineEnvironment.transform 12 2088 env33894 = env33895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env33894 == env33895) = true)

theorem identity33895 : scanCanonicalize (H12AffineFastState.compose env33895 (packedSelected [0,3,5,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound33895 : packedSelected [0,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env33896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,2088,2420,1345,2082,2405,3124,1024,1344,3124,3092,17,3126,2089,64,372,2404,3189,2421,1364,32,256,33,1296,513]

theorem envBound33896 : H12AffineFastState.Bounded env33896 := by
  intro p hp
  have h : env33896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33895_33896 : H12AffineEnvironment.transform 11 3188 env33895 = env33896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env33895 == env33896) = true)

theorem identity33896 : scanCanonicalize (H12AffineFastState.compose env33896 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound33896 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,1280,348,0,1345,342,17,1344,1024,1344,1344,1376,17,1346,349,64,372,16,1281,1,1364,32,256,33,1296,513]

theorem envBound33897 : H12AffineFastState.Bounded env33897 := by
  intro p hp
  have h : env33897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33896_33897 : H12AffineEnvironment.transform 10 372 env33896 = env33897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env33896 == env33897) = true)

def env33898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,16,98645,8328,64,4592709,5393,4233,431377,1365,4235613,256,32,46212,74371]

theorem envBound33898 : H12AffineFastState.Bounded env33898 := by
  intro p hp
  have h : env33898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33878_33898 : H12AffineEnvironment.transform 13 5377 env33878 = env33898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33878 == env33898) = true)

theorem identity33898 : scanCanonicalize (H12AffineFastState.compose env33898 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound33898 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,4296,4194304,16,138,8328,64,4592709,5393,4233,431377,1365,4235613,256,32,46212,41820]

theorem envBound33899 : H12AffineFastState.Bounded env33899 := by
  intro p hp
  have h : env33899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33898_33899 : H12AffineEnvironment.transform 15 33247 env33898 = env33899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env33898 == env33899) = true)

def env33900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4160,4194304,16,2,8192,64,4592709,5393,4097,431377,1365,4235613,256,32,46092,41820]

theorem envBound33900 : H12AffineFastState.Bounded env33900 := by
  intro p hp
  have h : env33900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33899_33900 : H12AffineEnvironment.transform 6 8 env33899 = env33900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33899 == env33900) = true)

theorem identity33900 : scanCanonicalize (H12AffineFastState.compose env33900 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound33900 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env33901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,35188,1024,32769,4160,4194304,16,2,8192,64,4365617,5393,4097,138341,1365,4235613,256,32,46092,41820]

theorem envBound33901 : H12AffineFastState.Bounded env33901 := by
  intro p hp
  have h : env33901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33900_33901 : H12AffineEnvironment.transform 17 35188 env33900 = env33901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env33900 == env33901) = true)

theorem identity33901 : scanCanonicalize (H12AffineFastState.compose env33901 (packedSelected [0,2,6,11,14,16,18,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound33901 : packedSelected [0,2,6,11,14,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env33902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,35188,1024,32769,4160,8572,16,2,8192,64,179277,5393,4097,138341,1365,32801,256,32,46092,41820]

theorem envBound33902 : H12AffineFastState.Bounded env33902 := by
  intro p hp
  have h : env33902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33901_33902 : H12AffineEnvironment.transform 21 8572 env33901 = env33902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env33901 == env33902) = true)

theorem identity33902 : scanCanonicalize (H12AffineFastState.compose env33902 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound33902 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env33903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,5441,35188,1024,32769,4160,8572,16,2,8192,64,43276,5393,4097,2340,1365,32801,256,32,46092,41820]

theorem envBound33903 : H12AffineFastState.Bounded env33903 := by
  intro p hp
  have h : env33903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33902_33903 : H12AffineEnvironment.transform 16 5441 env33902 = env33903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env33902 == env33903) = true)

theorem identity33903 : scanCanonicalize (H12AffineFastState.compose env33903 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound33903 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,32768,33111,5441,35188,1024,32769,4160,112,16,2,268,64,34816,5393,4097,2340,1365,32801,256,32,38144,33360]

theorem envBound33904 : H12AffineFastState.Bounded env33904 := by
  intro p hp
  have h : env33904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33903_33904 : H12AffineEnvironment.transform 12 268 env33903 = env33904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env33903 == env33904) = true)

theorem identity33904 : scanCanonicalize (H12AffineFastState.compose env33904 (packedSelected [0,1,2,6,7,8,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound33904 : packedSelected [0,1,2,6,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env33905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,263,5441,2340,1024,81,4160,112,16,2,268,64,2128,5393,4097,2340,1365,113,256,32,5456,512]

theorem envBound33905 : H12AffineFastState.Bounded env33905 := by
  intro p hp
  have h : env33905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33904_33905 : H12AffineEnvironment.transform 14 80 env33904 = env33905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env33904 == env33905) = true)

theorem identity33905 : scanCanonicalize (H12AffineFastState.compose env33905 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33905 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33906 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,268,5377,80,263,5441,2308,1024,81,4160,80,16,2,268,64,2128,5393,4097,2308,1365,81,256,0,5456,512]

theorem envBound33906 : H12AffineFastState.Bounded env33906 := by
  intro p hp
  have h : env33906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33905_33906 : H12AffineEnvironment.transform 4 0 env33905 = env33906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33905 == env33906) = true)

theorem identity33906 : scanCanonicalize (H12AffineFastState.compose env33906 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33906 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33907 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,268,4113,80,263,4177,2308,272,81,4160,80,16,2,268,64,2128,4097,4097,2308,69,81,256,0,4160,512]

theorem envBound33907 : H12AffineFastState.Bounded env33907 := by
  intro p hp
  have h : env33907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33906_33907 : H12AffineEnvironment.transform 9 272 env33906 = env33907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33906 == env33907) = true)

theorem identity33907 : scanCanonicalize (H12AffineFastState.compose env33907 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33907 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env33908 : List Nat := [2,4,8,16,0,1,8,256,512,272,2048,4096,268,4113,17,263,4112,2308,272,16,4097,17,16,2,268,1,2065,4097,4097,2308,4,16,256,0,4097,512]

theorem envBound33908 : H12AffineFastState.Bounded env33908 := by
  intro p hp
  have h : env33908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33907_33908 : H12AffineEnvironment.transform 5 1 env33907 = env33908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33907 == env33908) = true)

theorem identity33908 : scanCanonicalize (H12AffineFastState.compose env33908 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound33908 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33909 : List Nat := [2,4,8,16,0,1,8,256,512,272,2048,17,268,0,17,263,1,2308,272,16,16,17,16,2,268,1,2065,16,16,2308,4,16,256,0,16,512]

theorem envBound33909 : H12AffineFastState.Bounded env33909 := by
  intro p hp
  have h : env33909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33908_33909 : H12AffineEnvironment.transform 11 17 env33908 = env33909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33908 == env33909) = true)

def env33910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4161,4194304,16,3,8193,64,4592709,5393,4096,431377,1365,4235613,256,32,46093,41820]

theorem envBound33910 : H12AffineFastState.Bounded env33910 := by
  intro p hp
  have h : env33910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33899_33910 : H12AffineEnvironment.transform 6 9 env33899 = env33910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33899 == env33910) = true)

theorem identity33910 : scanCanonicalize (H12AffineFastState.compose env33910 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33910 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4161,4194304,16,3,8193,64,4592709,5393,4096,406604,1365,4194304,256,32,5456,513]

theorem envBound33911 : H12AffineFastState.Bounded env33911 := by
  intro p hp
  have h : env33911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33910_33911 : H12AffineEnvironment.transform 14 8541 env33910 = env33911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33910 == env33911) = true)

theorem identity33911 : scanCanonicalize (H12AffineFastState.compose env33911 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound33911 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10360,1024,8540,4161,4194304,16,3,8193,64,4340797,5393,4096,138292,1365,4194304,256,32,5456,513]

theorem envBound33912 : H12AffineFastState.Bounded env33912 := by
  intro p hp
  have h : env33912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33911_33912 : H12AffineEnvironment.transform 17 10360 env33911 = env33912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env33911 == env33912) = true)

theorem identity33912 : scanCanonicalize (H12AffineFastState.compose env33912 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound33912 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,4097,10360,1024,8540,4161,4194304,16,3,8193,64,4205628,5393,4096,3125,1365,4194304,256,32,5456,513]

theorem envBound33913 : H12AffineFastState.Bounded env33913 := by
  intro p hp
  have h : env33913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33912_33913 : H12AffineEnvironment.transform 16 4097 env33912 = env33913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env33912 == env33913) = true)

theorem identity33913 : scanCanonicalize (H12AffineFastState.compose env33913 (packedSelected [9,14,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33913 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env33914 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8541,8203,4097,10360,272,8540,4161,4194304,16,3,8193,64,4204844,4097,4096,2341,69,4194304,256,32,4160,513]

theorem envBound33914 : H12AffineFastState.Bounded env33914 := by
  intro p hp
  have h : env33914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33913_33914 : H12AffineEnvironment.transform 9 272 env33913 = env33914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33913 == env33914) = true)

theorem identity33914 : scanCanonicalize (H12AffineFastState.compose env33914 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33914 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33915 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,4113,8461,8203,4097,10280,272,8460,4113,4194304,16,3,8193,16,4204844,4097,4096,2341,21,4194304,256,32,4112,513]

theorem envBound33915 : H12AffineFastState.Bounded env33915 := by
  intro p hp
  have h : env33915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33914_33915 : H12AffineEnvironment.transform 5 16 env33914 = env33915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33914 == env33915) = true)

theorem identity33915 : scanCanonicalize (H12AffineFastState.compose env33915 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33915 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33916 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8192,4113,8232,8203,4097,10280,53,8233,4113,4194304,16,3,8193,16,4204553,4097,4096,2048,21,4194304,37,32,4112,513]

theorem envBound33916 : H12AffineFastState.Bounded env33916 := by
  intro p hp
  have h : env33916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33915_33916 : H12AffineEnvironment.transform 7 37 env33915 = env33916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33915 == env33916) = true)

theorem identity33916 : scanCanonicalize (H12AffineFastState.compose env33916 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound33916 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33917 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,6200,4113,6160,6195,4097,4112,53,6161,4113,4194304,16,3,6201,16,4198449,4097,4096,2048,21,4194304,37,32,4112,513]

theorem envBound33917 : H12AffineFastState.Bounded env33917 := by
  intro p hp
  have h : env33917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33916_33917 : H12AffineEnvironment.transform 12 6200 env33916 = env33917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env33916 == env33917) = true)

theorem identity33917 : scanCanonicalize (H12AffineFastState.compose env33917 (packedSelected [1,4] rootPS)) = affineNative (2^(21+1) ^^^ 59) := by decide +kernel

theorem selectedBound33917 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env33918 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,6200,4113,6160,6195,4097,4112,53,6161,4113,59,16,3,6201,16,4106,4097,4096,2048,21,59,37,32,4112,513]

theorem envBound33918 : H12AffineFastState.Bounded env33918 := by
  intro p hp
  have h : env33918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33917_33918 : H12AffineEnvironment.transform 21 59 env33917 = env33918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 59 env33917 == env33918) = true)

theorem identity33918 : scanCanonicalize (H12AffineFastState.compose env33918 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound33918 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env33919 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2059,51,2074,27,56,2058,2075,53,26,2074,59,16,3,50,16,2049,2058,2059,2048,21,59,37,32,2075,513]

theorem envBound33919 : H12AffineFastState.Bounded env33919 := by
  intro p hp
  have h : env33919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33918_33919 : H12AffineEnvironment.transform 11 2059 env33918 = env33919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env33918 == env33919) = true)

theorem identity33919 : scanCanonicalize (H12AffineFastState.compose env33919 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound33919 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33920 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,2059,51,2074,27,56,2058,2075,53,26,2074,59,16,3,50,16,2049,2058,2059,2048,21,59,37,32,2075,10]

theorem envBound33920 : H12AffineFastState.Bounded env33920 := by
  intro p hp
  have h : env33920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33919_33920 : H12AffineEnvironment.transform 8 11 env33919 = env33920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env33919 == env33920) = true)

theorem identity33920 : scanCanonicalize (H12AffineFastState.compose env33920 (packedSelected [0,1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33920 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env33921 : List Nat := [2,4,8,11,32,11,9,37,11,46,2048,2059,40,2049,0,35,2058,2048,46,1,2049,32,11,3,41,11,2049,2058,2059,2048,14,32,37,32,2048,10]

theorem envBound33921 : H12AffineFastState.Bounded env33921 := by
  intro p hp
  have h : env33921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33920_33921 : H12AffineEnvironment.transform 3 11 env33920 = env33921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33920 == env33921) = true)

theorem identity33921 : scanCanonicalize (H12AffineFastState.compose env33921 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33922 : List Nat := [2,4,3,0,32,0,2,37,0,37,2048,2048,35,2049,0,35,2049,2048,37,1,2049,32,0,3,34,0,2049,2049,2048,2048,5,32,37,32,2048,1]

theorem envBound33922 : H12AffineFastState.Bounded env33922 := by
  intro p hp
  have h : env33922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33921_33922 : H12AffineEnvironment.transform 2 3 env33921 = env33922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33921 == env33922) = true)

theorem identity33922 : scanCanonicalize (H12AffineFastState.compose env33922 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33922 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33923 : List Nat := [2,4,3,0,32,0,2,37,0,37,1,1,35,0,0,35,0,1,37,1,0,32,0,3,34,0,0,0,1,1,5,32,37,32,1,1]

theorem envBound33923 : H12AffineFastState.Bounded env33923 := by
  intro p hp
  have h : env33923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33922_33923 : H12AffineEnvironment.transform 10 1 env33922 = env33923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33922 == env33923) = true)

theorem identity33923 : scanCanonicalize (H12AffineFastState.compose env33923 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33924 : List Nat := [2,4,3,0,1,0,2,4,0,4,1,1,2,0,0,2,0,1,4,1,0,1,0,3,3,0,0,0,1,1,5,1,4,1,1,1]

theorem envBound33924 : H12AffineFastState.Bounded env33924 := by
  intro p hp
  have h : env33924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33923_33924 : H12AffineEnvironment.transform 4 1 env33923 = env33924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33923 == env33924) = true)

def env33925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound33925 : H12AffineFastState.Bounded env33925 := by
  intro p hp
  have h : env33925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33736_33925 : H12AffineEnvironment.transform 18 1025 env33736 = env33925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env33736 == env33925) = true)

theorem identity33925 : scanCanonicalize (H12AffineFastState.compose env33925 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237468) := by decide +kernel

theorem selectedBound33925 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237468,16777216,8328,64,23454748,18973837,160076,2417693,19111948,23160257,257,17031345,16974101,19040219]

theorem envBound33926 : H12AffineFastState.Bounded env33926 := by
  intro p hp
  have h : env33926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33925_33926 : H12AffineEnvironment.transform 22 2237468 env33925 = env33926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237468 env33925 == env33926) = true)

def env33927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237468,243088,8328,64,6705548,2240797,160076,2417693,2102684,6475857,257,21793,46213,2175563]

theorem envBound33927 : H12AffineFastState.Bounded env33927 := by
  intro p hp
  have h : env33927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33926_33927 : H12AffineEnvironment.transform 23 243088 env33926 = env33927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env33926 == env33927) = true)

def env33928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237468,243088,8328,64,2144660,2240797,160076,2417693,2102684,2373705,257,21793,46213,2175563]

theorem envBound33928 : H12AffineFastState.Bounded env33928 := by
  intro p hp
  have h : env33928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33927_33928 : H12AffineEnvironment.transform 21 452632 env33927 = env33928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env33927 == env33928) = true)

def env33929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144476,243088,8328,64,43476,139613,160076,324701,1500,272393,257,21793,46213,74251]

theorem envBound33929 : H12AffineFastState.Bounded env33929 := by
  intro p hp
  have h : env33929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33928_33929 : H12AffineEnvironment.transform 20 4160 env33928 = env33929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33928 == env33929) = true)

theorem identity33929 : scanCanonicalize (H12AffineFastState.compose env33929 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound33929 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4160,272513,62661,95497,8328,64,43476,57796,45525,324701,1500,272393,257,21793,46213,74251]

theorem envBound33930 : H12AffineFastState.Bounded env33930 := by
  intro p hp
  have h : env33930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33929_33930 : H12AffineEnvironment.transform 16 49305 env33929 = env33930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env33929 == env33930) = true)

theorem identity33930 : scanCanonicalize (H12AffineFastState.compose env33930 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33930 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49305,262144,1025,32769,4160,272513,62661,21763,8328,64,43476,57796,45525,324701,1500,272393,257,21793,46213,513]

theorem envBound33931 : H12AffineFastState.Bounded env33931 := by
  intro p hp
  have h : env33931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33930_33931 : H12AffineEnvironment.transform 15 8202 env33930 = env33931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33930 == env33931) = true)

theorem identity33931 : scanCanonicalize (H12AffineFastState.compose env33931 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound33931 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env33932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49305,56436,1025,32769,4160,62709,62661,21763,8328,64,43476,57796,45525,10281,1500,62589,257,21793,46213,513]

theorem envBound33932 : H12AffineFastState.Bounded env33932 := by
  intro p hp
  have h : env33932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33931_33932 : H12AffineEnvironment.transform 17 56436 env33931 = env33932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env33931 == env33932) = true)

theorem identity33932 : scanCanonicalize (H12AffineFastState.compose env33932 (packedSelected [2,3,6,7,10,14,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33932 : packedSelected [2,3,6,7,10,14,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env33933 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,49305,56356,1025,32769,4112,62629,62613,21763,8328,16,43396,57748,45445,10281,1420,62509,257,21793,46213,513]

theorem envBound33933 : H12AffineFastState.Bounded env33933 := by
  intro p hp
  have h : env33933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33932_33933 : H12AffineEnvironment.transform 5 16 env33932 = env33933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33932 == env33933) = true)

theorem identity33933 : scanCanonicalize (H12AffineFastState.compose env33933 (packedSelected [2,3,4,6,9,10,14,19,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33933 : packedSelected [2,3,4,6,9,10,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env33934 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,56356,1025,32769,4112,62508,62492,21763,8193,16,43277,57629,45324,10281,1285,62509,257,21793,46092,513]

theorem envBound33934 : H12AffineFastState.Bounded env33934 := by
  intro p hp
  have h : env33934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33933_33934 : H12AffineEnvironment.transform 6 9 env33933 = env33934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33933 == env33934) = true)

theorem identity33934 : scanCanonicalize (H12AffineFastState.compose env33934 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound33934 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env33935 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,8202,46109,43049,1025,32769,4112,32801,32785,8462,8193,16,43277,38160,45324,10281,1285,32800,257,8492,46092,513]

theorem envBound33935 : H12AffineFastState.Bounded env33935 := by
  intro p hp
  have h : env33935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33934_33935 : H12AffineEnvironment.transform 13 13325 env33934 = env33935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env33934 == env33935) = true)

theorem identity33935 : scanCanonicalize (H12AffineFastState.compose env33935 (packedSelected [2,4,6,7,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound33935 : packedSelected [2,4,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33936 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,292,8202,13625,10509,1025,293,4112,261,309,8462,8193,16,10281,5172,12328,10281,1285,260,257,8492,13608,513]

theorem envBound33936 : H12AffineFastState.Bounded env33936 := by
  intro p hp
  have h : env33936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33935_33936 : H12AffineEnvironment.transform 14 292 env33935 = env33936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env33935 == env33936) = true)

theorem identity33936 : scanCanonicalize (H12AffineFastState.compose env33936 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33936 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33937 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,292,263,5172,2048,1025,293,4112,261,309,3,268,16,2340,5172,4389,2340,1285,260,257,33,5157,513]

theorem envBound33937 : H12AffineFastState.Bounded env33937 := by
  intro p hp
  have h : env33937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33936_33937 : H12AffineEnvironment.transform 12 269 env33936 = env33937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33936 == env33937) = true)

def env33938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144477,243088,8328,64,43477,139612,160076,324700,1501,272392,257,21793,46213,74250]

theorem envBound33938 : H12AffineFastState.Bounded env33938 := by
  intro p hp
  have h : env33938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33928_33938 : H12AffineEnvironment.transform 20 4161 env33928 = env33938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33928 == env33938) = true)

def env33939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180272,144477,243088,8328,64,43477,139612,160076,56436,1501,32,257,21793,46213,74250]

theorem envBound33939 : H12AffineFastState.Bounded env33939 := by
  intro p hp
  have h : env33939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33938_33939 : H12AffineEnvironment.transform 17 10280 env33938 = env33939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33938 == env33939) = true)

def env33940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,21792,41293,73856,8328,64,43477,46156,58460,56436,1501,32,257,21793,46213,74250]

theorem envBound33940 : H12AffineFastState.Bounded env33940 := by
  intro p hp
  have h : env33940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33939_33940 : H12AffineEnvironment.transform 16 38160 env33939 = env33940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env33939 == env33940) = true)

theorem identity33940 : scanCanonicalize (H12AffineFastState.compose env33940 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound33940 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13508,10280,1025,8661,4161,21792,153,73856,8328,64,2049,5528,17800,32160,1501,32,257,21793,5457,74250]

theorem envBound33941 : H12AffineFastState.Bounded env33941 := by
  intro p hp
  have h : env33941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33940_33941 : H12AffineEnvironment.transform 14 8660 env33940 = env33941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env33940 == env33941) = true)

theorem identity33941 : scanCanonicalize (H12AffineFastState.compose env33941 (packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound33941 : packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4541,8660,65536,13508,10280,1025,8661,4161,1181,153,73856,8328,64,2049,5528,5173,11293,1501,32,257,1180,5457,74250]

theorem envBound33942 : H12AffineFastState.Bounded env33942 := by
  intro p hp
  have h : env33942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33941_33942 : H12AffineEnvironment.transform 13 4541 env33941 = env33942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env33941 == env33942) = true)

theorem identity33942 : scanCanonicalize (H12AffineFastState.compose env33942 (packedSelected [2,5,6,7,9,12,15,16,19,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound33942 : packedSelected [2,5,6,7,9,12,15,16,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env33943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4541,8660,9326,13508,10280,1025,8661,4161,1181,153,1262,8328,64,2049,5528,5173,11293,1501,32,257,1180,5457,1636]

theorem envBound33943 : H12AffineFastState.Bounded env33943 := by
  intro p hp
  have h : env33943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33942_33943 : H12AffineEnvironment.transform 15 9326 env33942 = env33943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env33942 == env33943) = true)

theorem identity33943 : scanCanonicalize (H12AffineFastState.compose env33943 (packedSelected [3,5,10,11,12,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound33943 : packedSelected [3,5,10,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env33944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,4541,508,1094,5356,2048,1025,509,4161,1181,153,1262,160,64,2049,5528,5173,3125,1501,32,257,1180,5457,1636]

theorem envBound33944 : H12AffineFastState.Bounded env33944 := by
  intro p hp
  have h : env33944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33943_33944 : H12AffineEnvironment.transform 12 40 env33943 = env33944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env33943 == env33944) = true)

theorem identity33944 : scanCanonicalize (H12AffineFastState.compose env33944 (packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33944 : packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env33945 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,40,4541,508,343,4605,2048,272,509,4161,396,153,511,160,64,2049,4233,4388,2340,204,32,257,397,4160,885]

theorem envBound33945 : H12AffineFastState.Bounded env33945 := by
  intro p hp
  have h : env33945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33944_33945 : H12AffineEnvironment.transform 9 273 env33944 = env33945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33944 == env33945) = true)

def env33946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,21793,41292,73857,8328,64,43477,46157,58461,56436,1501,32,257,21793,46213,74250]

theorem envBound33946 : H12AffineFastState.Bounded env33946 := by
  intro p hp
  have h : env33946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33939_33946 : H12AffineEnvironment.transform 16 38161 env33939 = env33946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env33939 == env33946) = true)

theorem identity33946 : scanCanonicalize (H12AffineFastState.compose env33946 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33946 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,13389,10280,1025,8541,4161,21793,16,73857,8328,64,2185,5393,17665,32040,1501,32,257,21793,5593,74250]

theorem envBound33947 : H12AffineFastState.Bounded env33947 := by
  intro p hp
  have h : env33947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33946_33947 : H12AffineEnvironment.transform 14 8540 env33946 = env33947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33946 == env33947) = true)

theorem identity33947 : scanCanonicalize (H12AffineFastState.compose env33947 (packedSelected [5,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound33947 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env33948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,1094,13389,10280,1025,8541,4161,21793,16,9415,8328,64,2185,5393,17665,32040,1501,32,257,21793,5593,9804]

theorem envBound33948 : H12AffineFastState.Bounded env33948 := by
  intro p hp
  have h : env33948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33947_33948 : H12AffineEnvironment.transform 15 1094 env33947 = env33948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env33947 == env33948) = true)

theorem identity33948 : scanCanonicalize (H12AffineFastState.compose env33948 (packedSelected [2,6,7,9,20,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound33948 : packedSelected [2,6,7,9,20,22,27] rootPS < 2^1333 := by decide +kernel

def env33949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,16384,1345,1094,4176,3125,1025,1344,4161,21793,16,218,1173,64,2185,5393,17665,22837,1501,32,257,21793,5593,593]

theorem envBound33949 : H12AffineFastState.Bounded env33949 := by
  intro p hp
  have h : env33949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33948_33949 : H12AffineEnvironment.transform 12 1053 env33948 = env33949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env33948 == env33949) = true)

theorem identity33949 : scanCanonicalize (H12AffineFastState.compose env33949 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound33949 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env33950 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1053,16384,1261,1094,4176,3125,1025,1260,4161,21645,16,218,1173,64,2185,5309,17581,22681,1137,32,173,21645,5237,593]

theorem envBound33950 : H12AffineFastState.Bounded env33950 := by
  intro p hp
  have h : env33950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33949_33950 : H12AffineEnvironment.transform 7 172 env33949 = env33950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33949 == env33950) = true)

theorem identity33950 : scanCanonicalize (H12AffineFastState.compose env33950 (packedSelected [2,3,5,6,9,10,14,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33950 : packedSelected [2,3,5,6,9,10,14,22] rootPS < 2^1333 := by decide +kernel

def env33951 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1053,16384,1213,1046,4096,3125,1025,1212,4113,21645,16,138,1173,16,2185,5309,17581,22681,1057,32,173,21645,5157,513]

theorem envBound33951 : H12AffineFastState.Bounded env33951 := by
  intro p hp
  have h : env33951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33950_33951 : H12AffineEnvironment.transform 5 16 env33950 = env33951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33950 == env33951) = true)

theorem identity33951 : scanCanonicalize (H12AffineFastState.compose env33951 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound33951 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env33952 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1053,5157,1213,1046,4096,3125,1025,1212,4113,168,16,138,1173,16,2185,5309,4232,3260,1057,32,173,168,5157,513]

theorem envBound33952 : H12AffineFastState.Bounded env33952 := by
  intro p hp
  have h : env33952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33951_33952 : H12AffineEnvironment.transform 13 5157 env33951 = env33952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env33951 == env33952) = true)

theorem identity33952 : scanCanonicalize (H12AffineFastState.compose env33952 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound33952 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env33953 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1196,1053,137,1213,1046,1196,3125,1025,1212,1213,168,16,138,1173,16,2185,17,1060,3260,1057,32,173,168,137,513]

theorem envBound33953 : H12AffineFastState.Bounded env33953 := by
  intro p hp
  have h : env33953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33952_33953 : H12AffineEnvironment.transform 11 1196 env33952 = env33953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env33952 == env33953) = true)

theorem identity33953 : scanCanonicalize (H12AffineFastState.compose env33953 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound33953 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33954 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1077,1196,1053,137,1213,1046,1196,0,1025,1212,1213,168,16,138,1173,16,1212,17,1060,137,1057,32,173,168,137,513]

theorem envBound33954 : H12AffineFastState.Bounded env33954 := by
  intro p hp
  have h : env33954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33953_33954 : H12AffineEnvironment.transform 10 1077 env33953 = env33954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env33953 == env33954) = true)

theorem identity33954 : scanCanonicalize (H12AffineFastState.compose env33954 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound33954 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env33955 : List Nat := [2,4,8,16,32,16,128,172,512,189,136,17,160,137,0,171,17,0,188,1,0,168,16,138,40,16,1,17,153,137,156,32,173,168,137,513]

theorem envBound33955 : H12AffineFastState.Bounded env33955 := by
  intro p hp
  have h : env33955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33954_33955 : H12AffineEnvironment.transform 9 189 env33954 = env33955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env33954 == env33955) = true)

theorem identity33955 : scanCanonicalize (H12AffineFastState.compose env33955 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33955 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env33956 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,40,1,0,35,17,0,52,1,0,32,16,2,40,16,1,17,17,1,20,32,37,32,1,513]

theorem envBound33956 : H12AffineFastState.Bounded env33956 := by
  intro p hp
  have h : env33956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33955_33956 : H12AffineEnvironment.transform 6 8 env33955 = env33956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33955 == env33956) = true)

theorem identity33956 : scanCanonicalize (H12AffineFastState.compose env33956 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound33956 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33957 : List Nat := [2,4,8,16,32,16,8,36,17,53,0,17,40,1,0,35,17,0,52,1,0,32,16,2,40,16,1,17,17,1,20,32,37,32,1,16]

theorem envBound33957 : H12AffineFastState.Bounded env33957 := by
  intro p hp
  have h : env33957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33956_33957 : H12AffineEnvironment.transform 8 17 env33956 = env33957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env33956 == env33957) = true)

theorem identity33957 : scanCanonicalize (H12AffineFastState.compose env33957 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33957 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33958 : List Nat := [2,4,8,16,11,16,8,15,17,30,0,17,3,1,0,8,17,0,31,1,0,11,16,2,3,16,1,17,17,1,20,11,14,11,1,16]

theorem envBound33958 : H12AffineFastState.Bounded env33958 := by
  intro p hp
  have h : env33958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33957_33958 : H12AffineEnvironment.transform 4 11 env33957 = env33958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33957 == env33958) = true)

theorem identity33958 : scanCanonicalize (H12AffineFastState.compose env33958 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33958 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33959 : List Nat := [2,4,8,1,11,1,8,15,0,15,0,0,3,1,0,8,0,0,14,1,0,11,1,2,3,1,1,0,0,1,5,11,14,11,1,1]

theorem envBound33959 : H12AffineFastState.Bounded env33959 := by
  intro p hp
  have h : env33959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33958_33959 : H12AffineEnvironment.transform 3 1 env33958 = env33959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33958 == env33959) = true)

def env33960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180273,144477,243088,8328,64,43477,139612,160076,56437,1501,33,257,21793,46213,74250]

theorem envBound33960 : H12AffineFastState.Bounded env33960 := by
  intro p hp
  have h : env33960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33938_33960 : H12AffineEnvironment.transform 17 10281 env33938 = env33960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33938 == env33960) = true)

def env33961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,21793,41293,73856,8328,64,43477,46156,58460,56437,1501,33,257,21793,46213,74250]

theorem envBound33961 : H12AffineFastState.Bounded env33961 := by
  intro p hp
  have h : env33961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33960_33961 : H12AffineEnvironment.transform 16 38160 env33960 = env33961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env33960 == env33961) = true)

theorem identity33961 : scanCanonicalize (H12AffineFastState.compose env33961 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33961 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,21793,41293,73737,8193,64,43356,46156,58460,56437,1364,33,257,21793,46092,74250]

theorem envBound33962 : H12AffineFastState.Bounded env33962 := by
  intro p hp
  have h : env33962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33961_33962 : H12AffineEnvironment.transform 6 9 env33961 = env33962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33961 == env33962) = true)

theorem identity33962 : scanCanonicalize (H12AffineFastState.compose env33962 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound33962 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,10281,1025,32769,4161,21793,41293,54531,8193,64,43356,46156,58460,56437,1364,33,257,21793,46092,55040]

theorem envBound33963 : H12AffineFastState.Bounded env33963 := by
  intro p hp
  have h : env33963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33962_33963 : H12AffineEnvironment.transform 15 62730 env33962 = env33963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env33962 == env33963) = true)

theorem identity33963 : scanCanonicalize (H12AffineFastState.compose env33963 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound33963 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,29962,5392,10281,1025,1,4161,21793,8525,21763,8193,64,10588,13388,25692,23669,1364,33,257,21793,13324,22272]

theorem envBound33964 : H12AffineFastState.Bounded env33964 := by
  intro p hp
  have h : env33964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33963_33964 : H12AffineEnvironment.transform 14 0 env33963 = env33964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env33963 == env33964) = true)

theorem identity33964 : scanCanonicalize (H12AffineFastState.compose env33964 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound33964 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env33965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,263,5392,10281,1025,1,4161,8492,8525,8462,8193,64,10588,13388,4177,10360,1364,33,257,8492,13324,8973]

theorem envBound33965 : H12AffineFastState.Bounded env33965 := by
  intro p hp
  have h : env33965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33964_33965 : H12AffineEnvironment.transform 13 13325 env33964 = env33965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env33964 == env33965) = true)

theorem identity33965 : scanCanonicalize (H12AffineFastState.compose env33965 (packedSelected [0,3,5,6,7,10,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33965 : packedSelected [0,3,5,6,7,10,14,16] rootPS < 2^1333 := by decide +kernel

def env33966 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,263,5392,10281,1025,1,4112,8492,8476,8462,8193,17,10509,13341,4096,10281,1285,33,257,8492,13324,8973]

theorem envBound33966 : H12AffineFastState.Bounded env33966 := by
  intro p hp
  have h : env33966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33965_33966 : H12AffineEnvironment.transform 5 17 env33965 = env33966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33965 == env33966) = true)

theorem identity33966 : scanCanonicalize (H12AffineFastState.compose env33966 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound33966 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env33967 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2096,8192,11325,0,263,3360,10281,1025,1,2080,8492,8476,8462,8193,17,10509,11309,2096,10281,1285,33,257,8492,11324,8973]

theorem envBound33967 : H12AffineFastState.Bounded env33967 := by
  intro p hp
  have h : env33967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33966_33967 : H12AffineEnvironment.transform 11 2096 env33966 = env33967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env33966 == env33967) = true)

theorem identity33967 : scanCanonicalize (H12AffineFastState.compose env33967 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound33967 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33968 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2096,1304,2341,0,263,3360,3377,1025,1,2080,1076,1028,1046,1305,17,3093,2357,2096,3377,1285,33,257,1076,2340,1557]

theorem envBound33968 : H12AffineFastState.Bounded env33968 := by
  intro p hp
  have h : env33968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33967_33968 : H12AffineEnvironment.transform 12 1304 env33967 = env33968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env33967 == env33968) = true)

theorem identity33968 : scanCanonicalize (H12AffineFastState.compose env33968 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33968 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env33969 : List Nat := [2,4,8,16,32,17,9,256,512,21,2048,2096,269,2341,0,263,2357,2340,20,1,2080,33,17,3,268,17,2048,2357,2096,2340,272,33,257,33,2340,512]

theorem envBound33969 : H12AffineFastState.Bounded env33969 := by
  intro p hp
  have h : env33969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33968_33969 : H12AffineEnvironment.transform 9 21 env33968 = env33969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33968 == env33969) = true)

theorem identity33969 : scanCanonicalize (H12AffineFastState.compose env33969 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33970 : List Nat := [2,4,8,16,32,17,9,256,512,21,49,1,269,276,0,263,260,277,20,1,17,33,17,3,268,17,49,260,1,277,272,33,257,33,277,512]

theorem envBound33970 : H12AffineFastState.Bounded env33970 := by
  intro p hp
  have h : env33970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33969_33970 : H12AffineEnvironment.transform 10 49 env33969 = env33970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33969 == env33970) = true)

theorem identity33970 : scanCanonicalize (H12AffineFastState.compose env33970 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound33970 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33971 : List Nat := [2,4,8,16,32,17,9,256,32,21,49,1,269,276,0,263,260,277,20,1,17,33,17,3,268,17,49,260,1,277,272,33,257,33,277,32]

theorem envBound33971 : H12AffineFastState.Bounded env33971 := by
  intro p hp
  have h : env33971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33970_33971 : H12AffineEnvironment.transform 8 32 env33970 = env33971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env33970 == env33971) = true)

theorem identity33971 : scanCanonicalize (H12AffineFastState.compose env33971 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33971 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33972 : List Nat := [2,4,8,16,1,17,9,256,1,21,16,1,269,276,0,263,260,277,20,1,17,0,17,3,268,17,16,260,1,277,272,0,257,0,277,1]

theorem envBound33972 : H12AffineFastState.Bounded env33972 := by
  intro p hp
  have h : env33972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33971_33972 : H12AffineEnvironment.transform 4 1 env33971 = env33972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33971 == env33972) = true)

theorem identity33972 : scanCanonicalize (H12AffineFastState.compose env33972 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33973 : List Nat := [2,4,8,1,1,0,9,256,1,4,1,1,269,261,0,263,260,260,5,1,0,0,0,3,268,0,1,260,1,260,257,0,257,0,260,1]

theorem envBound33973 : H12AffineFastState.Bounded env33973 := by
  intro p hp
  have h : env33973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33972_33973 : H12AffineEnvironment.transform 3 1 env33972 = env33973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33972 == env33973) = true)

def env33974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,21792,41292,73857,8328,64,43477,46157,58461,56437,1501,33,257,21793,46213,74250]

theorem envBound33974 : H12AffineFastState.Bounded env33974 := by
  intro p hp
  have h : env33974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33960_33974 : H12AffineEnvironment.transform 16 38161 env33960 = env33974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env33960 == env33974) = true)

theorem identity33974 : scanCanonicalize (H12AffineFastState.compose env33974 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound33974 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38161,10281,1025,32769,4161,21792,41292,3,8328,64,43477,46157,58461,56437,1501,33,257,21793,46213,648]

theorem envBound33975 : H12AffineFastState.Bounded env33975 := by
  intro p hp
  have h : env33975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33974_33975 : H12AffineEnvironment.transform 15 8322 env33974 = env33975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env33974 == env33975) = true)

theorem identity33975 : scanCanonicalize (H12AffineFastState.compose env33975 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33975 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env33976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,479,38161,2420,1025,32769,4161,21792,32785,3,469,64,34952,38160,50432,56437,1501,33,257,21793,38360,648]

theorem envBound33976 : H12AffineFastState.Bounded env33976 := by
  intro p hp
  have h : env33976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33975_33976 : H12AffineEnvironment.transform 12 349 env33975 = env33976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33975 == env33976) = true)

theorem identity33976 : scanCanonicalize (H12AffineFastState.compose env33976 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound33976 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env33977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,217,479,5576,2420,1025,216,4161,21792,200,3,469,64,2129,5577,17881,23724,1501,33,257,21793,5377,648]

theorem envBound33977 : H12AffineFastState.Bounded env33977 := by
  intro p hp
  have h : env33977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33976_33977 : H12AffineEnvironment.transform 14 217 env33976 = env33977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env33976 == env33977) = true)

theorem identity33977 : scanCanonicalize (H12AffineFastState.compose env33977 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound33977 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33978 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,0,262,5393,2420,1025,1,4161,21792,17,3,268,64,2129,5392,17664,23669,1284,33,257,21793,5377,593]

theorem envBound33978 : H12AffineFastState.Bounded env33978 := by
  intro p hp
  have h : env33978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33977_33978 : H12AffineEnvironment.transform 6 89 env33977 = env33978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env33977 == env33978) = true)

theorem identity33978 : scanCanonicalize (H12AffineFastState.compose env33978 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33978 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env33979 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5377,0,262,5393,2420,1025,1,4161,33,17,3,268,64,2129,5392,4097,2420,1284,33,257,32,5377,593]

theorem envBound33979 : H12AffineFastState.Bounded env33979 := by
  intro p hp
  have h : env33979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33978_33979 : H12AffineEnvironment.transform 13 5377 env33978 = env33979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33978 == env33979) = true)

theorem identity33979 : scanCanonicalize (H12AffineFastState.compose env33979 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 868) := by decide +kernel

theorem selectedBound33979 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env33980 : List Nat := [2,4,8,16,32,64,89,256,512,1024,868,4096,349,5377,0,262,5393,528,1025,1,4161,33,17,3,268,64,821,5392,4097,528,1284,33,257,32,5377,593]

theorem envBound33980 : H12AffineFastState.Bounded env33980 := by
  intro p hp
  have h : env33980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33979_33980 : H12AffineEnvironment.transform 10 868 env33979 = env33980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 868 env33979 == env33980) = true)

theorem identity33980 : scanCanonicalize (H12AffineFastState.compose env33980 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound33980 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env33981 : List Nat := [2,4,8,16,32,48,41,256,512,1024,788,4096,301,5377,0,262,5393,528,1025,1,4145,33,17,3,268,48,821,5392,4097,528,1284,33,257,32,5377,545]

theorem envBound33981 : H12AffineFastState.Bounded env33981 := by
  intro p hp
  have h : env33981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33980_33981 : H12AffineEnvironment.transform 5 48 env33980 = env33981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env33980 == env33981) = true)

theorem identity33981 : scanCanonicalize (H12AffineFastState.compose env33981 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound33981 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env33982 : List Nat := [2,4,8,16,32,48,41,256,512,1024,788,1557,301,788,0,262,772,528,1025,1,1572,33,17,3,268,48,821,773,1556,528,1284,33,257,32,788,545]

theorem envBound33982 : H12AffineFastState.Bounded env33982 := by
  intro p hp
  have h : env33982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33981_33982 : H12AffineEnvironment.transform 11 1557 env33981 = env33982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env33981 == env33982) = true)

theorem identity33982 : scanCanonicalize (H12AffineFastState.compose env33982 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33982 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33983 : List Nat := [2,4,8,16,32,48,41,256,512,21,788,512,301,788,0,262,772,528,20,1,561,33,17,3,268,48,821,773,513,528,273,33,257,32,788,545]

theorem envBound33983 : H12AffineFastState.Bounded env33983 := by
  intro p hp
  have h : env33983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33982_33983 : H12AffineEnvironment.transform 9 21 env33982 = env33983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33982 == env33983) = true)

theorem identity33983 : scanCanonicalize (H12AffineFastState.compose env33983 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33983 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env33984 : List Nat := [2,4,8,16,32,48,41,37,512,21,561,512,8,561,0,35,545,528,20,1,561,33,17,3,41,48,528,544,513,528,52,33,36,32,561,545]

theorem envBound33984 : H12AffineFastState.Bounded env33984 := by
  intro p hp
  have h : env33984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33983_33984 : H12AffineEnvironment.transform 7 37 env33983 = env33984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33983 == env33984) = true)

theorem identity33984 : scanCanonicalize (H12AffineFastState.compose env33984 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33984 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33985 : List Nat := [2,4,8,16,1,17,8,4,512,21,528,512,8,528,0,2,512,528,20,1,528,0,17,3,8,17,528,513,513,528,21,0,5,1,528,512]

theorem envBound33985 : H12AffineFastState.Bounded env33985 := by
  intro p hp
  have h : env33985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33984_33985 : H12AffineEnvironment.transform 4 1 env33984 = env33985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33984 == env33985) = true)

theorem identity33985 : scanCanonicalize (H12AffineFastState.compose env33985 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33985 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33986 : List Nat := [2,4,8,16,1,17,8,4,1,21,17,1,8,17,0,2,1,17,20,1,17,0,17,3,8,17,17,0,0,17,21,0,5,1,17,1]

theorem envBound33986 : H12AffineFastState.Bounded env33986 := by
  intro p hp
  have h : env33986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33985_33986 : H12AffineEnvironment.transform 8 1 env33985 = env33986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33985 == env33986) = true)

theorem identity33986 : scanCanonicalize (H12AffineFastState.compose env33986 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33987 : List Nat := [2,1,8,16,1,17,8,1,1,16,17,1,8,17,0,2,1,17,17,1,17,0,17,3,8,17,17,0,0,17,16,0,0,1,17,1]

theorem envBound33987 : H12AffineFastState.Bounded env33987 := by
  intro p hp
  have h : env33987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33986_33987 : H12AffineEnvironment.transform 1 1 env33986 = env33987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33986 == env33987) = true)

theorem identity33987 : scanCanonicalize (H12AffineFastState.compose env33987 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33987 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33988 : List Nat := [2,1,8,0,1,1,8,1,1,0,1,1,8,1,0,2,1,1,1,1,1,0,1,3,8,1,1,0,0,1,0,0,0,1,1,1]

theorem envBound33988 : H12AffineFastState.Bounded env33988 := by
  intro p hp
  have h : env33988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33987_33988 : H12AffineEnvironment.transform 3 0 env33987 = env33988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33987 == env33988) = true)

def env33989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237468,243088,8328,64,2144661,2240797,160076,2417693,2102684,2373704,257,21793,46213,2175563]

theorem envBound33989 : H12AffineFastState.Bounded env33989 := by
  intro p hp
  have h : env33989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33927_33989 : H12AffineEnvironment.transform 21 452633 env33927 = env33989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env33927 == env33989) = true)

def env33990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144476,243088,8328,64,43477,139613,160076,324701,1500,272392,257,21793,46213,74251]

theorem envBound33990 : H12AffineFastState.Bounded env33990 := by
  intro p hp
  have h : env33990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33989_33990 : H12AffineEnvironment.transform 20 4160 env33989 = env33990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33989 == env33990) = true)

theorem identity33990 : scanCanonicalize (H12AffineFastState.compose env33990 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound33990 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,400589,144476,213316,8328,64,23809,139613,160076,262281,1500,272392,257,21793,16465,74251]

theorem envBound33991 : H12AffineFastState.Bounded env33991 := by
  intro p hp
  have h : env33991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33990_33991 : H12AffineEnvironment.transform 14 29908 env33990 = env33991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env33990 == env33991) = true)

def env33992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32240,1025,29909,4160,155965,144476,213316,8328,64,23809,139613,160076,32121,1500,22008,257,21793,16465,74251]

theorem envBound33992 : H12AffineFastState.Bounded env33992 := by
  intro p hp
  have h : env33992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33991_33992 : H12AffineEnvironment.transform 17 32240 env33991 = env33992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env33991 == env33992) = true)

theorem identity33992 : scanCanonicalize (H12AffineFastState.compose env33992 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound33992 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79179,32240,1025,29909,4160,87158,65815,29711,8328,64,23809,70678,82951,32121,1500,22008,257,21793,16465,74251]

theorem envBound33993 : H12AffineFastState.Bounded env33993 := by
  intro p hp
  have h : env33993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33992_33993 : H12AffineEnvironment.transform 16 79179 env33992 = env33993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env33992 == env33993) = true)

theorem identity33993 : scanCanonicalize (H12AffineFastState.compose env33993 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound33993 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env33994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,16585,32240,1025,29909,4160,8692,29845,29711,8328,64,23809,24980,12677,32121,1500,22008,257,21793,16465,22409]

theorem envBound33994 : H12AffineFastState.Bounded env33994 := by
  intro p hp
  have h : env33994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33993_33994 : H12AffineEnvironment.transform 15 30082 env33993 = env33994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env33993 == env33994) = true)

theorem identity33994 : scanCanonicalize (H12AffineFastState.compose env33994 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33994 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33995 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29708,30042,16401,32040,1025,29709,4160,8492,29773,29711,8272,64,23809,24908,12637,32121,1284,21792,257,21793,16465,22353]

theorem envBound33995 : H12AffineFastState.Bounded env33995 := by
  intro p hp
  have h : env33995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33994_33995 : H12AffineEnvironment.transform 6 88 env33994 = env33995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33994 == env33995) = true)

theorem identity33995 : scanCanonicalize (H12AffineFastState.compose env33995 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound33995 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env33996 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13405,81,263,13388,2421,1025,80,4160,8492,16,82,8272,64,10588,5393,12637,2340,1284,8573,257,8572,13324,8972]

theorem envBound33996 : H12AffineFastState.Bounded env33996 := by
  intro p hp
  have h : env33996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33995_33996 : H12AffineEnvironment.transform 13 13405 env33995 = env33996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env33995 == env33996) = true)

theorem identity33996 : scanCanonicalize (H12AffineFastState.compose env33996 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33996 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env33997 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,81,263,5441,2421,1025,80,4160,33,16,82,349,64,2129,5393,4176,2340,1284,112,257,113,5377,513]

theorem envBound33997 : H12AffineFastState.Bounded env33997 := by
  intro p hp
  have h : env33997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33996_33997 : H12AffineEnvironment.transform 12 269 env33996 = env33997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33996 == env33997) = true)

theorem identity33997 : scanCanonicalize (H12AffineFastState.compose env33997 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33997 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33998 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,121,5156,81,115,5173,2049,1025,80,4160,33,16,82,41,64,2129,5221,4176,2128,1136,112,117,113,5237,513]

theorem envBound33998 : H12AffineFastState.Bounded env33998 := by
  intro p hp
  have h : env33998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33997_33998 : H12AffineEnvironment.transform 7 116 env33997 = env33998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33997 == env33998) = true)

def env33999 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4112,33,16,2,41,16,2049,5173,4096,2048,1056,32,37,33,5157,513]

theorem envBound33999 : H12AffineFastState.Bounded env33999 := by
  intro p hp
  have h : env33999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33998_33999 : H12AffineEnvironment.transform 5 16 env33998 = env33999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33998 == env33999) = true)

theorem identity33999 : scanCanonicalize (H12AffineFastState.compose env33999 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33999 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34000 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,1,35,4097,2049,53,0,4112,33,16,2,41,16,2049,4097,4096,2048,20,32,37,33,4113,513]

theorem envBound34000 : H12AffineFastState.Bounded env34000 := by
  intro p hp
  have h : env34000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33999_34000 : H12AffineEnvironment.transform 9 52 env33999 = env34000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33999 == env34000) = true)

theorem identity34000 : scanCanonicalize (H12AffineFastState.compose env34000 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound34000 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34001 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,4096,41,4112,1,35,4097,49,53,0,4112,33,16,2,41,16,49,4097,4096,48,20,32,37,33,4113,513]

theorem envBound34001 : H12AffineFastState.Bounded env34001 := by
  intro p hp
  have h : env34001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34000_34001 : H12AffineEnvironment.transform 10 48 env34000 = env34001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env34000 == env34001) = true)

theorem identity34001 : scanCanonicalize (H12AffineFastState.compose env34001 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound34001 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34002 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,41,48,1,35,33,49,53,0,48,33,16,2,41,16,49,33,32,48,20,32,37,33,49,513]

theorem envBound34002 : H12AffineFastState.Bounded env34002 := by
  intro p hp
  have h : env34002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34001_34002 : H12AffineEnvironment.transform 11 32 env34001 = env34002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env34001 == env34002) = true)

def leafEnv34002 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,41,48,1,35,33,49,53,0,48,33,16,2,21,41,1,16,49,33,32,48,20,32,37,33,5,35,49,513,1,49,0]

def active34002 : List Nat := [0,1,2,3,4,8]

def tree34002 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34002 : H12WitnessSearch.Good tree34002 := H12GlobalWitnessIndex.good

theorem leafIdentity34002 : H12AffineFastState.composeSystem env34002 rootObs = leafEnv34002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34002 rootObs == leafEnv34002) = true)

theorem terminalChecked34002 : H12PackedTerminal.terminalCheckFast leafEnv34002 active34002 tree34002 = true := by decide +kernel

def env34003 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,0,34,5173,2049,1025,1,4113,33,16,3,41,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

end H12CloudChart1