import H12CloudChart1Data007

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans1946_1954 : H12AffineEnvironment.transform 6 41 env1946 = env1954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1946 == env1954) = true)

theorem identity1954 : scanCanonicalize (H12AffineFastState.compose env1954 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound1954 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1955 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,8574,5125,262144,1025,8541,2097152,32,21572,35,8225,21525,283764,16384,17412,2081,1024,21588,257,1,5125,22101]

theorem envBound1955 : H12AffineFastState.Bounded env1955 := by
  intro p hp
  have h : env1955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1954_1955 : H12AffineEnvironment.transform 21 32 env1954 = env1955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env1954 == env1955) = true)

theorem identity1955 : scanCanonicalize (H12AffineFastState.compose env1955 (packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 289901) := by decide +kernel

theorem selectedBound1955 : packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env1956 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,8574,5125,262144,1025,8541,289901,32,21572,35,8225,21525,283764,16384,17412,2081,1024,21588,257,1,5125,22101]

theorem envBound1956 : H12AffineFastState.Bounded env1956 := by
  intro p hp
  have h : env1956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1955_1956 : H12AffineEnvironment.transform 20 289901 env1955 = env1956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 289901 env1955 == env1956) = true)

theorem identity1956 : scanCanonicalize (H12AffineFastState.compose env1956 (packedSelected [0,1,2,4,6,7,8,9,13,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound1956 : packedSelected [0,1,2,4,6,7,8,9,13,19] rootPS < 2^1333 := by decide +kernel

def env1957 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5376,8541,8574,5125,262144,1025,8541,276845,32,324,35,8225,277,262516,5376,4356,2081,1024,340,257,1,5125,853]

theorem envBound1957 : H12AffineFastState.Bounded env1957 := by
  intro p hp
  have h : env1957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1956_1957 : H12AffineEnvironment.transform 13 5376 env1956 = env1957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env1956 == env1957) = true)

theorem identity1957 : scanCanonicalize (H12AffineFastState.compose env1957 (packedSelected [2,6,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound1957 : packedSelected [2,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env1958 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5376,8541,8574,5125,2340,1025,8541,12361,32,324,35,8225,277,2128,5376,4356,2081,1024,340,257,1,5125,853]

theorem envBound1958 : H12AffineFastState.Bounded env1958 := by
  intro p hp
  have h : env1958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1957_1958 : H12AffineEnvironment.transform 17 2340 env1957 = env1958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env1957 == env1958) = true)

theorem identity1958 : scanCanonicalize (H12AffineFastState.compose env1958 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound1958 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1959 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,5205,8200,8235,5125,2161,1025,8200,12361,32,17,35,8225,64,2128,5205,4177,2081,1024,1,84,1,5125,512]

theorem envBound1959 : H12AffineFastState.Bounded env1959 := by
  intro p hp
  have h : env1959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1958_1959 : H12AffineEnvironment.transform 7 85 env1958 = env1959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env1958 == env1959) = true)

theorem identity1959 : scanCanonicalize (H12AffineFastState.compose env1959 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound1959 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1960 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,5677,5205,5669,5638,5125,2161,1025,5669,1636,32,17,35,5644,64,2128,5205,4177,2081,1024,1,84,1,5125,512]

theorem envBound1960 : H12AffineFastState.Bounded env1960 := by
  intro p hp
  have h : env1960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1959_1960 : H12AffineEnvironment.transform 12 5677 env1959 = env1960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env1959 == env1960) = true)

theorem identity1960 : scanCanonicalize (H12AffineFastState.compose env1960 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1652) := by decide +kernel

theorem selectedBound1960 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env1961 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,1652,89,545,81,114,625,2161,1025,81,1636,32,17,35,120,64,2128,545,1573,2081,1024,1,84,1,625,512]

theorem envBound1961 : H12AffineFastState.Bounded env1961 := by
  intro p hp
  have h : env1961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1960_1961 : H12AffineEnvironment.transform 11 1652 env1960 = env1961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1652 env1960 == env1961) = true)

theorem identity1961 : scanCanonicalize (H12AffineFastState.compose env1961 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound1961 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1962 : List Nat := [2,4,8,16,32,64,41,85,512,5,2048,625,89,545,81,114,625,2161,4,81,609,32,17,35,120,64,2128,545,544,2081,5,1,84,1,625,512]

theorem envBound1962 : H12AffineFastState.Bounded env1962 := by
  intro p hp
  have h : env1962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1961_1962 : H12AffineEnvironment.transform 9 5 env1961 = env1962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env1961 == env1962) = true)

theorem identity1962 : scanCanonicalize (H12AffineFastState.compose env1962 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound1962 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1963 : List Nat := [2,4,8,16,32,64,41,85,512,5,586,625,89,545,81,114,625,571,4,81,609,32,17,35,120,64,538,545,544,619,5,1,84,1,625,512]

theorem envBound1963 : H12AffineFastState.Bounded env1963 := by
  intro p hp
  have h : env1963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1962_1963 : H12AffineEnvironment.transform 10 586 env1962 = env1963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env1962 == env1963) = true)

def env1964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16384,151553,2081,16852468,4341976,257,1,131073,16925299]

theorem envBound1964 : H12AffineFastState.Bounded env1964 := by
  intro p hp
  have h : env1964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1942_1964 : H12AffineEnvironment.transform 34 131073 env1942 = env1964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1942 == env1964) = true)

theorem identity1964 : scanCanonicalize (H12AffineFastState.compose env1964 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 206290) := by decide +kernel

theorem selectedBound1964 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,206290,4194304,147521,16777216,8328,147472,409816,16384,151553,2081,16852468,4341976,257,1,131073,16925299]

theorem envBound1965 : H12AffineFastState.Bounded env1965 := by
  intro p hp
  have h : env1965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1964_1965 : H12AffineEnvironment.transform 20 206290 env1964 = env1965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206290 env1964 == env1965) = true)

theorem identity1965 : scanCanonicalize (H12AffineFastState.compose env1965 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound1965 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,206290,4194304,147521,138,8328,147472,409816,16384,151553,2081,75134,4341976,257,1,131073,148217]

theorem envBound1966 : H12AffineFastState.Bounded env1966 := by
  intro p hp
  have h : env1966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1965_1966 : H12AffineEnvironment.transform 23 138 env1965 = env1966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env1965 == env1966) = true)

theorem identity1966 : scanCanonicalize (H12AffineFastState.compose env1966 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 147749) := by decide +kernel

theorem selectedBound1966 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env1967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,206290,147749,147521,138,8328,147472,409816,16384,151553,2081,75134,509,257,1,131073,148217]

theorem envBound1967 : H12AffineFastState.Bounded env1967 := by
  intro p hp
  have h : env1967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1966_1967 : H12AffineEnvironment.transform 21 147749 env1966 = env1967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147749 env1966 == env1967) = true)

theorem identity1967 : scanCanonicalize (H12AffineFastState.compose env1967 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1967 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env1968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1025,8692,132268,147749,147521,138,8328,147472,409816,16384,151553,2081,1024,509,257,1,131073,148217]

theorem envBound1968 : H12AffineFastState.Bounded env1968 := by
  intro p hp
  have h : env1968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1967_1968 : H12AffineEnvironment.transform 15 8574 env1967 = env1968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1967 == env1968) = true)

def env1969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,262144,1025,8692,17492,477,185,138,8328,232,262176,16384,4345,2081,1024,509,257,1,16633,513]

theorem envBound1969 : H12AffineFastState.Bounded env1969 := by
  intro p hp
  have h : env1969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1968_1969 : H12AffineEnvironment.transform 16 16632 env1968 = env1969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1968 == env1969) = true)

theorem identity1969 : scanCanonicalize (H12AffineFastState.compose env1969 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13809) := by decide +kernel

theorem selectedBound1969 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13809,8692,8574,13577,262144,1025,8692,12709,477,185,138,8328,232,262176,13809,4345,2081,1024,509,257,1,13576,513]

theorem envBound1970 : H12AffineFastState.Bounded env1970 := by
  intro p hp
  have h : env1970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1969_1970 : H12AffineEnvironment.transform 13 13809 env1969 = env1970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13809 env1969 == env1970) = true)

theorem identity1970 : scanCanonicalize (H12AffineFastState.compose env1970 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound1970 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,9,5624,509,375,5376,262144,1025,509,4524,477,185,138,129,232,262176,5624,4345,2081,1024,509,257,1,5377,513]

theorem envBound1971 : H12AffineFastState.Bounded env1971 := by
  intro p hp
  have h : env1971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1970_1971 : H12AffineEnvironment.transform 12 9 env1970 = env1971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env1970 == env1971) = true)

theorem identity1971 : scanCanonicalize (H12AffineFastState.compose env1971 (packedSelected [4,6,9,20] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound1971 : packedSelected [4,6,9,20] rootPS < 2^1333 := by decide +kernel

def env1972 : List Nat := [2,4,8,16,32,64,104,256,512,1024,2048,4096,9,5392,277,375,5376,262144,1025,277,4420,309,81,98,105,0,262176,5392,4113,2081,1024,277,257,1,5377,513]

theorem envBound1972 : H12AffineFastState.Bounded env1972 := by
  intro p hp
  have h : env1972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1971_1972 : H12AffineEnvironment.transform 6 104 env1971 = env1972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env1971 == env1972) = true)

theorem identity1972 : scanCanonicalize (H12AffineFastState.compose env1972 (packedSelected [0,2,7,11,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 2357) := by decide +kernel

theorem selectedBound1972 : packedSelected [0,2,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env1973 : List Nat := [2,4,8,16,32,64,104,256,512,1024,2048,4096,9,5392,277,375,5376,2357,1025,277,4420,309,81,98,105,0,2325,5392,4113,2081,1024,277,257,1,5377,513]

theorem envBound1973 : H12AffineFastState.Bounded env1973 := by
  intro p hp
  have h : env1973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1972_1973 : H12AffineEnvironment.transform 17 2357 env1972 = env1973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2357 env1972 == env1973) = true)

theorem identity1973 : scanCanonicalize (H12AffineFastState.compose env1973 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1973 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env1974 : List Nat := [2,4,8,1,32,64,104,256,512,1024,2048,4096,9,5377,260,358,5376,2340,1025,260,4420,292,64,98,105,0,2308,5377,4096,2081,1024,260,257,1,5377,513]

theorem envBound1974 : H12AffineFastState.Bounded env1974 := by
  intro p hp
  have h : env1974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1973_1974 : H12AffineEnvironment.transform 3 1 env1973 = env1974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1973 == env1974) = true)

theorem identity1974 : scanCanonicalize (H12AffineFastState.compose env1974 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound1974 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env1975 : List Nat := [2,4,8,1,32,64,104,256,512,1024,2048,357,9,1124,260,358,1125,2340,1025,260,33,292,64,98,105,0,2308,1124,357,2081,1024,260,257,1,1124,513]

theorem envBound1975 : H12AffineFastState.Bounded env1975 := by
  intro p hp
  have h : env1975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1974_1975 : H12AffineEnvironment.transform 11 357 env1974 = env1975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env1974 == env1975) = true)

theorem identity1975 : scanCanonicalize (H12AffineFastState.compose env1975 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1615) := by decide +kernel

theorem selectedBound1975 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env1976 : List Nat := [2,4,8,1,32,64,104,256,512,1024,1615,357,9,1124,260,358,1125,1899,1025,260,33,292,64,98,105,0,1867,1124,357,1646,1024,260,257,1,1124,513]

theorem envBound1976 : H12AffineFastState.Bounded env1976 := by
  intro p hp
  have h : env1976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1975_1976 : H12AffineEnvironment.transform 10 1615 env1975 = env1976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1615 env1975 == env1976) = true)

theorem identity1976 : scanCanonicalize (H12AffineFastState.compose env1976 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound1976 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1977 : List Nat := [2,4,8,1,32,64,104,69,512,1024,1615,32,9,1124,65,35,1125,1582,1025,65,33,97,64,98,105,0,1550,1124,32,1646,1024,65,68,1,1124,513]

theorem envBound1977 : H12AffineFastState.Bounded env1977 := by
  intro p hp
  have h : env1977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1976_1977 : H12AffineEnvironment.transform 7 69 env1976 = env1977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env1976 == env1977) = true)

def env1978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1025,8692,17493,476,184,138,8328,233,262177,16384,4344,2081,1024,509,257,1,16632,512]

theorem envBound1978 : H12AffineFastState.Bounded env1978 := by
  intro p hp
  have h : env1978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1968_1978 : H12AffineEnvironment.transform 16 16633 env1968 = env1978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1968 == env1978) = true)

theorem identity1978 : scanCanonicalize (H12AffineFastState.compose env1978 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound1978 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,10281,1025,8692,17493,476,184,138,8328,233,10248,16384,4344,2081,1024,509,257,1,16632,512]

theorem envBound1979 : H12AffineFastState.Bounded env1979 := by
  intro p hp
  have h : env1979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1978_1979 : H12AffineEnvironment.transform 17 10281 env1978 = env1979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env1978 == env1979) = true)

theorem identity1979 : scanCanonicalize (H12AffineFastState.compose env1979 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound1979 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env1980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,16384,81,219,16633,2444,1025,81,17493,476,184,138,301,233,2477,16384,4344,2081,1024,509,257,1,16632,512]

theorem envBound1980 : H12AffineFastState.Bounded env1980 := by
  intro p hp
  have h : env1980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1979_1980 : H12AffineEnvironment.transform 12 421 env1979 = env1980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env1979 == env1980) = true)

theorem identity1980 : scanCanonicalize (H12AffineFastState.compose env1980 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound1980 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1981 : List Nat := [2,4,8,16,32,64,57,256,512,1024,2048,4096,284,16384,81,98,16448,2357,1025,81,17493,357,1,51,301,80,2324,16384,4161,2081,1024,324,257,1,16449,512]

theorem envBound1981 : H12AffineFastState.Bounded env1981 := by
  intro p hp
  have h : env1981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1980_1981 : H12AffineEnvironment.transform 6 57 env1980 = env1981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env1980 == env1981) = true)

def env1982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2081,17375732,13108377,525568,1,34359738368,25691698]

theorem envBound1982 : H12AffineFastState.Bounded env1982 := by
  intro p hp
  have h : env1982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1822_1982 : H12AffineEnvironment.transform 14 8693 env1822 = env1982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1822 == env1982) = true)

theorem identity1982 : scanCanonicalize (H12AffineFastState.compose env1982 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound1982 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913970,8328,8914000,9176216,16384,151553,2081,8463814,13108377,525568,1,34359738368,512]

theorem envBound1983 : H12AffineFastState.Bounded env1983 := by
  intro p hp
  have h : env1983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1982_1983 : H12AffineEnvironment.transform 23 8913970 env1982 = env1983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env1982 == env1983) = true)

theorem identity1983 : scanCanonicalize (H12AffineFastState.compose env1983 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound1983 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,525344,8388608,8913970,8328,8914000,9176216,16384,151553,2081,8463814,8388793,525568,1,34359738368,512]

theorem envBound1984 : H12AffineFastState.Bounded env1984 := by
  intro p hp
  have h : env1984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1983_1984 : H12AffineEnvironment.transform 21 525344 env1983 = env1984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env1983 == env1984) = true)

theorem identity1984 : scanCanonicalize (H12AffineFastState.compose env1984 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound1984 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462668,8328,8462638,8724966,16384,151553,2081,8463814,8388793,73854,1,34359738368,512]

theorem envBound1985 : H12AffineFastState.Bounded env1985 := by
  intro p hp
  have h : env1985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1984_1985 : H12AffineEnvironment.transform 18 75134 env1984 = env1985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env1984 == env1985) = true)

theorem identity1985 : scanCanonicalize (H12AffineFastState.compose env1985 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound1985 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462668,8328,8462638,8724966,16384,151553,2081,8463814,8388793,73854,1,131332,512]

theorem envBound1986 : H12AffineFastState.Bounded env1986 := by
  intro p hp
  have h : env1986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1985_1986 : H12AffineEnvironment.transform 34 131332 env1985 = env1986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env1985 == env1986) = true)

def env1987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,184,74228,8328,74134,336222,16384,151553,2081,75134,1,73854,1,131332,512]

theorem envBound1987 : H12AffineFastState.Bounded env1987 := by
  intro p hp
  have h : env1987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1986_1987 : H12AffineEnvironment.transform 22 184 env1986 = env1987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1986 == env1987) = true)

theorem identity1987 : scanCanonicalize (H12AffineFastState.compose env1987 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223322) := by decide +kernel

theorem selectedBound1987 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,223322,75134,8693,2097152,74078,184,74228,8328,74134,149764,16384,151553,2081,75134,1,73854,1,131332,512]

theorem envBound1988 : H12AffineFastState.Bounded env1988 := by
  intro p hp
  have h : env1988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1987_1988 : H12AffineEnvironment.transform 17 223322 env1987 = env1988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223322 env1987 == env1988) = true)

def env1989 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74882,8201,2097152,73890,184,73736,8328,73834,149752,16384,151553,2081,74882,1,73854,1,131320,512]

theorem envBound1989 : H12AffineFastState.Bounded env1989 := by
  intro p hp
  have h : env1989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1988_1989 : H12AffineEnvironment.transform 7 252 env1988 = env1989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1988 == env1989) = true)

theorem identity1989 : scanCanonicalize (H12AffineFastState.compose env1989 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound1989 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1990 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74882,8201,151553,73890,184,73736,8328,73834,149752,16384,151553,2081,74882,1,73854,1,131320,512]

theorem envBound1990 : H12AffineFastState.Bounded env1990 := by
  intro p hp
  have h : env1990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1989_1990 : H12AffineEnvironment.transform 20 151553 env1989 = env1990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env1989 == env1990) = true)

theorem identity1990 : scanCanonicalize (H12AffineFastState.compose env1990 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound1990 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1991 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,90235,2081,74882,8201,77946,73890,184,73736,8328,73834,75907,16384,77946,2081,74882,1,73854,1,90243,512]

theorem envBound1991 : H12AffineFastState.Bounded env1991 := by
  intro p hp
  have h : env1991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1990_1991 : H12AffineEnvironment.transform 16 90235 env1990 = env1991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env1990 == env1991) = true)

theorem identity1991 : scanCanonicalize (H12AffineFastState.compose env1991 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1991 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1992 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,8323,16632,2081,1025,8201,4345,33,184,139,8328,233,2048,16384,4345,2081,1025,1,253,1,16384,512]

theorem envBound1992 : H12AffineFastState.Bounded env1992 := by
  intro p hp
  have h : env1992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1991_1992 : H12AffineEnvironment.transform 15 8323 env1991 = env1992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1991 == env1992) = true)

theorem identity1992 : scanCanonicalize (H12AffineFastState.compose env1992 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound1992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1993 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8201,8323,5261,2081,1025,8201,4345,33,184,139,8328,233,2048,5237,4345,2081,1025,1,253,1,5237,512]

theorem envBound1993 : H12AffineFastState.Bounded env1993 := by
  intro p hp
  have h : env1993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1992_1993 : H12AffineEnvironment.transform 13 5237 env1992 = env1993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env1992 == env1993) = true)

theorem identity1993 : scanCanonicalize (H12AffineFastState.compose env1993 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound1993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1994 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,602,8201,8323,674,2081,1025,8201,1750,33,184,139,8328,233,2048,602,1750,2081,1025,1,253,1,602,512]

theorem envBound1994 : H12AffineFastState.Bounded env1994 := by
  intro p hp
  have h : env1994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1993_1994 : H12AffineEnvironment.transform 11 1583 env1993 = env1994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env1993 == env1994) = true)

theorem identity1994 : scanCanonicalize (H12AffineFastState.compose env1994 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3823) := by decide +kernel

theorem selectedBound1994 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1995 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3823,602,3814,3692,674,2081,1025,3814,1750,33,184,139,3687,233,2048,602,1750,2081,1025,1,253,1,602,512]

theorem envBound1995 : H12AffineFastState.Bounded env1995 := by
  intro p hp
  have h : env1995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1994_1995 : H12AffineEnvironment.transform 12 3823 env1994 = env1995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3823 env1994 == env1995) = true)

theorem identity1995 : scanCanonicalize (H12AffineFastState.compose env1995 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound1995 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1996 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,554,2794,602,2787,2665,674,2081,4,2787,723,33,184,139,2658,233,2048,602,723,2081,4,1,253,1,602,512]

theorem envBound1996 : H12AffineFastState.Bounded env1996 := by
  intro p hp
  have h : env1996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1995_1996 : H12AffineEnvironment.transform 9 5 env1995 = env1996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env1995 == env1996) = true)

theorem identity1996 : scanCanonicalize (H12AffineFastState.compose env1996 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1996 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1997 : List Nat := [2,4,8,16,32,64,121,5,512,5,2048,554,2579,602,2586,2665,603,2081,4,2586,554,33,65,114,2658,16,2048,602,554,2081,4,1,4,1,602,512]

theorem envBound1997 : H12AffineFastState.Bounded env1997 := by
  intro p hp
  have h : env1997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1996_1997 : H12AffineEnvironment.transform 6 121 env1996 = env1997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1996 == env1997) = true)

theorem identity1997 : scanCanonicalize (H12AffineFastState.compose env1997 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound1997 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1998 : List Nat := [2,4,8,16,32,64,121,5,512,5,608,554,115,602,122,9,603,577,4,122,554,33,65,114,2,16,608,602,554,577,4,1,4,1,602,512]

theorem envBound1998 : H12AffineFastState.Bounded env1998 := by
  intro p hp
  have h : env1998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1997_1998 : H12AffineEnvironment.transform 10 608 env1997 = env1998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env1997 == env1998) = true)

theorem identity1998 : scanCanonicalize (H12AffineFastState.compose env1998 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound1998 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1999 : List Nat := [2,4,8,16,26,64,67,5,512,5,602,528,73,602,64,9,603,577,4,64,528,27,65,72,2,16,602,602,528,577,4,1,4,1,602,512]

theorem envBound1999 : H12AffineFastState.Bounded env1999 := by
  intro p hp
  have h : env1999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1998_1999 : H12AffineEnvironment.transform 4 26 env1998 = env1999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env1998 == env1999) = true)

def env2000 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74883,8200,2097152,73891,184,73737,8328,73835,149753,16384,151553,2081,74883,1,73854,1,131321,512]

theorem envBound2000 : H12AffineFastState.Bounded env2000 := by
  intro p hp
  have h : env2000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1988_2000 : H12AffineEnvironment.transform 7 253 env1988 = env2000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1988 == env2000) = true)

theorem identity2000 : scanCanonicalize (H12AffineFastState.compose env2000 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound2000 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2001 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74883,8200,78035,73891,184,73737,8328,73835,149753,16384,151553,2081,74883,1,73854,1,131321,512]

theorem envBound2001 : H12AffineFastState.Bounded env2001 := by
  intro p hp
  have h : env2001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2000_2001 : H12AffineEnvironment.transform 20 78035 env2000 = env2001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env2000 == env2001) = true)

theorem identity2001 : scanCanonicalize (H12AffineFastState.compose env2001 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound2001 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2002 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7694,8200,65536,131072,210516,74883,8200,78035,73891,184,73737,8328,73835,136951,7694,134671,2081,74883,1,73854,1,131321,512]

theorem envBound2002 : H12AffineFastState.Bounded env2002 := by
  intro p hp
  have h : env2002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2001_2002 : H12AffineEnvironment.transform 13 7694 env2001 = env2002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env2001 == env2002) = true)

def env2003 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,131072,205376,74883,8200,74951,73891,184,73737,8328,73835,131811,2586,134671,2081,74883,1,73854,1,131321,512]

theorem envBound2003 : H12AffineFastState.Bounded env2003 := by
  intro p hp
  have h : env2003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2002_2003 : H12AffineEnvironment.transform 11 1044 env2002 = env2003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env2002 == env2003) = true)

def env2004 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76384,2080,74883,8200,74951,73891,184,73737,8328,73835,75907,2586,74863,2081,74883,1,73854,1,76441,512]

theorem envBound2004 : H12AffineFastState.Bounded env2004 := by
  intro p hp
  have h : env2004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2003_2004 : H12AffineEnvironment.transform 16 76384 env2003 = env2004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2003 == env2004) = true)

theorem identity2004 : scanCanonicalize (H12AffineFastState.compose env2004 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2004 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2005 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,3733,9461,2080,10774,8200,10834,11830,184,11932,8328,12030,9750,2586,11002,2081,10774,1,12011,1,9228,512]

theorem envBound2005 : H12AffineFastState.Bounded env2005 := by
  intro p hp
  have h : env2005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2004_2005 : H12AffineEnvironment.transform 15 3733 env2004 = env2005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2004 == env2005) = true)

theorem identity2005 : scanCanonicalize (H12AffineFastState.compose env2005 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2005 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2006 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2586,3615,3733,2786,2080,1025,3615,1093,33,184,139,3743,233,2049,2586,1261,2081,1025,1,252,1,2587,512]

theorem envBound2006 : H12AffineFastState.Bounded env2006 := by
  intro p hp
  have h : env2006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2005_2006 : H12AffineEnvironment.transform 12 3607 env2005 = env2006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2005 == env2006) = true)

theorem identity2006 : scanCanonicalize (H12AffineFastState.compose env2006 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound2006 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2007 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,64,2627,2586,2635,2753,2786,2080,85,2635,17,33,184,139,2763,233,2049,2586,185,2081,85,1,252,1,2587,512]

theorem envBound2007 : H12AffineFastState.Bounded env2007 := by
  intro p hp
  have h : env2007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2006_2007 : H12AffineEnvironment.transform 9 84 env2006 = env2007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env2006 == env2007) = true)

theorem identity2007 : scanCanonicalize (H12AffineFastState.compose env2007 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2007 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2008 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,64,2627,2586,2635,2665,2634,2080,85,2635,17,33,16,35,2659,65,2049,2586,17,2081,85,1,84,1,2587,512]

theorem envBound2008 : H12AffineFastState.Bounded env2008 := by
  intro p hp
  have h : env2008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2007_2008 : H12AffineEnvironment.transform 6 40 env2007 = env2008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2007 == env2008) = true)

def env2009 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,64,2627,2586,2635,2649,2634,2064,85,2635,17,17,16,19,2643,65,2049,2586,17,2065,85,1,84,1,2587,512]

theorem envBound2009 : H12AffineFastState.Bounded env2009 := by
  intro p hp
  have h : env2009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2008_2009 : H12AffineEnvironment.transform 4 16 env2008 = env2009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2008 == env2009) = true)

def env2010 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,64,579,538,587,601,586,16,85,587,17,17,16,19,595,65,1,538,17,17,85,1,84,1,539,512]

theorem envBound2010 : H12AffineFastState.Bounded env2010 := by
  intro p hp
  have h : env2010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2009_2010 : H12AffineEnvironment.transform 10 0 env2009 = env2010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2009 == env2010) = true)

theorem identity2010 : scanCanonicalize (H12AffineFastState.compose env2010 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2010 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2011 : List Nat := [2,4,5,16,16,64,21,85,512,84,0,64,579,535,582,596,583,16,85,582,17,17,16,19,595,65,1,535,17,17,85,1,84,1,534,512]

theorem envBound2011 : H12AffineFastState.Bounded env2011 := by
  intro p hp
  have h : env2011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2010_2011 : H12AffineEnvironment.transform 2 5 env2010 = env2011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2010 == env2011) = true)

def env2012 : List Nat := [2,4,5,16,16,0,21,21,512,20,0,0,515,535,518,532,519,16,21,518,17,17,16,19,531,1,1,535,17,17,21,1,20,1,534,512]

theorem envBound2012 : H12AffineFastState.Bounded env2012 := by
  intro p hp
  have h : env2012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2011_2012 : H12AffineEnvironment.transform 5 0 env2011 = env2012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2011 == env2012) = true)

theorem identity2012 : scanCanonicalize (H12AffineFastState.compose env2012 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound2012 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2013 : List Nat := [2,4,5,16,16,0,21,21,22,20,0,0,21,1,16,2,17,16,21,16,17,17,16,19,5,1,1,1,17,17,21,1,20,1,0,22]

theorem envBound2013 : H12AffineFastState.Bounded env2013 := by
  intro p hp
  have h : env2013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2012_2013 : H12AffineEnvironment.transform 8 22 env2012 = env2013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env2012 == env2013) = true)

def leafEnv2013 : List Nat := [2,4,5,16,16,0,21,21,22,20,0,0,21,1,16,2,17,16,21,16,17,17,16,19,21,5,1,1,1,1,17,17,21,1,20,1,4,19,0,22,1,16,0]

def active2013 : List Nat := [0,1,3]

def tree2013 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2013 : H12WitnessSearch.Good tree2013 := H12GlobalWitnessIndex.good

theorem leafIdentity2013 : H12AffineFastState.composeSystem env2013 rootObs = leafEnv2013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2013 rootObs == leafEnv2013) = true)

theorem terminalChecked2013 : H12PackedTerminal.terminalCheckFast leafEnv2013 active2013 tree2013 = true := by decide +kernel

def env2014 : List Nat := [2,4,5,16,16,1,21,20,512,21,0,1,514,535,519,533,518,16,20,519,17,17,16,19,530,0,1,535,17,17,20,1,21,1,534,512]

theorem envBound2014 : H12AffineFastState.Bounded env2014 := by
  intro p hp
  have h : env2014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2011_2014 : H12AffineEnvironment.transform 5 1 env2011 = env2014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2011 == env2014) = true)

def leafEnv2014 : List Nat := [2,4,5,16,16,1,21,20,512,21,0,1,514,535,519,533,518,16,20,519,17,17,16,19,20,530,1,0,1,535,17,17,20,1,21,1,4,516,534,512,1,16,0]

def active2014 : List Nat := [0,1,3,8]

def tree2014 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2014 : H12WitnessSearch.Good tree2014 := H12GlobalWitnessIndex.good

theorem leafIdentity2014 : H12AffineFastState.composeSystem env2014 rootObs = leafEnv2014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2014 rootObs == leafEnv2014) = true)

theorem terminalChecked2014 : H12PackedTerminal.terminalCheckFast leafEnv2014 active2014 tree2014 = true := by decide +kernel

def env2015 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,64,578,539,586,600,587,17,85,586,17,17,16,19,594,65,0,539,17,16,85,1,84,1,538,512]

theorem envBound2015 : H12AffineFastState.Bounded env2015 := by
  intro p hp
  have h : env2015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2009_2015 : H12AffineEnvironment.transform 10 1 env2009 = env2015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2009 == env2015) = true)

theorem identity2015 : scanCanonicalize (H12AffineFastState.compose env2015 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2016 : List Nat := [2,4,8,12,12,64,4,73,512,72,1,64,578,519,586,580,587,13,73,586,13,13,12,15,590,65,0,519,13,12,73,1,72,1,518,512]

theorem envBound2016 : H12AffineFastState.Bounded env2016 := by
  intro p hp
  have h : env2016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2015_2016 : H12AffineEnvironment.transform 3 12 env2015 = env2016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2015 == env2016) = true)

def env2017 : List Nat := [2,4,8,12,12,0,4,9,512,8,1,0,514,519,522,516,523,13,9,522,13,13,12,15,526,1,0,519,13,12,9,1,8,1,518,512]

theorem envBound2017 : H12AffineFastState.Bounded env2017 := by
  intro p hp
  have h : env2017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2016_2017 : H12AffineEnvironment.transform 5 0 env2016 = env2017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2016 == env2017) = true)

def leafEnv2017 : List Nat := [2,4,8,12,12,0,4,9,512,8,1,0,514,519,522,516,523,13,9,522,13,13,12,15,9,526,1,1,0,519,13,12,9,1,8,1,4,521,518,512,1,12,0]

def active2017 : List Nat := [0,1,2,8]

def tree2017 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2017 : H12WitnessSearch.Good tree2017 := H12GlobalWitnessIndex.good

theorem leafIdentity2017 : H12AffineFastState.composeSystem env2017 rootObs = leafEnv2017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2017 rootObs == leafEnv2017) = true)

theorem terminalChecked2017 : H12PackedTerminal.terminalCheckFast leafEnv2017 active2017 tree2017 = true := by decide +kernel

def env2018 : List Nat := [2,4,8,12,12,1,4,8,512,9,1,1,515,519,523,517,522,13,8,523,13,13,12,15,527,0,0,519,13,12,8,1,9,1,518,512]

theorem envBound2018 : H12AffineFastState.Bounded env2018 := by
  intro p hp
  have h : env2018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2016_2018 : H12AffineEnvironment.transform 5 1 env2016 = env2018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2016 == env2018) = true)

theorem identity2018 : scanCanonicalize (H12AffineFastState.compose env2018 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2019 : List Nat := [2,4,8,12,12,1,4,8,6,9,1,1,5,1,13,3,12,13,8,13,13,13,12,15,9,0,0,1,13,12,8,1,9,1,0,6]

theorem envBound2019 : H12AffineFastState.Bounded env2019 := by
  intro p hp
  have h : env2019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2018_2019 : H12AffineEnvironment.transform 8 6 env2018 = env2019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2018 == env2019) = true)

def leafEnv2019 : List Nat := [2,4,8,12,12,1,4,8,6,9,1,1,5,1,13,3,12,13,8,13,13,13,12,15,8,9,1,0,0,1,13,12,8,1,9,1,4,14,0,6,1,12,0]

def active2019 : List Nat := [0,1,2]

def tree2019 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2019 : H12WitnessSearch.Good tree2019 := H12GlobalWitnessIndex.good

theorem leafIdentity2019 : H12AffineFastState.composeSystem env2019 rootObs = leafEnv2019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2019 rootObs == leafEnv2019) = true)

theorem terminalChecked2019 : H12PackedTerminal.terminalCheckFast leafEnv2019 active2019 tree2019 = true := by decide +kernel

def env2020 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,64,2627,2586,2635,2648,2634,2065,85,2635,17,16,16,18,2642,65,2049,2586,17,2064,85,1,84,1,2587,512]

theorem envBound2020 : H12AffineFastState.Bounded env2020 := by
  intro p hp
  have h : env2020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2008_2020 : H12AffineEnvironment.transform 4 17 env2008 = env2020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2008 == env2020) = true)

def env2021 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,64,579,538,587,600,586,17,85,587,17,16,16,18,594,65,1,538,17,16,85,1,84,1,539,512]

theorem envBound2021 : H12AffineFastState.Bounded env2021 := by
  intro p hp
  have h : env2021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2020_2021 : H12AffineEnvironment.transform 10 0 env2020 = env2021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2020 == env2021) = true)

theorem identity2021 : scanCanonicalize (H12AffineFastState.compose env2021 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound2021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2022 : List Nat := [2,4,8,16,17,64,25,85,70,84,0,64,5,92,13,30,12,17,85,13,17,16,16,18,20,65,1,92,17,16,85,1,84,1,93,70]

theorem envBound2022 : H12AffineFastState.Bounded env2022 := by
  intro p hp
  have h : env2022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2021_2022 : H12AffineEnvironment.transform 8 70 env2021 = env2022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env2021 == env2022) = true)

def env2023 : List Nat := [2,4,8,16,17,0,25,21,6,20,0,0,5,28,13,30,12,17,21,13,17,16,16,18,20,1,1,28,17,16,21,1,20,1,29,6]

theorem envBound2023 : H12AffineFastState.Bounded env2023 := by
  intro p hp
  have h : env2023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2022_2023 : H12AffineEnvironment.transform 5 0 env2022 = env2023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2022 == env2023) = true)

theorem identity2023 : scanCanonicalize (H12AffineFastState.compose env2023 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2024 : List Nat := [2,4,8,12,13,0,5,9,6,8,0,0,5,0,13,2,12,13,9,13,13,12,12,14,8,1,1,0,13,12,9,1,8,1,1,6]

theorem envBound2024 : H12AffineFastState.Bounded env2024 := by
  intro p hp
  have h : env2024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2023_2024 : H12AffineEnvironment.transform 3 12 env2023 = env2024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2023 == env2024) = true)

def leafEnv2024 : List Nat := [2,4,8,12,13,0,5,9,6,8,0,0,5,0,13,2,12,13,9,13,13,12,12,14,9,8,1,1,1,0,13,12,9,1,8,1,4,14,1,6,1,12,0]

def active2024 : List Nat := [0,1,2]

def tree2024 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2024 : H12WitnessSearch.Good tree2024 := H12GlobalWitnessIndex.good

theorem leafIdentity2024 : H12AffineFastState.composeSystem env2024 rootObs = leafEnv2024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2024 rootObs == leafEnv2024) = true)

theorem terminalChecked2024 : H12PackedTerminal.terminalCheckFast leafEnv2024 active2024 tree2024 = true := by decide +kernel

def env2025 : List Nat := [2,4,8,16,17,1,25,20,7,21,0,1,5,29,13,30,12,17,20,13,17,16,16,18,20,0,1,29,17,16,20,1,21,1,28,7]

theorem envBound2025 : H12AffineFastState.Bounded env2025 := by
  intro p hp
  have h : env2025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2022_2025 : H12AffineEnvironment.transform 5 1 env2022 = env2025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2022 == env2025) = true)

def leafEnv2025 : List Nat := [2,4,8,16,17,1,25,20,7,21,0,1,5,29,13,30,12,17,20,13,17,16,16,18,20,20,1,0,1,29,17,16,20,1,21,1,4,14,28,7,1,16,0]

def active2025 : List Nat := [0,1,2,3]

def tree2025 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2025 : H12WitnessSearch.Good tree2025 := H12GlobalWitnessIndex.good

theorem leafIdentity2025 : H12AffineFastState.composeSystem env2025 rootObs = leafEnv2025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2025 rootObs == leafEnv2025) = true)

theorem terminalChecked2025 : H12PackedTerminal.terminalCheckFast leafEnv2025 active2025 tree2025 = true := by decide +kernel

def env2026 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,64,578,539,586,601,587,16,85,586,17,16,16,18,595,65,0,539,17,17,85,1,84,1,538,512]

theorem envBound2026 : H12AffineFastState.Bounded env2026 := by
  intro p hp
  have h : env2026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2020_2026 : H12AffineEnvironment.transform 10 1 env2020 = env2026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2020 == env2026) = true)

theorem identity2026 : scanCanonicalize (H12AffineFastState.compose env2026 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound2026 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2027 : List Nat := [2,4,8,16,17,64,25,85,87,84,1,64,21,76,29,14,28,16,85,29,17,16,16,18,4,65,0,76,17,17,85,1,84,1,77,87]

theorem envBound2027 : H12AffineFastState.Bounded env2027 := by
  intro p hp
  have h : env2027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2026_2027 : H12AffineEnvironment.transform 8 87 env2026 = env2027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env2026 == env2027) = true)

def env2028 : List Nat := [2,4,8,16,17,0,25,21,23,20,1,0,21,12,29,14,28,16,21,29,17,16,16,18,4,1,0,12,17,17,21,1,20,1,13,23]

theorem envBound2028 : H12AffineFastState.Bounded env2028 := by
  intro p hp
  have h : env2028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2027_2028 : H12AffineEnvironment.transform 5 0 env2027 = env2028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2027 == env2028) = true)

def leafEnv2028 : List Nat := [2,4,8,16,17,0,25,21,23,20,1,0,21,12,29,14,28,16,21,29,17,16,16,18,21,4,1,1,0,12,17,17,21,1,20,1,4,30,13,23,1,16,0]

def active2028 : List Nat := [0,1,2,3]

def tree2028 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2028 : H12WitnessSearch.Good tree2028 := H12GlobalWitnessIndex.good

theorem leafIdentity2028 : H12AffineFastState.composeSystem env2028 rootObs = leafEnv2028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2028 rootObs == leafEnv2028) = true)

theorem terminalChecked2028 : H12PackedTerminal.terminalCheckFast leafEnv2028 active2028 tree2028 = true := by decide +kernel

def env2029 : List Nat := [2,4,8,16,17,1,25,20,22,21,1,1,21,13,29,14,28,16,20,29,17,16,16,18,4,0,0,13,17,17,20,1,21,1,12,22]

theorem envBound2029 : H12AffineFastState.Bounded env2029 := by
  intro p hp
  have h : env2029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2027_2029 : H12AffineEnvironment.transform 5 1 env2027 = env2029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2027 == env2029) = true)

theorem identity2029 : scanCanonicalize (H12AffineFastState.compose env2029 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2029 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2030 : List Nat := [2,4,5,16,17,1,20,20,22,21,1,1,21,0,16,3,17,16,20,16,17,16,16,18,4,0,0,0,17,17,20,1,21,1,1,22]

theorem envBound2030 : H12AffineFastState.Bounded env2030 := by
  intro p hp
  have h : env2030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2029_2030 : H12AffineEnvironment.transform 2 5 env2029 = env2030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2029 == env2030) = true)

def leafEnv2030 : List Nat := [2,4,5,16,17,1,20,20,22,21,1,1,21,0,16,3,17,16,20,16,17,16,16,18,20,4,1,0,0,0,17,17,20,1,21,1,4,19,1,22,1,16,0]

def active2030 : List Nat := [0,1,3]

def tree2030 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2030 : H12WitnessSearch.Good tree2030 := H12GlobalWitnessIndex.good

theorem leafIdentity2030 : H12AffineFastState.composeSystem env2030 rootObs = leafEnv2030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2030 rootObs == leafEnv2030) = true)

theorem terminalChecked2030 : H12PackedTerminal.terminalCheckFast leafEnv2030 active2030 tree2030 = true := by decide +kernel

def env2031 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76385,2081,74883,8200,74951,73891,184,73737,8328,73835,75906,2586,74862,2081,74883,1,73854,1,76440,512]

theorem envBound2031 : H12AffineFastState.Bounded env2031 := by
  intro p hp
  have h : env2031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2003_2031 : H12AffineEnvironment.transform 16 76385 env2003 = env2031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2003 == env2031) = true)

theorem identity2031 : scanCanonicalize (H12AffineFastState.compose env2031 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound2031 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2032 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,225,2586,233,65536,68224,2081,66658,233,66598,65602,184,65768,105,65674,67683,2586,66703,2081,66658,1,65695,1,68217,512]

theorem envBound2032 : H12AffineFastState.Bounded env2032 := by
  intro p hp
  have h : env2032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2031_2032 : H12AffineEnvironment.transform 12 225 env2031 = env2032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env2031 == env2032) = true)

def env2033 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,131072,205377,74883,8200,74950,73891,184,73737,8328,73835,131810,2587,134671,2081,74883,1,73854,1,131321,512]

theorem envBound2033 : H12AffineFastState.Bounded env2033 := by
  intro p hp
  have h : env2033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2002_2033 : H12AffineEnvironment.transform 11 1045 env2002 = env2033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env2002 == env2033) = true)

def env2034 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76384,2081,74883,8200,74950,73891,184,73737,8328,73835,75906,2587,74863,2081,74883,1,73854,1,76441,512]

theorem envBound2034 : H12AffineFastState.Bounded env2034 := by
  intro p hp
  have h : env2034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2033_2034 : H12AffineEnvironment.transform 16 76384 env2033 = env2034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2033 == env2034) = true)

theorem identity2034 : scanCanonicalize (H12AffineFastState.compose env2034 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound2034 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2035 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,99,10755,2081,9440,8200,9381,8384,184,8298,8328,8200,10465,2587,9228,2081,9440,1,8221,1,11002,512]

theorem envBound2035 : H12AffineFastState.Bounded env2035 := by
  intro p hp
  have h : env2035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2034_2035 : H12AffineEnvironment.transform 15 99 env2034 = env2035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env2034 == env2035) = true)

def env2036 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76385,2080,74883,8200,74950,73891,184,73737,8328,73835,75907,2587,74862,2081,74883,1,73854,1,76440,512]

theorem envBound2036 : H12AffineFastState.Bounded env2036 := by
  intro p hp
  have h : env2036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2033_2036 : H12AffineEnvironment.transform 16 76385 env2033 = env2036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2033 == env2036) = true)

theorem identity2036 : scanCanonicalize (H12AffineFastState.compose env2036 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound2036 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2037 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2587,3615,65536,66678,2080,68244,3615,68305,69300,184,69150,3743,69244,67220,2587,68217,2081,68244,1,69225,1,66703,512]

theorem envBound2037 : H12AffineFastState.Bounded env2037 := by
  intro p hp
  have h : env2037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2036_2037 : H12AffineEnvironment.transform 12 3607 env2036 = env2037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env2036 == env2037) = true)

theorem identity2037 : scanCanonicalize (H12AffineFastState.compose env2037 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound2037 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2038 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2587,3615,3733,2787,2080,1025,3615,1092,33,184,139,3743,233,2049,2587,1260,2081,1025,1,252,1,2586,512]

theorem envBound2038 : H12AffineFastState.Bounded env2038 := by
  intro p hp
  have h : env2038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2037_2038 : H12AffineEnvironment.transform 15 3733 env2037 = env2038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env2037 == env2038) = true)

theorem identity2038 : scanCanonicalize (H12AffineFastState.compose env2038 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound2038 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2039 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2627,2587,2635,2753,2787,2080,85,2635,16,33,184,139,2763,233,2049,2587,184,2081,85,1,252,1,2586,512]

theorem envBound2039 : H12AffineFastState.Bounded env2039 := by
  intro p hp
  have h : env2039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2038_2039 : H12AffineEnvironment.transform 9 84 env2038 = env2039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env2038 == env2039) = true)

theorem identity2039 : scanCanonicalize (H12AffineFastState.compose env2039 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2039 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2040 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,65,2627,2587,2635,2665,2635,2080,85,2635,16,33,16,35,2659,65,2049,2587,16,2081,85,1,84,1,2586,512]

theorem envBound2040 : H12AffineFastState.Bounded env2040 := by
  intro p hp
  have h : env2040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2039_2040 : H12AffineEnvironment.transform 6 40 env2039 = env2040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2039 == env2040) = true)

def env2041 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,65,2627,2587,2635,2649,2635,2064,85,2635,16,17,16,19,2643,65,2049,2587,16,2065,85,1,84,1,2586,512]

theorem envBound2041 : H12AffineFastState.Bounded env2041 := by
  intro p hp
  have h : env2041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2040_2041 : H12AffineEnvironment.transform 4 16 env2040 = env2041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2040 == env2041) = true)

def env2042 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,65,579,539,587,601,587,16,85,587,16,17,16,19,595,65,1,539,16,17,85,1,84,1,538,512]

theorem envBound2042 : H12AffineFastState.Bounded env2042 := by
  intro p hp
  have h : env2042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2041_2042 : H12AffineEnvironment.transform 10 0 env2041 = env2042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2041 == env2042) = true)

theorem identity2042 : scanCanonicalize (H12AffineFastState.compose env2042 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2043 : List Nat := [2,4,8,16,16,64,24,85,7,84,0,65,68,28,76,94,76,16,85,76,16,17,16,19,84,65,1,28,16,17,85,1,84,1,29,7]

theorem envBound2043 : H12AffineFastState.Bounded env2043 := by
  intro p hp
  have h : env2043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2042_2043 : H12AffineEnvironment.transform 8 7 env2042 = env2043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2042 == env2043) = true)

def env2044 : List Nat := [2,4,8,16,16,0,24,21,7,20,0,1,4,28,12,30,12,16,21,12,16,17,16,19,20,1,1,28,16,17,21,1,20,1,29,7]

theorem envBound2044 : H12AffineFastState.Bounded env2044 := by
  intro p hp
  have h : env2044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2043_2044 : H12AffineEnvironment.transform 5 0 env2043 = env2044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2043 == env2044) = true)

def leafEnv2044 : List Nat := [2,4,8,16,16,0,24,21,7,20,0,1,4,28,12,30,12,16,21,12,16,17,16,19,21,20,1,1,1,28,16,17,21,1,20,1,4,15,29,7,1,17,0]

def active2044 : List Nat := [0,1,2,3]

def tree2044 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2044 : H12WitnessSearch.Good tree2044 := H12GlobalWitnessIndex.good

theorem leafIdentity2044 : H12AffineFastState.composeSystem env2044 rootObs = leafEnv2044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2044 rootObs == leafEnv2044) = true)

theorem terminalChecked2044 : H12PackedTerminal.terminalCheckFast leafEnv2044 active2044 tree2044 = true := by decide +kernel

def env2045 : List Nat := [2,4,8,16,16,1,24,20,7,21,0,0,5,28,13,31,13,16,20,13,16,17,16,19,21,0,1,28,16,17,20,1,21,1,29,7]

theorem envBound2045 : H12AffineFastState.Bounded env2045 := by
  intro p hp
  have h : env2045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2043_2045 : H12AffineEnvironment.transform 5 1 env2043 = env2045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2043 == env2045) = true)

theorem identity2045 : scanCanonicalize (H12AffineFastState.compose env2045 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2046 : List Nat := [2,4,8,12,12,1,4,8,7,9,0,0,5,0,13,3,13,12,8,13,12,13,12,15,9,0,1,0,12,13,8,1,9,1,1,7]

theorem envBound2046 : H12AffineFastState.Bounded env2046 := by
  intro p hp
  have h : env2046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2045_2046 : H12AffineEnvironment.transform 3 12 env2045 = env2046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2045 == env2046) = true)

def leafEnv2046 : List Nat := [2,4,8,12,12,1,4,8,7,9,0,0,5,0,13,3,13,12,8,13,12,13,12,15,8,9,1,0,1,0,12,13,8,1,9,1,4,14,1,7,1,13,0]

def active2046 : List Nat := [0,1,2]

def tree2046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2046 : H12WitnessSearch.Good tree2046 := H12GlobalWitnessIndex.good

theorem leafIdentity2046 : H12AffineFastState.composeSystem env2046 rootObs = leafEnv2046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2046 rootObs == leafEnv2046) = true)

theorem terminalChecked2046 : H12PackedTerminal.terminalCheckFast leafEnv2046 active2046 tree2046 = true := by decide +kernel

def env2047 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,65,578,538,586,600,586,17,85,586,16,17,16,19,594,65,0,538,16,16,85,1,84,1,539,512]

theorem envBound2047 : H12AffineFastState.Bounded env2047 := by
  intro p hp
  have h : env2047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2041_2047 : H12AffineEnvironment.transform 10 1 env2041 = env2047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2041 == env2047) = true)

theorem identity2047 : scanCanonicalize (H12AffineFastState.compose env2047 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2047 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2048 : List Nat := [2,4,8,16,16,64,24,85,23,84,1,65,85,13,93,79,93,17,85,93,16,17,16,19,69,65,0,13,16,16,85,1,84,1,12,23]

theorem envBound2048 : H12AffineFastState.Bounded env2048 := by
  intro p hp
  have h : env2048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2047_2048 : H12AffineEnvironment.transform 8 23 env2047 = env2048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2047 == env2048) = true)

def env2049 : List Nat := [2,4,8,16,16,0,24,21,23,20,1,1,21,13,29,15,29,17,21,29,16,17,16,19,5,1,0,13,16,16,21,1,20,1,12,23]

theorem envBound2049 : H12AffineFastState.Bounded env2049 := by
  intro p hp
  have h : env2049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2048_2049 : H12AffineEnvironment.transform 5 0 env2048 = env2049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2048 == env2049) = true)

theorem identity2049 : scanCanonicalize (H12AffineFastState.compose env2049 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2049 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2050 : List Nat := [2,4,5,16,16,0,21,21,23,20,1,1,21,0,16,2,16,17,21,16,16,17,16,19,5,1,0,0,16,16,21,1,20,1,1,23]

theorem envBound2050 : H12AffineFastState.Bounded env2050 := by
  intro p hp
  have h : env2050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2049_2050 : H12AffineEnvironment.transform 2 5 env2049 = env2050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2049 == env2050) = true)

def leafEnv2050 : List Nat := [2,4,5,16,16,0,21,21,23,20,1,1,21,0,16,2,16,17,21,16,16,17,16,19,21,5,1,1,0,0,16,16,21,1,20,1,4,19,1,23,1,17,0]

def active2050 : List Nat := [0,1,3]

def tree2050 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2050 : H12WitnessSearch.Good tree2050 := H12GlobalWitnessIndex.good

theorem leafIdentity2050 : H12AffineFastState.composeSystem env2050 rootObs = leafEnv2050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2050 rootObs == leafEnv2050) = true)

theorem terminalChecked2050 : H12PackedTerminal.terminalCheckFast leafEnv2050 active2050 tree2050 = true := by decide +kernel

def env2051 : List Nat := [2,4,8,16,16,1,24,20,23,21,1,0,20,13,28,14,28,17,20,28,16,17,16,19,4,0,0,13,16,16,20,1,21,1,12,23]

theorem envBound2051 : H12AffineFastState.Bounded env2051 := by
  intro p hp
  have h : env2051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2048_2051 : H12AffineEnvironment.transform 5 1 env2048 = env2051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2048 == env2051) = true)

def leafEnv2051 : List Nat := [2,4,8,16,16,1,24,20,23,21,1,0,20,13,28,14,28,17,20,28,16,17,16,19,20,4,1,0,0,13,16,16,20,1,21,1,4,31,12,23,1,17,0]

def active2051 : List Nat := [0,1,2,3]

def tree2051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2051 : H12WitnessSearch.Good tree2051 := H12GlobalWitnessIndex.good

theorem leafIdentity2051 : H12AffineFastState.composeSystem env2051 rootObs = leafEnv2051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2051 rootObs == leafEnv2051) = true)

theorem terminalChecked2051 : H12PackedTerminal.terminalCheckFast leafEnv2051 active2051 tree2051 = true := by decide +kernel

def env2052 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,65,2627,2587,2635,2648,2635,2065,85,2635,16,16,16,18,2642,65,2049,2587,16,2064,85,1,84,1,2586,512]

theorem envBound2052 : H12AffineFastState.Bounded env2052 := by
  intro p hp
  have h : env2052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2040_2052 : H12AffineEnvironment.transform 4 17 env2040 = env2052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2040 == env2052) = true)

def env2053 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,65,579,539,587,600,587,17,85,587,16,16,16,18,594,65,1,539,16,16,85,1,84,1,538,512]

theorem envBound2053 : H12AffineFastState.Bounded env2053 := by
  intro p hp
  have h : env2053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2052_2053 : H12AffineEnvironment.transform 10 0 env2052 = env2053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2052 == env2053) = true)

theorem identity2053 : scanCanonicalize (H12AffineFastState.compose env2053 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound2053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2054 : List Nat := [2,4,8,16,17,12,25,25,512,24,0,13,527,539,519,532,519,17,25,519,16,16,16,18,542,13,1,539,16,16,25,1,24,1,538,512]

theorem envBound2054 : H12AffineFastState.Bounded env2054 := by
  intro p hp
  have h : env2054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2053_2054 : H12AffineEnvironment.transform 5 12 env2053 = env2054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env2053 == env2054) = true)

def env2055 : List Nat := [2,4,4,16,17,0,21,21,512,20,0,1,515,535,519,532,519,17,21,519,16,16,16,18,530,1,1,535,16,16,21,1,20,1,534,512]

theorem envBound2055 : H12AffineFastState.Bounded env2055 := by
  intro p hp
  have h : env2055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2054_2055 : H12AffineEnvironment.transform 2 4 env2054 = env2055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2054 == env2055) = true)

def leafEnv2055 : List Nat := [2,4,4,16,17,0,21,21,512,20,0,1,515,535,519,532,519,17,21,519,16,16,16,18,21,530,1,1,1,535,16,16,21,1,20,1,4,516,534,512,1,17,0]

def active2055 : List Nat := [0,1,3,8]

def tree2055 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2055 : H12WitnessSearch.Good tree2055 := H12GlobalWitnessIndex.good

theorem leafIdentity2055 : H12AffineFastState.composeSystem env2055 rootObs = leafEnv2055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2055 rootObs == leafEnv2055) = true)

theorem terminalChecked2055 : H12PackedTerminal.terminalCheckFast leafEnv2055 active2055 tree2055 = true := by decide +kernel

def env2056 : List Nat := [2,4,5,16,17,1,20,20,512,21,0,0,514,534,519,532,519,17,20,519,16,16,16,18,531,0,1,534,16,16,20,1,21,1,535,512]

theorem envBound2056 : H12AffineFastState.Bounded env2056 := by
  intro p hp
  have h : env2056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2054_2056 : H12AffineEnvironment.transform 2 5 env2054 = env2056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2054 == env2056) = true)

theorem identity2056 : scanCanonicalize (H12AffineFastState.compose env2056 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2056 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2057 : List Nat := [2,4,5,16,17,1,20,20,23,21,0,0,21,1,16,3,16,17,20,16,16,16,16,18,4,0,1,1,16,16,20,1,21,1,0,23]

theorem envBound2057 : H12AffineFastState.Bounded env2057 := by
  intro p hp
  have h : env2057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2056_2057 : H12AffineEnvironment.transform 8 23 env2056 = env2057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2056 == env2057) = true)

def leafEnv2057 : List Nat := [2,4,5,16,17,1,20,20,23,21,0,0,21,1,16,3,16,17,20,16,16,16,16,18,20,4,1,0,1,1,16,16,20,1,21,1,4,19,0,23,1,17,0]

def active2057 : List Nat := [0,1,3]

def tree2057 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2057 : H12WitnessSearch.Good tree2057 := H12GlobalWitnessIndex.good

theorem leafIdentity2057 : H12AffineFastState.composeSystem env2057 rootObs = leafEnv2057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2057 rootObs == leafEnv2057) = true)

theorem terminalChecked2057 : H12PackedTerminal.terminalCheckFast leafEnv2057 active2057 tree2057 = true := by decide +kernel

def env2058 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,65,578,538,586,601,586,16,85,586,16,16,16,18,595,65,0,538,16,17,85,1,84,1,539,512]

theorem envBound2058 : H12AffineFastState.Bounded env2058 := by
  intro p hp
  have h : env2058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2052_2058 : H12AffineEnvironment.transform 10 1 env2052 = env2058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2052 == env2058) = true)

theorem identity2058 : scanCanonicalize (H12AffineFastState.compose env2058 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound2058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2059 : List Nat := [2,4,8,16,17,28,25,9,512,8,1,29,542,538,534,517,534,16,9,534,16,16,16,18,527,29,0,538,16,17,9,1,8,1,539,512]

theorem envBound2059 : H12AffineFastState.Bounded env2059 := by
  intro p hp
  have h : env2059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2058_2059 : H12AffineEnvironment.transform 5 28 env2058 = env2059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env2058 == env2059) = true)

def env2060 : List Nat := [2,4,8,12,13,0,5,9,512,8,1,1,514,518,522,517,522,12,9,522,12,12,12,14,527,1,0,518,12,13,9,1,8,1,519,512]

theorem envBound2060 : H12AffineFastState.Bounded env2060 := by
  intro p hp
  have h : env2060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2059_2060 : H12AffineEnvironment.transform 3 12 env2059 = env2060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2059 == env2060) = true)

theorem identity2060 : scanCanonicalize (H12AffineFastState.compose env2060 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2061 : List Nat := [2,4,8,12,13,0,5,9,7,8,1,1,5,1,13,2,13,12,9,13,12,12,12,14,8,1,0,1,12,13,9,1,8,1,0,7]

theorem envBound2061 : H12AffineFastState.Bounded env2061 := by
  intro p hp
  have h : env2061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2060_2061 : H12AffineEnvironment.transform 8 7 env2060 = env2061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2060 == env2061) = true)

def leafEnv2061 : List Nat := [2,4,8,12,13,0,5,9,7,8,1,1,5,1,13,2,13,12,9,13,12,12,12,14,9,8,1,1,0,1,12,13,9,1,8,1,4,14,0,7,1,13,0]

def active2061 : List Nat := [0,1,2]

def tree2061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2061 : H12WitnessSearch.Good tree2061 := H12GlobalWitnessIndex.good

theorem leafIdentity2061 : H12AffineFastState.composeSystem env2061 rootObs = leafEnv2061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2061 rootObs == leafEnv2061) = true)

theorem terminalChecked2061 : H12PackedTerminal.terminalCheckFast leafEnv2061 active2061 tree2061 = true := by decide +kernel

def env2062 : List Nat := [2,4,8,13,12,1,4,9,512,8,1,0,515,519,523,517,523,13,9,523,13,13,13,15,527,0,0,519,13,12,9,1,8,1,518,512]

theorem envBound2062 : H12AffineFastState.Bounded env2062 := by
  intro p hp
  have h : env2062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2059_2062 : H12AffineEnvironment.transform 3 13 env2059 = env2062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2059 == env2062) = true)

def leafEnv2062 : List Nat := [2,4,8,13,12,1,4,9,512,8,1,0,515,519,523,517,523,13,9,523,13,13,13,15,9,527,1,0,0,519,13,12,9,1,8,1,4,520,518,512,1,12,0]

def active2062 : List Nat := [0,1,2,8]

def tree2062 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2062 : H12WitnessSearch.Good tree2062 := H12GlobalWitnessIndex.good

theorem leafIdentity2062 : H12AffineFastState.composeSystem env2062 rootObs = leafEnv2062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2062 rootObs == leafEnv2062) = true)

theorem terminalChecked2062 : H12PackedTerminal.terminalCheckFast leafEnv2062 active2062 tree2062 = true := by decide +kernel

def env2063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,185,74229,8328,74135,336223,16384,151553,2081,75135,0,73854,1,131332,512]

theorem envBound2063 : H12AffineFastState.Bounded env2063 := by
  intro p hp
  have h : env2063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1986_2063 : H12AffineEnvironment.transform 22 185 env1986 = env2063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1986 == env2063) = true)

theorem identity2063 : scanCanonicalize (H12AffineFastState.compose env2063 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound2063 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2064 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,74883,8200,2097152,73891,185,73736,8328,73834,336034,16384,151553,2081,74882,0,73854,1,131321,512]

theorem envBound2064 : H12AffineFastState.Bounded env2064 := by
  intro p hp
  have h : env2064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2063_2064 : H12AffineEnvironment.transform 7 253 env2063 = env2064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2063 == env2064) = true)

def env2065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2080,17399809,13149549,525568,0,34359738368,25733063]

theorem envBound2065 : H12AffineFastState.Bounded env2065 := by
  intro p hp
  have h : env2065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1821_2065 : H12AffineEnvironment.transform 27 16385 env1821 = env2065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env1821 == env2065) = true)

def env2066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2080,17375733,13108377,525568,0,34359738368,25691699]

theorem envBound2066 : H12AffineFastState.Bounded env2066 := by
  intro p hp
  have h : env2066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2065_2066 : H12AffineEnvironment.transform 14 8692 env2065 = env2066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env2065 == env2066) = true)

theorem identity2066 : scanCanonicalize (H12AffineFastState.compose env2066 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound2066 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env2067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913971,8328,8914000,9176216,16385,151552,2080,8463814,13108377,525568,0,34359738368,512]

theorem envBound2067 : H12AffineFastState.Bounded env2067 := by
  intro p hp
  have h : env2067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2066_2067 : H12AffineEnvironment.transform 23 8913971 env2066 = env2067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env2066 == env2067) = true)

theorem identity2067 : scanCanonicalize (H12AffineFastState.compose env2067 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound2067 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525344,8388608,8913971,8328,8914000,9176216,16385,151552,2080,8463814,8388793,525568,0,34359738368,512]

theorem envBound2068 : H12AffineFastState.Bounded env2068 := by
  intro p hp
  have h : env2068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2067_2068 : H12AffineEnvironment.transform 21 525344 env2067 = env2068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env2067 == env2068) = true)

theorem identity2068 : scanCanonicalize (H12AffineFastState.compose env2068 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound2068 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env2069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462669,8328,8462638,8724966,16385,151552,2080,8463814,8388793,73854,0,34359738368,512]

theorem envBound2069 : H12AffineFastState.Bounded env2069 := by
  intro p hp
  have h : env2069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2068_2069 : H12AffineEnvironment.transform 18 75134 env2068 = env2069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env2068 == env2069) = true)

theorem identity2069 : scanCanonicalize (H12AffineFastState.compose env2069 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound2069 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462669,8328,8462638,8724966,16385,151552,2080,8463814,8388793,73854,0,131332,512]

theorem envBound2070 : H12AffineFastState.Bounded env2070 := by
  intro p hp
  have h : env2070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2069_2070 : H12AffineEnvironment.transform 34 131332 env2069 = env2070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env2069 == env2070) = true)

def env2071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,184,74229,8328,74134,336222,16385,151552,2080,75134,1,73854,0,131332,512]

theorem envBound2071 : H12AffineFastState.Bounded env2071 := by
  intro p hp
  have h : env2071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2070_2071 : H12AffineEnvironment.transform 22 184 env2070 = env2071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env2070 == env2071) = true)

theorem identity2071 : scanCanonicalize (H12AffineFastState.compose env2071 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound2071 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2072 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74883,8201,2097152,73891,184,73736,8328,73835,336035,16385,151552,2080,74883,1,73854,0,131321,512]

theorem envBound2072 : H12AffineFastState.Bounded env2072 := by
  intro p hp
  have h : env2072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2071_2072 : H12AffineEnvironment.transform 7 253 env2071 = env2072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2071 == env2072) = true)

def env2073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,185,74228,8328,74135,336223,16385,151552,2080,75135,0,73854,0,131332,512]

theorem envBound2073 : H12AffineFastState.Bounded env2073 := by
  intro p hp
  have h : env2073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2070_2073 : H12AffineEnvironment.transform 22 185 env2070 = env2073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env2070 == env2073) = true)

theorem identity2073 : scanCanonicalize (H12AffineFastState.compose env2073 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound2073 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env2074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223323,75134,8692,2097152,74078,185,74228,8328,74135,149764,16385,151552,2080,75135,0,73854,0,131332,512]

theorem envBound2074 : H12AffineFastState.Bounded env2074 := by
  intro p hp
  have h : env2074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2073_2074 : H12AffineEnvironment.transform 17 223323 env2073 = env2074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env2073 == env2074) = true)

def env2075 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74882,8200,2097152,73890,185,73736,8328,73835,149752,16385,151552,2080,74883,0,73854,0,131320,512]

theorem envBound2075 : H12AffineFastState.Bounded env2075 := by
  intro p hp
  have h : env2075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2074_2075 : H12AffineEnvironment.transform 7 252 env2074 = env2075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2074 == env2075) = true)

theorem identity2075 : scanCanonicalize (H12AffineFastState.compose env2075 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound2075 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2076 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74882,8200,151553,73890,185,73736,8328,73835,149752,16385,151552,2080,74883,0,73854,0,131320,512]

theorem envBound2076 : H12AffineFastState.Bounded env2076 := by
  intro p hp
  have h : env2076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2075_2076 : H12AffineEnvironment.transform 20 151553 env2075 = env2076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env2075 == env2076) = true)

theorem identity2076 : scanCanonicalize (H12AffineFastState.compose env2076 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound2076 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env2077 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90235,2080,74882,8200,77946,73890,185,73736,8328,73835,75907,16385,77947,2080,74883,0,73854,0,90243,512]

theorem envBound2077 : H12AffineFastState.Bounded env2077 := by
  intro p hp
  have h : env2077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2076_2077 : H12AffineEnvironment.transform 16 90235 env2076 = env2077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env2076 == env2077) = true)

theorem identity2077 : scanCanonicalize (H12AffineFastState.compose env2077 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound2077 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env2078 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16632,2080,1025,8200,4345,33,185,139,8328,232,2048,16385,4344,2080,1024,0,253,0,16384,512]

theorem envBound2078 : H12AffineFastState.Bounded env2078 := by
  intro p hp
  have h : env2078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2077_2078 : H12AffineEnvironment.transform 15 8323 env2077 = env2078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env2077 == env2078) = true)

theorem identity2078 : scanCanonicalize (H12AffineFastState.compose env2078 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound2078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2079 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8200,8323,5260,2080,1025,8200,4345,33,185,139,8328,232,2048,5237,4344,2080,1024,0,253,0,5236,512]

theorem envBound2079 : H12AffineFastState.Bounded env2079 := by
  intro p hp
  have h : env2079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2078_2079 : H12AffineEnvironment.transform 13 5236 env2078 = env2079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env2078 == env2079) = true)

theorem identity2079 : scanCanonicalize (H12AffineFastState.compose env2079 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound2079 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2080 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,603,8200,8323,675,2080,1025,8200,1750,33,185,139,8328,232,2048,602,1751,2080,1024,0,253,0,603,512]

theorem envBound2080 : H12AffineFastState.Bounded env2080 := by
  intro p hp
  have h : env2080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2079_2080 : H12AffineEnvironment.transform 11 1583 env2079 = env2080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env2079 == env2080) = true)

theorem identity2080 : scanCanonicalize (H12AffineFastState.compose env2080 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3823) := by decide +kernel

theorem selectedBound2080 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env2081 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3823,603,3815,3692,675,2080,1025,3815,1750,33,185,139,3687,232,2048,602,1751,2080,1024,0,253,0,603,512]

theorem envBound2081 : H12AffineFastState.Bounded env2081 := by
  intro p hp
  have h : env2081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2080_2081 : H12AffineEnvironment.transform 12 3823 env2080 = env2081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3823 env2080 == env2081) = true)

theorem identity2081 : scanCanonicalize (H12AffineFastState.compose env2081 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2081 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env2082 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,555,2795,603,2787,2664,675,2080,5,2787,722,33,185,139,2659,232,2048,602,723,2080,4,0,253,0,603,512]

theorem envBound2082 : H12AffineFastState.Bounded env2082 := by
  intro p hp
  have h : env2082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2081_2082 : H12AffineEnvironment.transform 9 4 env2081 = env2082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2081 == env2082) = true)

theorem identity2082 : scanCanonicalize (H12AffineFastState.compose env2082 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2082 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env2083 : List Nat := [2,4,8,16,32,64,120,4,512,4,2048,555,2579,603,2587,2664,603,2080,5,2587,554,33,65,115,2659,16,2048,602,555,2080,4,0,5,0,603,512]

theorem envBound2083 : H12AffineFastState.Bounded env2083 := by
  intro p hp
  have h : env2083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2082_2083 : H12AffineEnvironment.transform 6 120 env2082 = env2083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2082 == env2083) = true)

theorem identity2083 : scanCanonicalize (H12AffineFastState.compose env2083 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound2083 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2084 : List Nat := [2,4,8,16,32,64,120,4,512,4,608,555,115,603,123,8,603,576,5,123,554,33,65,115,3,16,608,602,555,576,4,0,5,0,603,512]

theorem envBound2084 : H12AffineFastState.Bounded env2084 := by
  intro p hp
  have h : env2084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2083_2084 : H12AffineEnvironment.transform 10 608 env2083 = env2084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env2083 == env2084) = true)

theorem identity2084 : scanCanonicalize (H12AffineFastState.compose env2084 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound2084 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env2085 : List Nat := [2,4,8,16,27,64,67,4,512,4,603,528,72,603,64,8,603,576,5,64,529,26,65,72,3,16,603,602,528,576,4,0,5,0,603,512]

theorem envBound2085 : H12AffineFastState.Bounded env2085 := by
  intro p hp
  have h : env2085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2084_2085 : H12AffineEnvironment.transform 4 27 env2084 = env2085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env2084 == env2085) = true)

def env2086 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74883,8201,2097152,73891,185,73737,8328,73834,149753,16385,151552,2080,74882,0,73854,0,131321,512]

theorem envBound2086 : H12AffineFastState.Bounded env2086 := by
  intro p hp
  have h : env2086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2074_2086 : H12AffineEnvironment.transform 7 253 env2074 = env2086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env2074 == env2086) = true)

theorem identity2086 : scanCanonicalize (H12AffineFastState.compose env2086 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78034) := by decide +kernel

theorem selectedBound2086 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env2087 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74883,8201,78034,73891,185,73737,8328,73834,149753,16385,151552,2080,74882,0,73854,0,131321,512]

theorem envBound2087 : H12AffineFastState.Bounded env2087 := by
  intro p hp
  have h : env2087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2086_2087 : H12AffineEnvironment.transform 20 78034 env2086 = env2087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78034 env2086 == env2087) = true)

theorem identity2087 : scanCanonicalize (H12AffineFastState.compose env2087 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound2087 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2088 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210516,74883,8201,78034,73891,185,73737,8328,73834,136950,7694,134671,2080,74882,0,73854,0,131321,512]

theorem envBound2088 : H12AffineFastState.Bounded env2088 := by
  intro p hp
  have h : env2088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2087_2088 : H12AffineEnvironment.transform 13 7695 env2087 = env2088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env2087 == env2088) = true)

def env2089 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205376,74883,8201,74950,73891,185,73737,8328,73834,131810,2586,134671,2080,74882,0,73854,0,131321,512]

theorem envBound2089 : H12AffineFastState.Bounded env2089 := by
  intro p hp
  have h : env2089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2088_2089 : H12AffineEnvironment.transform 11 1044 env2088 = env2089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env2088 == env2089) = true)

def env2090 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2080,74883,8201,74950,73891,185,73737,8328,73834,75906,2586,74863,2080,74882,0,73854,0,76441,512]

theorem envBound2090 : H12AffineFastState.Bounded env2090 := by
  intro p hp
  have h : env2090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2089_2090 : H12AffineEnvironment.transform 16 76384 env2089 = env2090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2089 == env2090) = true)

theorem identity2090 : scanCanonicalize (H12AffineFastState.compose env2090 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound2090 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2091 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,225,2587,232,65536,68225,2080,66658,232,66599,65602,185,65768,105,65675,67683,2586,66702,2080,66659,0,65695,0,68216,512]

theorem envBound2091 : H12AffineFastState.Bounded env2091 := by
  intro p hp
  have h : env2091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2090_2091 : H12AffineEnvironment.transform 12 225 env2090 = env2091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env2090 == env2091) = true)

def env2092 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2081,74883,8201,74950,73891,185,73737,8328,73834,75907,2586,74862,2080,74882,0,73854,0,76440,512]

theorem envBound2092 : H12AffineFastState.Bounded env2092 := by
  intro p hp
  have h : env2092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2089_2092 : H12AffineEnvironment.transform 16 76385 env2089 = env2092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2089 == env2092) = true)

theorem identity2092 : scanCanonicalize (H12AffineFastState.compose env2092 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound2092 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2093 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,3732,9461,2081,10775,8201,10834,11831,185,11933,8328,12030,9751,2586,11002,2080,10774,0,12010,0,9228,512]

theorem envBound2093 : H12AffineFastState.Bounded env2093 := by
  intro p hp
  have h : env2093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2092_2093 : H12AffineEnvironment.transform 15 3732 env2092 = env2093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env2092 == env2093) = true)

theorem identity2093 : scanCanonicalize (H12AffineFastState.compose env2093 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound2093 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2094 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2587,3615,3732,2787,2081,1025,3615,1092,33,185,139,3742,232,2049,2586,1260,2080,1024,0,252,0,2586,512]

theorem envBound2094 : H12AffineFastState.Bounded env2094 := by
  intro p hp
  have h : env2094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2093_2094 : H12AffineEnvironment.transform 12 3606 env2093 = env2094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env2093 == env2094) = true)

theorem identity2094 : scanCanonicalize (H12AffineFastState.compose env2094 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2094 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2095 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2627,2587,2634,2753,2787,2081,84,2634,17,33,185,139,2763,232,2049,2586,185,2080,85,0,252,0,2586,512]

theorem envBound2095 : H12AffineFastState.Bounded env2095 := by
  intro p hp
  have h : env2095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2094_2095 : H12AffineEnvironment.transform 9 85 env2094 = env2095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2094 == env2095) = true)

theorem identity2095 : scanCanonicalize (H12AffineFastState.compose env2095 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2095 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2096 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,65,2627,2587,2634,2664,2634,2081,84,2634,17,33,16,34,2658,65,2049,2586,16,2080,85,0,85,0,2586,512]

theorem envBound2096 : H12AffineFastState.Bounded env2096 := by
  intro p hp
  have h : env2096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2095_2096 : H12AffineEnvironment.transform 6 41 env2095 = env2096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2095 == env2096) = true)

def env2097 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,65,2627,2587,2634,2648,2634,2065,84,2634,17,17,16,18,2642,65,2049,2586,16,2064,85,0,85,0,2586,512]

theorem envBound2097 : H12AffineFastState.Bounded env2097 := by
  intro p hp
  have h : env2097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2096_2097 : H12AffineEnvironment.transform 4 16 env2096 = env2097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2096 == env2097) = true)

def env2098 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,65,579,539,586,600,586,17,84,586,17,17,16,18,594,65,1,538,16,16,85,0,85,0,538,512]

theorem envBound2098 : H12AffineFastState.Bounded env2098 := by
  intro p hp
  have h : env2098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2097_2098 : H12AffineEnvironment.transform 10 0 env2097 = env2098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2097 == env2098) = true)

theorem identity2098 : scanCanonicalize (H12AffineFastState.compose env2098 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound2098 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2099 : List Nat := [2,4,8,16,16,64,25,84,22,85,0,65,85,13,92,78,92,17,84,92,17,17,16,18,68,65,1,12,16,16,85,0,85,0,12,22]

theorem envBound2099 : H12AffineFastState.Bounded env2099 := by
  intro p hp
  have h : env2099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2098_2099 : H12AffineEnvironment.transform 8 22 env2098 = env2099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env2098 == env2099) = true)

def env2100 : List Nat := [2,4,8,16,16,0,25,20,22,21,0,1,21,13,28,14,28,17,20,28,17,17,16,18,4,1,1,12,16,16,21,0,21,0,12,22]

theorem envBound2100 : H12AffineFastState.Bounded env2100 := by
  intro p hp
  have h : env2100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2099_2100 : H12AffineEnvironment.transform 5 0 env2099 = env2100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2099 == env2100) = true)

theorem identity2100 : scanCanonicalize (H12AffineFastState.compose env2100 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2100 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2101 : List Nat := [2,4,5,16,16,0,20,20,22,21,0,1,21,0,17,3,17,17,20,17,17,17,16,18,4,1,1,1,16,16,21,0,21,0,1,22]

theorem envBound2101 : H12AffineFastState.Bounded env2101 := by
  intro p hp
  have h : env2101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2100_2101 : H12AffineEnvironment.transform 2 5 env2100 = env2101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2100 == env2101) = true)

def leafEnv2101 : List Nat := [2,4,5,16,16,0,20,20,22,21,0,1,21,0,17,3,17,17,20,17,17,17,16,18,21,4,1,1,1,1,16,16,21,0,21,0,4,19,1,22,1,16,0]

def active2101 : List Nat := [0,1,3]

def tree2101 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2101 : H12WitnessSearch.Good tree2101 := H12GlobalWitnessIndex.good

theorem leafIdentity2101 : H12AffineFastState.composeSystem env2101 rootObs = leafEnv2101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2101 rootObs == leafEnv2101) = true)

theorem terminalChecked2101 : H12PackedTerminal.terminalCheckFast leafEnv2101 active2101 tree2101 = true := by decide +kernel

def env2102 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,0,20,13,29,15,29,17,21,29,17,17,16,18,5,0,1,12,16,16,20,0,20,0,12,22]

theorem envBound2102 : H12AffineFastState.Bounded env2102 := by
  intro p hp
  have h : env2102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2099_2102 : H12AffineEnvironment.transform 5 1 env2099 = env2102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2099 == env2102) = true)

def leafEnv2102 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,0,20,13,29,15,29,17,21,29,17,17,16,18,20,5,1,0,1,12,16,16,20,0,20,0,4,31,12,22,1,16,0]

def active2102 : List Nat := [0,1,2,3]

def tree2102 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2102 : H12WitnessSearch.Good tree2102 := H12GlobalWitnessIndex.good

theorem leafIdentity2102 : H12AffineFastState.composeSystem env2102 rootObs = leafEnv2102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2102 rootObs == leafEnv2102) = true)

theorem terminalChecked2102 : H12PackedTerminal.terminalCheckFast leafEnv2102 active2102 tree2102 = true := by decide +kernel

def env2103 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,65,578,538,587,601,587,16,84,587,17,17,16,18,595,65,0,539,16,17,85,0,85,0,539,512]

theorem envBound2103 : H12AffineFastState.Bounded env2103 := by
  intro p hp
  have h : env2103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2097_2103 : H12AffineEnvironment.transform 10 1 env2097 = env2103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2097 == env2103) = true)

theorem identity2103 : scanCanonicalize (H12AffineFastState.compose env2103 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound2103 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2104 : List Nat := [2,4,8,16,16,64,25,84,7,85,1,65,69,29,76,94,76,16,84,76,17,17,16,18,84,65,0,28,16,17,85,0,85,0,28,7]

theorem envBound2104 : H12AffineFastState.Bounded env2104 := by
  intro p hp
  have h : env2104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2103_2104 : H12AffineEnvironment.transform 8 7 env2103 = env2104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env2103 == env2104) = true)

def env2105 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,1,5,29,12,30,12,16,20,12,17,17,16,18,20,1,0,28,16,17,21,0,21,0,28,7]

theorem envBound2105 : H12AffineFastState.Bounded env2105 := by
  intro p hp
  have h : env2105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2104_2105 : H12AffineEnvironment.transform 5 0 env2104 = env2105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2104 == env2105) = true)

def leafEnv2105 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,1,5,29,12,30,12,16,20,12,17,17,16,18,21,20,1,1,0,28,16,17,21,0,21,0,4,14,28,7,1,16,0]

def active2105 : List Nat := [0,1,2,3]

def tree2105 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2105 : H12WitnessSearch.Good tree2105 := H12GlobalWitnessIndex.good

theorem leafIdentity2105 : H12AffineFastState.composeSystem env2105 rootObs = leafEnv2105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2105 rootObs == leafEnv2105) = true)

theorem terminalChecked2105 : H12PackedTerminal.terminalCheckFast leafEnv2105 active2105 tree2105 = true := by decide +kernel

def env2106 : List Nat := [2,4,8,16,16,1,25,21,7,20,1,0,4,29,13,31,13,16,21,13,17,17,16,18,21,0,0,28,16,17,20,0,20,0,28,7]

theorem envBound2106 : H12AffineFastState.Bounded env2106 := by
  intro p hp
  have h : env2106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2104_2106 : H12AffineEnvironment.transform 5 1 env2104 = env2106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2104 == env2106) = true)

theorem identity2106 : scanCanonicalize (H12AffineFastState.compose env2106 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2106 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2107 : List Nat := [2,4,8,13,13,1,4,8,7,9,1,0,4,0,13,2,13,13,8,13,12,12,13,15,8,0,0,1,13,12,9,0,9,0,1,7]

theorem envBound2107 : H12AffineFastState.Bounded env2107 := by
  intro p hp
  have h : env2107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2106_2107 : H12AffineEnvironment.transform 3 13 env2106 = env2107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2106 == env2107) = true)

def leafEnv2107 : List Nat := [2,4,8,13,13,1,4,8,7,9,1,0,4,0,13,2,13,13,8,13,12,12,13,15,9,8,1,0,0,1,13,12,9,0,9,0,4,15,1,7,1,13,0]

def active2107 : List Nat := [0,1,2]

def tree2107 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2107 : H12WitnessSearch.Good tree2107 := H12GlobalWitnessIndex.good

theorem leafIdentity2107 : H12AffineFastState.composeSystem env2107 rootObs = leafEnv2107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2107 rootObs == leafEnv2107) = true)

theorem terminalChecked2107 : H12PackedTerminal.terminalCheckFast leafEnv2107 active2107 tree2107 = true := by decide +kernel

def env2108 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,65,2627,2587,2634,2649,2634,2064,84,2634,17,16,16,19,2643,65,2049,2586,16,2065,85,0,85,0,2586,512]

theorem envBound2108 : H12AffineFastState.Bounded env2108 := by
  intro p hp
  have h : env2108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2096_2108 : H12AffineEnvironment.transform 4 17 env2096 = env2108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2096 == env2108) = true)

def env2109 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,65,579,539,586,601,586,16,84,586,17,16,16,19,595,65,1,538,16,17,85,0,85,0,538,512]

theorem envBound2109 : H12AffineFastState.Bounded env2109 := by
  intro p hp
  have h : env2109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2108_2109 : H12AffineEnvironment.transform 10 0 env2108 = env2109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2108 == env2109) = true)

theorem identity2109 : scanCanonicalize (H12AffineFastState.compose env2109 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound2109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2110 : List Nat := [2,4,8,16,17,28,24,8,512,9,0,29,543,539,534,517,534,16,8,534,17,16,16,19,527,29,1,538,16,17,9,0,9,0,538,512]

theorem envBound2110 : H12AffineFastState.Bounded env2110 := by
  intro p hp
  have h : env2110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2109_2110 : H12AffineEnvironment.transform 5 28 env2109 = env2110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env2109 == env2110) = true)

def env2111 : List Nat := [2,4,8,12,13,0,4,8,512,9,0,1,515,519,522,517,522,12,8,522,13,12,12,15,527,1,1,518,12,13,9,0,9,0,518,512]

theorem envBound2111 : H12AffineFastState.Bounded env2111 := by
  intro p hp
  have h : env2111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2110_2111 : H12AffineEnvironment.transform 3 12 env2110 = env2111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2110 == env2111) = true)

theorem identity2111 : scanCanonicalize (H12AffineFastState.compose env2111 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2112 : List Nat := [2,4,8,12,13,0,4,8,6,9,0,1,5,1,12,3,12,12,8,12,13,12,12,15,9,1,1,0,12,13,9,0,9,0,0,6]

theorem envBound2112 : H12AffineFastState.Bounded env2112 := by
  intro p hp
  have h : env2112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2111_2112 : H12AffineEnvironment.transform 8 6 env2111 = env2112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2111 == env2112) = true)

def leafEnv2112 : List Nat := [2,4,8,12,13,0,4,8,6,9,0,1,5,1,12,3,12,12,8,12,13,12,12,15,9,9,1,1,1,0,12,13,9,0,9,0,4,14,0,6,1,12,0]

def active2112 : List Nat := [0,1,2]

def tree2112 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2112 : H12WitnessSearch.Good tree2112 := H12GlobalWitnessIndex.good

theorem leafIdentity2112 : H12AffineFastState.composeSystem env2112 rootObs = leafEnv2112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2112 rootObs == leafEnv2112) = true)

theorem terminalChecked2112 : H12PackedTerminal.terminalCheckFast leafEnv2112 active2112 tree2112 = true := by decide +kernel

def env2113 : List Nat := [2,4,8,13,12,1,5,8,512,9,0,0,514,518,523,517,523,13,8,523,12,13,13,14,527,0,1,519,13,12,9,0,9,0,519,512]

theorem envBound2113 : H12AffineFastState.Bounded env2113 := by
  intro p hp
  have h : env2113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2110_2113 : H12AffineEnvironment.transform 3 13 env2110 = env2113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2110 == env2113) = true)

def leafEnv2113 : List Nat := [2,4,8,13,12,1,5,8,512,9,0,0,514,518,523,517,523,13,8,523,12,13,13,14,9,527,1,0,1,519,13,12,9,0,9,0,4,521,519,512,1,13,0]

def active2113 : List Nat := [0,1,2,8]

def tree2113 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2113 : H12WitnessSearch.Good tree2113 := H12GlobalWitnessIndex.good

theorem leafIdentity2113 : H12AffineFastState.composeSystem env2113 rootObs = leafEnv2113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2113 rootObs == leafEnv2113) = true)

theorem terminalChecked2113 : H12PackedTerminal.terminalCheckFast leafEnv2113 active2113 tree2113 = true := by decide +kernel

def env2114 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,65,578,538,587,600,587,17,84,587,17,16,16,19,594,65,0,539,16,16,85,0,85,0,539,512]

theorem envBound2114 : H12AffineFastState.Bounded env2114 := by
  intro p hp
  have h : env2114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2108_2114 : H12AffineEnvironment.transform 10 1 env2108 = env2114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2108 == env2114) = true)

theorem identity2114 : scanCanonicalize (H12AffineFastState.compose env2114 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound2114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2115 : List Nat := [2,4,8,16,17,13,24,25,512,24,1,12,527,538,518,533,518,17,25,518,17,16,16,19,543,12,0,539,16,16,24,0,24,0,539,512]

theorem envBound2115 : H12AffineFastState.Bounded env2115 := by
  intro p hp
  have h : env2115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2114_2115 : H12AffineEnvironment.transform 5 13 env2114 = env2115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env2114 == env2115) = true)

def env2116 : List Nat := [2,4,4,16,17,1,20,21,512,20,1,0,515,534,518,533,518,17,21,518,17,16,16,19,531,0,0,535,16,16,20,0,20,0,535,512]

theorem envBound2116 : H12AffineFastState.Bounded env2116 := by
  intro p hp
  have h : env2116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2115_2116 : H12AffineEnvironment.transform 2 4 env2115 = env2116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2115 == env2116) = true)

theorem identity2116 : scanCanonicalize (H12AffineFastState.compose env2116 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2117 : List Nat := [2,4,4,16,17,1,20,21,23,20,1,0,20,1,17,2,17,17,21,17,17,16,16,19,4,0,0,0,16,16,20,0,20,0,0,23]

theorem envBound2117 : H12AffineFastState.Bounded env2117 := by
  intro p hp
  have h : env2117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2116_2117 : H12AffineEnvironment.transform 8 23 env2116 = env2117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2116 == env2117) = true)

def leafEnv2117 : List Nat := [2,4,4,16,17,1,20,21,23,20,1,0,20,1,17,2,17,17,21,17,17,16,16,19,20,4,1,0,0,0,16,16,20,0,20,0,4,19,0,23,1,16,0]

def active2117 : List Nat := [0,1,3]

def tree2117 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2117 : H12WitnessSearch.Good tree2117 := H12GlobalWitnessIndex.good

theorem leafIdentity2117 : H12AffineFastState.composeSystem env2117 rootObs = leafEnv2117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2117 rootObs == leafEnv2117) = true)

theorem terminalChecked2117 : H12PackedTerminal.terminalCheckFast leafEnv2117 active2117 tree2117 = true := by decide +kernel

def env2118 : List Nat := [2,4,5,16,17,0,21,20,512,21,1,1,514,535,518,533,518,17,20,518,17,16,16,19,530,1,0,534,16,16,21,0,21,0,534,512]

theorem envBound2118 : H12AffineFastState.Bounded env2118 := by
  intro p hp
  have h : env2118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2115_2118 : H12AffineEnvironment.transform 2 5 env2115 = env2118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2115 == env2118) = true)

def leafEnv2118 : List Nat := [2,4,5,16,17,0,21,20,512,21,1,1,514,535,518,533,518,17,20,518,17,16,16,19,21,530,1,1,0,534,16,16,21,0,21,0,4,516,534,512,1,16,0]

def active2118 : List Nat := [0,1,3,8]

def tree2118 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2118 : H12WitnessSearch.Good tree2118 := H12GlobalWitnessIndex.good

theorem leafIdentity2118 : H12AffineFastState.composeSystem env2118 rootObs = leafEnv2118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2118 rootObs == leafEnv2118) = true)

theorem terminalChecked2118 : H12PackedTerminal.terminalCheckFast leafEnv2118 active2118 tree2118 = true := by decide +kernel

def env2119 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205377,74883,8201,74951,73891,185,73737,8328,73834,131811,2587,134671,2080,74882,0,73854,0,131321,512]

theorem envBound2119 : H12AffineFastState.Bounded env2119 := by
  intro p hp
  have h : env2119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2088_2119 : H12AffineEnvironment.transform 11 1045 env2088 = env2119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env2088 == env2119) = true)

def env2120 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2081,74883,8201,74951,73891,185,73737,8328,73834,75907,2587,74863,2080,74882,0,73854,0,76441,512]

theorem envBound2120 : H12AffineFastState.Bounded env2120 := by
  intro p hp
  have h : env2120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2119_2120 : H12AffineEnvironment.transform 16 76384 env2119 = env2120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env2119 == env2120) = true)

theorem identity2120 : scanCanonicalize (H12AffineFastState.compose env2120 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound2120 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2121 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2586,3615,65536,66678,2081,68245,3615,68305,69301,185,69151,3742,69244,67221,2587,68217,2080,68244,0,69224,0,66703,512]

theorem envBound2121 : H12AffineFastState.Bounded env2121 := by
  intro p hp
  have h : env2121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2120_2121 : H12AffineEnvironment.transform 12 3606 env2120 = env2121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env2120 == env2121) = true)

theorem identity2121 : scanCanonicalize (H12AffineFastState.compose env2121 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound2121 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env2122 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2586,3615,3732,2786,2081,1025,3615,1093,33,185,139,3742,232,2049,2587,1261,2080,1024,0,252,0,2587,512]

theorem envBound2122 : H12AffineFastState.Bounded env2122 := by
  intro p hp
  have h : env2122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2121_2122 : H12AffineEnvironment.transform 15 3732 env2121 = env2122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env2121 == env2122) = true)

theorem identity2122 : scanCanonicalize (H12AffineFastState.compose env2122 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2122 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env2123 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2627,2586,2634,2753,2786,2081,84,2634,16,33,185,139,2763,232,2049,2587,184,2080,85,0,252,0,2587,512]

theorem envBound2123 : H12AffineFastState.Bounded env2123 := by
  intro p hp
  have h : env2123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2122_2123 : H12AffineEnvironment.transform 9 85 env2122 = env2123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2122 == env2123) = true)

theorem identity2123 : scanCanonicalize (H12AffineFastState.compose env2123 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2123 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env2124 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,64,2627,2586,2634,2664,2635,2081,84,2634,16,33,16,34,2658,65,2049,2587,17,2080,85,0,85,0,2587,512]

theorem envBound2124 : H12AffineFastState.Bounded env2124 := by
  intro p hp
  have h : env2124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2123_2124 : H12AffineEnvironment.transform 6 41 env2123 = env2124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2123 == env2124) = true)

def env2125 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,64,2627,2586,2634,2648,2635,2065,84,2634,16,17,16,18,2642,65,2049,2587,17,2064,85,0,85,0,2587,512]

theorem envBound2125 : H12AffineFastState.Bounded env2125 := by
  intro p hp
  have h : env2125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2124_2125 : H12AffineEnvironment.transform 4 16 env2124 = env2125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2124 == env2125) = true)

def env2126 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,64,579,538,586,600,587,17,84,586,16,17,16,18,594,65,1,539,17,16,85,0,85,0,539,512]

theorem envBound2126 : H12AffineFastState.Bounded env2126 := by
  intro p hp
  have h : env2126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2125_2126 : H12AffineEnvironment.transform 10 0 env2125 = env2126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2125 == env2126) = true)

theorem identity2126 : scanCanonicalize (H12AffineFastState.compose env2126 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound2126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2127 : List Nat := [2,4,8,13,13,64,4,73,512,72,0,64,579,519,586,581,587,12,73,586,13,12,13,15,591,65,1,518,12,13,72,0,72,0,518,512]

theorem envBound2127 : H12AffineFastState.Bounded env2127 := by
  intro p hp
  have h : env2127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2126_2127 : H12AffineEnvironment.transform 3 13 env2126 = env2127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env2126 == env2127) = true)

def env2128 : List Nat := [2,4,8,13,13,0,4,9,512,8,0,0,515,519,522,517,523,12,9,522,13,12,13,15,527,1,1,518,12,13,8,0,8,0,518,512]

theorem envBound2128 : H12AffineFastState.Bounded env2128 := by
  intro p hp
  have h : env2128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2127_2128 : H12AffineEnvironment.transform 5 0 env2127 = env2128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2127 == env2128) = true)

def leafEnv2128 : List Nat := [2,4,8,13,13,0,4,9,512,8,0,0,515,519,522,517,523,12,9,522,13,12,13,15,8,527,1,1,1,518,12,13,8,0,8,0,4,520,518,512,1,12,0]

def active2128 : List Nat := [0,1,2,8]

def tree2128 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2128 : H12WitnessSearch.Good tree2128 := H12GlobalWitnessIndex.good

theorem leafIdentity2128 : H12AffineFastState.composeSystem env2128 rootObs = leafEnv2128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2128 rootObs == leafEnv2128) = true)

theorem terminalChecked2128 : H12PackedTerminal.terminalCheckFast leafEnv2128 active2128 tree2128 = true := by decide +kernel

def env2129 : List Nat := [2,4,8,13,13,1,4,8,512,9,0,1,514,519,523,516,522,12,8,523,13,12,13,15,526,0,1,518,12,13,9,0,9,0,518,512]

theorem envBound2129 : H12AffineFastState.Bounded env2129 := by
  intro p hp
  have h : env2129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2127_2129 : H12AffineEnvironment.transform 5 1 env2127 = env2129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2127 == env2129) = true)

theorem identity2129 : scanCanonicalize (H12AffineFastState.compose env2129 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2129 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2130 : List Nat := [2,4,8,13,13,1,4,8,6,9,0,1,4,1,13,2,12,12,8,13,13,12,13,15,8,0,1,0,12,13,9,0,9,0,0,6]

theorem envBound2130 : H12AffineFastState.Bounded env2130 := by
  intro p hp
  have h : env2130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2129_2130 : H12AffineEnvironment.transform 8 6 env2129 = env2130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2129 == env2130) = true)

def leafEnv2130 : List Nat := [2,4,8,13,13,1,4,8,6,9,0,1,4,1,13,2,12,12,8,13,13,12,13,15,9,8,1,0,1,0,12,13,9,0,9,0,4,15,0,6,1,12,0]

def active2130 : List Nat := [0,1,2]

def tree2130 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2130 : H12WitnessSearch.Good tree2130 := H12GlobalWitnessIndex.good

theorem leafIdentity2130 : H12AffineFastState.composeSystem env2130 rootObs = leafEnv2130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2130 rootObs == leafEnv2130) = true)

theorem terminalChecked2130 : H12PackedTerminal.terminalCheckFast leafEnv2130 active2130 tree2130 = true := by decide +kernel

def env2131 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,64,578,539,587,601,586,16,84,587,16,17,16,18,595,65,0,538,17,17,85,0,85,0,538,512]

theorem envBound2131 : H12AffineFastState.Bounded env2131 := by
  intro p hp
  have h : env2131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2125_2131 : H12AffineEnvironment.transform 10 1 env2125 = env2131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2125 == env2131) = true)

theorem identity2131 : scanCanonicalize (H12AffineFastState.compose env2131 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2131 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2132 : List Nat := [2,4,5,16,16,64,20,84,512,85,1,64,578,534,582,596,583,16,84,582,16,17,16,18,595,65,0,535,17,17,85,0,85,0,535,512]

theorem envBound2132 : H12AffineFastState.Bounded env2132 := by
  intro p hp
  have h : env2132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2131_2132 : H12AffineEnvironment.transform 2 5 env2131 = env2132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2131 == env2132) = true)

def env2133 : List Nat := [2,4,5,16,16,0,20,20,512,21,1,0,514,534,518,532,519,16,20,518,16,17,16,18,531,1,0,535,17,17,21,0,21,0,535,512]

theorem envBound2133 : H12AffineFastState.Bounded env2133 := by
  intro p hp
  have h : env2133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2132_2133 : H12AffineEnvironment.transform 5 0 env2132 = env2133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2132 == env2133) = true)

theorem identity2133 : scanCanonicalize (H12AffineFastState.compose env2133 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound2133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2134 : List Nat := [2,4,5,16,16,0,20,20,23,21,1,0,21,1,17,3,16,16,20,17,16,17,16,18,4,1,0,0,17,17,21,0,21,0,0,23]

theorem envBound2134 : H12AffineFastState.Bounded env2134 := by
  intro p hp
  have h : env2134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2133_2134 : H12AffineEnvironment.transform 8 23 env2133 = env2134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env2133 == env2134) = true)

def leafEnv2134 : List Nat := [2,4,5,16,16,0,20,20,23,21,1,0,21,1,17,3,16,16,20,17,16,17,16,18,21,4,1,1,0,0,17,17,21,0,21,0,4,19,0,23,1,17,0]

def active2134 : List Nat := [0,1,3]

def tree2134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2134 : H12WitnessSearch.Good tree2134 := H12GlobalWitnessIndex.good

theorem leafIdentity2134 : H12AffineFastState.composeSystem env2134 rootObs = leafEnv2134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2134 rootObs == leafEnv2134) = true)

theorem terminalChecked2134 : H12PackedTerminal.terminalCheckFast leafEnv2134 active2134 tree2134 = true := by decide +kernel

def env2135 : List Nat := [2,4,5,16,16,1,20,21,512,20,1,1,515,534,519,533,518,16,21,519,16,17,16,18,530,0,0,535,17,17,20,0,20,0,535,512]

theorem envBound2135 : H12AffineFastState.Bounded env2135 := by
  intro p hp
  have h : env2135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2132_2135 : H12AffineEnvironment.transform 5 1 env2132 = env2135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2132 == env2135) = true)

def leafEnv2135 : List Nat := [2,4,5,16,16,1,20,21,512,20,1,1,515,534,519,533,518,16,21,519,16,17,16,18,20,530,1,0,0,535,17,17,20,0,20,0,4,517,535,512,1,17,0]

def active2135 : List Nat := [0,1,3,8]

def tree2135 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2135 : H12WitnessSearch.Good tree2135 := H12GlobalWitnessIndex.good

theorem leafIdentity2135 : H12AffineFastState.composeSystem env2135 rootObs = leafEnv2135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2135 rootObs == leafEnv2135) = true)

theorem terminalChecked2135 : H12PackedTerminal.terminalCheckFast leafEnv2135 active2135 tree2135 = true := by decide +kernel

def env2136 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,64,2627,2586,2634,2649,2635,2064,84,2634,16,16,16,19,2643,65,2049,2587,17,2065,85,0,85,0,2587,512]

theorem envBound2136 : H12AffineFastState.Bounded env2136 := by
  intro p hp
  have h : env2136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2124_2136 : H12AffineEnvironment.transform 4 17 env2124 = env2136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2124 == env2136) = true)

def env2137 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,64,579,538,586,601,587,16,84,586,16,16,16,19,595,65,1,539,17,17,85,0,85,0,539,512]

theorem envBound2137 : H12AffineFastState.Bounded env2137 := by
  intro p hp
  have h : env2137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2136_2137 : H12AffineEnvironment.transform 10 0 env2136 = env2137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2136 == env2137) = true)

theorem identity2137 : scanCanonicalize (H12AffineFastState.compose env2137 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound2137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2138 : List Nat := [2,4,8,16,17,64,24,84,87,85,0,64,20,77,29,14,28,16,84,29,16,16,16,19,4,65,1,76,17,17,85,0,85,0,76,87]

theorem envBound2138 : H12AffineFastState.Bounded env2138 := by
  intro p hp
  have h : env2138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2137_2138 : H12AffineEnvironment.transform 8 87 env2137 = env2138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env2137 == env2138) = true)

def env2139 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,0,20,13,29,14,28,16,20,29,16,16,16,19,4,1,1,12,17,17,21,0,21,0,12,23]

theorem envBound2139 : H12AffineFastState.Bounded env2139 := by
  intro p hp
  have h : env2139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2138_2139 : H12AffineEnvironment.transform 5 0 env2138 = env2139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2138 == env2139) = true)

def leafEnv2139 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,0,20,13,29,14,28,16,20,29,16,16,16,19,21,4,1,1,1,12,17,17,21,0,21,0,4,31,12,23,1,17,0]

def active2139 : List Nat := [0,1,2,3]

def tree2139 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2139 : H12WitnessSearch.Good tree2139 := H12GlobalWitnessIndex.good

theorem leafIdentity2139 : H12AffineFastState.composeSystem env2139 rootObs = leafEnv2139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2139 rootObs == leafEnv2139) = true)

theorem terminalChecked2139 : H12PackedTerminal.terminalCheckFast leafEnv2139 active2139 tree2139 = true := by decide +kernel

def env2140 : List Nat := [2,4,8,16,17,1,24,21,22,20,0,1,20,12,29,14,28,16,21,29,16,16,16,19,4,0,1,13,17,17,20,0,20,0,13,22]

theorem envBound2140 : H12AffineFastState.Bounded env2140 := by
  intro p hp
  have h : env2140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2138_2140 : H12AffineEnvironment.transform 5 1 env2138 = env2140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2138 == env2140) = true)

theorem identity2140 : scanCanonicalize (H12AffineFastState.compose env2140 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2140 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2141 : List Nat := [2,4,4,16,17,1,20,21,22,20,0,1,20,0,17,2,16,16,21,17,16,16,16,19,4,0,1,1,17,17,20,0,20,0,1,22]

theorem envBound2141 : H12AffineFastState.Bounded env2141 := by
  intro p hp
  have h : env2141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2140_2141 : H12AffineEnvironment.transform 2 4 env2140 = env2141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2140 == env2141) = true)

def leafEnv2141 : List Nat := [2,4,4,16,17,1,20,21,22,20,0,1,20,0,17,2,16,16,21,17,16,16,16,19,20,4,1,0,1,1,17,17,20,0,20,0,4,19,1,22,1,17,0]

def active2141 : List Nat := [0,1,3]

def tree2141 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2141 : H12WitnessSearch.Good tree2141 := H12GlobalWitnessIndex.good

theorem leafIdentity2141 : H12AffineFastState.composeSystem env2141 rootObs = leafEnv2141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2141 rootObs == leafEnv2141) = true)

theorem terminalChecked2141 : H12PackedTerminal.terminalCheckFast leafEnv2141 active2141 tree2141 = true := by decide +kernel

def env2142 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,64,578,539,587,600,586,17,84,587,16,16,16,19,594,65,0,538,17,16,85,0,85,0,538,512]

theorem envBound2142 : H12AffineFastState.Bounded env2142 := by
  intro p hp
  have h : env2142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2136_2142 : H12AffineEnvironment.transform 10 1 env2136 = env2142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env2136 == env2142) = true)

theorem identity2142 : scanCanonicalize (H12AffineFastState.compose env2142 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound2142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2143 : List Nat := [2,4,8,16,17,64,24,84,71,85,1,64,5,92,12,31,13,17,84,12,16,16,16,19,21,65,0,93,17,16,85,0,85,0,93,71]

theorem envBound2143 : H12AffineFastState.Bounded env2143 := by
  intro p hp
  have h : env2143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2142_2143 : H12AffineEnvironment.transform 8 71 env2142 = env2143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env2142 == env2143) = true)

def env2144 : List Nat := [2,4,8,16,17,0,24,20,7,21,1,0,5,28,12,31,13,17,20,12,16,16,16,19,21,1,0,29,17,16,21,0,21,0,29,7]

theorem envBound2144 : H12AffineFastState.Bounded env2144 := by
  intro p hp
  have h : env2144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2143_2144 : H12AffineEnvironment.transform 5 0 env2143 = env2144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2143 == env2144) = true)

theorem identity2144 : scanCanonicalize (H12AffineFastState.compose env2144 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound2144 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2145 : List Nat := [2,4,8,12,13,0,4,8,7,9,1,0,5,0,12,3,13,13,8,12,12,12,12,15,9,1,0,1,13,12,9,0,9,0,1,7]

theorem envBound2145 : H12AffineFastState.Bounded env2145 := by
  intro p hp
  have h : env2145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2144_2145 : H12AffineEnvironment.transform 3 12 env2144 = env2145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env2144 == env2145) = true)

def leafEnv2145 : List Nat := [2,4,8,12,13,0,4,8,7,9,1,0,5,0,12,3,13,13,8,12,12,12,12,15,9,9,1,1,0,1,13,12,9,0,9,0,4,14,1,7,1,13,0]

def active2145 : List Nat := [0,1,2]

def tree2145 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2145 : H12WitnessSearch.Good tree2145 := H12GlobalWitnessIndex.good

theorem leafIdentity2145 : H12AffineFastState.composeSystem env2145 rootObs = leafEnv2145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2145 rootObs == leafEnv2145) = true)

theorem terminalChecked2145 : H12PackedTerminal.terminalCheckFast leafEnv2145 active2145 tree2145 = true := by decide +kernel

def env2146 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,1,5,29,12,31,13,17,21,12,16,16,16,19,21,0,0,28,17,16,20,0,20,0,28,6]

theorem envBound2146 : H12AffineFastState.Bounded env2146 := by
  intro p hp
  have h : env2146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2143_2146 : H12AffineEnvironment.transform 5 1 env2143 = env2146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2143 == env2146) = true)

def leafEnv2146 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,1,5,29,12,31,13,17,21,12,16,16,16,19,20,21,1,0,0,28,17,16,20,0,20,0,4,14,28,6,1,17,0]

def active2146 : List Nat := [0,1,2,3]

def tree2146 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood2146 : H12WitnessSearch.Good tree2146 := H12GlobalWitnessIndex.good

theorem leafIdentity2146 : H12AffineFastState.composeSystem env2146 rootObs = leafEnv2146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env2146 rootObs == leafEnv2146) = true)

theorem terminalChecked2146 : H12PackedTerminal.terminalCheckFast leafEnv2146 active2146 tree2146 = true := by decide +kernel

def env2147 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2080,74883,8201,74951,73891,185,73737,8328,73834,75906,2587,74862,2080,74882,0,73854,0,76440,512]

theorem envBound2147 : H12AffineFastState.Bounded env2147 := by
  intro p hp
  have h : env2147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2119_2147 : H12AffineEnvironment.transform 16 76385 env2119 = env2147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env2119 == env2147) = true)

theorem identity2147 : scanCanonicalize (H12AffineFastState.compose env2147 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound2147 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2148 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,99,10754,2080,9440,8201,9380,8384,185,8298,8328,8201,10465,2587,9229,2080,9441,0,8221,0,11003,512]

theorem envBound2148 : H12AffineFastState.Bounded env2148 := by
  intro p hp
  have h : env2148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2147_2148 : H12AffineEnvironment.transform 15 99 env2147 = env2148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env2147 == env2148) = true)

def env2149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2080,17375732,13108376,525568,0,34359738368,25691698]

theorem envBound2149 : H12AffineFastState.Bounded env2149 := by
  intro p hp
  have h : env2149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2065_2149 : H12AffineEnvironment.transform 14 8693 env2065 = env2149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env2065 == env2149) = true)

def env2150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672784,935128,16385,151552,2080,17375732,4867288,525568,0,34359738368,17450610]

theorem envBound2150 : H12AffineFastState.Bounded env2150 := by
  intro p hp
  have h : env2150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2149_2150 : H12AffineEnvironment.transform 22 147520 env2149 = env2150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env2149 == env2150) = true)

def env2151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16385,151552,2080,16852468,4341976,256,0,34359738368,16925298]

theorem envBound2151 : H12AffineFastState.Bounded env2151 := by
  intro p hp
  have h : env2151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2150_2151 : H12AffineEnvironment.transform 18 1024 env2150 = env2151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2150 == env2151) = true)

def env2152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16385,151552,2080,16852468,4341976,256,0,131072,16925298]

theorem envBound2152 : H12AffineFastState.Bounded env2152 := by
  intro p hp
  have h : env2152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2151_2152 : H12AffineEnvironment.transform 34 131072 env2151 = env2152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2151 == env2152) = true)

theorem identity2152 : scanCanonicalize (H12AffineFastState.compose env2152 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6439359) := by decide +kernel

theorem selectedBound2152 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,6439359,8328,147472,409816,16385,151552,2080,6513739,4341976,256,0,131072,6292429]

theorem envBound2153 : H12AffineFastState.Bounded env2153 := by
  intro p hp
  have h : env2153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2152_2153 : H12AffineEnvironment.transform 23 6439359 env2152 = env2153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6439359 env2152 == env2153) = true)

theorem identity2153 : scanCanonicalize (H12AffineFastState.compose env2153 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2153 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,4194304,147520,6439359,8328,147472,409816,16385,151552,2080,6439985,4341976,256,0,131072,6292429]

theorem envBound2154 : H12AffineFastState.Bounded env2154 := by
  intro p hp
  have h : env2154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2153_2154 : H12AffineEnvironment.transform 15 8314 env2153 = env2154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2153 == env2154) = true)

def env2155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,147672,147520,2097511,8328,147472,409816,16385,151552,2080,2098409,0,256,0,131072,2245397]

theorem envBound2155 : H12AffineFastState.Bounded env2155 := by
  intro p hp
  have h : env2155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2154_2155 : H12AffineEnvironment.transform 21 147672 env2154 = env2155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env2154 == env2155) = true)

theorem identity2155 : scanCanonicalize (H12AffineFastState.compose env2155 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 147472) := by decide +kernel

theorem selectedBound2155 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,147472,147672,147520,147831,8328,147472,409816,16385,151552,2080,148729,0,256,0,131072,773]

theorem envBound2156 : H12AffineFastState.Bounded env2156 := by
  intro p hp
  have h : env2156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2155_2156 : H12AffineEnvironment.transform 20 147472 env2155 = env2156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147472 env2155 == env2156) = true)

theorem identity2156 : scanCanonicalize (H12AffineFastState.compose env2156 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound2156 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env2157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16632,262144,1024,8693,232,32,184,399,8328,232,262176,16385,4344,2080,1025,0,256,0,16632,773]

theorem envBound2157 : H12AffineFastState.Bounded env2157 := by
  intro p hp
  have h : env2157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2156_2157 : H12AffineEnvironment.transform 16 16632 env2156 = env2157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2156 == env2157) = true)

theorem identity2157 : scanCanonicalize (H12AffineFastState.compose env2157 (packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2157 : packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env2158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16632,2265,1024,8693,232,32,184,399,8328,232,2297,16385,4344,2080,1025,0,256,0,16632,773]

theorem envBound2158 : H12AffineFastState.Bounded env2158 := by
  intro p hp
  have h : env2158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2157_2158 : H12AffineEnvironment.transform 17 2265 env2157 = env2158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2157 == env2158) = true)

theorem identity2158 : scanCanonicalize (H12AffineFastState.compose env2158 (packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound2158 : packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env2159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1085,16384,1480,1095,16632,2265,1024,1480,232,32,184,399,1205,232,2297,16385,4344,2080,1025,0,256,0,16632,773]

theorem envBound2159 : H12AffineFastState.Bounded env2159 := by
  intro p hp
  have h : env2159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2158_2159 : H12AffineEnvironment.transform 12 1085 env2158 = env2159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env2158 == env2159) = true)

theorem identity2159 : scanCanonicalize (H12AffineFastState.compose env2159 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound2159 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env2160 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1085,16384,1125,1095,16632,2265,1024,1125,232,32,184,34,1205,232,2297,16385,4344,2080,1025,0,173,0,16632,680]

theorem envBound2160 : H12AffineFastState.Bounded env2160 := by
  intro p hp
  have h : env2160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2159_2160 : H12AffineEnvironment.transform 7 173 env2159 = env2160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env2159 == env2160) = true)

theorem identity2160 : scanCanonicalize (H12AffineFastState.compose env2160 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2097) := by decide +kernel

theorem selectedBound2160 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env2161 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1085,2097,1125,1095,2249,2265,1024,1125,232,32,184,34,1205,232,2297,2096,4344,2080,1025,0,173,0,2249,680]

theorem envBound2161 : H12AffineFastState.Bounded env2161 := by
  intro p hp
  have h : env2161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2160_2161 : H12AffineEnvironment.transform 13 2097 env2160 = env2161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2097 env2160 == env2161) = true)

theorem identity2161 : scanCanonicalize (H12AffineFastState.compose env2161 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound2161 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env2162 : List Nat := [2,4,8,16,32,64,128,173,512,117,2048,4096,72,2097,16,50,2249,2265,117,16,232,32,184,34,192,232,2297,2096,4344,2080,116,0,173,0,2249,680]

theorem envBound2162 : H12AffineFastState.Bounded env2162 := by
  intro p hp
  have h : env2162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2161_2162 : H12AffineEnvironment.transform 9 117 env2161 = env2162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env2161 == env2162) = true)

theorem identity2162 : scanCanonicalize (H12AffineFastState.compose env2162 (packedSelected [0,1,3,5,7,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 2296) := by decide +kernel

theorem selectedBound2162 : packedSelected [0,1,3,5,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env2163 : List Nat := [2,4,8,16,32,64,128,173,512,117,2048,2296,72,2097,16,50,2249,2265,117,16,232,32,184,34,192,232,2297,2096,2048,2080,116,0,173,0,2249,680]

theorem envBound2163 : H12AffineFastState.Bounded env2163 := by
  intro p hp
  have h : env2163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2162_2163 : H12AffineEnvironment.transform 11 2296 env2162 = env2163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2296 env2162 == env2163) = true)

theorem identity2163 : scanCanonicalize (H12AffineFastState.compose env2163 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound2163 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env2164 : List Nat := [2,4,8,16,32,16,128,173,512,37,2048,2216,24,2097,16,50,2201,2185,37,16,184,32,184,34,144,184,2217,2096,2048,2080,36,0,173,0,2201,680]

theorem envBound2164 : H12AffineFastState.Bounded env2164 := by
  intro p hp
  have h : env2164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2163_2164 : H12AffineEnvironment.transform 5 16 env2163 = env2164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2163 == env2164) = true)

theorem identity2164 : scanCanonicalize (H12AffineFastState.compose env2164 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2164 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env2165 : List Nat := [2,4,8,1,32,1,128,173,512,37,2048,2216,9,2080,1,35,2184,2185,37,1,169,32,169,34,129,169,2217,2081,2048,2080,36,0,173,0,2184,680]

theorem envBound2165 : H12AffineFastState.Bounded env2165 := by
  intro p hp
  have h : env2165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2164_2165 : H12AffineEnvironment.transform 3 1 env2164 = env2165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2164 == env2165) = true)

theorem identity2165 : scanCanonicalize (H12AffineFastState.compose env2165 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound2165 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env2166 : List Nat := [2,4,8,1,32,1,128,173,512,37,169,1,9,137,1,35,33,32,37,1,169,32,169,34,129,169,0,136,169,137,36,0,173,0,33,680]

theorem envBound2166 : H12AffineFastState.Bounded env2166 := by
  intro p hp
  have h : env2166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2165_2166 : H12AffineEnvironment.transform 10 169 env2165 = env2166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env2165 == env2166) = true)

theorem identity2166 : scanCanonicalize (H12AffineFastState.compose env2166 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound2166 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env2167 : List Nat := [2,4,8,1,32,1,36,9,512,37,13,1,9,45,1,35,33,32,37,1,13,32,13,34,37,13,0,44,13,45,36,0,9,0,33,524]

theorem envBound2167 : H12AffineFastState.Bounded env2167 := by
  intro p hp
  have h : env2167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2166_2167 : H12AffineEnvironment.transform 6 36 env2166 = env2167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env2166 == env2167) = true)

def env2168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,147673,147520,2097510,8328,147472,409816,16385,151552,2080,2098408,1,256,0,131072,2245396]

theorem envBound2168 : H12AffineFastState.Bounded env2168 := by
  intro p hp
  have h : env2168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2154_2168 : H12AffineEnvironment.transform 21 147673 env2154 = env2168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env2154 == env2168) = true)

theorem identity2168 : scanCanonicalize (H12AffineFastState.compose env2168 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2168 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2169 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1024,8432,2097152,147673,147520,2097251,8328,147472,409816,16385,151552,2080,2098408,1,5,0,131072,2245137]

theorem envBound2169 : H12AffineFastState.Bounded env2169 := by
  intro p hp
  have h : env2169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2168_2169 : H12AffineEnvironment.transform 7 5 env2168 = env2169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2168 == env2169) = true)

def env2170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16385,151552,2080,16852468,4341976,256,0,131073,16925298]

theorem envBound2170 : H12AffineFastState.Bounded env2170 := by
  intro p hp
  have h : env2170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2151_2170 : H12AffineEnvironment.transform 34 131073 env2151 = env2170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2151 == env2170) = true)

theorem identity2170 : scanCanonicalize (H12AffineFastState.compose env2170 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4346302) := by decide +kernel

theorem selectedBound2170 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,4346302,8328,147472,409816,16385,151552,2080,4420682,4341976,256,0,131073,4199372]

theorem envBound2171 : H12AffineFastState.Bounded env2171 := by
  intro p hp
  have h : env2171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2170_2171 : H12AffineEnvironment.transform 23 4346302 env2170 = env2171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4346302 env2170 == env2171) = true)

theorem identity2171 : scanCanonicalize (H12AffineFastState.compose env2171 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound2171 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,293,147520,151707,8328,147472,409816,16385,151552,2080,226671,147965,256,0,131073,4841]

theorem envBound2172 : H12AffineFastState.Bounded env2172 := by
  intro p hp
  have h : env2172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2171_2172 : H12AffineEnvironment.transform 21 293 env2171 = env2172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env2171 == env2172) = true)

def env2173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,16384,8693,65536,131072,262144,1024,8693,2097152,293,147520,147571,8328,147472,409816,16385,147688,2080,222599,147965,256,0,131073,513]

theorem envBound2173 : H12AffineFastState.Bounded env2173 := by
  intro p hp
  have h : env2173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2172_2173 : H12AffineEnvironment.transform 11 232 env2172 = env2173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env2172 == env2173) = true)

theorem identity2173 : scanCanonicalize (H12AffineFastState.compose env2173 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 445) := by decide +kernel

theorem selectedBound2173 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,16384,8693,65536,131072,262144,1024,8693,445,293,147520,147571,8328,147472,409816,16385,147688,2080,222599,147965,256,0,131073,513]

theorem envBound2174 : H12AffineFastState.Bounded env2174 := by
  intro p hp
  have h : env2174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2173_2174 : H12AffineEnvironment.transform 20 445 env2173 = env2174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 445 env2173 == env2174) = true)

theorem identity2174 : scanCanonicalize (H12AffineFastState.compose env2174 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90243) := by decide +kernel

theorem selectedBound2174 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,16384,8693,65536,90243,262144,1024,8693,445,293,73923,73968,8328,73875,335963,16385,73835,2080,1284,74110,256,0,90242,513]

theorem envBound2175 : H12AffineFastState.Bounded env2175 := by
  intro p hp
  have h : env2175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2174_2175 : H12AffineEnvironment.transform 16 90243 env2174 = env2175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90243 env2174 == env2175) = true)

theorem identity2175 : scanCanonicalize (H12AffineFastState.compose env2175 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2175 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2176 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,232,8192,16384,8201,65536,90243,262144,1024,8201,65,217,73923,73968,8328,73875,335963,16385,73835,2080,1272,73858,252,0,90242,513]

theorem envBound2176 : H12AffineFastState.Bounded env2176 := by
  intro p hp
  have h : env2176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2175_2176 : H12AffineEnvironment.transform 7 252 env2175 = env2176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2175 == env2176) = true)

theorem identity2176 : scanCanonicalize (H12AffineFastState.compose env2176 (packedSelected [17,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound2176 : packedSelected [17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env2177 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,232,8192,16384,8201,8322,16385,262144,1024,8201,65,217,65,114,8328,17,262361,16385,233,2080,1272,0,252,0,16384,513]

theorem envBound2177 : H12AffineFastState.Bounded env2177 := by
  intro p hp
  have h : env2177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2176_2177 : H12AffineEnvironment.transform 15 8322 env2176 = env2177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env2176 == env2177) = true)

theorem identity2177 : scanCanonicalize (H12AffineFastState.compose env2177 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound2177 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2178 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,232,8192,81,8201,8322,80,262144,1024,8201,65,217,65,114,8328,17,262361,80,233,2080,1272,0,252,0,81,513]

theorem envBound2178 : H12AffineFastState.Bounded env2178 := by
  intro p hp
  have h : env2178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2177_2178 : H12AffineEnvironment.transform 13 81 env2177 = env2178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env2177 == env2178) = true)

theorem identity2178 : scanCanonicalize (H12AffineFastState.compose env2178 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 1036) := by decide +kernel

theorem selectedBound2178 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2179 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,232,1036,81,1029,1166,80,262144,1024,1029,65,217,65,114,1156,17,262361,80,233,2080,1272,0,252,0,81,513]

theorem envBound2179 : H12AffineFastState.Bounded env2179 := by
  intro p hp
  have h : env2179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2178_2179 : H12AffineEnvironment.transform 12 1036 env2178 = env2179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1036 env2178 == env2179) = true)

theorem identity2179 : scanCanonicalize (H12AffineFastState.compose env2179 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound2179 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env2180 : List Nat := [2,4,8,16,32,64,128,252,512,1024,33,232,1036,81,1029,1166,80,262144,1024,1029,65,217,65,114,1156,17,262361,80,233,1,1272,0,252,0,81,513]

theorem envBound2180 : H12AffineFastState.Bounded env2180 := by
  intro p hp
  have h : env2180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2179_2180 : H12AffineEnvironment.transform 10 33 env2179 = env2180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env2179 == env2180) = true)

theorem identity2180 : scanCanonicalize (H12AffineFastState.compose env2180 (packedSelected [0,2,9] rootPS)) = affineNative (2^(17+1) ^^^ 523) := by decide +kernel

theorem selectedBound2180 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env2181 : List Nat := [2,4,8,16,32,64,128,252,512,1024,33,232,1036,81,1029,1166,80,523,1024,1029,65,217,65,114,1156,17,722,80,233,1,1272,0,252,0,81,513]

theorem envBound2181 : H12AffineFastState.Bounded env2181 := by
  intro p hp
  have h : env2181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2180_2181 : H12AffineEnvironment.transform 17 523 env2180 = env2181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 523 env2180 == env2181) = true)

theorem identity2181 : scanCanonicalize (H12AffineFastState.compose env2181 (packedSelected [0,1,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2181 : packedSelected [0,1,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env2182 : List Nat := [2,4,8,16,32,64,128,252,512,4,33,232,8,81,1,138,80,523,4,1,65,217,65,114,128,17,722,80,233,1,252,0,252,0,81,513]

theorem envBound2182 : H12AffineFastState.Bounded env2182 := by
  intro p hp
  have h : env2182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2181_2182 : H12AffineEnvironment.transform 9 4 env2181 = env2182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2181 == env2182) = true)

theorem identity2182 : scanCanonicalize (H12AffineFastState.compose env2182 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 242) := by decide +kernel

theorem selectedBound2182 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env2183 : List Nat := [2,4,8,16,32,64,128,252,242,4,33,232,8,81,1,138,80,249,4,1,65,217,65,114,128,17,32,80,233,1,252,0,252,0,81,243]

theorem envBound2183 : H12AffineFastState.Bounded env2183 := by
  intro p hp
  have h : env2183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2182_2183 : H12AffineEnvironment.transform 8 242 env2182 = env2183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 242 env2182 == env2183) = true)

theorem identity2183 : scanCanonicalize (H12AffineFastState.compose env2183 (packedSelected [0,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound2183 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env2184 : List Nat := [2,4,8,16,32,64,121,5,11,4,33,17,8,81,1,115,80,0,4,1,65,32,65,114,121,17,32,80,16,1,5,0,5,0,81,10]

theorem envBound2184 : H12AffineFastState.Bounded env2184 := by
  intro p hp
  have h : env2184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2183_2184 : H12AffineEnvironment.transform 6 121 env2183 = env2184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env2183 == env2184) = true)

theorem identity2184 : scanCanonicalize (H12AffineFastState.compose env2184 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2184 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2185 : List Nat := [2,4,8,16,1,64,88,5,11,4,0,17,8,81,1,82,80,0,4,1,65,1,65,83,88,17,1,80,16,1,5,0,5,0,81,10]

theorem envBound2185 : H12AffineFastState.Bounded env2185 := by
  intro p hp
  have h : env2185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2184_2185 : H12AffineEnvironment.transform 4 1 env2184 = env2185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2184 == env2185) = true)

theorem identity2185 : scanCanonicalize (H12AffineFastState.compose env2185 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound2185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2186 : List Nat := [2,4,8,2,1,64,74,5,11,4,0,3,8,67,1,64,66,0,4,1,65,1,65,65,74,3,1,66,2,1,5,0,5,0,67,10]

theorem envBound2186 : H12AffineFastState.Bounded env2186 := by
  intro p hp
  have h : env2186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2185_2186 : H12AffineEnvironment.transform 3 2 env2185 = env2186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env2185 == env2186) = true)

theorem identity2186 : scanCanonicalize (H12AffineFastState.compose env2186 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2186 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2187 : List Nat := [2,4,8,2,1,1,11,5,11,4,0,3,8,2,1,1,3,0,4,1,0,1,0,0,11,3,1,3,2,1,5,0,5,0,2,10]

theorem envBound2187 : H12AffineFastState.Bounded env2187 := by
  intro p hp
  have h : env2187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2186_2187 : H12AffineEnvironment.transform 5 1 env2186 = env2187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2186 == env2187) = true)

theorem identity2187 : scanCanonicalize (H12AffineFastState.compose env2187 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound2187 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2188 : List Nat := [0,4,8,0,1,1,9,5,9,4,0,1,8,0,1,1,1,0,4,1,0,1,0,0,9,1,1,1,0,1,5,0,5,0,0,8]

theorem envBound2188 : H12AffineFastState.Bounded env2188 := by
  intro p hp
  have h : env2188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2187_2188 : H12AffineEnvironment.transform 0 0 env2187 = env2188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env2187 == env2188) = true)

theorem identity2188 : scanCanonicalize (H12AffineFastState.compose env2188 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound2188 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2189 : List Nat := [0,0,8,0,1,1,9,1,9,0,0,1,8,0,1,1,1,0,0,1,0,1,0,0,9,1,1,1,0,1,1,0,1,0,0,8]

theorem envBound2189 : H12AffineFastState.Bounded env2189 := by
  intro p hp
  have h : env2189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2188_2189 : H12AffineEnvironment.transform 1 0 env2188 = env2189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env2188 == env2189) = true)

def env2190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,131072,262144,1024,8693,2097152,293,147520,147570,8328,147472,409816,16385,147689,2080,222598,147965,256,0,131073,512]

theorem envBound2190 : H12AffineFastState.Bounded env2190 := by
  intro p hp
  have h : env2190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2172_2190 : H12AffineEnvironment.transform 11 233 env2172 = env2190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env2172 == env2190) = true)

theorem identity2190 : scanCanonicalize (H12AffineFastState.compose env2190 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2190 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2191 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,233,8192,16384,8432,65536,131072,262144,1024,8432,2097152,32,147520,147570,8328,147472,409816,16385,147689,2080,222339,147704,5,0,131073,512]

theorem envBound2191 : H12AffineFastState.Bounded env2191 := by
  intro p hp
  have h : env2191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2190_2191 : H12AffineEnvironment.transform 7 5 env2190 = env2191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2190 == env2191) = true)

theorem identity2191 : scanCanonicalize (H12AffineFastState.compose env2191 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2191 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2192 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,233,8192,16384,8432,8314,131072,262144,1024,8432,2097152,32,147520,147570,8328,147472,409816,16385,147689,2080,148729,147704,5,0,131073,512]

theorem envBound2192 : H12AffineFastState.Bounded env2192 := by
  intro p hp
  have h : env2192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1