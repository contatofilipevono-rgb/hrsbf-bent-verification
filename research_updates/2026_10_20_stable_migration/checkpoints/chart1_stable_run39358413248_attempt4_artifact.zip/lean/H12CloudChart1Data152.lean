import H12CloudChart1Data151

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound38540 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38541 : List Nat := [2,4,1,16,0,16,0,4,3,21,1,17,1,1,1,2,17,1,21,0,0,1,17,3,0,16,0,16,17,0,20,0,4,0,1,3]

theorem envBound38541 : H12AffineFastState.Bounded env38541 := by
  intro p hp
  have h : env38541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38540_38541 : H12AffineEnvironment.transform 2 1 env38540 = env38541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38540 == env38541) = true)

theorem identity38541 : scanCanonicalize (H12AffineFastState.compose env38541 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38542 : List Nat := [2,1,1,16,0,16,0,1,3,16,1,17,1,1,1,2,17,1,16,0,0,1,17,3,0,16,0,16,17,0,17,0,1,0,1,3]

theorem envBound38542 : H12AffineFastState.Bounded env38542 := by
  intro p hp
  have h : env38542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38541_38542 : H12AffineEnvironment.transform 1 1 env38541 = env38542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38541 == env38542) = true)

def env38543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98781,8328,64,2259213,2098513,17665,2543697,2102685,2411677,256,21793,46213,2175563]

theorem envBound38543 : H12AffineFastState.Bounded env38543 := by
  intro p hp
  have h : env38543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38494_38543 : H12AffineEnvironment.transform 21 272513 env38494 = env38543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38494 == env38543) = true)

theorem identity38543 : scanCanonicalize (H12AffineFastState.compose env38543 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound38543 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,272513,73754,98781,8328,64,215367,79131,17665,516123,75223,392407,256,21793,46213,513]

theorem envBound38544 : H12AffineFastState.Bounded env38544 := by
  intro p hp
  have h : env38544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38543_38544 : H12AffineEnvironment.transform 20 77898 env38543 = env38544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env38543 == env38544) = true)

def env38545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,272393,73754,98645,8192,64,215367,79131,17665,516123,75103,392287,256,21793,46093,513]

theorem envBound38545 : H12AffineFastState.Bounded env38545 := by
  intro p hp
  have h : env38545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38544_38545 : H12AffineEnvironment.transform 6 8 env38544 = env38545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38544 == env38545) = true)

theorem identity38545 : scanCanonicalize (H12AffineFastState.compose env38545 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound38545 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,77898,272393,73754,98645,8192,64,10589,79131,17665,294913,75103,392287,256,21793,46093,513]

theorem envBound38546 : H12AffineFastState.Bounded env38546 := by
  intro p hp
  have h : env38546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38545_38546 : H12AffineEnvironment.transform 16 90138 env38545 = env38546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env38545 == env38546) = true)

theorem identity38546 : scanCanonicalize (H12AffineFastState.compose env38546 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38546 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env38547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4161,272393,17,41310,8192,64,10589,5392,17665,294913,1364,318548,256,21793,46093,513]

theorem envBound38547 : H12AffineFastState.Bounded env38547 := by
  intro p hp
  have h : env38547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38546_38547 : H12AffineEnvironment.transform 15 8203 env38546 = env38547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38546 == env38547) = true)

theorem identity38547 : scanCanonicalize (H12AffineFastState.compose env38547 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound38547 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1024,32769,4161,41341,17,41310,8192,64,10589,5392,17665,2421,1364,21792,256,21793,46093,513]

theorem envBound38548 : H12AffineFastState.Bounded env38548 := by
  intro p hp
  have h : env38548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38547_38548 : H12AffineEnvironment.transform 17 35188 env38547 = env38548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env38547 == env38548) = true)

theorem identity38548 : scanCanonicalize (H12AffineFastState.compose env38548 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound38548 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,8203,16401,3125,1024,1344,4161,9276,17,9247,8192,64,10589,5392,17665,2421,1364,21792,256,21793,12620,513]

theorem envBound38549 : H12AffineFastState.Bounded env38549 := by
  intro p hp
  have h : env38549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38548_38549 : H12AffineEnvironment.transform 14 1345 env38548 = env38549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env38548 == env38549) = true)

theorem identity38549 : scanCanonicalize (H12AffineFastState.compose env38549 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound38549 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,16384,1345,1379,16401,3125,1024,1344,4161,340,17,375,1384,64,3125,5392,17665,2421,1364,21792,256,21793,5156,513]

theorem envBound38550 : H12AffineFastState.Bounded env38550 := by
  intro p hp
  have h : env38550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38549_38550 : H12AffineEnvironment.transform 12 1384 env38549 = env38550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env38549 == env38550) = true)

theorem identity38550 : scanCanonicalize (H12AffineFastState.compose env38550 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38550 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,1384,16384,1345,1379,16401,1077,1024,1344,4161,340,17,375,1384,64,1077,5392,17665,373,1364,21792,256,21793,5156,513]

theorem envBound38551 : H12AffineFastState.Bounded env38551 := by
  intro p hp
  have h : env38551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38550_38551 : H12AffineEnvironment.transform 10 0 env38550 = env38551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38550 == env38551) = true)

theorem identity38551 : scanCanonicalize (H12AffineFastState.compose env38551 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound38551 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env38552 : List Nat := [2,4,8,16,32,64,8,256,512,100,0,4096,268,16384,293,263,16401,81,100,292,4161,340,17,375,268,64,81,4468,16741,373,304,20804,256,20805,4160,513]

theorem envBound38552 : H12AffineFastState.Bounded env38552 := by
  intro p hp
  have h : env38552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38551_38552 : H12AffineEnvironment.transform 9 100 env38551 = env38552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env38551 == env38552) = true)

theorem identity38552 : scanCanonicalize (H12AffineFastState.compose env38552 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound38552 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38553 : List Nat := [2,4,8,16,32,64,8,256,512,100,0,4096,268,4113,293,263,4096,81,100,292,4161,340,17,375,268,64,81,4468,4468,373,304,341,256,340,4160,513]

theorem envBound38553 : H12AffineFastState.Bounded env38553 := by
  intro p hp
  have h : env38553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38552_38553 : H12AffineEnvironment.transform 13 4113 env38552 = env38553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env38552 == env38553) = true)

theorem identity38553 : scanCanonicalize (H12AffineFastState.compose env38553 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38553 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38554 : List Nat := [2,4,8,16,32,17,8,256,512,53,0,4096,268,4113,293,263,4096,0,53,292,4112,261,17,294,268,17,0,4389,4389,292,304,260,256,261,4113,513]

theorem envBound38554 : H12AffineFastState.Bounded env38554 := by
  intro p hp
  have h : env38554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38553_38554 : H12AffineEnvironment.transform 5 17 env38553 = env38554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38553 == env38554) = true)

theorem identity38554 : scanCanonicalize (H12AffineFastState.compose env38554 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound38554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38555 : List Nat := [2,4,8,16,32,17,8,256,512,53,0,16,268,1,293,263,16,0,53,292,0,261,17,294,268,17,0,309,309,292,304,260,256,261,1,513]

theorem envBound38555 : H12AffineFastState.Bounded env38555 := by
  intro p hp
  have h : env38555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38554_38555 : H12AffineEnvironment.transform 11 16 env38554 = env38555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env38554 == env38555) = true)

theorem identity38555 : scanCanonicalize (H12AffineFastState.compose env38555 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38555 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38556 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,41,1,0,34,16,0,53,1,0,32,17,3,41,17,0,16,16,1,21,33,37,32,1,513]

theorem envBound38556 : H12AffineFastState.Bounded env38556 := by
  intro p hp
  have h : env38556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38555_38556 : H12AffineEnvironment.transform 7 37 env38555 = env38556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38555 == env38556) = true)

theorem identity38556 : scanCanonicalize (H12AffineFastState.compose env38556 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38556 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38557 : List Nat := [2,4,8,0,32,1,8,37,512,37,0,0,41,1,0,34,0,0,37,1,0,32,1,3,41,1,0,0,0,1,5,33,37,32,1,513]

theorem envBound38557 : H12AffineFastState.Bounded env38557 := by
  intro p hp
  have h : env38557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38556_38557 : H12AffineEnvironment.transform 3 0 env38556 = env38557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38556 == env38557) = true)

theorem identity38557 : scanCanonicalize (H12AffineFastState.compose env38557 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38558 : List Nat := [2,4,8,0,11,1,8,14,512,14,0,0,2,1,0,9,0,0,14,1,0,11,1,3,2,1,0,0,0,1,5,10,14,11,1,513]

theorem envBound38558 : H12AffineFastState.Bounded env38558 := by
  intro p hp
  have h : env38558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38557_38558 : H12AffineEnvironment.transform 4 11 env38557 = env38558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38557 == env38558) = true)

def env38559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,272392,73754,98644,8193,64,215367,79131,17665,516123,75102,392286,256,21793,46092,513]

theorem envBound38559 : H12AffineFastState.Bounded env38559 := by
  intro p hp
  have h : env38559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38544_38559 : H12AffineEnvironment.transform 6 9 env38544 = env38559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38544 == env38559) = true)

def env38560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77898,32,73754,98644,8193,64,215367,79131,17665,247859,75102,119926,256,21793,46092,513]

theorem envBound38560 : H12AffineFastState.Bounded env38560 := by
  intro p hp
  have h : env38560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38559_38560 : H12AffineEnvironment.transform 17 10280 env38559 = env38560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38559 == env38560) = true)

def env38561 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,32,73754,98564,8193,16,215319,79131,17665,247859,75022,119846,256,21793,46092,513]

theorem envBound38561 : H12AffineFastState.Bounded env38561 := by
  intro p hp
  have h : env38561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38560_38561 : H12AffineEnvironment.transform 5 16 env38560 = env38561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38560 == env38561) = true)

theorem identity38561 : scanCanonicalize (H12AffineFastState.compose env38561 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38561 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38562 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,10280,1024,0,77850,32,73754,65797,8193,16,215319,79131,17665,215090,75022,87079,256,21793,13325,513]

theorem envBound38562 : H12AffineFastState.Bounded env38562 := by
  intro p hp
  have h : env38562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38561_38562 : H12AffineEnvironment.transform 14 1 env38561 = env38562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38561 == env38562) = true)

theorem identity38562 : scanCanonicalize (H12AffineFastState.compose env38562 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound38562 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env38563 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,5392,10280,1024,0,77850,32,73754,65797,8193,16,89095,79131,17665,89378,75022,87079,256,21793,13325,513]

theorem envBound38563 : H12AffineFastState.Bounded env38563 := by
  intro p hp
  have h : env38563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38562_38563 : H12AffineEnvironment.transform 16 5392 env38562 = env38563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env38562 == env38563) = true)

theorem identity38563 : scanCanonicalize (H12AffineFastState.compose env38563 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound38563 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38564 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,262,5392,10280,1024,0,12572,32,8476,3,8193,16,23809,13341,17665,23588,9224,21793,256,21793,13325,513]

theorem envBound38564 : H12AffineFastState.Bounded env38564 := by
  intro p hp
  have h : env38564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38563_38564 : H12AffineEnvironment.transform 15 262 env38563 = env38564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env38563 == env38564) = true)

theorem identity38564 : scanCanonicalize (H12AffineFastState.compose env38564 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound38564 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38565 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,262,5392,10280,1024,0,12572,32,8476,3,8193,16,10508,13341,12556,10281,9224,8492,256,8492,13325,513]

theorem envBound38565 : H12AffineFastState.Bounded env38565 := by
  intro p hp
  have h : env38565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38564_38565 : H12AffineEnvironment.transform 13 13325 env38564 = env38565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env38564 == env38565) = true)

theorem identity38565 : scanCanonicalize (H12AffineFastState.compose env38565 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38565 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38566 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1024,0,4112,32,16,3,269,16,2048,5393,4096,2341,1284,32,256,32,5377,513]

theorem envBound38566 : H12AffineFastState.Bounded env38566 := by
  intro p hp
  have h : env38566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38565_38566 : H12AffineEnvironment.transform 12 268 env38565 = env38566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38565 == env38566) = true)

theorem identity38566 : scanCanonicalize (H12AffineFastState.compose env38566 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound38566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38567 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,32,268,1313,1,262,1328,2340,1024,0,48,32,16,3,269,16,2048,1329,32,2341,1284,32,256,32,1313,513]

theorem envBound38567 : H12AffineFastState.Bounded env38567 := by
  intro p hp
  have h : env38567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38566_38567 : H12AffineEnvironment.transform 11 32 env38566 = env38567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env38566 == env38567) = true)

theorem identity38567 : scanCanonicalize (H12AffineFastState.compose env38567 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound38567 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38568 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1323,32,268,1313,1,262,1328,1039,1024,0,48,32,16,3,269,16,1323,1329,32,1038,1284,32,256,32,1313,513]

theorem envBound38568 : H12AffineFastState.Bounded env38568 := by
  intro p hp
  have h : env38568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38567_38568 : H12AffineEnvironment.transform 10 1323 env38567 = env38568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env38567 == env38568) = true)

theorem identity38568 : scanCanonicalize (H12AffineFastState.compose env38568 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound38568 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38569 : List Nat := [2,4,8,16,32,16,9,256,271,1024,1323,32,268,1313,1,262,1328,1039,1024,0,48,32,16,3,269,16,1323,1329,32,1038,1284,32,256,32,1313,270]

theorem envBound38569 : H12AffineFastState.Bounded env38569 := by
  intro p hp
  have h : env38569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38568_38569 : H12AffineEnvironment.transform 8 271 env38568 = env38569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env38568 == env38569) = true)

theorem identity38569 : scanCanonicalize (H12AffineFastState.compose env38569 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound38569 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38570 : List Nat := [2,4,8,16,32,16,9,31,16,1024,1076,32,19,1086,1,25,1071,1039,1024,0,48,32,16,3,18,16,1076,1070,32,1038,1051,32,31,32,1086,17]

theorem envBound38570 : H12AffineFastState.Bounded env38570 := by
  intro p hp
  have h : env38570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38569_38570 : H12AffineEnvironment.transform 7 31 env38569 = env38570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env38569 == env38570) = true)

theorem identity38570 : scanCanonicalize (H12AffineFastState.compose env38570 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound38570 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38571 : List Nat := [2,4,8,16,32,16,9,31,16,47,27,32,19,17,1,25,0,32,47,0,48,32,16,3,18,16,27,1,32,33,52,32,31,32,17,17]

theorem envBound38571 : H12AffineFastState.Bounded env38571 := by
  intro p hp
  have h : env38571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38570_38571 : H12AffineEnvironment.transform 9 47 env38570 = env38571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env38570 == env38571) = true)

theorem identity38571 : scanCanonicalize (H12AffineFastState.compose env38571 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38571 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38572 : List Nat := [2,4,8,1,32,1,9,14,1,47,10,32,2,0,1,8,0,32,47,0,33,32,1,3,3,1,10,1,32,33,37,32,14,32,0,0]

theorem envBound38572 : H12AffineFastState.Bounded env38572 := by
  intro p hp
  have h : env38572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38571_38572 : H12AffineEnvironment.transform 3 1 env38571 = env38572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38571 == env38572) = true)

theorem identity38572 : scanCanonicalize (H12AffineFastState.compose env38572 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound38572 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38573 : List Nat := [2,4,8,1,4,1,9,14,1,11,10,4,2,0,1,8,0,4,11,0,5,4,1,3,3,1,10,1,4,5,1,4,14,4,0,0]

theorem envBound38573 : H12AffineFastState.Bounded env38573 := by
  intro p hp
  have h : env38573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38572_38573 : H12AffineEnvironment.transform 4 4 env38572 = env38573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env38572 == env38573) = true)

theorem identity38573 : scanCanonicalize (H12AffineFastState.compose env38573 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38573 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env38574 : List Nat := [2,4,3,1,4,1,2,5,1,0,1,4,2,0,1,3,0,4,0,0,5,4,1,3,3,1,1,1,4,5,1,4,5,4,0,0]

theorem envBound38574 : H12AffineFastState.Bounded env38574 := by
  intro p hp
  have h : env38574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38573_38574 : H12AffineEnvironment.transform 2 3 env38573 = env38574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38573 == env38574) = true)

theorem identity38574 : scanCanonicalize (H12AffineFastState.compose env38574 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38574 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38575 : List Nat := [2,3,3,1,3,1,2,2,1,0,1,3,2,0,1,3,0,3,0,0,2,3,1,3,3,1,1,1,3,2,1,3,2,3,0,0]

theorem envBound38575 : H12AffineFastState.Bounded env38575 := by
  intro p hp
  have h : env38575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38574_38575 : H12AffineEnvironment.transform 1 3 env38574 = env38575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38574 == env38575) = true)

def env38576 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,32,73754,98565,8193,17,215318,79131,17665,247859,75023,119847,256,21793,46092,513]

theorem envBound38576 : H12AffineFastState.Bounded env38576 := by
  intro p hp
  have h : env38576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38560_38576 : H12AffineEnvironment.transform 5 17 env38560 = env38576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38560 == env38576) = true)

theorem identity38576 : scanCanonicalize (H12AffineFastState.compose env38576 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38576 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38577 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,131072,10280,1024,32769,12572,32,8477,32770,8193,17,149521,13340,17665,182580,9224,54560,256,21793,46092,513]

theorem envBound38577 : H12AffineFastState.Bounded env38577 := by
  intro p hp
  have h : env38577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38576_38577 : H12AffineEnvironment.transform 15 263 env38576 = env38577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38576 == env38577) = true)

theorem identity38577 : scanCanonicalize (H12AffineFastState.compose env38577 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound38577 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38578 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,263,5393,10280,1024,32769,12572,32,8477,32770,8193,17,23808,13340,17665,56357,9224,54560,256,21793,46092,513]

theorem envBound38578 : H12AffineFastState.Bounded env38578 := by
  intro p hp
  have h : env38578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38577_38578 : H12AffineEnvironment.transform 16 5393 env38577 = env38578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env38577 == env38578) = true)

theorem identity38578 : scanCanonicalize (H12AffineFastState.compose env38578 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38578 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env38579 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,263,5393,10280,1024,32769,12572,32,8477,32770,8193,17,2049,13340,4096,35108,9224,32801,256,32,46092,513]

theorem envBound38579 : H12AffineFastState.Bounded env38579 := by
  intro p hp
  have h : env38579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38578_38579 : H12AffineEnvironment.transform 13 5377 env38578 = env38579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38578 == env38579) = true)

theorem identity38579 : scanCanonicalize (H12AffineFastState.compose env38579 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38579 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env38580 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,0,263,5393,10280,1024,1,12572,32,8477,2,8193,17,2049,13340,4096,2340,9224,33,256,32,13324,513]

theorem envBound38580 : H12AffineFastState.Bounded env38580 := by
  intro p hp
  have h : env38580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38579_38580 : H12AffineEnvironment.transform 14 0 env38579 = env38580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38579 == env38580) = true)

theorem identity38580 : scanCanonicalize (H12AffineFastState.compose env38580 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38580 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env38581 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,4096,8192,4357,0,263,4373,10280,4,1,12572,32,8477,2,8193,17,2049,12312,4096,2340,8204,33,256,32,12296,513]

theorem envBound38581 : H12AffineFastState.Bounded env38581 := by
  intro p hp
  have h : env38581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38580_38581 : H12AffineEnvironment.transform 9 4 env38580 = env38581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38580 == env38581) = true)

theorem identity38581 : scanCanonicalize (H12AffineFastState.compose env38581 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound38581 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env38582 : List Nat := [2,4,8,16,32,17,9,52,512,4,2048,4096,8192,4145,0,51,4129,10280,4,1,12328,32,8233,2,8193,17,2049,12312,4096,2064,8204,33,52,32,12296,513]

theorem envBound38582 : H12AffineFastState.Bounded env38582 := by
  intro p hp
  have h : env38582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38581_38582 : H12AffineEnvironment.transform 7 52 env38581 = env38582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env38581 == env38582) = true)

theorem identity38582 : scanCanonicalize (H12AffineFastState.compose env38582 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound38582 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env38583 : List Nat := [2,4,8,16,32,17,9,52,512,4,2048,4096,57,4145,0,51,4129,2065,4,1,4113,32,16,2,56,17,2049,4129,4096,2064,53,33,52,32,4145,513]

theorem envBound38583 : H12AffineFastState.Bounded env38583 := by
  intro p hp
  have h : env38583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38582_38583 : H12AffineEnvironment.transform 12 57 env38582 = env38583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env38582 == env38583) = true)

theorem identity38583 : scanCanonicalize (H12AffineFastState.compose env38583 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38584 : List Nat := [2,4,8,1,32,0,9,37,512,4,2048,4096,40,4128,0,34,4129,2048,4,1,4096,32,1,2,41,0,2049,4129,4096,2049,36,33,37,32,4128,513]

theorem envBound38584 : H12AffineFastState.Bounded env38584 := by
  intro p hp
  have h : env38584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38583_38584 : H12AffineEnvironment.transform 3 1 env38583 = env38584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38583 == env38584) = true)

theorem identity38584 : scanCanonicalize (H12AffineFastState.compose env38584 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38584 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38585 : List Nat := [2,4,8,1,0,0,9,5,512,4,2048,4096,8,4096,0,2,4097,2048,4,1,4096,0,1,2,9,0,2049,4097,4096,2049,4,1,5,0,4096,513]

theorem envBound38585 : H12AffineFastState.Bounded env38585 := by
  intro p hp
  have h : env38585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38584_38585 : H12AffineEnvironment.transform 4 0 env38584 = env38585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38584 == env38585) = true)

theorem identity38585 : scanCanonicalize (H12AffineFastState.compose env38585 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38585 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38586 : List Nat := [2,4,8,1,0,0,9,5,512,4,2048,0,8,0,0,2,1,2048,4,1,0,0,1,2,9,0,2049,1,0,2049,4,1,5,0,0,513]

theorem envBound38586 : H12AffineFastState.Bounded env38586 := by
  intro p hp
  have h : env38586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38585_38586 : H12AffineEnvironment.transform 11 0 env38585 = env38586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38585 == env38586) = true)

theorem identity38586 : scanCanonicalize (H12AffineFastState.compose env38586 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound38586 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38587 : List Nat := [2,4,8,1,0,0,9,5,512,4,10,0,8,0,0,2,1,10,4,1,0,0,1,2,9,0,11,1,0,11,4,1,5,0,0,513]

theorem envBound38587 : H12AffineFastState.Bounded env38587 := by
  intro p hp
  have h : env38587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38586_38587 : H12AffineEnvironment.transform 10 10 env38586 = env38587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env38586 == env38587) = true)

theorem identity38587 : scanCanonicalize (H12AffineFastState.compose env38587 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound38587 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38588 : List Nat := [2,4,8,1,0,0,9,5,10,4,10,0,8,0,0,2,1,10,4,1,0,0,1,2,9,0,11,1,0,11,4,1,5,0,0,11]

theorem envBound38588 : H12AffineFastState.Bounded env38588 := by
  intro p hp
  have h : env38588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38587_38588 : H12AffineEnvironment.transform 8 10 env38587 = env38588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env38587 == env38588) = true)

def env38589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77898,33,73754,98644,8193,64,215367,79131,17665,247858,75102,119927,256,21793,46092,513]

theorem envBound38589 : H12AffineFastState.Bounded env38589 := by
  intro p hp
  have h : env38589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38559_38589 : H12AffineEnvironment.transform 17 10281 env38559 = env38589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38559 == env38589) = true)

theorem identity38589 : scanCanonicalize (H12AffineFastState.compose env38589 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38589 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1024,32769,4160,33,16,41310,8193,64,158029,5393,17665,190520,1364,62589,256,21793,46092,513]

theorem envBound38590 : H12AffineFastState.Bounded env38590 := by
  intro p hp
  have h : env38590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38589_38590 : H12AffineEnvironment.transform 15 8202 env38589 = env38590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38589 == env38590) = true)

theorem identity38590 : scanCanonicalize (H12AffineFastState.compose env38590 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27740) := by decide +kernel

theorem selectedBound38590 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,27740,10281,1024,32769,4160,33,16,41310,8193,64,1297,5393,17665,33892,1364,62589,256,21793,46092,513]

theorem envBound38591 : H12AffineFastState.Bounded env38591 := by
  intro p hp
  have h : env38591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38590_38591 : H12AffineEnvironment.transform 16 27740 env38590 = env38591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27740 env38590 == env38591) = true)

theorem identity38591 : scanCanonicalize (H12AffineFastState.compose env38591 (packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38591 : packedSelected [1,3,4,5,8,9,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env38592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,19573,2048,1024,32769,4160,33,16,33143,40,64,1297,5393,17665,33892,1364,54356,256,21793,37925,513]

theorem envBound38592 : H12AffineFastState.Bounded env38592 := by
  intro p hp
  have h : env38592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38591_38592 : H12AffineEnvironment.transform 12 41 env38591 = env38592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38591 == env38592) = true)

theorem identity38592 : scanCanonicalize (H12AffineFastState.compose env38592 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound38592 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env38593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5409,32768,35,6484,2048,1024,32769,4160,33,16,33143,40,64,1297,5393,4128,33892,1364,33141,256,0,37925,513]

theorem envBound38593 : H12AffineFastState.Bounded env38593 := by
  intro p hp
  have h : env38593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38592_38593 : H12AffineEnvironment.transform 13 5409 env38592 = env38593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env38592 == env38593) = true)

theorem identity38593 : scanCanonicalize (H12AffineFastState.compose env38593 (packedSelected [11,23] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound38593 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env38594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1376,4096,41,5409,32768,35,5172,1376,1024,32769,4160,33,16,33143,40,64,1297,5393,4128,33892,1364,33141,256,0,37925,513]

theorem envBound38594 : H12AffineFastState.Bounded env38594 := by
  intro p hp
  have h : env38594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38593_38594 : H12AffineEnvironment.transform 10 1376 env38593 = env38594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env38593 == env38594) = true)

theorem identity38594 : scanCanonicalize (H12AffineFastState.compose env38594 (packedSelected [4,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound38594 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38595 : List Nat := [2,4,8,16,32,64,9,256,512,304,80,4096,41,4113,32768,35,4356,80,304,32769,4160,33,16,33143,40,64,33,4129,4128,33108,100,33141,256,0,37141,513]

theorem envBound38595 : H12AffineFastState.Bounded env38595 := by
  intro p hp
  have h : env38595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38594_38595 : H12AffineEnvironment.transform 9 304 env38594 = env38595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env38594 == env38595) = true)

theorem identity38595 : scanCanonicalize (H12AffineFastState.compose env38595 (packedSelected [2,3,4,5,6,9,12,19] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound38595 : packedSelected [2,3,4,5,6,9,12,19] rootPS < 2^1333 := by decide +kernel

def env38596 : List Nat := [2,4,8,16,32,64,9,256,512,304,80,4096,41,4113,4112,35,4356,80,304,4113,4160,33,16,4455,40,64,33,4129,4128,4420,100,4453,256,0,261,513]

theorem envBound38596 : H12AffineFastState.Bounded env38596 := by
  intro p hp
  have h : env38596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38595_38596 : H12AffineEnvironment.transform 14 4112 env38595 = env38596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env38595 == env38596) = true)

theorem identity38596 : scanCanonicalize (H12AffineFastState.compose env38596 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 357) := by decide +kernel

theorem selectedBound38596 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env38597 : List Nat := [2,4,8,16,32,64,9,256,357,304,80,4096,41,4113,4112,35,4356,80,304,4113,4160,33,16,4455,40,64,33,4129,4128,4420,100,4453,256,0,261,356]

theorem envBound38597 : H12AffineFastState.Bounded env38597 := by
  intro p hp
  have h : env38597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38596_38597 : H12AffineEnvironment.transform 8 357 env38596 = env38597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 357 env38596 == env38597) = true)

theorem identity38597 : scanCanonicalize (H12AffineFastState.compose env38597 (packedSelected [10,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38597 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env38598 : List Nat := [2,4,8,16,32,0,9,256,293,304,16,4096,41,4113,4112,35,4356,16,304,4113,4096,33,16,4391,40,0,33,4129,4128,4356,36,4389,256,0,261,292]

theorem envBound38598 : H12AffineFastState.Bounded env38598 := by
  intro p hp
  have h : env38598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38597_38598 : H12AffineEnvironment.transform 5 0 env38597 = env38598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38597 == env38598) = true)

theorem identity38598 : scanCanonicalize (H12AffineFastState.compose env38598 (packedSelected [1,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38598 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env38599 : List Nat := [2,4,8,16,1,0,9,256,260,273,16,4096,8,4113,4112,2,4356,16,273,4113,4096,0,16,4358,9,0,0,4096,4097,4356,5,4356,256,0,261,261]

theorem envBound38599 : H12AffineFastState.Bounded env38599 := by
  intro p hp
  have h : env38599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38598_38599 : H12AffineEnvironment.transform 4 1 env38598 = env38599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38598 == env38599) = true)

theorem identity38599 : scanCanonicalize (H12AffineFastState.compose env38599 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38599 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env38600 : List Nat := [2,4,8,16,1,0,9,21,17,4,16,4096,8,4113,4112,2,4113,16,4,4113,4096,0,16,4115,9,0,0,4096,4097,4113,5,4113,21,0,16,16]

theorem envBound38600 : H12AffineFastState.Bounded env38600 := by
  intro p hp
  have h : env38600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38599_38600 : H12AffineEnvironment.transform 7 21 env38599 = env38600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38599 == env38600) = true)

theorem identity38600 : scanCanonicalize (H12AffineFastState.compose env38600 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38601 : List Nat := [2,4,8,0,1,0,9,5,1,4,0,4096,8,4097,4096,2,4097,0,4,4097,4096,0,0,4099,9,0,0,4096,4097,4097,5,4097,5,0,0,0]

theorem envBound38601 : H12AffineFastState.Bounded env38601 := by
  intro p hp
  have h : env38601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38600_38601 : H12AffineEnvironment.transform 3 0 env38600 = env38601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38600 == env38601) = true)

theorem identity38601 : scanCanonicalize (H12AffineFastState.compose env38601 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound38601 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38602 : List Nat := [2,4,8,0,1,0,9,5,1,4,0,10,8,11,10,2,11,0,4,11,10,0,0,9,9,0,0,10,11,11,5,11,5,0,0,0]

theorem envBound38602 : H12AffineFastState.Bounded env38602 := by
  intro p hp
  have h : env38602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38601_38602 : H12AffineEnvironment.transform 11 10 env38601 = env38602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env38601 == env38602) = true)

theorem identity38602 : scanCanonicalize (H12AffineFastState.compose env38602 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38602 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38603 : List Nat := [2,4,3,0,1,0,2,5,1,4,0,1,3,0,1,2,0,0,4,0,1,0,0,2,2,0,0,1,0,0,5,0,5,0,0,0]

theorem envBound38603 : H12AffineFastState.Bounded env38603 := by
  intro p hp
  have h : env38603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38602_38603 : H12AffineEnvironment.transform 2 3 env38602 = env38603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38602 == env38603) = true)

def env38604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101329,98780,8328,64,6705548,2098512,17664,2543696,2102685,6349853,256,21793,46213,2175563]

theorem envBound38604 : H12AffineFastState.Bounded env38604 := by
  intro p hp
  have h : env38604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38493_38604 : H12AffineEnvironment.transform 22 2101329 env38493 = env38604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env38493 == env38604) = true)

def env38605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101329,98780,8328,64,2259212,2098512,17664,2543696,2102685,2411677,256,21793,46213,2175563]

theorem envBound38605 : H12AffineFastState.Bounded env38605 := by
  intro p hp
  have h : env38605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38604_38605 : H12AffineEnvironment.transform 21 272512 env38604 = env38605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38604 == env38605) = true)

theorem identity38605 : scanCanonicalize (H12AffineFastState.compose env38605 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound38605 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,2097152,272512,2101329,21763,8328,64,2259212,2098512,17664,2543696,2102685,2411677,256,21793,46213,2156180]

theorem envBound38606 : H12AffineFastState.Bounded env38606 := by
  intro p hp
  have h : env38606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38605_38606 : H12AffineEnvironment.transform 15 54495 env38605 = env38606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env38605 == env38606) = true)

def env38607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,2097152,272392,2101329,21763,8192,64,2259212,2098512,17664,2543696,2102549,2411541,256,21793,46093,2156060]

theorem envBound38607 : H12AffineFastState.Bounded env38607 := by
  intro p hp
  have h : env38607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38606_38607 : H12AffineEnvironment.transform 6 8 env38606 = env38607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38606 == env38607) = true)

theorem identity38607 : scanCanonicalize (H12AffineFastState.compose env38607 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound38607 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env38608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,157752,1024,32769,2097152,147504,2101329,21763,8192,64,2259212,2098512,17664,2144360,2102549,2270253,256,21793,46093,2156060]

theorem envBound38608 : H12AffineFastState.Bounded env38608 := by
  intro p hp
  have h : env38608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38607_38608 : H12AffineEnvironment.transform 17 157752 env38607 = env38608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env38607 == env38608) = true)

theorem identity38608 : scanCanonicalize (H12AffineFastState.compose env38608 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound38608 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,57676,35188,1024,32769,2097152,41340,2101329,21763,8192,64,2136128,2098512,17664,2144360,2102549,2114913,256,21793,46093,2156060]

theorem envBound38609 : H12AffineFastState.Bounded env38609 := by
  intro p hp
  have h : env38609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38608_38609 : H12AffineEnvironment.transform 16 57676 env38608 = env38609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env38608 == env38609) = true)

theorem identity38609 : scanCanonicalize (H12AffineFastState.compose env38609 (packedSelected [1,5,8,17,19,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 45340) := by decide +kernel

theorem selectedBound38609 : packedSelected [1,5,8,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,57676,35188,1024,32769,45340,41340,41293,21763,8192,64,10588,46156,17664,2420,41993,62589,256,21793,46093,22272]

theorem envBound38610 : H12AffineFastState.Bounded env38610 := by
  intro p hp
  have h : env38610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38609_38610 : H12AffineEnvironment.transform 20 45340 env38609 = env38610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45340 env38609 == env38610) = true)

theorem identity38610 : scanCanonicalize (H12AffineFastState.compose env38610 (packedSelected [1,4,5,9,10,12,14,15,16,18,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound38610 : packedSelected [1,4,5,9,10,12,14,15,16,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,41343,37988,35188,1024,32769,45340,41340,41293,8235,8192,64,10588,46156,12328,2420,41993,33109,256,8201,46093,8744]

theorem envBound38611 : H12AffineFastState.Bounded env38611 := by
  intro p hp
  have h : env38611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38610_38611 : H12AffineEnvironment.transform 13 13608 env38610 = env38611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env38610 == env38611) = true)

theorem identity38611 : scanCanonicalize (H12AffineFastState.compose env38611 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38611 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env38612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,34,13625,10281,1024,8540,4161,33,16,8235,8192,64,10588,5393,12328,2420,1364,8200,256,8201,5456,8744]

theorem envBound38612 : H12AffineFastState.Bounded env38612 := by
  intro p hp
  have h : env38612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38611_38612 : H12AffineEnvironment.transform 14 8541 env38611 = env38612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38611 == env38612) = true)

theorem identity38612 : scanCanonicalize (H12AffineFastState.compose env38612 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38612 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38613 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,8192,13576,8541,2,13593,10249,1024,8540,4161,1,16,8203,8192,64,10588,5393,12296,2388,1364,8200,256,8201,5456,8712]

theorem envBound38613 : H12AffineFastState.Bounded env38613 := by
  intro p hp
  have h : env38613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38612_38613 : H12AffineEnvironment.transform 4 0 env38612 = env38613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38612 == env38613) = true)

theorem identity38613 : scanCanonicalize (H12AffineFastState.compose env38613 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38613 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38614 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,8192,12312,8541,2,12297,10249,272,8540,4161,1,16,8203,8192,64,10588,4097,12296,2388,68,8200,256,8201,4160,8712]

theorem envBound38614 : H12AffineFastState.Bounded env38614 := by
  intro p hp
  have h : env38614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38613_38614 : H12AffineEnvironment.transform 9 272 env38613 = env38614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38613 == env38614) = true)

theorem identity38614 : scanCanonicalize (H12AffineFastState.compose env38614 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38614 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env38615 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,349,4421,0,2,4436,2388,272,1,4161,1,16,342,349,64,2049,4097,4437,2388,68,341,256,340,4160,853]

theorem envBound38615 : H12AffineFastState.Bounded env38615 := by
  intro p hp
  have h : env38615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38614_38615 : H12AffineEnvironment.transform 12 349 env38614 = env38615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38614 == env38615) = true)

theorem identity38615 : scanCanonicalize (H12AffineFastState.compose env38615 (packedSelected [0,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38615 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env38616 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,268,4372,0,2,4357,2309,272,1,4112,1,16,263,268,17,2049,4097,4356,2309,21,260,256,261,4113,772]

theorem envBound38616 : H12AffineFastState.Bounded env38616 := by
  intro p hp
  have h : env38616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38615_38616 : H12AffineEnvironment.transform 5 17 env38615 = env38616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38615 == env38616) = true)

theorem identity38616 : scanCanonicalize (H12AffineFastState.compose env38616 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38616 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env38617 : List Nat := [2,4,8,16,0,17,8,256,512,272,0,4096,268,4372,0,2,4357,261,272,1,4112,1,16,263,268,17,1,4097,4356,261,21,260,256,261,4113,772]

theorem envBound38617 : H12AffineFastState.Bounded env38617 := by
  intro p hp
  have h : env38617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38616_38617 : H12AffineEnvironment.transform 10 0 env38616 = env38617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38616 == env38617) = true)

theorem identity38617 : scanCanonicalize (H12AffineFastState.compose env38617 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38617 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env38618 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,4096,9,4113,0,2,4096,0,21,1,4112,1,16,2,9,17,1,4097,4097,0,21,1,5,0,4113,513]

theorem envBound38618 : H12AffineFastState.Bounded env38618 := by
  intro p hp
  have h : env38618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38617_38618 : H12AffineEnvironment.transform 7 5 env38617 = env38618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38617 == env38618) = true)

theorem identity38618 : scanCanonicalize (H12AffineFastState.compose env38618 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound38618 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38619 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,512,9,529,0,2,512,0,21,1,528,1,16,2,9,17,1,513,513,0,21,1,5,0,529,513]

theorem envBound38619 : H12AffineFastState.Bounded env38619 := by
  intro p hp
  have h : env38619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38618_38619 : H12AffineEnvironment.transform 11 512 env38618 = env38619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env38618 == env38619) = true)

def env38620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,2097152,272393,2101329,21763,8193,64,2259212,2098512,17664,2543696,2102548,2411540,256,21793,46092,2156061]

theorem envBound38620 : H12AffineFastState.Bounded env38620 := by
  intro p hp
  have h : env38620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38606_38620 : H12AffineEnvironment.transform 6 9 env38606 = env38620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38606 == env38620) = true)

theorem identity38620 : scanCanonicalize (H12AffineFastState.compose env38620 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 314420) := by decide +kernel

theorem selectedBound38620 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env38621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,314420,272393,318565,21763,8193,64,439608,313700,17664,138340,317728,32,256,21793,46092,272937]

theorem envBound38621 : H12AffineFastState.Bounded env38621 := by
  intro p hp
  have h : env38621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38620_38621 : H12AffineEnvironment.transform 20 314420 env38620 = env38621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314420 env38620 == env38621) = true)

def env38622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,58396,33,62541,21763,8193,64,171280,57676,17664,138340,61704,32,256,21793,46092,513]

theorem envBound38622 : H12AffineFastState.Bounded env38622 := by
  intro p hp
  have h : env38622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38621_38622 : H12AffineEnvironment.transform 17 10280 env38621 = env38622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38621 == env38622) = true)

theorem identity38622 : scanCanonicalize (H12AffineFastState.compose env38622 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound38622 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env38623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49217,10280,1024,32769,58396,33,62541,21763,8193,64,23889,57676,17664,56357,61704,32,256,21793,46092,513]

theorem envBound38623 : H12AffineFastState.Bounded env38623 := by
  intro p hp
  have h : env38623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38622_38623 : H12AffineEnvironment.transform 16 49217 env38622 = env38623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env38622 == env38623) = true)

theorem identity38623 : scanCanonicalize (H12AffineFastState.compose env38623 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound38623 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env38624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,8283,13388,10280,1024,29708,4113,33,64,21763,8193,64,23889,5441,17664,10280,1285,32,256,21793,16385,513]

theorem envBound38624 : H12AffineFastState.Bounded env38624 := by
  intro p hp
  have h : env38624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38623_38624 : H12AffineEnvironment.transform 14 29709 env38623 = env38624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env38623 == env38624) = true)

theorem identity38624 : scanCanonicalize (H12AffineFastState.compose env38624 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound38624 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,8283,13388,10280,1024,0,4113,33,64,8463,8193,64,10589,5441,12556,10280,1285,32,256,8493,13325,513]

theorem envBound38625 : H12AffineFastState.Bounded env38625 := by
  intro p hp
  have h : env38625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38624_38625 : H12AffineEnvironment.transform 13 13324 env38624 = env38625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env38624 == env38625) = true)

theorem identity38625 : scanCanonicalize (H12AffineFastState.compose env38625 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38625 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,343,5440,2340,1024,0,4113,33,64,3,269,64,2129,5441,4096,2340,1285,32,256,33,5377,513]

theorem envBound38626 : H12AffineFastState.Bounded env38626 := by
  intro p hp
  have h : env38626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38625_38626 : H12AffineEnvironment.transform 12 268 env38625 = env38626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38625 == env38626) = true)

theorem identity38626 : scanCanonicalize (H12AffineFastState.compose env38626 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38626 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38627 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1024,0,4113,33,17,3,269,17,2048,5392,4096,2340,1285,32,256,33,5377,513]

theorem envBound38627 : H12AffineFastState.Bounded env38627 := by
  intro p hp
  have h : env38627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38626_38627 : H12AffineEnvironment.transform 5 17 env38626 = env38627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38626 == env38627) = true)

theorem identity38627 : scanCanonicalize (H12AffineFastState.compose env38627 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38628 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5173,2048,1024,0,4113,33,17,3,41,17,2048,5172,4096,2048,1057,32,36,33,5157,513]

theorem envBound38628 : H12AffineFastState.Bounded env38628 := by
  intro p hp
  have h : env38628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38627_38628 : H12AffineEnvironment.transform 7 36 env38627 = env38628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38627 == env38628) = true)

theorem identity38628 : scanCanonicalize (H12AffineFastState.compose env38628 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound38628 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38629 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,40,5156,1,34,5173,523,1024,0,4113,33,17,3,41,17,523,5172,4096,523,1057,32,36,33,5157,513]

theorem envBound38629 : H12AffineFastState.Bounded env38629 := by
  intro p hp
  have h : env38629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38628_38629 : H12AffineEnvironment.transform 10 523 env38628 = env38629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env38628 == env38629) = true)

theorem identity38629 : scanCanonicalize (H12AffineFastState.compose env38629 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38629 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38630 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,9,5125,1,3,5140,523,1024,0,4113,0,17,3,8,17,523,5141,4096,523,1024,1,5,0,5124,513]

theorem envBound38630 : H12AffineFastState.Bounded env38630 := by
  intro p hp
  have h : env38630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38629_38630 : H12AffineEnvironment.transform 4 1 env38629 = env38630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38629 == env38630) = true)

def env38631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,58397,32,62540,21763,8193,64,171281,57677,17664,138340,61705,32,256,21793,46092,512]

theorem envBound38631 : H12AffineFastState.Bounded env38631 := by
  intro p hp
  have h : env38631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38621_38631 : H12AffineEnvironment.transform 17 10281 env38621 = env38631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38621 == env38631) = true)

theorem identity38631 : scanCanonicalize (H12AffineFastState.compose env38631 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 3092) := by decide +kernel

theorem selectedBound38631 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env38632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3092,32768,38978,131072,10281,1024,32769,43017,32,47192,6423,8193,64,171281,44377,2324,138340,48413,32,256,6453,46092,512]

theorem envBound38632 : H12AffineFastState.Bounded env38632 := by
  intro p hp
  have h : env38632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38631_38632 : H12AffineEnvironment.transform 13 3092 env38631 = env38632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3092 env38631 == env38632) = true)

theorem identity38632 : scanCanonicalize (H12AffineFastState.compose env38632 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 14408) := by decide +kernel

theorem selectedBound38632 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3092,14408,8202,131072,10281,1024,14409,4161,32,16,6423,8193,64,140633,5393,2324,138340,1365,32,256,6453,3140,512]

theorem envBound38633 : H12AffineFastState.Bounded env38633 := by
  intro p hp
  have h : env38633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38632_38633 : H12AffineEnvironment.transform 14 14408 env38632 = env38633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14408 env38632 == env38633) = true)

theorem identity38633 : scanCanonicalize (H12AffineFastState.compose env38633 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound38633 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,3092,7252,1046,131072,3125,1024,7253,4161,32,16,6423,1053,64,131397,5393,2324,138340,1365,32,256,6453,3140,512]

theorem envBound38634 : H12AffineFastState.Bounded env38634 := by
  intro p hp
  have h : env38634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38633_38634 : H12AffineEnvironment.transform 12 1052 env38633 = env38634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env38633 == env38634) = true)

theorem identity38634 : scanCanonicalize (H12AffineFastState.compose env38634 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 3441) := by decide +kernel

theorem selectedBound38634 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,3092,7252,1046,3441,3125,1024,7253,4161,32,16,6423,1053,64,3124,5393,2324,4373,1365,32,256,6453,3140,512]

theorem envBound38635 : H12AffineFastState.Bounded env38635 := by
  intro p hp
  have h : env38635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38634_38635 : H12AffineEnvironment.transform 16 3441 env38634 = env38635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3441 env38634 == env38635) = true)

theorem identity38635 : scanCanonicalize (H12AffineFastState.compose env38635 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound38635 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env38636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,1052,3092,260,1046,3441,3125,1024,261,3345,32,16,1095,1053,64,3124,2113,2324,3141,1365,32,256,1125,3140,512]

theorem envBound38636 : H12AffineFastState.Bounded env38636 := by
  intro p hp
  have h : env38636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38635_38636 : H12AffineEnvironment.transform 11 3408 env38635 = env38636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env38635 == env38636) = true)

theorem identity38636 : scanCanonicalize (H12AffineFastState.compose env38636 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38636 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env38637 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,1052,3092,113,1046,3076,3125,1024,112,3172,32,16,1095,1053,64,3124,2113,2145,3141,1056,32,117,1125,3140,512]

theorem envBound38637 : H12AffineFastState.Bounded env38637 := by
  intro p hp
  have h : env38637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38636_38637 : H12AffineEnvironment.transform 7 117 env38636 = env38637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38636 == env38637) = true)

theorem identity38637 : scanCanonicalize (H12AffineFastState.compose env38637 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound38637 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env38638 : List Nat := [2,4,8,16,32,64,9,117,512,15,2048,2090,19,2075,113,25,2059,2106,15,112,2155,32,16,72,18,64,2107,2113,2145,2122,47,32,117,106,2123,512]

theorem envBound38638 : H12AffineFastState.Bounded env38638 := by
  intro p hp
  have h : env38638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38637_38638 : H12AffineEnvironment.transform 9 15 env38637 = env38638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env38637 == env38638) = true)

theorem identity38638 : scanCanonicalize (H12AffineFastState.compose env38638 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound38638 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env38639 : List Nat := [2,4,8,16,32,64,9,117,512,15,90,112,19,65,113,25,81,96,15,112,49,32,16,72,18,64,97,27,59,16,47,32,117,106,17,512]

theorem envBound38639 : H12AffineFastState.Bounded env38639 := by
  intro p hp
  have h : env38639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38638_38639 : H12AffineEnvironment.transform 10 90 env38638 = env38639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env38638 == env38639) = true)

theorem identity38639 : scanCanonicalize (H12AffineFastState.compose env38639 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38639 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env38640 : List Nat := [2,4,8,10,32,64,9,111,512,15,64,106,9,65,107,3,75,96,15,106,43,32,10,72,8,64,97,1,33,10,47,32,111,106,11,512]

theorem envBound38640 : H12AffineFastState.Bounded env38640 := by
  intro p hp
  have h : env38640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38639_38640 : H12AffineEnvironment.transform 3 10 env38639 = env38640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38639 == env38640) = true)

theorem identity38640 : scanCanonicalize (H12AffineFastState.compose env38640 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound38640 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env38641 : List Nat := [2,4,6,4,32,64,7,97,512,1,64,100,7,65,101,3,69,96,1,100,37,32,4,70,6,64,97,1,33,4,33,32,97,100,5,512]

theorem envBound38641 : H12AffineFastState.Bounded env38641 := by
  intro p hp
  have h : env38641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38640_38641 : H12AffineEnvironment.transform 2 6 env38640 = env38641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env38640 == env38641) = true)

theorem identity38641 : scanCanonicalize (H12AffineFastState.compose env38641 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound38641 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38642 : List Nat := [2,4,6,4,32,36,7,5,512,1,36,0,7,37,1,3,33,4,1,0,37,32,4,34,6,36,5,1,33,4,33,32,5,0,5,512]

theorem envBound38642 : H12AffineFastState.Bounded env38642 := by
  intro p hp
  have h : env38642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38641_38642 : H12AffineEnvironment.transform 5 36 env38641 = env38642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env38641 == env38642) = true)

theorem identity38642 : scanCanonicalize (H12AffineFastState.compose env38642 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound38642 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env38643 : List Nat := [2,4,6,4,5,1,7,5,512,1,1,0,7,0,1,3,4,4,1,0,0,5,4,7,6,1,5,1,4,4,4,5,5,0,5,512]

theorem envBound38643 : H12AffineFastState.Bounded env38643 := by
  intro p hp
  have h : env38643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38642_38643 : H12AffineEnvironment.transform 4 5 env38642 = env38643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env38642 == env38643) = true)

theorem identity38643 : scanCanonicalize (H12AffineFastState.compose env38643 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38643 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38644 : List Nat := [2,0,2,0,1,1,3,1,512,1,1,0,3,0,1,3,0,0,1,0,0,1,0,3,2,1,1,1,0,0,0,1,1,0,1,512]

theorem envBound38644 : H12AffineFastState.Bounded env38644 := by
  intro p hp
  have h : env38644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38643_38644 : H12AffineEnvironment.transform 1 0 env38643 = env38644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38643 == env38644) = true)

theorem identity38644 : scanCanonicalize (H12AffineFastState.compose env38644 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound38644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38645 : List Nat := [2,0,2,0,1,1,3,1,2,1,1,0,3,0,1,3,0,0,1,0,0,1,0,3,2,1,1,1,0,0,0,1,1,0,1,2]

theorem envBound38645 : H12AffineFastState.Bounded env38645 := by
  intro p hp
  have h : env38645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38644_38645 : H12AffineEnvironment.transform 8 2 env38644 = env38645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env38644 == env38645) = true)

def env38646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101329,98780,8328,64,2259213,2098512,17664,2543696,2102685,2411676,256,21793,46213,2175563]

theorem envBound38646 : H12AffineFastState.Bounded env38646 := by
  intro p hp
  have h : env38646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38604_38646 : H12AffineEnvironment.transform 21 272513 env38604 = env38646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38604 == env38646) = true)

theorem identity38646 : scanCanonicalize (H12AffineFastState.compose env38646 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound38646 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,120015,98780,8328,64,245139,115150,17664,464078,119043,329730,256,21793,46213,63189]

theorem envBound38647 : H12AffineFastState.Bounded env38647 := by
  intro p hp
  have h : env38647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38646_38647 : H12AffineEnvironment.transform 20 115870 env38646 = env38647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env38646 == env38647) = true)

def env38648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,119879,98644,8192,64,245019,115014,17664,463942,119043,329730,256,21793,46093,63069]

theorem envBound38648 : H12AffineFastState.Bounded env38648 := by
  intro p hp
  have h : env38648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38647_38648 : H12AffineEnvironment.transform 6 8 env38647 = env38648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38647 == env38648) = true)

theorem identity38648 : scanCanonicalize (H12AffineFastState.compose env38648 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound38648 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,171109,1024,32769,115734,177260,119879,98644,8192,64,245019,115014,17664,100387,119043,234599,256,21793,46093,63069]

theorem envBound38649 : H12AffineFastState.Bounded env38649 := by
  intro p hp
  have h : env38649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38648_38649 : H12AffineEnvironment.transform 17 171109 env38648 = env38649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env38648 == env38649) = true)

theorem identity38649 : scanCanonicalize (H12AffineFastState.compose env38649 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38649 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,171109,1024,32769,102679,177260,98630,98644,8192,64,245019,103495,4097,100387,99330,234599,256,32,46093,41820]

theorem envBound38650 : H12AffineFastState.Bounded env38650 := by
  intro p hp
  have h : env38650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38649_38650 : H12AffineEnvironment.transform 13 5377 env38649 = env38650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38649 == env38650) = true)

theorem identity38650 : scanCanonicalize (H12AffineFastState.compose env38650 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound38650 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103494,67619,1024,32769,102679,73770,98630,98644,8192,64,10589,103495,4097,100387,99330,33,256,32,46093,41820]

theorem envBound38651 : H12AffineFastState.Bounded env38651 := by
  intro p hp
  have h : env38651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38650_38651 : H12AffineEnvironment.transform 16 103494 env38650 = env38651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env38650 == env38651) = true)

theorem identity38651 : scanCanonicalize (H12AffineFastState.compose env38651 (packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound38651 : packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env38652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,32768,65536,103494,67619,1024,32769,102679,65619,98630,98644,121,64,2340,103495,4097,100387,99330,33,256,32,38004,33573]

theorem envBound38652 : H12AffineFastState.Bounded env38652 := by
  intro p hp
  have h : env38652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38651_38652 : H12AffineEnvironment.transform 12 121 env38651 = env38652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env38651 == env38652) = true)

def env38653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,119878,98645,8193,64,245018,115015,17664,463943,119043,329730,256,21793,46092,63068]

theorem envBound38653 : H12AffineFastState.Bounded env38653 := by
  intro p hp
  have h : env38653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38647_38653 : H12AffineEnvironment.transform 6 9 env38647 = env38653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38647 == env38653) = true)

theorem identity38653 : scanCanonicalize (H12AffineFastState.compose env38653 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38653 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38654 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115735,32,119878,98645,8193,64,245018,115015,17664,212079,119043,73770,256,21793,46092,63068]

theorem envBound38654 : H12AffineFastState.Bounded env38654 := by
  intro p hp
  have h : env38654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38653_38654 : H12AffineEnvironment.transform 17 10280 env38653 = env38654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38653 == env38654) = true)

theorem identity38654 : scanCanonicalize (H12AffineFastState.compose env38654 (packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound38654 : packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env38655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,115735,32,119878,98645,8193,64,64605,115015,17664,32040,119043,73770,256,21793,46092,63068]

theorem envBound38655 : H12AffineFastState.Bounded env38655 := by
  intro p hp
  have h : env38655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38654_38655 : H12AffineEnvironment.transform 16 82247 env38654 = env38655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env38654 == env38655) = true)

theorem identity38655 : scanCanonicalize (H12AffineFastState.compose env38655 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound38655 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,82247,10280,1024,29788,77898,32,73755,95496,8193,64,2048,79130,17664,32040,75102,73770,256,21793,16465,513]

theorem envBound38656 : H12AffineFastState.Bounded env38656 := by
  intro p hp
  have h : env38656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38655_38656 : H12AffineEnvironment.transform 14 29789 env38655 = env38656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env38655 == env38656) = true)

theorem identity38656 : scanCanonicalize (H12AffineFastState.compose env38656 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound38656 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,16401,10280,1024,29788,12572,32,8525,29790,8193,64,2048,13388,17664,32040,9224,8572,256,21793,16465,513]

theorem envBound38657 : H12AffineFastState.Bounded env38657 := by
  intro p hp
  have h : env38657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38656_38657 : H12AffineEnvironment.transform 15 342 env38656 = env38657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env38656 == env38657) = true)

theorem identity38657 : scanCanonicalize (H12AffineFastState.compose env38657 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38657 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,342,16401,2421,1024,21761,4161,32,16,21763,348,64,2048,5393,17664,23669,1365,33,256,21793,16465,513]

theorem envBound38658 : H12AffineFastState.Bounded env38658 := by
  intro p hp
  have h : env38658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38657_38658 : H12AffineEnvironment.transform 12 349 env38657 = env38658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38657 == env38658) = true)

theorem identity38658 : scanCanonicalize (H12AffineFastState.compose env38658 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38658 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1024,0,4161,32,16,2,348,64,2048,5393,4097,2420,1365,33,256,32,5456,513]

theorem envBound38659 : H12AffineFastState.Bounded env38659 := by
  intro p hp
  have h : env38659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38658_38659 : H12AffineEnvironment.transform 13 5377 env38658 = env38659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38658 == env38659) = true)

theorem identity38659 : scanCanonicalize (H12AffineFastState.compose env38659 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound38659 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,869,349,1636,1,342,1653,2421,1024,0,804,32,16,2,348,64,2048,1652,868,2420,1365,33,256,32,1589,513]

theorem envBound38660 : H12AffineFastState.Bounded env38660 := by
  intro p hp
  have h : env38660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38659_38660 : H12AffineEnvironment.transform 11 869 env38659 = env38660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env38659 == env38660) = true)

theorem identity38660 : scanCanonicalize (H12AffineFastState.compose env38660 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1792) := by decide +kernel

theorem selectedBound38660 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1792,869,349,1636,1,342,1653,1653,1024,0,804,32,16,2,348,64,1792,1652,868,1652,1365,33,256,32,1589,513]

theorem envBound38661 : H12AffineFastState.Bounded env38661 := by
  intro p hp
  have h : env38661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38660_38661 : H12AffineEnvironment.transform 10 1792 env38660 = env38661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env38660 == env38661) = true)

theorem identity38661 : scanCanonicalize (H12AffineFastState.compose env38661 (packedSelected [5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38661 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env38662 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,820,268,1589,1,263,1572,1572,1024,0,804,32,16,2,269,17,1792,1573,821,1573,1284,33,256,32,1589,513]

theorem envBound38662 : H12AffineFastState.Bounded env38662 := by
  intro p hp
  have h : env38662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38661_38662 : H12AffineEnvironment.transform 5 17 env38661 = env38662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38661 == env38662) = true)

theorem identity38662 : scanCanonicalize (H12AffineFastState.compose env38662 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound38662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38663 : List Nat := [2,4,8,16,32,17,9,53,512,1024,1589,513,57,1589,1,50,1572,1572,1024,0,529,32,16,2,56,17,1589,1573,512,1573,1073,33,53,32,1589,513]

theorem envBound38663 : H12AffineFastState.Bounded env38663 := by
  intro p hp
  have h : env38663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38662_38663 : H12AffineEnvironment.transform 7 53 env38662 = env38663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env38662 == env38663) = true)

theorem identity38663 : scanCanonicalize (H12AffineFastState.compose env38663 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound38663 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38664 : List Nat := [2,4,8,16,32,17,9,53,512,565,0,513,57,0,1,50,17,17,565,0,529,32,16,2,56,17,0,16,512,16,516,33,53,32,0,513]

theorem envBound38664 : H12AffineFastState.Bounded env38664 := by
  intro p hp
  have h : env38664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38663_38664 : H12AffineEnvironment.transform 9 565 env38663 = env38664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env38663 == env38664) = true)

theorem identity38664 : scanCanonicalize (H12AffineFastState.compose env38664 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound38664 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38665 : List Nat := [2,4,8,16,32,17,9,53,16,37,0,17,57,0,1,50,17,17,37,0,1,32,16,2,56,17,0,16,16,16,20,33,53,32,0,17]

theorem envBound38665 : H12AffineFastState.Bounded env38665 := by
  intro p hp
  have h : env38665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38664_38665 : H12AffineEnvironment.transform 8 16 env38664 = env38665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env38664 == env38665) = true)

theorem identity38665 : scanCanonicalize (H12AffineFastState.compose env38665 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38666 : List Nat := [2,4,8,16,1,17,9,20,16,4,0,17,24,0,1,19,17,17,4,0,1,1,16,2,25,17,0,16,16,16,20,0,20,1,0,17]

theorem envBound38666 : H12AffineFastState.Bounded env38666 := by
  intro p hp
  have h : env38666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38665_38666 : H12AffineEnvironment.transform 4 1 env38665 = env38666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38665 == env38666) = true)

theorem identity38666 : scanCanonicalize (H12AffineFastState.compose env38666 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38667 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,1,8,0,1,3,1,1,4,0,1,1,0,2,9,1,0,0,0,0,4,0,4,1,0,1]

theorem envBound38667 : H12AffineFastState.Bounded env38667 := by
  intro p hp
  have h : env38667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38666_38667 : H12AffineEnvironment.transform 3 0 env38666 = env38667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38666 == env38667) = true)

def env38668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound38668 : H12AffineFastState.Bounded env38668 := by
  intro p hp
  have h : env38668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38310_38668 : H12AffineEnvironment.transform 18 1025 env38310 = env38668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env38310 == env38668) = true)

theorem identity38668 : scanCanonicalize (H12AffineFastState.compose env38668 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642688) := by decide +kernel

theorem selectedBound38668 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642688,8328,64,4464768,10642445,10507601,8830976,156816,14845249,257,2237485,2278792,213831]

theorem envBound38669 : H12AffineFastState.Bounded env38669 := by
  intro p hp
  have h : env38669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38668_38669 : H12AffineEnvironment.transform 23 8642688 env38668 = env38669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642688 env38668 == env38669) = true)

def env38670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,8388608,8642688,8328,64,4464768,8393985,8528989,8830976,156816,12645453,257,21793,46212,213831]

theorem envBound38670 : H12AffineFastState.Bounded env38670 := by
  intro p hp
  have h : env38670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38669_38670 : H12AffineEnvironment.transform 20 160012 env38669 = env38670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160012 env38669 == env38670) = true)

def env38671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169352,95496,8328,64,4464768,163977,45525,284040,156816,4350405,257,21793,46212,213831]

theorem envBound38671 : H12AffineFastState.Bounded env38671 := by
  intro p hp
  have h : env38671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38670_38671 : H12AffineEnvironment.transform 22 169352 env38670 = env38671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env38670 == env38671) = true)

def env38672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169352,95496,8328,64,2048,163977,45525,284040,156816,411973,257,21793,46212,213831]

theorem envBound38672 : H12AffineFastState.Bounded env38672 := by
  intro p hp
  have h : env38672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38671_38672 : H12AffineEnvironment.transform 21 272512 env38671 = env38672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38671 == env38672) = true)

theorem identity38672 : scanCanonicalize (H12AffineFastState.compose env38672 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound38672 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,58517,272512,17,95496,8328,64,2048,5392,45525,284040,61705,318684,257,21793,46212,120542]

theorem envBound38673 : H12AffineFastState.Bounded env38673 := by
  intro p hp
  have h : env38673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38672_38673 : H12AffineEnvironment.transform 16 38297 env38672 = env38673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env38672 == env38673) = true)

def env38674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,17,95496,8192,64,2048,5392,45405,283904,61705,318548,257,21793,46092,120406]

theorem envBound38674 : H12AffineFastState.Bounded env38674 := by
  intro p hp
  have h : env38674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38673_38674 : H12AffineEnvironment.transform 6 8 env38673 = env38674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38673 == env38674) = true)

theorem identity38674 : scanCanonicalize (H12AffineFastState.compose env38674 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,58397,32,17,95496,8192,64,2048,5392,45405,32040,61705,62588,257,21793,46092,120406]

theorem envBound38675 : H12AffineFastState.Bounded env38675 := by
  intro p hp
  have h : env38675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38674_38675 : H12AffineEnvironment.transform 17 10280 env38674 = env38675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38674 == env38675) = true)

theorem identity38675 : scanCanonicalize (H12AffineFastState.compose env38675 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound38675 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,38161,10280,1025,32769,58397,32,17,8542,8192,64,2048,5392,45405,32040,61705,62588,257,21793,46092,33280]

theorem envBound38676 : H12AffineFastState.Bounded env38676 := by
  intro p hp
  have h : env38676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38675_38676 : H12AffineEnvironment.transform 15 21590 env38675 = env38676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env38675 == env38676) = true)

theorem identity38676 : scanCanonicalize (H12AffineFastState.compose env38676 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound38676 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21590,16401,10280,1025,21761,12573,32,17,8542,8192,64,2048,5392,25693,32040,9225,8572,257,21793,24844,22272]

theorem envBound38677 : H12AffineFastState.Bounded env38677 := by
  intro p hp
  have h : env38677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38676_38677 : H12AffineEnvironment.transform 14 21760 env38676 = env38677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env38676 == env38677) = true)

theorem identity38677 : scanCanonicalize (H12AffineFastState.compose env38677 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38677 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env38678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21590,16401,2420,1025,21761,4161,32,17,2,348,64,2048,5392,17665,23668,1365,32,257,21793,16464,22272]

theorem envBound38678 : H12AffineFastState.Bounded env38678 := by
  intro p hp
  have h : env38678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38677_38678 : H12AffineEnvironment.transform 12 348 env38677 = env38678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38677 == env38678) = true)

theorem identity38678 : scanCanonicalize (H12AffineFastState.compose env38678 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound38678 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env38679 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,16384,21589,21590,16401,2081,1025,21588,4161,32,17,2,9,64,2048,5189,17492,23668,1024,32,84,21620,16464,22101]

theorem envBound38679 : H12AffineFastState.Bounded env38679 := by
  intro p hp
  have h : env38679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38678_38679 : H12AffineEnvironment.transform 7 85 env38678 = env38679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env38678 == env38679) = true)

theorem identity38679 : scanCanonicalize (H12AffineFastState.compose env38679 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound38679 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env38680 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,5205,0,3,5188,2081,1025,1,4161,32,17,2,9,64,2048,5189,4097,2081,1024,32,84,33,5125,512]

theorem envBound38680 : H12AffineFastState.Bounded env38680 := by
  intro p hp
  have h : env38680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38679_38680 : H12AffineEnvironment.transform 13 5205 env38679 = env38680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env38679 == env38680) = true)

theorem identity38680 : scanCanonicalize (H12AffineFastState.compose env38680 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound38680 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38681 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,4096,9,4161,0,3,4176,2081,21,1,4161,32,17,2,9,64,2048,4177,4097,2081,20,32,84,33,4113,512]

theorem envBound38681 : H12AffineFastState.Bounded env38681 := by
  intro p hp
  have h : env38681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38680_38681 : H12AffineEnvironment.transform 9 20 env38680 = env38681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38680 == env38681) = true)

theorem identity38681 : scanCanonicalize (H12AffineFastState.compose env38681 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound38681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38682 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,96,9,33,0,3,48,2081,21,1,33,32,17,2,9,64,2048,49,97,2081,20,32,84,33,113,512]

theorem envBound38682 : H12AffineFastState.Bounded env38682 := by
  intro p hp
  have h : env38682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38681_38682 : H12AffineEnvironment.transform 11 96 env38681 = env38682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env38681 == env38682) = true)

theorem identity38682 : scanCanonicalize (H12AffineFastState.compose env38682 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38682 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38683 : List Nat := [2,4,8,16,0,64,8,85,512,20,2048,64,9,1,0,3,16,2049,21,1,1,0,17,2,9,64,2048,17,65,2049,20,0,84,1,81,512]

theorem envBound38683 : H12AffineFastState.Bounded env38683 := by
  intro p hp
  have h : env38683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38682_38683 : H12AffineEnvironment.transform 4 0 env38682 = env38683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38682 == env38683) = true)

theorem identity38683 : scanCanonicalize (H12AffineFastState.compose env38683 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound38683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38684 : List Nat := [2,4,8,16,0,64,8,85,80,20,2048,64,9,1,0,3,16,2049,21,1,1,0,17,2,9,64,2048,17,65,2049,20,0,84,1,81,80]

theorem envBound38684 : H12AffineFastState.Bounded env38684 := by
  intro p hp
  have h : env38684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38683_38684 : H12AffineEnvironment.transform 8 80 env38683 = env38684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env38683 == env38684) = true)

theorem identity38684 : scanCanonicalize (H12AffineFastState.compose env38684 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38684 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38685 : List Nat := [2,4,8,16,0,64,8,85,80,20,1,64,9,1,0,3,16,0,21,1,1,0,17,2,9,64,1,17,65,0,20,0,84,1,81,80]

theorem envBound38685 : H12AffineFastState.Bounded env38685 := by
  intro p hp
  have h : env38685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38684_38685 : H12AffineEnvironment.transform 10 1 env38684 = env38685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38684 == env38685) = true)

def env38686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,17,95496,8193,64,2048,5392,45404,283905,61705,318549,257,21793,46093,120407]

theorem envBound38686 : H12AffineFastState.Bounded env38686 := by
  intro p hp
  have h : env38686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38673_38686 : H12AffineEnvironment.transform 6 9 env38673 = env38686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38673 == env38686) = true)

theorem identity38686 : scanCanonicalize (H12AffineFastState.compose env38686 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound38686 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35189,1025,32769,58396,41340,17,95496,8193,64,2048,5392,45404,56436,61705,21792,257,21793,46093,120407]

theorem envBound38687 : H12AffineFastState.Bounded env38687 := by
  intro p hp
  have h : env38687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38686_38687 : H12AffineEnvironment.transform 17 35189 env38686 = env38687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env38686 == env38687) = true)

theorem identity38687 : scanCanonicalize (H12AffineFastState.compose env38687 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38687 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env38688 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,37989,34816,1025,32769,58396,40969,17,95357,8193,64,2048,5221,45097,56436,61564,21589,116,21588,46093,120407]

theorem envBound38688 : H12AffineFastState.Bounded env38688 := by
  intro p hp
  have h : env38688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38687_38688 : H12AffineEnvironment.transform 7 117 env38687 = env38688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38687 == env38688) = true)

theorem identity38688 : scanCanonicalize (H12AffineFastState.compose env38688 (packedSelected [0,1,4,7,8,12,15,16,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound38688 : packedSelected [0,1,4,7,8,12,15,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env38689 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8313,65536,13340,10361,1025,8312,17509,112,17,95357,8193,64,2048,5221,4176,31757,20485,21589,116,21588,5236,95790]

theorem envBound38689 : H12AffineFastState.Bounded env38689 := by
  intro p hp
  have h : env38689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38688_38689 : H12AffineEnvironment.transform 14 8313 env38688 = env38689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env38688 == env38689) = true)

theorem identity38689 : scanCanonicalize (H12AffineFastState.compose env38689 (packedSelected [0,1,4,7,8,12,15,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound38689 : packedSelected [0,1,4,7,8,12,15,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38690 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8313,114,13340,10361,1025,8312,17509,112,17,29711,8193,64,2048,5221,4176,31757,20485,21589,116,21588,5236,30300]

theorem envBound38690 : H12AffineFastState.Bounded env38690 := by
  intro p hp
  have h : env38690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38689_38690 : H12AffineEnvironment.transform 15 114 env38689 = env38690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env38689 == env38690) = true)

theorem identity38690 : scanCanonicalize (H12AffineFastState.compose env38690 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound38690 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env38691 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8313,114,13340,10361,1025,8312,4113,112,17,8315,8193,64,2048,5221,4176,10361,1137,33,116,32,5236,8744]

theorem envBound38691 : H12AffineFastState.Bounded env38691 := by
  intro p hp
  have h : env38691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38690_38691 : H12AffineEnvironment.transform 13 5236 env38690 = env38691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env38690 == env38691) = true)

theorem identity38691 : scanCanonicalize (H12AffineFastState.compose env38691 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38691 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env38692 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,8192,4160,8313,114,12328,10361,53,8312,4113,112,17,8315,8193,64,2048,4177,4176,10361,69,33,116,32,4160,8744]

theorem envBound38692 : H12AffineFastState.Bounded env38692 := by
  intro p hp
  have h : env38692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38691_38692 : H12AffineEnvironment.transform 9 52 env38691 = env38692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38691 == env38692) = true)

theorem identity38692 : scanCanonicalize (H12AffineFastState.compose env38692 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound38692 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38693 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,120,4160,1,114,4176,2049,53,0,4113,112,17,3,121,64,2048,4177,4176,2049,69,33,116,32,4160,592]

theorem envBound38693 : H12AffineFastState.Bounded env38693 := by
  intro p hp
  have h : env38693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38692_38693 : H12AffineEnvironment.transform 12 120 env38692 = env38693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env38692 == env38693) = true)

theorem identity38693 : scanCanonicalize (H12AffineFastState.compose env38693 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38693 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env38694 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,4096,120,4160,1,114,4176,1,53,0,4113,112,17,3,121,64,0,4177,4176,1,69,33,116,32,4160,592]

theorem envBound38694 : H12AffineFastState.Bounded env38694 := by
  intro p hp
  have h : env38694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38693_38694 : H12AffineEnvironment.transform 10 0 env38693 = env38694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38693 == env38694) = true)

theorem identity38694 : scanCanonicalize (H12AffineFastState.compose env38694 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound38694 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38695 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,64,120,0,1,114,16,1,53,0,81,112,17,3,121,64,0,17,16,1,69,33,116,32,0,592]

theorem envBound38695 : H12AffineFastState.Bounded env38695 := by
  intro p hp
  have h : env38695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38694_38695 : H12AffineEnvironment.transform 11 64 env38694 = env38695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env38694 == env38695) = true)

theorem identity38695 : scanCanonicalize (H12AffineFastState.compose env38695 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38695 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38696 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,17,41,0,1,35,16,1,53,0,0,33,17,3,40,17,0,17,16,1,20,33,37,32,0,513]

theorem envBound38696 : H12AffineFastState.Bounded env38696 := by
  intro p hp
  have h : env38696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38695_38696 : H12AffineEnvironment.transform 5 17 env38695 = env38696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38695 == env38696) = true)

theorem identity38696 : scanCanonicalize (H12AffineFastState.compose env38696 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38696 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38697 : List Nat := [2,4,2,16,32,17,3,36,512,52,0,17,35,0,1,35,16,1,53,0,0,33,17,3,34,17,0,17,16,1,20,33,37,32,0,513]

theorem envBound38697 : H12AffineFastState.Bounded env38697 := by
  intro p hp
  have h : env38697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38696_38697 : H12AffineEnvironment.transform 2 2 env38696 = env38697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38696 == env38697) = true)

def env38698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169352,95496,8328,64,2049,163977,45525,284040,156816,411972,257,21793,46212,213831]

theorem envBound38698 : H12AffineFastState.Bounded env38698 := by
  intro p hp
  have h : env38698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38671_38698 : H12AffineEnvironment.transform 21 272513 env38671 = env38698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38671 == env38698) = true)

def env38699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169216,95496,8192,64,2049,163841,45405,283904,156696,411972,257,21793,46092,213831]

theorem envBound38699 : H12AffineFastState.Bounded env38699 := by
  intro p hp
  have h : env38699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38698_38699 : H12AffineEnvironment.transform 6 8 env38698 = env38699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38698 == env38699) = true)

def env38700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,16,95496,8192,64,2049,5393,45405,283904,61704,318548,257,21793,46092,120407]

theorem envBound38700 : H12AffineFastState.Bounded env38700 := by
  intro p hp
  have h : env38700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38699_38700 : H12AffineEnvironment.transform 16 38160 env38699 = env38700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env38699 == env38700) = true)

def env38701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,12572,272393,16,95496,8192,64,2049,5393,25693,283904,9224,264532,257,21793,24844,66391]

theorem envBound38701 : H12AffineFastState.Bounded env38701 := by
  intro p hp
  have h : env38701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38700_38701 : H12AffineEnvironment.transform 14 21760 env38700 = env38701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env38700 == env38701) = true)

theorem identity38701 : scanCanonicalize (H12AffineFastState.compose env38701 (packedSelected [1,4,8,9,12,14,16,19,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound38701 : packedSelected [1,4,8,9,12,14,16,19,38] rootPS < 2^1333 := by decide +kernel

def env38702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16400,32040,1025,21761,12572,21793,16,95496,8192,64,2049,5393,25693,10280,9224,29820,257,21793,24844,66391]

theorem envBound38702 : H12AffineFastState.Bounded env38702 := by
  intro p hp
  have h : env38702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38701_38702 : H12AffineEnvironment.transform 17 32040 env38701 = env38702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env38701 == env38702) = true)

theorem identity38702 : scanCanonicalize (H12AffineFastState.compose env38702 (packedSelected [4,5,9,12,14,15,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound38702 : packedSelected [4,5,9,12,14,15,16,24,26] rootPS < 2^1333 := by decide +kernel

def env38703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8283,16400,32040,1025,21761,12572,21793,16,21843,8192,64,2049,5393,25693,10280,9224,29820,257,21793,24844,8972]

theorem envBound38703 : H12AffineFastState.Bounded env38703 := by
  intro p hp
  have h : env38703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38702_38703 : H12AffineEnvironment.transform 15 8283 env38702 = env38703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env38702 == env38703) = true)

theorem identity38703 : scanCanonicalize (H12AffineFastState.compose env38703 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound38703 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env38704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8461,8283,13341,2341,1025,8460,12572,8492,16,8542,8192,64,2049,5393,4176,10280,9224,113,257,8492,5377,8972]

theorem envBound38704 : H12AffineFastState.Bounded env38704 := by
  intro p hp
  have h : env38704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38703_38704 : H12AffineEnvironment.transform 13 13325 env38703 = env38704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env38703 == env38704) = true)

theorem identity38704 : scanCanonicalize (H12AffineFastState.compose env38704 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38704 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env38705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,1,343,5393,2341,1025,0,4112,32,16,82,268,64,2049,5393,4176,2340,1284,113,257,32,5377,512]

theorem envBound38705 : H12AffineFastState.Bounded env38705 := by
  intro p hp
  have h : env38705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38704_38705 : H12AffineEnvironment.transform 12 268 env38704 = env38705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38704 == env38705) = true)

theorem identity38705 : scanCanonicalize (H12AffineFastState.compose env38705 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38706 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,268,5377,1,343,5393,2308,1025,0,4112,1,16,82,268,64,2049,5393,4176,2309,1284,80,257,1,5377,512]

theorem envBound38706 : H12AffineFastState.Bounded env38706 := by
  intro p hp
  have h : env38706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38705_38706 : H12AffineEnvironment.transform 4 1 env38705 = env38706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38705 == env38706) = true)

theorem identity38706 : scanCanonicalize (H12AffineFastState.compose env38706 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38706 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38707 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,4096,268,4112,1,343,4096,2308,272,0,4112,1,16,82,268,64,2049,4096,4176,2309,21,80,257,1,4112,512]

theorem envBound38707 : H12AffineFastState.Bounded env38707 := by
  intro p hp
  have h : env38707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38706_38707 : H12AffineEnvironment.transform 9 273 env38706 = env38707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38706 == env38707) = true)

def env38708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,12573,272393,16,95496,8192,64,2049,5393,25692,283904,9225,264533,257,21793,24845,66390]

theorem envBound38708 : H12AffineFastState.Bounded env38708 := by
  intro p hp
  have h : env38708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38700_38708 : H12AffineEnvironment.transform 14 21761 env38700 = env38708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env38700 == env38708) = true)

theorem identity38708 : scanCanonicalize (H12AffineFastState.compose env38708 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound38708 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,16401,262144,1025,21760,12573,272393,16,29791,8192,64,2049,5393,25692,283904,9225,264533,257,21793,24845,513]

theorem envBound38709 : H12AffineFastState.Bounded env38709 := by
  intro p hp
  have h : env38709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38708_38709 : H12AffineEnvironment.transform 15 343 env38708 = env38709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env38708 == env38709) = true)

theorem identity38709 : scanCanonicalize (H12AffineFastState.compose env38709 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound38709 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,16401,23669,1025,21760,12573,29820,16,29791,8192,64,2049,5393,25692,2421,9225,21792,257,21793,24845,513]

theorem envBound38710 : H12AffineFastState.Bounded env38710 := by
  intro p hp
  have h : env38710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38709_38710 : H12AffineEnvironment.transform 17 23669 env38709 = env38710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env38709 == env38710) = true)

theorem identity38710 : scanCanonicalize (H12AffineFastState.compose env38710 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38710 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16401,23669,1025,21760,4160,21793,16,21762,349,64,2049,5393,17665,2421,1364,21792,257,21793,16464,513]

theorem envBound38711 : H12AffineFastState.Bounded env38711 := by
  intro p hp
  have h : env38711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38710_38711 : H12AffineEnvironment.transform 12 349 env38710 = env38711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38710 == env38711) = true)

theorem identity38711 : scanCanonicalize (H12AffineFastState.compose env38711 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound38711 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,343,5441,2341,1025,80,4160,113,16,82,349,64,2049,5393,4177,2421,1364,112,257,113,5376,513]

theorem envBound38712 : H12AffineFastState.Bounded env38712 := by
  intro p hp
  have h : env38712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38711_38712 : H12AffineEnvironment.transform 13 5456 env38711 = env38712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env38711 == env38712) = true)

theorem identity38712 : scanCanonicalize (H12AffineFastState.compose env38712 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound38712 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,367,4096,349,5456,81,343,5441,74,1025,80,4160,113,16,82,349,64,366,5393,4177,26,1364,112,257,113,5376,513]

theorem envBound38713 : H12AffineFastState.Bounded env38713 := by
  intro p hp
  have h : env38713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38712_38713 : H12AffineEnvironment.transform 10 367 env38712 = env38713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env38712 == env38713) = true)

theorem identity38713 : scanCanonicalize (H12AffineFastState.compose env38713 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 367) := by decide +kernel

theorem selectedBound38713 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,367,367,349,1087,81,343,1070,74,1025,80,303,113,16,82,349,64,366,1150,318,26,1364,112,257,113,1135,513]

theorem envBound38714 : H12AffineFastState.Bounded env38714 := by
  intro p hp
  have h : env38714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38713_38714 : H12AffineEnvironment.transform 11 367 env38713 = env38714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 367 env38713 == env38714) = true)

theorem identity38714 : scanCanonicalize (H12AffineFastState.compose env38714 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 330) := by decide +kernel

theorem selectedBound38714 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env38715 : List Nat := [2,4,8,16,32,64,8,256,512,330,367,367,349,373,81,343,356,74,331,80,303,113,16,82,349,64,366,308,318,26,30,112,257,113,293,513]

theorem envBound38715 : H12AffineFastState.Bounded env38715 := by
  intro p hp
  have h : env38715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38714_38715 : H12AffineEnvironment.transform 9 330 env38714 = env38715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 330 env38714 == env38715) = true)

theorem identity38715 : scanCanonicalize (H12AffineFastState.compose env38715 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound38715 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38716 : List Nat := [2,4,8,16,32,64,8,256,356,330,367,367,349,373,81,343,356,74,331,80,303,113,16,82,349,64,366,308,318,26,30,112,257,113,293,357]

theorem envBound38716 : H12AffineFastState.Bounded env38716 := by
  intro p hp
  have h : env38716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38715_38716 : H12AffineEnvironment.transform 8 356 env38715 = env38716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env38715 == env38716) = true)

theorem identity38716 : scanCanonicalize (H12AffineFastState.compose env38716 (packedSelected [1,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38716 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env38717 : List Nat := [2,4,8,0,32,64,8,256,356,330,367,367,333,357,65,327,356,74,331,64,303,97,0,66,333,64,366,292,302,10,14,96,257,97,293,357]

theorem envBound38717 : H12AffineFastState.Bounded env38717 := by
  intro p hp
  have h : env38717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38716_38717 : H12AffineEnvironment.transform 3 0 env38716 = env38717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38716 == env38717) = true)

theorem identity38717 : scanCanonicalize (H12AffineFastState.compose env38717 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound38717 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38718 : List Nat := [2,4,8,0,32,64,8,14,106,68,97,97,67,107,65,73,106,74,69,64,33,97,0,66,67,64,96,42,32,10,14,96,15,97,43,107]

theorem envBound38718 : H12AffineFastState.Bounded env38718 := by
  intro p hp
  have h : env38718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38717_38718 : H12AffineEnvironment.transform 7 14 env38717 = env38718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env38717 == env38718) = true)

theorem identity38718 : scanCanonicalize (H12AffineFastState.compose env38718 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound38718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38719 : List Nat := [2,4,8,0,32,14,8,14,36,10,47,47,13,37,15,7,36,4,11,14,33,47,0,12,13,14,46,42,32,10,14,46,15,47,43,37]

theorem envBound38719 : H12AffineFastState.Bounded env38719 := by
  intro p hp
  have h : env38719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38718_38719 : H12AffineEnvironment.transform 5 14 env38718 = env38719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env38718 == env38719) = true)

theorem identity38719 : scanCanonicalize (H12AffineFastState.compose env38719 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound38719 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env38720 : List Nat := [2,4,8,0,8,14,8,14,12,10,7,7,13,13,15,7,12,4,11,14,9,7,0,12,13,14,6,2,8,10,14,6,15,7,3,13]

theorem envBound38720 : H12AffineFastState.Bounded env38720 := by
  intro p hp
  have h : env38720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38719_38720 : H12AffineEnvironment.transform 4 8 env38719 = env38720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env38719 == env38720) = true)

theorem identity38720 : scanCanonicalize (H12AffineFastState.compose env38720 (packedSelected [1,11] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38720 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env38721 : List Nat := [2,4,1,0,1,7,1,7,5,3,7,7,4,4,6,7,5,4,2,7,0,7,0,5,4,7,6,2,1,3,7,6,6,7,3,4]

theorem envBound38721 : H12AffineFastState.Bounded env38721 := by
  intro p hp
  have h : env38721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38720_38721 : H12AffineEnvironment.transform 2 1 env38720 = env38721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38720 == env38721) = true)

def env38722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,17,95496,8192,64,2049,5392,45405,283904,61705,318549,257,21793,46092,120406]

theorem envBound38722 : H12AffineFastState.Bounded env38722 := by
  intro p hp
  have h : env38722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38699_38722 : H12AffineEnvironment.transform 16 38161 env38699 = env38722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env38699 == env38722) = true)

theorem identity38722 : scanCanonicalize (H12AffineFastState.compose env38722 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38722 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,58397,33,17,95496,8192,64,2049,5392,45405,32040,61705,62589,257,21793,46092,120406]

theorem envBound38723 : H12AffineFastState.Bounded env38723 := by
  intro p hp
  have h : env38723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38722_38723 : H12AffineEnvironment.transform 17 10280 env38722 = env38723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38722 == env38723) = true)

theorem identity38723 : scanCanonicalize (H12AffineFastState.compose env38723 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38723 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,38161,2421,1025,32769,50496,33,17,87125,349,64,2049,5392,36864,23669,53332,54560,257,21793,38225,120406]

theorem envBound38724 : H12AffineFastState.Bounded env38724 := by
  intro p hp
  have h : env38724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38723_38724 : H12AffineEnvironment.transform 12 349 env38723 = env38724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38723 == env38724) = true)

theorem identity38724 : scanCanonicalize (H12AffineFastState.compose env38724 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound38724 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env38725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33111,38161,2421,1025,32769,50496,33,17,54530,349,64,2049,5392,36864,23669,53332,54560,257,21793,38225,22273]

theorem envBound38725 : H12AffineFastState.Bounded env38725 := by
  intro p hp
  have h : env38725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38724_38725 : H12AffineEnvironment.transform 15 33111 env38724 = env38725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env38724 == env38725) = true)

theorem identity38725 : scanCanonicalize (H12AffineFastState.compose env38725 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38725 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,5392,2421,1025,0,17729,33,17,21763,349,64,2049,5392,4097,23669,20565,21793,257,21793,5456,22273]

theorem envBound38726 : H12AffineFastState.Bounded env38726 := by
  intro p hp
  have h : env38726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38725_38726 : H12AffineEnvironment.transform 14 1 env38725 = env38726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38725 == env38726) = true)

theorem identity38726 : scanCanonicalize (H12AffineFastState.compose env38726 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38726 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38727 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,1,114,5172,2129,1025,0,17509,33,17,21543,121,64,2049,5172,4097,23669,20565,21509,37,21509,5236,22053]

theorem envBound38727 : H12AffineFastState.Bounded env38727 := by
  intro p hp
  have h : env38727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38726_38727 : H12AffineEnvironment.transform 7 36 env38726 = env38727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38726 == env38727) = true)

theorem identity38727 : scanCanonicalize (H12AffineFastState.compose env38727 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound38727 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env38728 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,121,16384,1,114,65,2129,1025,0,17509,33,17,16466,121,64,2049,65,1140,18432,17440,16496,37,16496,1,16976]

theorem envBound38728 : H12AffineFastState.Bounded env38728 := by
  intro p hp
  have h : env38728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38727_38728 : H12AffineEnvironment.transform 11 1141 env38727 = env38728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env38727 == env38728) = true)

theorem identity38728 : scanCanonicalize (H12AffineFastState.compose env38728 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound38728 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38729 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,121,81,1,114,65,2129,1025,0,1076,33,17,3,121,64,2049,65,1140,2129,1137,33,37,33,1,513]

theorem envBound38729 : H12AffineFastState.Bounded env38729 := by
  intro p hp
  have h : env38729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38728_38729 : H12AffineEnvironment.transform 13 81 env38728 = env38729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env38728 == env38729) = true)

theorem identity38729 : scanCanonicalize (H12AffineFastState.compose env38729 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1599) := by decide +kernel

theorem selectedBound38729 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38730 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1599,1141,121,81,1,114,65,1646,1025,0,1076,33,17,3,121,64,1598,65,1140,1646,1137,33,37,33,1,513]

theorem envBound38730 : H12AffineFastState.Bounded env38730 := by
  intro p hp
  have h : env38730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38729_38730 : H12AffineEnvironment.transform 10 1599 env38729 = env38730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1599 env38729 == env38730) = true)

theorem identity38730 : scanCanonicalize (H12AffineFastState.compose env38730 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound38730 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38731 : List Nat := [2,4,8,16,32,64,8,36,512,20,555,97,121,81,1,114,65,634,21,0,32,33,17,3,121,64,554,65,96,634,101,33,37,33,1,513]

theorem envBound38731 : H12AffineFastState.Bounded env38731 := by
  intro p hp
  have h : env38731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38730_38731 : H12AffineEnvironment.transform 9 20 env38730 = env38731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38730 == env38731) = true)

theorem identity38731 : scanCanonicalize (H12AffineFastState.compose env38731 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38731 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38732 : List Nat := [2,4,8,16,32,16,8,36,512,20,555,49,41,1,1,34,17,554,21,0,32,33,17,3,41,16,554,17,48,554,53,33,37,33,1,513]

theorem envBound38732 : H12AffineFastState.Bounded env38732 := by
  intro p hp
  have h : env38732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38731_38732 : H12AffineEnvironment.transform 5 16 env38731 = env38732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38731 == env38732) = true)

theorem identity38732 : scanCanonicalize (H12AffineFastState.compose env38732 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound38732 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38733 : List Nat := [2,4,8,5,32,5,8,36,512,1,555,36,41,1,1,34,4,554,0,0,32,33,4,3,41,5,554,4,37,554,32,33,37,33,1,513]

theorem envBound38733 : H12AffineFastState.Bounded env38733 := by
  intro p hp
  have h : env38733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38732_38733 : H12AffineEnvironment.transform 3 5 env38732 = env38733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env38732 == env38733) = true)

def env38734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272392,169217,95496,8193,64,2049,163840,45404,283905,156697,411972,257,21793,46093,213831]

theorem envBound38734 : H12AffineFastState.Bounded env38734 := by
  intro p hp
  have h : env38734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38698_38734 : H12AffineEnvironment.transform 6 9 env38698 = env38734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38698 == env38734) = true)

def env38735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,17,95496,8193,64,2049,5392,45404,283905,61705,318548,257,21793,46093,120407]

theorem envBound38735 : H12AffineFastState.Bounded env38735 := by
  intro p hp
  have h : env38735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38734_38735 : H12AffineEnvironment.transform 16 38160 env38734 = env38735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env38734 == env38735) = true)

theorem identity38735 : scanCanonicalize (H12AffineFastState.compose env38735 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound38735 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35189,1025,32769,58396,41341,17,95496,8193,64,2049,5392,45404,56436,61705,21793,257,21793,46093,120407]

theorem envBound38736 : H12AffineFastState.Bounded env38736 := by
  intro p hp
  have h : env38736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38735_38736 : H12AffineEnvironment.transform 17 35189 env38735 = env38736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env38735 == env38736) = true)

theorem identity38736 : scanCanonicalize (H12AffineFastState.compose env38736 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound38736 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env38737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,65536,5220,2049,1025,373,25960,8201,17,95496,8193,64,2049,5392,12328,23808,28797,21793,257,21793,13689,87843]

theorem envBound38737 : H12AffineFastState.Bounded env38737 := by
  intro p hp
  have h : env38737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38736_38737 : H12AffineEnvironment.transform 14 372 env38736 = env38737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env38736 == env38737) = true)

theorem identity38737 : scanCanonicalize (H12AffineFastState.compose env38737 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound38737 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,21794,5220,2049,1025,373,25960,8201,17,8234,8193,64,2049,5392,12328,23808,28797,21793,257,21793,13689,513]

theorem envBound38738 : H12AffineFastState.Bounded env38738 := by
  intro p hp
  have h : env38738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38737_38738 : H12AffineEnvironment.transform 15 21794 env38737 = env38738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env38737 == env38738) = true)

theorem identity38738 : scanCanonicalize (H12AffineFastState.compose env38738 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound38738 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env38739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,372,1331,5220,2049,1025,373,13689,8201,17,8234,8193,64,2049,5392,12328,3345,8300,1328,257,1328,13689,513]

theorem envBound38739 : H12AffineFastState.Bounded env38739 := by
  intro p hp
  have h : env38739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38738_38739 : H12AffineEnvironment.transform 13 4113 env38738 = env38739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env38738 == env38739) = true)

theorem identity38739 : scanCanonicalize (H12AffineFastState.compose env38739 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound38739 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38740 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4113,372,343,4096,2049,101,373,12573,8201,17,8234,8193,64,2049,4468,12328,2421,8300,340,257,340,12573,513]

theorem envBound38740 : H12AffineFastState.Bounded env38740 := by
  intro p hp
  have h : env38740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38739_38740 : H12AffineEnvironment.transform 9 100 env38739 = env38740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env38739 == env38740) = true)

theorem identity38740 : scanCanonicalize (H12AffineFastState.compose env38740 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38740 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env38741 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,268,4113,372,343,4096,2049,101,373,4113,261,17,294,269,64,2049,4468,4388,2421,352,340,257,340,4113,513]

theorem envBound38741 : H12AffineFastState.Bounded env38741 := by
  intro p hp
  have h : env38741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38740_38741 : H12AffineEnvironment.transform 12 268 env38740 = env38741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38740 == env38741) = true)

theorem identity38741 : scanCanonicalize (H12AffineFastState.compose env38741 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38741 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38742 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,268,4113,293,262,4096,2049,52,292,4113,261,17,294,269,17,2049,4389,4388,2340,305,261,257,261,4113,513]

theorem envBound38742 : H12AffineFastState.Bounded env38742 := by
  intro p hp
  have h : env38742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38741_38742 : H12AffineEnvironment.transform 5 17 env38741 = env38742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38741 == env38742) = true)

theorem identity38742 : scanCanonicalize (H12AffineFastState.compose env38742 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38743 : List Nat := [2,4,8,16,17,17,9,256,512,4,2048,4096,268,4113,276,262,4096,2049,5,277,4113,261,17,279,269,17,2049,4372,4373,2325,256,261,257,261,4113,513]

theorem envBound38743 : H12AffineFastState.Bounded env38743 := by
  intro p hp
  have h : env38743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38742_38743 : H12AffineEnvironment.transform 4 17 env38742 = env38743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38742 == env38743) = true)

theorem identity38743 : scanCanonicalize (H12AffineFastState.compose env38743 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 262) := by decide +kernel

theorem selectedBound38743 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38744 : List Nat := [2,4,8,16,17,17,9,256,512,4,262,4096,268,4113,276,262,4096,263,5,277,4113,261,17,279,269,17,263,4372,4373,19,256,261,257,261,4113,513]

theorem envBound38744 : H12AffineFastState.Bounded env38744 := by
  intro p hp
  have h : env38744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38743_38744 : H12AffineEnvironment.transform 10 262 env38743 = env38744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 262 env38743 == env38744) = true)

theorem identity38744 : scanCanonicalize (H12AffineFastState.compose env38744 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound38744 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38745 : List Nat := [2,4,8,16,17,17,9,256,18,4,262,4096,268,4113,276,262,4096,263,5,277,4113,261,17,279,269,17,263,4372,4373,19,256,261,257,261,4113,19]

theorem envBound38745 : H12AffineFastState.Bounded env38745 := by
  intro p hp
  have h : env38745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38744_38745 : H12AffineEnvironment.transform 8 18 env38744 = env38745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env38744 == env38745) = true)

theorem identity38745 : scanCanonicalize (H12AffineFastState.compose env38745 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound38745 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env38746 : List Nat := [2,4,8,16,17,17,9,30,18,4,24,4096,18,4113,10,24,4096,25,5,11,4113,27,17,9,19,17,25,4106,4107,19,30,27,31,27,4113,19]

theorem envBound38746 : H12AffineFastState.Bounded env38746 := by
  intro p hp
  have h : env38746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38745_38746 : H12AffineEnvironment.transform 7 30 env38745 = env38746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env38745 == env38746) = true)

theorem identity38746 : scanCanonicalize (H12AffineFastState.compose env38746 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38746 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env38747 : List Nat := [2,4,8,10,11,11,9,4,8,4,2,4096,8,4107,10,2,4096,3,5,11,4107,1,11,9,9,11,3,4106,4107,9,4,1,5,1,4107,9]

theorem envBound38747 : H12AffineFastState.Bounded env38747 := by
  intro p hp
  have h : env38747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38746_38747 : H12AffineEnvironment.transform 3 10 env38746 = env38747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38746 == env38747) = true)

theorem identity38747 : scanCanonicalize (H12AffineFastState.compose env38747 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38747 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env38748 : List Nat := [2,3,8,10,11,11,9,3,8,3,2,4096,8,4107,10,2,4096,3,2,11,4107,1,11,9,9,11,3,4106,4107,9,3,1,2,1,4107,9]

theorem envBound38748 : H12AffineFastState.Bounded env38748 := by
  intro p hp
  have h : env38748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38747_38748 : H12AffineEnvironment.transform 1 3 env38747 = env38748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38747 == env38748) = true)

theorem identity38748 : scanCanonicalize (H12AffineFastState.compose env38748 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38748 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env38749 : List Nat := [2,3,1,3,2,2,0,3,1,3,2,4096,1,4098,3,2,4096,3,2,2,4098,1,2,0,0,2,3,4099,4098,0,3,1,2,1,4098,0]

theorem envBound38749 : H12AffineFastState.Bounded env38749 := by
  intro p hp
  have h : env38749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38748_38749 : H12AffineEnvironment.transform 2 1 env38748 = env38749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38748 == env38749) = true)

theorem identity38749 : scanCanonicalize (H12AffineFastState.compose env38749 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound38749 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38750 : List Nat := [2,3,1,3,2,2,0,3,1,3,2,1,1,3,3,2,1,3,2,2,3,1,2,0,0,2,3,2,3,0,3,1,2,1,3,0]

theorem envBound38750 : H12AffineFastState.Bounded env38750 := by
  intro p hp
  have h : env38750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38749_38750 : H12AffineEnvironment.transform 11 1 env38749 = env38750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env38749 == env38750) = true)

theorem identity38750 : scanCanonicalize (H12AffineFastState.compose env38750 (packedSelected [19] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38750 : packedSelected [19] rootPS < 2^1333 := by decide +kernel

def env38751 : List Nat := [0,1,1,1,0,0,0,1,1,1,0,1,1,1,1,0,1,1,0,0,1,1,0,0,0,0,1,0,1,0,1,1,0,1,1,0]

theorem envBound38751 : H12AffineFastState.Bounded env38751 := by
  intro p hp
  have h : env38751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38750_38751 : H12AffineEnvironment.transform 0 0 env38750 = env38751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38750 == env38751) = true)

def env38752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,16,95496,8193,64,2049,5393,45404,283905,61704,318549,257,21793,46093,120406]

theorem envBound38752 : H12AffineFastState.Bounded env38752 := by
  intro p hp
  have h : env38752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38734_38752 : H12AffineEnvironment.transform 16 38161 env38734 = env38752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env38734 == env38752) = true)

theorem identity38752 : scanCanonicalize (H12AffineFastState.compose env38752 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38752 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,13389,262144,1025,8541,17729,272392,16,95496,8193,64,2049,5393,4096,283905,20564,294153,257,21793,5457,96010]

theorem envBound38753 : H12AffineFastState.Bounded env38753 := by
  intro p hp
  have h : env38753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38752_38753 : H12AffineEnvironment.transform 14 8540 env38752 = env38753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38752 == env38753) = true)

theorem identity38753 : scanCanonicalize (H12AffineFastState.compose env38753 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound38753 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env38754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,13389,67618,1025,8541,17729,73770,16,95496,8193,64,2049,5393,4096,89379,20564,95531,257,21793,5457,96010]

theorem envBound38754 : H12AffineFastState.Bounded env38754 := by
  intro p hp
  have h : env38754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38753_38754 : H12AffineEnvironment.transform 17 67618 env38753 = env38754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env38753 == env38754) = true)

theorem identity38754 : scanCanonicalize (H12AffineFastState.compose env38754 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38754 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,65536,5393,67618,1025,1,17729,65910,16,87124,349,64,2049,5393,4096,89379,20564,87159,257,21793,5457,87638]

theorem envBound38755 : H12AffineFastState.Bounded env38755 := by
  intro p hp
  have h : env38755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38754_38755 : H12AffineEnvironment.transform 12 348 env38754 = env38755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38754 == env38755) = true)

theorem identity38755 : scanCanonicalize (H12AffineFastState.compose env38755 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound38755 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21795,5393,23809,1025,1,17729,21589,16,375,349,64,2049,5393,4096,2048,20564,340,257,21793,5457,885]

theorem envBound38756 : H12AffineFastState.Bounded env38756 := by
  intro p hp
  have h : env38756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38755_38756 : H12AffineEnvironment.transform 15 21795 env38755 = env38756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env38755 == env38756) = true)

theorem identity38756 : scanCanonicalize (H12AffineFastState.compose env38756 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38756 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env38757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,35,5393,2049,1025,1,4161,341,16,375,349,64,2049,5393,4096,2048,1364,340,257,33,5457,885]

theorem envBound38757 : H12AffineFastState.Bounded env38757 := by
  intro p hp
  have h : env38757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38756_38757 : H12AffineEnvironment.transform 13 5376 env38756 = env38757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38756 == env38757) = true)

theorem identity38757 : scanCanonicalize (H12AffineFastState.compose env38757 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38757 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38758 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5156,0,35,5173,2049,1025,1,4161,113,16,83,121,64,2049,5173,4096,2048,1136,112,37,33,5237,593]

theorem envBound38758 : H12AffineFastState.Bounded env38758 := by
  intro p hp
  have h : env38758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38757_38758 : H12AffineEnvironment.transform 7 36 env38757 = env38758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38757 == env38758) = true)

theorem identity38758 : scanCanonicalize (H12AffineFastState.compose env38758 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound38758 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env38759 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2112,120,3172,0,35,3189,2049,1025,1,2049,113,16,83,121,64,2049,3189,2112,2048,1136,112,37,33,3125,593]

theorem envBound38759 : H12AffineFastState.Bounded env38759 := by
  intro p hp
  have h : env38759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38758_38759 : H12AffineEnvironment.transform 11 2112 env38758 = env38759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env38758 == env38759) = true)

theorem identity38759 : scanCanonicalize (H12AffineFastState.compose env38759 (packedSelected [2,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38759 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env38760 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,2112,120,2129,0,35,2112,2049,52,1,2049,113,16,83,121,64,2049,2112,2112,2048,69,112,37,33,2048,593]

theorem envBound38760 : H12AffineFastState.Bounded env38760 := by
  intro p hp
  have h : env38760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38759_38760 : H12AffineEnvironment.transform 9 53 env38759 = env38760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38759 == env38760) = true)

theorem identity38760 : scanCanonicalize (H12AffineFastState.compose env38760 (packedSelected [2,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38760 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env38761 : List Nat := [2,4,8,16,32,64,9,36,0,53,2048,2112,120,2129,0,35,2112,2049,52,1,2049,113,16,83,121,64,2049,2112,2112,2048,69,112,37,33,2048,81]

theorem envBound38761 : H12AffineFastState.Bounded env38761 := by
  intro p hp
  have h : env38761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38760_38761 : H12AffineEnvironment.transform 8 0 env38760 = env38761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38760 == env38761) = true)

theorem identity38761 : scanCanonicalize (H12AffineFastState.compose env38761 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38761 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env38762 : List Nat := [2,4,8,16,32,17,9,36,0,53,2048,2065,41,2048,0,35,2065,2049,52,1,2049,32,16,2,40,17,2049,2065,2065,2048,20,33,37,33,2048,0]

theorem envBound38762 : H12AffineFastState.Bounded env38762 := by
  intro p hp
  have h : env38762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38761_38762 : H12AffineEnvironment.transform 5 17 env38761 = env38762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38761 == env38762) = true)

theorem identity38762 : scanCanonicalize (H12AffineFastState.compose env38762 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38762 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38763 : List Nat := [2,4,8,16,32,17,9,36,0,53,0,17,41,0,0,35,17,1,52,1,1,32,16,2,40,17,1,17,17,0,20,33,37,33,0,0]

theorem envBound38763 : H12AffineFastState.Bounded env38763 := by
  intro p hp
  have h : env38763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38762_38763 : H12AffineEnvironment.transform 10 0 env38762 = env38763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38762 == env38763) = true)

theorem identity38763 : scanCanonicalize (H12AffineFastState.compose env38763 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound38763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38764 : List Nat := [2,4,8,16,30,17,9,26,0,11,0,17,23,0,0,29,17,1,10,1,1,30,16,2,22,17,1,17,17,0,20,31,27,31,0,0]

theorem envBound38764 : H12AffineFastState.Bounded env38764 := by
  intro p hp
  have h : env38764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38763_38764 : H12AffineEnvironment.transform 4 30 env38763 = env38764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env38763 == env38764) = true)

theorem identity38764 : scanCanonicalize (H12AffineFastState.compose env38764 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38764 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38765 : List Nat := [2,4,8,0,14,1,9,10,0,11,0,1,7,0,0,13,1,1,10,1,1,14,0,2,6,1,1,1,1,0,4,15,11,15,0,0]

theorem envBound38765 : H12AffineFastState.Bounded env38765 := by
  intro p hp
  have h : env38765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38764_38765 : H12AffineEnvironment.transform 3 0 env38764 = env38765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38764 == env38765) = true)

theorem identity38765 : scanCanonicalize (H12AffineFastState.compose env38765 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound38765 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38766 : List Nat := [2,4,6,0,0,1,7,4,0,5,0,1,7,0,0,3,1,1,4,1,1,0,0,2,6,1,1,1,1,0,4,1,5,1,0,0]

theorem envBound38766 : H12AffineFastState.Bounded env38766 := by
  intro p hp
  have h : env38766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38765_38766 : H12AffineEnvironment.transform 2 6 env38765 = env38766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env38765 == env38766) = true)

def env38767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169353,95497,8328,64,4464768,163976,45524,284041,156816,4350404,257,21793,46212,213831]

theorem envBound38767 : H12AffineFastState.Bounded env38767 := by
  intro p hp
  have h : env38767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38670_38767 : H12AffineEnvironment.transform 22 169353 env38670 = env38767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env38670 == env38767) = true)

def env38768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169353,95497,8328,64,2048,163976,45524,284041,156816,411972,257,21793,46212,213831]

theorem envBound38768 : H12AffineFastState.Bounded env38768 := by
  intro p hp
  have h : env38768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38767_38768 : H12AffineEnvironment.transform 21 272512 env38767 = env38768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38767 == env38768) = true)

theorem identity38768 : scanCanonicalize (H12AffineFastState.compose env38768 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound38768 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272512,62661,95497,8328,64,2048,57796,45524,284041,1500,272392,257,21793,46212,74251]

theorem envBound38769 : H12AffineFastState.Bounded env38769 := by
  intro p hp
  have h : env38769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38768_38769 : H12AffineEnvironment.transform 16 24908 env38768 = env38769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env38768 == env38769) = true)

theorem identity38769 : scanCanonicalize (H12AffineFastState.compose env38769 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38769 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,4160,272512,62661,21763,8328,64,2048,57796,45524,284041,1500,272392,257,21793,46212,513]

theorem envBound38770 : H12AffineFastState.Bounded env38770 := by
  intro p hp
  have h : env38770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38769_38770 : H12AffineEnvironment.transform 15 8202 env38769 = env38770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38769 == env38770) = true)

theorem identity38770 : scanCanonicalize (H12AffineFastState.compose env38770 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound38770 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env38771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,23668,1025,32769,4160,29940,62661,21763,8328,64,2048,57796,45524,2557,1500,29820,257,21793,46212,513]

theorem envBound38771 : H12AffineFastState.Bounded env38771 := by
  intro p hp
  have h : env38771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38770_38771 : H12AffineEnvironment.transform 17 23668 env38770 = env38771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env38770 == env38771) = true)

theorem identity38771 : scanCanonicalize (H12AffineFastState.compose env38771 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound38771 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env38772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8202,24908,23668,1025,21896,4160,29940,8524,21763,8328,64,2048,13389,25693,2557,1500,29820,257,21793,24845,513]

theorem envBound38772 : H12AffineFastState.Bounded env38772 := by
  intro p hp
  have h : env38772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38771_38772 : H12AffineEnvironment.transform 14 21897 env38771 = env38772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env38771 == env38772) = true)

theorem identity38772 : scanCanonicalize (H12AffineFastState.compose env38772 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound38772 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env38773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8541,8202,5528,10400,1025,8540,4160,32,8524,8663,8328,64,2048,13389,4233,2557,1500,168,257,8693,5593,513]

theorem envBound38773 : H12AffineFastState.Bounded env38773 := by
  intro p hp
  have h : env38773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38772_38773 : H12AffineEnvironment.transform 13 13524 env38772 = env38773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env38772 == env38773) = true)

theorem identity38773 : scanCanonicalize (H12AffineFastState.compose env38773 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38773 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,1,342,5528,2556,1025,0,4160,32,16,139,468,64,2048,5393,4233,2557,1500,168,257,169,5593,513]

theorem envBound38774 : H12AffineFastState.Bounded env38774 := by
  intro p hp
  have h : env38774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38773_38774 : H12AffineEnvironment.transform 12 348 env38773 = env38774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38773 == env38774) = true)

theorem identity38774 : scanCanonicalize (H12AffineFastState.compose env38774 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound38774 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38775 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,5456,1,342,5440,2340,1025,0,4160,32,16,83,268,64,2048,5393,4177,2341,1284,112,257,113,5377,513]

theorem envBound38775 : H12AffineFastState.Bounded env38775 := by
  intro p hp
  have h : env38775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38774_38775 : H12AffineEnvironment.transform 6 88 env38774 = env38775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env38774 == env38775) = true)

theorem identity38775 : scanCanonicalize (H12AffineFastState.compose env38775 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1857) := by decide +kernel

theorem selectedBound38775 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38776 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1857,348,529,1,342,513,2340,1025,0,1793,32,16,83,268,64,2048,592,1808,2341,1284,112,257,113,576,513]

theorem envBound38776 : H12AffineFastState.Bounded env38776 := by
  intro p hp
  have h : env38776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38775_38776 : H12AffineEnvironment.transform 11 1857 env38775 = env38776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1857 env38775 == env38776) = true)

theorem identity38776 : scanCanonicalize (H12AffineFastState.compose env38776 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 885) := by decide +kernel

theorem selectedBound38776 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38777 : List Nat := [2,4,8,16,32,64,88,256,512,1024,885,1857,348,529,1,342,513,593,1025,0,1793,32,16,83,268,64,885,592,1808,592,1284,112,257,113,576,513]

theorem envBound38777 : H12AffineFastState.Bounded env38777 := by
  intro p hp
  have h : env38777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38776_38777 : H12AffineEnvironment.transform 10 885 env38776 = env38777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 885 env38776 == env38777) = true)

theorem identity38777 : scanCanonicalize (H12AffineFastState.compose env38777 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound38777 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38778 : List Nat := [2,4,8,16,32,64,88,256,512,257,885,576,348,529,1,342,513,593,256,0,512,32,16,83,268,64,885,592,529,592,5,112,257,113,576,513]

theorem envBound38778 : H12AffineFastState.Bounded env38778 := by
  intro p hp
  have h : env38778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38777_38778 : H12AffineEnvironment.transform 9 257 env38777 = env38778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env38777 == env38778) = true)

theorem identity38778 : scanCanonicalize (H12AffineFastState.compose env38778 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound38778 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env38779 : List Nat := [2,4,8,16,32,64,88,116,512,117,513,576,40,529,1,34,513,593,116,0,512,32,16,83,120,64,513,592,529,592,5,112,117,113,576,513]

theorem envBound38779 : H12AffineFastState.Bounded env38779 := by
  intro p hp
  have h : env38779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38778_38779 : H12AffineEnvironment.transform 7 116 env38778 = env38779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env38778 == env38779) = true)

def env38780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169353,95497,8328,64,2049,163976,45524,284041,156816,411973,257,21793,46212,213831]

theorem envBound38780 : H12AffineFastState.Bounded env38780 := by
  intro p hp
  have h : env38780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38767_38780 : H12AffineEnvironment.transform 21 272513 env38767 = env38780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38767 == env38780) = true)

theorem identity38780 : scanCanonicalize (H12AffineFastState.compose env38780 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound38780 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160012,272513,155997,95497,8328,64,2049,160860,17664,284041,156816,411973,257,21793,16464,213831]

theorem envBound38781 : H12AffineFastState.Bounded env38781 := by
  intro p hp
  have h : env38781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38780_38781 : H12AffineEnvironment.transform 14 29908 env38780 = env38781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env38780 == env38781) = true)

theorem identity38781 : scanCanonicalize (H12AffineFastState.compose env38781 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound38781 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env38782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149860,1025,29909,160012,156133,155997,95497,8328,64,2049,160860,17664,138477,156816,33,257,21793,16464,213831]

theorem envBound38782 : H12AffineFastState.Bounded env38782 := by
  intro p hp
  have h : env38782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38781_38782 : H12AffineEnvironment.transform 17 149860 env38781 = env38782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env38781 == env38782) = true)

def env38783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149860,1025,29789,160012,156013,155997,95497,8192,64,2049,160860,17664,138341,156696,33,257,21793,16464,213831]

theorem envBound38783 : H12AffineFastState.Bounded env38783 := by
  intro p hp
  have h : env38783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38782_38783 : H12AffineEnvironment.transform 6 8 env38782 = env38783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38782 == env38783) = true)

theorem identity38783 : scanCanonicalize (H12AffineFastState.compose env38783 (packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound38783 : packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env38784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,131072,149860,1025,29789,160012,156013,155997,8543,8192,64,2049,160860,17664,138341,156696,33,257,21793,16464,136977]

theorem envBound38784 : H12AffineFastState.Bounded env38784 := by
  intro p hp
  have h : env38784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38783_38784 : H12AffineEnvironment.transform 15 21590 env38783 = env38784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env38783 == env38784) = true)

theorem identity38784 : scanCanonicalize (H12AffineFastState.compose env38784 (packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 16448) := by decide +kernel

theorem selectedBound38784 : packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env38785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,16448,2340,1025,29789,12620,8493,8477,8543,8192,64,2049,13340,17664,23589,9304,33,257,21793,16464,22353]

theorem envBound38785 : H12AffineFastState.Bounded env38785 := by
  intro p hp
  have h : env38785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38784_38785 : H12AffineEnvironment.transform 16 16448 env38784 = env38785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env38784 == env38785) = true)

theorem identity38785 : scanCanonicalize (H12AffineFastState.compose env38785 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38785 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env38786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,21590,16448,2340,1025,21840,4161,32,16,82,269,64,2049,5393,17664,23589,1365,33,257,21793,16464,22353]

theorem envBound38786 : H12AffineFastState.Bounded env38786 := by
  intro p hp
  have h : env38786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38785_38786 : H12AffineEnvironment.transform 12 269 env38785 = env38786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38785 == env38786) = true)

theorem identity38786 : scanCanonicalize (H12AffineFastState.compose env38786 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38786 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env38787 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,269,16384,20545,20806,16448,2340,273,20544,4161,32,16,82,269,64,2049,4097,16400,22837,69,33,257,20529,16464,21057]

theorem envBound38787 : H12AffineFastState.Bounded env38787 := by
  intro p hp
  have h : env38787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38786_38787 : H12AffineEnvironment.transform 9 272 env38786 = env38787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38786 == env38787) = true)

theorem identity38787 : scanCanonicalize (H12AffineFastState.compose env38787 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38787 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38788 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,269,16384,20496,20759,16401,2340,273,20497,4112,32,16,3,269,17,2049,4097,16400,22837,20,33,257,20529,16385,21008]

theorem envBound38788 : H12AffineFastState.Bounded env38788 := by
  intro p hp
  have h : env38788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38787_38788 : H12AffineEnvironment.transform 5 17 env38787 = env38788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38787 == env38788) = true)

theorem identity38788 : scanCanonicalize (H12AffineFastState.compose env38788 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound38788 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38789 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,309,269,16384,16677,16418,16401,2340,273,16676,293,32,16,3,269,17,2049,308,16400,18432,20,33,257,16644,16385,17189]

theorem envBound38789 : H12AffineFastState.Bounded env38789 := by
  intro p hp
  have h : env38789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38788_38789 : H12AffineEnvironment.transform 11 309 env38788 = env38789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env38788 == env38789) = true)

theorem identity38789 : scanCanonicalize (H12AffineFastState.compose env38789 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound38789 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38790 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,309,269,293,0,263,308,2340,273,1,293,32,16,3,269,17,2049,308,309,2341,20,33,257,33,292,512]

theorem envBound38790 : H12AffineFastState.Bounded env38790 := by
  intro p hp
  have h : env38790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38789_38790 : H12AffineEnvironment.transform 13 293 env38789 = env38790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env38789 == env38790) = true)

theorem identity38790 : scanCanonicalize (H12AffineFastState.compose env38790 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38790 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38791 : List Nat := [2,4,8,0,32,1,8,256,512,256,2048,293,269,293,0,263,292,2340,257,1,293,32,0,3,269,1,2049,292,293,2341,4,33,257,33,292,512]

theorem envBound38791 : H12AffineFastState.Bounded env38791 := by
  intro p hp
  have h : env38791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38790_38791 : H12AffineEnvironment.transform 3 0 env38790 = env38791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38790 == env38791) = true)

theorem identity38791 : scanCanonicalize (H12AffineFastState.compose env38791 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 769) := by decide +kernel

theorem selectedBound38791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38792 : List Nat := [2,4,8,0,32,1,8,256,512,256,769,293,269,293,0,263,292,549,257,1,293,32,0,3,269,1,768,292,293,548,4,33,257,33,292,512]

theorem envBound38792 : H12AffineFastState.Bounded env38792 := by
  intro p hp
  have h : env38792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38791_38792 : H12AffineEnvironment.transform 10 769 env38791 = env38792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 769 env38791 == env38792) = true)

theorem identity38792 : scanCanonicalize (H12AffineFastState.compose env38792 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound38792 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38793 : List Nat := [2,4,8,0,32,1,8,256,260,256,5,293,269,293,0,263,292,289,257,1,293,32,0,3,269,1,4,292,293,288,4,33,257,33,292,260]

theorem envBound38793 : H12AffineFastState.Bounded env38793 := by
  intro p hp
  have h : env38793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38792_38793 : H12AffineEnvironment.transform 8 260 env38792 = env38793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env38792 == env38793) = true)

theorem identity38793 : scanCanonicalize (H12AffineFastState.compose env38793 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38793 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38794 : List Nat := [2,4,8,0,32,1,8,37,33,37,5,0,40,0,0,34,1,4,36,1,0,32,0,3,40,1,4,1,0,5,4,33,36,33,1,33]

theorem envBound38794 : H12AffineFastState.Bounded env38794 := by
  intro p hp
  have h : env38794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38793_38794 : H12AffineEnvironment.transform 7 37 env38793 = env38794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38793 == env38794) = true)

theorem identity38794 : scanCanonicalize (H12AffineFastState.compose env38794 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

end H12CloudChart1