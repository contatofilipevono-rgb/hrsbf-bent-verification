import H12CloudChart1Data053

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env13554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,65536,5392,2420,1025,0,69911,33,65862,65876,349,64,67927,70726,4096,67618,66563,65910,257,32,5457,513]

theorem envBound13554 : H12AffineFastState.Bounded env13554 := by
  intro p hp
  have h : env13554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13553_13554 : H12AffineEnvironment.transform 13 5377 env13553 = env13554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13553 == env13554) = true)

theorem identity13554 : scanCanonicalize (H12AffineFastState.compose env13554 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound13554 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5392,2420,1025,0,4160,33,17,3,349,64,2048,5393,4096,2421,1364,33,257,32,5457,513]

theorem envBound13555 : H12AffineFastState.Bounded env13555 := by
  intro p hp
  have h : env13555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13554_13555 : H12AffineEnvironment.transform 15 343 env13554 = env13555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env13554 == env13555) = true)

theorem identity13555 : scanCanonicalize (H12AffineFastState.compose env13555 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2414) := by decide +kernel

theorem selectedBound13555 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2414,348,3183,1,343,3198,2420,1025,0,2350,33,17,3,349,64,2048,3199,2414,2421,1364,33,257,32,3135,513]

theorem envBound13556 : H12AffineFastState.Bounded env13556 := by
  intro p hp
  have h : env13556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13555_13556 : H12AffineEnvironment.transform 11 2414 env13555 = env13556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2414 env13555 == env13556) = true)

theorem identity13556 : scanCanonicalize (H12AffineFastState.compose env13556 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound13556 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13557 : List Nat := [2,4,8,16,32,64,9,256,512,266,2048,2414,348,2405,1,343,2420,2420,267,0,2350,33,17,3,349,64,2048,2421,2414,2421,94,33,257,32,2357,513]

theorem envBound13557 : H12AffineFastState.Bounded env13557 := by
  intro p hp
  have h : env13557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13556_13557 : H12AffineEnvironment.transform 9 266 env13556 = env13557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env13556 == env13557) = true)

theorem identity13557 : scanCanonicalize (H12AffineFastState.compose env13557 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13557 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13558 : List Nat := [2,4,8,16,1,64,9,256,512,266,2048,2383,348,2372,1,343,2389,2389,267,0,2319,0,17,3,349,64,2048,2388,2383,2388,94,0,257,1,2324,513]

theorem envBound13558 : H12AffineFastState.Bounded env13558 := by
  intro p hp
  have h : env13558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13557_13558 : H12AffineEnvironment.transform 4 1 env13557 = env13558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13557 == env13558) = true)

theorem identity13558 : scanCanonicalize (H12AffineFastState.compose env13558 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13558 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13559 : List Nat := [2,4,8,16,1,16,9,256,512,266,2048,2335,268,2324,1,263,2309,2309,267,0,2319,0,17,3,269,16,2048,2308,2335,2308,14,0,257,1,2324,513]

theorem envBound13559 : H12AffineFastState.Bounded env13559 := by
  intro p hp
  have h : env13559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13558_13559 : H12AffineEnvironment.transform 5 16 env13558 = env13559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13558 == env13559) = true)

theorem identity13559 : scanCanonicalize (H12AffineFastState.compose env13559 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound13559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13560 : List Nat := [2,4,8,16,1,16,9,15,512,5,2048,2064,3,2075,1,8,2058,2058,4,0,2048,0,17,3,2,16,2048,2059,2064,2059,14,0,14,1,2075,513]

theorem envBound13560 : H12AffineFastState.Bounded env13560 := by
  intro p hp
  have h : env13560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13559_13560 : H12AffineEnvironment.transform 7 15 env13559 = env13560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env13559 == env13560) = true)

theorem identity13560 : scanCanonicalize (H12AffineFastState.compose env13560 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound13560 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13561 : List Nat := [2,4,8,16,1,16,9,15,16,5,2048,2064,3,2075,1,8,2058,2058,4,0,2048,0,17,3,2,16,2048,2059,2064,2059,14,0,14,1,2075,17]

theorem envBound13561 : H12AffineFastState.Bounded env13561 := by
  intro p hp
  have h : env13561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13560_13561 : H12AffineEnvironment.transform 8 16 env13560 = env13561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env13560 == env13561) = true)

theorem identity13561 : scanCanonicalize (H12AffineFastState.compose env13561 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound13561 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13562 : List Nat := [2,4,8,16,1,16,9,15,16,5,27,11,3,0,1,8,17,17,4,0,27,0,17,3,2,16,27,16,11,16,14,0,14,1,0,17]

theorem envBound13562 : H12AffineFastState.Bounded env13562 := by
  intro p hp
  have h : env13562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13561_13562 : H12AffineEnvironment.transform 10 27 env13561 = env13562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env13561 == env13562) = true)

theorem identity13562 : scanCanonicalize (H12AffineFastState.compose env13562 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13562 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13563 : List Nat := [2,2,8,16,1,16,9,9,16,3,27,11,3,0,1,8,17,17,2,0,27,0,17,3,2,16,27,16,11,16,8,0,8,1,0,17]

theorem envBound13563 : H12AffineFastState.Bounded env13563 := by
  intro p hp
  have h : env13563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13562_13563 : H12AffineEnvironment.transform 1 2 env13562 = env13563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13562 == env13563) = true)

theorem identity13563 : scanCanonicalize (H12AffineFastState.compose env13563 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13563 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env13564 : List Nat := [2,2,8,10,1,10,9,9,10,3,1,11,3,0,1,8,11,11,2,0,1,0,11,3,2,10,1,10,11,10,8,0,8,1,0,11]

theorem envBound13564 : H12AffineFastState.Bounded env13564 := by
  intro p hp
  have h : env13564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13563_13564 : H12AffineEnvironment.transform 3 10 env13563 = env13564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13563 == env13564) = true)

theorem identity13564 : scanCanonicalize (H12AffineFastState.compose env13564 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound13564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13565 : List Nat := [2,2,1,3,1,3,0,0,3,3,1,2,3,0,1,1,2,2,2,0,1,0,2,3,2,3,1,3,2,3,1,0,1,1,0,2]

theorem envBound13565 : H12AffineFastState.Bounded env13565 := by
  intro p hp
  have h : env13565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13564_13565 : H12AffineEnvironment.transform 2 1 env13564 = env13565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env13564 == env13565) = true)

def env13566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,77899,32,73754,98645,8193,64,121943,79130,17665,89378,75103,119927,257,21793,46092,513]

theorem envBound13566 : H12AffineFastState.Bounded env13566 := by
  intro p hp
  have h : env13566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13550_13566 : H12AffineEnvironment.transform 17 10281 env13550 = env13566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13550 == env13566) = true)

theorem identity13566 : scanCanonicalize (H12AffineFastState.compose env13566 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13566 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1025,32769,4161,32,16,41311,8193,64,64605,5392,17665,32040,1365,62589,257,21793,46092,513]

theorem envBound13567 : H12AffineFastState.Bounded env13567 := by
  intro p hp
  have h : env13567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13566_13567 : H12AffineEnvironment.transform 15 8202 env13566 = env13567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13566 == env13567) = true)

theorem identity13567 : scanCanonicalize (H12AffineFastState.compose env13567 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound13567 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,32768,3142,38161,1125,1025,32769,4161,32,16,36115,3149,64,53265,5392,17665,20836,1365,55345,257,21793,38976,513]

theorem envBound13568 : H12AffineFastState.Bounded env13568 := by
  intro p hp
  have h : env13568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13567_13568 : H12AffineEnvironment.transform 12 3148 env13567 = env13568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env13567 == env13568) = true)

theorem identity13568 : scanCanonicalize (H12AffineFastState.compose env13568 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound13568 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,21760,3142,16401,1125,1025,21761,4161,32,16,22547,3149,64,1297,5392,17665,20836,1365,3377,257,21793,19776,513]

theorem envBound13569 : H12AffineFastState.Bounded env13569 := by
  intro p hp
  have h : env13569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13568_13569 : H12AffineEnvironment.transform 14 21760 env13568 = env13569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env13568 == env13569) = true)

theorem identity13569 : scanCanonicalize (H12AffineFastState.compose env13569 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound13569 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,16384,21760,343,16401,1125,1025,21761,4161,32,16,21762,348,64,1297,5392,17665,20836,1365,32,257,21793,16465,513]

theorem envBound13570 : H12AffineFastState.Bounded env13570 := by
  intro p hp
  have h : env13570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13569_13570 : H12AffineEnvironment.transform 10 1297 env13569 = env13570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env13569 == env13570) = true)

theorem identity13570 : scanCanonicalize (H12AffineFastState.compose env13570 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound13570 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,4096,349,4405,1077,343,4388,1125,1025,1076,4161,32,16,1079,348,64,1297,5392,5172,81,1365,32,257,1044,4452,513]

theorem envBound13571 : H12AffineFastState.Bounded env13571 := by
  intro p hp
  have h : env13571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13570_13571 : H12AffineEnvironment.transform 13 4405 env13570 = env13571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env13570 == env13571) = true)

theorem identity13571 : scanCanonicalize (H12AffineFastState.compose env13571 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13571 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env13572 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1124,4096,40,4160,1077,34,4177,1125,1025,1076,4161,32,16,1079,41,64,1124,5221,5172,81,1056,32,116,1044,4113,513]

theorem envBound13572 : H12AffineFastState.Bounded env13572 := by
  intro p hp
  have h : env13572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13571_13572 : H12AffineEnvironment.transform 7 117 env13571 = env13572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13571 == env13572) = true)

theorem identity13572 : scanCanonicalize (H12AffineFastState.compose env13572 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13572 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env13573 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,4096,40,4113,1077,34,4096,1076,1025,1076,4112,32,16,1079,41,17,1077,5172,5172,0,1056,32,37,1044,4113,513]

theorem envBound13573 : H12AffineFastState.Bounded env13573 := by
  intro p hp
  have h : env13573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13572_13573 : H12AffineEnvironment.transform 5 17 env13572 = env13573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13572 == env13573) = true)

theorem identity13573 : scanCanonicalize (H12AffineFastState.compose env13573 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13574 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,4096,40,4113,1,34,4096,0,53,0,4112,32,16,3,41,17,1,4096,4096,0,20,32,37,32,4113,513]

theorem envBound13574 : H12AffineFastState.Bounded env13574 := by
  intro p hp
  have h : env13574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13573_13574 : H12AffineEnvironment.transform 9 52 env13573 = env13574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13573 == env13574) = true)

theorem identity13574 : scanCanonicalize (H12AffineFastState.compose env13574 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13575 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,40,0,1,34,17,0,53,0,1,32,16,3,41,17,1,17,17,0,20,32,37,32,0,513]

theorem envBound13575 : H12AffineFastState.Bounded env13575 := by
  intro p hp
  have h : env13575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13574_13575 : H12AffineEnvironment.transform 11 17 env13574 = env13575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13574 == env13575) = true)

theorem identity13575 : scanCanonicalize (H12AffineFastState.compose env13575 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13575 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13576 : List Nat := [2,4,8,16,11,17,9,15,512,31,1,17,3,0,1,9,17,0,30,0,1,11,16,3,2,17,1,17,17,0,20,11,14,11,0,513]

theorem envBound13576 : H12AffineFastState.Bounded env13576 := by
  intro p hp
  have h : env13576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13575_13576 : H12AffineEnvironment.transform 4 11 env13575 = env13576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13575 == env13576) = true)

def env13577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157597,2098513,17665,2377024,2102685,2411677,257,21793,46213,2175562]

theorem envBound13577 : H12AffineFastState.Bounded env13577 := by
  intro p hp
  have h : env13577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13540_13577 : H12AffineEnvironment.transform 21 272513 env13540 = env13577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13540 == env13577) = true)

theorem identity13577 : scanCanonicalize (H12AffineFastState.compose env13577 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13577 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,2097152,272513,2101329,41431,8328,64,2157597,2098513,17665,2377024,2102685,2411677,257,21793,46213,2101825]

theorem envBound13578 : H12AffineFastState.Bounded env13578 := by
  intro p hp
  have h : env13578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13577_13578 : H12AffineEnvironment.transform 15 8203 env13577 = env13578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13577 == env13578) = true)

def env13579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,2097152,272393,2101329,41311,8192,64,2157597,2098513,17665,2377024,2102549,2411541,257,21793,46093,2101825]

theorem envBound13579 : H12AffineFastState.Bounded env13579 := by
  intro p hp
  have h : env13579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13578_13579 : H12AffineEnvironment.transform 6 8 env13578 = env13579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13578 == env13579) = true)

theorem identity13579 : scanCanonicalize (H12AffineFastState.compose env13579 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301364) := by decide +kernel

theorem selectedBound13579 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env13580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,301364,272393,297317,41311,8192,64,292137,302181,17665,56436,298017,21793,257,21793,46093,297845]

theorem envBound13580 : H12AffineFastState.Bounded env13580 := by
  intro p hp
  have h : env13580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13579_13580 : H12AffineEnvironment.transform 20 301364 env13579 = env13580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301364 env13579 == env13580) = true)

theorem identity13580 : scanCanonicalize (H12AffineFastState.compose env13580 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13580 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,35,38161,262144,1025,32769,301364,264225,297317,33143,40,64,283905,302181,17665,56436,298017,21793,257,21793,37925,297845]

theorem envBound13581 : H12AffineFastState.Bounded env13581 := by
  intro p hp
  have h : env13581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13580_13581 : H12AffineEnvironment.transform 12 40 env13580 = env13581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13580 == env13581) = true)

theorem identity13581 : scanCanonicalize (H12AffineFastState.compose env13581 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound13581 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env13582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21760,35,16401,262144,1025,21761,281652,264225,285797,21623,40,64,283905,280933,17665,2420,284961,21793,257,21793,16677,286325]

theorem envBound13582 : H12AffineFastState.Bounded env13582 := by
  intro p hp
  have h : env13582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13581_13582 : H12AffineEnvironment.transform 14 21760 env13581 = env13582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env13581 == env13582) = true)

theorem identity13582 : scanCanonicalize (H12AffineFastState.compose env13582 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound13582 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env13583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21760,35,16401,23669,1025,21761,4161,21588,16,21623,40,64,2420,5392,17665,2420,1364,21793,257,21793,16677,512]

theorem envBound13583 : H12AffineFastState.Bounded env13583 := by
  intro p hp
  have h : env13583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13582_13583 : H12AffineEnvironment.transform 17 23669 env13582 = env13583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env13582 == env13583) = true)

theorem identity13583 : scanCanonicalize (H12AffineFastState.compose env13583 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound13583 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5125,261,35,5140,2160,1025,260,4161,81,16,114,40,64,2420,5392,4356,2420,1364,292,257,292,5408,512]

theorem envBound13584 : H12AffineFastState.Bounded env13584 := by
  intro p hp
  have h : env13584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13583_13584 : H12AffineEnvironment.transform 13 5125 env13583 = env13584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env13583 == env13584) = true)

theorem identity13584 : scanCanonicalize (H12AffineFastState.compose env13584 (packedSelected [6,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13584 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env13585 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,40,5125,32,35,5140,2160,1025,33,4161,81,16,114,40,64,2129,5173,4129,2129,1137,1,36,1,5125,512]

theorem envBound13585 : H12AffineFastState.Bounded env13585 := by
  intro p hp
  have h : env13585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13584_13585 : H12AffineEnvironment.transform 7 37 env13584 = env13585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13584 == env13585) = true)

theorem identity13585 : scanCanonicalize (H12AffineFastState.compose env13585 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound13585 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env13586 : List Nat := [2,4,8,16,32,64,8,37,512,1024,576,4096,40,5125,32,35,5140,560,1025,33,4161,81,16,114,40,64,529,5173,4129,529,1137,1,36,1,5125,512]

theorem envBound13586 : H12AffineFastState.Bounded env13586 := by
  intro p hp
  have h : env13586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13585_13586 : H12AffineEnvironment.transform 10 576 env13585 = env13586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env13585 == env13586) = true)

theorem identity13586 : scanCanonicalize (H12AffineFastState.compose env13586 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound13586 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13587 : List Nat := [2,4,8,16,32,64,8,37,512,5,576,4096,40,4096,32,35,4113,560,4,33,4161,81,16,114,40,64,529,4144,4129,529,116,1,36,1,4096,512]

theorem envBound13587 : H12AffineFastState.Bounded env13587 := by
  intro p hp
  have h : env13587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13586_13587 : H12AffineEnvironment.transform 9 5 env13586 = env13587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env13586 == env13587) = true)

theorem identity13587 : scanCanonicalize (H12AffineFastState.compose env13587 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 112) := by decide +kernel

theorem selectedBound13587 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env13588 : List Nat := [2,4,8,16,32,64,8,37,512,5,576,112,40,112,32,35,97,560,4,33,49,81,16,114,40,64,529,64,81,529,116,1,36,1,112,512]

theorem envBound13588 : H12AffineFastState.Bounded env13588 := by
  intro p hp
  have h : env13588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13587_13588 : H12AffineEnvironment.transform 11 112 env13587 = env13588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 112 env13587 == env13588) = true)

theorem identity13588 : scanCanonicalize (H12AffineFastState.compose env13588 (packedSelected [3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound13588 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env13589 : List Nat := [2,4,8,16,32,64,8,37,81,5,17,112,40,112,32,35,97,97,4,33,49,81,16,114,40,64,64,64,81,64,116,1,36,1,112,81]

theorem envBound13589 : H12AffineFastState.Bounded env13589 := by
  intro p hp
  have h : env13589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13588_13589 : H12AffineEnvironment.transform 8 81 env13588 = env13589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env13588 == env13589) = true)

def env13590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,2097152,272392,2101329,41310,8193,64,2157597,2098513,17665,2377024,2102548,2411540,257,21793,46092,2101825]

theorem envBound13590 : H12AffineFastState.Bounded env13590 := by
  intro p hp
  have h : env13590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13578_13590 : H12AffineEnvironment.transform 6 9 env13578 = env13590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13578 == env13590) = true)

theorem identity13590 : scanCanonicalize (H12AffineFastState.compose env13590 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276585) := by decide +kernel

theorem selectedBound13590 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env13591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,276585,272392,272440,41310,8193,64,316532,277816,17665,32041,273789,62589,257,21793,46092,272936]

theorem envBound13591 : H12AffineFastState.Bounded env13591 := by
  intro p hp
  have h : env13591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13590_13591 : H12AffineEnvironment.transform 20 276585 env13590 = env13591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276585 env13590 == env13591) = true)

def env13592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound13592 : H12AffineFastState.Bounded env13592 := by
  intro p hp
  have h : env13592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12742_13592 : H12AffineEnvironment.transform 25 65 env12742 = env13592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env12742 == env13592) = true)

def env13593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound13593 : H12AffineFastState.Bounded env13593 := by
  intro p hp
  have h : env13593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13592_13593 : H12AffineEnvironment.transform 26 30393344 env13592 = env13593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env13592 == env13593) = true)

def env13594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound13594 : H12AffineFastState.Bounded env13594 := by
  intro p hp
  have h : env13594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13593_13594 : H12AffineEnvironment.transform 18 1024 env13593 = env13594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13593 == env13594) = true)

theorem identity13594 : scanCanonicalize (H12AffineFastState.compose env13594 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898592) := by decide +kernel

theorem selectedBound13594 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898592,8328,65,4196384,10898604,10507601,8830976,412721,15117793,256,2493580,2551080,486374]

theorem envBound13595 : H12AffineFastState.Bounded env13595 := by
  intro p hp
  have h : env13595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13594_13595 : H12AffineEnvironment.transform 23 8898592 env13594 = env13595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898592 env13594 == env13595) = true)

def env13596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,8388608,8898592,8328,65,4196384,8393984,8785149,8830976,412721,12645453,256,21792,46212,486374]

theorem envBound13596 : H12AffineFastState.Bounded env13596 := by
  intro p hp
  have h : env13596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13595_13596 : H12AffineEnvironment.transform 20 416172 env13595 = env13596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416172 env13595 == env13596) = true)

def env13597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441640,95496,8328,65,4196384,436264,45525,32040,412721,4606309,256,21792,46212,486374]

theorem envBound13597 : H12AffineFastState.Bounded env13597 := by
  intro p hp
  have h : env13597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13596_13597 : H12AffineEnvironment.transform 22 441640 env13596 = env13597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env13596 == env13597) = true)

def env13598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441640,95496,8328,65,270496,436264,45525,32040,412721,156133,256,21792,46212,486374]

theorem envBound13598 : H12AffineFastState.Bounded env13598 := by
  intro p hp
  have h : env13598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13597_13598 : H12AffineEnvironment.transform 21 272512 env13597 = env13598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13597 == env13598) = true)

theorem identity13598 : scanCanonicalize (H12AffineFastState.compose env13598 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound13598 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,77899,213351,120015,95496,8328,65,215367,115151,45525,32040,75222,156133,256,21792,46212,513]

theorem envBound13599 : H12AffineFastState.Bounded env13599 := by
  intro p hp
  have h : env13599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13598_13599 : H12AffineEnvironment.transform 17 223719 env13598 = env13599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env13598 == env13599) = true)

def env13600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77899,213351,119879,95496,8192,65,215367,115015,45405,32040,75102,156013,256,21792,46092,513]

theorem envBound13600 : H12AffineFastState.Bounded env13600 := by
  intro p hp
  have h : env13600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13599_13600 : H12AffineEnvironment.transform 6 8 env13599 = env13600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13599 == env13600) = true)

theorem identity13600 : scanCanonicalize (H12AffineFastState.compose env13600 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound13600 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,2421,1024,32769,77899,8573,119879,95496,8192,65,10589,115015,45405,32040,75102,65911,256,21792,46092,513]

theorem envBound13601 : H12AffineFastState.Bounded env13601 := by
  intro p hp
  have h : env13601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13600_13601 : H12AffineEnvironment.transform 16 90138 env13600 = env13601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env13600 == env13601) = true)

theorem identity13601 : scanCanonicalize (H12AffineFastState.compose env13601 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound13601 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env13602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,90138,2421,1024,29708,77899,8573,73802,95496,8192,65,10589,79178,17744,32040,75102,65911,256,21792,16385,513]

theorem envBound13602 : H12AffineFastState.Bounded env13602 := by
  intro p hp
  have h : env13602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13601_13602 : H12AffineEnvironment.transform 14 29709 env13601 = env13602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env13601 == env13602) = true)

theorem identity13602 : scanCanonicalize (H12AffineFastState.compose env13602 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound13602 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,29962,5392,2421,1024,29708,17729,8573,21824,2,8192,65,10589,16448,17744,32040,20564,29821,256,21792,16385,513]

theorem envBound13603 : H12AffineFastState.Bounded env13603 := by
  intro p hp
  have h : env13603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13602_13603 : H12AffineEnvironment.transform 15 29962 env13602 = env13603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env13602 == env13603) = true)

theorem identity13603 : scanCanonicalize (H12AffineFastState.compose env13603 (packedSelected [2,3,5,6,10,12,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound13603 : packedSelected [2,3,5,6,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env13604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,373,114,5392,2421,1024,372,12345,8573,8248,2,8192,65,10589,13624,12328,2128,9516,261,256,8280,13689,513]

theorem envBound13604 : H12AffineFastState.Bounded env13604 := by
  intro p hp
  have h : env13604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13603_13604 : H12AffineEnvironment.transform 13 13688 env13603 = env13604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env13603 == env13604) = true)

theorem identity13604 : scanCanonicalize (H12AffineFastState.compose env13604 (packedSelected [2,3,5,6,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound13604 : packedSelected [2,3,5,6,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env13605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4405,373,114,5392,2421,1024,372,5236,1328,1141,2,1101,65,3344,4469,5221,2128,353,261,256,1045,4404,513]

theorem envBound13605 : H12AffineFastState.Bounded env13605 := by
  intro p hp
  have h : env13605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13604_13605 : H12AffineEnvironment.transform 12 1101 env13604 = env13605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env13604 == env13605) = true)

theorem identity13605 : scanCanonicalize (H12AffineFastState.compose env13605 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13605 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env13606 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,4405,292,35,5392,2340,1024,293,5157,1328,1060,2,1052,16,3344,4388,5172,2049,304,261,256,1045,4404,513]

theorem envBound13606 : H12AffineFastState.Bounded env13606 := by
  intro p hp
  have h : env13606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13605_13606 : H12AffineEnvironment.transform 5 17 env13605 = env13606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13605 == env13606) = true)

theorem identity13606 : scanCanonicalize (H12AffineFastState.compose env13606 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13606 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env13607 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,41,4405,292,35,4389,2340,53,293,4112,261,17,2,41,16,2341,4388,4097,2049,304,261,256,32,4404,513]

theorem envBound13607 : H12AffineFastState.Bounded env13607 := by
  intro p hp
  have h : env13607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13606_13607 : H12AffineEnvironment.transform 9 53 env13606 = env13607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13606 == env13607) = true)

def env13608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213351,119878,95496,8193,65,215367,115014,45404,32040,75103,156012,256,21792,46093,513]

theorem envBound13608 : H12AffineFastState.Bounded env13608 := by
  intro p hp
  have h : env13608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13599_13608 : H12AffineEnvironment.transform 6 9 env13599 = env13608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13599 == env13608) = true)

theorem identity13608 : scanCanonicalize (H12AffineFastState.compose env13608 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound13608 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env13609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,77899,33,119878,95496,8193,65,2049,115014,45404,32040,75103,73770,256,21792,46093,513]

theorem envBound13609 : H12AffineFastState.Bounded env13609 := by
  intro p hp
  have h : env13609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13608_13609 : H12AffineEnvironment.transform 16 82246 env13608 = env13609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env13608 == env13609) = true)

theorem identity13609 : scanCanonicalize (H12AffineFastState.compose env13609 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound13609 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env13610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,5393,10280,1024,32769,25628,33,32785,8543,8193,65,2049,38161,45404,32040,28936,29821,256,21792,46093,513]

theorem envBound13610 : H12AffineFastState.Bounded env13610 := by
  intro p hp
  have h : env13610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13609_13610 : H12AffineEnvironment.transform 15 21591 env13609 = env13610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env13609 == env13610) = true)

theorem identity13610 : scanCanonicalize (H12AffineFastState.compose env13610 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13610 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env13611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21591,5393,10280,1024,1,25628,33,17,8543,8193,65,2049,5393,12636,32040,28936,29821,256,21792,13325,513]

theorem envBound13611 : H12AffineFastState.Bounded env13611 := by
  intro p hp
  have h : env13611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13610_13611 : H12AffineEnvironment.transform 14 0 env13610 = env13611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13610 == env13611) = true)

theorem identity13611 : scanCanonicalize (H12AffineFastState.compose env13611 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13611 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,0,21591,5393,2340,1024,1,17680,33,17,83,269,65,2049,5393,4176,23588,20484,21873,256,21792,5377,513]

theorem envBound13612 : H12AffineFastState.Bounded env13612 := by
  intro p hp
  have h : env13612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13611_13612 : H12AffineEnvironment.transform 12 268 env13611 = env13612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13611 == env13612) = true)

theorem identity13612 : scanCanonicalize (H12AffineFastState.compose env13612 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13612 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,343,5393,2340,1024,1,4112,33,17,83,269,65,2049,5393,4176,2340,1284,113,256,32,5377,513]

theorem envBound13613 : H12AffineFastState.Bounded env13613 := by
  intro p hp
  have h : env13613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13612_13613 : H12AffineEnvironment.transform 13 5376 env13612 = env13613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13612 == env13613) = true)

def env13614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441640,95496,8328,65,270497,436264,45525,32040,412721,156132,256,21792,46212,486374]

theorem envBound13614 : H12AffineFastState.Bounded env13614 := by
  intro p hp
  have h : env13614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13597_13614 : H12AffineEnvironment.transform 21 272513 env13597 = env13614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13597 == env13614) = true)

theorem identity13614 : scanCanonicalize (H12AffineFastState.compose env13614 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound13614 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,416172,272513,441640,41431,8328,65,270497,436264,45525,32040,412721,156132,256,21792,46212,442169]

theorem envBound13615 : H12AffineFastState.Bounded env13615 := by
  intro p hp
  have h : env13615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13614_13615 : H12AffineEnvironment.transform 15 54495 env13614 = env13615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env13614 == env13615) = true)

def env13616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416036,272393,441640,41311,8192,65,270377,436264,45405,32040,412721,156012,256,21792,46092,442169]

theorem envBound13616 : H12AffineFastState.Bounded env13616 := by
  intro p hp
  have h : env13616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13615_13616 : H12AffineEnvironment.transform 6 8 env13615 = env13616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13615 == env13616) = true)

theorem identity13616 : scanCanonicalize (H12AffineFastState.compose env13616 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13616 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env13617 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,415825,272393,441437,41002,8192,65,270377,436264,45096,31837,412721,155673,117,21589,46092,441932]

theorem envBound13617 : H12AffineFastState.Bounded env13617 := by
  intro p hp
  have h : env13617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13616_13617 : H12AffineEnvironment.transform 7 117 env13616 = env13617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13616 == env13617) = true)

theorem identity13617 : scanCanonicalize (H12AffineFastState.compose env13617 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 34816) := by decide +kernel

theorem selectedBound13617 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env13618 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,131072,34816,1024,32769,184401,40969,144477,41002,8192,65,43049,139304,45096,31837,181297,155673,117,21589,46092,144972]

theorem envBound13618 : H12AffineFastState.Bounded env13618 := by
  intro p hp
  have h : env13618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13617_13618 : H12AffineEnvironment.transform 17 34816 env13617 = env13618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34816 env13617 == env13618) = true)

theorem identity13618 : scanCanonicalize (H12AffineFastState.compose env13618 (packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 57401) := by decide +kernel

theorem selectedBound13618 : packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env13619 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,57401,34816,1024,32769,12392,40969,54372,41002,8192,65,43049,49169,45096,31837,9224,32800,117,21589,46092,54901]

theorem envBound13619 : H12AffineFastState.Bounded env13619 := by
  intro p hp
  have h : env13619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13618_13619 : H12AffineEnvironment.transform 16 57401 env13618 = env13619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57401 env13618 == env13619) = true)

theorem identity13619 : scanCanonicalize (H12AffineFastState.compose env13619 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13619 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env13620 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,32768,54359,49169,34816,1024,32769,4160,32801,54372,32770,40,65,34817,49169,36864,23669,1056,32800,117,21589,37924,54901]

theorem envBound13620 : H12AffineFastState.Bounded env13620 := by
  intro p hp
  have h : env13620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13619_13620 : H12AffineEnvironment.transform 12 40 env13619 = env13620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13619 == env13620) = true)

theorem identity13620 : scanCanonicalize (H12AffineFastState.compose env13620 (packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound13620 : packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env13621 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21620,35,5221,23668,1024,21621,4160,21589,16,21622,40,65,23669,5221,17524,23669,1056,21588,117,21589,16464,513]

theorem envBound13621 : H12AffineFastState.Bounded env13621 := by
  intro p hp
  have h : env13621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13620_13621 : H12AffineEnvironment.transform 14 21620 env13620 = env13621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env13620 == env13621) = true)

theorem identity13621 : scanCanonicalize (H12AffineFastState.compose env13621 (packedSelected [2,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13621 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env13622 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,16384,20496,35,4097,22544,100,20497,4160,20529,16,20498,40,65,22545,4097,16400,22545,68,20528,117,20529,16464,513]

theorem envBound13622 : H12AffineFastState.Bounded env13622 := by
  intro p hp
  have h : env13622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13621_13622 : H12AffineEnvironment.transform 9 100 env13621 = env13622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13621 == env13622) = true)

theorem identity13622 : scanCanonicalize (H12AffineFastState.compose env13622 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13622 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13623 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,16384,20496,35,4097,22544,52,20497,4112,20529,16,20498,40,17,22545,4097,16400,22545,20,20528,37,20529,16384,513]

theorem envBound13623 : H12AffineFastState.Bounded env13623 := by
  intro p hp
  have h : env13623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13622_13623 : H12AffineEnvironment.transform 5 16 env13622 = env13623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13622 == env13623) = true)

theorem identity13623 : scanCanonicalize (H12AffineFastState.compose env13623 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound13623 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13624 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4113,1,35,4097,2049,52,0,4112,32,16,3,40,17,2048,4097,4097,2048,20,33,37,32,4113,513]

theorem envBound13624 : H12AffineFastState.Bounded env13624 := by
  intro p hp
  have h : env13624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13623_13624 : H12AffineEnvironment.transform 13 4113 env13623 = env13624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env13623 == env13624) = true)

theorem identity13624 : scanCanonicalize (H12AffineFastState.compose env13624 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound13624 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13625 : List Nat := [2,4,8,16,32,16,8,37,512,52,516,4096,40,4113,1,35,4097,517,52,0,4112,32,16,3,40,17,516,4097,4097,516,20,33,37,32,4113,513]

theorem envBound13625 : H12AffineFastState.Bounded env13625 := by
  intro p hp
  have h : env13625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13624_13625 : H12AffineEnvironment.transform 10 516 env13624 = env13625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env13624 == env13625) = true)

theorem identity13625 : scanCanonicalize (H12AffineFastState.compose env13625 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 19) := by decide +kernel

theorem selectedBound13625 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13626 : List Nat := [2,4,8,16,32,16,8,37,512,52,516,19,40,2,1,35,18,517,52,0,3,32,16,3,40,17,516,18,18,516,20,33,37,32,2,513]

theorem envBound13626 : H12AffineFastState.Bounded env13626 := by
  intro p hp
  have h : env13626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13625_13626 : H12AffineEnvironment.transform 11 19 env13625 = env13626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 19 env13625 == env13626) = true)

theorem identity13626 : scanCanonicalize (H12AffineFastState.compose env13626 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13627 : List Nat := [2,4,8,0,32,0,8,37,512,36,516,3,40,2,1,35,2,517,36,0,3,32,0,3,40,1,516,2,2,516,4,33,37,32,2,513]

theorem envBound13627 : H12AffineFastState.Bounded env13627 := by
  intro p hp
  have h : env13627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13626_13627 : H12AffineEnvironment.transform 3 0 env13626 = env13627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13626 == env13627) = true)

theorem identity13627 : scanCanonicalize (H12AffineFastState.compose env13627 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound13627 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13628 : List Nat := [2,4,8,0,32,0,8,37,12,36,8,3,40,2,1,35,2,9,36,0,3,32,0,3,40,1,8,2,2,8,4,33,37,32,2,13]

theorem envBound13628 : H12AffineFastState.Bounded env13628 := by
  intro p hp
  have h : env13628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13627_13628 : H12AffineEnvironment.transform 8 12 env13627 = env13628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env13627 == env13628) = true)

theorem identity13628 : scanCanonicalize (H12AffineFastState.compose env13628 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13628 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13629 : List Nat := [2,4,8,0,11,0,8,14,12,15,8,3,3,2,1,8,2,9,15,0,3,11,0,3,3,1,8,2,2,8,4,10,14,11,2,13]

theorem envBound13629 : H12AffineFastState.Bounded env13629 := by
  intro p hp
  have h : env13629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13628_13629 : H12AffineEnvironment.transform 4 11 env13628 = env13629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13628 == env13629) = true)

theorem identity13629 : scanCanonicalize (H12AffineFastState.compose env13629 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13629 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13630 : List Nat := [2,4,2,0,1,0,2,4,6,5,2,3,3,2,1,2,2,3,5,0,3,1,0,3,3,1,2,2,2,2,4,0,4,1,2,7]

theorem envBound13630 : H12AffineFastState.Bounded env13630 := by
  intro p hp
  have h : env13630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13629_13630 : H12AffineEnvironment.transform 2 2 env13629 = env13630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13629 == env13630) = true)

def env13631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416037,272392,441640,41310,8193,65,270376,436264,45404,32040,412721,156013,256,21792,46093,442169]

theorem envBound13631 : H12AffineFastState.Bounded env13631 := by
  intro p hp
  have h : env13631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13615_13631 : H12AffineEnvironment.transform 6 9 env13615 = env13631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13615 == env13631) = true)

theorem identity13631 : scanCanonicalize (H12AffineFastState.compose env13631 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound13631 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env13632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,262144,1024,32769,290153,272392,297316,41310,8193,65,270376,302180,45404,32040,292989,21793,256,21792,46093,297845]

theorem envBound13632 : H12AffineFastState.Bounded env13632 := by
  intro p hp
  have h : env13632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13631_13632 : H12AffineEnvironment.transform 16 13388 env13631 = env13632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env13631 == env13632) = true)

theorem identity13632 : scanCanonicalize (H12AffineFastState.compose env13632 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound13632 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env13633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,64808,1024,32769,36929,54560,29772,41310,8193,65,56576,24908,45404,32040,34133,21793,256,21792,46093,30301]

theorem envBound13633 : H12AffineFastState.Bounded env13633 := by
  intro p hp
  have h : env13633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13632_13633 : H12AffineEnvironment.transform 17 64808 env13632 = env13633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env13632 == env13633) = true)

theorem identity13633 : scanCanonicalize (H12AffineFastState.compose env13633 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13633 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env13634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54358,5441,56357,1024,32769,36929,54560,21825,32851,268,65,56576,16449,36945,23589,34133,21793,256,21792,38144,22352]

theorem envBound13634 : H12AffineFastState.Bounded env13634 := by
  intro p hp
  have h : env13634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13633_13634 : H12AffineEnvironment.transform 12 269 env13633 = env13634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13633 == env13634) = true)

theorem identity13634 : scanCanonicalize (H12AffineFastState.compose env13634 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound13634 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env13635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,32768,33031,5441,35188,1024,32769,36929,32881,16,32851,268,65,34897,5392,36945,2420,34133,112,256,113,38144,513]

theorem envBound13635 : H12AffineFastState.Bounded env13635 := by
  intro p hp
  have h : env13635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13634_13635 : H12AffineEnvironment.transform 13 5457 env13634 = env13635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env13634 == env13635) = true)

def env13636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441641,95497,8328,65,4196384,436265,45524,32041,412721,4606308,256,21792,46212,486374]

theorem envBound13636 : H12AffineFastState.Bounded env13636 := by
  intro p hp
  have h : env13636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13596_13636 : H12AffineEnvironment.transform 22 441641 env13596 = env13636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env13596 == env13636) = true)

def env13637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441641,95497,8328,65,270496,436265,45524,32041,412721,156132,256,21792,46212,486374]

theorem envBound13637 : H12AffineFastState.Bounded env13637 := by
  intro p hp
  have h : env13637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13636_13637 : H12AffineEnvironment.transform 21 272512 env13636 = env13637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13636 == env13637) = true)

theorem identity13637 : scanCanonicalize (H12AffineFastState.compose env13637 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound13637 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,115870,243122,73755,95497,8328,65,245138,79131,45524,32041,119043,156132,256,21792,46212,63188]

theorem envBound13638 : H12AffineFastState.Bounded env13638 := by
  intro p hp
  have h : env13638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13637_13638 : H12AffineEnvironment.transform 17 236850 env13637 = env13638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env13637 == env13638) = true)

def env13639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,67754,1024,32769,115870,73770,73755,95497,8328,65,75786,79131,45524,32041,119043,62588,256,21792,46212,63188]

theorem envBound13639 : H12AffineFastState.Bounded env13639 := by
  intro p hp
  have h : env13639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13638_13639 : H12AffineEnvironment.transform 16 38296 env13638 = env13639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env13638 == env13639) = true)

theorem identity13639 : scanCanonicalize (H12AffineFastState.compose env13639 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound13639 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env13640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,38296,56573,1024,32769,4297,62589,62540,41310,8328,65,64605,57676,45524,32041,1364,62588,256,21792,46212,63188]

theorem envBound13640 : H12AffineFastState.Bounded env13640 := by
  intro p hp
  have h : env13640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13639_13640 : H12AffineEnvironment.transform 15 54359 env13639 = env13640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env13639 == env13640) = true)

theorem identity13640 : scanCanonicalize (H12AffineFastState.compose env13640 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound13640 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env13641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,54359,38296,56573,1024,32769,4297,54696,54681,32907,349,65,56712,49305,36865,23804,1364,54697,256,21792,38225,55041]

theorem envBound13641 : H12AffineFastState.Bounded env13641 := by
  intro p hp
  have h : env13641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13640_13641 : H12AffineEnvironment.transform 12 469 env13640 = env13641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env13640 == env13641) = true)

theorem identity13641 : scanCanonicalize (H12AffineFastState.compose env13641 (packedSelected [1,5,8,16,17,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound13641 : packedSelected [1,5,8,16,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env13642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,343,16536,2557,1024,21761,4297,168,153,21899,349,65,2184,5529,17665,23804,1364,169,256,21792,16465,513]

theorem envBound13642 : H12AffineFastState.Bounded env13642 := by
  intro p hp
  have h : env13642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13641_13642 : H12AffineEnvironment.transform 14 21760 env13641 = env13642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env13641 == env13642) = true)

def env13643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,67755,1024,32769,115870,73771,73755,95497,8328,65,75787,79131,45524,32041,119043,62589,256,21792,46212,63188]

theorem envBound13643 : H12AffineFastState.Bounded env13643 := by
  intro p hp
  have h : env13643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13638_13643 : H12AffineEnvironment.transform 16 38297 env13638 = env13643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env13638 == env13643) = true)

theorem identity13643 : scanCanonicalize (H12AffineFastState.compose env13643 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound13643 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env13644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,38297,64928,1024,32769,12693,54560,54544,32770,8328,65,56576,49168,45524,32041,9224,62589,256,21792,46212,63188]

theorem envBound13644 : H12AffineFastState.Bounded env13644 := by
  intro p hp
  have h : env13644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13643_13644 : H12AffineEnvironment.transform 15 62731 env13643 = env13644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env13643 == env13644) = true)

theorem identity13644 : scanCanonicalize (H12AffineFastState.compose env13644 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound13644 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env13645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,342,25028,2557,1024,29788,12693,8573,8525,29791,8328,65,10589,13389,17801,32041,9224,32,256,21792,16601,649]

theorem envBound13645 : H12AffineFastState.Bounded env13645 := by
  intro p hp
  have h : env13645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13644_13645 : H12AffineEnvironment.transform 14 29789 env13644 = env13645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13644 == env13645) = true)

theorem identity13645 : scanCanonicalize (H12AffineFastState.compose env13645 (packedSelected [0,1,2,3,5,6,7,8,10,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 12740) := by decide +kernel

theorem selectedBound13645 : packedSelected [0,1,2,3,5,6,7,8,10,16,17,19] rootPS < 2^1333 := by decide +kernel

def env13646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12740,1433,342,4096,2557,1024,1432,12693,8573,8525,1435,8328,65,10589,13389,13389,3309,9224,32,256,9444,12573,649]

theorem envBound13646 : H12AffineFastState.Bounded env13646 := by
  intro p hp
  have h : env13646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13645_13646 : H12AffineEnvironment.transform 13 12740 env13645 = env13646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12740 env13645 == env13646) = true)

theorem identity13646 : scanCanonicalize (H12AffineFastState.compose env13646 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13646 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env13647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,1296,342,4096,2420,1024,1297,12572,8573,8525,1298,8193,65,10589,13389,13389,3172,9224,32,256,9325,12573,512]

theorem envBound13647 : H12AffineFastState.Bounded env13647 := by
  intro p hp
  have h : env13647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13646_13647 : H12AffineEnvironment.transform 6 9 env13646 = env13647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13646 == env13647) = true)

theorem identity13647 : scanCanonicalize (H12AffineFastState.compose env13647 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound13647 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,4145,1296,342,4096,2420,1024,1297,4192,1,49,1298,381,65,2081,5425,5425,3172,1396,32,256,1297,4193,512]

theorem envBound13648 : H12AffineFastState.Bounded env13648 := by
  intro p hp
  have h : env13648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13647_13648 : H12AffineEnvironment.transform 12 380 env13647 = env13648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env13647 == env13648) = true)

theorem identity13648 : scanCanonicalize (H12AffineFastState.compose env13648 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13648 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13649 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,380,4145,372,342,4096,2420,100,373,4192,1,49,374,381,65,2081,4437,4437,2048,272,32,256,373,4193,512]

theorem envBound13649 : H12AffineFastState.Bounded env13649 := by
  intro p hp
  have h : env13649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13648_13649 : H12AffineEnvironment.transform 9 100 env13648 = env13649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13648 == env13649) = true)

theorem identity13649 : scanCanonicalize (H12AffineFastState.compose env13649 (packedSelected [1,2,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound13649 : packedSelected [1,2,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env13650 : List Nat := [2,4,8,16,32,64,9,256,512,100,260,4096,380,4145,372,342,4096,112,100,373,4192,1,49,374,381,65,293,4437,4437,260,272,32,256,373,4193,512]

theorem envBound13650 : H12AffineFastState.Bounded env13650 := by
  intro p hp
  have h : env13650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13649_13650 : H12AffineEnvironment.transform 10 260 env13649 = env13650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env13649 == env13650) = true)

theorem identity13650 : scanCanonicalize (H12AffineFastState.compose env13650 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13650 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env13651 : List Nat := [2,4,8,16,32,64,9,4,512,100,0,4096,120,4145,112,82,4096,112,100,113,4192,1,49,114,121,65,33,4177,4177,0,20,32,4,113,4193,512]

theorem envBound13651 : H12AffineFastState.Bounded env13651 := by
  intro p hp
  have h : env13651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13650_13651 : H12AffineEnvironment.transform 7 4 env13650 = env13651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13650 == env13651) = true)

theorem identity13651 : scanCanonicalize (H12AffineFastState.compose env13651 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13651 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13652 : List Nat := [2,4,8,16,1,64,9,4,512,69,0,4096,89,4112,81,82,4096,81,69,80,4161,1,16,83,88,65,0,4177,4177,0,20,1,4,80,4160,512]

theorem envBound13652 : H12AffineFastState.Bounded env13652 := by
  intro p hp
  have h : env13652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13651_13652 : H12AffineEnvironment.transform 4 1 env13651 = env13652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13651 == env13652) = true)

theorem identity13652 : scanCanonicalize (H12AffineFastState.compose env13652 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound13652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13653 : List Nat := [2,4,8,16,1,64,9,4,512,69,0,64,89,80,81,82,64,81,69,80,1,1,16,83,88,65,0,17,17,0,20,1,4,80,0,512]

theorem envBound13653 : H12AffineFastState.Bounded env13653 := by
  intro p hp
  have h : env13653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13652_13653 : H12AffineEnvironment.transform 11 64 env13652 = env13653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env13652 == env13653) = true)

theorem identity13653 : scanCanonicalize (H12AffineFastState.compose env13653 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 21) := by decide +kernel

theorem selectedBound13653 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13654 : List Nat := [2,4,8,16,1,21,9,4,512,16,0,21,12,5,4,7,21,4,16,5,1,1,16,6,13,20,0,17,17,0,20,1,4,5,0,512]

theorem envBound13654 : H12AffineFastState.Bounded env13654 := by
  intro p hp
  have h : env13654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13653_13654 : H12AffineEnvironment.transform 5 21 env13653 = env13654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env13653 == env13654) = true)

theorem identity13654 : scanCanonicalize (H12AffineFastState.compose env13654 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound13654 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13655 : List Nat := [2,4,8,16,1,21,9,4,5,16,0,21,12,5,4,7,21,4,16,5,1,1,16,6,13,20,0,17,17,0,20,1,4,5,0,5]

theorem envBound13655 : H12AffineFastState.Bounded env13655 := by
  intro p hp
  have h : env13655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13654_13655 : H12AffineEnvironment.transform 8 5 env13654 = env13655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env13654 == env13655) = true)

theorem identity13655 : scanCanonicalize (H12AffineFastState.compose env13655 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13655 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13656 : List Nat := [2,4,8,0,1,5,9,4,5,0,0,5,12,5,4,7,5,4,0,5,1,1,0,6,13,4,0,1,1,0,4,1,4,5,0,5]

theorem envBound13656 : H12AffineFastState.Bounded env13656 := by
  intro p hp
  have h : env13656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13655_13656 : H12AffineEnvironment.transform 3 0 env13655 = env13656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13655 == env13656) = true)

def env13657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441641,95497,8328,65,270497,436265,45524,32041,412721,156133,256,21792,46212,486374]

theorem envBound13657 : H12AffineFastState.Bounded env13657 := by
  intro p hp
  have h : env13657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13636_13657 : H12AffineEnvironment.transform 21 272513 env13636 = env13657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13636 == env13657) = true)

theorem identity13657 : scanCanonicalize (H12AffineFastState.compose env13657 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13657 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416172,272513,441641,21762,8328,65,270497,436265,45524,32041,412721,156133,256,21792,46212,412653]

theorem envBound13658 : H12AffineFastState.Bounded env13658 := by
  intro p hp
  have h : env13658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13657_13658 : H12AffineEnvironment.transform 15 8203 env13657 = env13658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13657 == env13658) = true)

def env13659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416036,272393,441641,21762,8192,65,270377,436265,45404,32041,412721,156013,256,21792,46092,412517]

theorem envBound13659 : H12AffineFastState.Bounded env13659 := by
  intro p hp
  have h : env13659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13658_13659 : H12AffineEnvironment.transform 6 8 env13658 = env13659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13658 == env13659) = true)

theorem identity13659 : scanCanonicalize (H12AffineFastState.compose env13659 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound13659 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env13660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8203,131072,262144,1024,29993,416036,272393,411649,21762,8192,65,270377,417025,17524,32041,412721,156013,256,21792,16676,412517]

theorem envBound13660 : H12AffineFastState.Bounded env13660 := by
  intro p hp
  have h : env13660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13659_13660 : H12AffineEnvironment.transform 14 29992 env13659 = env13660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env13659 == env13660) = true)

theorem identity13660 : scanCanonicalize (H12AffineFastState.compose env13660 (packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound13660 : packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env13661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8203,5221,262144,1024,29993,281921,272393,285796,21762,8192,65,270377,280932,17524,32041,284756,29960,256,21792,16676,286464]

theorem envBound13661 : H12AffineFastState.Bounded env13661 := by
  intro p hp
  have h : env13661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13660_13661 : H12AffineEnvironment.transform 16 5221 env13660 = env13661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env13660 == env13661) = true)

theorem identity13661 : scanCanonicalize (H12AffineFastState.compose env13661 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13661 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env13662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8233,8203,5221,262144,1024,8232,268352,272393,264549,3,8192,65,270377,269413,4469,10280,265557,8201,256,33,5157,264705]

theorem envBound13662 : H12AffineFastState.Bounded env13662 := by
  intro p hp
  have h : env13662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13661_13662 : H12AffineEnvironment.transform 13 5377 env13661 = env13662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13661 == env13662) = true)

theorem identity13662 : scanCanonicalize (H12AffineFastState.compose env13662 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound13662 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env13663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3385,5377,3344,3378,5221,262144,1024,3345,268352,263472,264549,3,3385,65,265488,269413,4469,1297,265557,3376,256,33,5157,264705]

theorem envBound13663 : H12AffineFastState.Bounded env13663 := by
  intro p hp
  have h : env13663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13662_13663 : H12AffineEnvironment.transform 12 3385 env13662 = env13663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env13662 == env13663) = true)

theorem identity13663 : scanCanonicalize (H12AffineFastState.compose env13663 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound13663 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env13664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3385,5377,3344,3378,5221,2420,1024,3345,4404,3140,17,3,3385,65,1124,5393,4469,1297,1057,3376,256,33,5157,885]

theorem envBound13664 : H12AffineFastState.Bounded env13664 := by
  intro p hp
  have h : env13664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13663_13664 : H12AffineEnvironment.transform 17 2420 env13663 = env13664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env13663 == env13664) = true)

theorem identity13664 : scanCanonicalize (H12AffineFastState.compose env13664 (packedSelected [1,4,6,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound13664 : packedSelected [1,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env13665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,3385,1,3344,3378,357,2420,1024,3345,1076,3140,17,3,3385,65,1124,17,1141,1297,1057,3376,256,33,293,885]

theorem envBound13665 : H12AffineFastState.Bounded env13665 := by
  intro p hp
  have h : env13665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13664_13665 : H12AffineEnvironment.transform 11 1280 env13664 = env13665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env13664 == env13665) = true)

theorem identity13665 : scanCanonicalize (H12AffineFastState.compose env13665 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound13665 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1280,1100,1,1125,1095,357,1,1024,1124,1076,1329,17,3,1100,65,1124,17,1141,1297,1057,1093,256,33,293,885]

theorem envBound13666 : H12AffineFastState.Bounded env13666 := by
  intro p hp
  have h : env13666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13665_13666 : H12AffineEnvironment.transform 10 373 env13665 = env13666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env13665 == env13666) = true)

theorem identity13666 : scanCanonicalize (H12AffineFastState.compose env13666 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13666 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13667 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,1061,1100,1,1125,1095,64,1,1024,1124,1076,1044,17,3,1100,65,1124,17,1141,1076,1057,1093,37,33,0,592]

theorem envBound13667 : H12AffineFastState.Bounded env13667 := by
  intro p hp
  have h : env13667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13666_13667 : H12AffineEnvironment.transform 7 37 env13666 = env13667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13666 == env13667) = true)

theorem identity13667 : scanCanonicalize (H12AffineFastState.compose env13667 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound13667 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13668 : List Nat := [2,4,8,16,32,64,8,37,512,543,80,570,595,1,634,600,64,1,543,635,555,523,17,3,595,65,635,17,618,555,574,602,37,33,0,592]

theorem envBound13668 : H12AffineFastState.Bounded env13668 := by
  intro p hp
  have h : env13668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13667_13668 : H12AffineEnvironment.transform 9 543 env13667 = env13668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env13667 == env13668) = true)

theorem identity13668 : scanCanonicalize (H12AffineFastState.compose env13668 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13668 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env13669 : List Nat := [2,4,8,16,1,64,8,4,512,543,80,539,595,1,603,600,64,1,543,602,522,523,17,3,595,65,602,17,587,522,543,602,4,0,0,592]

theorem envBound13669 : H12AffineFastState.Bounded env13669 := by
  intro p hp
  have h : env13669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13668_13669 : H12AffineEnvironment.transform 4 1 env13668 = env13669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13668 == env13669) = true)

theorem identity13669 : scanCanonicalize (H12AffineFastState.compose env13669 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13669 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13670 : List Nat := [2,4,8,16,1,16,8,4,512,543,0,539,515,1,523,520,16,1,543,522,522,523,17,3,515,17,522,17,539,522,543,522,4,0,0,512]

theorem envBound13670 : H12AffineFastState.Bounded env13670 := by
  intro p hp
  have h : env13670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13669_13670 : H12AffineEnvironment.transform 5 16 env13669 = env13670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13669 == env13670) = true)

theorem identity13670 : scanCanonicalize (H12AffineFastState.compose env13670 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound13670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13671 : List Nat := [2,4,8,16,1,16,8,4,11,20,0,16,8,1,0,3,16,1,20,1,1,0,17,3,8,17,1,17,16,1,20,1,4,0,0,11]

theorem envBound13671 : H12AffineFastState.Bounded env13671 := by
  intro p hp
  have h : env13671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13670_13671 : H12AffineEnvironment.transform 8 11 env13670 = env13671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env13670 == env13671) = true)

theorem identity13671 : scanCanonicalize (H12AffineFastState.compose env13671 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound13671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13672 : List Nat := [2,0,8,16,1,16,8,0,11,16,0,16,8,1,0,3,16,1,16,1,1,0,17,3,8,17,1,17,16,1,16,1,0,0,0,11]

theorem envBound13672 : H12AffineFastState.Bounded env13672 := by
  intro p hp
  have h : env13672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13671_13672 : H12AffineEnvironment.transform 1 0 env13671 = env13672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env13671 == env13672) = true)

theorem identity13672 : scanCanonicalize (H12AffineFastState.compose env13672 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound13672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13673 : List Nat := [2,0,8,2,1,2,8,0,11,2,0,2,8,1,0,3,2,1,2,1,1,0,3,3,8,3,1,3,2,1,2,1,0,0,0,11]

theorem envBound13673 : H12AffineFastState.Bounded env13673 := by
  intro p hp
  have h : env13673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13672_13673 : H12AffineEnvironment.transform 3 2 env13672 = env13673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env13672 == env13673) = true)

def env13674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416037,272392,441641,21762,8193,65,270376,436265,45405,32041,412721,156012,256,21792,46093,412516]

theorem envBound13674 : H12AffineFastState.Bounded env13674 := by
  intro p hp
  have h : env13674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13658_13674 : H12AffineEnvironment.transform 6 9 env13658 = env13674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13658 == env13674) = true)

theorem identity13674 : scanCanonicalize (H12AffineFastState.compose env13674 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound13674 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env13675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,157752,1024,32769,12573,147504,54545,21762,8193,65,149520,49169,45405,32041,9225,156012,256,21792,46093,9052]

theorem envBound13675 : H12AffineFastState.Bounded env13675 := by
  intro p hp
  have h : env13675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13674_13675 : H12AffineEnvironment.transform 17 157752 env13674 = env13675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env13674 == env13675) = true)

theorem identity13675 : scanCanonicalize (H12AffineFastState.compose env13675 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound13675 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env13676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46156,56436,1024,32769,12573,62588,54545,21762,8193,65,64604,49169,45405,32041,9225,54560,256,21792,46093,9052]

theorem envBound13676 : H12AffineFastState.Bounded env13676 := by
  intro p hp
  have h : env13676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13675_13676 : H12AffineEnvironment.transform 16 46156 env13675 = env13676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env13675 == env13676) = true)

theorem identity13676 : scanCanonicalize (H12AffineFastState.compose env13676 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13676 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env13677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,13388,23668,1024,1,12573,29820,21777,21762,8193,65,31836,16401,12637,32041,9225,21792,256,21792,13325,9052]

theorem envBound13677 : H12AffineFastState.Bounded env13677 := by
  intro p hp
  have h : env13677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13676_13677 : H12AffineEnvironment.transform 14 0 env13676 = env13677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13676 == env13677) = true)

theorem identity13677 : scanCanonicalize (H12AffineFastState.compose env13677 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13677 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env13678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,0,35,5220,23668,1024,1,4405,21588,21777,21762,41,65,23668,16401,4469,23809,1057,21792,256,21792,5157,884]

theorem envBound13678 : H12AffineFastState.Bounded env13678 := by
  intro p hp
  have h : env13678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13677_13678 : H12AffineEnvironment.transform 12 40 env13677 = env13678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13677 == env13678) = true)

theorem identity13678 : scanCanonicalize (H12AffineFastState.compose env13678 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound13678 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,0,35,5220,2048,1024,1,4405,32,357,374,41,65,2048,5221,4469,2421,1057,340,256,340,5157,884]

theorem envBound13679 : H12AffineFastState.Bounded env13679 := by
  intro p hp
  have h : env13679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13678_13679 : H12AffineEnvironment.transform 13 5236 env13678 = env13679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env13678 == env13679) = true)

theorem identity13679 : scanCanonicalize (H12AffineFastState.compose env13679 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13679 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13680 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,0,35,5220,2048,1024,1,4160,32,16,3,41,65,2048,5221,4096,2048,1057,33,117,33,5157,513]

theorem envBound13680 : H12AffineFastState.Bounded env13680 := by
  intro p hp
  have h : env13680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13679_13680 : H12AffineEnvironment.transform 7 117 env13679 = env13680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13679 == env13680) = true)

theorem identity13680 : scanCanonicalize (H12AffineFastState.compose env13680 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound13680 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13681 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,4096,40,5236,0,35,5220,1134,1024,1,4160,32,16,3,41,65,1134,5221,4096,1134,1057,33,117,33,5157,513]

theorem envBound13681 : H12AffineFastState.Bounded env13681 := by
  intro p hp
  have h : env13681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13680_13681 : H12AffineEnvironment.transform 10 1134 env13680 = env13681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env13680 == env13681) = true)

theorem identity13681 : scanCanonicalize (H12AffineFastState.compose env13681 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound13681 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13682 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,1125,40,17,0,35,1,1134,1024,1,1061,32,16,3,41,65,1134,0,1125,1134,1057,33,117,33,64,513]

theorem envBound13682 : H12AffineFastState.Bounded env13682 := by
  intro p hp
  have h : env13682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13681_13682 : H12AffineEnvironment.transform 11 1125 env13681 = env13682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env13681 == env13682) = true)

theorem identity13682 : scanCanonicalize (H12AffineFastState.compose env13682 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound13682 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13683 : List Nat := [2,4,8,16,32,64,9,117,512,110,0,11,40,17,0,35,1,0,110,1,75,32,16,3,41,65,0,0,11,0,79,33,117,33,64,513]

theorem envBound13683 : H12AffineFastState.Bounded env13683 := by
  intro p hp
  have h : env13683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13682_13683 : H12AffineEnvironment.transform 9 110 env13682 = env13683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env13682 == env13683) = true)

theorem identity13683 : scanCanonicalize (H12AffineFastState.compose env13683 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound13683 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13684 : List Nat := [2,4,8,16,32,59,9,14,512,21,0,11,40,17,0,35,1,0,21,1,48,32,16,3,41,58,0,0,11,0,52,33,14,33,59,513]

theorem envBound13684 : H12AffineFastState.Bounded env13684 := by
  intro p hp
  have h : env13684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13683_13684 : H12AffineEnvironment.transform 5 59 env13683 = env13684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env13683 == env13684) = true)

theorem identity13684 : scanCanonicalize (H12AffineFastState.compose env13684 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound13684 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13685 : List Nat := [2,4,8,16,10,17,9,14,512,21,0,11,2,17,0,9,1,0,21,1,26,10,16,3,3,16,0,0,11,0,30,11,14,11,17,513]

theorem envBound13685 : H12AffineFastState.Bounded env13685 := by
  intro p hp
  have h : env13685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13684_13685 : H12AffineEnvironment.transform 4 10 env13684 = env13685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env13684 == env13685) = true)

theorem identity13685 : scanCanonicalize (H12AffineFastState.compose env13685 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13685 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13686 : List Nat := [2,4,8,10,10,11,9,14,512,15,0,11,2,11,0,9,1,0,15,1,0,10,10,3,3,10,0,0,11,0,4,11,14,11,11,513]

theorem envBound13686 : H12AffineFastState.Bounded env13686 := by
  intro p hp
  have h : env13686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13685_13686 : H12AffineEnvironment.transform 3 10 env13685 = env13686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13685 == env13686) = true)

theorem identity13686 : scanCanonicalize (H12AffineFastState.compose env13686 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound13686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13687 : List Nat := [2,4,8,10,10,11,9,14,15,15,0,11,2,11,0,9,1,0,15,1,0,10,10,3,3,10,0,0,11,0,4,11,14,11,11,14]

theorem envBound13687 : H12AffineFastState.Bounded env13687 := by
  intro p hp
  have h : env13687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13686_13687 : H12AffineEnvironment.transform 8 15 env13686 = env13687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env13686 == env13687) = true)

def env13688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,8388608,8898592,8328,65,4196384,8393985,8785148,8830976,412721,12645452,256,21793,46213,486374]

theorem envBound13688 : H12AffineFastState.Bounded env13688 := by
  intro p hp
  have h : env13688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13595_13688 : H12AffineEnvironment.transform 20 416173 env13595 = env13688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416173 env13595 == env13688) = true)

def env13689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441640,95496,8328,65,4196384,436265,45524,32040,412721,4606308,256,21793,46213,486374]

theorem envBound13689 : H12AffineFastState.Bounded env13689 := by
  intro p hp
  have h : env13689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13688_13689 : H12AffineEnvironment.transform 22 441640 env13688 = env13689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env13688 == env13689) = true)

def env13690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441640,95496,8328,65,270496,436265,45524,32040,412721,156132,256,21793,46213,486374]

theorem envBound13690 : H12AffineFastState.Bounded env13690 := by
  intro p hp
  have h : env13690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13689_13690 : H12AffineEnvironment.transform 21 272512 env13689 = env13690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13689 == env13690) = true)

theorem identity13690 : scanCanonicalize (H12AffineFastState.compose env13690 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13690 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416173,272512,412156,95496,8328,65,270496,417021,17664,32040,412721,156132,256,21793,16465,486374]

theorem envBound13691 : H12AffineFastState.Bounded env13691 := by
  intro p hp
  have h : env13691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13690_13691 : H12AffineEnvironment.transform 14 29908 env13690 = env13691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13690 == env13691) = true)

def env13692 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272512,412076,95496,8328,17,270496,416941,17664,32040,412721,156084,256,21793,16385,486326]

theorem envBound13692 : H12AffineFastState.Bounded env13692 := by
  intro p hp
  have h : env13692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13691_13692 : H12AffineEnvironment.transform 5 16 env13691 = env13692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13691 == env13692) = true)

theorem identity13692 : scanCanonicalize (H12AffineFastState.compose env13692 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 212151) := by decide +kernel

theorem selectedBound13692 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env13693 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,212151,1024,29829,91418,201783,95515,95496,8328,17,203799,90138,17664,32040,94342,156084,256,21793,16385,22273]

theorem envBound13693 : H12AffineFastState.Bounded env13693 := by
  intro p hp
  have h : env13693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13692_13693 : H12AffineEnvironment.transform 17 212151 env13692 = env13693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212151 env13692 == env13693) = true)

theorem identity13693 : scanCanonicalize (H12AffineFastState.compose env13693 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound13693 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env13694 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,131072,138293,1024,29829,17816,144565,21913,21898,8328,17,146581,16536,17664,32040,20484,156084,256,21793,16385,22273]

theorem envBound13694 : H12AffineFastState.Bounded env13694 := by
  intro p hp
  have h : env13694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13693_13694 : H12AffineEnvironment.transform 15 8322 env13693 = env13694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env13693 == env13694) = true)

theorem identity13694 : scanCanonicalize (H12AffineFastState.compose env13694 (packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound13694 : packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env13695 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,16536,23725,1024,29829,17816,29741,21913,21898,8328,17,31757,16536,17664,32040,20484,8492,256,21793,16385,22273]

theorem envBound13695 : H12AffineFastState.Bounded env13695 := by
  intro p hp
  have h : env13695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13694_13695 : H12AffineEnvironment.transform 16 16536 env13694 = env13695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env13694 == env13695) = true)

theorem identity13695 : scanCanonicalize (H12AffineFastState.compose env13695 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13695 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env13696 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,8322,5528,2477,1024,8581,4248,8493,153,138,8328,17,10509,5528,4096,10280,1284,8492,256,33,5377,513]

theorem envBound13696 : H12AffineFastState.Bounded env13696 := by
  intro p hp
  have h : env13696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13695_13696 : H12AffineEnvironment.transform 13 5376 env13695 = env13696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13695 == env13696) = true)

def env13697 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272512,412077,95496,8328,16,270496,416940,17664,32040,412721,156085,256,21793,16384,486327]

theorem envBound13697 : H12AffineFastState.Bounded env13697 := by
  intro p hp
  have h : env13697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13691_13697 : H12AffineEnvironment.transform 5 17 env13691 = env13697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13691 == env13697) = true)

theorem identity13697 : scanCanonicalize (H12AffineFastState.compose env13697 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound13697 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env13698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24860,262144,1024,29828,276657,272512,272561,95496,8328,16,270496,277936,17664,32040,273709,169,256,21793,16384,330411]

theorem envBound13698 : H12AffineFastState.Bounded env13698 := by
  intro p hp
  have h : env13698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13697_13698 : H12AffineEnvironment.transform 16 24860 env13697 = env13698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env13697 == env13698) = true)

theorem identity13698 : scanCanonicalize (H12AffineFastState.compose env13698 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound13698 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env13699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24860,2476,1024,29828,12573,8492,8477,95496,8328,16,10508,13340,17664,32040,9345,169,256,21793,16384,66311]

theorem envBound13699 : H12AffineFastState.Bounded env13699 := by
  intro p hp
  have h : env13699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13698_13699 : H12AffineEnvironment.transform 17 2476 env13698 = env13699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env13698 == env13699) = true)

theorem identity13699 : scanCanonicalize (H12AffineFastState.compose env13699 (packedSelected [1,10,17,19,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13699 : packedSelected [1,10,17,19,28] rootPS < 2^1333 := by decide +kernel

def env13700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24860,2476,1024,29828,12573,8492,8477,21762,8328,16,10508,13340,17664,32040,9345,169,256,21793,16384,8973]

theorem envBound13700 : H12AffineFastState.Bounded env13700 := by
  intro p hp
  have h : env13700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13699_13700 : H12AffineEnvironment.transform 15 8202 env13699 = env13700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13699 == env13700) = true)

theorem identity13700 : scanCanonicalize (H12AffineFastState.compose env13700 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 11412) := by decide +kernel

theorem selectedBound13700 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env13701 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,11412,6161,8202,3464,2476,1024,6160,12573,8492,8477,14742,8328,16,10508,13340,10644,4540,9345,169,256,14773,11412,8973]

theorem envBound13701 : H12AffineFastState.Bounded env13701 := by
  intro p hp
  have h : env13701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13700_13701 : H12AffineEnvironment.transform 13 11412 env13700 = env13701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11412 env13700 == env13701) = true)

theorem identity13701 : scanCanonicalize (H12AffineFastState.compose env13701 (packedSelected [0,2,3,5,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound13701 : packedSelected [0,2,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env13702 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4153,7341,6161,4147,3464,2476,1024,6160,292,4373,4388,2479,4273,16,6453,1061,6573,4540,5304,169,256,2444,7341,4916]

theorem envBound13702 : H12AffineFastState.Bounded env13702 := by
  intro p hp
  have h : env13702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13701_13702 : H12AffineEnvironment.transform 12 4153 env13701 = env13702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env13701 == env13702) = true)

theorem identity13702 : scanCanonicalize (H12AffineFastState.compose env13702 (packedSelected [0,1,4,7,8,9,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound13702 : packedSelected [0,1,4,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env13703 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1212,4096,4153,4113,5293,4147,308,1296,1024,5292,292,4373,4388,1299,4273,16,5513,1061,5393,4540,5304,169,256,1328,4113,4916]

theorem envBound13703 : H12AffineFastState.Bounded env13703 := by
  intro p hp
  have h : env13703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13702_13703 : H12AffineEnvironment.transform 10 1212 env13702 = env13703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env13702 == env13703) = true)

theorem identity13703 : scanCanonicalize (H12AffineFastState.compose env13703 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound13703 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env13704 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1212,152,161,137,1077,171,308,1296,1024,1076,292,397,444,1299,41,16,1297,1061,1417,292,1056,169,256,1328,137,940]

theorem envBound13704 : H12AffineFastState.Bounded env13704 := by
  intro p hp
  have h : env13704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13703_13704 : H12AffineEnvironment.transform 11 152 env13703 = env13704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env13703 == env13704) = true)

theorem identity13704 : scanCanonicalize (H12AffineFastState.compose env13704 (packedSelected [2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13704 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env13705 : List Nat := [2,4,8,16,32,17,128,37,512,1024,1212,152,161,137,1077,171,17,1077,1024,1076,1,168,153,1078,41,16,1076,1061,1196,1,1056,169,37,1045,137,649]

theorem envBound13705 : H12AffineFastState.Bounded env13705 := by
  intro p hp
  have h : env13705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13704_13705 : H12AffineEnvironment.transform 7 37 env13704 = env13705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13704 == env13705) = true)

theorem identity13705 : scanCanonicalize (H12AffineFastState.compose env13705 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13705 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env13706 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,16,41,1,1077,35,17,1077,1024,1076,1,32,17,1078,41,16,1076,1061,1060,1,1056,33,37,1045,1,513]

theorem envBound13706 : H12AffineFastState.Bounded env13706 := by
  intro p hp
  have h : env13706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13705_13706 : H12AffineEnvironment.transform 6 8 env13705 = env13706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13705 == env13706) = true)

theorem identity13706 : scanCanonicalize (H12AffineFastState.compose env13706 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13706 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13707 : List Nat := [2,4,8,16,32,17,8,37,512,53,1,16,41,1,0,35,17,0,53,1,1,32,17,3,41,16,1,16,17,1,21,33,37,32,1,513]

theorem envBound13707 : H12AffineFastState.Bounded env13707 := by
  intro p hp
  have h : env13707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13706_13707 : H12AffineEnvironment.transform 9 53 env13706 = env13707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13706 == env13707) = true)

theorem identity13707 : scanCanonicalize (H12AffineFastState.compose env13707 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound13707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13708 : List Nat := [2,4,8,16,32,17,8,37,48,53,1,16,41,1,0,35,17,0,53,1,1,32,17,3,41,16,1,16,17,1,21,33,37,32,1,49]

theorem envBound13708 : H12AffineFastState.Bounded env13708 := by
  intro p hp
  have h : env13708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13707_13708 : H12AffineEnvironment.transform 8 48 env13707 = env13708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env13707 == env13708) = true)

theorem identity13708 : scanCanonicalize (H12AffineFastState.compose env13708 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13709 : List Nat := [2,4,8,0,32,1,8,37,32,37,1,0,41,1,0,35,1,0,37,1,1,32,1,3,41,0,1,0,1,1,5,33,37,32,1,33]

theorem envBound13709 : H12AffineFastState.Bounded env13709 := by
  intro p hp
  have h : env13709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13708_13709 : H12AffineEnvironment.transform 3 0 env13708 = env13709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13708 == env13709) = true)

def env13710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441640,95496,8328,65,270497,436265,45524,32040,412721,156133,256,21793,46213,486374]

theorem envBound13710 : H12AffineFastState.Bounded env13710 := by
  intro p hp
  have h : env13710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13689_13710 : H12AffineEnvironment.transform 21 272513 env13689 = env13710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13689 == env13710) = true)

theorem identity13710 : scanCanonicalize (H12AffineFastState.compose env13710 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound13710 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,156013,62660,95496,8328,65,158029,57797,45524,32040,1501,156133,256,21793,46213,74250]

theorem envBound13711 : H12AffineFastState.Bounded env13711 := by
  intro p hp
  have h : env13711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13710_13711 : H12AffineEnvironment.transform 17 149996 env13710 = env13711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env13710 == env13711) = true)

theorem identity13711 : scanCanonicalize (H12AffineFastState.compose env13711 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13711 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4161,156013,62660,21763,8328,65,158029,57797,45524,32040,1501,156133,256,21793,46213,513]

theorem envBound13712 : H12AffineFastState.Bounded env13712 := by
  intro p hp
  have h : env13712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13711_13712 : H12AffineEnvironment.transform 15 8203 env13711 = env13712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13711 == env13712) = true)

theorem identity13712 : scanCanonicalize (H12AffineFastState.compose env13712 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound13712 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env13713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8203,131072,146744,1024,32769,4161,136633,32784,8663,8328,65,138649,38161,45524,2556,1501,136497,256,8693,46213,513]

theorem envBound13713 : H12AffineFastState.Bounded env13713 := by
  intro p hp
  have h : env13713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13712_13713 : H12AffineEnvironment.transform 13 13524 env13712 = env13713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env13712 == env13713) = true)

theorem identity13713 : scanCanonicalize (H12AffineFastState.compose env13713 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound13713 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env13714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8203,5529,10401,1024,32769,4161,32,32784,8663,8328,65,2048,38161,45524,2556,1501,168,256,8693,46213,513]

theorem envBound13714 : H12AffineFastState.Bounded env13714 := by
  intro p hp
  have h : env13714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13713_13714 : H12AffineEnvironment.transform 16 5529 env13713 = env13714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env13713 == env13714) = true)

theorem identity13714 : scanCanonicalize (H12AffineFastState.compose env13714 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13714 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env13715 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,8203,5529,10401,1024,32769,4112,32,32784,8582,8328,16,2048,38161,45445,2477,1420,168,256,8612,46213,513]

theorem envBound13715 : H12AffineFastState.Bounded env13715 := by
  intro p hp
  have h : env13715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13714_13715 : H12AffineEnvironment.transform 5 17 env13714 = env13715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13714 == env13715) = true)

theorem identity13715 : scanCanonicalize (H12AffineFastState.compose env13715 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound13715 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13716 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,32768,398,5529,2340,1024,32769,4112,32,32784,3,269,16,2048,38161,36864,2477,1420,168,256,33,38144,513]

theorem envBound13716 : H12AffineFastState.Bounded env13716 := by
  intro p hp
  have h : env13716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13715_13716 : H12AffineEnvironment.transform 12 389 env13715 = env13716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env13715 == env13716) = true)

theorem identity13716 : scanCanonicalize (H12AffineFastState.compose env13716 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound13716 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env13717 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,293,398,5529,2340,1024,292,4112,32,309,3,269,16,2048,5172,4389,2477,1420,168,256,33,5157,513]

theorem envBound13717 : H12AffineFastState.Bounded env13717 := by
  intro p hp
  have h : env13717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13716_13717 : H12AffineEnvironment.transform 14 293 env13716 = env13717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env13716 == env13717) = true)

theorem identity13717 : scanCanonicalize (H12AffineFastState.compose env13717 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound13717 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env13718 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2493,389,3261,293,398,3108,2340,1024,292,2477,32,309,3,269,16,2048,3465,2200,2477,1420,168,256,33,3480,513]

theorem envBound13718 : H12AffineFastState.Bounded env13718 := by
  intro p hp
  have h : env13718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13717_13718 : H12AffineEnvironment.transform 11 2493 env13717 = env13718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env13717 == env13718) = true)

theorem identity13718 : scanCanonicalize (H12AffineFastState.compose env13718 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13718 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env13719 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2064,40,3261,136,35,3108,2185,1024,137,2048,32,152,3,160,16,2048,3108,2200,2048,1057,168,173,33,3125,513]

theorem envBound13719 : H12AffineFastState.Bounded env13719 := by
  intro p hp
  have h : env13719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13718_13719 : H12AffineEnvironment.transform 7 173 env13718 = env13719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13718 == env13719) = true)

theorem identity13719 : scanCanonicalize (H12AffineFastState.compose env13719 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13719 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13720 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,2064,40,2185,136,35,2064,2185,52,137,2048,32,152,3,160,16,2048,2064,2200,2048,21,168,173,33,2049,513]

theorem envBound13720 : H12AffineFastState.Bounded env13720 := by
  intro p hp
  have h : env13720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13719_13720 : H12AffineEnvironment.transform 9 52 env13719 = env13720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13719 == env13720) = true)

theorem identity13720 : scanCanonicalize (H12AffineFastState.compose env13720 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13721 : List Nat := [2,4,8,16,32,17,128,173,512,52,0,16,40,137,136,35,16,137,52,137,0,32,152,3,160,16,0,16,152,0,21,168,173,33,1,513]

theorem envBound13721 : H12AffineFastState.Bounded env13721 := by
  intro p hp
  have h : env13721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13720_13721 : H12AffineEnvironment.transform 10 0 env13720 = env13721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13720 == env13721) = true)

def env13722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441641,95497,8328,65,4196384,436264,45525,32041,412721,4606309,256,21793,46213,486374]

theorem envBound13722 : H12AffineFastState.Bounded env13722 := by
  intro p hp
  have h : env13722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13688_13722 : H12AffineEnvironment.transform 22 441641 env13688 = env13722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env13688 == env13722) = true)

def env13723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441641,95497,8328,65,270496,436264,45525,32041,412721,156133,256,21793,46213,486374]

theorem envBound13723 : H12AffineFastState.Bounded env13723 := by
  intro p hp
  have h : env13723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13722_13723 : H12AffineEnvironment.transform 21 272512 env13722 = env13723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13722 == env13723) = true)

def env13724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272392,441641,95497,8192,65,270376,436264,45405,32041,412721,156013,256,21793,46093,486254]

theorem envBound13724 : H12AffineFastState.Bounded env13724 := by
  intro p hp
  have h : env13724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13723_13724 : H12AffineEnvironment.transform 6 8 env13723 = env13724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13723 == env13724) = true)

def env13725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314421,272392,272441,95497,8192,65,270376,277816,45405,32041,317729,62589,256,21793,46093,392830]

theorem envBound13725 : H12AffineFastState.Bounded env13725 := by
  intro p hp
  have h : env13725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13724_13725 : H12AffineEnvironment.transform 16 38160 env13724 = env13725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env13724 == env13725) = true)

theorem identity13725 : scanCanonicalize (H12AffineFastState.compose env13725 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound13725 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89379,1024,32769,102678,95531,95514,95497,8192,65,97547,90139,45405,32041,99330,62589,256,21793,46093,41821]

theorem envBound13726 : H12AffineFastState.Bounded env13726 := by
  intro p hp
  have h : env13726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13725_13726 : H12AffineEnvironment.transform 17 89379 env13725 = env13726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env13725 == env13726) = true)

theorem identity13726 : scanCanonicalize (H12AffineFastState.compose env13726 (packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound13726 : packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env13727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,65536,38160,89379,1024,32769,102678,87379,87394,87409,120,65,89459,82019,37157,23889,99330,54277,256,21793,38005,33573]

theorem envBound13727 : H12AffineFastState.Bounded env13727 := by
  intro p hp
  have h : env13727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13726_13727 : H12AffineEnvironment.transform 12 120 env13726 = env13727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env13726 == env13727) = true)

theorem identity13727 : scanCanonicalize (H12AffineFastState.compose env13727 (packedSelected [2,4,6,8,10,11,12,15,18,20,22,28] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13727 : packedSelected [2,4,6,8,10,11,12,15,18,20,22,28] rootPS < 2^1333 := by decide +kernel

def env13728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,33110,38160,56437,1024,32769,4160,54277,54324,54311,120,65,56357,49461,37157,23889,1364,54277,256,21793,38005,33573]

theorem envBound13728 : H12AffineFastState.Bounded env13728 := by
  intro p hp
  have h : env13728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13727_13728 : H12AffineEnvironment.transform 15 33110 env13727 = env13728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13727 == env13728) = true)

theorem identity13728 : scanCanonicalize (H12AffineFastState.compose env13728 (packedSelected [0,1,2,7,8,12,14,15,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound13728 : packedSelected [0,1,2,7,8,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env13729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21621,21795,16741,2048,1024,21620,4160,112,65,82,120,65,2128,5440,17744,23889,1364,112,256,21793,16384,22352]

theorem envBound13729 : H12AffineFastState.Bounded env13729 := by
  intro p hp
  have h : env13729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13728_13729 : H12AffineEnvironment.transform 14 21621 env13728 = env13729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env13728 == env13729) = true)

theorem identity13729 : scanCanonicalize (H12AffineFastState.compose env13729 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound13729 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5156,81,263,5441,2048,1024,80,4160,112,65,82,120,65,2128,5440,4468,2421,1364,112,256,261,5156,884]

theorem envBound13730 : H12AffineFastState.Bounded env13730 := by
  intro p hp
  have h : env13730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13729_13730 : H12AffineEnvironment.transform 13 5156 env13729 = env13730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env13729 == env13730) = true)

theorem identity13730 : scanCanonicalize (H12AffineFastState.compose env13730 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13730 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13731 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5156,81,114,5172,2048,1024,80,4160,112,65,82,120,65,2128,5173,4097,2048,1057,112,117,112,5156,513]

theorem envBound13731 : H12AffineFastState.Bounded env13731 := by
  intro p hp
  have h : env13731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13730_13731 : H12AffineEnvironment.transform 7 117 env13730 = env13731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13730 == env13731) = true)

theorem identity13731 : scanCanonicalize (H12AffineFastState.compose env13731 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13731 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env13732 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,120,4161,81,114,4177,2048,101,80,4160,112,65,82,120,65,2128,4176,4097,2048,68,112,117,112,4161,513]

theorem envBound13732 : H12AffineFastState.Bounded env13732 := by
  intro p hp
  have h : env13732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13731_13732 : H12AffineEnvironment.transform 9 101 env13731 = env13732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13731 == env13732) = true)

theorem identity13732 : scanCanonicalize (H12AffineFastState.compose env13732 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2160) := by decide +kernel

theorem selectedBound13732 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env13733 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,2160,120,2097,81,114,2081,2048,101,80,2096,112,65,82,120,65,2128,2080,2161,2048,68,112,117,112,2097,513]

theorem envBound13733 : H12AffineFastState.Bounded env13733 := by
  intro p hp
  have h : env13733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13732_13733 : H12AffineEnvironment.transform 11 2160 env13732 = env13733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2160 env13732 == env13733) = true)

theorem identity13733 : scanCanonicalize (H12AffineFastState.compose env13733 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13733 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13734 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2081,41,2097,0,35,2081,2048,52,1,2096,33,16,3,41,16,2049,2080,2080,2048,21,33,36,33,2097,513]

theorem envBound13734 : H12AffineFastState.Bounded env13734 := by
  intro p hp
  have h : env13734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13733_13734 : H12AffineEnvironment.transform 5 17 env13733 = env13734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13733 == env13734) = true)

theorem identity13734 : scanCanonicalize (H12AffineFastState.compose env13734 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound13734 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13735 : List Nat := [2,4,8,16,32,17,8,36,16,52,2048,2081,41,2097,0,35,2081,2048,52,1,2096,33,16,3,41,16,2049,2080,2080,2048,21,33,36,33,2097,17]

theorem envBound13735 : H12AffineFastState.Bounded env13735 := by
  intro p hp
  have h : env13735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13734_13735 : H12AffineEnvironment.transform 8 16 env13734 = env13735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env13734 == env13735) = true)

theorem identity13735 : scanCanonicalize (H12AffineFastState.compose env13735 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13736 : List Nat := [2,4,8,16,16,17,8,20,16,4,2048,2065,25,2049,0,19,2065,2048,4,1,2048,17,16,3,25,16,2049,2064,2064,2048,21,17,20,17,2049,17]

theorem envBound13736 : H12AffineFastState.Bounded env13736 := by
  intro p hp
  have h : env13736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13735_13736 : H12AffineEnvironment.transform 4 16 env13735 = env13736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13735 == env13736) = true)

theorem identity13736 : scanCanonicalize (H12AffineFastState.compose env13736 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound13736 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13737 : List Nat := [2,4,8,16,16,17,8,20,16,4,16,1,25,17,0,19,1,16,4,1,16,17,16,3,25,16,17,0,0,16,21,17,20,17,17,17]

theorem envBound13737 : H12AffineFastState.Bounded env13737 := by
  intro p hp
  have h : env13737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13736_13737 : H12AffineEnvironment.transform 10 16 env13736 = env13737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env13736 == env13737) = true)

theorem identity13737 : scanCanonicalize (H12AffineFastState.compose env13737 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13737 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13738 : List Nat := [2,4,8,0,0,1,8,4,0,4,0,1,9,1,0,3,1,0,4,1,0,1,0,3,9,0,1,0,0,0,5,1,4,1,1,1]

theorem envBound13738 : H12AffineFastState.Bounded env13738 := by
  intro p hp
  have h : env13738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13737_13738 : H12AffineEnvironment.transform 3 0 env13737 = env13738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13737 == env13738) = true)

def env13739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314420,272392,272440,95497,8192,65,270376,277817,45405,32041,317728,62588,256,21793,46093,392831]

theorem envBound13739 : H12AffineFastState.Bounded env13739 := by
  intro p hp
  have h : env13739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13724_13739 : H12AffineEnvironment.transform 16 38161 env13724 = env13739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13724 == env13739) = true)

theorem identity13739 : scanCanonicalize (H12AffineFastState.compose env13739 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound13739 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,38161,262144,1024,32769,314420,272392,272440,2,8192,65,270376,277817,45405,32041,317728,62588,256,21793,46093,297844]

theorem envBound13740 : H12AffineFastState.Bounded env13740 := by
  intro p hp
  have h : env13740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13739_13740 : H12AffineEnvironment.transform 15 29963 env13739 = env13740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env13739 == env13740) = true)

theorem identity13740 : scanCanonicalize (H12AffineFastState.compose env13740 (packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound13740 : packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env13741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,38161,2129,1024,32769,50277,8281,8297,2,8192,65,10361,13672,45405,32041,53617,62588,256,21793,46093,33573]

theorem envBound13741 : H12AffineFastState.Bounded env13741 := by
  intro p hp
  have h : env13741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13740_13741 : H12AffineEnvironment.transform 17 2129 env13740 = env13741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env13740 == env13741) = true)

theorem identity13741 : scanCanonicalize (H12AffineFastState.compose env13741 (packedSelected [1,3,8,10,12,15,16,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound13741 : packedSelected [1,3,8,10,12,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env13742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,29963,24633,2129,1024,29993,12621,8281,8297,2,8192,65,10361,13672,17525,32041,9305,340,256,21793,16677,30221]

theorem envBound13742 : H12AffineFastState.Bounded env13742 := by
  intro p hp
  have h : env13742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13741_13742 : H12AffineEnvironment.transform 14 29992 env13741 = env13742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env13741 == env13742) = true)

theorem identity13742 : scanCanonicalize (H12AffineFastState.compose env13742 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13742 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env13743 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,29822,24633,2129,1024,29788,12344,8281,8297,2,8192,65,10361,13341,17525,31836,9305,33,117,21588,16464,30221]

theorem envBound13743 : H12AffineFastState.Bounded env13743 := by
  intro p hp
  have h : env13743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13742_13743 : H12AffineEnvironment.transform 7 117 env13742 = env13743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13742 == env13743) = true)

theorem identity13743 : scanCanonicalize (H12AffineFastState.compose env13743 (packedSelected [0,3,5,7,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound13743 : packedSelected [0,3,5,7,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13744 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1052,16384,20545,20578,17445,2129,1024,20544,5156,1093,1141,2,1052,65,3173,4097,17525,22592,69,33,117,21588,16464,21009]

theorem envBound13744 : H12AffineFastState.Bounded env13744 := by
  intro p hp
  have h : env13744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13743_13744 : H12AffineEnvironment.transform 12 1052 env13743 = env13744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env13743 == env13744) = true)

theorem identity13744 : scanCanonicalize (H12AffineFastState.compose env13744 (packedSelected [2,4,6,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13744 : packedSelected [2,4,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env13745 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,120,16384,20545,20578,16449,2129,100,20544,4160,33,17,2,120,65,2049,4097,16401,22592,69,33,117,20528,16464,21009]

theorem envBound13745 : H12AffineFastState.Bounded env13745 := by
  intro p hp
  have h : env13745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13744_13745 : H12AffineEnvironment.transform 9 100 env13744 = env13745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13744 == env13745) = true)

theorem identity13745 : scanCanonicalize (H12AffineFastState.compose env13745 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound13745 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13746 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,120,4160,1,34,4097,2129,100,0,4160,33,17,2,120,65,2049,4097,4177,2048,69,33,117,112,4112,593]

theorem envBound13746 : H12AffineFastState.Bounded env13746 := by
  intro p hp
  have h : env13746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13745_13746 : H12AffineEnvironment.transform 13 4160 env13745 = env13746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env13745 == env13746) = true)

def env13747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441641,95497,8193,65,270377,436264,45404,32041,412721,156012,256,21793,46092,486255]

theorem envBound13747 : H12AffineFastState.Bounded env13747 := by
  intro p hp
  have h : env13747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13723_13747 : H12AffineEnvironment.transform 6 9 env13723 = env13747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13723 == env13747) = true)

def env13748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272441,95497,8193,65,270377,277816,45404,32041,317729,62588,256,21793,46092,392831]

theorem envBound13748 : H12AffineFastState.Bounded env13748 := by
  intro p hp
  have h : env13748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13747_13748 : H12AffineEnvironment.transform 16 38160 env13747 = env13748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env13747 == env13748) = true)

theorem identity13748 : scanCanonicalize (H12AffineFastState.compose env13748 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound13748 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1024,32769,314420,272393,272441,41311,8193,65,270377,277816,45404,32041,317729,62588,256,21793,46092,272937]

theorem envBound13749 : H12AffineFastState.Bounded env13749 := by
  intro p hp
  have h : env13749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13748_13749 : H12AffineEnvironment.transform 15 54358 env13748 = env13749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env13748 == env13749) = true)

theorem identity13749 : scanCanonicalize (H12AffineFastState.compose env13749 (packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13749 : packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env13750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21591,5393,262144,1024,0,281653,272393,272441,8542,8193,65,270377,277816,12637,32041,284960,29821,256,21793,13325,272937]

theorem envBound13750 : H12AffineFastState.Bounded env13750 := by
  intro p hp
  have h : env13750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13749_13750 : H12AffineEnvironment.transform 14 1 env13749 = env13750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13749 == env13750) = true)

theorem identity13750 : scanCanonicalize (H12AffineFastState.compose env13750 (packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound13750 : packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env13751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8202,5393,262144,1024,0,276584,272393,272441,8542,8193,65,270377,277816,12637,2420,273789,32,256,8572,13325,272937]

theorem envBound13751 : H12AffineFastState.Bounded env13751 := by
  intro p hp
  have h : env13751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13750_13751 : H12AffineEnvironment.transform 13 13405 env13750 = env13751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env13750 == env13751) = true)

theorem identity13751 : scanCanonicalize (H12AffineFastState.compose env13751 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound13751 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8202,5393,10361,1024,0,4113,112,64,8542,8193,65,2128,5441,12637,2420,1284,32,256,8572,13325,592]

theorem envBound13752 : H12AffineFastState.Bounded env13752 := by
  intro p hp
  have h : env13752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13751_13752 : H12AffineEnvironment.transform 17 10361 env13751 = env13752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env13751 == env13752) = true)

theorem identity13752 : scanCanonicalize (H12AffineFastState.compose env13752 (packedSelected [2,3,4,5,6,7,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound13752 : packedSelected [2,3,4,5,6,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env13753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,8192,10509,1,8202,2113,10361,1024,0,3393,112,64,8542,8193,65,2128,2065,11277,2420,1284,32,256,8572,10589,592]

theorem envBound13753 : H12AffineFastState.Bounded env13753 := by
  intro p hp
  have h : env13753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13752_13753 : H12AffineEnvironment.transform 11 3408 env13752 = env13753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env13752 == env13753) = true)

theorem identity13753 : scanCanonicalize (H12AffineFastState.compose env13753 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13753 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env13754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,268,2049,1,262,2113,2421,1024,0,3393,112,64,82,269,65,2128,2065,3329,2420,1284,32,256,112,2129,592]

theorem envBound13754 : H12AffineFastState.Bounded env13754 := by
  intro p hp
  have h : env13754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13753_13754 : H12AffineEnvironment.transform 12 268 env13753 = env13754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13753 == env13754) = true)

theorem identity13754 : scanCanonicalize (H12AffineFastState.compose env13754 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13754 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env13755 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,268,2049,1,262,2065,2341,1024,0,3345,32,16,2,269,17,2048,2065,3329,2340,1284,32,256,32,2049,512]

theorem envBound13755 : H12AffineFastState.Bounded env13755 := by
  intro p hp
  have h : env13755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13754_13755 : H12AffineEnvironment.transform 5 16 env13754 = env13755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13754 == env13755) = true)

theorem identity13755 : scanCanonicalize (H12AffineFastState.compose env13755 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13756 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,3328,268,2049,1,262,2065,2309,1024,0,3345,0,16,2,269,17,2048,2065,3329,2308,1284,0,256,0,2049,512]

theorem envBound13756 : H12AffineFastState.Bounded env13756 := by
  intro p hp
  have h : env13756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13755_13756 : H12AffineEnvironment.transform 4 0 env13755 = env13756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13755 == env13756) = true)

theorem identity13756 : scanCanonicalize (H12AffineFastState.compose env13756 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound13756 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13757 : List Nat := [2,4,8,16,0,16,9,256,271,1024,2048,3328,268,2049,1,262,2065,2309,1024,0,3345,0,16,2,269,17,2048,2065,3329,2308,1284,0,256,0,2049,271]

theorem envBound13757 : H12AffineFastState.Bounded env13757 := by
  intro p hp
  have h : env13757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13756_13757 : H12AffineEnvironment.transform 8 271 env13756 = env13757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env13756 == env13757) = true)

theorem identity13757 : scanCanonicalize (H12AffineFastState.compose env13757 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13757 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13758 : List Nat := [2,4,8,16,0,16,9,256,271,1024,0,1280,268,1,1,262,17,261,1024,0,1297,0,16,2,269,17,0,17,1281,260,1284,0,256,0,1,271]

theorem envBound13758 : H12AffineFastState.Bounded env13758 := by
  intro p hp
  have h : env13758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13757_13758 : H12AffineEnvironment.transform 10 0 env13757 = env13758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13757 == env13758) = true)

def env13759 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272440,95497,8193,65,270377,277817,45404,32041,317728,62589,256,21793,46092,392830]

theorem envBound13759 : H12AffineFastState.Bounded env13759 := by
  intro p hp
  have h : env13759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13747_13759 : H12AffineEnvironment.transform 16 38161 env13747 = env13759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13747 == env13759) = true)

theorem identity13759 : scanCanonicalize (H12AffineFastState.compose env13759 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound13759 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13760 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130175,1024,32769,77898,119926,119879,95497,8193,65,121942,115014,45404,32041,75103,62589,256,21793,46092,513]

theorem envBound13760 : H12AffineFastState.Bounded env13760 := by
  intro p hp
  have h : env13760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13759_13760 : H12AffineEnvironment.transform 17 130175 env13759 = env13760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env13759 == env13760) = true)

theorem identity13760 : scanCanonicalize (H12AffineFastState.compose env13760 (packedSelected [1,2,6,10,18,19,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound13760 : packedSelected [1,2,6,10,18,19,23,28] rootPS < 2^1333 := by decide +kernel

def env13761 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30042,38161,35109,1024,32769,17680,41260,41245,83,8193,65,43276,46108,45404,32041,20485,62589,256,21793,46092,513]

theorem envBound13761 : H12AffineFastState.Bounded env13761 := by
  intro p hp
  have h : env13761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13760_13761 : H12AffineEnvironment.transform 15 30042 env13760 = env13761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env13760 == env13761) = true)

theorem identity13761 : scanCanonicalize (H12AffineFastState.compose env13761 (packedSelected [0,1,7,8,12,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound13761 : packedSelected [0,1,7,8,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env13762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,30042,5440,2420,1024,80,17680,8573,8524,83,8193,65,10589,13389,12557,32041,20485,29740,256,21793,13405,513]

theorem envBound13762 : H12AffineFastState.Bounded env13762 := by
  intro p hp
  have h : env13762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13761_13762 : H12AffineEnvironment.transform 14 81 env13761 = env13762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env13761 == env13762) = true)

theorem identity13762 : scanCanonicalize (H12AffineFastState.compose env13762 (packedSelected [0,3,4,5,7,9,10,12,14,15,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound13762 : packedSelected [0,3,4,5,7,9,10,12,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env13763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,81,8203,5440,2420,1024,80,4161,8573,8524,83,8193,65,10589,13389,12557,10360,1364,8573,256,112,13405,513]

theorem envBound13763 : H12AffineFastState.Bounded env13763 := by
  intro p hp
  have h : env13763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13762_13763 : H12AffineEnvironment.transform 13 5457 env13762 = env13763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env13762 == env13763) = true)

theorem identity13763 : scanCanonicalize (H12AffineFastState.compose env13763 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 5912) := by decide +kernel

theorem selectedBound13763 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env13764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5912,5457,81,5907,5440,2420,1024,80,4161,5733,5716,83,5913,65,7749,853,1557,8032,1364,5733,256,112,837,513]

theorem envBound13764 : H12AffineFastState.Bounded env13764 := by
  intro p hp
  have h : env13764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13763_13764 : H12AffineEnvironment.transform 12 5912 env13763 = env13764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5912 env13763 == env13764) = true)

theorem identity13764 : scanCanonicalize (H12AffineFastState.compose env13764 (packedSelected [0,1,2,4,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound13764 : packedSelected [0,1,2,4,8,14] rootPS < 2^1333 := by decide +kernel

def env13765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1557,269,836,81,262,853,2420,1024,80,1620,112,65,83,268,65,2128,853,1557,2421,1364,112,256,112,837,513]

theorem envBound13765 : H12AffineFastState.Bounded env13765 := by
  intro p hp
  have h : env13765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13764_13765 : H12AffineEnvironment.transform 11 1557 env13764 = env13765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env13764 == env13765) = true)

theorem identity13765 : scanCanonicalize (H12AffineFastState.compose env13765 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13765 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13766 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1557,269,788,1,262,773,2340,1024,0,1540,32,17,3,268,17,2048,773,1557,2341,1284,32,256,32,789,513]

theorem envBound13766 : H12AffineFastState.Bounded env13766 := by
  intro p hp
  have h : env13766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13765_13766 : H12AffineEnvironment.transform 5 16 env13765 = env13766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13765 == env13766) = true)

theorem identity13766 : scanCanonicalize (H12AffineFastState.compose env13766 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound13766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13767 : List Nat := [2,4,8,16,32,16,9,256,512,5,2048,528,269,788,1,262,773,2340,5,0,513,32,17,3,268,17,2048,773,528,2341,257,32,256,32,789,513]

theorem envBound13767 : H12AffineFastState.Bounded env13767 := by
  intro p hp
  have h : env13767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13766_13767 : H12AffineEnvironment.transform 9 5 env13766 = env13767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env13766 == env13767) = true)

def env13768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441641,95497,8328,65,270497,436264,45525,32041,412721,156132,256,21793,46213,486374]

theorem envBound13768 : H12AffineFastState.Bounded env13768 := by
  intro p hp
  have h : env13768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13722_13768 : H12AffineEnvironment.transform 21 272513 env13722 = env13768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13722 == env13768) = true)

theorem identity13768 : scanCanonicalize (H12AffineFastState.compose env13768 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound13768 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58516,169400,16,95497,8328,65,171416,5393,45525,32041,61704,156132,256,21793,46213,120543]

theorem envBound13769 : H12AffineFastState.Bounded env13769 := by
  intro p hp
  have h : env13769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13768_13769 : H12AffineEnvironment.transform 17 179513 env13768 = env13769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env13768 == env13769) = true)

def env13770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58396,169264,16,95497,8192,65,171280,5393,45405,32041,61704,156012,256,21793,46093,120407]

theorem envBound13770 : H12AffineFastState.Bounded env13770 := by
  intro p hp
  have h : env13770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13769_13770 : H12AffineEnvironment.transform 6 8 env13769 = env13770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13769 == env13770) = true)

theorem identity13770 : scanCanonicalize (H12AffineFastState.compose env13770 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound13770 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,89379,1024,32769,58396,95530,16,95497,8192,65,97546,5393,45405,32041,61704,98678,256,21793,46093,120407]

theorem envBound13771 : H12AffineFastState.Bounded env13771 := by
  intro p hp
  have h : env13771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13770_13771 : H12AffineEnvironment.transform 16 122906 env13770 = env13771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env13770 == env13771) = true)

theorem identity13771 : scanCanonicalize (H12AffineFastState.compose env13771 (packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62591) := by decide +kernel

theorem selectedBound13771 : packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env13772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62591,5221,43356,1024,32769,58396,33109,16,33142,8192,65,35189,5393,45405,32041,61704,29961,256,21793,46093,8744]

theorem envBound13772 : H12AffineFastState.Bounded env13772 := by
  intro p hp
  have h : env13772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13771_13772 : H12AffineEnvironment.transform 15 62591 env13771 = env13772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62591 env13771 == env13772) = true)

theorem identity13772 : scanCanonicalize (H12AffineFastState.compose env13772 (packedSelected [2,3,5,6,9,10,11,12,14,15,19,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound13772 : packedSelected [2,3,5,6,9,10,11,12,14,15,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env13773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,32768,40971,5221,43356,1024,32769,45160,33109,16,33142,8192,65,35189,5393,45405,10589,42364,8573,256,341,46093,8744]

theorem envBound13773 : H12AffineFastState.Bounded env13773 := by
  intro p hp
  have h : env13773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13772_13773 : H12AffineEnvironment.transform 13 5236 env13772 = env13773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env13772 == env13773) = true)

theorem identity13773 : scanCanonicalize (H12AffineFastState.compose env13773 (packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13773 : packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env13774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8540,343,5221,2048,1024,8541,4404,8201,16,8234,8192,65,10281,5393,4097,10589,1056,8573,256,341,5457,8744]

theorem envBound13774 : H12AffineFastState.Bounded env13774 := by
  intro p hp
  have h : env13774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13773_13774 : H12AffineEnvironment.transform 14 8540 env13773 = env13774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13773 == env13774) = true)

theorem identity13774 : scanCanonicalize (H12AffineFastState.compose env13774 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13774 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env13775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,1,343,5221,2048,1024,0,4404,340,16,375,349,65,2420,5393,4097,2048,1056,32,256,341,5457,885]

theorem envBound13775 : H12AffineFastState.Bounded env13775 := by
  intro p hp
  have h : env13775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13774_13775 : H12AffineEnvironment.transform 12 349 env13774 = env13775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13774 == env13775) = true)

theorem identity13775 : scanCanonicalize (H12AffineFastState.compose env13775 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound13775 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13776 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,301,5124,1,295,5141,2048,1024,0,4404,292,16,263,301,49,2308,5393,4097,2048,1056,32,256,293,5409,773]

theorem envBound13776 : H12AffineFastState.Bounded env13776 := by
  intro p hp
  have h : env13776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13775_13776 : H12AffineEnvironment.transform 5 48 env13775 = env13776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env13775 == env13776) = true)

theorem identity13776 : scanCanonicalize (H12AffineFastState.compose env13776 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13776 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env13777 : List Nat := [2,4,8,16,32,48,8,4,512,1024,2048,4096,41,5124,1,35,5141,2048,1024,0,4144,32,16,3,41,49,2048,5141,4097,2048,1056,32,4,33,5157,513]

theorem envBound13777 : H12AffineFastState.Bounded env13777 := by
  intro p hp
  have h : env13777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13776_13777 : H12AffineEnvironment.transform 7 4 env13776 = env13777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13776 == env13777) = true)

theorem identity13777 : scanCanonicalize (H12AffineFastState.compose env13777 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound13777 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13778 : List Nat := [2,4,8,16,32,48,8,4,512,1024,1566,4096,41,5124,1,35,5141,1566,1024,0,4144,32,16,3,41,49,1566,5141,4097,1566,1056,32,4,33,5157,513]

theorem envBound13778 : H12AffineFastState.Bounded env13778 := by
  intro p hp
  have h : env13778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13777_13778 : H12AffineEnvironment.transform 10 1566 env13777 = env13778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env13777 == env13778) = true)

theorem identity13778 : scanCanonicalize (H12AffineFastState.compose env13778 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13778 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13779 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1566,4096,9,5124,1,3,5141,1566,1024,0,4112,0,16,3,9,17,1566,5141,4097,1566,1024,0,4,1,5125,513]

theorem envBound13779 : H12AffineFastState.Bounded env13779 := by
  intro p hp
  have h : env13779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13778_13779 : H12AffineEnvironment.transform 4 0 env13778 = env13779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13778 == env13779) = true)

def env13780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58397,169265,16,95497,8193,65,171281,5393,45404,32041,61704,156013,256,21793,46092,120406]

theorem envBound13780 : H12AffineFastState.Bounded env13780 := by
  intro p hp
  have h : env13780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13769_13780 : H12AffineEnvironment.transform 6 9 env13769 = env13780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13769 == env13780) = true)

theorem identity13780 : scanCanonicalize (H12AffineFastState.compose env13780 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound13780 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130175,1024,32769,58397,119927,16,95497,8193,65,121943,5393,45404,32041,61704,73771,256,21793,46092,120406]

theorem envBound13781 : H12AffineFastState.Bounded env13781 := by
  intro p hp
  have h : env13781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13780_13781 : H12AffineEnvironment.transform 16 82246 env13780 = env13781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env13780 == env13781) = true)

theorem identity13781 : scanCanonicalize (H12AffineFastState.compose env13781 (packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13781 : packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS < 2^1333 := by decide +kernel

def env13782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,82246,122146,1024,32769,50496,119927,16,87124,348,65,121943,5393,36865,23668,53333,65910,256,21793,38225,120406]

theorem envBound13782 : H12AffineFastState.Bounded env13782 := by
  intro p hp
  have h : env13782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13781_13782 : H12AffineEnvironment.transform 12 349 env13781 = env13782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13781 == env13782) = true)

def env13783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound13783 : H12AffineFastState.Bounded env13783 := by
  intro p hp
  have h : env13783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13593_13783 : H12AffineEnvironment.transform 18 1025 env13593 = env13783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13593 == env13783) = true)

theorem identity13783 : scanCanonicalize (H12AffineFastState.compose env13783 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound13783 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616289,18973837,10507601,8579233,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound13784 : H12AffineFastState.Bounded env13784 := by
  intro p hp
  have h : env13784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13783_13784 : H12AffineEnvironment.transform 17 10400 env13783 = env13784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env13783 == env13784) = true)

def env13785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616169,18973701,10507601,8579113,25265169,23160137,257,27378725,27337992,25207631]

theorem envBound13785 : H12AffineFastState.Bounded env13785 := by
  intro p hp
  have h : env13785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13784_13785 : H12AffineEnvironment.transform 6 8 env13784 = env13785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13784 == env13785) = true)

theorem identity13785 : scanCanonicalize (H12AffineFastState.compose env13785 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 8429902) := by decide +kernel

theorem selectedBound13785 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,8429902,8192,65,4409703,10560843,10507601,8579113,75103,14795783,257,2188651,2196550,513]

theorem envBound13786 : H12AffineFastState.Bounded env13786 := by
  intro p hp
  have h : env13786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13785_13786 : H12AffineEnvironment.transform 23 8429902 env13785 = env13786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429902 env13785 == env13786) = true)

def env13787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155532,2114882,8192,65,4409703,115015,45405,2231333,75103,4268043,257,2188651,2196550,513]

theorem envBound13787 : H12AffineFastState.Bounded env13787 := by
  intro p hp
  have h : env13787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13786_13787 : H12AffineEnvironment.transform 22 2155532 env13786 = env13787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env13786 == env13787) = true)

def env13788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114882,8192,65,215367,115015,45405,2231333,75103,73771,257,2188651,2196550,513]

theorem envBound13788 : H12AffineFastState.Bounded env13788 := by
  intro p hp
  have h : env13788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13787_13788 : H12AffineEnvironment.transform 21 32 env13787 = env13788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13787 == env13788) = true)

theorem identity13788 : scanCanonicalize (H12AffineFastState.compose env13788 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound13788 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,32,73754,98644,8192,65,215367,115015,45405,247859,75103,73771,257,41341,16464,513]

theorem envBound13789 : H12AffineFastState.Bounded env13789 := by
  intro p hp
  have h : env13789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13788_13789 : H12AffineEnvironment.transform 20 115734 env13788 = env13789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env13788 == env13789) = true)

theorem identity13789 : scanCanonicalize (H12AffineFastState.compose env13789 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13789 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115734,32,73754,98644,8192,65,67926,115015,45405,100386,75103,73771,257,41341,16464,513]

theorem envBound13790 : H12AffineFastState.Bounded env13790 := by
  intro p hp
  have h : env13790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13789_13790 : H12AffineEnvironment.transform 16 16401 env13789 = env13790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13789 == env13790) = true)

theorem identity13790 : scanCanonicalize (H12AffineFastState.compose env13790 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13790 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,58397,32,17,41311,8192,65,10589,57676,45405,43049,1364,32,257,41341,16464,513]

theorem envBound13791 : H12AffineFastState.Bounded env13791 := by
  intro p hp
  have h : env13791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13790_13791 : H12AffineEnvironment.transform 15 8203 env13790 = env13791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13790 == env13791) = true)

theorem identity13791 : scanCanonicalize (H12AffineFastState.compose env13791 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound13791 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8203,16401,10280,1025,81,25677,32,17,8463,8192,65,10589,24860,12557,10361,1364,32,257,8493,16464,513]

theorem envBound13792 : H12AffineFastState.Bounded env13792 := by
  intro p hp
  have h : env13792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13791_13792 : H12AffineEnvironment.transform 14 80 env13791 = env13792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env13791 == env13792) = true)

theorem identity13792 : scanCanonicalize (H12AffineFastState.compose env13792 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13792 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,80,343,16401,2420,1025,81,17681,32,17,83,348,65,2049,16448,4177,2341,1364,32,257,113,16464,513]

theorem envBound13793 : H12AffineFastState.Bounded env13793 := by
  intro p hp
  have h : env13793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13792_13793 : H12AffineEnvironment.transform 12 348 env13792 = env13793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13792 == env13793) = true)

theorem identity13793 : scanCanonicalize (H12AffineFastState.compose env13793 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13793 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13794 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1025,0,17681,32,17,2,269,16,2049,16401,4096,2341,1285,32,257,32,16385,513]

theorem envBound13794 : H12AffineFastState.Bounded env13794 := by
  intro p hp
  have h : env13794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13793_13794 : H12AffineEnvironment.transform 5 17 env13793 = env13794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13793 == env13794) = true)

theorem identity13794 : scanCanonicalize (H12AffineFastState.compose env13794 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13795 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2309,1025,0,17681,0,17,2,269,16,2049,16401,4096,2309,1285,0,257,0,16385,513]

theorem envBound13795 : H12AffineFastState.Bounded env13795 := by
  intro p hp
  have h : env13795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13794_13795 : H12AffineEnvironment.transform 4 0 env13794 = env13795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13794 == env13795) = true)

theorem identity13795 : scanCanonicalize (H12AffineFastState.compose env13795 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound13795 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13796 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,16,269,16384,1,262,16401,2309,1025,0,17681,0,17,2,269,16,2049,16401,16,2309,1285,0,257,0,16385,513]

theorem envBound13796 : H12AffineFastState.Bounded env13796 := by
  intro p hp
  have h : env13796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13795_13796 : H12AffineEnvironment.transform 11 16 env13795 = env13796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env13795 == env13796) = true)

theorem identity13796 : scanCanonicalize (H12AffineFastState.compose env13796 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1808) := by decide +kernel

theorem selectedBound13796 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13797 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,16,269,1808,1,262,1793,2309,1025,0,513,0,17,2,269,16,2049,1793,16,2309,1285,0,257,0,1809,513]

theorem envBound13797 : H12AffineFastState.Bounded env13797 := by
  intro p hp
  have h : env13797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13796_13797 : H12AffineEnvironment.transform 13 1808 env13796 = env13797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1808 env13796 == env13797) = true)

theorem identity13797 : scanCanonicalize (H12AffineFastState.compose env13797 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound13797 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13798 : List Nat := [2,4,8,16,0,17,8,256,512,1024,529,16,269,1808,1,262,1793,788,1025,0,513,0,17,2,269,16,528,1793,16,788,1285,0,257,0,1809,513]

theorem envBound13798 : H12AffineFastState.Bounded env13798 := by
  intro p hp
  have h : env13798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13797_13798 : H12AffineEnvironment.transform 10 529 env13797 = env13798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env13797 == env13798) = true)

theorem identity13798 : scanCanonicalize (H12AffineFastState.compose env13798 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound13798 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13799 : List Nat := [2,4,8,16,0,17,8,256,512,257,529,16,269,529,1,262,512,788,256,0,513,0,17,2,269,16,528,512,16,788,4,0,257,0,528,513]

theorem envBound13799 : H12AffineFastState.Bounded env13799 := by
  intro p hp
  have h : env13799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13798_13799 : H12AffineEnvironment.transform 9 257 env13798 = env13799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env13798 == env13799) = true)

theorem identity13799 : scanCanonicalize (H12AffineFastState.compose env13799 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound13799 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13800 : List Nat := [2,4,8,16,0,17,8,256,260,257,277,16,269,277,1,262,260,16,256,0,261,0,17,2,269,16,276,260,16,16,4,0,257,0,276,261]

theorem envBound13800 : H12AffineFastState.Bounded env13800 := by
  intro p hp
  have h : env13800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13799_13800 : H12AffineEnvironment.transform 8 260 env13799 = env13800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env13799 == env13800) = true)

def env13801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155532,2114882,8192,65,215366,115015,45405,2231333,75103,73770,257,2188651,2196550,513]

theorem envBound13801 : H12AffineFastState.Bounded env13801 := by
  intro p hp
  have h : env13801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13787_13801 : H12AffineEnvironment.transform 21 33 env13787 = env13801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13787 == env13801) = true)

theorem identity13801 : scanCanonicalize (H12AffineFastState.compose env13801 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13801 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,2097152,33,2155532,2114882,8192,65,158029,57676,45405,2231333,1364,33,257,2114912,2139213,513]

theorem envBound13802 : H12AffineFastState.Bounded env13802 := by
  intro p hp
  have h : env13802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13801_13802 : H12AffineEnvironment.transform 15 8203 env13801 = env13802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13801 == env13802) = true)

theorem identity13802 : scanCanonicalize (H12AffineFastState.compose env13802 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 173149) := by decide +kernel

theorem selectedBound13802 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env13803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,173149,33,147537,188703,8192,65,158029,57676,45405,43128,1364,33,257,188733,131088,513]

theorem envBound13803 : H12AffineFastState.Bounded env13803 := by
  intro p hp
  have h : env13803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13802_13803 : H12AffineEnvironment.transform 20 173149 env13802 = env13803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 173149 env13802 == env13803) = true)

theorem identity13803 : scanCanonicalize (H12AffineFastState.compose env13803 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound13803 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env13804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10280,1025,32769,50449,33,8477,32851,8192,65,2049,57676,45405,43128,1364,33,257,32881,24924,513]

theorem envBound13804 : H12AffineFastState.Bounded env13804 := by
  intro p hp
  have h : env13804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13803_13804 : H12AffineEnvironment.transform 16 24908 env13803 = env13804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env13803 == env13804) = true)

theorem identity13804 : scanCanonicalize (H12AffineFastState.compose env13804 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13804 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,16448,2340,1025,32769,50449,33,17,32851,268,65,2049,49216,36945,35188,1364,33,257,32881,16464,513]

theorem envBound13805 : H12AffineFastState.Bounded env13805 := by
  intro p hp
  have h : env13805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13804_13805 : H12AffineEnvironment.transform 12 268 env13804 = env13805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13804 == env13805) = true)

theorem identity13805 : scanCanonicalize (H12AffineFastState.compose env13805 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13805 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env13806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,1,263,16448,2340,1025,0,17680,33,17,82,268,65,2049,16449,4176,2421,1364,33,257,112,16464,513]

theorem envBound13806 : H12AffineFastState.Bounded env13806 := by
  intro p hp
  have h : env13806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13805_13806 : H12AffineEnvironment.transform 14 1 env13805 = env13806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13805 == env13806) = true)

theorem identity13806 : scanCanonicalize (H12AffineFastState.compose env13806 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13806 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13807 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16401,2340,1025,0,17680,33,17,3,268,16,2049,16400,4097,2340,1285,33,257,33,16385,513]

theorem envBound13807 : H12AffineFastState.Bounded env13807 := by
  intro p hp
  have h : env13807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13806_13807 : H12AffineEnvironment.transform 5 17 env13806 = env13807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13806 == env13807) = true)

theorem identity13807 : scanCanonicalize (H12AffineFastState.compose env13807 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound13807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13808 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4113,1,263,4096,2340,1025,0,5377,33,17,3,268,16,2049,4097,4097,2340,1285,33,257,33,4112,513]

theorem envBound13808 : H12AffineFastState.Bounded env13808 := by
  intro p hp
  have h : env13808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13807_13808 : H12AffineEnvironment.transform 13 4113 env13807 = env13808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env13807 == env13808) = true)

theorem identity13808 : scanCanonicalize (H12AffineFastState.compose env13808 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound13808 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13809 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,309,268,292,1,263,309,2340,1025,0,1076,33,17,3,268,16,2049,308,308,2340,1285,33,257,33,293,513]

theorem envBound13809 : H12AffineFastState.Bounded env13809 := by
  intro p hp
  have h : env13809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13808_13809 : H12AffineEnvironment.transform 11 309 env13808 = env13809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env13808 == env13809) = true)

theorem identity13809 : scanCanonicalize (H12AffineFastState.compose env13809 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13809 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13810 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,17,40,0,1,35,17,2048,1025,0,1076,33,17,3,40,16,2049,16,16,2048,1057,33,37,33,1,513]

theorem envBound13810 : H12AffineFastState.Bounded env13810 := by
  intro p hp
  have h : env13810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13809_13810 : H12AffineEnvironment.transform 7 36 env13809 = env13810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13809 == env13810) = true)

theorem identity13810 : scanCanonicalize (H12AffineFastState.compose env13810 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound13810 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13811 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,17,40,0,1,35,17,1077,1025,0,1076,33,17,3,40,16,1076,16,16,1077,1057,33,37,33,1,513]

theorem envBound13811 : H12AffineFastState.Bounded env13811 := by
  intro p hp
  have h : env13811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13810_13811 : H12AffineEnvironment.transform 10 1077 env13810 = env13811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env13810 == env13811) = true)

end H12CloudChart1