import H12CloudChart1Data019

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity4943 : scanCanonicalize (H12AffineFastState.compose env4943 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 3598) := by decide +kernel

theorem selectedBound4943 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env4944 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,3598,8200,15908,4097,8712,1024,8200,4097,5156,5125,35,8224,5125,15398,3598,3598,5678,6671,7695,5,7695,1029,5636]

theorem envBound4944 : H12AffineFastState.Bounded env4944 := by
  intro p hp
  have h : env4944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4943_4944 : H12AffineEnvironment.transform 13 3598 env4943 = env4944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3598 env4943 == env4944) = true)

theorem identity4944 : scanCanonicalize (H12AffineFastState.compose env4944 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound4944 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4945 : List Nat := [2,4,8,0,32,0,41,5,512,1024,522,4096,8192,1028,8200,13358,4097,8712,1024,8200,4097,5156,5125,35,8224,5125,13868,1028,1028,5678,4101,5125,5,5125,1029,5636]

theorem envBound4945 : H12AffineFastState.Bounded env4945 := by
  intro p hp
  have h : env4945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4944_4945 : H12AffineEnvironment.transform 10 522 env4944 = env4945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env4944 == env4945) = true)

theorem identity4945 : scanCanonicalize (H12AffineFastState.compose env4945 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound4945 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4946 : List Nat := [2,4,8,0,32,0,41,5,512,558,522,4096,8192,554,8200,12800,4097,8712,558,8200,4097,4618,4651,35,8224,4651,12290,554,554,4096,4101,4651,5,4651,555,4138]

theorem envBound4946 : H12AffineFastState.Bounded env4946 := by
  intro p hp
  have h : env4946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4945_4946 : H12AffineEnvironment.transform 9 558 env4945 = env4946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env4945 == env4946) = true)

theorem identity4946 : scanCanonicalize (H12AffineFastState.compose env4946 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4137) := by decide +kernel

theorem selectedBound4946 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4947 : List Nat := [2,4,8,0,32,0,41,5,512,558,522,4096,4137,554,4129,553,4097,4641,558,4129,4097,4618,4651,35,4105,4651,43,554,554,4096,4101,4651,5,4651,555,4138]

theorem envBound4947 : H12AffineFastState.Bounded env4947 := by
  intro p hp
  have h : env4947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4946_4947 : H12AffineEnvironment.transform 12 4137 env4946 = env4947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4137 env4946 == env4947) = true)

theorem identity4947 : scanCanonicalize (H12AffineFastState.compose env4947 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound4947 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4948 : List Nat := [2,4,8,0,32,0,41,5,512,558,522,513,552,554,544,553,512,32,558,544,512,11,42,35,520,42,43,554,554,513,516,42,5,42,555,555]

theorem envBound4948 : H12AffineFastState.Bounded env4948 := by
  intro p hp
  have h : env4948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4947_4948 : H12AffineEnvironment.transform 11 513 env4947 = env4948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env4947 == env4948) = true)

def env4949 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1024,32768,4097,46124,8388608,41003,8329,8388608,323713,16384,16385,22560,62625,8406189,173,20481,1196,8389121]

theorem envBound4949 : H12AffineFastState.Bounded env4949 := by
  intro p hp
  have h : env4949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4938_4949 : H12AffineEnvironment.transform 3 1 env4938 = env4949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4938 == env4949) = true)

def env4950 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8352,28714,4096,262144,1024,8352,4097,5260,8388608,139,8329,8388608,282657,16384,16385,22560,21505,8406189,173,20481,1196,8389121]

theorem envBound4950 : H12AffineFastState.Bounded env4950 := by
  intro p hp
  have h : env4950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4949_4950 : H12AffineEnvironment.transform 14 8352 env4949 = env4950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env4949 == env4950) = true)

theorem identity4950 : scanCanonicalize (H12AffineFastState.compose env4950 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 7204) := by decide +kernel

theorem selectedBound4950 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4951 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8352,28714,4096,7204,1024,8352,4097,5260,8388608,139,8329,8388608,19461,16384,16385,22560,21505,8406189,173,20481,1196,8389121]

theorem envBound4951 : H12AffineFastState.Bounded env4951 := by
  intro p hp
  have h : env4951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4950_4951 : H12AffineEnvironment.transform 17 7204 env4950 = env4951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7204 env4950 == env4951) = true)

theorem identity4951 : scanCanonicalize (H12AffineFastState.compose env4951 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(22+1) ^^^ 6307) := by decide +kernel

theorem selectedBound4951 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env4952 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8352,28714,4096,7204,1024,8352,4097,5260,6307,139,8329,6307,19461,16384,16385,22560,21505,23566,173,20481,1196,6818]

theorem envBound4952 : H12AffineFastState.Bounded env4952 := by
  intro p hp
  have h : env4952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4951_4952 : H12AffineEnvironment.transform 22 6307 env4951 = env4952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6307 env4951 == env4952) = true)

theorem identity4952 : scanCanonicalize (H12AffineFastState.compose env4952 (packedSelected [1,3,4,8,10,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 7814) := by decide +kernel

theorem selectedBound4952 : packedSelected [1,3,4,8,10,20,22,24] rootPS < 2^1333 := by decide +kernel

def env4953 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,7814,8352,11948,4096,7204,1024,8352,4097,5260,6307,139,8329,6307,4739,7814,7815,1702,2695,648,173,3719,1196,6818]

theorem envBound4953 : H12AffineFastState.Bounded env4953 := by
  intro p hp
  have h : env4953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4952_4953 : H12AffineEnvironment.transform 13 7814 env4952 = env4953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7814 env4952 == env4953) = true)

theorem identity4953 : scanCanonicalize (H12AffineFastState.compose env4953 (packedSelected [1,2,4,5,6,10,12,13,15,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4953 : packedSelected [1,2,4,5,6,10,12,13,15,20,22] rootPS < 2^1333 := by decide +kernel

def env4954 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1197,8192,2603,8352,11948,1197,2185,1024,8352,1196,33,3086,139,8329,3086,1582,2603,2602,1702,2695,648,173,3719,1196,3599]

theorem envBound4954 : H12AffineFastState.Bounded env4954 := by
  intro p hp
  have h : env4954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4953_4954 : H12AffineEnvironment.transform 11 1197 env4953 = env4954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env4953 == env4954) = true)

theorem identity4954 : scanCanonicalize (H12AffineFastState.compose env4954 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound4954 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4955 : List Nat := [2,4,8,1,32,1,128,173,512,1024,1190,1197,8192,1677,8352,8714,1197,1071,1024,8352,1196,33,168,139,8329,168,1582,1677,1676,1702,1569,648,173,545,1196,681]

theorem envBound4955 : H12AffineFastState.Bounded env4955 := by
  intro p hp
  have h : env4955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4954_4955 : H12AffineEnvironment.transform 10 1190 env4954 = env4955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env4954 == env4955) = true)

theorem identity4955 : scanCanonicalize (H12AffineFastState.compose env4955 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound4955 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4956 : List Nat := [2,4,8,1,32,1,128,173,137,1024,1190,1197,8192,1028,8352,8323,1197,1071,1024,8352,1196,33,168,139,8329,168,1191,1028,1029,1071,1192,1,173,168,1196,32]

theorem envBound4956 : H12AffineFastState.Bounded env4956 := by
  intro p hp
  have h : env4956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4955_4956 : H12AffineEnvironment.transform 8 137 env4955 = env4956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env4955 == env4956) = true)

theorem identity4956 : scanCanonicalize (H12AffineFastState.compose env4956 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound4956 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4957 : List Nat := [2,4,8,1,32,1,128,173,137,1024,1190,1197,1063,1028,1159,1188,1197,1071,1024,1159,1196,33,168,139,1198,168,1191,1028,1029,1071,1192,1,173,168,1196,32]

theorem envBound4957 : H12AffineFastState.Bounded env4957 := by
  intro p hp
  have h : env4957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4956_4957 : H12AffineEnvironment.transform 12 1063 env4956 = env4957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env4956 == env4957) = true)

theorem identity4957 : scanCanonicalize (H12AffineFastState.compose env4957 (packedSelected [1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound4957 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env4958 : List Nat := [2,4,8,1,32,1,128,173,137,5,163,168,34,1,130,161,168,42,5,130,169,33,168,139,171,168,162,1,0,42,173,1,173,168,169,32]

theorem envBound4958 : H12AffineFastState.Bounded env4958 := by
  intro p hp
  have h : env4958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4957_4958 : H12AffineEnvironment.transform 9 5 env4957 = env4958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env4957 == env4958) = true)

theorem identity4958 : scanCanonicalize (H12AffineFastState.compose env4958 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound4958 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4959 : List Nat := [2,4,8,1,32,1,9,36,0,5,42,33,34,1,11,40,33,42,5,11,32,33,33,2,34,33,43,1,0,42,36,1,36,33,32,32]

theorem envBound4959 : H12AffineFastState.Bounded env4959 := by
  intro p hp
  have h : env4959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4958_4959 : H12AffineEnvironment.transform 6 9 env4958 = env4959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env4958 == env4959) = true)

theorem identity4959 : scanCanonicalize (H12AffineFastState.compose env4959 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4960 : List Nat := [2,4,3,1,32,1,2,36,0,5,33,33,34,1,0,35,33,33,5,0,32,33,33,2,34,33,32,1,0,33,36,1,36,33,32,32]

theorem envBound4960 : H12AffineFastState.Bounded env4960 := by
  intro p hp
  have h : env4960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4959_4960 : H12AffineEnvironment.transform 2 3 env4959 = env4960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4959 == env4960) = true)

theorem identity4960 : scanCanonicalize (H12AffineFastState.compose env4960 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4960 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4961 : List Nat := [2,4,3,1,0,1,2,4,0,5,1,1,2,1,0,3,1,1,5,0,0,1,1,2,2,1,0,1,0,1,4,1,4,1,0,0]

theorem envBound4961 : H12AffineFastState.Bounded env4961 := by
  intro p hp
  have h : env4961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4960_4961 : H12AffineEnvironment.transform 4 0 env4960 = env4961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4960 == env4961) = true)

def env4962 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8353,28715,4096,262144,1024,8353,4097,5261,8388608,138,8329,8388608,282656,16384,16385,22560,21504,8406189,173,20481,1196,8389121]

theorem envBound4962 : H12AffineFastState.Bounded env4962 := by
  intro p hp
  have h : env4962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4949_4962 : H12AffineEnvironment.transform 14 8353 env4949 = env4962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env4949 == env4962) = true)

theorem identity4962 : scanCanonicalize (H12AffineFastState.compose env4962 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 284704) := by decide +kernel

theorem selectedBound4962 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4963 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8353,28715,4096,262144,1024,8353,4097,5261,284704,138,8329,284704,282656,16384,16385,22560,21504,269453,173,20481,1196,285217]

theorem envBound4963 : H12AffineFastState.Bounded env4963 := by
  intro p hp
  have h : env4963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4962_4963 : H12AffineEnvironment.transform 22 284704 env4962 = env4963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284704 env4962 == env4963) = true)

theorem identity4963 : scanCanonicalize (H12AffineFastState.compose env4963 (packedSelected [0,2,3,4,5,7,9,10,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 18976) := by decide +kernel

theorem selectedBound4963 : packedSelected [0,2,3,4,5,7,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env4964 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,8353,28715,4096,18976,1024,8353,4097,5261,4608,138,8329,4608,6656,16384,16385,22560,21504,22189,173,20481,1196,4097]

theorem envBound4964 : H12AffineFastState.Bounded env4964 := by
  intro p hp
  have h : env4964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4963_4964 : H12AffineEnvironment.transform 17 18976 env4963 = env4964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18976 env4963 == env4964) = true)

theorem identity4964 : scanCanonicalize (H12AffineFastState.compose env4964 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(13+1) ^^^ 15879) := by decide +kernel

theorem selectedBound4964 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env4965 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,15879,8353,3628,4096,13351,1024,8353,4097,5261,4608,138,8329,4608,6656,15879,15878,9767,10759,10410,173,11782,1196,4097]

theorem envBound4965 : H12AffineFastState.Bounded env4965 := by
  intro p hp
  have h : env4965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4964_4965 : H12AffineEnvironment.transform 13 15879 env4964 = env4965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15879 env4964 == env4965) = true)

theorem identity4965 : scanCanonicalize (H12AffineFastState.compose env4965 (packedSelected [1,2,3,4,8,10,13,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 7343) := by decide +kernel

theorem selectedBound4965 : packedSelected [1,2,3,4,8,10,13,22,24] rootPS < 2^1333 := by decide +kernel

def env4966 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,7343,680,7182,3628,4096,2184,1024,7182,4097,5261,4608,138,7206,4608,6656,680,681,6792,5800,5125,173,4777,1196,4097]

theorem envBound4966 : H12AffineFastState.Bounded env4966 := by
  intro p hp
  have h : env4966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4965_4966 : H12AffineEnvironment.transform 12 7343 env4965 = env4966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7343 env4965 == env4966) = true)

theorem identity4966 : scanCanonicalize (H12AffineFastState.compose env4966 (packedSelected [3,4,5,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound4966 : packedSelected [3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env4967 : List Nat := [2,4,8,1,32,1,128,173,512,37,2048,4096,6282,680,6187,2569,4096,2184,37,6187,4097,4264,4608,138,6147,4608,6656,680,681,6792,4749,4128,173,4777,137,4097]

theorem envBound4967 : H12AffineFastState.Bounded env4967 := by
  intro p hp
  have h : env4967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4966_4967 : H12AffineEnvironment.transform 9 37 env4966 = env4967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env4966 == env4967) = true)

theorem identity4967 : scanCanonicalize (H12AffineFastState.compose env4967 (packedSelected [1,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound4967 : packedSelected [1,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env4968 : List Nat := [2,4,8,1,32,1,128,173,512,37,2048,2602,672,680,513,2569,2602,2184,37,513,2603,2690,2090,138,553,2090,42,680,681,162,2215,2570,173,2179,137,2603]

theorem envBound4968 : H12AffineFastState.Bounded env4968 := by
  intro p hp
  have h : env4968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4967_4968 : H12AffineEnvironment.transform 11 2602 env4967 = env4968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env4967 == env4968) = true)

theorem identity4968 : scanCanonicalize (H12AffineFastState.compose env4968 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound4968 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env4969 : List Nat := [2,4,8,1,32,1,128,173,512,37,642,168,672,680,513,139,168,522,37,513,169,0,680,138,553,680,42,680,681,162,549,136,173,513,137,169]

theorem envBound4969 : H12AffineFastState.Bounded env4969 := by
  intro p hp
  have h : env4969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4968_4969 : H12AffineEnvironment.transform 10 642 env4968 = env4969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env4968 == env4969) = true)

theorem identity4969 : scanCanonicalize (H12AffineFastState.compose env4969 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound4969 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env4970 : List Nat := [2,4,8,1,32,1,35,14,512,37,545,11,515,523,513,40,11,522,37,513,10,0,523,41,553,523,42,523,522,1,549,43,14,513,42,10]

theorem envBound4970 : H12AffineFastState.Bounded env4970 := by
  intro p hp
  have h : env4970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4969_4970 : H12AffineEnvironment.transform 6 35 env4969 = env4970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env4969 == env4970) = true)

theorem identity4970 : scanCanonicalize (H12AffineFastState.compose env4970 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4970 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env4971 : List Nat := [2,4,8,1,0,1,3,14,512,5,513,11,515,523,513,8,11,522,5,513,10,0,523,9,521,523,10,523,522,1,517,11,14,513,10,10]

theorem envBound4971 : H12AffineFastState.Bounded env4971 := by
  intro p hp
  have h : env4971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4970_4971 : H12AffineEnvironment.transform 4 0 env4970 = env4971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4970 == env4971) = true)

theorem identity4971 : scanCanonicalize (H12AffineFastState.compose env4971 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4971 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4972 : List Nat := [2,4,8,1,0,1,3,14,0,5,1,11,3,11,1,8,11,10,5,1,10,0,11,9,9,11,10,11,10,1,5,11,14,1,10,10]

theorem envBound4972 : H12AffineFastState.Bounded env4972 := by
  intro p hp
  have h : env4972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4971_4972 : H12AffineEnvironment.transform 8 0 env4971 = env4972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4971 == env4972) = true)

theorem identity4972 : scanCanonicalize (H12AffineFastState.compose env4972 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4973 : List Nat := [2,4,2,1,0,1,3,4,0,5,1,1,3,1,1,2,1,0,5,1,0,0,1,3,3,1,0,1,0,1,5,1,4,1,0,0]

theorem envBound4973 : H12AffineFastState.Bounded env4973 := by
  intro p hp
  have h : env4973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4972_4973 : H12AffineEnvironment.transform 2 2 env4972 = env4973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4972 == env4973) = true)

def env4974 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4097,46125,8388608,41003,8329,8388608,323713,16384,16401,22560,74795,8406189,189,20481,1197,8389120]

theorem envBound4974 : H12AffineFastState.Bounded env4974 := by
  intro p hp
  have h : env4974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4936_4974 : H12AffineEnvironment.transform 7 189 env4936 = env4974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env4936 == env4974) = true)

theorem identity4974 : scanCanonicalize (H12AffineFastState.compose env4974 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 46109) := by decide +kernel

theorem selectedBound4974 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env4975 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4097,46125,46109,41003,8329,46109,323713,16384,16401,22560,74795,61616,189,20481,1197,46621]

theorem envBound4975 : H12AffineFastState.Bounded env4975 := by
  intro p hp
  have h : env4975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4974_4975 : H12AffineEnvironment.transform 22 46109 env4974 = env4975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46109 env4974 == env4975) = true)

def env4976 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,4097,46125,46093,41003,8329,46093,323713,16384,16385,22560,74795,61600,173,20481,1197,46605]

theorem envBound4976 : H12AffineFastState.Bounded env4976 := by
  intro p hp
  have h : env4976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4975_4976 : H12AffineEnvironment.transform 3 0 env4975 = env4976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4975 == env4976) = true)

theorem identity4976 : scanCanonicalize (H12AffineFastState.compose env4976 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound4976 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env4977 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,262144,1024,32768,4097,46125,46093,41003,8329,46093,323713,16384,16385,22560,62473,61600,173,20481,1197,46605]

theorem envBound4977 : H12AffineFastState.Bounded env4977 := by
  intro p hp
  have h : env4977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4976_4977 : H12AffineEnvironment.transform 15 53282 env4976 = env4977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env4976 == env4977) = true)

theorem identity4977 : scanCanonicalize (H12AffineFastState.compose env4977 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 63528) := by decide +kernel

theorem selectedBound4977 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4978 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,63528,1024,32768,4097,46125,46093,41003,8329,46093,2217,16384,16385,22560,62473,61600,173,20481,1197,46605]

theorem envBound4978 : H12AffineFastState.Bounded env4978 := by
  intro p hp
  have h : env4978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4977_4978 : H12AffineEnvironment.transform 17 63528 env4977 = env4978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63528 env4977 == env4978) = true)

theorem identity4978 : scanCanonicalize (H12AffineFastState.compose env4978 (packedSelected [0,3,5,7,10,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4978 : packedSelected [0,3,5,7,10,18,20,23] rootPS < 2^1333 := by decide +kernel

def env4979 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,29225,8715,4096,2561,1024,29225,4097,17924,17956,20994,8329,17956,2217,16384,16385,22560,1568,649,173,20481,1197,17444]

theorem envBound4979 : H12AffineFastState.Bounded env4979 := by
  intro p hp
  have h : env4979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4978_4979 : H12AffineEnvironment.transform 14 29225 env4978 = env4979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4978 == env4979) = true)

theorem identity4979 : scanCanonicalize (H12AffineFastState.compose env4979 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4979 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env4980 : List Nat := [2,4,8,0,32,0,128,173,32,1024,2048,4096,8192,16384,28681,8235,4096,2081,1024,28681,4097,17444,17412,20514,8329,17412,2217,16384,16385,22560,1024,169,173,20481,1197,17444]

theorem envBound4980 : H12AffineFastState.Bounded env4980 := by
  intro p hp
  have h : env4980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4979_4980 : H12AffineEnvironment.transform 8 32 env4979 = env4980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4979 == env4980) = true)

theorem identity4980 : scanCanonicalize (H12AffineFastState.compose env4980 (packedSelected [0,1,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound4980 : packedSelected [0,1,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env4981 : List Nat := [2,4,8,0,32,0,128,173,32,1024,1191,4096,8192,16384,28681,8235,4096,1158,1024,28681,4097,17444,17412,20514,8329,17412,1038,16384,16385,21639,1024,169,173,20481,1197,17444]

theorem envBound4981 : H12AffineFastState.Bounded env4981 := by
  intro p hp
  have h : env4981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4980_4981 : H12AffineEnvironment.transform 10 1191 env4980 = env4981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env4980 == env4981) = true)

theorem identity4981 : scanCanonicalize (H12AffineFastState.compose env4981 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound4981 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env4982 : List Nat := [2,4,8,0,32,0,128,173,32,1024,1191,4096,8192,4096,8201,8235,4096,1158,1024,8201,4097,5156,5124,34,8329,5124,1038,4096,4097,1159,1024,169,173,1,1197,5156]

theorem envBound4982 : H12AffineFastState.Bounded env4982 := by
  intro p hp
  have h : env4982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4981_4982 : H12AffineEnvironment.transform 13 4096 env4981 = env4982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4981 == env4982) = true)

def env4983 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4097,46125,46092,41003,8329,46092,323713,16384,16384,22560,74795,61601,172,20481,1197,46604]

theorem envBound4983 : H12AffineFastState.Bounded env4983 := by
  intro p hp
  have h : env4983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4975_4983 : H12AffineEnvironment.transform 3 1 env4975 = env4983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4975 == env4983) = true)

theorem identity4983 : scanCanonicalize (H12AffineFastState.compose env4983 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4983 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env4984 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,1024,8200,4097,5157,5124,35,8329,5124,282761,16384,16384,22560,74795,20649,172,20481,1197,5636]

theorem envBound4984 : H12AffineFastState.Bounded env4984 := by
  intro p hp
  have h : env4984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4983_4984 : H12AffineEnvironment.transform 14 8200 env4983 = env4984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4983 == env4984) = true)

theorem identity4984 : scanCanonicalize (H12AffineFastState.compose env4984 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 13446) := by decide +kernel

theorem selectedBound4984 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4985 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,8200,13446,4097,262144,1024,8200,4097,5157,5124,35,8329,5124,282761,16384,16384,22560,4269,20649,172,20481,1197,5636]

theorem envBound4985 : H12AffineFastState.Bounded env4985 := by
  intro p hp
  have h : env4985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4984_4985 : H12AffineEnvironment.transform 15 13446 env4984 = env4985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13446 env4984 == env4985) = true)

theorem identity4985 : scanCanonicalize (H12AffineFastState.compose env4985 (packedSelected [0,2,7,11,13,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 23209) := by decide +kernel

theorem selectedBound4985 : packedSelected [0,2,7,11,13,18,20,21] rootPS < 2^1333 := by decide +kernel

def env4986 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,8200,13446,4097,23209,1024,8200,4097,5157,5124,35,8329,5124,2592,16384,16384,22560,4269,20649,172,20481,1197,5636]

theorem envBound4986 : H12AffineFastState.Bounded env4986 := by
  intro p hp
  have h : env4986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4985_4986 : H12AffineEnvironment.transform 17 23209 env4985 = env4986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23209 env4985 == env4986) = true)

theorem identity4986 : scanCanonicalize (H12AffineFastState.compose env4986 (packedSelected [0,1,3,7,12,13,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound4986 : packedSelected [0,1,3,7,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env4987 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,1028,8200,13446,4097,7853,1024,8200,4097,5157,5124,35,8329,5124,2592,1028,1028,7204,4269,5293,172,5125,1197,5636]

theorem envBound4987 : H12AffineFastState.Bounded env4987 := by
  intro p hp
  have h : env4987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4986_4987 : H12AffineEnvironment.transform 13 1028 env4986 = env4987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env4986 == env4987) = true)

theorem identity4987 : scanCanonicalize (H12AffineFastState.compose env4987 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 3751) := by decide +kernel

theorem selectedBound4987 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4988 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,3751,8192,1028,8200,10785,3750,10,1024,8200,3750,2690,2723,35,8329,2723,2592,1028,1028,643,3594,2570,172,2722,1197,2211]

theorem envBound4988 : H12AffineFastState.Bounded env4988 := by
  intro p hp
  have h : env4988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4987_4988 : H12AffineEnvironment.transform 11 3751 env4987 = env4988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3751 env4987 == env4988) = true)

theorem identity4988 : scanCanonicalize (H12AffineFastState.compose env4988 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 641) := by decide +kernel

theorem selectedBound4988 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env4989 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,3751,641,1028,649,2208,3750,10,1024,649,3750,2690,2723,35,520,2723,2592,1028,1028,643,3594,2570,172,2722,1197,2211]

theorem envBound4989 : H12AffineFastState.Bounded env4989 := by
  intro p hp
  have h : env4989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4988_4989 : H12AffineEnvironment.transform 12 641 env4988 = env4989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env4988 == env4989) = true)

theorem identity4989 : scanCanonicalize (H12AffineFastState.compose env4989 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound4989 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4990 : List Nat := [2,4,8,1,32,1,128,172,512,1024,1061,642,641,1028,649,1157,643,10,1024,649,643,1703,1670,35,520,1670,1541,1028,1028,643,559,1583,172,1671,1197,1158]

theorem envBound4990 : H12AffineFastState.Bounded env4990 := by
  intro p hp
  have h : env4990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4989_4990 : H12AffineEnvironment.transform 10 1061 env4989 = env4990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env4989 == env4990) = true)

theorem identity4990 : scanCanonicalize (H12AffineFastState.compose env4990 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4990 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env4991 : List Nat := [2,4,8,1,32,1,40,4,512,1024,1061,554,553,1028,545,1069,555,10,1024,545,555,1551,1582,35,520,1582,1541,1028,1028,555,559,1583,4,1583,1029,1070]

theorem envBound4991 : H12AffineFastState.Bounded env4991 := by
  intro p hp
  have h : env4991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4990_4991 : H12AffineEnvironment.transform 6 40 env4990 = env4991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4990 == env4991) = true)

theorem identity4991 : scanCanonicalize (H12AffineFastState.compose env4991 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound4991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4992 : List Nat := [2,4,8,1,32,1,40,4,512,15,42,554,553,11,545,34,555,10,15,545,555,512,545,35,520,545,522,11,11,555,559,544,4,544,10,33]

theorem envBound4992 : H12AffineFastState.Bounded env4992 := by
  intro p hp
  have h : env4992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4991_4992 : H12AffineEnvironment.transform 9 15 env4991 = env4992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env4991 == env4992) = true)

theorem identity4992 : scanCanonicalize (H12AffineFastState.compose env4992 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound4992 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4993 : List Nat := [2,4,8,1,32,1,40,4,10,15,42,32,35,11,43,34,33,10,15,43,33,10,43,35,2,43,0,11,11,33,37,42,4,42,10,33]

theorem envBound4993 : H12AffineFastState.Bounded env4993 := by
  intro p hp
  have h : env4993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4992_4993 : H12AffineEnvironment.transform 8 10 env4992 = env4993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env4992 == env4993) = true)

theorem identity4993 : scanCanonicalize (H12AffineFastState.compose env4993 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4994 : List Nat := [2,4,8,1,1,1,9,4,10,15,11,1,2,11,10,3,0,10,15,10,0,10,10,2,2,10,0,11,11,0,4,11,4,11,10,0]

theorem envBound4994 : H12AffineFastState.Bounded env4994 := by
  intro p hp
  have h : env4994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4993_4994 : H12AffineEnvironment.transform 4 1 env4993 = env4994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4993 == env4994) = true)

theorem identity4994 : scanCanonicalize (H12AffineFastState.compose env4994 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4994 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4995 : List Nat := [2,4,3,1,1,1,2,4,1,4,0,1,2,0,1,3,0,1,4,1,0,1,1,2,2,1,0,0,0,0,4,0,4,0,1,0]

theorem envBound4995 : H12AffineFastState.Bounded env4995 := by
  intro p hp
  have h : env4995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4994_4995 : H12AffineEnvironment.transform 2 3 env4994 = env4995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4994 == env4995) = true)

theorem identity4995 : scanCanonicalize (H12AffineFastState.compose env4995 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4996 : List Nat := [2,1,3,1,1,1,2,1,1,1,0,1,2,0,1,3,0,1,1,1,0,1,1,2,2,1,0,0,0,0,1,0,1,0,1,0]

theorem envBound4996 : H12AffineFastState.Bounded env4996 := by
  intro p hp
  have h : env4996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4995_4996 : H12AffineEnvironment.transform 1 1 env4995 = env4996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4995 == env4996) = true)

def env4997 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,46481,8388608,41003,8329,8388609,323712,16384,16813,22561,74795,8406188,256,20480,1297,8389564]

theorem envBound4997 : H12AffineFastState.Bounded env4997 := by
  intro p hp
  have h : env4997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4935_4997 : H12AffineEnvironment.transform 5 17 env4935 = env4997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4935 == env4997) = true)

theorem identity4997 : scanCanonicalize (H12AffineFastState.compose env4997 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4997 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4998 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,46481,444,41003,8329,445,323712,16384,16813,22561,74795,17680,256,20480,1297,512]

theorem envBound4998 : H12AffineFastState.Bounded env4998 := by
  intro p hp
  have h : env4998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4997_4998 : H12AffineEnvironment.transform 22 444 env4997 = env4998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4997 == env4998) = true)

theorem identity4998 : scanCanonicalize (H12AffineFastState.compose env4998 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound4998 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4999 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1024,32768,1044,41348,444,41003,8329,445,320661,16384,16813,19508,74795,17680,256,17429,1297,512]

theorem envBound4999 : H12AffineFastState.Bounded env4999 := by
  intro p hp
  have h : env4999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4998_4999 : H12AffineEnvironment.transform 11 1045 env4998 = env4999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env4998 == env4999) = true)

theorem identity4999 : scanCanonicalize (H12AffineFastState.compose env4999 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound4999 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5000 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,65536,1465,262144,1024,26260,1044,18192,444,18111,8329,445,262657,16384,16813,19508,74795,17680,256,17429,1297,512]

theorem envBound5000 : H12AffineFastState.Bounded env5000 := by
  intro p hp
  have h : env5000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4999_5000 : H12AffineEnvironment.transform 14 26260 env4999 = env5000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env4999 == env5000) = true)

theorem identity5000 : scanCanonicalize (H12AffineFastState.compose env5000 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25750) := by decide +kernel

theorem selectedBound5000 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5001 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,25750,1465,262144,1024,26260,1044,18192,444,18111,8329,445,262657,16384,16813,19508,16573,17680,256,17429,1297,512]

theorem envBound5001 : H12AffineFastState.Bounded env5001 := by
  intro p hp
  have h : env5001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5000_5001 : H12AffineEnvironment.transform 15 25750 env5000 = env5001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25750 env5000 == env5001) = true)

theorem identity5001 : scanCanonicalize (H12AffineFastState.compose env5001 (packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5001 : packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env5002 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1045,8192,16384,26172,25662,1297,262144,1024,26172,1044,18192,276,17943,8225,277,262657,16384,16645,19508,16405,17680,256,17429,1297,512]

theorem envBound5002 : H12AffineFastState.Bounded env5002 := by
  intro p hp
  have h : env5002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5001_5002 : H12AffineEnvironment.transform 6 40 env5001 = env5002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5001 == env5002) = true)

def env5003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323792,16384,16892,22641,74794,12644669,257,20560,4239488,8389612]

theorem envBound5003 : H12AffineFastState.Bounded env5003 := by
  intro p hp
  have h : env5003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4933_5003 : H12AffineEnvironment.transform 18 1025 env4933 = env5003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4933 == env5003) = true)

theorem identity5003 : scanCanonicalize (H12AffineFastState.compose env5003 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255937) := by decide +kernel

theorem selectedBound5003 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4255937,41003,8329,4255888,323792,16384,16892,22641,74794,508,257,20560,4239488,4256557]

theorem envBound5004 : H12AffineFastState.Bounded env5004 := by
  intro p hp
  have h : env5004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5003_5004 : H12AffineEnvironment.transform 22 4255937 env5003 = env5004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255937 env5003 == env5004) = true)

def env5005 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4255889,41003,8329,4255888,323712,16384,16812,22561,74794,428,257,20480,4239488,4256557]

theorem envBound5005 : H12AffineFastState.Bounded env5005 := by
  intro p hp
  have h : env5005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5004_5005 : H12AffineEnvironment.transform 5 16 env5004 = env5005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5004 == env5005) = true)

theorem identity5005 : scanCanonicalize (H12AffineFastState.compose env5005 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61741) := by decide +kernel

theorem selectedBound5005 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5006 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,61741,444,41003,8329,445,323712,16384,16812,22561,74794,428,257,20480,16813,512]

theorem envBound5006 : H12AffineFastState.Bounded env5006 := by
  intro p hp
  have h : env5006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5005_5006 : H12AffineEnvironment.transform 21 61741 env5005 = env5006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61741 env5005 == env5006) = true)

theorem identity5006 : scanCanonicalize (H12AffineFastState.compose env5006 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound5006 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5007 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1025,32768,4097,41349,444,41003,8329,445,303144,4264,4356,2185,74794,428,257,168,4357,512]

theorem envBound5007 : H12AffineFastState.Bounded env5007 := by
  intro p hp
  have h : env5007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5006_5007 : H12AffineEnvironment.transform 13 4264 env5006 = env5007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env5006 == env5007) = true)

theorem identity5007 : scanCanonicalize (H12AffineFastState.compose env5007 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound5007 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5008 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,65536,4525,262144,1025,13885,4097,6072,444,5654,8329,445,267797,4264,4356,2185,74794,428,257,168,4357,512]

theorem envBound5008 : H12AffineFastState.Bounded env5008 := by
  intro p hp
  have h : env5008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5007_5008 : H12AffineEnvironment.transform 14 13885 env5007 = env5008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env5007 == env5008) = true)

theorem identity5008 : scanCanonicalize (H12AffineFastState.compose env5008 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5008 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5009 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,8235,4525,262144,1025,13885,4097,6072,444,5654,8329,445,267797,4264,4356,2185,1025,428,257,168,4357,512]

theorem envBound5009 : H12AffineFastState.Bounded env5009 := by
  intro p hp
  have h : env5009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5008_5009 : H12AffineEnvironment.transform 15 8235 env5008 = env5009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5008 == env5009) = true)

theorem identity5009 : scanCanonicalize (H12AffineFastState.compose env5009 (packedSelected [0,1,5,8,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5009 : packedSelected [0,1,5,8,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env5010 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,8235,4525,2080,1025,13885,4097,6072,444,5654,8329,445,7733,4264,4356,2185,1025,428,257,168,4357,512]

theorem envBound5010 : H12AffineFastState.Bounded env5010 := by
  intro p hp
  have h : env5010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5009_5010 : H12AffineEnvironment.transform 17 2080 env5009 = env5010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5009 == env5010) = true)

theorem identity5010 : scanCanonicalize (H12AffineFastState.compose env5010 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1802) := by decide +kernel

theorem selectedBound5010 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env5011 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1802,8192,1954,8503,8235,1703,2080,1025,8503,1803,178,444,284,8329,445,2367,1954,1550,2185,1025,428,257,168,1551,512]

theorem envBound5011 : H12AffineFastState.Bounded env5011 := by
  intro p hp
  have h : env5011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5010_5011 : H12AffineEnvironment.transform 11 1802 env5010 = env5011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1802 env5010 == env5011) = true)

theorem identity5011 : scanCanonicalize (H12AffineFastState.compose env5011 (packedSelected [0,4,7,9,13,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5011 : packedSelected [0,4,7,9,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env5012 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1802,8192,1803,8503,8235,1550,2080,1025,8503,1803,27,277,284,8224,276,2367,1803,1550,2080,1025,261,257,1,1551,512]

theorem envBound5012 : H12AffineFastState.Bounded env5012 := by
  intro p hp
  have h : env5012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5011_5012 : H12AffineEnvironment.transform 6 41 env5011 = env5012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5011 == env5012) = true)

theorem identity5012 : scanCanonicalize (H12AffineFastState.compose env5012 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound5012 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5013 : List Nat := [2,4,8,16,32,16,41,62,512,1024,2048,1588,8192,1589,8201,8235,1550,2080,1025,8201,1589,27,43,34,8224,42,2049,1589,1550,2080,1025,59,63,1,1551,512]

theorem envBound5013 : H12AffineFastState.Bounded env5013 := by
  intro p hp
  have h : env5013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5012_5013 : H12AffineEnvironment.transform 7 62 env5012 = env5013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env5012 == env5013) = true)

theorem identity5013 : scanCanonicalize (H12AffineFastState.compose env5013 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound5013 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env5014 : List Nat := [2,4,8,16,32,16,41,62,512,1024,2048,1588,51,1589,58,24,1550,2080,1025,58,1589,27,43,34,19,42,2049,1589,1550,2080,1025,59,63,1,1551,512]

theorem envBound5014 : H12AffineFastState.Bounded env5014 := by
  intro p hp
  have h : env5014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5013_5014 : H12AffineEnvironment.transform 12 51 env5013 = env5014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env5013 == env5014) = true)

theorem identity5014 : scanCanonicalize (H12AffineFastState.compose env5014 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 571) := by decide +kernel

theorem selectedBound5014 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env5015 : List Nat := [2,4,8,16,32,16,41,62,512,1024,571,1588,51,1589,58,24,1550,539,1025,58,1589,27,43,34,19,42,570,1589,1550,539,1025,59,63,1,1551,512]

theorem envBound5015 : H12AffineFastState.Bounded env5015 := by
  intro p hp
  have h : env5015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5014_5015 : H12AffineEnvironment.transform 10 571 env5014 = env5015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 571 env5014 == env5015) = true)

theorem identity5015 : scanCanonicalize (H12AffineFastState.compose env5015 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5015 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env5016 : List Nat := [2,4,8,16,27,16,18,5,512,1024,512,1551,8,1550,1,24,1550,539,1025,1,1550,27,16,25,19,17,513,1550,1550,539,1025,0,4,1,1551,512]

theorem envBound5016 : H12AffineFastState.Bounded env5016 := by
  intro p hp
  have h : env5016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5015_5016 : H12AffineEnvironment.transform 4 27 env5015 = env5016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5015 == env5016) = true)

theorem identity5016 : scanCanonicalize (H12AffineFastState.compose env5016 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5016 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5017 : List Nat := [2,4,2,16,17,16,18,5,512,1024,512,1541,2,1540,1,18,1540,529,1025,1,1540,17,16,19,19,17,513,1540,1540,529,1025,0,4,1,1541,512]

theorem envBound5017 : H12AffineFastState.Bounded env5017 := by
  intro p hp
  have h : env5017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5016_5017 : H12AffineEnvironment.transform 2 2 env5016 = env5017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5016 == env5017) = true)

theorem identity5017 : scanCanonicalize (H12AffineFastState.compose env5017 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5017 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5018 : List Nat := [2,4,2,0,1,0,2,5,512,1024,512,1541,2,1540,1,2,1540,513,1025,1,1540,1,0,3,3,1,513,1540,1540,513,1025,0,4,1,1541,512]

theorem envBound5018 : H12AffineFastState.Bounded env5018 := by
  intro p hp
  have h : env5018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5017_5018 : H12AffineEnvironment.transform 3 0 env5017 = env5018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5017 == env5018) = true)

theorem identity5018 : scanCanonicalize (H12AffineFastState.compose env5018 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5019 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1028,2,1029,1,2,1029,0,1025,1,1029,1,0,3,3,1,0,1029,1029,0,1025,0,4,1,1028,1]

theorem envBound5019 : H12AffineFastState.Bounded env5019 := by
  intro p hp
  have h : env5019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5018_5019 : H12AffineEnvironment.transform 8 1 env5018 = env5019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5018 == env5019) = true)

def leafEnv5019 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1028,2,1029,1,2,1029,0,1025,1,1029,1,0,3,1024,3,1,1,0,1029,1029,0,1025,0,4,1,5,2,1028,1,1,1029,0]

def active5019 : List Nat := [0,1,9]

def tree5019 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5019 : H12WitnessSearch.Good tree5019 := H12GlobalWitnessIndex.good

theorem leafIdentity5019 : H12AffineFastState.composeSystem env5019 rootObs = leafEnv5019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5019 rootObs == leafEnv5019) = true)

theorem terminalChecked5019 : H12PackedTerminal.terminalCheckFast leafEnv5019 active5019 tree5019 = true := by decide +kernel

def env5020 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4255888,41003,8329,4255888,323713,16384,16813,22560,74794,429,257,20481,4239488,4256557]

theorem envBound5020 : H12AffineFastState.Bounded env5020 := by
  intro p hp
  have h : env5020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5004_5020 : H12AffineEnvironment.transform 5 17 env5004 = env5020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5004 == env5020) = true)

def env5021 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,4194304,4255888,41003,8329,4255888,323713,16384,16401,22560,74794,17,189,20481,4239488,4256401]

theorem envBound5021 : H12AffineFastState.Bounded env5021 := by
  intro p hp
  have h : env5021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5020_5021 : H12AffineEnvironment.transform 7 188 env5020 = env5021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5020 == env5021) = true)

theorem identity5021 : scanCanonicalize (H12AffineFastState.compose env5021 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound5021 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5022 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,53403,4112,262144,1025,32768,4097,4194304,4255888,41003,8329,4255888,323713,16384,16401,22560,62641,17,189,20481,4239488,4256401]

theorem envBound5022 : H12AffineFastState.Bounded env5022 := by
  intro p hp
  have h : env5022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5021_5022 : H12AffineEnvironment.transform 15 53403 env5021 = env5022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env5021 == env5022) = true)

def env5023 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4096,32768,32923,4112,262144,1025,32768,4097,4194304,4235408,41003,8329,4235408,303233,4096,4113,2080,42161,17,189,1,4239488,4235921]

theorem envBound5023 : H12AffineFastState.Bounded env5023 := by
  intro p hp
  have h : env5023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5022_5023 : H12AffineEnvironment.transform 13 4096 env5022 = env5023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5022 == env5023) = true)

theorem identity5023 : scanCanonicalize (H12AffineFastState.compose env5023 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5023 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5024 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,32768,32907,4096,262144,1025,32768,4097,4194304,4235392,41003,8329,4235392,303233,4096,4097,2080,42145,1,173,1,4239488,4235905]

theorem envBound5024 : H12AffineFastState.Bounded env5024 := by
  intro p hp
  have h : env5024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5023_5024 : H12AffineEnvironment.transform 3 0 env5023 = env5024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5023 == env5024) = true)

theorem identity5024 : scanCanonicalize (H12AffineFastState.compose env5024 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 305313) := by decide +kernel

theorem selectedBound5024 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env5025 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,32768,32907,4096,262144,1025,32768,4097,305313,264225,41003,8329,264225,303233,4096,4097,2080,42145,1,173,1,268321,264736]

theorem envBound5025 : H12AffineFastState.Bounded env5025 := by
  intro p hp
  have h : env5025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5024_5025 : H12AffineEnvironment.transform 21 305313 env5024 = env5025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305313 env5024 == env5025) = true)

theorem identity5025 : scanCanonicalize (H12AffineFastState.compose env5025 (packedSelected [4,9,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound5025 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env5026 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,32768,32907,4096,2185,1025,32768,4097,41000,168,41003,8329,168,43016,4096,4097,2080,42145,1,173,1,4264,681]

theorem envBound5026 : H12AffineFastState.Bounded env5026 := by
  intro p hp
  have h : env5026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5025_5026 : H12AffineEnvironment.transform 17 2185 env5025 = env5026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env5025 == env5026) = true)

theorem identity5026 : scanCanonicalize (H12AffineFastState.compose env5026 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 13868) := by decide +kernel

theorem selectedBound5026 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5027 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4096,13868,13991,4096,2185,1025,13868,4097,5636,168,5639,8329,168,7716,4096,4097,2080,4749,1,173,1,4264,681]

theorem envBound5027 : H12AffineFastState.Bounded env5027 := by
  intro p hp
  have h : env5027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5026_5027 : H12AffineEnvironment.transform 14 13868 env5026 = env5027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13868 env5026 == env5027) = true)

theorem identity5027 : scanCanonicalize (H12AffineFastState.compose env5027 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1549) := by decide +kernel

theorem selectedBound5027 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5028 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,1549,4096,4129,4266,4096,2185,1025,4129,4097,5636,168,5639,1668,168,7716,4096,4097,2080,4749,1,173,1,4264,681]

theorem envBound5028 : H12AffineFastState.Bounded env5028 := by
  intro p hp
  have h : env5028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5027_5028 : H12AffineEnvironment.transform 12 1549 env5027 = env5028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1549 env5027 == env5028) = true)

theorem identity5028 : scanCanonicalize (H12AffineFastState.compose env5028 (packedSelected [4,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound5028 : packedSelected [4,6,7,12] rootPS < 2^1333 := by decide +kernel

def env5029 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,512,1549,512,545,682,512,2185,1025,545,513,1028,168,1031,1668,168,3108,512,513,2080,141,1,173,1,680,681]

theorem envBound5029 : H12AffineFastState.Bounded env5029 := by
  intro p hp
  have h : env5029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5028_5029 : H12AffineEnvironment.transform 11 512 env5028 = env5029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env5028 == env5029) = true)

theorem identity5029 : scanCanonicalize (H12AffineFastState.compose env5029 (packedSelected [5,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound5029 : packedSelected [5,8,11] rootPS < 2^1333 := by decide +kernel

def env5030 : List Nat := [2,4,8,0,32,1,128,172,512,37,2048,512,552,512,545,682,512,2185,36,545,513,33,168,34,673,168,2049,512,513,2080,141,1,173,1,680,681]

theorem envBound5030 : H12AffineFastState.Bounded env5030 := by
  intro p hp
  have h : env5030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5029_5030 : H12AffineEnvironment.transform 9 37 env5029 = env5030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env5029 == env5030) = true)

theorem identity5030 : scanCanonicalize (H12AffineFastState.compose env5030 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound5030 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5031 : List Nat := [2,4,8,0,32,1,128,172,162,37,2048,162,138,162,131,8,162,2185,36,131,163,33,168,34,3,168,2049,162,163,2080,141,1,173,1,10,11]

theorem envBound5031 : H12AffineFastState.Bounded env5031 := by
  intro p hp
  have h : env5031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5030_5031 : H12AffineEnvironment.transform 8 162 env5030 = env5031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env5030 == env5031) = true)

theorem identity5031 : scanCanonicalize (H12AffineFastState.compose env5031 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound5031 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env5032 : List Nat := [2,4,8,0,32,1,128,172,162,37,43,162,138,162,131,8,162,162,36,131,163,33,168,34,3,168,42,162,163,11,141,1,173,1,10,11]

theorem envBound5032 : H12AffineFastState.Bounded env5032 := by
  intro p hp
  have h : env5032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5031_5032 : H12AffineEnvironment.transform 10 43 env5031 = env5032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env5031 == env5032) = true)

theorem identity5032 : scanCanonicalize (H12AffineFastState.compose env5032 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5032 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env5033 : List Nat := [2,4,8,0,32,1,3,47,33,37,43,33,9,33,0,8,33,33,36,0,32,33,43,34,3,43,42,33,32,11,14,1,46,1,10,11]

theorem envBound5033 : H12AffineFastState.Bounded env5033 := by
  intro p hp
  have h : env5033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5032_5033 : H12AffineEnvironment.transform 6 3 env5032 = env5033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5032 == env5033) = true)

theorem identity5033 : scanCanonicalize (H12AffineFastState.compose env5033 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5034 : List Nat := [2,4,8,0,0,1,3,15,1,5,11,1,9,1,0,8,1,1,4,0,0,1,11,2,3,11,10,1,0,11,14,1,14,1,10,11]

theorem envBound5034 : H12AffineFastState.Bounded env5034 := by
  intro p hp
  have h : env5034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5033_5034 : H12AffineEnvironment.transform 4 0 env5033 = env5034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5033 == env5034) = true)

def env5035 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4097,32768,32922,4112,262144,1025,32768,4097,4194304,4235409,41003,8329,4235409,303232,4097,4112,2081,42160,17,189,0,4239488,4235920]

theorem envBound5035 : H12AffineFastState.Bounded env5035 := by
  intro p hp
  have h : env5035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5022_5035 : H12AffineEnvironment.transform 13 4097 env5022 = env5035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5022 == env5035) = true)

theorem identity5035 : scanCanonicalize (H12AffineFastState.compose env5035 (packedSelected [0,3,5,9,10,22,27] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5035 : packedSelected [0,3,5,9,10,22,27] rootPS < 2^1333 := by decide +kernel

def env5036 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4097,32768,32906,4096,262144,1025,32768,4097,4194304,4235393,41003,8329,4235393,303232,4097,4096,2081,42144,1,173,0,4239488,4235904]

theorem envBound5036 : H12AffineFastState.Bounded env5036 := by
  intro p hp
  have h : env5036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5035_5036 : H12AffineEnvironment.transform 3 0 env5035 = env5036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5035 == env5036) = true)

theorem identity5036 : scanCanonicalize (H12AffineFastState.compose env5036 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43136) := by decide +kernel

theorem selectedBound5036 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env5037 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4097,32768,32906,4096,43136,1025,32768,4097,4194304,4235393,41003,8329,4235393,2048,4097,4096,2081,42144,1,173,0,4239488,4235904]

theorem envBound5037 : H12AffineFastState.Bounded env5037 := by
  intro p hp
  have h : env5037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5036_5037 : H12AffineEnvironment.transform 17 43136 env5036 = env5037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43136 env5036 == env5037) = true)

theorem identity5037 : scanCanonicalize (H12AffineFastState.compose env5037 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5037 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env5038 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,4097,32768,32803,4096,43049,1025,32768,4097,4194304,4235304,41003,8224,4235304,2048,4097,4096,2081,41993,1,4,0,4239401,4235817]

theorem envBound5038 : H12AffineFastState.Bounded env5038 := by
  intro p hp
  have h : env5038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5037_5038 : H12AffineEnvironment.transform 6 41 env5037 = env5038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5037 == env5038) = true)

theorem identity5038 : scanCanonicalize (H12AffineFastState.compose env5038 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(21+1) ^^^ 46605) := by decide +kernel

theorem selectedBound5038 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5039 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,4097,32768,32803,4096,43049,1025,32768,4097,46605,5669,41003,8224,5669,2048,4097,4096,2081,41993,1,4,0,1572,5156]

theorem envBound5039 : H12AffineFastState.Bounded env5039 := by
  intro p hp
  have h : env5039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5038_5039 : H12AffineEnvironment.transform 21 46605 env5038 = env5039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46605 env5038 == env5039) = true)

theorem identity5039 : scanCanonicalize (H12AffineFastState.compose env5039 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 13837) := by decide +kernel

theorem selectedBound5039 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env5040 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,4097,13837,13870,4096,7716,1025,13837,4097,0,5669,5670,8224,5669,2048,4097,4096,2081,4612,1,4,0,1572,5156]

theorem envBound5040 : H12AffineFastState.Bounded env5040 := by
  intro p hp
  have h : env5040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5039_5040 : H12AffineEnvironment.transform 14 13837 env5039 = env5040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13837 env5039 == env5040) = true)

theorem identity5040 : scanCanonicalize (H12AffineFastState.compose env5040 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5040 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5041 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,1030,4097,4619,4648,4096,7716,1025,4619,4097,0,5669,5670,1062,5669,2048,4097,4096,2081,4612,1,4,0,1572,5156]

theorem envBound5041 : H12AffineFastState.Bounded env5041 := by
  intro p hp
  have h : env5041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5040_5041 : H12AffineEnvironment.transform 12 1030 env5040 = env5041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5040 == env5041) = true)

theorem identity5041 : scanCanonicalize (H12AffineFastState.compose env5041 (packedSelected [1,3,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5041 : packedSelected [1,3,11,12] rootPS < 2^1333 := by decide +kernel

def env5042 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1540,4096,1030,4097,4619,4648,4096,4128,1025,4619,4097,0,5669,5670,1062,5669,1540,4097,4096,1573,4612,1,4,0,1572,5156]

theorem envBound5042 : H12AffineFastState.Bounded env5042 := by
  intro p hp
  have h : env5042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5041_5042 : H12AffineEnvironment.transform 10 1540 env5041 = env5042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env5041 == env5042) = true)

theorem identity5042 : scanCanonicalize (H12AffineFastState.compose env5042 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound5042 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5043 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1540,1582,1030,1583,1061,1030,1582,1550,1025,1061,1583,0,11,8,1062,11,1540,1583,1582,1573,1066,1,4,0,1572,522]

theorem envBound5043 : H12AffineFastState.Bounded env5043 := by
  intro p hp
  have h : env5043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5042_5043 : H12AffineEnvironment.transform 11 1582 env5042 = env5043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env5042 == env5043) = true)

theorem identity5043 : scanCanonicalize (H12AffineFastState.compose env5043 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5044 : List Nat := [2,4,2,0,32,1,35,5,512,1024,1540,1572,1030,1573,1061,1030,1572,1540,1025,1061,1573,0,1,2,1062,1,1540,1573,1572,1573,1056,1,4,0,1572,512]

theorem envBound5044 : H12AffineFastState.Bounded env5044 := by
  intro p hp
  have h : env5044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5043_5044 : H12AffineEnvironment.transform 2 2 env5043 = env5044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5043 == env5044) = true)

theorem identity5044 : scanCanonicalize (H12AffineFastState.compose env5044 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5045 : List Nat := [2,4,2,0,1,1,2,5,512,1024,1540,1541,1030,1540,1028,1030,1541,1540,1025,1028,1540,0,1,2,1031,1,1540,1540,1541,1540,1025,1,4,0,1541,512]

theorem envBound5045 : H12AffineFastState.Bounded env5045 := by
  intro p hp
  have h : env5045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5044_5045 : H12AffineEnvironment.transform 4 1 env5044 = env5045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5044 == env5045) = true)

theorem identity5045 : scanCanonicalize (H12AffineFastState.compose env5045 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound5045 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5046 : List Nat := [2,4,2,0,1,1,2,5,512,5,513,512,3,513,1,3,512,513,4,1,513,0,1,2,2,1,513,513,512,513,4,1,4,0,512,512]

theorem envBound5046 : H12AffineFastState.Bounded env5046 := by
  intro p hp
  have h : env5046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5045_5046 : H12AffineEnvironment.transform 9 5 env5045 = env5046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env5045 == env5046) = true)

theorem identity5046 : scanCanonicalize (H12AffineFastState.compose env5046 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5046 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5047 : List Nat := [2,4,2,0,1,1,2,5,0,5,1,0,3,1,1,3,0,1,4,1,1,0,1,2,2,1,1,1,0,1,4,1,4,0,0,0]

theorem envBound5047 : H12AffineFastState.Bounded env5047 := by
  intro p hp
  have h : env5047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5046_5047 : H12AffineEnvironment.transform 8 0 env5046 = env5047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5046 == env5047) = true)

def env5048 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,4194304,4255888,41003,8329,4255888,323713,16384,16400,22560,74794,16,188,20481,4239488,4256400]

theorem envBound5048 : H12AffineFastState.Bounded env5048 := by
  intro p hp
  have h : env5048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5020_5048 : H12AffineEnvironment.transform 7 189 env5020 = env5048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5020 == env5048) = true)

theorem identity5048 : scanCanonicalize (H12AffineFastState.compose env5048 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 28832) := by decide +kernel

theorem selectedBound5048 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5049 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,28832,65536,4113,262144,1025,28832,4097,4194304,4194352,20619,8329,4194352,262177,16384,16400,22560,74794,16,188,20481,4210720,4194864]

theorem envBound5049 : H12AffineFastState.Bounded env5049 := by
  intro p hp
  have h : env5049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5048_5049 : H12AffineEnvironment.transform 14 28832 env5048 = env5049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28832 env5048 == env5049) = true)

def env5050 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,8352,65536,4113,262144,1025,8352,4097,4194304,4194352,139,8329,4194352,262177,4096,4112,2080,74794,16,188,1,4198432,4194864]

theorem envBound5050 : H12AffineFastState.Bounded env5050 := by
  intro p hp
  have h : env5050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5049_5050 : H12AffineEnvironment.transform 13 4096 env5049 = env5050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5049 == env5050) = true)

theorem identity5050 : scanCanonicalize (H12AffineFastState.compose env5050 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound5050 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5051 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8216,65536,4113,262144,1025,8216,4097,4194304,4194352,51,8241,4194352,262177,4096,4112,2080,74794,16,4,1,4198432,4194864]

theorem envBound5051 : H12AffineFastState.Bounded env5051 := by
  intro p hp
  have h : env5051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5050_5051 : H12AffineEnvironment.transform 6 56 env5050 = env5051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5050 == env5051) = true)

theorem identity5051 : scanCanonicalize (H12AffineFastState.compose env5051 (packedSelected [2,11,18] rootPS)) = affineNative (2^(21+1) ^^^ 264209) := by decide +kernel

theorem selectedBound5051 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5052 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8216,65536,4113,262144,1025,8216,4097,264209,264225,51,8241,264225,262177,4096,4112,2080,74794,16,4,1,268337,264737]

theorem envBound5052 : H12AffineFastState.Bounded env5052 := by
  intro p hp
  have h : env5052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5051_5052 : H12AffineEnvironment.transform 21 264209 env5051 = env5052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264209 env5051 == env5052) = true)

theorem identity5052 : scanCanonicalize (H12AffineFastState.compose env5052 (packedSelected [0,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound5052 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5053 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8216,65536,4113,7701,1025,8216,4097,5636,5684,51,8241,5684,7732,4096,4112,2080,74794,16,4,1,1572,5172]

theorem envBound5053 : H12AffineFastState.Bounded env5053 := by
  intro p hp
  have h : env5053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5052_5053 : H12AffineEnvironment.transform 17 7701 env5052 = env5053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env5052 == env5053) = true)

theorem identity5053 : scanCanonicalize (H12AffineFastState.compose env5053 (packedSelected [1,3,4,6,9,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 5645) := by decide +kernel

theorem selectedBound5053 : packedSelected [1,3,4,6,9,12,15] rootPS < 2^1333 := by decide +kernel

def env5054 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,8192,4096,8216,5645,4113,7701,1025,8216,4097,5636,5684,51,8241,5684,7732,4096,4112,2080,12839,16,4,1,1572,5172]

theorem envBound5054 : H12AffineFastState.Bounded env5054 := by
  intro p hp
  have h : env5054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5053_5054 : H12AffineEnvironment.transform 15 5645 env5053 = env5054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5645 env5053 == env5054) = true)

theorem identity5054 : scanCanonicalize (H12AffineFastState.compose env5054 (packedSelected [0,4,7,13,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound5054 : packedSelected [0,4,7,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5055 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,4096,2,4096,26,5645,4113,7701,1025,26,4097,5636,5684,51,51,5684,7732,4096,4112,2080,4645,16,4,1,1572,5172]

theorem envBound5055 : H12AffineFastState.Bounded env5055 := by
  intro p hp
  have h : env5055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5054_5055 : H12AffineEnvironment.transform 12 2 env5054 = env5055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env5054 == env5055) = true)

theorem identity5055 : scanCanonicalize (H12AffineFastState.compose env5055 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5055 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5056 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,4096,2,4096,10,5645,4097,7685,1025,10,4097,5636,5668,35,35,5668,7716,4096,4096,2080,4645,0,4,1,1572,5156]

theorem envBound5056 : H12AffineFastState.Bounded env5056 := by
  intro p hp
  have h : env5056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5055_5056 : H12AffineEnvironment.transform 3 0 env5055 = env5056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5055 == env5056) = true)

theorem identity5056 : scanCanonicalize (H12AffineFastState.compose env5056 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5056 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env5057 : List Nat := [2,4,8,0,10,1,2,5,512,1024,2048,4096,2,4096,10,5645,4097,7685,1025,10,4097,5636,5646,9,9,5646,7694,4096,4096,2058,4623,0,4,1,1550,5134]

theorem envBound5057 : H12AffineFastState.Bounded env5057 := by
  intro p hp
  have h : env5057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5056_5057 : H12AffineEnvironment.transform 4 10 env5056 = env5057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5056 == env5057) = true)

theorem identity5057 : scanCanonicalize (H12AffineFastState.compose env5057 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound5057 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5058 : List Nat := [2,4,8,0,10,1,2,5,512,1024,522,4096,2,4096,10,5645,4097,5135,1025,10,4097,5636,5646,9,9,5646,5124,4096,4096,512,4623,0,4,1,1550,5134]

theorem envBound5058 : H12AffineFastState.Bounded env5058 := by
  intro p hp
  have h : env5058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5057_5058 : H12AffineEnvironment.transform 10 522 env5057 = env5058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env5057 == env5058) = true)

theorem identity5058 : scanCanonicalize (H12AffineFastState.compose env5058 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5058 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5059 : List Nat := [2,4,8,0,10,1,2,5,512,1024,522,1550,2,1550,10,3,1551,513,1025,10,1551,10,0,9,9,0,522,1550,1550,512,1025,0,4,1,1550,512]

theorem envBound5059 : H12AffineFastState.Bounded env5059 := by
  intro p hp
  have h : env5059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5058_5059 : H12AffineEnvironment.transform 11 1550 env5058 = env5059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env5058 == env5059) = true)

theorem identity5059 : scanCanonicalize (H12AffineFastState.compose env5059 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5059 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env5060 : List Nat := [2,4,3,0,1,1,2,5,512,1024,513,1541,2,1541,1,3,1540,513,1025,1,1540,1,0,2,2,0,513,1541,1541,512,1025,0,4,1,1541,512]

theorem envBound5060 : H12AffineFastState.Bounded env5060 := by
  intro p hp
  have h : env5060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5059_5060 : H12AffineEnvironment.transform 2 3 env5059 = env5060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5059 == env5060) = true)

theorem identity5060 : scanCanonicalize (H12AffineFastState.compose env5060 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5061 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1028,2,1028,1,3,1029,0,1025,1,1029,1,0,2,2,0,0,1028,1028,1,1025,0,4,1,1028,1]

theorem envBound5061 : H12AffineFastState.Bounded env5061 := by
  intro p hp
  have h : env5061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5060_5061 : H12AffineEnvironment.transform 8 1 env5060 = env5061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5060 == env5061) = true)

def leafEnv5061 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1028,2,1028,1,3,1029,0,1025,1,1029,1,0,2,1024,2,1,0,0,1028,1028,1,1025,0,4,1,5,2,1028,1,1,1028,0]

def active5061 : List Nat := [0,1,9]

def tree5061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5061 : H12WitnessSearch.Good tree5061 := H12GlobalWitnessIndex.good

theorem leafIdentity5061 : H12AffineFastState.composeSystem env5061 rootObs = leafEnv5061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5061 rootObs == leafEnv5061) = true)

theorem terminalChecked5061 : H12PackedTerminal.terminalCheckFast leafEnv5061 active5061 tree5061 = true := by decide +kernel

def env5062 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,8353,65536,4113,262144,1025,8353,4097,4194304,4194352,138,8329,4194352,262177,4097,4113,2081,74794,16,188,0,4198433,4194864]

theorem envBound5062 : H12AffineFastState.Bounded env5062 := by
  intro p hp
  have h : env5062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5049_5062 : H12AffineEnvironment.transform 13 4097 env5049 = env5062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5049 == env5062) = true)

theorem identity5062 : scanCanonicalize (H12AffineFastState.compose env5062 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 264209) := by decide +kernel

theorem selectedBound5062 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5063 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,8353,65536,4113,262144,1025,8353,4097,264209,264225,138,8329,264225,262177,4097,4113,2081,74794,16,188,0,268336,264737]

theorem envBound5063 : H12AffineFastState.Bounded env5063 := by
  intro p hp
  have h : env5063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5062_5063 : H12AffineEnvironment.transform 21 264209 env5062 = env5063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264209 env5062 == env5063) = true)

theorem identity5063 : scanCanonicalize (H12AffineFastState.compose env5063 (packedSelected [0,2,4,7,11,13,17,18,22] rootPS)) = affineNative (2^(17+1) ^^^ 75786) := by decide +kernel

theorem selectedBound5063 : packedSelected [0,2,4,7,11,13,17,18,22] rootPS < 2^1333 := by decide +kernel

def env5064 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,8353,65536,4113,75786,1025,8353,4097,73755,73771,138,8329,73771,75819,4097,4113,2081,74794,16,188,0,77882,74283]

theorem envBound5064 : H12AffineFastState.Bounded env5064 := by
  intro p hp
  have h : env5064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5063_5064 : H12AffineEnvironment.transform 17 75786 env5063 = env5064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75786 env5063 == env5064) = true)

theorem identity5064 : scanCanonicalize (H12AffineFastState.compose env5064 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound5064 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5065 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1676,8192,1677,8353,65536,1693,75786,1025,8353,1677,73755,73771,138,8329,73771,75819,1677,1693,2081,74794,16,188,0,75446,74283]

theorem envBound5065 : H12AffineFastState.Bounded env5065 := by
  intro p hp
  have h : env5065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5064_5065 : H12AffineEnvironment.transform 11 1676 env5064 = env5065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env5064 == env5065) = true)

theorem identity5065 : scanCanonicalize (H12AffineFastState.compose env5065 (packedSelected [4,9,20] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5065 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env5066 : List Nat := [2,4,8,16,32,17,41,20,512,1024,2048,1573,8192,1572,8200,65536,1588,75786,1025,8200,1572,73755,73771,35,8224,73771,75819,1572,1588,2081,74794,16,21,0,75295,74283]

theorem envBound5066 : H12AffineFastState.Bounded env5066 := by
  intro p hp
  have h : env5066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5065_5066 : H12AffineEnvironment.transform 6 41 env5065 = env5066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5065 == env5066) = true)

theorem identity5066 : scanCanonicalize (H12AffineFastState.compose env5066 (packedSelected [0,1,3,6,7,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 2568) := by decide +kernel

theorem selectedBound5066 : packedSelected [0,1,3,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env5067 : List Nat := [2,4,8,16,32,17,41,20,512,1024,2048,1573,8192,1572,8200,2568,1588,8706,1025,8200,1572,10771,10787,35,8224,10787,8739,1572,1588,2081,11810,16,21,0,11287,10275]

theorem envBound5067 : H12AffineFastState.Bounded env5067 := by
  intro p hp
  have h : env5067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5066_5067 : H12AffineEnvironment.transform 15 2568 env5066 = env5067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2568 env5066 == env5067) = true)

theorem identity5067 : scanCanonicalize (H12AffineFastState.compose env5067 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2610) := by decide +kernel

theorem selectedBound5067 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5068 : List Nat := [2,4,8,16,32,17,41,20,512,1024,2048,1573,2610,1572,2618,2568,1588,2096,1025,2618,1572,33,17,35,2578,17,2065,1572,1588,2081,1040,16,21,0,1573,529]

theorem envBound5068 : H12AffineFastState.Bounded env5068 := by
  intro p hp
  have h : env5068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5067_5068 : H12AffineEnvironment.transform 12 2610 env5067 = env5068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2610 env5067 == env5068) = true)

theorem identity5068 : scanCanonicalize (H12AffineFastState.compose env5068 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound5068 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5069 : List Nat := [2,4,8,16,32,17,41,20,512,1024,1589,1573,1031,1572,1039,1085,1588,1541,1025,1039,1572,33,17,35,1063,17,1572,1572,1588,1556,1040,16,21,0,1573,529]

theorem envBound5069 : H12AffineFastState.Bounded env5069 := by
  intro p hp
  have h : env5069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5068_5069 : H12AffineEnvironment.transform 10 1589 env5068 = env5069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env5068 == env5069) = true)

theorem identity5069 : scanCanonicalize (H12AffineFastState.compose env5069 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5069 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5070 : List Nat := [2,4,8,16,26,17,19,20,512,1024,1551,1567,1031,1566,1039,1031,1550,1541,1025,1039,1566,27,17,25,1053,17,1566,1566,1550,1556,1040,16,21,0,1567,529]

theorem envBound5070 : H12AffineFastState.Bounded env5070 := by
  intro p hp
  have h : env5070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5069_5070 : H12AffineEnvironment.transform 4 26 env5069 = env5070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5069 == env5070) = true)

theorem identity5070 : scanCanonicalize (H12AffineFastState.compose env5070 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5070 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5071 : List Nat := [2,4,8,0,10,1,3,4,512,1024,1551,1551,1031,1550,1039,1031,1550,1541,1025,1039,1550,11,1,9,1037,1,1550,1550,1550,1540,1024,0,5,0,1551,513]

theorem envBound5071 : H12AffineFastState.Bounded env5071 := by
  intro p hp
  have h : env5071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5070_5071 : H12AffineEnvironment.transform 3 0 env5070 = env5071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5070 == env5071) = true)

theorem identity5071 : scanCanonicalize (H12AffineFastState.compose env5071 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5071 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5072 : List Nat := [2,0,8,0,10,1,3,0,512,1024,1547,1547,1027,1546,1035,1027,1546,1537,1025,1035,1546,11,1,9,1033,1,1546,1546,1546,1536,1024,0,1,0,1547,513]

theorem envBound5072 : H12AffineFastState.Bounded env5072 := by
  intro p hp
  have h : env5072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5071_5072 : H12AffineEnvironment.transform 1 0 env5071 = env5072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5071 == env5072) = true)

theorem identity5072 : scanCanonicalize (H12AffineFastState.compose env5072 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5072 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5073 : List Nat := [2,0,8,0,10,1,3,0,0,1024,1035,1035,1027,1034,1035,1027,1034,1025,1025,1035,1034,11,1,9,1033,1,1034,1034,1034,1024,1024,0,1,0,1035,1]

theorem envBound5073 : H12AffineFastState.Bounded env5073 := by
  intro p hp
  have h : env5073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5072_5073 : H12AffineEnvironment.transform 8 0 env5072 = env5073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5072 == env5073) = true)

theorem identity5073 : scanCanonicalize (H12AffineFastState.compose env5073 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound5073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5074 : List Nat := [2,0,8,0,10,1,3,0,0,10,1,1,9,0,1,9,0,11,11,1,0,11,1,9,3,1,0,0,0,10,10,0,1,0,1,1]

theorem envBound5074 : H12AffineFastState.Bounded env5074 := by
  intro p hp
  have h : env5074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5073_5074 : H12AffineEnvironment.transform 9 10 env5073 = env5074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env5073 == env5074) = true)

def leafEnv5074 : List Nat := [2,0,8,0,10,1,3,0,0,10,1,1,9,0,1,9,0,11,11,1,0,11,1,9,11,3,1,1,0,0,0,10,10,0,1,0,1,3,1,1,1,1,0]

def active5074 : List Nat := [0,2]

def tree5074 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5074 : H12WitnessSearch.Good tree5074 := H12GlobalWitnessIndex.good

theorem leafIdentity5074 : H12AffineFastState.composeSystem env5074 rootObs = leafEnv5074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5074 rootObs == leafEnv5074) = true)

theorem terminalChecked5074 : H12PackedTerminal.terminalCheckFast leafEnv5074 active5074 tree5074 = true := by decide +kernel

def env5075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914001,2942161,16385,16893,2641008,598058,14737725,525568,2638929,6332544,8914925]

theorem envBound5075 : H12AffineFastState.Bounded env5075 := by
  intro p hp
  have h : env5075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4843_5075 : H12AffineEnvironment.transform 25 8914001 env4843 = env5075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env4843 == env5075) = true)

def env5076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849105,16385,16893,547952,598058,12644669,525568,545873,4239488,8914925]

theorem envBound5076 : H12AffineFastState.Bounded env5076 := by
  intro p hp
  have h : env5076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5075_5076 : H12AffineEnvironment.transform 20 4096 env5075 = env5076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5075 == env5076) = true)

def env5077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323793,16385,16893,22640,74794,12644669,256,20561,4239488,8389613]

theorem envBound5077 : H12AffineFastState.Bounded env5077 := by
  intro p hp
  have h : env5077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5076_5077 : H12AffineEnvironment.transform 18 1024 env5076 = env5077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5076 == env5077) = true)

theorem identity5077 : scanCanonicalize (H12AffineFastState.compose env5077 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound5077 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4264,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,303225,4265,4437,2264,74794,12624277,256,249,4239488,8389613]

theorem envBound5078 : H12AffineFastState.Bounded env5078 := by
  intro p hp
  have h : env5078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5077_5078 : H12AffineEnvironment.transform 13 4264 env5077 = env5078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env5077 == env5078) = true)

def env5079 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,4194304,8388608,41003,8329,8388609,303145,4265,4357,2184,74794,12624277,256,169,4239488,8389565]

theorem envBound5079 : H12AffineFastState.Bounded env5079 := by
  intro p hp
  have h : env5079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5078_5079 : H12AffineEnvironment.transform 5 16 env5078 = env5079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5078 == env5079) = true)

theorem identity5079 : scanCanonicalize (H12AffineFastState.compose env5079 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5079 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5080 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,4194304,445,41003,8329,444,303145,4265,4357,2184,74794,4235304,256,169,4239488,512]

theorem envBound5080 : H12AffineFastState.Bounded env5080 := by
  intro p hp
  have h : env5080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5079_5080 : H12AffineEnvironment.transform 22 445 env5079 = env5080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5079 == env5080) = true)

theorem identity5080 : scanCanonicalize (H12AffineFastState.compose env5080 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5080 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5081 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,41349,445,41003,8329,444,303145,4265,4357,2184,74794,429,256,169,4357,512]

theorem envBound5081 : H12AffineFastState.Bounded env5081 := by
  intro p hp
  have h : env5081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5080_5081 : H12AffineEnvironment.transform 21 41349 env5080 = env5081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5080 == env5081) = true)

theorem identity5081 : scanCanonicalize (H12AffineFastState.compose env5081 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound5081 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5082 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,65536,4525,262144,1024,13885,4096,6072,445,5654,8329,444,267796,4265,4357,2184,74794,429,256,169,4357,512]

theorem envBound5082 : H12AffineFastState.Bounded env5082 := by
  intro p hp
  have h : env5082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5081_5082 : H12AffineEnvironment.transform 14 13885 env5081 = env5082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env5081 == env5082) = true)

theorem identity5082 : scanCanonicalize (H12AffineFastState.compose env5082 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound5082 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5083 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,13885,8234,4525,262144,1024,13885,4096,6072,445,5654,8329,444,267796,4265,4357,2184,1024,429,256,169,4357,512]

theorem envBound5083 : H12AffineFastState.Bounded env5083 := by
  intro p hp
  have h : env5083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5082_5083 : H12AffineEnvironment.transform 15 8234 env5082 = env5083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env5082 == env5083) = true)

def env5084 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4096,4194304,8388608,41003,8329,8388608,303144,4265,4356,2185,74794,12624277,256,168,4239488,8389564]

theorem envBound5084 : H12AffineFastState.Bounded env5084 := by
  intro p hp
  have h : env5084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5078_5084 : H12AffineEnvironment.transform 5 17 env5078 = env5084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5078 == env5084) = true)

def env5085 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,262144,1024,32768,4096,4194304,8388608,41003,8329,8388608,303144,4265,4264,2185,74794,12623929,172,168,4239488,8389136]

theorem envBound5085 : H12AffineFastState.Bounded env5085 := by
  intro p hp
  have h : env5085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5084_5085 : H12AffineEnvironment.transform 7 172 env5084 = env5085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env5084 == env5085) = true)

theorem identity5085 : scanCanonicalize (H12AffineFastState.compose env5085 (packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound5085 : packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5086 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7700,1024,32768,4096,4194304,8388608,41003,8329,8388608,48700,4265,4264,2185,74794,12623929,172,168,4239488,8389136]

theorem envBound5086 : H12AffineFastState.Bounded env5086 := by
  intro p hp
  have h : env5086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5085_5086 : H12AffineEnvironment.transform 17 7700 env5085 = env5086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env5085 == env5086) = true)

def env5087 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7700,1024,32768,4096,41088,8388608,41003,8329,8388608,48700,4265,4264,2185,74794,8388793,172,168,4096,8389136]

theorem envBound5087 : H12AffineFastState.Bounded env5087 := by
  intro p hp
  have h : env5087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5086_5087 : H12AffineEnvironment.transform 21 41088 env5086 = env5087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5086 == env5087) = true)

theorem identity5087 : scanCanonicalize (H12AffineFastState.compose env5087 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 185) := by decide +kernel

theorem selectedBound5087 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5088 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7700,1024,32768,4096,41088,185,41003,8329,185,48700,4265,4264,2185,74794,0,172,168,4096,681]

theorem envBound5088 : H12AffineFastState.Bounded env5088 := by
  intro p hp
  have h : env5088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5087_5088 : H12AffineEnvironment.transform 22 185 env5087 = env5088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env5087 == env5088) = true)

theorem identity5088 : scanCanonicalize (H12AffineFastState.compose env5088 (packedSelected [0,3,5,7,8,13,17,18,20,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5088 : packedSelected [0,3,5,7,8,13,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env5089 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,8201,65536,4096,7700,1024,8201,4096,137,185,34,8329,185,7733,4265,4264,2185,74794,0,172,168,4096,681]

theorem envBound5089 : H12AffineFastState.Bounded env5089 := by
  intro p hp
  have h : env5089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5088_5089 : H12AffineEnvironment.transform 14 8201 env5088 = env5089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5088 == env5089) = true)

theorem identity5089 : scanCanonicalize (H12AffineFastState.compose env5089 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound5089 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5090 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1589,8192,1693,8201,65536,1589,2081,1024,8201,1589,137,185,34,8329,185,2048,1692,1693,2185,74794,0,172,168,1589,681]

theorem envBound5090 : H12AffineFastState.Bounded env5090 := by
  intro p hp
  have h : env5090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5089_5090 : H12AffineEnvironment.transform 11 1589 env5089 = env5090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env5089 == env5090) = true)

theorem identity5090 : scanCanonicalize (H12AffineFastState.compose env5090 (packedSelected [1,2,6,7,8,9,11,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2699) := by decide +kernel

theorem selectedBound5090 : packedSelected [1,2,6,7,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env5091 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1589,8192,1693,8201,2699,1589,2081,1024,8201,1589,137,185,34,8329,185,2048,1692,1693,2185,11937,0,172,168,1589,681]

theorem envBound5091 : H12AffineFastState.Bounded env5091 := by
  intro p hp
  have h : env5091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5090_5091 : H12AffineEnvironment.transform 15 2699 env5090 = env5091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2699 env5090 == env5091) = true)

theorem identity5091 : scanCanonicalize (H12AffineFastState.compose env5091 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound5091 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5092 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1589,8192,1693,8201,1068,1589,1670,1024,8201,1589,137,185,34,8329,185,1703,1692,1693,1582,8198,0,172,168,1589,681]

theorem envBound5092 : H12AffineFastState.Bounded env5092 := by
  intro p hp
  have h : env5092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5091_5092 : H12AffineEnvironment.transform 10 1703 env5091 = env5092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env5091 == env5092) = true)

theorem identity5092 : scanCanonicalize (H12AffineFastState.compose env5092 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5092 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5093 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1589,1030,1693,1039,1068,1589,1670,1024,1039,1589,137,185,34,1167,185,1703,1692,1693,1582,1024,0,172,168,1589,681]

theorem envBound5093 : H12AffineFastState.Bounded env5093 := by
  intro p hp
  have h : env5093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5092_5093 : H12AffineEnvironment.transform 12 1030 env5092 = env5093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5092 == env5093) = true)

theorem identity5093 : scanCanonicalize (H12AffineFastState.compose env5093 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5093 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5094 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1551,1589,1030,1589,1039,1068,1589,1582,1024,1039,1589,33,17,34,1063,17,1551,1588,1589,1582,1024,0,4,0,1589,513]

theorem envBound5094 : H12AffineFastState.Bounded env5094 := by
  intro p hp
  have h : env5094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5093_5094 : H12AffineEnvironment.transform 6 40 env5093 = env5094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5093 == env5094) = true)

theorem identity5094 : scanCanonicalize (H12AffineFastState.compose env5094 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound5094 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5095 : List Nat := [2,4,8,16,32,17,40,4,52,1024,1083,1025,1030,1025,1039,1068,1025,1050,1024,1039,1025,33,17,34,1063,17,1083,1024,1025,1050,1024,0,4,0,1025,53]

theorem envBound5095 : H12AffineFastState.Bounded env5095 := by
  intro p hp
  have h : env5095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5094_5095 : H12AffineEnvironment.transform 8 52 env5094 = env5095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env5094 == env5095) = true)

theorem identity5095 : scanCanonicalize (H12AffineFastState.compose env5095 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5096 : List Nat := [2,4,8,11,32,10,40,4,47,1024,1056,1025,1030,1025,1039,1068,1025,1025,1024,1039,1025,33,10,34,1063,10,1056,1024,1025,1025,1024,0,4,0,1025,46]

theorem envBound5096 : H12AffineFastState.Bounded env5096 := by
  intro p hp
  have h : env5096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5095_5096 : H12AffineEnvironment.transform 3 11 env5095 = env5096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5095 == env5096) = true)

def env5097 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4264,32768,65536,4096,7700,1024,32768,4096,41089,8388608,41003,8329,8388608,48700,4265,4264,2185,74794,8388792,172,168,4097,8389136]

theorem envBound5097 : H12AffineFastState.Bounded env5097 := by
  intro p hp
  have h : env5097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5086_5097 : H12AffineEnvironment.transform 21 41089 env5086 = env5097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5086 == env5097) = true)

theorem identity5097 : scanCanonicalize (H12AffineFastState.compose env5097 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5097 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5098 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,32768,65536,4096,7700,1024,32768,4096,41001,8388608,41003,8225,8388608,48700,4097,4096,2081,74794,8388624,4,0,4097,8389136]

theorem envBound5098 : H12AffineFastState.Bounded env5098 := by
  intro p hp
  have h : env5098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5097_5098 : H12AffineEnvironment.transform 6 40 env5097 = env5098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5097 == env5098) = true)

theorem identity5098 : scanCanonicalize (H12AffineFastState.compose env5098 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(22+1) ^^^ 103942) := by decide +kernel

theorem selectedBound5098 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env5099 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,32768,65536,4096,7700,1024,32768,4096,41001,103942,41003,8225,103942,48700,4097,4096,2081,74794,103958,4,0,4097,103446]

theorem envBound5099 : H12AffineFastState.Bounded env5099 := by
  intro p hp
  have h : env5099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5098_5099 : H12AffineEnvironment.transform 22 103942 env5098 = env5099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 103942 env5098 == env5099) = true)

theorem identity5099 : scanCanonicalize (H12AffineFastState.compose env5099 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 13855) := by decide +kernel

theorem selectedBound5099 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5100 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,32768,13855,4096,7700,1024,32768,4096,41001,40985,41003,8225,40985,48700,4097,4096,2081,4661,40969,4,0,4097,41481]

theorem envBound5100 : H12AffineFastState.Bounded env5100 := by
  intro p hp
  have h : env5100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5099_5100 : H12AffineEnvironment.transform 15 13855 env5099 = env5100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13855 env5099 == env5100) = true)

theorem identity5100 : scanCanonicalize (H12AffineFastState.compose env5100 (packedSelected [1,2,4,5,6,9,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 14898) := by decide +kernel

theorem selectedBound5100 : packedSelected [1,2,4,5,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env5101 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4096,14898,13855,4096,7700,1024,14898,4096,6683,6699,6681,8225,6699,1038,4097,4096,2081,4661,6715,4,0,4097,6203]

theorem envBound5101 : H12AffineFastState.Bounded env5101 := by
  intro p hp
  have h : env5101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5100_5101 : H12AffineEnvironment.transform 14 14898 env5100 = env5101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14898 env5100 == env5101) = true)

theorem identity5101 : scanCanonicalize (H12AffineFastState.compose env5101 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5101 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5102 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1038,4096,8192,4096,13884,13855,4096,4634,1024,13884,4096,5653,5669,5655,8225,5669,1038,4097,4096,1071,4661,5685,4,0,4097,5173]

theorem envBound5102 : H12AffineFastState.Bounded env5102 := by
  intro p hp
  have h : env5102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5101_5102 : H12AffineEnvironment.transform 10 1038 env5101 = env5102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env5101 == env5102) = true)

theorem identity5102 : scanCanonicalize (H12AffineFastState.compose env5102 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound5102 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5103 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1038,1077,8192,1077,8713,8746,1077,1583,1024,8713,1077,544,528,546,8225,528,1038,1076,1077,1071,1536,512,4,0,1076,0]

theorem envBound5103 : H12AffineFastState.Bounded env5103 := by
  intro p hp
  have h : env5103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5102_5103 : H12AffineEnvironment.transform 11 1077 env5102 = env5103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env5102 == env5103) = true)

theorem identity5103 : scanCanonicalize (H12AffineFastState.compose env5103 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound5103 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env5104 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1038,1077,1031,1077,1550,1581,1077,1583,1024,1550,1077,544,528,546,1062,528,1038,1076,1077,1071,1536,512,4,0,1076,0]

theorem envBound5104 : H12AffineFastState.Bounded env5104 := by
  intro p hp
  have h : env5104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5103_5104 : H12AffineEnvironment.transform 12 1031 env5103 = env5104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env5103 == env5104) = true)

theorem identity5104 : scanCanonicalize (H12AffineFastState.compose env5104 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5104 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env5105 : List Nat := [2,4,8,16,32,17,40,4,1,1024,1038,1077,1031,1077,1039,1068,1077,1070,1024,1039,1077,33,17,35,1062,17,1038,1076,1077,1071,1025,1,4,0,1076,0]

theorem envBound5105 : H12AffineFastState.Bounded env5105 := by
  intro p hp
  have h : env5105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5104_5105 : H12AffineEnvironment.transform 8 1 env5104 = env5105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5104 == env5105) = true)

theorem identity5105 : scanCanonicalize (H12AffineFastState.compose env5105 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5106 : List Nat := [2,4,2,16,32,17,34,4,1,1024,1028,1077,1031,1077,1029,1062,1077,1060,1024,1029,1077,33,17,35,1062,17,1028,1076,1077,1061,1025,1,4,0,1076,0]

theorem envBound5106 : H12AffineFastState.Bounded env5106 := by
  intro p hp
  have h : env5106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5105_5106 : H12AffineEnvironment.transform 2 2 env5105 = env5106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5105 == env5106) = true)

theorem identity5106 : scanCanonicalize (H12AffineFastState.compose env5106 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound5106 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5107 : List Nat := [2,4,2,16,5,17,7,4,1,1024,1028,1040,1031,1040,1029,1027,1040,1025,1024,1029,1040,4,17,6,1027,17,1028,1041,1040,1024,1025,1,4,0,1041,0]

theorem envBound5107 : H12AffineFastState.Bounded env5107 := by
  intro p hp
  have h : env5107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5106_5107 : H12AffineEnvironment.transform 4 5 env5106 = env5107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env5106 == env5107) = true)

theorem identity5107 : scanCanonicalize (H12AffineFastState.compose env5107 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound5107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5108 : List Nat := [2,4,2,16,5,17,7,4,1,17,21,1,22,1,20,18,1,16,17,20,1,4,17,6,18,17,21,0,1,17,16,1,4,0,0,0]

theorem envBound5108 : H12AffineFastState.Bounded env5108 := by
  intro p hp
  have h : env5108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5107_5108 : H12AffineEnvironment.transform 9 17 env5107 = env5108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env5107 == env5108) = true)

theorem identity5108 : scanCanonicalize (H12AffineFastState.compose env5108 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound5108 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env5109 : List Nat := [2,4,2,4,5,5,7,4,1,5,1,1,2,1,0,6,1,4,5,0,1,4,5,6,6,5,1,0,1,5,4,1,4,0,0,0]

theorem envBound5109 : H12AffineFastState.Bounded env5109 := by
  intro p hp
  have h : env5109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5108_5109 : H12AffineEnvironment.transform 3 4 env5108 = env5109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5108 == env5109) = true)

theorem identity5109 : scanCanonicalize (H12AffineFastState.compose env5109 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5109 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5110 : List Nat := [2,1,2,1,0,0,2,1,1,0,1,1,2,1,0,3,1,1,0,0,1,1,0,3,3,0,1,0,1,0,1,1,1,0,0,0]

theorem envBound5110 : H12AffineFastState.Bounded env5110 := by
  intro p hp
  have h : env5110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5109_5110 : H12AffineEnvironment.transform 1 1 env5109 = env5110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5109 == env5110) = true)

def env5111 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,262144,1024,32768,4096,4194304,8388608,41003,8329,8388608,303144,4265,4265,2185,74794,12623928,173,168,4239488,8389137]

theorem envBound5111 : H12AffineFastState.Bounded env5111 := by
  intro p hp
  have h : env5111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5084_5111 : H12AffineEnvironment.transform 7 173 env5084 = env5111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5084 == env5111) = true)

theorem identity5111 : scanCanonicalize (H12AffineFastState.compose env5111 (packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 81470) := by decide +kernel

theorem selectedBound5111 : packedSelected [0,3,5,8,10,11,13,18,21,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5112 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81470,1024,32768,4096,4194304,8388608,41003,8329,8388608,106006,4265,4265,2185,74794,12623928,173,168,4239488,8389137]

theorem envBound5112 : H12AffineFastState.Bounded env5112 := by
  intro p hp
  have h : env5112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5111_5112 : H12AffineEnvironment.transform 17 81470 env5111 = env5112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81470 env5111 == env5112) = true)

def env5113 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81470,1024,32768,4096,41088,8388608,41003,8329,8388608,106006,4265,4265,2185,74794,8388792,173,168,4096,8389137]

theorem envBound5113 : H12AffineFastState.Bounded env5113 := by
  intro p hp
  have h : env5113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5112_5113 : H12AffineEnvironment.transform 21 41088 env5112 = env5113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5112 == env5113) = true)

theorem identity5113 : scanCanonicalize (H12AffineFastState.compose env5113 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 185) := by decide +kernel

theorem selectedBound5113 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5114 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81470,1024,32768,4096,41088,185,41003,8329,185,106006,4265,4265,2185,74794,1,173,168,4096,680]

theorem envBound5114 : H12AffineFastState.Bounded env5114 := by
  intro p hp
  have h : env5114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5113_5114 : H12AffineEnvironment.transform 22 185 env5113 = env5114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env5113 == env5114) = true)

theorem identity5114 : scanCanonicalize (H12AffineFastState.compose env5114 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5114 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env5115 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,8235,4097,7701,1024,32768,4096,41088,185,41003,8329,185,48701,4265,4265,2185,1025,1,173,168,4096,680]

theorem envBound5115 : H12AffineFastState.Bounded env5115 := by
  intro p hp
  have h : env5115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5114_5115 : H12AffineEnvironment.transform 15 8235 env5114 = env5115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5114 == env5115) = true)

theorem identity5115 : scanCanonicalize (H12AffineFastState.compose env5115 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound5115 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5116 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1693,8192,1589,32768,8235,1692,2184,1024,32768,1693,41088,185,41003,8329,185,43168,1588,1588,2185,1025,1,173,168,1693,680]

theorem envBound5116 : H12AffineFastState.Bounded env5116 := by
  intro p hp
  have h : env5116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5115_5116 : H12AffineEnvironment.transform 11 1693 env5115 = env5116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env5115 == env5116) = true)

theorem identity5116 : scanCanonicalize (H12AffineFastState.compose env5116 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound5116 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5117 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1693,8192,1589,8353,8235,1692,2184,1024,8353,1693,33,185,138,8329,185,2049,1588,1588,2185,1025,1,173,168,1693,680]

theorem envBound5117 : H12AffineFastState.Bounded env5117 := by
  intro p hp
  have h : env5117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5116_5117 : H12AffineEnvironment.transform 14 8353 env5116 = env5117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5116 == env5117) = true)

theorem identity5117 : scanCanonicalize (H12AffineFastState.compose env5117 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1724) := by decide +kernel

theorem selectedBound5117 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5118 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1724,1693,8192,1589,8353,8235,1692,1588,1024,8353,1693,33,185,138,8329,185,1725,1588,1588,1589,1025,1,173,168,1693,680]

theorem envBound5118 : H12AffineFastState.Bounded env5118 := by
  intro p hp
  have h : env5118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5117_5118 : H12AffineEnvironment.transform 10 1724 env5117 = env5118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1724 env5117 == env5118) = true)

theorem identity5118 : scanCanonicalize (H12AffineFastState.compose env5118 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound5118 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5119 : List Nat := [2,4,8,16,32,17,51,30,512,1024,1551,1582,8192,1589,8210,8235,1583,1588,1024,8210,1582,33,10,57,8250,10,1550,1588,1588,1589,1025,1,30,27,1582,539]

theorem envBound5119 : H12AffineFastState.Bounded env5119 := by
  intro p hp
  have h : env5119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5118_5119 : H12AffineEnvironment.transform 6 51 env5118 = env5119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env5118 == env5119) = true)

theorem identity5119 : scanCanonicalize (H12AffineFastState.compose env5119 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5119 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env5120 : List Nat := [2,4,8,16,32,17,51,30,512,1024,1551,1582,1062,1589,1076,1037,1583,1588,1024,1076,1582,33,10,57,1052,10,1550,1588,1588,1589,1025,1,30,27,1582,539]

theorem envBound5120 : H12AffineFastState.Bounded env5120 := by
  intro p hp
  have h : env5120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5119_5120 : H12AffineEnvironment.transform 12 1062 env5119 = env5120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5119 == env5120) = true)

theorem identity5120 : scanCanonicalize (H12AffineFastState.compose env5120 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5120 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env5121 : List Nat := [2,4,8,10,32,11,41,4,512,1024,1551,1582,1062,1583,1070,1037,1583,1582,1024,1070,1582,33,10,35,1030,10,1550,1582,1582,1583,1025,1,4,1,1582,513]

theorem envBound5121 : H12AffineFastState.Bounded env5121 := by
  intro p hp
  have h : env5121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5120_5121 : H12AffineEnvironment.transform 3 10 env5120 = env5121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5120 == env5121) = true)

theorem identity5121 : scanCanonicalize (H12AffineFastState.compose env5121 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5121 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5122 : List Nat := [2,4,6,4,32,5,39,4,512,1024,1537,1568,1062,1569,1056,1027,1569,1568,1024,1056,1568,33,4,35,1030,4,1536,1568,1568,1569,1025,1,4,1,1568,513]

theorem envBound5122 : H12AffineFastState.Bounded env5122 := by
  intro p hp
  have h : env5122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5121_5122 : H12AffineEnvironment.transform 2 6 env5121 = env5122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5121 == env5122) = true)

theorem identity5122 : scanCanonicalize (H12AffineFastState.compose env5122 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5122 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5123 : List Nat := [2,0,2,0,32,1,35,0,512,1024,1537,1568,1058,1569,1056,1027,1569,1568,1024,1056,1568,33,0,35,1026,0,1536,1568,1568,1569,1025,1,0,1,1568,513]

theorem envBound5123 : H12AffineFastState.Bounded env5123 := by
  intro p hp
  have h : env5123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5122_5123 : H12AffineEnvironment.transform 1 0 env5122 = env5123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5122 == env5123) = true)

theorem identity5123 : scanCanonicalize (H12AffineFastState.compose env5123 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5123 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5124 : List Nat := [2,0,2,0,32,1,35,0,0,1024,1025,1056,1058,1057,1056,1027,1057,1056,1024,1056,1056,33,0,35,1026,0,1024,1056,1056,1057,1025,1,0,1,1056,1]

theorem envBound5124 : H12AffineFastState.Bounded env5124 := by
  intro p hp
  have h : env5124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5123_5124 : H12AffineEnvironment.transform 8 0 env5123 = env5124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5123 == env5124) = true)

theorem identity5124 : scanCanonicalize (H12AffineFastState.compose env5124 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 33) := by decide +kernel

theorem selectedBound5124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5125 : List Nat := [2,0,2,0,32,1,35,0,0,33,32,1,3,0,1,34,0,1,33,1,1,33,0,35,35,0,33,1,1,0,32,1,0,1,1,1]

theorem envBound5125 : H12AffineFastState.Bounded env5125 := by
  intro p hp
  have h : env5125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5124_5125 : H12AffineEnvironment.transform 9 33 env5124 = env5125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env5124 == env5125) = true)

def leafEnv5125 : List Nat := [2,0,2,0,32,1,35,0,0,33,32,1,3,0,1,34,0,1,33,1,1,33,0,35,32,35,1,0,33,1,1,0,32,1,0,1,0,2,1,1,1,0,0]

def active5125 : List Nat := [0,4]

def tree5125 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5125 : H12WitnessSearch.Good tree5125 := H12GlobalWitnessIndex.good

theorem leafIdentity5125 : H12AffineFastState.composeSystem env5125 rootObs = leafEnv5125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5125 rootObs == leafEnv5125) = true)

theorem terminalChecked5125 : H12PackedTerminal.terminalCheckFast leafEnv5125 active5125 tree5125 = true := by decide +kernel

def env5126 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4264,32768,65536,4097,81470,1024,32768,4096,41089,8388608,41003,8329,8388608,106006,4265,4265,2185,74794,8388793,173,168,4097,8389137]

theorem envBound5126 : H12AffineFastState.Bounded env5126 := by
  intro p hp
  have h : env5126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5112_5126 : H12AffineEnvironment.transform 21 41089 env5112 = env5126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5112 == env5126) = true)

theorem identity5126 : scanCanonicalize (H12AffineFastState.compose env5126 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5126 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5127 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,32768,65536,4097,81470,1024,32768,4096,41000,8388608,41003,8224,8388608,106006,4096,4096,2080,74794,8388624,4,1,4097,8389137]

theorem envBound5127 : H12AffineFastState.Bounded env5127 := by
  intro p hp
  have h : env5127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5126_5127 : H12AffineEnvironment.transform 6 41 env5126 = env5127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5126 == env5127) = true)

theorem identity5127 : scanCanonicalize (H12AffineFastState.compose env5127 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound5127 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env5128 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,32768,32803,4097,48669,1024,32768,4096,41000,8388608,41003,8224,8388608,7733,4096,4096,2080,41993,8388624,4,1,4097,8389137]

theorem envBound5128 : H12AffineFastState.Bounded env5128 := by
  intro p hp
  have h : env5128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5127_5128 : H12AffineEnvironment.transform 15 32803 env5127 = env5128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env5127 == env5128) = true)

theorem identity5128 : scanCanonicalize (H12AffineFastState.compose env5128 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5128 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5129 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,8200,8235,4097,7701,1024,8200,4096,32,8388608,35,8224,8388608,7733,4096,4096,2080,1025,8388624,4,1,4097,8389137]

theorem envBound5129 : H12AffineFastState.Bounded env5129 := by
  intro p hp
  have h : env5129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5128_5129 : H12AffineEnvironment.transform 14 8200 env5128 = env5129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5128 == env5129) = true)

theorem identity5129 : scanCanonicalize (H12AffineFastState.compose env5129 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5129 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5130 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1551,8192,1550,8200,8235,1550,2074,1024,8200,1551,32,8388608,35,8224,8388608,2106,1551,1551,2080,1025,8388624,4,1,1550,8389137]

theorem envBound5130 : H12AffineFastState.Bounded env5130 := by
  intro p hp
  have h : env5130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5129_5130 : H12AffineEnvironment.transform 11 1551 env5129 = env5130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env5129 == env5130) = true)

theorem identity5130 : scanCanonicalize (H12AffineFastState.compose env5130 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound5130 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5131 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1551,8192,1550,8200,8235,1550,2074,1024,8200,1551,32,17,35,8224,17,2106,1551,1551,2080,1025,1,4,1,1550,512]

theorem envBound5131 : H12AffineFastState.Bounded env5131 := by
  intro p hp
  have h : env5131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5130_5131 : H12AffineEnvironment.transform 22 17 env5130 = env5131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env5130 == env5131) = true)

theorem identity5131 : scanCanonicalize (H12AffineFastState.compose env5131 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5132 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1551,8192,1550,8200,8235,1550,1557,1024,8200,1551,32,17,35,8224,17,1589,1551,1551,1583,1025,1,4,1,1550,512]

theorem envBound5132 : H12AffineFastState.Bounded env5132 := by
  intro p hp
  have h : env5132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5131_5132 : H12AffineEnvironment.transform 10 1551 env5131 = env5132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5131 == env5132) = true)

theorem identity5132 : scanCanonicalize (H12AffineFastState.compose env5132 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5132 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5133 : List Nat := [2,4,8,16,27,17,18,4,512,1024,1551,1551,8192,1550,8200,8208,1550,1557,1024,8200,1551,27,17,24,8219,17,1550,1551,1551,1556,1025,1,4,1,1550,512]

theorem envBound5133 : H12AffineFastState.Bounded env5133 := by
  intro p hp
  have h : env5133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5132_5133 : H12AffineEnvironment.transform 4 27 env5132 = env5133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5132 == env5133) = true)

theorem identity5133 : scanCanonicalize (H12AffineFastState.compose env5133 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound5133 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5134 : List Nat := [2,4,8,16,27,17,18,4,512,1024,1551,1551,1053,1550,1045,1037,1550,1557,1024,1045,1551,27,17,24,1030,17,1550,1551,1551,1556,1025,1,4,1,1550,512]

theorem envBound5134 : H12AffineFastState.Bounded env5134 := by
  intro p hp
  have h : env5134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5133_5134 : H12AffineEnvironment.transform 12 1053 env5133 = env5134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env5133 == env5134) = true)

theorem identity5134 : scanCanonicalize (H12AffineFastState.compose env5134 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5134 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5135 : List Nat := [2,4,8,16,27,17,18,4,1,1024,1038,1038,1053,1039,1045,1037,1039,1044,1024,1045,1038,27,17,24,1030,17,1039,1038,1038,1045,1025,1,4,1,1039,1]

theorem envBound5135 : H12AffineFastState.Bounded env5135 := by
  intro p hp
  have h : env5135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5134_5135 : H12AffineEnvironment.transform 8 1 env5134 = env5135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5134 == env5135) = true)

theorem identity5135 : scanCanonicalize (H12AffineFastState.compose env5135 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5136 : List Nat := [2,4,8,16,27,17,18,4,1,14,0,0,19,1,27,3,1,26,14,27,0,27,17,24,8,17,1,0,0,27,15,1,4,1,1,1]

theorem envBound5136 : H12AffineFastState.Bounded env5136 := by
  intro p hp
  have h : env5136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5135_5136 : H12AffineEnvironment.transform 9 14 env5135 = env5136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5135 == env5136) = true)

def env5137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323792,16385,16893,22641,74795,12644669,257,20560,4239488,8389612]

theorem envBound5137 : H12AffineFastState.Bounded env5137 := by
  intro p hp
  have h : env5137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5076_5137 : H12AffineEnvironment.transform 18 1025 env5076 = env5137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5076 == env5137) = true)

theorem identity5137 : scanCanonicalize (H12AffineFastState.compose env5137 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5545) := by decide +kernel

theorem selectedBound5137 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,5545,41003,8329,5625,323792,16385,16893,22641,74795,4252820,257,20560,4239488,5701]

theorem envBound5138 : H12AffineFastState.Bounded env5138 := by
  intro p hp
  have h : env5138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5137_5138 : H12AffineEnvironment.transform 22 5545 env5137 = env5138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5545 env5137 == env5138) = true)

def env5139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,5545,41003,8329,5545,323712,16385,16813,22561,74795,4252820,257,20480,4239488,5653]

theorem envBound5139 : H12AffineFastState.Bounded env5139 := by
  intro p hp
  have h : env5139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5138_5139 : H12AffineEnvironment.transform 5 16 env5138 = env5139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5138 == env5139) = true)

def env5140 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41260,5545,41003,8329,5545,323712,16385,16813,22561,74795,17848,257,20480,4524,5653]

theorem envBound5140 : H12AffineFastState.Bounded env5140 := by
  intro p hp
  have h : env5140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5139_5140 : H12AffineEnvironment.transform 21 41260 env5139 = env5140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env5139 == env5140) = true)

theorem identity5140 : scanCanonicalize (H12AffineFastState.compose env5140 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5140 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env5141 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4096,41260,5376,41003,8224,5376,323625,16385,16644,22561,74795,17681,257,20480,4357,5653]

theorem envBound5141 : H12AffineFastState.Bounded env5141 := by
  intro p hp
  have h : env5141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5140_5141 : H12AffineEnvironment.transform 6 41 env5140 = env5141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5140 == env5141) = true)

def env5142 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,32768,65536,1044,262144,1025,32768,1296,41260,16,41003,8224,16,320825,16385,16644,19761,74795,17681,257,17680,1045,773]

theorem envBound5142 : H12AffineFastState.Bounded env5142 := by
  intro p hp
  have h : env5142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5141_5142 : H12AffineEnvironment.transform 11 1296 env5141 = env5142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env5141 == env5142) = true)

def env5143 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,32768,65536,1045,262144,1025,32768,1297,41260,17,41003,8224,17,320824,16385,16644,19760,74795,17681,257,17681,1044,772]

theorem envBound5143 : H12AffineFastState.Bounded env5143 := by
  intro p hp
  have h : env5143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5141_5143 : H12AffineEnvironment.transform 11 1297 env5141 = env5143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env5141 == env5143) = true)

theorem identity5143 : scanCanonicalize (H12AffineFastState.compose env5143 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5143 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5144 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,65536,1045,262144,1025,32768,1044,41001,17,41003,8224,17,320573,16385,16385,19509,74795,17428,4,17428,1044,513]

theorem envBound5144 : H12AffineFastState.Bounded env5144 := by
  intro p hp
  have h : env5144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5143_5144 : H12AffineEnvironment.transform 7 5 env5143 = env5144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5143 == env5144) = true)

theorem identity5144 : scanCanonicalize (H12AffineFastState.compose env5144 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5144 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5145 : List Nat := [2,4,8,16,32,16,41,5,32,1024,2048,1044,8192,16384,32768,65536,1045,262144,1025,32768,1044,41001,17,41003,8224,17,320573,16385,16385,19509,74795,17428,4,17428,1044,33]

theorem envBound5145 : H12AffineFastState.Bounded env5145 := by
  intro p hp
  have h : env5145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5144_5145 : H12AffineEnvironment.transform 8 32 env5144 = env5145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5144 == env5145) = true)

theorem identity5145 : scanCanonicalize (H12AffineFastState.compose env5145 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound5145 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5146 : List Nat := [2,4,8,16,32,16,41,5,32,1024,2048,1044,8192,16384,32768,25647,1045,262144,1025,32768,1044,41001,17,41003,8224,17,320573,16385,16385,19509,16388,17428,4,17428,1044,33]

theorem envBound5146 : H12AffineFastState.Bounded env5146 := by
  intro p hp
  have h : env5146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5145_5146 : H12AffineEnvironment.transform 15 25647 env5145 = env5146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env5145 == env5146) = true)

theorem identity5146 : scanCanonicalize (H12AffineFastState.compose env5146 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound5146 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5147 : List Nat := [2,4,8,16,32,16,41,5,32,1024,2048,1044,8192,16384,8216,25647,1045,262144,1025,8216,1044,49,17,51,8224,17,279589,16385,16385,19509,16388,17428,4,17428,1044,33]

theorem envBound5147 : H12AffineFastState.Bounded env5147 := by
  intro p hp
  have h : env5147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5146_5147 : H12AffineEnvironment.transform 14 8216 env5146 = env5147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env5146 == env5147) = true)

theorem identity5147 : scanCanonicalize (H12AffineFastState.compose env5147 (packedSelected [2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 39) := by decide +kernel

theorem selectedBound5147 : packedSelected [2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env5148 : List Nat := [2,4,8,16,32,16,41,5,32,1024,2048,1044,39,16384,63,17416,1045,262144,1025,63,1044,49,17,51,7,17,279589,16385,16385,19509,16388,17428,4,17428,1044,33]

theorem envBound5148 : H12AffineFastState.Bounded env5148 := by
  intro p hp
  have h : env5148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5147_5148 : H12AffineEnvironment.transform 12 39 env5147 = env5148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 39 env5147 == env5148) = true)

theorem identity5148 : scanCanonicalize (H12AffineFastState.compose env5148 (packedSelected [0,1,2,4,5,6,7,8,9,15] rootPS)) = affineNative (2^(17+1) ^^^ 2097) := by decide +kernel

theorem selectedBound5148 : packedSelected [0,1,2,4,5,6,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env5149 : List Nat := [2,4,8,16,32,16,41,5,32,1024,2048,1044,39,16384,63,17416,1045,2097,1025,63,1044,49,17,51,7,17,19476,16385,16385,19509,16388,17428,4,17428,1044,33]

theorem envBound5149 : H12AffineFastState.Bounded env5149 := by
  intro p hp
  have h : env5149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5148_5149 : H12AffineEnvironment.transform 17 2097 env5148 = env5149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2097 env5148 == env5149) = true)

theorem identity5149 : scanCanonicalize (H12AffineFastState.compose env5149 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5149 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5150 : List Nat := [2,4,8,1,32,1,41,5,32,1024,2048,1029,39,16384,46,17416,1028,2080,1025,46,1029,32,0,34,7,0,19461,16385,16385,19492,16388,17413,4,17413,1029,33]

theorem envBound5150 : H12AffineFastState.Bounded env5150 := by
  intro p hp
  have h : env5150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5149_5150 : H12AffineEnvironment.transform 3 1 env5149 = env5150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5149 == env5150) = true)

theorem identity5150 : scanCanonicalize (H12AffineFastState.compose env5150 (packedSelected [0,1,4] rootPS)) = affineNative (2^(13+1) ^^^ 3114) := by decide +kernel

theorem selectedBound5150 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5151 : List Nat := [2,4,8,1,32,1,41,5,32,1024,2048,1029,39,3114,46,2082,1028,2080,1025,46,1029,32,0,34,7,0,47,3115,3115,14,3118,2095,4,2095,1029,33]

theorem envBound5151 : H12AffineFastState.Bounded env5151 := by
  intro p hp
  have h : env5151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5150_5151 : H12AffineEnvironment.transform 13 3114 env5150 = env5151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3114 env5150 == env5151) = true)

theorem identity5151 : scanCanonicalize (H12AffineFastState.compose env5151 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5151 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5152 : List Nat := [2,4,8,1,32,1,41,5,32,14,2048,11,39,2084,46,2082,10,2080,15,46,11,32,0,34,7,0,47,2085,2085,14,2080,2095,4,2095,11,33]

theorem envBound5152 : H12AffineFastState.Bounded env5152 := by
  intro p hp
  have h : env5152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5151_5152 : H12AffineEnvironment.transform 9 14 env5151 = env5152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5151 == env5152) = true)

theorem identity5152 : scanCanonicalize (H12AffineFastState.compose env5152 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound5152 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5153 : List Nat := [2,4,8,1,32,1,41,5,32,14,37,11,39,1,46,7,10,5,15,46,11,32,0,34,7,0,47,0,0,14,5,10,4,10,11,33]

theorem envBound5153 : H12AffineFastState.Bounded env5153 := by
  intro p hp
  have h : env5153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5152_5153 : H12AffineEnvironment.transform 10 37 env5152 = env5153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env5152 == env5153) = true)

theorem identity5153 : scanCanonicalize (H12AffineFastState.compose env5153 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5153 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5154 : List Nat := [2,4,6,1,32,1,39,5,32,0,37,5,39,1,32,7,4,5,1,32,5,32,0,34,7,0,33,0,0,0,5,4,4,4,5,33]

theorem envBound5154 : H12AffineFastState.Bounded env5154 := by
  intro p hp
  have h : env5154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5153_5154 : H12AffineEnvironment.transform 2 6 env5153 = env5154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5153 == env5154) = true)

theorem identity5154 : scanCanonicalize (H12AffineFastState.compose env5154 (packedSelected [2,7] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound5154 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env5155 : List Nat := [2,4,6,1,4,1,3,5,4,0,1,5,3,1,4,7,4,5,1,4,5,4,0,6,7,0,5,0,0,0,5,4,4,4,5,5]

theorem envBound5155 : H12AffineFastState.Bounded env5155 := by
  intro p hp
  have h : env5155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5154_5155 : H12AffineEnvironment.transform 4 4 env5154 = env5155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env5154 == env5155) = true)

def leafEnv5155 : List Nat := [2,4,6,1,4,1,3,5,4,0,1,5,3,1,4,7,4,5,1,4,5,4,0,6,5,7,1,0,5,0,0,0,5,4,4,4,4,2,5,5,1,0,0]

def active5155 : List Nat := [0,1]

def tree5155 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5155 : H12WitnessSearch.Good tree5155 := H12GlobalWitnessIndex.good

theorem leafIdentity5155 : H12AffineFastState.composeSystem env5155 rootObs = leafEnv5155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5155 rootObs == leafEnv5155) = true)

theorem terminalChecked5155 : H12PackedTerminal.terminalCheckFast leafEnv5155 active5155 tree5155 = true := by decide +kernel

def env5156 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41261,5545,41003,8329,5545,323712,16385,16813,22561,74795,17849,257,20480,4525,5653]

theorem envBound5156 : H12AffineFastState.Bounded env5156 := by
  intro p hp
  have h : env5156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5139_5156 : H12AffineEnvironment.transform 21 41261 env5139 = env5156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env5139 == env5156) = true)

theorem identity5156 : scanCanonicalize (H12AffineFastState.compose env5156 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound5156 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env5157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1025,32768,4096,41261,5545,41003,8329,5545,323712,16385,16813,22561,16657,17849,257,20480,4525,5653]

theorem envBound5157 : H12AffineFastState.Bounded env5157 := by
  intro p hp
  have h : env5157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5156_5157 : H12AffineEnvironment.transform 15 25914 env5156 = env5157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env5156 == env5157) = true)

def env5158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1464,8192,16384,32768,25914,1045,262144,1025,32768,1464,41261,17,41003,8329,17,320824,16385,16813,19865,16657,17849,257,17848,1045,941]

theorem envBound5158 : H12AffineFastState.Bounded env5158 := by
  intro p hp
  have h : env5158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5157_5158 : H12AffineEnvironment.transform 11 1464 env5157 = env5158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env5157 == env5158) = true)

theorem identity5158 : scanCanonicalize (H12AffineFastState.compose env5158 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5158 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5159 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,32768,25914,1045,262144,1025,32768,1297,41261,17,41003,8224,17,320824,16385,16644,19760,16657,17680,257,17681,1045,772]

theorem envBound5159 : H12AffineFastState.Bounded env5159 := by
  intro p hp
  have h : env5159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5158_5159 : H12AffineEnvironment.transform 6 41 env5158 = env5159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5158 == env5159) = true)

theorem identity5159 : scanCanonicalize (H12AffineFastState.compose env5159 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 57623) := by decide +kernel

theorem selectedBound5159 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5160 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,32768,25914,1045,57623,1025,32768,1297,41261,17,41003,8224,17,1071,16385,16644,19760,16657,17680,257,17681,1045,772]

theorem envBound5160 : H12AffineFastState.Bounded env5160 := by
  intro p hp
  have h : env5160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5159_5160 : H12AffineEnvironment.transform 17 57623 env5159 = env5160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 57623 env5159 == env5160) = true)

theorem identity5160 : scanCanonicalize (H12AffineFastState.compose env5160 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 16410) := by decide +kernel

theorem selectedBound5160 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env5161 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,16410,25914,1045,8461,1025,16410,1297,24887,17,24625,8224,17,1071,16385,16644,19760,16657,17680,257,17681,1045,772]

theorem envBound5161 : H12AffineFastState.Bounded env5161 := by
  intro p hp
  have h : env5161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5160_5161 : H12AffineEnvironment.transform 14 16410 env5160 = env5161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16410 env5160 == env5161) = true)

theorem identity5161 : scanCanonicalize (H12AffineFastState.compose env5161 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5161 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5162 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,16384,16410,25662,1045,8201,1025,16410,1045,24627,17,24625,8224,17,1071,16385,16384,19508,16405,17428,5,17429,1045,512]

theorem envBound5162 : H12AffineFastState.Bounded env5162 := by
  intro p hp
  have h : env5162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5161_5162 : H12AffineEnvironment.transform 7 4 env5161 = env5162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5161 == env5162) = true)

theorem identity5162 : scanCanonicalize (H12AffineFastState.compose env5162 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 2106) := by decide +kernel

theorem selectedBound5162 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env5163 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,2106,2080,11268,1045,8201,1025,2080,1045,10249,17,10251,8224,17,1071,2107,2106,1038,2095,3118,5,3119,1045,512]

theorem envBound5163 : H12AffineFastState.Bounded env5163 := by
  intro p hp
  have h : env5163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5162_5163 : H12AffineEnvironment.transform 13 2106 env5162 = env5163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2106 env5162 == env5163) = true)

theorem identity5163 : scanCanonicalize (H12AffineFastState.compose env5163 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound5163 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env5164 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1076,1045,8192,1038,1044,8240,1045,8201,1025,1044,1045,9277,17,9279,8224,17,1071,1039,1038,1038,1051,26,5,27,1045,512]

theorem envBound5164 : H12AffineFastState.Bounded env5164 := by
  intro p hp
  have h : env5164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5163_5164 : H12AffineEnvironment.transform 10 1076 env5163 = env5164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env5163 == env5164) = true)

theorem identity5164 : scanCanonicalize (H12AffineFastState.compose env5164 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5164 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5165 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1076,1045,1062,1038,1044,1046,1045,1071,1025,1044,1045,27,17,25,1030,17,1071,1039,1038,1038,1051,26,5,27,1045,512]

theorem envBound5165 : H12AffineFastState.Bounded env5165 := by
  intro p hp
  have h : env5165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5164_5165 : H12AffineEnvironment.transform 12 1062 env5164 = env5165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5164 == env5165) = true)

theorem identity5165 : scanCanonicalize (H12AffineFastState.compose env5165 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound5165 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5166 : List Nat := [2,4,8,16,32,16,41,4,512,21,33,0,51,27,1,3,0,58,20,1,0,27,17,25,19,17,58,26,27,27,14,26,5,27,0,512]

theorem envBound5166 : H12AffineFastState.Bounded env5166 := by
  intro p hp
  have h : env5166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5165_5166 : H12AffineEnvironment.transform 9 21 env5165 = env5166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env5165 == env5166) = true)

theorem identity5166 : scanCanonicalize (H12AffineFastState.compose env5166 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5166 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env5167 : List Nat := [2,4,8,16,26,16,19,4,512,21,27,0,9,27,1,3,0,0,20,1,0,27,17,25,19,17,0,26,27,27,14,26,5,27,0,512]

theorem envBound5167 : H12AffineFastState.Bounded env5167 := by
  intro p hp
  have h : env5167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5166_5167 : H12AffineEnvironment.transform 4 26 env5166 = env5167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5166 == env5167) = true)

theorem identity5167 : scanCanonicalize (H12AffineFastState.compose env5167 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5168 : List Nat := [2,4,8,11,1,11,8,4,512,14,0,0,9,0,1,3,0,0,15,1,0,0,10,2,8,10,0,1,0,0,14,1,5,0,0,512]

theorem envBound5168 : H12AffineFastState.Bounded env5168 := by
  intro p hp
  have h : env5168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5167_5168 : H12AffineEnvironment.transform 3 11 env5167 = env5168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5167 == env5168) = true)

theorem identity5168 : scanCanonicalize (H12AffineFastState.compose env5168 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5168 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env5169 : List Nat := [2,4,8,11,1,11,8,4,1,14,0,0,9,0,1,3,0,0,15,1,0,0,10,2,8,10,0,1,0,0,14,1,5,0,0,1]

theorem envBound5169 : H12AffineFastState.Bounded env5169 := by
  intro p hp
  have h : env5169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5168_5169 : H12AffineEnvironment.transform 8 1 env5168 = env5169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5168 == env5169) = true)

def env5170 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1465,8192,16384,32768,25914,1044,262144,1025,32768,1465,41261,16,41003,8329,16,320825,16385,16813,19864,16657,17849,257,17849,1044,940]

theorem envBound5170 : H12AffineFastState.Bounded env5170 := by
  intro p hp
  have h : env5170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5157_5170 : H12AffineEnvironment.transform 11 1465 env5157 = env5170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env5157 == env5170) = true)

theorem identity5170 : scanCanonicalize (H12AffineFastState.compose env5170 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5170 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5171 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,16384,32768,25663,1044,262144,1025,32768,1212,41000,16,41003,8329,16,320572,16385,16552,19613,16404,17596,4,17596,1044,681]

theorem envBound5171 : H12AffineFastState.Bounded env5171 := by
  intro p hp
  have h : env5171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5170_5171 : H12AffineEnvironment.transform 7 5 env5170 = env5171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5170 == env5171) = true)

theorem identity5171 : scanCanonicalize (H12AffineFastState.compose env5171 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5171 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env5172 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,1588,32768,8715,1044,262144,1025,32768,1212,41000,16,41003,8329,16,303624,1589,1692,2729,1568,648,4,648,1044,681]

theorem envBound5172 : H12AffineFastState.Bounded env5172 := by
  intro p hp
  have h : env5172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5171_5172 : H12AffineEnvironment.transform 13 1588 env5171 = env5172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1588 env5171 == env5172) = true)

theorem identity5172 : scanCanonicalize (H12AffineFastState.compose env5172 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound5172 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env5173 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,1588,8353,8715,1044,262144,1025,8353,1212,137,16,138,8329,16,262825,1589,1692,2729,1568,648,4,648,1044,681]

theorem envBound5173 : H12AffineFastState.Bounded env5173 := by
  intro p hp
  have h : env5173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5172_5173 : H12AffineEnvironment.transform 14 8353 env5172 = env5173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5172 == env5173) = true)

theorem identity5173 : scanCanonicalize (H12AffineFastState.compose env5173 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2728) := by decide +kernel

theorem selectedBound5173 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5174 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1212,8192,1588,8353,8715,1044,2728,1025,8353,1212,137,16,138,8329,16,2049,1589,1692,2729,1568,648,4,648,1044,681]

theorem envBound5174 : H12AffineFastState.Bounded env5174 := by
  intro p hp
  have h : env5174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5173_5174 : H12AffineEnvironment.transform 17 2728 env5173 = env5174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2728 env5173 == env5174) = true)

theorem identity5174 : scanCanonicalize (H12AffineFastState.compose env5174 (packedSelected [2,5,6,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound5174 : packedSelected [2,5,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env5175 : List Nat := [2,4,8,16,32,16,128,5,146,1024,2048,1212,8192,1190,8353,8345,1044,2106,1025,8353,1212,137,16,138,8329,16,2049,1191,1038,2107,1202,26,4,26,1044,59]

theorem envBound5175 : H12AffineFastState.Bounded env5175 := by
  intro p hp
  have h : env5175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5174_5175 : H12AffineEnvironment.transform 8 146 env5174 = env5175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env5174 == env5175) = true)

theorem identity5175 : scanCanonicalize (H12AffineFastState.compose env5175 (packedSelected [0,2,7,13] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound5175 : packedSelected [0,2,7,13] rootPS < 2^1333 := by decide +kernel

def env5176 : List Nat := [2,4,8,16,32,16,128,5,146,53,2048,137,8192,147,8353,8345,33,2106,52,8353,137,137,16,138,8329,16,2049,146,59,2107,135,26,4,26,33,59]

theorem envBound5176 : H12AffineFastState.Bounded env5176 := by
  intro p hp
  have h : env5176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5175_5176 : H12AffineEnvironment.transform 9 53 env5175 = env5176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env5175 == env5176) = true)

theorem identity5176 : scanCanonicalize (H12AffineFastState.compose env5176 (packedSelected [1,2,3,4,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound5176 : packedSelected [1,2,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env5177 : List Nat := [2,4,8,16,32,16,128,5,146,53,2048,137,8,147,169,145,33,2106,52,169,137,137,16,138,129,16,2049,146,59,2107,135,26,4,26,33,59]

theorem envBound5177 : H12AffineFastState.Bounded env5177 := by
  intro p hp
  have h : env5177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5176_5177 : H12AffineEnvironment.transform 12 8 env5176 = env5177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env5176 == env5177) = true)

theorem identity5177 : scanCanonicalize (H12AffineFastState.compose env5177 (packedSelected [1,2,3,4,5,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound5177 : packedSelected [1,2,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env5178 : List Nat := [2,4,8,16,32,16,51,5,33,53,2048,58,8,32,26,34,33,2106,52,26,58,58,16,57,50,16,2049,33,59,2107,52,26,4,26,33,59]

theorem envBound5178 : H12AffineFastState.Bounded env5178 := by
  intro p hp
  have h : env5178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5177_5178 : H12AffineEnvironment.transform 6 51 env5177 = env5178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env5177 == env5178) = true)

theorem identity5178 : scanCanonicalize (H12AffineFastState.compose env5178 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound5178 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5179 : List Nat := [2,4,8,16,32,16,51,5,33,53,59,58,8,32,26,34,33,1,52,26,58,58,16,57,50,16,58,33,59,0,52,26,4,26,33,59]

theorem envBound5179 : H12AffineFastState.Bounded env5179 := by
  intro p hp
  have h : env5179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5178_5179 : H12AffineEnvironment.transform 10 59 env5178 = env5179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env5178 == env5179) = true)

theorem identity5179 : scanCanonicalize (H12AffineFastState.compose env5179 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5179 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5180 : List Nat := [2,4,8,16,1,16,18,5,0,20,26,27,8,1,26,3,0,1,21,26,27,27,16,24,19,16,27,0,26,0,21,26,4,26,0,26]

theorem envBound5180 : H12AffineFastState.Bounded env5180 := by
  intro p hp
  have h : env5180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5179_5180 : H12AffineEnvironment.transform 4 1 env5179 = env5180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5179 == env5180) = true)

theorem identity5180 : scanCanonicalize (H12AffineFastState.compose env5180 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5180 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5181 : List Nat := [2,4,8,11,1,11,9,5,0,15,1,0,8,1,1,3,0,1,14,1,0,0,11,3,8,11,0,0,1,0,14,1,4,1,0,1]

theorem envBound5181 : H12AffineFastState.Bounded env5181 := by
  intro p hp
  have h : env5181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5180_5181 : H12AffineEnvironment.transform 3 11 env5180 = env5181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5180 == env5181) = true)

theorem identity5181 : scanCanonicalize (H12AffineFastState.compose env5181 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5182 : List Nat := [2,4,2,1,1,1,3,5,0,5,1,0,2,1,1,3,0,1,4,1,0,0,1,3,2,1,0,0,1,0,4,1,4,1,0,1]

theorem envBound5182 : H12AffineFastState.Bounded env5182 := by
  intro p hp
  have h : env5182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5181_5182 : H12AffineEnvironment.transform 2 2 env5181 = env5182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5181 == env5182) = true)

theorem identity5182 : scanCanonicalize (H12AffineFastState.compose env5182 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5183 : List Nat := [2,0,2,1,1,1,3,1,0,1,1,0,2,1,1,3,0,1,0,1,0,0,1,3,2,1,0,0,1,0,0,1,0,1,0,1]

theorem envBound5183 : H12AffineFastState.Bounded env5183 := by
  intro p hp
  have h : env5183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5182_5183 : H12AffineEnvironment.transform 1 0 env5182 = env5183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5182 == env5183) = true)

def env5184 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,5545,41003,8329,5544,323713,16385,16812,22560,74795,4252820,257,20481,4239488,5652]

theorem envBound5184 : H12AffineFastState.Bounded env5184 := by
  intro p hp
  have h : env5184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5138_5184 : H12AffineEnvironment.transform 5 17 env5138 = env5184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5138 == env5184) = true)

theorem identity5184 : scanCanonicalize (H12AffineFastState.compose env5184 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound5184 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5185 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1464,262144,1025,32768,1044,4194304,445,41003,8329,444,320661,16385,16812,19508,74795,4252820,257,17429,4236436,512]

theorem envBound5185 : H12AffineFastState.Bounded env5185 := by
  intro p hp
  have h : env5185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5184_5185 : H12AffineEnvironment.transform 11 1044 env5184 = env5185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env5184 == env5185) = true)

theorem identity5185 : scanCanonicalize (H12AffineFastState.compose env5185 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5185 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5186 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1464,262144,1025,32768,1044,41348,445,41003,8329,444,320661,16385,16812,19508,74795,17680,257,17429,1296,512]

theorem envBound5186 : H12AffineFastState.Bounded env5186 := by
  intro p hp
  have h : env5186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5185_5186 : H12AffineEnvironment.transform 21 41348 env5185 = env5186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5185 == env5186) = true)

theorem identity5186 : scanCanonicalize (H12AffineFastState.compose env5186 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5186 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5187 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26260,65536,1464,262144,1025,26260,1044,18192,445,18111,8329,444,262657,16385,16812,19508,74795,17680,257,17429,1296,512]

theorem envBound5187 : H12AffineFastState.Bounded env5187 := by
  intro p hp
  have h : env5187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5186_5187 : H12AffineEnvironment.transform 14 26260 env5186 = env5187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5186 == env5187) = true)

theorem identity5187 : scanCanonicalize (H12AffineFastState.compose env5187 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25750) := by decide +kernel

theorem selectedBound5187 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5188 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26260,25750,1464,262144,1025,26260,1044,18192,445,18111,8329,444,262657,16385,16812,19508,16573,17680,257,17429,1296,512]

theorem envBound5188 : H12AffineFastState.Bounded env5188 := by
  intro p hp
  have h : env5188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5187_5188 : H12AffineEnvironment.transform 15 25750 env5187 = env5188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25750 env5187 == env5188) = true)

theorem identity5188 : scanCanonicalize (H12AffineFastState.compose env5188 (packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound5188 : packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env5189 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26260,25750,1464,2341,1025,26260,1044,18192,445,18111,8329,444,2852,16385,16812,19508,16573,17680,257,17429,1296,512]

theorem envBound5189 : H12AffineFastState.Bounded env5189 := by
  intro p hp
  have h : env5189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5188_5189 : H12AffineEnvironment.transform 17 2341 env5188 = env5189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env5188 == env5189) = true)

theorem identity5189 : scanCanonicalize (H12AffineFastState.compose env5189 (packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound5189 : packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS < 2^1333 := by decide +kernel

def env5190 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,1840,8612,9126,1464,2341,1025,8612,1044,32,445,399,8329,444,2852,1841,1692,2820,1933,544,257,805,1296,512]

theorem envBound5190 : H12AffineFastState.Bounded env5190 := by
  intro p hp
  have h : env5190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5189_5190 : H12AffineEnvironment.transform 13 1840 env5189 = env5190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env5189 == env5190) = true)

theorem identity5190 : scanCanonicalize (H12AffineFastState.compose env5190 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5190 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5191 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1044,8192,1840,8460,8974,1296,2341,1025,8460,1044,32,277,295,8225,276,2852,1841,1588,2820,1829,544,257,805,1296,512]

theorem envBound5191 : H12AffineFastState.Bounded env5191 := by
  intro p hp
  have h : env5191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5190_5191 : H12AffineEnvironment.transform 6 40 env5190 = env5191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5190 == env5191) = true)

theorem identity5191 : scanCanonicalize (H12AffineFastState.compose env5191 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5191 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1