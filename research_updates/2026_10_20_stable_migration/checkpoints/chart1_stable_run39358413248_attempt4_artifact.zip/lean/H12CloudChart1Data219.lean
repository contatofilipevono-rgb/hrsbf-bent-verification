import H12CloudChart1Data218

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans55451_55452 : H12AffineEnvironment.transform 14 29909 env55451 = env55452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env55451 == env55452) = true)

theorem identity55452 : scanCanonicalize (H12AffineFastState.compose env55452 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound55452 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,16400,10708,1025,29908,12573,8200,17,21763,8328,64,10589,5392,25693,23808,9344,8320,257,21792,16464,512]

theorem envBound55453 : H12AffineFastState.Bounded env55453 := by
  intro p hp
  have h : env55453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55452_55453 : H12AffineEnvironment.transform 17 10708 env55452 = env55453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env55452 == env55453) = true)

theorem identity55453 : scanCanonicalize (H12AffineFastState.compose env55453 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55453 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env55454 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,29909,34,16400,10401,1025,29908,12392,8200,17,21622,8328,64,10280,5221,25693,23669,9344,8320,116,21589,16464,512]

theorem envBound55454 : H12AffineFastState.Bounded env55454 := by
  intro p hp
  have h : env55454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55453_55454 : H12AffineEnvironment.transform 7 117 env55453 = env55454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55453 == env55454) = true)

theorem identity55454 : scanCanonicalize (H12AffineFastState.compose env55454 (packedSelected [0,1,7,8,10,11,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 6320) := by decide +kernel

theorem selectedBound55454 : packedSelected [0,1,7,8,10,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env55455 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,6320,16384,19557,34,16400,4113,1025,19556,2264,6328,17,21622,6200,64,4248,5221,23789,23669,7216,6192,116,21589,16464,512]

theorem envBound55455 : H12AffineFastState.Bounded env55455 := by
  intro p hp
  have h : env55455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55454_55455 : H12AffineEnvironment.transform 12 6320 env55454 = env55455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6320 env55454 == env55455) = true)

theorem identity55455 : scanCanonicalize (H12AffineFastState.compose env55455 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound55455 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env55456 : List Nat := [2,4,8,16,32,64,128,117,512,1024,112,4096,4288,16384,17429,34,16400,4113,1025,17428,168,4296,17,21622,4168,64,4248,5221,21661,21509,5184,4160,116,21589,16464,512]

theorem envBound55456 : H12AffineFastState.Bounded env55456 := by
  intro p hp
  have h : env55456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55455_55456 : H12AffineEnvironment.transform 10 112 env55455 = env55456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env55455 == env55456) = true)

theorem identity55456 : scanCanonicalize (H12AffineFastState.compose env55456 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound55456 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55457 : List Nat := [2,4,8,16,32,64,128,117,512,1024,112,4096,4288,5205,4160,34,5189,4113,1025,4161,168,4296,17,35,4168,64,4248,5221,200,80,5184,4160,116,0,5125,512]

theorem envBound55457 : H12AffineFastState.Bounded env55457 := by
  intro p hp
  have h : env55457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55456_55457 : H12AffineEnvironment.transform 13 5205 env55456 = env55457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env55456 == env55457) = true)

theorem identity55457 : scanCanonicalize (H12AffineFastState.compose env55457 (packedSelected [0,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound55457 : packedSelected [0,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env55458 : List Nat := [2,4,8,16,32,64,128,117,512,1024,112,153,89,1228,217,34,1244,136,1025,216,168,81,17,35,209,64,1,1276,200,80,1241,217,116,0,1180,512]

theorem envBound55458 : H12AffineFastState.Bounded env55458 := by
  intro p hp
  have h : env55458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55457_55458 : H12AffineEnvironment.transform 11 153 env55457 = env55458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env55457 == env55458) = true)

theorem identity55458 : scanCanonicalize (H12AffineFastState.compose env55458 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound55458 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env55459 : List Nat := [2,4,8,16,32,64,88,117,512,1024,112,65,89,1044,1,34,1028,80,1025,0,112,81,17,35,9,64,1,1060,16,80,1025,1,116,0,1092,512]

theorem envBound55459 : H12AffineFastState.Bounded env55459 := by
  intro p hp
  have h : env55459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55458_55459 : H12AffineEnvironment.transform 6 88 env55458 = env55459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env55458 == env55459) = true)

theorem identity55459 : scanCanonicalize (H12AffineFastState.compose env55459 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound55459 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55460 : List Nat := [2,4,8,16,32,48,40,5,512,1024,0,49,41,1044,1,34,1028,32,1025,0,0,33,17,35,9,48,1,1060,16,32,1025,1,4,0,1076,512]

theorem envBound55460 : H12AffineFastState.Bounded env55460 := by
  intro p hp
  have h : env55460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55459_55460 : H12AffineEnvironment.transform 5 48 env55459 = env55460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env55459 == env55460) = true)

theorem identity55460 : scanCanonicalize (H12AffineFastState.compose env55460 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound55460 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55461 : List Nat := [2,4,8,16,32,48,40,5,512,574,0,49,41,554,1,34,570,32,575,0,0,33,17,35,9,48,1,538,16,32,575,1,4,0,522,512]

theorem envBound55461 : H12AffineFastState.Bounded env55461 := by
  intro p hp
  have h : env55461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55460_55461 : H12AffineEnvironment.transform 9 574 env55460 = env55461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env55460 == env55461) = true)

theorem identity55461 : scanCanonicalize (H12AffineFastState.compose env55461 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound55461 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55462 : List Nat := [2,4,8,3,32,35,40,5,512,557,0,34,41,554,1,34,553,32,556,0,0,33,2,35,9,35,1,521,3,32,556,1,4,0,522,512]

theorem envBound55462 : H12AffineFastState.Bounded env55462 := by
  intro p hp
  have h : env55462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55461_55462 : H12AffineEnvironment.transform 3 3 env55461 = env55462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env55461 == env55462) = true)

def env55463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,50633,264669,65863,106625,8328,64,75787,57796,102879,360790,75222,264532,257,106658,82183,513]

theorem envBound55463 : H12AffineFastState.Bounded env55463 := by
  intro p hp
  have h : env55463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55449_55463 : H12AffineEnvironment.transform 16 16401 env55449 = env55463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55449 == env55463) = true)

theorem identity55463 : scanCanonicalize (H12AffineFastState.compose env55463 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55463 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,50633,264669,8525,32907,8328,64,2049,57796,45525,303452,1500,264532,257,32936,24845,513]

theorem envBound55464 : H12AffineFastState.Bounded env55464 := by
  intro p hp
  have h : env55464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55463_55464 : H12AffineEnvironment.transform 15 8202 env55463 = env55464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55463 == env55464) = true)

theorem identity55464 : scanCanonicalize (H12AffineFastState.compose env55464 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound55464 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env55465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10401,1025,32769,50633,8572,8525,32907,8328,64,2049,57796,45525,35325,1500,8693,257,32936,24845,513]

theorem envBound55465 : H12AffineFastState.Bounded env55465 := by
  intro p hp
  have h : env55465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55464_55465 : H12AffineEnvironment.transform 17 10401 env55464 = env55465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55464 == env55465) = true)

theorem identity55465 : scanCanonicalize (H12AffineFastState.compose env55465 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55465 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16401,10401,1025,1,17865,8572,8525,139,8328,64,2049,25028,12757,2557,1500,8693,257,168,24845,513]

theorem envBound55466 : H12AffineFastState.Bounded env55466 := by
  intro p hp
  have h : env55466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55465_55466 : H12AffineEnvironment.transform 14 0 env55465 = env55466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55465 == env55466) = true)

theorem identity55466 : scanCanonicalize (H12AffineFastState.compose env55466 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55466 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env55467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,0,262,16401,2477,1025,1,17865,112,65,139,388,64,2049,16584,4313,2557,1500,249,257,168,16385,513]

theorem envBound55467 : H12AffineFastState.Bounded env55467 := by
  intro p hp
  have h : env55467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55466_55467 : H12AffineEnvironment.transform 12 268 env55466 = env55467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55466 == env55467) = true)

theorem identity55467 : scanCanonicalize (H12AffineFastState.compose env55467 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55467 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env55468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,0,262,16401,2340,1025,1,17728,112,65,2,269,64,2049,16449,4176,2420,1365,112,257,33,16385,513]

theorem envBound55468 : H12AffineFastState.Bounded env55468 := by
  intro p hp
  have h : env55468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55467_55468 : H12AffineEnvironment.transform 6 9 env55467 = env55468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55467 == env55468) = true)

theorem identity55468 : scanCanonicalize (H12AffineFastState.compose env55468 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55468 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55469 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16401,2340,1025,1,17680,32,17,2,269,16,2049,16401,4096,2340,1285,32,257,33,16385,513]

theorem envBound55469 : H12AffineFastState.Bounded env55469 := by
  intro p hp
  have h : env55469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55468_55469 : H12AffineEnvironment.transform 5 16 env55468 = env55469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55468 == env55469) = true)

theorem identity55469 : scanCanonicalize (H12AffineFastState.compose env55469 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound55469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55470 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,1297,0,262,1280,2340,1025,1,1,32,17,2,269,16,2049,1280,4096,2340,1285,32,257,33,1296,513]

theorem envBound55470 : H12AffineFastState.Bounded env55470 := by
  intro p hp
  have h : env55470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55469_55470 : H12AffineEnvironment.transform 13 1297 env55469 = env55470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env55469 == env55470) = true)

theorem identity55470 : scanCanonicalize (H12AffineFastState.compose env55470 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound55470 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55471 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,308,268,1297,0,262,1280,2340,1025,1,1,32,17,2,269,16,2049,1280,308,2340,1285,32,257,33,1296,513]

theorem envBound55471 : H12AffineFastState.Bounded env55471 := by
  intro p hp
  have h : env55471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55470_55471 : H12AffineEnvironment.transform 11 308 env55470 = env55471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env55470 == env55471) = true)

theorem identity55471 : scanCanonicalize (H12AffineFastState.compose env55471 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound55471 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55472 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1296,308,268,1297,0,262,1280,1076,1025,1,1,32,17,2,269,16,1297,1280,308,1076,1285,32,257,33,1296,513]

theorem envBound55472 : H12AffineFastState.Bounded env55472 := by
  intro p hp
  have h : env55472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55471_55472 : H12AffineEnvironment.transform 10 1296 env55471 = env55472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env55471 == env55472) = true)

theorem identity55472 : scanCanonicalize (H12AffineFastState.compose env55472 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55472 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env55473 : List Nat := [2,4,8,16,32,16,9,256,512,52,292,308,268,293,0,262,308,0,53,1,1,32,17,2,269,16,293,308,308,0,305,32,257,33,292,513]

theorem envBound55473 : H12AffineFastState.Bounded env55473 := by
  intro p hp
  have h : env55473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55472_55473 : H12AffineEnvironment.transform 9 52 env55472 = env55473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55472 == env55473) = true)

theorem identity55473 : scanCanonicalize (H12AffineFastState.compose env55473 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound55473 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55474 : List Nat := [2,4,8,16,32,16,9,256,260,52,292,308,268,293,0,262,308,0,53,1,1,32,17,2,269,16,293,308,308,0,305,32,257,33,292,261]

theorem envBound55474 : H12AffineFastState.Bounded env55474 := by
  intro p hp
  have h : env55474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55473_55474 : H12AffineEnvironment.transform 8 260 env55473 = env55474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env55473 == env55474) = true)

def env55475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213334,16777216,8328,64,16959643,16974165,102878,360790,16958790,17148372,257,16777250,16834951,17031825]

theorem envBound55475 : H12AffineFastState.Bounded env55475 := by
  intro p hp
  have h : env55475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55447_55475 : H12AffineEnvironment.transform 20 165337 env55447 = env55475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env55447 == env55475) = true)

theorem identity55475 : scanCanonicalize (H12AffineFastState.compose env55475 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound55475 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env55476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115870,329867,17,16777216,8328,64,16878044,16793618,102878,360790,16876545,17148372,257,16777250,16834951,16819158]

theorem envBound55476 : H12AffineFastState.Bounded env55476 := by
  intro p hp
  have h : env55476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55475_55476 : H12AffineEnvironment.transform 16 82247 env55475 = env55476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env55475 == env55476) = true)

def env55477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115870,329867,17,95496,8328,64,64724,79130,102878,360790,61705,318684,257,95530,103567,120542]

theorem envBound55477 : H12AffineFastState.Bounded env55477 := by
  intro p hp
  have h : env55477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55476_55477 : H12AffineEnvironment.transform 23 95496 env55476 = env55477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env55476 == env55477) = true)

theorem identity55477 : scanCanonicalize (H12AffineFastState.compose env55477 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound55477 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38296,262144,1025,32769,4161,318548,17,41431,8328,64,64724,57797,17665,284041,61705,318684,257,41461,16464,513]

theorem envBound55478 : H12AffineFastState.Bounded env55478 := by
  intro p hp
  have h : env55478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55477_55478 : H12AffineEnvironment.transform 15 54495 env55477 = env55478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env55477 == env55478) = true)

def env55479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,4161,318548,17,41311,8192,64,64604,57677,17665,283905,61705,318548,257,41341,16464,513]

theorem envBound55479 : H12AffineFastState.Bounded env55479 := by
  intro p hp
  have h : env55479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55478_55479 : H12AffineEnvironment.transform 6 8 env55478 = env55479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55478 == env55479) = true)

theorem identity55479 : scanCanonicalize (H12AffineFastState.compose env55479 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55479 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10281,1025,32769,4161,62589,17,41311,8192,64,64604,57677,17665,32040,61705,62589,257,41341,16464,513]

theorem envBound55480 : H12AffineFastState.Bounded env55480 := by
  intro p hp
  have h : env55480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55479_55480 : H12AffineEnvironment.transform 17 10281 env55479 = env55480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55479 == env55480) = true)

theorem identity55480 : scanCanonicalize (H12AffineFastState.compose env55480 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55480 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env55481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,38160,10281,1025,32769,4161,41341,17,41311,8192,64,43356,46157,4097,10280,41993,41341,257,41341,5456,513]

theorem envBound55481 : H12AffineFastState.Bounded env55481 := by
  intro p hp
  have h : env55481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55480_55481 : H12AffineEnvironment.transform 13 5376 env55480 = env55481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55480 == env55481) = true)

theorem identity55481 : scanCanonicalize (H12AffineFastState.compose env55481 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55481 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,32768,33111,38160,2049,1025,32769,4161,33109,17,33143,40,64,35188,37989,4097,2048,33825,33109,257,33109,5456,513]

theorem envBound55482 : H12AffineFastState.Bounded env55482 := by
  intro p hp
  have h : env55482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55481_55482 : H12AffineEnvironment.transform 12 40 env55481 = env55482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55481 == env55482) = true)

theorem identity55482 : scanCanonicalize (H12AffineFastState.compose env55482 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound55482 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env55483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,81,262,5441,2049,1025,80,4161,260,17,294,40,64,2341,5172,4097,2048,1136,260,257,260,5456,513]

theorem envBound55483 : H12AffineFastState.Bounded env55483 := by
  intro p hp
  have h : env55483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55482_55483 : H12AffineEnvironment.transform 14 81 env55482 = env55483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env55482 == env55483) = true)

theorem identity55483 : scanCanonicalize (H12AffineFastState.compose env55483 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55483 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55484 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5156,81,34,5221,2049,1025,80,4161,32,17,2,40,64,2049,5172,4097,2048,1136,32,37,32,5236,513]

theorem envBound55484 : H12AffineFastState.Bounded env55484 := by
  intro p hp
  have h : env55484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55483_55484 : H12AffineEnvironment.transform 7 36 env55483 = env55484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55483 == env55484) = true)

theorem identity55484 : scanCanonicalize (H12AffineFastState.compose env55484 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound55484 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55485 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,40,81,81,34,16,2049,1025,80,1076,32,17,2,40,64,2049,65,1140,2048,1136,32,37,32,1,513]

theorem envBound55485 : H12AffineFastState.Bounded env55485 := by
  intro p hp
  have h : env55485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55484_55485 : H12AffineEnvironment.transform 11 1141 env55484 = env55485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env55484 == env55485) = true)

theorem identity55485 : scanCanonicalize (H12AffineFastState.compose env55485 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55485 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55486 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1060,40,0,0,34,16,2049,1025,1,1076,32,17,2,40,17,2049,16,1061,2048,1057,32,37,32,1,513]

theorem envBound55486 : H12AffineFastState.Bounded env55486 := by
  intro p hp
  have h : env55486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55485_55486 : H12AffineEnvironment.transform 5 17 env55485 = env55486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55485 == env55486) = true)

theorem identity55486 : scanCanonicalize (H12AffineFastState.compose env55486 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound55486 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55487 : List Nat := [2,4,8,16,32,17,8,36,512,36,2048,0,40,0,0,34,16,2049,37,1,16,32,17,2,40,17,2049,16,1,2048,5,32,37,32,1,513]

theorem envBound55487 : H12AffineFastState.Bounded env55487 := by
  intro p hp
  have h : env55487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55486_55487 : H12AffineEnvironment.transform 9 36 env55486 = env55487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env55486 == env55487) = true)

theorem identity55487 : scanCanonicalize (H12AffineFastState.compose env55487 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound55487 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55488 : List Nat := [2,4,8,16,32,17,8,36,512,36,11,0,40,0,0,34,16,10,37,1,16,32,17,2,40,17,10,16,1,11,5,32,37,32,1,513]

theorem envBound55488 : H12AffineFastState.Bounded env55488 := by
  intro p hp
  have h : env55488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55487_55488 : H12AffineEnvironment.transform 10 11 env55487 = env55488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env55487 == env55488) = true)

theorem identity55488 : scanCanonicalize (H12AffineFastState.compose env55488 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound55488 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55489 : List Nat := [2,4,8,16,26,17,8,30,512,30,11,0,18,0,0,24,16,10,31,1,16,26,17,2,18,17,10,16,1,11,5,26,31,26,1,513]

theorem envBound55489 : H12AffineFastState.Bounded env55489 := by
  intro p hp
  have h : env55489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55488_55489 : H12AffineEnvironment.transform 4 26 env55488 = env55489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env55488 == env55489) = true)

theorem identity55489 : scanCanonicalize (H12AffineFastState.compose env55489 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55489 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55490 : List Nat := [2,4,8,11,1,10,8,5,512,5,11,0,9,0,0,3,11,10,4,1,11,1,10,2,9,10,10,11,1,11,5,1,4,1,1,513]

theorem envBound55490 : H12AffineFastState.Bounded env55490 := by
  intro p hp
  have h : env55490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55489_55490 : H12AffineEnvironment.transform 3 11 env55489 = env55490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55489 == env55490) = true)

theorem identity55490 : scanCanonicalize (H12AffineFastState.compose env55490 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55491 : List Nat := [2,4,6,5,1,4,6,5,512,5,5,0,7,0,0,3,5,4,4,1,5,1,4,2,7,4,4,5,1,5,5,1,4,1,1,513]

theorem envBound55491 : H12AffineFastState.Bounded env55491 := by
  intro p hp
  have h : env55491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55490_55491 : H12AffineEnvironment.transform 2 6 env55490 = env55491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55490 == env55491) = true)

def env55492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,4161,318548,17,41310,8193,64,64605,57676,17665,283904,61705,318549,257,41340,16464,513]

theorem envBound55492 : H12AffineFastState.Bounded env55492 := by
  intro p hp
  have h : env55492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55478_55492 : H12AffineEnvironment.transform 6 9 env55478 = env55492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55478 == env55492) = true)

theorem identity55492 : scanCanonicalize (H12AffineFastState.compose env55492 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound55492 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,35188,1025,32769,4161,21792,17,41310,8193,64,64605,57676,17665,56436,61705,21793,257,41340,16464,513]

theorem envBound55493 : H12AffineFastState.Bounded env55493 := by
  intro p hp
  have h : env55493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55492_55493 : H12AffineEnvironment.transform 17 35188 env55492 = env55493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env55492 == env55493) = true)

theorem identity55493 : scanCanonicalize (H12AffineFastState.compose env55493 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound55493 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env55494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28699,12636,11577,1025,9292,4161,21792,17,1299,8193,64,22544,17665,17665,30777,21828,21793,257,1329,16464,513]

theorem envBound55494 : H12AffineFastState.Bounded env55494 := by
  intro p hp
  have h : env55494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55493_55494 : H12AffineEnvironment.transform 14 9293 env55493 = env55494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env55493 == env55494) = true)

theorem identity55494 : scanCanonicalize (H12AffineFastState.compose env55494 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55494 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1297,20807,4096,3173,1025,1296,4161,21792,17,1299,349,64,22544,17665,17665,22885,21828,21793,257,1329,16464,513]

theorem envBound55495 : H12AffineFastState.Bounded env55495 := by
  intro p hp
  have h : env55495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55494_55495 : H12AffineEnvironment.transform 12 348 env55494 = env55495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55494 == env55495) = true)

theorem identity55495 : scanCanonicalize (H12AffineFastState.compose env55495 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55495 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1297,1094,4096,3173,1025,1296,4161,33,17,1299,349,64,3345,4096,4096,3172,69,32,257,1329,5457,513]

theorem envBound55496 : H12AffineFastState.Bounded env55496 := by
  intro p hp
  have h : env55496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55495_55496 : H12AffineEnvironment.transform 13 5377 env55495 = env55496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55495 == env55496) = true)

theorem identity55496 : scanCanonicalize (H12AffineFastState.compose env55496 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55496 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55497 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4113,1,342,4096,2421,273,0,4161,33,17,3,349,64,2049,4096,4096,2420,69,32,257,33,4161,513]

theorem envBound55497 : H12AffineFastState.Bounded env55497 := by
  intro p hp
  have h : env55497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55496_55497 : H12AffineEnvironment.transform 9 272 env55496 = env55497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55496 == env55497) = true)

theorem identity55497 : scanCanonicalize (H12AffineFastState.compose env55497 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound55497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55498 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,308,348,293,1,342,308,2421,273,0,373,33,17,3,349,64,2049,308,308,2420,69,32,257,33,373,513]

theorem envBound55498 : H12AffineFastState.Bounded env55498 := by
  intro p hp
  have h : env55498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55497_55498 : H12AffineEnvironment.transform 11 308 env55497 = env55498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env55497 == env55498) = true)

theorem identity55498 : scanCanonicalize (H12AffineFastState.compose env55498 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55499 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,16,120,1,1,114,16,2129,53,0,81,33,17,3,121,64,2049,16,16,2128,69,32,37,33,81,513]

theorem envBound55499 : H12AffineFastState.Bounded env55499 := by
  intro p hp
  have h : env55499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55498_55499 : H12AffineEnvironment.transform 7 36 env55498 = env55499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55498 == env55499) = true)

theorem identity55499 : scanCanonicalize (H12AffineFastState.compose env55499 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55499 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55500 : List Nat := [2,4,8,16,32,64,9,36,512,52,0,16,120,1,1,114,16,81,53,0,81,33,17,3,121,64,1,16,16,80,69,32,37,33,81,513]

theorem envBound55500 : H12AffineFastState.Bounded env55500 := by
  intro p hp
  have h : env55500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55499_55500 : H12AffineEnvironment.transform 10 0 env55499 = env55500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55499 == env55500) = true)

theorem identity55500 : scanCanonicalize (H12AffineFastState.compose env55500 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55500 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55501 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,16,40,1,1,34,16,1,53,0,1,33,17,3,41,16,1,16,16,0,21,32,37,33,1,513]

theorem envBound55501 : H12AffineFastState.Bounded env55501 := by
  intro p hp
  have h : env55501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55500_55501 : H12AffineEnvironment.transform 5 16 env55500 = env55501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55500 == env55501) = true)

theorem identity55501 : scanCanonicalize (H12AffineFastState.compose env55501 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound55501 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55502 : List Nat := [2,4,8,16,32,16,9,36,49,52,0,16,40,1,1,34,16,1,53,0,1,33,17,3,41,16,1,16,16,0,21,32,37,33,1,48]

theorem envBound55502 : H12AffineFastState.Bounded env55502 := by
  intro p hp
  have h : env55502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55501_55502 : H12AffineEnvironment.transform 8 49 env55501 = env55502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env55501 == env55502) = true)

theorem identity55502 : scanCanonicalize (H12AffineFastState.compose env55502 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55502 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55503 : List Nat := [2,4,8,1,32,1,9,36,32,37,0,1,40,1,1,34,1,1,36,0,1,33,0,3,41,1,1,1,1,0,4,32,37,33,1,33]

theorem envBound55503 : H12AffineFastState.Bounded env55503 := by
  intro p hp
  have h : env55503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55502_55503 : H12AffineEnvironment.transform 3 1 env55502 = env55503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55502 == env55503) = true)

def env55504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115870,329867,17,95497,8328,64,64725,79131,102878,360790,61704,318685,257,95531,103566,120543]

theorem envBound55504 : H12AffineFastState.Bounded env55504 := by
  intro p hp
  have h : env55504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55476_55504 : H12AffineEnvironment.transform 23 95497 env55476 = env55504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env55476 == env55504) = true)

def env55505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115734,329731,17,95497,8192,64,64605,79131,102742,360790,61704,318549,257,95531,103430,120407]

theorem envBound55505 : H12AffineFastState.Bounded env55505 := by
  intro p hp
  have h : env55505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55504_55505 : H12AffineEnvironment.transform 6 8 env55504 = env55505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55504 == env55505) = true)

theorem identity55505 : scanCanonicalize (H12AffineFastState.compose env55505 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55505 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,115734,73770,17,95497,8192,64,64605,79131,102742,108927,61704,62588,257,95531,103430,120407]

theorem envBound55506 : H12AffineFastState.Bounded env55506 := by
  intro p hp
  have h : env55506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55505_55506 : H12AffineEnvironment.transform 17 10281 env55505 = env55506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55505 == env55506) = true)

theorem identity55506 : scanCanonicalize (H12AffineFastState.compose env55506 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound55506 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env55507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,46156,10281,1025,32769,12573,54561,17,32770,8192,64,64605,49168,25693,23668,61704,62588,257,32800,24845,9052]

theorem envBound55507 : H12AffineFastState.Bounded env55507 := by
  intro p hp
  have h : env55507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55506_55507 : H12AffineEnvironment.transform 15 62731 env55506 = env55507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env55506 == env55507) = true)

theorem identity55507 : scanCanonicalize (H12AffineFastState.compose env55507 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound55507 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,24908,10281,1025,21761,12573,33,17,21762,8192,64,10589,5392,25693,23668,9224,8572,257,21792,24845,9052]

theorem envBound55508 : H12AffineFastState.Bounded env55508 := by
  intro p hp
  have h : env55508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55507_55508 : H12AffineEnvironment.transform 14 21760 env55507 = env55508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55507 == env55508) = true)

theorem identity55508 : scanCanonicalize (H12AffineFastState.compose env55508 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound55508 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env55509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,81,8203,13341,10281,1025,80,12573,33,17,83,8192,64,10589,5392,12556,2341,9224,8572,257,113,13404,9052]

theorem envBound55509 : H12AffineFastState.Bounded env55509 := by
  intro p hp
  have h : env55509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55508_55509 : H12AffineEnvironment.transform 13 5457 env55508 = env55509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env55508 == env55509) = true)

theorem identity55509 : scanCanonicalize (H12AffineFastState.compose env55509 (packedSelected [0,2,3,5,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55509 : packedSelected [0,2,3,5,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env55510 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5237,81,8203,13341,10281,1025,80,12345,33,17,83,8192,64,10361,5172,12328,2049,9224,8280,37,113,13404,8824]

theorem envBound55510 : H12AffineFastState.Bounded env55510 := by
  intro p hp
  have h : env55510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55509_55510 : H12AffineEnvironment.transform 7 36 env55509 = env55510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55509 == env55510) = true)

theorem identity55510 : scanCanonicalize (H12AffineFastState.compose env55510 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound55510 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env55511 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,2562,5237,81,2569,7711,555,1025,80,6715,33,17,83,2562,64,635,5172,6698,2049,3594,2650,37,113,7774,2170]

theorem envBound55511 : H12AffineFastState.Bounded env55511 := by
  intro p hp
  have h : env55511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55510_55511 : H12AffineEnvironment.transform 12 2562 env55510 = env55511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env55510 == env55511) = true)

theorem identity55511 : scanCanonicalize (H12AffineFastState.compose env55511 (packedSelected [12,15] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound55511 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env55512 : List Nat := [2,4,8,16,32,64,8,36,512,1024,554,4096,40,5237,81,35,5173,555,1025,80,4113,33,17,83,40,64,635,5172,4096,555,1056,112,37,113,5236,592]

theorem envBound55512 : H12AffineFastState.Bounded env55512 := by
  intro p hp
  have h : env55512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55511_55512 : H12AffineEnvironment.transform 10 554 env55511 = env55512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env55511 == env55512) = true)

def env55513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115735,329730,17,95497,8193,64,64604,79131,102743,360790,61704,318548,257,95531,103431,120406]

theorem envBound55513 : H12AffineFastState.Bounded env55513 := by
  intro p hp
  have h : env55513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55504_55513 : H12AffineEnvironment.transform 6 9 env55504 = env55513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55504 == env55513) = true)

theorem identity55513 : scanCanonicalize (H12AffineFastState.compose env55513 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound55513 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,35188,1025,32769,115735,98678,17,95497,8193,64,64604,79131,102743,67618,61704,21792,257,95531,103431,120406]

theorem envBound55514 : H12AffineFastState.Bounded env55514 := by
  intro p hp
  have h : env55514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55513_55514 : H12AffineEnvironment.transform 17 35188 env55513 = env55514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env55513 == env55514) = true)

theorem identity55514 : scanCanonicalize (H12AffineFastState.compose env55514 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound55514 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,46156,35188,1025,32769,12572,29821,17,32770,8193,64,64604,49168,25692,64809,61704,21792,257,32800,24844,9053]

theorem envBound55515 : H12AffineFastState.Bounded env55515 := by
  intro p hp
  have h : env55515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55514_55515 : H12AffineEnvironment.transform 15 62731 env55514 = env55515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env55514 == env55515) = true)

theorem identity55515 : scanCanonicalize (H12AffineFastState.compose env55515 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55515 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40971,46156,35188,1025,32769,12572,8573,17,32770,8193,64,43356,38160,12636,43049,41992,32,257,32800,13324,9053]

theorem envBound55516 : H12AffineFastState.Bounded env55516 := by
  intro p hp
  have h : env55516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55515_55516 : H12AffineEnvironment.transform 13 5376 env55515 = env55516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55515 == env55516) = true)

theorem identity55516 : scanCanonicalize (H12AffineFastState.compose env55516 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55516 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env55517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,33111,38160,35188,1025,32769,4160,33,17,32770,349,64,34816,38160,4096,35189,34132,32,257,32800,5456,513]

theorem envBound55517 : H12AffineFastState.Bounded env55517 := by
  intro p hp
  have h : env55517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55516_55517 : H12AffineEnvironment.transform 12 348 env55516 = env55517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55516 == env55517) = true)

theorem identity55517 : scanCanonicalize (H12AffineFastState.compose env55517 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55517 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,2421,1025,0,4160,33,17,3,349,64,2049,5393,4096,2420,1365,32,257,33,5456,513]

theorem envBound55518 : H12AffineFastState.Bounded env55518 := by
  intro p hp
  have h : env55518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55517_55518 : H12AffineEnvironment.transform 14 1 env55517 = env55518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55517 == env55518) = true)

theorem identity55518 : scanCanonicalize (H12AffineFastState.compose env55518 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55518 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55519 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4405,1,342,4388,2421,52,0,4160,33,17,3,349,64,2049,4388,4096,2420,352,32,257,33,4453,513]

theorem envBound55519 : H12AffineFastState.Bounded env55519 := by
  intro p hp
  have h : env55519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55518_55519 : H12AffineEnvironment.transform 9 53 env55518 = env55519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55518 == env55519) = true)

def env55520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412109,213334,16777216,8328,64,16959642,18973836,2298887,360790,16958790,19344396,257,19039739,19031134,17031825]

theorem envBound55520 : H12AffineFastState.Bounded env55520 := by
  intro p hp
  have h : env55520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55446_55520 : H12AffineEnvironment.transform 21 412109 env55446 = env55520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412109 env55446 == env55520) = true)

def env55521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213334,16777216,8328,64,16959642,16974164,102879,360790,16958790,17148372,257,16777251,16834950,17031825]

theorem envBound55521 : H12AffineFastState.Bounded env55521 := by
  intro p hp
  have h : env55521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55520_55521 : H12AffineEnvironment.transform 20 165336 env55520 = env55521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env55520 == env55521) = true)

theorem identity55521 : scanCanonicalize (H12AffineFastState.compose env55521 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound55521 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env55522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213334,188870,8328,64,10588,123026,102879,360790,9344,477202,257,188901,131136,66391]

theorem envBound55522 : H12AffineFastState.Bounded env55522 := by
  intro p hp
  have h : env55522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55521_55522 : H12AffineEnvironment.transform 23 188870 env55521 = env55522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env55521 == env55522) = true)

def env55523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4160,318549,120014,29790,8328,64,10588,123026,102879,360790,9344,384394,257,29821,38360,66391]

theorem envBound55523 : H12AffineFastState.Bounded env55523 := by
  intro p hp
  have h : env55523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55522_55523 : H12AffineEnvironment.transform 16 38296 env55522 = env55523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env55522 == env55523) = true)

theorem identity55523 : scanCanonicalize (H12AffineFastState.compose env55523 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound55523 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24909,262144,1025,29908,4160,272512,73755,29790,8328,64,10588,70727,91402,357763,9344,338271,257,29821,24845,66391]

theorem envBound55524 : H12AffineFastState.Bounded env55524 := by
  intro p hp
  have h : env55524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55523_55524 : H12AffineEnvironment.transform 14 29909 env55523 = env55524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env55523 == env55524) = true)

def env55525 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24909,262144,1025,29908,4160,272512,73755,29790,8328,64,10588,70727,91402,357763,9344,338271,257,29789,24845,66391]

theorem envBound55525 : H12AffineFastState.Bounded env55525 := by
  intro p hp
  have h : env55525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55524_55525 : H12AffineEnvironment.transform 4 0 env55524 = env55525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55524 == env55525) = true)

theorem identity55525 : scanCanonicalize (H12AffineFastState.compose env55525 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 67722) := by decide +kernel

theorem selectedBound55525 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env55526 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24909,67722,1025,29908,4160,73738,73755,29790,8328,64,10588,70727,91402,32009,9344,8661,257,29789,24845,66391]

theorem envBound55526 : H12AffineFastState.Bounded env55526 := by
  intro p hp
  have h : env55526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55525_55526 : H12AffineEnvironment.transform 17 67722 env55525 = env55526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67722 env55525 == env55526) = true)

theorem identity55526 : scanCanonicalize (H12AffineFastState.compose env55526 (packedSelected [1,3,5,8,10,11,16,17,18,19,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound55526 : packedSelected [1,3,5,8,10,11,16,17,18,19,20,23,32] rootPS < 2^1333 := by decide +kernel

def env55527 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29909,479,24909,2389,1025,29908,4160,8661,8644,29790,8328,64,10588,5528,25813,32009,9344,8661,257,29789,24845,648]

theorem envBound55527 : H12AffineFastState.Bounded env55527 := by
  intro p hp
  have h : env55527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55526_55527 : H12AffineEnvironment.transform 15 479 env55526 = env55527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env55526 == env55527) = true)

theorem identity55527 : scanCanonicalize (H12AffineFastState.compose env55527 (packedSelected [0,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 12740) := by decide +kernel

theorem selectedBound55527 : packedSelected [0,7,16,17] rootPS < 2^1333 := by decide +kernel

def env55528 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,12740,1297,479,4233,2389,1025,1296,4160,8661,8644,1434,8328,64,10588,5528,5393,3277,9344,8661,257,1433,4297,648]

theorem envBound55528 : H12AffineFastState.Bounded env55528 := by
  intro p hp
  have h : env55528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55527_55528 : H12AffineEnvironment.transform 13 12740 env55527 = env55528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12740 env55527 == env55528) = true)

theorem identity55528 : scanCanonicalize (H12AffineFastState.compose env55528 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound55528 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55529 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,1101,5513,1297,479,4233,2389,1025,1296,4160,1432,1417,1434,1221,64,3345,5528,5393,3277,205,1432,257,1433,4297,648]

theorem envBound55529 : H12AffineFastState.Bounded env55529 := by
  intro p hp
  have h : env55529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55528_55529 : H12AffineEnvironment.transform 12 1101 env55528 = env55529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env55528 == env55529) = true)

theorem identity55529 : scanCanonicalize (H12AffineFastState.compose env55529 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55529 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55530 : List Nat := [2,4,8,16,0,64,128,256,512,272,2048,4096,349,4249,1,479,4233,2389,273,0,4160,136,153,138,469,64,2049,4232,4097,2525,205,136,257,137,4297,648]

theorem envBound55530 : H12AffineFastState.Bounded env55530 := by
  intro p hp
  have h : env55530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55529_55530 : H12AffineEnvironment.transform 9 272 env55529 = env55530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55529 == env55530) = true)

theorem identity55530 : scanCanonicalize (H12AffineFastState.compose env55530 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound55530 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env55531 : List Nat := [2,4,8,16,0,64,128,256,512,272,2048,2324,349,2445,1,479,2461,2389,273,0,2388,136,153,138,469,64,2049,2460,2325,2525,205,136,257,137,2525,648]

theorem envBound55531 : H12AffineFastState.Bounded env55531 := by
  intro p hp
  have h : env55531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55530_55531 : H12AffineEnvironment.transform 11 2324 env55530 = env55531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env55530 == env55531) = true)

theorem identity55531 : scanCanonicalize (H12AffineFastState.compose env55531 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound55531 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env55532 : List Nat := [2,4,8,16,0,64,128,141,512,157,2048,2201,208,2048,1,82,2064,2264,156,0,2265,136,153,138,88,64,2049,2065,2200,2128,205,136,140,137,2128,648]

theorem envBound55532 : H12AffineFastState.Bounded env55532 := by
  intro p hp
  have h : env55532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55531_55532 : H12AffineEnvironment.transform 7 141 env55531 = env55532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env55531 == env55532) = true)

theorem identity55532 : scanCanonicalize (H12AffineFastState.compose env55532 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55532 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env55533 : List Nat := [2,4,8,16,0,16,128,141,512,157,2048,2201,128,2048,1,2,2064,2184,156,0,2185,136,153,138,8,16,2049,2065,2200,2048,157,136,140,137,2048,648]

theorem envBound55533 : H12AffineFastState.Bounded env55533 := by
  intro p hp
  have h : env55533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55532_55533 : H12AffineEnvironment.transform 5 16 env55532 = env55533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55532 == env55533) = true)

theorem identity55533 : scanCanonicalize (H12AffineFastState.compose env55533 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55533 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55534 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,2064,9,2048,1,2,2064,2049,21,0,2048,1,16,3,8,16,2049,2065,2065,2048,20,1,5,0,2048,513]

theorem envBound55534 : H12AffineFastState.Bounded env55534 := by
  intro p hp
  have h : env55534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55533_55534 : H12AffineEnvironment.transform 6 9 env55533 = env55534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55533 == env55534) = true)

theorem identity55534 : scanCanonicalize (H12AffineFastState.compose env55534 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound55534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55535 : List Nat := [2,4,8,16,0,16,9,4,512,20,529,513,9,529,1,2,513,528,21,0,529,1,16,3,8,16,528,512,512,529,20,1,5,0,529,513]

theorem envBound55535 : H12AffineFastState.Bounded env55535 := by
  intro p hp
  have h : env55535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55534_55535 : H12AffineEnvironment.transform 10 529 env55534 = env55535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env55534 == env55535) = true)

theorem identity55535 : scanCanonicalize (H12AffineFastState.compose env55535 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55536 : List Nat := [2,4,8,10,0,10,9,4,512,14,523,513,9,523,1,2,513,522,15,0,523,1,10,3,8,10,522,512,512,523,14,1,5,0,523,513]

theorem envBound55536 : H12AffineFastState.Bounded env55536 := by
  intro p hp
  have h : env55536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55535_55536 : H12AffineEnvironment.transform 3 10 env55535 = env55536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55535 == env55536) = true)

theorem identity55536 : scanCanonicalize (H12AffineFastState.compose env55536 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound55536 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55537 : List Nat := [2,4,8,10,0,10,9,4,10,14,1,11,9,1,1,2,11,0,15,0,1,1,10,3,8,10,0,10,10,1,14,1,5,0,1,11]

theorem envBound55537 : H12AffineFastState.Bounded env55537 := by
  intro p hp
  have h : env55537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55536_55537 : H12AffineEnvironment.transform 8 10 env55536 = env55537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env55536 == env55537) = true)

def env55538 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24909,262144,1025,29908,4160,272512,73755,29790,8328,64,10588,70727,91402,357763,9344,338271,257,29788,24845,66391]

theorem envBound55538 : H12AffineFastState.Bounded env55538 := by
  intro p hp
  have h : env55538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55524_55538 : H12AffineEnvironment.transform 4 1 env55524 = env55538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55524 == env55538) = true)

theorem identity55538 : scanCanonicalize (H12AffineFastState.compose env55538 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound55538 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env55539 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24909,2525,1025,29908,4160,8541,73755,29790,8328,64,10588,70727,91402,97374,9344,73858,257,29788,24845,66391]

theorem envBound55539 : H12AffineFastState.Bounded env55539 := by
  intro p hp
  have h : env55539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55538_55539 : H12AffineEnvironment.transform 17 2525 env55538 = env55539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env55538 == env55539) = true)

theorem identity55539 : scanCanonicalize (H12AffineFastState.compose env55539 (packedSelected [1,2,4,6,7,9,10,11,16,17,18,19,20,23,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound55539 : packedSelected [1,2,4,6,7,9,10,11,16,17,18,19,20,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env55540 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29909,479,24909,2525,1025,29908,4160,8541,8644,29790,8328,64,10588,5528,25813,32129,9344,8541,257,29788,24845,648]

theorem envBound55540 : H12AffineFastState.Bounded env55540 := by
  intro p hp
  have h : env55540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55539_55540 : H12AffineEnvironment.transform 15 479 env55539 = env55540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env55539 == env55540) = true)

theorem identity55540 : scanCanonicalize (H12AffineFastState.compose env55540 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound55540 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env55541 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13524,1,479,5529,2525,1025,0,4160,8541,8644,138,8328,64,10588,5528,4097,2389,9344,8541,257,136,5593,648]

theorem envBound55541 : H12AffineFastState.Bounded env55541 := by
  intro p hp
  have h : env55541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55540_55541 : H12AffineEnvironment.transform 13 13524 env55540 = env55541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env55540 == env55541) = true)

theorem identity55541 : scanCanonicalize (H12AffineFastState.compose env55541 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound55541 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55542 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,468,5376,1,479,5529,2525,1025,0,4160,137,16,138,348,64,2184,5528,4097,2389,1364,137,257,136,5593,648]

theorem envBound55542 : H12AffineFastState.Bounded env55542 := by
  intro p hp
  have h : env55542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55541_55542 : H12AffineEnvironment.transform 12 468 env55541 = env55542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env55541 == env55542) = true)

theorem identity55542 : scanCanonicalize (H12AffineFastState.compose env55542 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound55542 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55543 : List Nat := [2,4,8,16,1,64,128,140,512,1024,2048,4096,88,5260,1,83,5141,2129,1025,0,4160,137,16,138,208,64,2184,5140,4097,2265,1240,137,141,136,5205,648]

theorem envBound55543 : H12AffineFastState.Bounded env55543 := by
  intro p hp
  have h : env55543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55542_55543 : H12AffineEnvironment.transform 7 140 env55542 = env55543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env55542 == env55543) = true)

theorem identity55543 : scanCanonicalize (H12AffineFastState.compose env55543 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55543 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55544 : List Nat := [2,4,8,16,1,64,128,140,512,21,2048,4096,88,4249,1,83,4096,2129,20,0,4160,137,16,138,208,64,2184,4097,4097,2265,205,137,141,136,4160,648]

theorem envBound55544 : H12AffineFastState.Bounded env55544 := by
  intro p hp
  have h : env55544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55543_55544 : H12AffineEnvironment.transform 9 21 env55543 = env55544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55543 == env55544) = true)

theorem identity55544 : scanCanonicalize (H12AffineFastState.compose env55544 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound55544 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55545 : List Nat := [2,4,8,16,1,64,89,85,512,21,2048,4096,88,4160,1,83,4096,2129,20,0,4160,80,16,83,9,64,2129,4097,4097,2048,20,80,84,81,4160,593]

theorem envBound55545 : H12AffineFastState.Bounded env55545 := by
  intro p hp
  have h : env55545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55544_55545 : H12AffineEnvironment.transform 6 89 env55544 = env55545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env55544 == env55545) = true)

theorem identity55545 : scanCanonicalize (H12AffineFastState.compose env55545 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound55545 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55546 : List Nat := [2,4,8,16,1,64,89,85,512,21,81,4096,88,4160,1,83,4096,0,20,0,4160,80,16,83,9,64,0,4097,4097,81,20,80,84,81,4160,593]

theorem envBound55546 : H12AffineFastState.Bounded env55546 := by
  intro p hp
  have h : env55546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55545_55546 : H12AffineEnvironment.transform 10 81 env55545 = env55546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env55545 == env55546) = true)

theorem identity55546 : scanCanonicalize (H12AffineFastState.compose env55546 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound55546 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55547 : List Nat := [2,4,8,16,1,64,89,85,512,21,81,16,88,80,1,83,16,0,20,0,80,80,16,83,9,64,0,17,17,81,20,80,84,81,80,593]

theorem envBound55547 : H12AffineFastState.Bounded env55547 := by
  intro p hp
  have h : env55547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55546_55547 : H12AffineEnvironment.transform 11 16 env55546 = env55547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env55546 == env55547) = true)

theorem identity55547 : scanCanonicalize (H12AffineFastState.compose env55547 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55547 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env55548 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,16,9,1,1,2,16,0,20,0,1,1,16,2,9,17,0,17,17,0,20,1,5,0,1,512]

theorem envBound55548 : H12AffineFastState.Bounded env55548 := by
  intro p hp
  have h : env55548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55547_55548 : H12AffineEnvironment.transform 5 17 env55547 = env55548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55547 == env55548) = true)

theorem identity55548 : scanCanonicalize (H12AffineFastState.compose env55548 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound55548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55549 : List Nat := [2,4,8,16,1,17,8,4,14,21,0,16,9,1,1,2,16,0,20,0,1,1,16,2,9,17,0,17,17,0,20,1,5,0,1,14]

theorem envBound55549 : H12AffineFastState.Bounded env55549 := by
  intro p hp
  have h : env55549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55548_55549 : H12AffineEnvironment.transform 8 14 env55548 = env55549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env55548 == env55549) = true)

def env55550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,318548,120015,29791,8328,64,10588,123026,102879,360790,9344,384395,257,29820,38361,66391]

theorem envBound55550 : H12AffineFastState.Bounded env55550 := by
  intro p hp
  have h : env55550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55522_55550 : H12AffineEnvironment.transform 16 38297 env55522 = env55550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env55522 == env55550) = true)

theorem identity55550 : scanCanonicalize (H12AffineFastState.compose env55550 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound55550 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,38297,262144,1025,32769,4161,318548,8525,29791,8328,64,10588,5392,25693,292052,9344,272393,257,29820,38361,63189]

theorem envBound55551 : H12AffineFastState.Bounded env55551 := by
  intro p hp
  have h : env55551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55550_55551 : H12AffineEnvironment.transform 15 62850 env55550 = env55551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env55550 == env55551) = true)

def env55552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4161,318548,8525,29791,8192,64,10588,5392,25693,291932,9224,272393,257,29820,38225,63069]

theorem envBound55552 : H12AffineFastState.Bounded env55552 := by
  intro p hp
  have h : env55552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55551_55552 : H12AffineEnvironment.transform 6 8 env55551 = env55552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55551 == env55552) = true)

theorem identity55552 : scanCanonicalize (H12AffineFastState.compose env55552 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound55552 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,24909,262144,1025,29789,4161,272392,8525,29791,8192,64,10588,5392,25693,291932,9224,272393,257,29820,24845,513]

theorem envBound55553 : H12AffineFastState.Bounded env55553 := by
  intro p hp
  have h : env55553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55552_55553 : H12AffineEnvironment.transform 14 29788 env55552 = env55553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env55552 == env55553) = true)

theorem identity55553 : scanCanonicalize (H12AffineFastState.compose env55553 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound55553 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,24909,32041,1025,29789,4161,21793,8525,29791,8192,64,10588,5392,25693,2421,9224,21792,257,29820,24845,513]

theorem envBound55554 : H12AffineFastState.Bounded env55554 := by
  intro p hp
  have h : env55554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55553_55554 : H12AffineEnvironment.transform 17 32041 env55553 = env55554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env55553 == env55554) = true)

def env55555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4161,318548,8525,29791,8193,64,10588,5392,25693,291933,9225,272393,257,29820,38224,63068]

theorem envBound55555 : H12AffineFastState.Bounded env55555 := by
  intro p hp
  have h : env55555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55551_55555 : H12AffineEnvironment.transform 6 9 env55551 = env55555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55551 == env55555) = true)

theorem identity55555 : scanCanonicalize (H12AffineFastState.compose env55555 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound55555 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env55556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,32041,1025,32769,4161,41341,8525,29791,8193,64,10588,5392,25693,2420,9225,21792,257,29820,38224,63068]

theorem envBound55556 : H12AffineFastState.Bounded env55556 := by
  intro p hp
  have h : env55556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55555_55556 : H12AffineEnvironment.transform 17 32041 env55555 = env55556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env55555 == env55556) = true)

theorem identity55556 : scanCanonicalize (H12AffineFastState.compose env55556 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound55556 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env55557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21541,8494,16693,32041,1025,21540,4161,30040,8525,29791,8193,64,10588,5392,25693,2420,9225,21792,257,29820,16757,8825]

theorem envBound55557 : H12AffineFastState.Bounded env55557 := by
  intro p hp
  have h : env55557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55556_55557 : H12AffineEnvironment.transform 14 21541 env55556 = env55557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env55556 == env55557) = true)

theorem identity55557 : scanCanonicalize (H12AffineFastState.compose env55557 (packedSelected [16,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55557 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env55558 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,21541,8203,16400,31756,1025,21540,4161,29821,8296,29791,8193,64,10361,5173,25693,2129,9225,21509,36,29820,16464,8825]

theorem envBound55558 : H12AffineFastState.Bounded env55558 := by
  intro p hp
  have h : env55558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55557_55558 : H12AffineEnvironment.transform 7 37 env55557 = env55558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55557 == env55558) = true)

theorem identity55558 : scanCanonicalize (H12AffineFastState.compose env55558 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound55558 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55559 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,16384,21541,115,16400,23668,1025,21540,4161,21509,16,21543,121,64,2049,5173,17445,2129,1137,21509,36,21508,16464,513]

theorem envBound55559 : H12AffineFastState.Bounded env55559 := by
  intro p hp
  have h : env55559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55558_55559 : H12AffineEnvironment.transform 12 120 env55558 = env55559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env55558 == env55559) = true)

theorem identity55559 : scanCanonicalize (H12AffineFastState.compose env55559 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound55559 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55560 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5237,80,115,5221,2049,1025,81,4161,112,16,82,121,64,2049,5173,4176,2129,1137,112,36,113,5157,513]

theorem envBound55560 : H12AffineFastState.Bounded env55560 := by
  intro p hp
  have h : env55560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55559_55560 : H12AffineEnvironment.transform 13 5237 env55559 = env55560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env55559 == env55560) = true)

theorem identity55560 : scanCanonicalize (H12AffineFastState.compose env55560 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55561 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4160,80,115,4176,2049,52,81,4161,112,16,82,121,64,2049,4096,4176,2129,68,112,36,113,4112,513]

theorem envBound55561 : H12AffineFastState.Bounded env55561 := by
  intro p hp
  have h : env55561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55560_55561 : H12AffineEnvironment.transform 9 53 env55560 = env55561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55560 == env55561) = true)

theorem identity55561 : scanCanonicalize (H12AffineFastState.compose env55561 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55561 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55562 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4112,0,35,4096,2049,52,1,4113,32,16,2,41,16,2049,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound55562 : H12AffineFastState.Bounded env55562 := by
  intro p hp
  have h : env55562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55561_55562 : H12AffineEnvironment.transform 5 16 env55561 = env55562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55561 == env55562) = true)

theorem identity55562 : scanCanonicalize (H12AffineFastState.compose env55562 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound55562 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55563 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,512,40,528,0,35,512,2049,52,1,529,32,16,2,41,16,2049,512,512,2049,20,32,36,33,528,513]

theorem envBound55563 : H12AffineFastState.Bounded env55563 := by
  intro p hp
  have h : env55563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55562_55563 : H12AffineEnvironment.transform 11 512 env55562 = env55563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env55562 == env55563) = true)

theorem identity55563 : scanCanonicalize (H12AffineFastState.compose env55563 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound55563 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55564 : List Nat := [2,4,8,16,32,16,9,37,512,53,26,512,40,528,0,35,512,27,52,1,529,32,16,2,41,16,27,512,512,27,20,32,36,33,528,513]

theorem envBound55564 : H12AffineFastState.Bounded env55564 := by
  intro p hp
  have h : env55564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55563_55564 : H12AffineEnvironment.transform 10 26 env55563 = env55564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env55563 == env55564) = true)

theorem identity55564 : scanCanonicalize (H12AffineFastState.compose env55564 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound55564 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55565 : List Nat := [2,4,8,16,32,16,9,37,17,53,26,17,40,1,0,35,17,27,52,1,0,32,16,2,41,16,27,17,17,27,20,32,36,33,1,16]

theorem envBound55565 : H12AffineFastState.Bounded env55565 := by
  intro p hp
  have h : env55565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55564_55565 : H12AffineEnvironment.transform 8 17 env55564 = env55565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env55564 == env55565) = true)

theorem identity55565 : scanCanonicalize (H12AffineFastState.compose env55565 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55565 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55566 : List Nat := [2,4,8,10,32,10,9,37,11,47,0,11,40,1,0,35,11,1,46,1,0,32,10,2,41,10,1,11,11,1,14,32,36,33,1,10]

theorem envBound55566 : H12AffineFastState.Bounded env55566 := by
  intro p hp
  have h : env55566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55565_55566 : H12AffineEnvironment.transform 3 10 env55565 = env55566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55565 == env55566) = true)

def env55567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213334,16777216,8328,64,16959642,16974165,102878,360790,16958790,17148373,257,16777250,16834951,17031825]

theorem envBound55567 : H12AffineFastState.Bounded env55567 := by
  intro p hp
  have h : env55567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55520_55567 : H12AffineEnvironment.transform 20 165337 env55520 = env55567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env55520 == env55567) = true)

def env55568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213334,254096,8328,64,75786,57797,102878,360790,75222,411973,257,254130,196887,513]

theorem envBound55568 : H12AffineFastState.Bounded env55568 := by
  intro p hp
  have h : env55568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55567_55568 : H12AffineEnvironment.transform 23 254096 env55567 = env55568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254096 env55567 == env55568) = true)

def env55569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213334,253976,8192,64,75786,57677,102742,360790,75102,411973,257,254010,196887,513]

theorem envBound55569 : H12AffineFastState.Bounded env55569 := by
  intro p hp
  have h : env55569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55568_55569 : H12AffineEnvironment.transform 6 8 env55568 = env55569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55568 == env55569) = true)

theorem identity55569 : scanCanonicalize (H12AffineFastState.compose env55569 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound55569 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env55570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,165201,180272,213334,253976,8192,64,75786,57677,102742,67619,75102,180272,257,254010,196887,513]

theorem envBound55570 : H12AffineFastState.Bounded env55570 := by
  intro p hp
  have h : env55570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55569_55570 : H12AffineEnvironment.transform 17 35189 env55569 = env55570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env55569 == env55570) = true)

theorem identity55570 : scanCanonicalize (H12AffineFastState.compose env55570 (packedSelected [0,3,4,5,7,8,9,14,16,17,18,20,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55570 : packedSelected [0,3,4,5,7,8,9,14,16,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env55571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,140301,156012,213334,213316,8192,64,75786,16401,77834,67619,75102,156012,257,213350,196887,513]

theorem envBound55571 : H12AffineFastState.Bounded env55571 := by
  intro p hp
  have h : env55571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55570_55571 : H12AffineEnvironment.transform 14 8540 env55570 = env55571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55570 == env55571) = true)

theorem identity55571 : scanCanonicalize (H12AffineFastState.compose env55571 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound55571 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10281,1025,8541,82966,65911,8525,8543,8192,64,75786,16401,77834,67619,75102,65911,257,8573,24844,513]

theorem envBound55572 : H12AffineFastState.Bounded env55572 := by
  intro p hp
  have h : env55572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55571_55572 : H12AffineEnvironment.transform 16 90139 env55571 = env55572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env55571 == env55572) = true)

theorem identity55572 : scanCanonicalize (H12AffineFastState.compose env55572 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55572 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,65536,82247,2421,1025,1,82966,65911,17,3,348,64,67926,16401,69974,67619,66562,65911,257,33,16464,513]

theorem envBound55573 : H12AffineFastState.Bounded env55573 := by
  intro p hp
  have h : env55573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55572_55573 : H12AffineEnvironment.transform 12 348 env55572 = env55573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55572 == env55573) = true)

def env55574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213334,253977,8193,64,75786,57676,102743,360790,75103,411973,257,254011,196887,513]

theorem envBound55574 : H12AffineFastState.Bounded env55574 := by
  intro p hp
  have h : env55574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55568_55574 : H12AffineEnvironment.transform 6 9 env55568 = env55574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55568 == env55574) = true)

theorem identity55574 : scanCanonicalize (H12AffineFastState.compose env55574 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound55574 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,124235,338271,8525,32770,8193,64,75786,57676,102743,360790,75103,338270,257,32800,24844,513]

theorem envBound55575 : H12AffineFastState.Bounded env55575 := by
  intro p hp
  have h : env55575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55574_55575 : H12AffineEnvironment.transform 16 90139 env55574 = env55575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env55574 == env55575) = true)

theorem identity55575 : scanCanonicalize (H12AffineFastState.compose env55575 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 53527) := by decide +kernel

theorem selectedBound55575 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env55576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53527,45324,262144,1025,32769,13404,325704,8525,32770,8193,64,63773,57676,16448,282689,62536,325705,257,32800,24844,513]

theorem envBound55576 : H12AffineFastState.Bounded env55576 := by
  intro p hp
  have h : env55576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55575_55576 : H12AffineEnvironment.transform 15 53527 env55575 = env55576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53527 env55575 == env55576) = true)

theorem identity55576 : scanCanonicalize (H12AffineFastState.compose env55576 (packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55576 : packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env55577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,53527,36945,262144,1025,32769,5377,317717,16,32770,348,64,55360,49169,16448,282689,54549,317716,257,32800,16465,513]

theorem envBound55577 : H12AffineFastState.Bounded env55577 := by
  intro p hp
  have h : env55577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55576_55577 : H12AffineEnvironment.transform 12 349 env55576 = env55577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55576 == env55577) = true)

theorem identity55577 : scanCanonicalize (H12AffineFastState.compose env55577 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 55652) := by decide +kernel

theorem selectedBound55577 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,53527,36945,55652,1025,32769,5377,113,16,32770,348,64,55360,49169,16448,35109,54549,112,257,32800,16465,513]

theorem envBound55578 : H12AffineFastState.Bounded env55578 := by
  intro p hp
  have h : env55578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55577_55578 : H12AffineEnvironment.transform 17 55652 env55577 = env55578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 55652 env55577 == env55578) = true)

theorem identity55578 : scanCanonicalize (H12AffineFastState.compose env55578 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55578 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,20758,4176,22885,1025,0,5377,113,16,3,348,64,22593,16400,16448,2340,21780,112,257,33,16465,513]

theorem envBound55579 : H12AffineFastState.Bounded env55579 := by
  intro p hp
  have h : env55579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55578_55579 : H12AffineEnvironment.transform 14 1 env55578 = env55579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55578 == env55579) = true)

theorem identity55579 : scanCanonicalize (H12AffineFastState.compose env55579 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound55579 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env55580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1,262,4176,2421,1025,0,5377,113,16,3,348,64,2129,4096,4176,2340,1284,112,257,33,4161,513]

theorem envBound55580 : H12AffineFastState.Bounded env55580 := by
  intro p hp
  have h : env55580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55579_55580 : H12AffineEnvironment.transform 13 4112 env55579 = env55580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env55579 == env55580) = true)

theorem identity55580 : scanCanonicalize (H12AffineFastState.compose env55580 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55580 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55581 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,4112,1,262,4096,2341,1025,0,5377,33,16,3,268,16,2049,4096,4096,2340,1284,32,257,33,4113,513]

theorem envBound55581 : H12AffineFastState.Bounded env55581 := by
  intro p hp
  have h : env55581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55580_55581 : H12AffineEnvironment.transform 5 16 env55580 = env55581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55580 == env55581) = true)

theorem identity55581 : scanCanonicalize (H12AffineFastState.compose env55581 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55582 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4112,1,262,4096,2341,273,0,4113,33,16,3,268,16,2049,4096,4096,2340,20,32,257,33,4113,513]

theorem envBound55582 : H12AffineFastState.Bounded env55582 := by
  intro p hp
  have h : env55582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55581_55582 : H12AffineEnvironment.transform 9 272 env55581 = env55582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55581 == env55582) = true)

def env55583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213334,254097,8328,64,75787,57796,102878,360790,75223,411972,257,254131,196886,512]

theorem envBound55583 : H12AffineFastState.Bounded env55583 := by
  intro p hp
  have h : env55583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55567_55583 : H12AffineEnvironment.transform 23 254097 env55567 = env55583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254097 env55567 == env55583) = true)

theorem identity55583 : scanCanonicalize (H12AffineFastState.compose env55583 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound55583 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,318549,120014,95497,8328,64,75787,57796,102878,360790,75223,318684,257,95531,103566,512]

theorem envBound55584 : H12AffineFastState.Bounded env55584 := by
  intro p hp
  have h : env55584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55583_55584 : H12AffineEnvironment.transform 16 38296 env55583 = env55584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env55583 == env55584) = true)

theorem identity55584 : scanCanonicalize (H12AffineFastState.compose env55584 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound55584 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,38296,262144,1025,32769,4161,318549,54681,29790,8328,64,10588,57796,37001,294913,9344,318684,257,29820,38361,512]

theorem envBound55585 : H12AffineFastState.Bounded env55585 := by
  intro p hp
  have h : env55585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55584_55585 : H12AffineEnvironment.transform 15 343 env55584 = env55585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env55584 == env55585) = true)

theorem identity55585 : scanCanonicalize (H12AffineFastState.compose env55585 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound55585 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env55586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,343,16401,262144,1025,21896,4161,264668,16,29790,8328,64,10588,13389,17664,284040,9344,264533,257,29820,16464,512]

theorem envBound55586 : H12AffineFastState.Bounded env55586 := by
  intro p hp
  have h : env55586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55585_55586 : H12AffineEnvironment.transform 14 21897 env55585 = env55586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env55585 == env55586) = true)

theorem identity55586 : scanCanonicalize (H12AffineFastState.compose env55586 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound55586 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,343,16401,2184,1025,21896,4161,340,16,29790,8328,64,10588,13389,17664,23808,9344,477,257,29820,16464,512]

theorem envBound55587 : H12AffineFastState.Bounded env55587 := by
  intro p hp
  have h : env55587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55586_55587 : H12AffineEnvironment.transform 17 2184 env55586 = env55587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env55586 == env55587) = true)

theorem identity55587 : scanCanonicalize (H12AffineFastState.compose env55587 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound55587 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env55588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,21897,343,16401,2184,1025,21896,4161,340,16,21758,40,64,2556,5357,17664,23808,1056,477,257,21724,16464,512]

theorem envBound55588 : H12AffineFastState.Bounded env55588 := by
  intro p hp
  have h : env55588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55587_55588 : H12AffineEnvironment.transform 12 160 env55587 = env55588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env55587 == env55588) = true)

theorem identity55588 : scanCanonicalize (H12AffineFastState.compose env55588 (packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 488) := by decide +kernel

theorem selectedBound55588 : packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env55589 : List Nat := [2,4,8,16,32,64,128,256,512,488,2048,4096,160,16384,20577,343,16401,2184,489,20576,4161,340,16,20758,40,64,2556,4357,16616,22760,456,477,257,20788,16464,512]

theorem envBound55589 : H12AffineFastState.Bounded env55589 := by
  intro p hp
  have h : env55589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55588_55589 : H12AffineEnvironment.transform 9 488 env55588 = env55589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 488 env55588 == env55589) = true)

theorem identity55589 : scanCanonicalize (H12AffineFastState.compose env55589 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4328) := by decide +kernel

theorem selectedBound55589 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55590 : List Nat := [2,4,8,16,32,64,128,256,512,488,2048,4096,160,4328,137,343,4345,2184,489,136,4161,340,16,510,40,64,2556,4357,4096,2048,456,477,257,476,4280,512]

theorem envBound55590 : H12AffineFastState.Bounded env55590 := by
  intro p hp
  have h : env55590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55589_55590 : H12AffineEnvironment.transform 13 4328 env55589 = env55590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4328 env55589 == env55590) = true)

theorem identity55590 : scanCanonicalize (H12AffineFastState.compose env55590 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound55590 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55591 : List Nat := [2,4,8,16,32,64,128,252,512,20,2048,4096,160,4328,137,171,4345,2184,21,136,4161,168,16,2,40,64,2048,4345,4096,2048,52,33,253,32,4280,512]

theorem envBound55591 : H12AffineFastState.Bounded env55591 := by
  intro p hp
  have h : env55591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55590_55591 : H12AffineEnvironment.transform 7 252 env55590 = env55591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env55590 == env55591) = true)

theorem identity55591 : scanCanonicalize (H12AffineFastState.compose env55591 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound55591 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55592 : List Nat := [2,4,8,16,32,64,41,85,512,20,2048,4096,9,4161,32,2,4176,2081,21,33,4161,1,16,2,40,64,2048,4176,4096,2048,52,33,84,32,4113,512]

theorem envBound55592 : H12AffineFastState.Bounded env55592 := by
  intro p hp
  have h : env55592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55591_55592 : H12AffineEnvironment.transform 6 41 env55591 = env55592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env55591 == env55592) = true)

theorem identity55592 : scanCanonicalize (H12AffineFastState.compose env55592 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound55592 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env55593 : List Nat := [2,4,8,16,32,64,41,85,512,20,2048,2096,9,2161,32,2,2144,2081,21,33,2161,1,16,2,40,64,2048,2144,2096,2048,52,33,84,32,2081,512]

theorem envBound55593 : H12AffineFastState.Bounded env55593 := by
  intro p hp
  have h : env55593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55592_55593 : H12AffineEnvironment.transform 11 2096 env55592 = env55593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env55592 == env55593) = true)

theorem identity55593 : scanCanonicalize (H12AffineFastState.compose env55593 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55593 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env55594 : List Nat := [2,4,8,16,32,17,41,4,512,20,2048,2096,9,2080,32,2,2097,2081,21,33,2080,1,16,2,40,17,2048,2097,2096,2048,52,33,5,32,2081,512]

theorem envBound55594 : H12AffineFastState.Bounded env55594 := by
  intro p hp
  have h : env55594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55593_55594 : H12AffineEnvironment.transform 5 17 env55593 = env55594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55593 == env55594) = true)

theorem identity55594 : scanCanonicalize (H12AffineFastState.compose env55594 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound55594 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55595 : List Nat := [2,4,8,16,32,17,41,4,512,20,4,52,9,36,32,2,53,37,21,33,36,1,16,2,40,17,4,53,52,4,52,33,5,32,37,512]

theorem envBound55595 : H12AffineFastState.Bounded env55595 := by
  intro p hp
  have h : env55595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55594_55595 : H12AffineEnvironment.transform 10 4 env55594 = env55595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env55594 == env55595) = true)

theorem identity55595 : scanCanonicalize (H12AffineFastState.compose env55595 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55595 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55596 : List Nat := [2,4,8,16,1,17,8,4,512,20,4,21,9,5,1,2,20,4,21,0,5,1,16,2,9,17,4,20,21,4,21,0,5,1,4,512]

theorem envBound55596 : H12AffineFastState.Bounded env55596 := by
  intro p hp
  have h : env55596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55595_55596 : H12AffineEnvironment.transform 4 1 env55595 = env55596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55595 == env55596) = true)

def env55597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound55597 : H12AffineFastState.Bounded env55597 := by
  intro p hp
  have h : env55597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55309_55597 : H12AffineEnvironment.transform 26 30393345 env55309 = env55597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env55309 == env55597) = true)

def env55598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound55598 : H12AffineFastState.Bounded env55598 := by
  intro p hp
  have h : env55598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55597_55598 : H12AffineEnvironment.transform 18 1024 env55597 = env55598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env55597 == env55598) = true)

theorem identity55598 : scanCanonicalize (H12AffineFastState.compose env55598 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound55598 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,4194304,8388608,16777216,8328,64,29868033,16793754,8491334,8830976,25265168,21012951,256,25166010,25223455,25207750]

theorem envBound55599 : H12AffineFastState.Bounded env55599 := by
  intro p hp
  have h : env55599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55598_55599 : H12AffineEnvironment.transform 20 115735 env55598 = env55599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env55598 == env55599) = true)

def env55600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,4194304,8388608,95616,8328,64,13022593,79130,8491334,8830976,8450448,4314199,256,8484154,8492191,8508998]

theorem envBound55600 : H12AffineFastState.Bounded env55600 := by
  intro p hp
  have h : env55600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55599_55600 : H12AffineEnvironment.transform 23 95616 env55599 = env55600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95616 env55599 == env55600) = true)

def env55601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73856,8328,64,13022593,79130,8491334,8819968,8430736,4292951,256,8462394,8492191,8487750]

theorem envBound55601 : H12AffineFastState.Bounded env55601 := by
  intro p hp
  have h : env55601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55600_55601 : H12AffineEnvironment.transform 13 5376 env55600 = env55601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55600 == env55601) = true)

def env55602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73856,8328,64,8828321,79130,8491334,8819968,8430736,98679,256,8462394,8492191,8487750]

theorem envBound55602 : H12AffineFastState.Bounded env55602 := by
  intro p hp
  have h : env55602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55601_55602 : H12AffineEnvironment.transform 21 32 env55601 = env55602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55601 == env55602) = true)

theorem identity55602 : scanCanonicalize (H12AffineFastState.compose env55602 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound55602 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,98767,73856,8328,64,472174,79130,4233,464079,75103,98679,256,41461,5456,649]

theorem envBound55603 : H12AffineFastState.Bounded env55603 := by
  intro p hp
  have h : env55603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55602_55603 : H12AffineEnvironment.transform 22 98767 env55602 = env55603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env55602 == env55603) = true)

theorem identity55603 : scanCanonicalize (H12AffineFastState.compose env55603 (packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound55603 : packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env55604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1024,32769,102679,32,98767,73856,8328,64,203983,79130,4233,212078,75103,98679,256,41461,5456,649]

theorem envBound55604 : H12AffineFastState.Bounded env55604 := by
  intro p hp
  have h : env55604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55603_55604 : H12AffineEnvironment.transform 17 10401 env55603 = env55604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55603 == env55604) = true)

theorem identity55604 : scanCanonicalize (H12AffineFastState.compose env55604 (packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55604 : packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102679,32,98631,73736,8192,64,203847,79130,4097,212078,75103,98679,256,41341,5456,513]

theorem envBound55605 : H12AffineFastState.Bounded env55605 := by
  intro p hp
  have h : env55605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55604_55605 : H12AffineEnvironment.transform 6 8 env55604 = env55605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55604 == env55605) = true)

theorem identity55605 : scanCanonicalize (H12AffineFastState.compose env55605 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55605 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env55606 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102679,32,98582,73736,8192,17,203798,79130,4097,212031,75022,98598,256,41260,5377,513]

theorem envBound55606 : H12AffineFastState.Bounded env55606 := by
  intro p hp
  have h : env55606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55605_55606 : H12AffineEnvironment.transform 5 17 env55605 = env55606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55605 == env55606) = true)

theorem identity55606 : scanCanonicalize (H12AffineFastState.compose env55606 (packedSelected [0,7,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound55606 : packedSelected [0,7,11,14] rootPS < 2^1333 := by decide +kernel

def env55607 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,65536,131072,10281,1024,8460,77850,32,73755,73736,8192,17,203798,79130,4097,212031,75022,73771,256,33,5377,513]

theorem envBound55607 : H12AffineFastState.Bounded env55607 := by
  intro p hp
  have h : env55607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55606_55607 : H12AffineEnvironment.transform 14 8461 env55606 = env55607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env55606 == env55607) = true)

theorem identity55607 : scanCanonicalize (H12AffineFastState.compose env55607 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound55607 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55608 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,65536,70679,10281,1024,8460,77850,32,73755,73736,8192,17,2049,79130,4097,10280,75022,73771,256,33,5377,513]

theorem envBound55608 : H12AffineFastState.Bounded env55608 := by
  intro p hp
  have h : env55608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55607_55608 : H12AffineEnvironment.transform 16 70679 env55607 = env55608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env55607 == env55608) = true)

theorem identity55608 : scanCanonicalize (H12AffineFastState.compose env55608 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55608 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55609 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,65536,70679,2341,1024,0,69910,32,65815,65796,268,17,2049,70678,4097,2340,66562,65831,256,33,5377,513]

theorem envBound55609 : H12AffineFastState.Bounded env55609 := by
  intro p hp
  have h : env55609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55608_55609 : H12AffineEnvironment.transform 12 268 env55608 = env55609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55608 == env55609) = true)

theorem identity55609 : scanCanonicalize (H12AffineFastState.compose env55609 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55609 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55610 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4113,32,16,3,268,17,2049,5393,4097,2340,1285,32,256,33,5377,513]

theorem envBound55610 : H12AffineFastState.Bounded env55610 := by
  intro p hp
  have h : env55610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55609_55610 : H12AffineEnvironment.transform 15 263 env55609 = env55610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55609 == env55610) = true)

theorem identity55610 : scanCanonicalize (H12AffineFastState.compose env55610 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55611 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,5124,1,3,5140,2081,1024,0,4113,32,16,3,8,17,2049,5141,4097,2080,1025,32,4,33,5125,513]

theorem envBound55611 : H12AffineFastState.Bounded env55611 := by
  intro p hp
  have h : env55611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55610_55611 : H12AffineEnvironment.transform 7 4 env55610 = env55611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55610 == env55611) = true)

theorem identity55611 : scanCanonicalize (H12AffineFastState.compose env55611 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55611 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55612 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,4096,8,4144,1,3,4128,2081,52,0,4113,32,16,3,8,17,2049,4129,4097,2080,53,32,4,33,4145,513]

theorem envBound55612 : H12AffineFastState.Bounded env55612 := by
  intro p hp
  have h : env55612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55611_55612 : H12AffineEnvironment.transform 9 52 env55611 = env55612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55611 == env55612) = true)

theorem identity55612 : scanCanonicalize (H12AffineFastState.compose env55612 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound55612 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55613 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,2608,8,2560,1,3,2576,2081,52,0,2593,32,16,3,8,17,2049,2577,2609,2080,53,32,4,33,2561,513]

theorem envBound55613 : H12AffineFastState.Bounded env55613 := by
  intro p hp
  have h : env55613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55612_55613 : H12AffineEnvironment.transform 11 2608 env55612 = env55613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env55612 == env55613) = true)

theorem identity55613 : scanCanonicalize (H12AffineFastState.compose env55613 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound55613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55614 : List Nat := [2,4,8,16,32,17,8,4,17,52,2048,2081,8,2065,1,3,2049,2081,52,0,2096,32,16,3,8,17,2049,2048,2080,2080,53,32,4,33,2064,16]

theorem envBound55614 : H12AffineFastState.Bounded env55614 := by
  intro p hp
  have h : env55614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55613_55614 : H12AffineEnvironment.transform 8 17 env55613 = env55614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env55613 == env55614) = true)

theorem identity55614 : scanCanonicalize (H12AffineFastState.compose env55614 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound55614 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55615 : List Nat := [2,4,8,16,32,17,8,4,17,52,49,16,8,32,1,3,48,16,52,0,1,32,16,3,8,17,48,49,17,17,53,32,4,33,33,16]

theorem envBound55615 : H12AffineFastState.Bounded env55615 := by
  intro p hp
  have h : env55615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55614_55615 : H12AffineEnvironment.transform 10 49 env55614 = env55615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env55614 == env55615) = true)

theorem identity55615 : scanCanonicalize (H12AffineFastState.compose env55615 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55615 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55616 : List Nat := [2,4,8,16,1,17,8,4,17,21,16,16,8,1,1,3,17,16,21,0,1,1,16,3,8,17,17,16,17,17,20,1,4,0,0,16]

theorem envBound55616 : H12AffineFastState.Bounded env55616 := by
  intro p hp
  have h : env55616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55615_55616 : H12AffineEnvironment.transform 4 1 env55615 = env55616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55615 == env55616) = true)

theorem identity55616 : scanCanonicalize (H12AffineFastState.compose env55616 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55617 : List Nat := [2,4,8,11,1,10,8,4,10,14,11,11,8,1,1,3,10,11,14,0,1,1,11,3,8,10,10,11,10,10,15,1,4,0,0,11]

theorem envBound55617 : H12AffineFastState.Bounded env55617 := by
  intro p hp
  have h : env55617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55616_55617 : H12AffineEnvironment.transform 3 11 env55616 = env55617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55616 == env55617) = true)

def env55618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,8388608,73856,8328,64,8828320,79130,8491334,8819968,8430736,98678,256,8462394,8492191,8487750]

theorem envBound55618 : H12AffineFastState.Bounded env55618 := by
  intro p hp
  have h : env55618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55601_55618 : H12AffineEnvironment.transform 21 33 env55601 = env55618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55601 == env55618) = true)

theorem identity55618 : scanCanonicalize (H12AffineFastState.compose env55618 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound55618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,131072,262144,1024,32769,4296,33,8388608,41311,8328,64,8828320,46277,8392857,8819968,8430736,169,256,8430053,8394048,8389273]

theorem envBound55619 : H12AffineFastState.Bounded env55619 := by
  intro p hp
  have h : env55619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55618_55619 : H12AffineEnvironment.transform 15 33247 env55618 = env55619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env55618 == env55619) = true)

theorem identity55619 : scanCanonicalize (H12AffineFastState.compose env55619 (packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55619 : packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env55620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,33,8388608,41311,8192,64,8828200,46157,8392721,8819968,8430616,33,256,8429933,8394048,8389137]

theorem envBound55620 : H12AffineFastState.Bounded env55620 := by
  intro p hp
  have h : env55620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55619_55620 : H12AffineEnvironment.transform 6 8 env55619 = env55620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55619 == env55620) = true)

theorem identity55620 : scanCanonicalize (H12AffineFastState.compose env55620 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound55620 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,33,16,41311,8192,64,439608,46157,4097,431376,41992,33,256,41341,5456,513]

theorem envBound55621 : H12AffineFastState.Bounded env55621 := by
  intro p hp
  have h : env55621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55620_55621 : H12AffineEnvironment.transform 22 16 env55620 = env55621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55620 == env55621) = true)

def env55622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73857,8328,64,13022593,79130,8491334,8819969,8430737,4292950,256,8462395,8492191,8487751]

theorem envBound55622 : H12AffineFastState.Bounded env55622 := by
  intro p hp
  have h : env55622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55600_55622 : H12AffineEnvironment.transform 13 5377 env55600 = env55622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55600 == env55622) = true)

def env55623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,8388608,73857,8328,64,8828321,79130,8491334,8819969,8430737,98678,256,8462395,8492191,8487751]

theorem envBound55623 : H12AffineFastState.Bounded env55623 := by
  intro p hp
  have h : env55623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55622_55623 : H12AffineEnvironment.transform 21 32 env55622 = env55623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55622 == env55623) = true)

theorem identity55623 : scanCanonicalize (H12AffineFastState.compose env55623 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98630) := by decide +kernel

theorem selectedBound55623 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98630,73857,8328,64,472295,79130,4096,463943,75223,98678,256,41341,5593,513]

theorem envBound55624 : H12AffineFastState.Bounded env55624 := by
  intro p hp
  have h : env55624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55623_55624 : H12AffineEnvironment.transform 22 98630 env55623 = env55624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98630 env55623 == env55624) = true)

def env55625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98630,73737,8192,64,472175,79130,4096,463943,75103,98678,256,41341,5457,513]

theorem envBound55625 : H12AffineFastState.Bounded env55625 := by
  intro p hp
  have h : env55625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55624_55625 : H12AffineEnvironment.transform 6 8 env55624 = env55625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55624 == env55625) = true)

def env55626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102678,32,98630,73737,8192,64,203847,79130,4096,212079,75103,98678,256,41341,5457,513]

theorem envBound55626 : H12AffineFastState.Bounded env55626 := by
  intro p hp
  have h : env55626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55625_55626 : H12AffineEnvironment.transform 17 10280 env55625 = env55626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55625 == env55626) = true)

theorem identity55626 : scanCanonicalize (H12AffineFastState.compose env55626 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 40036) := by decide +kernel

theorem selectedBound55626 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env55627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,40036,10280,1024,32769,102678,32,98630,73737,8192,64,98339,79130,4096,106507,75103,98678,256,41341,5457,513]

theorem envBound55627 : H12AffineFastState.Bounded env55627 := by
  intro p hp
  have h : env55627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55626_55627 : H12AffineEnvironment.transform 16 40036 env55626 = env55627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40036 env55626 == env55627) = true)

theorem identity55627 : scanCanonicalize (H12AffineFastState.compose env55627 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 43390) := by decide +kernel

theorem selectedBound55627 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env55628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,43390,40036,10280,1024,32769,14440,32,10296,35191,8192,64,10589,40036,4096,2421,35873,10248,256,41341,5457,513]

theorem envBound55628 : H12AffineFastState.Bounded env55628 := by
  intro p hp
  have h : env55628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55627_55628 : H12AffineEnvironment.transform 15 43390 env55627 = env55628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43390 env55627 == env55628) = true)

theorem identity55628 : scanCanonicalize (H12AffineFastState.compose env55628 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 3172) := by decide +kernel

theorem selectedBound55628 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,3172,9498,4096,10280,1024,3173,14440,32,10296,1299,8192,64,10589,4096,4096,2421,69,10248,256,11545,5457,513]

theorem envBound55629 : H12AffineFastState.Bounded env55629 := by
  intro p hp
  have h : env55629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55628_55629 : H12AffineEnvironment.transform 14 3172 env55628 = env55629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3172 env55628 == env55629) = true)

theorem identity55629 : scanCanonicalize (H12AffineFastState.compose env55629 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound55629 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2088,5377,3172,3378,4096,0,1024,3173,4160,32,16,1299,2088,64,373,4096,4096,2421,69,32,256,1329,5457,513]

theorem envBound55630 : H12AffineFastState.Bounded env55630 := by
  intro p hp
  have h : env55630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55629_55630 : H12AffineEnvironment.transform 12 2088 env55629 = env55630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env55629 == env55630) = true)

theorem identity55630 : scanCanonicalize (H12AffineFastState.compose env55630 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound55630 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,1336,5377,372,34,4096,0,1024,373,4160,32,16,1299,1336,64,373,4096,4096,1125,69,32,256,1329,5457,513]

theorem envBound55631 : H12AffineFastState.Bounded env55631 := by
  intro p hp
  have h : env55631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55630_55631 : H12AffineEnvironment.transform 10 1296 env55630 = env55631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env55630 == env55631) = true)

def env55632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102678,32,98630,73737,8192,64,203846,79130,4096,212078,75103,98678,256,41341,5457,513]

theorem envBound55632 : H12AffineFastState.Bounded env55632 := by
  intro p hp
  have h : env55632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55625_55632 : H12AffineEnvironment.transform 17 10281 env55625 = env55632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55625 == env55632) = true)

theorem identity55632 : scanCanonicalize (H12AffineFastState.compose env55632 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound55632 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env55633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,40970,131072,10281,1024,32769,12572,32,8524,32771,8192,64,179276,38160,4096,171108,34133,8572,256,41341,5457,513]

theorem envBound55633 : H12AffineFastState.Bounded env55633 := by
  intro p hp
  have h : env55633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55632_55633 : H12AffineEnvironment.transform 15 40970 env55632 = env55633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env55632 == env55633) = true)

theorem identity55633 : scanCanonicalize (H12AffineFastState.compose env55633 (packedSelected [0,1,3,5,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55633 : packedSelected [0,1,3,5,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env55634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33111,131072,2420,1024,32769,4161,32,17,32771,349,64,171281,38160,4096,171108,34133,33,256,32800,5457,513]

theorem envBound55634 : H12AffineFastState.Bounded env55634 := by
  intro p hp
  have h : env55634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55633_55634 : H12AffineEnvironment.transform 12 349 env55633 = env55634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55633 == env55634) = true)

theorem identity55634 : scanCanonicalize (H12AffineFastState.compose env55634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound55634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33111,38160,2420,1024,32769,4161,32,17,32771,349,64,2049,38160,4096,2420,34133,33,256,32800,5457,513]

theorem envBound55635 : H12AffineFastState.Bounded env55635 := by
  intro p hp
  have h : env55635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55634_55635 : H12AffineEnvironment.transform 16 38160 env55634 = env55635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env55634 == env55635) = true)

theorem identity55635 : scanCanonicalize (H12AffineFastState.compose env55635 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55635 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55636 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,33030,38160,2341,1024,32769,4112,32,17,32771,268,17,2049,38160,4096,2341,34052,33,256,32800,5376,513]

theorem envBound55636 : H12AffineFastState.Bounded env55636 := by
  intro p hp
  have h : env55636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55635_55636 : H12AffineEnvironment.transform 5 17 env55635 = env55636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55635 == env55636) = true)

theorem identity55636 : scanCanonicalize (H12AffineFastState.compose env55636 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55636 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55637 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4112,32,17,3,268,17,2049,5392,4096,2341,1284,33,256,32,5376,513]

theorem envBound55637 : H12AffineFastState.Bounded env55637 := by
  intro p hp
  have h : env55637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55636_55637 : H12AffineEnvironment.transform 14 0 env55636 = env55637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55636 == env55637) = true)

theorem identity55637 : scanCanonicalize (H12AffineFastState.compose env55637 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound55637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55638 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,309,268,1076,0,262,1061,2341,1024,1,293,32,17,3,268,17,2049,1061,309,2341,1284,33,256,32,1077,513]

theorem envBound55638 : H12AffineFastState.Bounded env55638 := by
  intro p hp
  have h : env55638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55637_55638 : H12AffineEnvironment.transform 11 309 env55637 = env55638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env55637 == env55638) = true)

theorem identity55638 : scanCanonicalize (H12AffineFastState.compose env55638 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55638 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55639 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,309,268,293,0,262,308,2341,273,1,293,32,17,3,268,17,2049,308,309,2341,21,33,256,32,292,513]

theorem envBound55639 : H12AffineFastState.Bounded env55639 := by
  intro p hp
  have h : env55639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55638_55639 : H12AffineEnvironment.transform 9 273 env55638 = env55639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55638 == env55639) = true)

theorem identity55639 : scanCanonicalize (H12AffineFastState.compose env55639 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55639 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55640 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,17,40,1,0,34,16,2049,53,1,1,32,17,3,40,17,2049,16,17,2049,21,33,36,32,0,513]

theorem envBound55640 : H12AffineFastState.Bounded env55640 := by
  intro p hp
  have h : env55640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55639_55640 : H12AffineEnvironment.transform 7 36 env55639 = env55640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55639 == env55640) = true)

theorem identity55640 : scanCanonicalize (H12AffineFastState.compose env55640 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55641 : List Nat := [2,4,8,16,16,17,8,20,512,5,2048,17,24,1,0,18,16,2049,5,1,1,16,17,3,24,17,2049,16,17,2049,21,17,20,16,0,513]

theorem envBound55641 : H12AffineFastState.Bounded env55641 := by
  intro p hp
  have h : env55641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55640_55641 : H12AffineEnvironment.transform 4 16 env55640 = env55641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55640 == env55641) = true)

theorem identity55641 : scanCanonicalize (H12AffineFastState.compose env55641 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound55641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55642 : List Nat := [2,4,8,16,16,17,8,20,512,5,16,17,24,1,0,18,16,17,5,1,1,16,17,3,24,17,17,16,17,17,21,17,20,16,0,513]

theorem envBound55642 : H12AffineFastState.Bounded env55642 := by
  intro p hp
  have h : env55642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55641_55642 : H12AffineEnvironment.transform 10 16 env55641 = env55642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env55641 == env55642) = true)

theorem identity55642 : scanCanonicalize (H12AffineFastState.compose env55642 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55642 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55643 : List Nat := [2,4,8,0,0,1,8,4,512,5,0,1,8,1,0,2,0,1,5,1,1,0,1,3,8,1,1,0,1,1,5,1,4,0,0,513]

theorem envBound55643 : H12AffineFastState.Bounded env55643 := by
  intro p hp
  have h : env55643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55642_55643 : H12AffineEnvironment.transform 3 0 env55642 = env55643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55642 == env55643) = true)

def env55644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98630,73736,8193,64,472174,79130,4096,463943,75102,98678,256,41341,5456,513]

theorem envBound55644 : H12AffineFastState.Bounded env55644 := by
  intro p hp
  have h : env55644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55624_55644 : H12AffineEnvironment.transform 6 9 env55624 = env55644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55624 == env55644) = true)

theorem identity55644 : scanCanonicalize (H12AffineFastState.compose env55644 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound55644 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,102678,32,98630,73736,8193,64,262516,79130,4096,270685,75102,98678,256,41341,5456,513]

theorem envBound55645 : H12AffineFastState.Bounded env55645 := by
  intro p hp
  have h : env55645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55644_55645 : H12AffineEnvironment.transform 16 79130 env55644 = env55645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env55644 == env55645) = true)

theorem identity55645 : scanCanonicalize (H12AffineFastState.compose env55645 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound55645 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,9499,4097,262144,1024,32769,46093,32,42077,1299,8193,64,262516,4097,4096,270685,69,42093,256,41341,5456,513]

theorem envBound55646 : H12AffineFastState.Bounded env55646 := by
  intro p hp
  have h : env55646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55645_55646 : H12AffineEnvironment.transform 15 9499 env55645 = env55646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env55645 == env55646) = true)

theorem identity55646 : scanCanonicalize (H12AffineFastState.compose env55646 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound55646 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,9499,4097,11576,1024,32769,46093,32,42077,1299,8193,64,11340,4097,4096,3173,69,42093,256,41341,5456,513]

theorem envBound55647 : H12AffineFastState.Bounded env55647 := by
  intro p hp
  have h : env55647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55646_55647 : H12AffineEnvironment.transform 17 11576 env55646 = env55647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env55646 == env55647) = true)

theorem identity55647 : scanCanonicalize (H12AffineFastState.compose env55647 (packedSelected [6,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound55647 : packedSelected [6,14,18,23] rootPS < 2^1333 := by decide +kernel

def env55648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8493,9499,4097,11576,1024,8492,5408,32,1392,1299,8193,64,11340,4097,4096,3173,69,1344,256,80,5456,513]

theorem envBound55648 : H12AffineFastState.Bounded env55648 := by
  intro p hp
  have h : env55648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55647_55648 : H12AffineEnvironment.transform 14 8493 env55647 = env55648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env55647 == env55648) = true)

theorem identity55648 : scanCanonicalize (H12AffineFastState.compose env55648 (packedSelected [0,6,21,27] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound55648 : packedSelected [0,6,21,27] rootPS < 2^1333 := by decide +kernel

def env55649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5377,80,1126,4097,3141,1024,81,5408,32,1392,1299,380,64,3377,4097,4096,3173,69,1344,256,80,5456,513]

theorem envBound55649 : H12AffineFastState.Bounded env55649 := by
  intro p hp
  have h : env55649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55648_55649 : H12AffineEnvironment.transform 12 381 env55648 = env55649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env55648 == env55649) = true)

theorem identity55649 : scanCanonicalize (H12AffineFastState.compose env55649 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound55649 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55650 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,381,4145,80,342,4097,2421,304,81,4112,32,64,35,380,64,2049,4097,4096,2389,69,112,256,80,4192,513]

theorem envBound55650 : H12AffineFastState.Bounded env55650 := by
  intro p hp
  have h : env55650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55649_55650 : H12AffineEnvironment.transform 9 304 env55649 = env55650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env55649 == env55650) = true)

theorem identity55650 : scanCanonicalize (H12AffineFastState.compose env55650 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55650 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env55651 : List Nat := [2,4,8,16,32,64,9,256,512,304,32,4096,381,4145,80,342,4097,341,304,81,4112,32,64,35,380,64,33,4097,4096,373,69,112,256,80,4192,513]

theorem envBound55651 : H12AffineFastState.Bounded env55651 := by
  intro p hp
  have h : env55651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55650_55651 : H12AffineEnvironment.transform 10 32 env55650 = env55651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55650 == env55651) = true)

theorem identity55651 : scanCanonicalize (H12AffineFastState.compose env55651 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound55651 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env55652 : List Nat := [2,4,8,16,32,64,9,256,512,304,32,97,381,80,80,342,96,341,304,81,113,32,64,35,380,64,33,96,97,373,69,112,256,80,1,513]

theorem envBound55652 : H12AffineFastState.Bounded env55652 := by
  intro p hp
  have h : env55652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55651_55652 : H12AffineEnvironment.transform 11 97 env55651 = env55652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env55651 == env55652) = true)

theorem identity55652 : scanCanonicalize (H12AffineFastState.compose env55652 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound55652 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55653 : List Nat := [2,4,8,16,32,64,9,256,340,304,32,97,381,80,80,342,96,341,304,81,113,32,64,35,380,64,33,96,97,373,69,112,256,80,1,341]

theorem envBound55653 : H12AffineFastState.Bounded env55653 := by
  intro p hp
  have h : env55653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55652_55653 : H12AffineEnvironment.transform 8 340 env55652 = env55653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env55652 == env55653) = true)

theorem identity55653 : scanCanonicalize (H12AffineFastState.compose env55653 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55653 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55654 : List Nat := [2,4,8,16,32,64,9,4,80,52,32,97,121,80,80,82,96,81,52,81,113,32,64,35,120,64,33,96,97,113,69,112,4,80,1,81]

theorem envBound55654 : H12AffineFastState.Bounded env55654 := by
  intro p hp
  have h : env55654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55653_55654 : H12AffineEnvironment.transform 7 4 env55653 = env55654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55653 == env55654) = true)

theorem identity55654 : scanCanonicalize (H12AffineFastState.compose env55654 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55654 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55655 : List Nat := [2,4,8,16,0,64,9,4,80,20,0,65,89,80,80,82,64,81,20,81,81,0,64,3,88,64,1,64,65,81,69,80,4,80,1,81]

theorem envBound55655 : H12AffineFastState.Bounded env55655 := by
  intro p hp
  have h : env55655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55654_55655 : H12AffineEnvironment.transform 4 0 env55654 = env55655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55654 == env55655) = true)

theorem identity55655 : scanCanonicalize (H12AffineFastState.compose env55655 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound55655 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55656 : List Nat := [2,4,8,16,0,0,9,4,16,20,0,1,25,16,16,18,0,17,20,17,17,0,0,3,24,0,1,0,1,17,5,16,4,16,1,17]

theorem envBound55656 : H12AffineFastState.Bounded env55656 := by
  intro p hp
  have h : env55656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55655_55656 : H12AffineEnvironment.transform 5 0 env55655 = env55656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55655 == env55656) = true)

def env55657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,8388608,73857,8328,64,8828320,79130,8491334,8819969,8430737,98679,256,8462395,8492191,8487751]

theorem envBound55657 : H12AffineFastState.Bounded env55657 := by
  intro p hp
  have h : env55657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55622_55657 : H12AffineEnvironment.transform 21 33 env55622 = env55657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55622 == env55657) = true)

theorem identity55657 : scanCanonicalize (H12AffineFastState.compose env55657 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound55657 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4160,33,8388608,41431,8328,64,8828320,46156,8392720,8819969,8430737,33,256,8429933,8394185,8389137]

theorem envBound55658 : H12AffineFastState.Bounded env55658 := by
  intro p hp
  have h : env55658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55657_55658 : H12AffineEnvironment.transform 15 33110 env55657 = env55658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env55657 == env55658) = true)

def env55659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146864,1024,32769,4160,33,8388608,41431,8328,64,8423440,46156,8392720,8431793,8430737,33,256,8429933,8394185,8389137]

theorem envBound55659 : H12AffineFastState.Bounded env55659 := by
  intro p hp
  have h : env55659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55658_55659 : H12AffineEnvironment.transform 17 146864 env55658 = env55659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env55658 == env55659) = true)

theorem identity55659 : scanCanonicalize (H12AffineFastState.compose env55659 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound55659 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,5393,10401,1024,32769,4160,33,8388608,41431,8328,64,8423440,46156,8392720,8431793,8430737,33,256,8429933,8394185,8389137]

theorem envBound55660 : H12AffineFastState.Bounded env55660 := by
  intro p hp
  have h : env55660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55659_55660 : H12AffineEnvironment.transform 16 5393 env55659 = env55660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55659 == env55660) = true)

theorem identity55660 : scanCanonicalize (H12AffineFastState.compose env55660 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound55660 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env55661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,136,478,5393,10401,1024,137,4160,33,8388608,8543,8328,64,8390808,13508,8392720,8398905,8397849,33,256,8397285,8394185,8389137]

theorem envBound55661 : H12AffineFastState.Bounded env55661 := by
  intro p hp
  have h : env55661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55660_55661 : H12AffineEnvironment.transform 14 136 env55660 = env55661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env55660 == env55661) = true)

theorem identity55661 : scanCanonicalize (H12AffineFastState.compose env55661 (packedSelected [1,3,16,20,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound55661 : packedSelected [1,3,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env55662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,136,478,5393,2420,1024,137,4160,33,8388608,138,349,64,8390808,5393,8392720,8391148,8390092,33,256,8388656,8394185,8389137]

theorem envBound55662 : H12AffineFastState.Bounded env55662 := by
  intro p hp
  have h : env55662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55661_55662 : H12AffineEnvironment.transform 12 469 env55661 = env55662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env55661 == env55662) = true)

theorem identity55662 : scanCanonicalize (H12AffineFastState.compose env55662 (packedSelected [0,2,3,4,5,7,9,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55662 : packedSelected [0,2,3,4,5,7,9,10,16] rootPS < 2^1333 := by decide +kernel

def env55663 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,161,5237,136,170,5221,2048,1024,137,4160,33,8388608,138,41,64,8390808,5221,8392720,8390808,8389816,33,116,8388656,8393917,8389137]

theorem envBound55663 : H12AffineFastState.Bounded env55663 := by
  intro p hp
  have h : env55663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55662_55663 : H12AffineEnvironment.transform 7 116 env55662 = env55663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55662 == env55663) = true)

theorem identity55663 : scanCanonicalize (H12AffineFastState.compose env55663 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(22+1) ^^^ 200) := by decide +kernel

theorem selectedBound55663 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55664 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,161,5237,136,170,5221,2048,1024,137,4160,33,200,138,41,64,2128,5221,4312,2128,1136,33,116,248,5237,729]

theorem envBound55664 : H12AffineFastState.Bounded env55664 := by
  intro p hp
  have h : env55664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55663_55664 : H12AffineEnvironment.transform 22 200 env55663 = env55664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 200 env55663 == env55664) = true)

theorem identity55664 : scanCanonicalize (H12AffineFastState.compose env55664 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55664 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55665 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,0,34,5221,2048,1024,1,4160,33,64,2,41,64,2128,5221,4176,2128,1136,33,116,112,5237,593]

theorem envBound55665 : H12AffineFastState.Bounded env55665 := by
  intro p hp
  have h : env55665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55664_55665 : H12AffineEnvironment.transform 6 8 env55664 = env55665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55664 == env55665) = true)

theorem identity55665 : scanCanonicalize (H12AffineFastState.compose env55665 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55665 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env55666 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,34,5173,2048,1024,1,4112,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound55666 : H12AffineFastState.Bounded env55666 := by
  intro p hp
  have h : env55666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55665_55666 : H12AffineEnvironment.transform 5 16 env55665 = env55666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55665 == env55666) = true)

def env55667 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,0,34,1029,2048,1024,1,32,33,16,2,41,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound55667 : H12AffineFastState.Bounded env55667 := by
  intro p hp
  have h : env55667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55666_55667 : H12AffineEnvironment.transform 11 48 env55666 = env55667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55666 == env55667) = true)

theorem identity55667 : scanCanonicalize (H12AffineFastState.compose env55667 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55668 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,48,41,1045,0,34,1029,0,1024,1,32,33,16,2,41,16,0,1029,48,0,1056,33,36,32,1045,513]

theorem envBound55668 : H12AffineFastState.Bounded env55668 := by
  intro p hp
  have h : env55668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55667_55668 : H12AffineEnvironment.transform 10 0 env55667 = env55668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55667 == env55668) = true)

def env55669 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,41,33,0,34,49,0,52,1,32,33,16,2,41,16,0,49,48,0,20,33,36,32,33,513]

theorem envBound55669 : H12AffineFastState.Bounded env55669 := by
  intro p hp
  have h : env55669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55668_55669 : H12AffineEnvironment.transform 9 52 env55668 = env55669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55668 == env55669) = true)

theorem identity55669 : scanCanonicalize (H12AffineFastState.compose env55669 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55670 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,48,41,33,0,34,49,0,52,1,32,33,16,2,41,16,0,49,48,0,20,33,36,32,33,43]

theorem envBound55670 : H12AffineFastState.Bounded env55670 := by
  intro p hp
  have h : env55670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55669_55670 : H12AffineEnvironment.transform 8 42 env55669 = env55670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55669 == env55670) = true)

def leafEnv55670 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,48,41,33,0,34,49,0,52,1,32,33,16,2,20,41,1,16,0,49,48,0,20,33,36,32,4,34,33,43,1,32,0]

def active55670 : List Nat := [0,1,2,3,4]

def tree55670 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55670 : H12WitnessSearch.Good tree55670 := H12GlobalWitnessIndex.good

theorem leafIdentity55670 : H12AffineFastState.composeSystem env55670 rootObs = leafEnv55670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55670 rootObs == leafEnv55670) = true)

theorem terminalChecked55670 : H12PackedTerminal.terminalCheckFast leafEnv55670 active55670 tree55670 = true := by decide +kernel

def env55671 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,41,32,0,34,48,0,53,1,32,33,16,2,41,16,0,48,48,0,21,33,36,32,32,513]

theorem envBound55671 : H12AffineFastState.Bounded env55671 := by
  intro p hp
  have h : env55671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55668_55671 : H12AffineEnvironment.transform 9 53 env55668 = env55671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55668 == env55671) = true)

def leafEnv55671 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,41,32,0,34,48,0,53,1,32,33,16,2,21,41,1,16,0,48,48,0,21,33,36,32,4,34,32,513,1,32,0]

def active55671 : List Nat := [0,1,2,3,4,8]

def tree55671 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55671 : H12WitnessSearch.Good tree55671 := H12GlobalWitnessIndex.good

theorem leafIdentity55671 : H12AffineFastState.composeSystem env55671 rootObs = leafEnv55671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55671 rootObs == leafEnv55671) = true)

theorem terminalChecked55671 : H12PackedTerminal.terminalCheckFast leafEnv55671 active55671 tree55671 = true := by decide +kernel

def env55672 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,0,34,1028,2048,1024,1,33,33,16,2,41,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound55672 : H12AffineFastState.Bounded env55672 := by
  intro p hp
  have h : env55672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55666_55672 : H12AffineEnvironment.transform 11 49 env55666 = env55672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55666 == env55672) = true)

theorem identity55672 : scanCanonicalize (H12AffineFastState.compose env55672 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound55672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55673 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,49,41,1044,0,34,1028,1076,1024,1,33,33,16,2,41,16,1076,1028,49,1076,1056,33,36,32,1044,513]

theorem envBound55673 : H12AffineFastState.Bounded env55673 := by
  intro p hp
  have h : env55673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55672_55673 : H12AffineEnvironment.transform 10 1076 env55672 = env55673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env55672 == env55673) = true)

def env55674 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,41,32,0,34,48,0,52,1,33,33,16,2,41,16,0,48,49,0,20,33,36,32,32,513]

theorem envBound55674 : H12AffineFastState.Bounded env55674 := by
  intro p hp
  have h : env55674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55673_55674 : H12AffineEnvironment.transform 9 52 env55673 = env55674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55673 == env55674) = true)

theorem identity55674 : scanCanonicalize (H12AffineFastState.compose env55674 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55675 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,49,41,32,0,34,48,0,52,1,33,33,16,2,41,16,0,48,49,0,20,33,36,32,32,43]

theorem envBound55675 : H12AffineFastState.Bounded env55675 := by
  intro p hp
  have h : env55675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55674_55675 : H12AffineEnvironment.transform 8 42 env55674 = env55675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55674 == env55675) = true)

def leafEnv55675 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,49,41,32,0,34,48,0,52,1,33,33,16,2,20,41,1,16,0,48,49,0,20,33,36,32,4,34,32,43,1,33,0]

def active55675 : List Nat := [0,1,2,3,4]

def tree55675 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55675 : H12WitnessSearch.Good tree55675 := H12GlobalWitnessIndex.good

theorem leafIdentity55675 : H12AffineFastState.composeSystem env55675 rootObs = leafEnv55675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55675 rootObs == leafEnv55675) = true)

theorem terminalChecked55675 : H12PackedTerminal.terminalCheckFast leafEnv55675 active55675 tree55675 = true := by decide +kernel

def env55676 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,41,33,0,34,49,1,53,1,33,33,16,2,41,16,1,49,49,1,21,33,36,32,33,513]

theorem envBound55676 : H12AffineFastState.Bounded env55676 := by
  intro p hp
  have h : env55676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55673_55676 : H12AffineEnvironment.transform 9 53 env55673 = env55676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55673 == env55676) = true)

def leafEnv55676 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,41,33,0,34,49,1,53,1,33,33,16,2,21,41,1,16,1,49,49,1,21,33,36,32,4,34,33,513,1,33,0]

def active55676 : List Nat := [0,1,2,3,4,8]

def tree55676 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55676 : H12WitnessSearch.Good tree55676 := H12GlobalWitnessIndex.good

theorem leafIdentity55676 : H12AffineFastState.composeSystem env55676 rootObs = leafEnv55676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55676 rootObs == leafEnv55676) = true)

theorem terminalChecked55676 : H12PackedTerminal.terminalCheckFast leafEnv55676 active55676 tree55676 = true := by decide +kernel

def env55677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146865,1024,32769,4160,33,8388608,41431,8328,64,8423441,46156,8392720,8431792,8430737,33,256,8429933,8394185,8389137]

theorem envBound55677 : H12AffineFastState.Bounded env55677 := by
  intro p hp
  have h : env55677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55658_55677 : H12AffineEnvironment.transform 17 146865 env55658 = env55677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env55658 == env55677) = true)

theorem identity55677 : scanCanonicalize (H12AffineFastState.compose env55677 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound55677 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,5528,10281,1024,32769,4160,33,8388608,41431,8328,64,8423441,46156,8392720,8431792,8430737,33,256,8429933,8394185,8389137]

theorem envBound55678 : H12AffineFastState.Bounded env55678 := by
  intro p hp
  have h : env55678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55677_55678 : H12AffineEnvironment.transform 16 5528 env55677 = env55678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env55677 == env55678) = true)

theorem identity55678 : scanCanonicalize (H12AffineFastState.compose env55678 (packedSelected [0,1,2,4,5,6,9,10,11,15,18,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55678 : packedSelected [0,1,2,4,5,6,9,10,11,15,18,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env55679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8202,5528,10281,1024,8541,4160,33,8388608,139,8328,64,8399181,5392,8392720,8391148,8390093,33,256,8388657,8394185,8389137]

theorem envBound55679 : H12AffineFastState.Bounded env55679 := by
  intro p hp
  have h : env55679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55678_55679 : H12AffineEnvironment.transform 14 8540 env55678 = env55679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55678 == env55679) = true)

theorem identity55679 : scanCanonicalize (H12AffineFastState.compose env55679 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound55679 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8202,5528,10281,1024,8541,4160,33,152,139,8328,64,10709,5392,4232,2420,1365,33,256,169,5457,649]

theorem envBound55680 : H12AffineFastState.Bounded env55680 := by
  intro p hp
  have h : env55680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55679_55680 : H12AffineEnvironment.transform 22 152 env55679 = env55680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env55679 == env55680) = true)

theorem identity55680 : scanCanonicalize (H12AffineFastState.compose env55680 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55680 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5392,10281,1024,8541,4160,33,16,3,8192,64,10589,5392,4096,2420,1365,33,256,33,5457,513]

theorem envBound55681 : H12AffineFastState.Bounded env55681 := by
  intro p hp
  have h : env55681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55680_55681 : H12AffineEnvironment.transform 6 8 env55680 = env55681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55680 == env55681) = true)

theorem identity55681 : scanCanonicalize (H12AffineFastState.compose env55681 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55681 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5392,2421,1024,1,4160,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5457,513]

theorem envBound55682 : H12AffineFastState.Bounded env55682 := by
  intro p hp
  have h : env55682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55681_55682 : H12AffineEnvironment.transform 12 348 env55681 = env55682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55681 == env55682) = true)

theorem identity55682 : scanCanonicalize (H12AffineFastState.compose env55682 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound55682 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55683 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,4096,348,5377,0,342,5392,2421,1024,1,4160,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5457,81]

theorem envBound55683 : H12AffineFastState.Bounded env55683 := by
  intro p hp
  have h : env55683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55682_55683 : H12AffineEnvironment.transform 8 80 env55682 = env55683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env55682 == env55683) = true)

theorem identity55683 : scanCanonicalize (H12AffineFastState.compose env55683 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound55683 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55684 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,1297,348,16,0,342,1,2421,1024,1,1361,33,16,3,348,64,2049,1,1297,2420,1365,33,256,33,64,81]

theorem envBound55684 : H12AffineFastState.Bounded env55684 := by
  intro p hp
  have h : env55684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55683_55684 : H12AffineEnvironment.transform 11 1297 env55683 = env55684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env55683 == env55684) = true)

theorem identity55684 : scanCanonicalize (H12AffineFastState.compose env55684 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound55684 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env55685 : List Nat := [2,4,8,16,32,64,8,85,80,1024,2048,1092,9,16,0,3,1,2080,1024,1,1028,33,16,3,9,64,2049,1,1092,2081,1024,33,85,33,64,81]

theorem envBound55685 : H12AffineFastState.Bounded env55685 := by
  intro p hp
  have h : env55685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55684_55685 : H12AffineEnvironment.transform 7 85 env55684 = env55685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env55684 == env55685) = true)

def env55686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,4194304,8388608,95617,8328,64,13022592,79131,8491334,8830976,8450449,4314198,256,8484155,8492190,8508999]

theorem envBound55686 : H12AffineFastState.Bounded env55686 := by
  intro p hp
  have h : env55686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55599_55686 : H12AffineEnvironment.transform 23 95617 env55599 = env55686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95617 env55599 == env55686) = true)

def env55687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73857,8328,64,13022592,79131,8491334,8819968,8430737,4292950,256,8462395,8492190,8487751]

theorem envBound55687 : H12AffineFastState.Bounded env55687 := by
  intro p hp
  have h : env55687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55686_55687 : H12AffineEnvironment.transform 13 5376 env55686 = env55687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55686 == env55687) = true)

def env55688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73857,8328,64,8828320,79131,8491334,8819968,8430737,98678,256,8462395,8492190,8487751]

theorem envBound55688 : H12AffineFastState.Bounded env55688 := by
  intro p hp
  have h : env55688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55687_55688 : H12AffineEnvironment.transform 21 32 env55687 = env55688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55687 == env55688) = true)

def env55689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73737,8192,64,8828200,79131,8491334,8819968,8430617,98678,256,8462395,8492054,8487751]

theorem envBound55689 : H12AffineFastState.Bounded env55689 := by
  intro p hp
  have h : env55689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55688_55689 : H12AffineEnvironment.transform 6 8 env55688 = env55689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55688 == env55689) = true)

def env55690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,16,73737,8192,64,439608,79131,102742,431376,41993,98678,256,73771,103430,99159]

theorem envBound55690 : H12AffineFastState.Bounded env55690 := by
  intro p hp
  have h : env55690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55689_55690 : H12AffineEnvironment.transform 22 16 env55689 = env55690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55689 == env55690) = true)

def env55691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5392,262144,1024,32769,102679,32,16,73737,8192,64,303144,79131,102742,294912,41993,98678,256,73771,103430,99159]

theorem envBound55691 : H12AffineFastState.Bounded env55691 := by
  intro p hp
  have h : env55691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55690_55691 : H12AffineEnvironment.transform 16 5392 env55690 = env55691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env55690 == env55691) = true)

theorem identity55691 : scanCanonicalize (H12AffineFastState.compose env55691 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound55691 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5392,262144,1024,32769,4161,32,16,41311,8192,64,303144,46157,4096,294912,41993,32,256,41341,5456,513]

theorem envBound55692 : H12AffineFastState.Bounded env55692 := by
  intro p hp
  have h : env55692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55691_55692 : H12AffineEnvironment.transform 15 33110 env55691 = env55692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env55691 == env55692) = true)

theorem identity55692 : scanCanonicalize (H12AffineFastState.compose env55692 (packedSelected [1,2,6,8,12,15,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound55692 : packedSelected [1,2,6,8,12,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,8283,5392,262144,1024,8460,4161,32,16,82,8192,64,262437,5440,4096,270605,1284,32,256,112,5456,513]

theorem envBound55693 : H12AffineFastState.Bounded env55693 := by
  intro p hp
  have h : env55693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55692_55693 : H12AffineEnvironment.transform 14 8461 env55692 = env55693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env55692 == env55693) = true)

theorem identity55693 : scanCanonicalize (H12AffineFastState.compose env55693 (packedSelected [1,2,6,8,12,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound55693 : packedSelected [1,2,6,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env55694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,8283,5392,10360,1024,8460,4161,32,16,82,8192,64,10589,5440,4096,2421,1284,32,256,112,5456,513]

theorem envBound55694 : H12AffineFastState.Bounded env55694 := by
  intro p hp
  have h : env55694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55693_55694 : H12AffineEnvironment.transform 17 10360 env55693 = env55694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env55693 == env55694) = true)

theorem identity55694 : scanCanonicalize (H12AffineFastState.compose env55694 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55694 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,81,263,5392,2340,1024,80,4161,32,16,82,348,64,2049,5440,4096,2421,1284,32,256,112,5456,513]

theorem envBound55695 : H12AffineFastState.Bounded env55695 := by
  intro p hp
  have h : env55695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55694_55695 : H12AffineEnvironment.transform 12 348 env55694 = env55695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55694 == env55695) = true)

def env55696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,262144,1024,32769,102679,32,16,73737,8192,64,303145,79131,102742,294913,41993,98678,256,73771,103430,99159]

theorem envBound55696 : H12AffineFastState.Bounded env55696 := by
  intro p hp
  have h : env55696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55690_55696 : H12AffineEnvironment.transform 16 5393 env55690 = env55696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55690 == env55696) = true)

theorem identity55696 : scanCanonicalize (H12AffineFastState.compose env55696 (packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound55696 : packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env55697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,108927,1024,32769,102679,32,16,73737,8192,64,67926,79131,102742,76158,41993,98678,256,73771,103430,99159]

theorem envBound55697 : H12AffineFastState.Bounded env55697 := by
  intro p hp
  have h : env55697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55696_55697 : H12AffineEnvironment.transform 17 108927 env55696 = env55697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env55696 == env55697) = true)

theorem identity55697 : scanCanonicalize (H12AffineFastState.compose env55697 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound55697 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env55698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,262,5393,43129,1024,32769,36881,32,16,8463,8192,64,2128,13341,36944,10360,41993,32880,256,8493,38144,33361]

theorem envBound55698 : H12AffineFastState.Bounded env55698 := by
  intro p hp
  have h : env55698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55697_55698 : H12AffineEnvironment.transform 15 262 env55697 = env55698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env55697 == env55698) = true)

theorem identity55698 : scanCanonicalize (H12AffineFastState.compose env55698 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55698 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env55699 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,262,5393,43049,1024,32769,36881,32,16,8463,8192,16,2048,13341,36864,10280,41993,32800,256,8493,38144,33281]

theorem envBound55699 : H12AffineFastState.Bounded env55699 := by
  intro p hp
  have h : env55699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55698_55699 : H12AffineEnvironment.transform 5 16 env55698 = env55699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55698 == env55699) = true)

theorem identity55699 : scanCanonicalize (H12AffineFastState.compose env55699 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55699 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env55700 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,32768,262,5393,35108,1024,32769,36881,32,16,2,269,16,2048,5392,36864,2341,34052,32800,256,32,38144,33281]

theorem envBound55700 : H12AffineFastState.Bounded env55700 := by
  intro p hp
  have h : env55700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55699_55700 : H12AffineEnvironment.transform 12 269 env55699 = env55700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55699 == env55700) = true)

theorem identity55700 : scanCanonicalize (H12AffineFastState.compose env55700 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55700 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55701 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,9,5124,32768,2,5141,34848,1024,32769,36881,32,16,2,9,16,2048,5140,36864,2081,33792,32800,4,32,37892,33281]

theorem envBound55701 : H12AffineFastState.Bounded env55701 := by
  intro p hp
  have h : env55701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55700_55701 : H12AffineEnvironment.transform 7 4 env55700 = env55701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55700 == env55701) = true)

theorem identity55701 : scanCanonicalize (H12AffineFastState.compose env55701 (packedSelected [1,2,8] rootPS)) = affineNative (2^(14+1) ^^^ 6192) := by decide +kernel

theorem selectedBound55701 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env55702 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,9,5124,6192,2,5141,4112,1024,6193,2081,32,16,2,9,16,2048,5140,2096,2081,7216,6160,4,32,3124,6705]

theorem envBound55702 : H12AffineFastState.Bounded env55702 := by
  intro p hp
  have h : env55702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55701_55702 : H12AffineEnvironment.transform 14 6192 env55701 = env55702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6192 env55701 == env55702) = true)

theorem identity55702 : scanCanonicalize (H12AffineFastState.compose env55702 (packedSelected [0,2,6,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound55702 : packedSelected [0,2,6,7,10] rootPS < 2^1333 := by decide +kernel

def env55703 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,3077,9,2049,1077,2,2064,3093,1024,1076,2081,32,16,2,9,16,2048,2065,2096,2081,53,1045,4,32,3124,1588]

theorem envBound55703 : H12AffineFastState.Bounded env55703 := by
  intro p hp
  have h : env55703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55702_55703 : H12AffineEnvironment.transform 11 3077 env55702 = env55703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env55702 == env55703) = true)

theorem identity55703 : scanCanonicalize (H12AffineFastState.compose env55703 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55703 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env55704 : List Nat := [2,4,8,16,32,16,8,4,512,52,2048,2097,9,2049,1,2,2064,2081,52,0,2081,32,16,2,9,16,2048,2065,2096,2081,53,33,4,32,2048,512]

theorem envBound55704 : H12AffineFastState.Bounded env55704 := by
  intro p hp
  have h : env55704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55703_55704 : H12AffineEnvironment.transform 9 52 env55703 = env55704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55703 == env55704) = true)

theorem identity55704 : scanCanonicalize (H12AffineFastState.compose env55704 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55704 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55705 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2049,1,2,2064,2049,20,0,2049,0,16,2,9,16,2048,2065,2064,2049,21,1,4,0,2048,512]

theorem envBound55705 : H12AffineFastState.Bounded env55705 := by
  intro p hp
  have h : env55705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55704_55705 : H12AffineEnvironment.transform 4 0 env55704 = env55705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55704 == env55705) = true)

theorem identity55705 : scanCanonicalize (H12AffineFastState.compose env55705 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55706 : List Nat := [2,4,8,16,0,16,8,4,1,20,2048,2065,9,2049,1,2,2064,2049,20,0,2049,0,16,2,9,16,2048,2065,2064,2049,21,1,4,0,2048,1]

theorem envBound55706 : H12AffineFastState.Bounded env55706 := by
  intro p hp
  have h : env55706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55705_55706 : H12AffineEnvironment.transform 8 1 env55705 = env55706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55705 == env55706) = true)

theorem identity55706 : scanCanonicalize (H12AffineFastState.compose env55706 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound55706 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55707 : List Nat := [2,4,8,16,0,16,8,4,1,20,31,14,9,30,1,2,15,30,20,0,30,0,16,2,9,16,31,14,15,30,21,1,4,0,31,1]

end H12CloudChart1