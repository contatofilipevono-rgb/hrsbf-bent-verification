import H12CloudChart1Data004

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound1208 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env1209 : List Nat := [2,4,8,16,32,0,41,63,512,20,16,59,25,58,59,9,42,32,21,59,59,48,17,34,56,0,1,59,43,49,4,17,62,1,42,513]

theorem envBound1209 : H12AffineFastState.Bounded env1209 := by
  intro p hp
  have h : env1209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1208_1209 : H12AffineEnvironment.transform 7 63 env1208 = env1209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env1208 == env1209) = true)

theorem identity1209 : scanCanonicalize (H12AffineFastState.compose env1209 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound1209 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1210 : List Nat := [2,4,8,16,32,0,41,63,48,20,16,59,25,58,59,9,42,32,21,59,59,48,17,34,56,0,1,59,43,49,4,17,62,1,42,49]

theorem envBound1210 : H12AffineFastState.Bounded env1210 := by
  intro p hp
  have h : env1210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1209_1210 : H12AffineEnvironment.transform 8 48 env1209 = env1210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env1209 == env1210) = true)

theorem identity1210 : scanCanonicalize (H12AffineFastState.compose env1210 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound1210 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env1211 : List Nat := [2,4,8,16,24,0,17,7,8,20,16,3,25,2,3,9,18,24,21,3,3,8,17,26,0,0,1,3,19,9,4,17,6,1,18,9]

theorem envBound1211 : H12AffineFastState.Bounded env1211 := by
  intro p hp
  have h : env1211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1210_1211 : H12AffineEnvironment.transform 4 24 env1210 = env1211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env1210 == env1211) = true)

theorem identity1211 : scanCanonicalize (H12AffineFastState.compose env1211 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound1211 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1212 : List Nat := [2,4,3,16,19,0,17,7,3,20,16,3,18,2,3,2,18,19,21,3,3,3,17,17,0,0,1,3,19,2,4,17,6,1,18,2]

theorem envBound1212 : H12AffineFastState.Bounded env1212 := by
  intro p hp
  have h : env1212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1211_1212 : H12AffineEnvironment.transform 2 3 env1211 = env1212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env1211 == env1212) = true)

theorem identity1212 : scanCanonicalize (H12AffineFastState.compose env1212 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound1212 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1213 : List Nat := [2,4,3,6,5,0,7,7,3,2,6,3,4,2,3,2,4,5,3,3,3,3,7,7,0,0,1,3,5,2,4,7,6,1,4,2]

theorem envBound1213 : H12AffineFastState.Bounded env1213 := by
  intro p hp
  have h : env1213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1212_1213 : H12AffineEnvironment.transform 3 6 env1212 = env1213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env1212 == env1213) = true)

theorem identity1213 : scanCanonicalize (H12AffineFastState.compose env1213 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound1213 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1214 : List Nat := [2,0,3,2,1,0,3,3,3,2,2,3,0,2,3,2,0,1,3,3,3,3,3,3,0,0,1,3,1,2,0,3,2,1,0,2]

theorem envBound1214 : H12AffineFastState.Bounded env1214 := by
  intro p hp
  have h : env1214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1213_1214 : H12AffineEnvironment.transform 1 0 env1213 = env1214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env1213 == env1214) = true)

def env1215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,4341976,257,1,131073,16925299]

theorem envBound1215 : H12AffineFastState.Bounded env1215 := by
  intro p hp
  have h : env1215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1191_1215 : H12AffineEnvironment.transform 34 131073 env1191 = env1215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1191 == env1215) = true)

theorem identity1215 : scanCanonicalize (H12AffineFastState.compose env1215 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 148700) := by decide +kernel

theorem selectedBound1215 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,148700,147521,16777216,8328,147472,409816,16385,151552,2081,16852468,1028,257,1,131073,16925299]

theorem envBound1216 : H12AffineFastState.Bounded env1216 := by
  intro p hp
  have h : env1216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1215_1216 : H12AffineEnvironment.transform 21 148700 env1215 = env1216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 148700 env1215 == env1216) = true)

theorem identity1216 : scanCanonicalize (H12AffineFastState.compose env1216 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 222473) := by decide +kernel

theorem selectedBound1216 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,148700,147521,222473,8328,147472,409816,16385,151552,2081,147709,1028,257,1,131073,75642]

theorem envBound1217 : H12AffineFastState.Bounded env1217 := by
  intro p hp
  have h : env1217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1216_1217 : H12AffineEnvironment.transform 23 222473 env1216 = env1217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 222473 env1216 == env1217) = true)

theorem identity1217 : scanCanonicalize (H12AffineFastState.compose env1217 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 9594) := by decide +kernel

theorem selectedBound1217 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,9594,131072,262144,1025,8692,2097152,148700,147521,147571,8328,147472,409816,16385,151552,2081,147709,1028,257,1,131073,512]

theorem envBound1218 : H12AffineFastState.Bounded env1218 := by
  intro p hp
  have h : env1218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1217_1218 : H12AffineEnvironment.transform 15 9594 env1217 = env1218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9594 env1217 == env1218) = true)

theorem identity1218 : scanCanonicalize (H12AffineFastState.compose env1218 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 17661) := by decide +kernel

theorem selectedBound1218 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,9594,17661,262144,1025,8692,2097152,33,1212,1166,8328,1261,263205,16385,5373,2081,1024,1028,257,1,17660,512]

theorem envBound1219 : H12AffineFastState.Bounded env1219 := by
  intro p hp
  have h : env1219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1218_1219 : H12AffineEnvironment.transform 16 17661 env1218 = env1219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17661 env1218 == env1219) = true)

theorem identity1219 : scanCanonicalize (H12AffineFastState.compose env1219 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1219 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1220 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16633,262144,5,8692,2097152,33,184,138,8328,233,262177,16385,4345,2081,4,0,257,1,16632,512]

theorem envBound1220 : H12AffineFastState.Bounded env1220 := by
  intro p hp
  have h : env1220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1219_1220 : H12AffineEnvironment.transform 9 4 env1219 = env1220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1219 == env1220) = true)

theorem identity1220 : scanCanonicalize (H12AffineFastState.compose env1220 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound1220 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1221 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8692,8574,16633,2081,5,8692,2097152,33,184,138,8328,233,2048,16385,4345,2081,4,0,257,1,16632,512]

theorem envBound1221 : H12AffineFastState.Bounded env1221 := by
  intro p hp
  have h : env1221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1220_1221 : H12AffineEnvironment.transform 17 2081 env1220 = env1221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env1220 == env1221) = true)

theorem identity1221 : scanCanonicalize (H12AffineFastState.compose env1221 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound1221 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1222 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16633,2081,5,8200,2097152,33,184,138,8328,233,2048,16385,4345,2081,4,0,253,1,16632,512]

theorem envBound1222 : H12AffineFastState.Bounded env1222 := by
  intro p hp
  have h : env1222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1221_1222 : H12AffineEnvironment.transform 7 252 env1221 = env1222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1221 == env1222) = true)

theorem identity1222 : scanCanonicalize (H12AffineFastState.compose env1222 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26827) := by decide +kernel

theorem selectedBound1222 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env1223 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8200,8322,16633,2081,5,8200,26827,33,184,138,8328,233,2048,16385,4345,2081,4,0,253,1,16632,512]

theorem envBound1223 : H12AffineFastState.Bounded env1223 := by
  intro p hp
  have h : env1223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1222_1223 : H12AffineEnvironment.transform 20 26827 env1222 = env1223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26827 env1222 == env1223) = true)

theorem identity1223 : scanCanonicalize (H12AffineFastState.compose env1223 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound1223 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1224 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12496,8200,8322,12329,2081,5,8200,6171,33,184,138,8328,233,2048,12497,4345,2081,4,0,253,1,12328,512]

theorem envBound1224 : H12AffineFastState.Bounded env1224 := by
  intro p hp
  have h : env1224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1223_1224 : H12AffineEnvironment.transform 13 12496 env1223 = env1224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env1223 == env1224) = true)

theorem identity1224 : scanCanonicalize (H12AffineFastState.compose env1224 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound1224 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env1225 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2282,6202,2274,2152,6339,2081,5,2274,6171,33,184,138,2146,233,2048,6203,4345,2081,4,0,253,1,6338,512]

theorem envBound1225 : H12AffineFastState.Bounded env1225 := by
  intro p hp
  have h : env1225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1224_1225 : H12AffineEnvironment.transform 12 2282 env1224 = env1225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env1224 == env1225) = true)

theorem identity1225 : scanCanonicalize (H12AffineFastState.compose env1225 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound1225 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env1226 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2216,2282,146,2274,2152,107,2081,5,2274,179,33,184,138,2146,233,2048,147,2129,2081,4,0,253,1,106,512]

theorem envBound1226 : H12AffineFastState.Bounded env1226 := by
  intro p hp
  have h : env1226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1225_1226 : H12AffineEnvironment.transform 11 2216 env1225 = env1226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env1225 == env1226) = true)

theorem identity1226 : scanCanonicalize (H12AffineFastState.compose env1226 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound1226 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1227 : List Nat := [2,4,8,16,32,64,128,252,512,4,59,147,209,146,217,83,107,26,5,217,179,33,184,138,89,233,59,147,106,26,4,0,253,1,106,512]

theorem envBound1227 : H12AffineFastState.Bounded env1227 := by
  intro p hp
  have h : env1227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1226_1227 : H12AffineEnvironment.transform 10 59 env1226 = env1227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env1226 == env1227) = true)

theorem identity1227 : scanCanonicalize (H12AffineFastState.compose env1227 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound1227 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env1228 : List Nat := [2,4,8,16,32,43,128,151,512,4,59,147,186,146,178,56,0,26,5,178,179,33,184,138,50,130,59,147,1,26,4,0,150,1,1,512]

theorem envBound1228 : H12AffineFastState.Bounded env1228 := by
  intro p hp
  have h : env1228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1227_1228 : H12AffineEnvironment.transform 5 43 env1227 = env1228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env1227 == env1228) = true)

theorem identity1228 : scanCanonicalize (H12AffineFastState.compose env1228 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound1228 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1229 : List Nat := [2,4,8,16,32,43,18,5,512,4,59,1,40,0,32,56,0,26,5,32,33,33,42,24,50,16,59,1,1,26,4,0,4,1,1,512]

theorem envBound1229 : H12AffineFastState.Bounded env1229 := by
  intro p hp
  have h : env1229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1228_1229 : H12AffineEnvironment.transform 6 18 env1228 = env1229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env1228 == env1229) = true)

theorem identity1229 : scanCanonicalize (H12AffineFastState.compose env1229 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound1229 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1230 : List Nat := [2,4,8,16,10,1,18,5,512,4,17,1,2,0,10,18,0,26,5,10,11,11,0,24,24,16,17,1,1,26,4,0,4,1,1,512]

theorem envBound1230 : H12AffineFastState.Bounded env1230 := by
  intro p hp
  have h : env1230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1229_1230 : H12AffineEnvironment.transform 4 10 env1229 = env1230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env1229 == env1230) = true)

theorem identity1230 : scanCanonicalize (H12AffineFastState.compose env1230 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound1230 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1231 : List Nat := [2,4,8,11,10,1,9,5,512,4,10,1,2,0,10,9,0,1,5,10,11,11,0,3,3,11,10,1,1,1,4,0,4,1,1,512]

theorem envBound1231 : H12AffineFastState.Bounded env1231 := by
  intro p hp
  have h : env1231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1230_1231 : H12AffineEnvironment.transform 3 11 env1230 = env1231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env1230 == env1231) = true)

theorem identity1231 : scanCanonicalize (H12AffineFastState.compose env1231 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound1231 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1232 : List Nat := [2,4,3,0,1,1,2,5,512,4,1,1,2,0,1,2,0,1,5,1,0,0,0,3,3,0,1,1,1,1,4,0,4,1,1,512]

theorem envBound1232 : H12AffineFastState.Bounded env1232 := by
  intro p hp
  have h : env1232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1231_1232 : H12AffineEnvironment.transform 2 3 env1231 = env1232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env1231 == env1232) = true)

theorem identity1232 : scanCanonicalize (H12AffineFastState.compose env1232 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1233 : List Nat := [2,4,3,0,1,1,2,5,6,4,1,1,2,0,1,2,0,1,5,1,0,0,0,3,3,0,1,1,1,1,4,0,4,1,1,6]

theorem envBound1233 : H12AffineFastState.Bounded env1233 := by
  intro p hp
  have h : env1233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1232_1233 : H12AffineEnvironment.transform 8 6 env1232 = env1233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1232 == env1233) = true)

def env1234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2081,17375732,13108377,525568,1,34359738368,25691698]

theorem envBound1234 : H12AffineFastState.Bounded env1234 := by
  intro p hp
  have h : env1234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1071_1234 : H12AffineEnvironment.transform 14 8693 env1071 = env1234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1071 == env1234) = true)

theorem identity1234 : scanCanonicalize (H12AffineFastState.compose env1234 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound1234 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913970,8328,8914000,9176216,16385,151552,2081,8463814,13108377,525568,1,34359738368,512]

theorem envBound1235 : H12AffineFastState.Bounded env1235 := by
  intro p hp
  have h : env1235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1234_1235 : H12AffineEnvironment.transform 23 8913970 env1234 = env1235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env1234 == env1235) = true)

theorem identity1235 : scanCanonicalize (H12AffineFastState.compose env1235 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound1235 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,525344,8388608,8913970,8328,8914000,9176216,16385,151552,2081,8463814,8388793,525568,1,34359738368,512]

theorem envBound1236 : H12AffineFastState.Bounded env1236 := by
  intro p hp
  have h : env1236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1235_1236 : H12AffineEnvironment.transform 21 525344 env1235 = env1236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env1235 == env1236) = true)

theorem identity1236 : scanCanonicalize (H12AffineFastState.compose env1236 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound1236 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462668,8328,8462638,8724966,16385,151552,2081,8463814,8388793,73854,1,34359738368,512]

theorem envBound1237 : H12AffineFastState.Bounded env1237 := by
  intro p hp
  have h : env1237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1236_1237 : H12AffineEnvironment.transform 18 75134 env1236 = env1237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env1236 == env1237) = true)

theorem identity1237 : scanCanonicalize (H12AffineFastState.compose env1237 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131333) := by decide +kernel

theorem selectedBound1237 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462668,8328,8462638,8724966,16385,151552,2081,8463814,8388793,73854,1,131333,512]

theorem envBound1238 : H12AffineFastState.Bounded env1238 := by
  intro p hp
  have h : env1238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1237_1238 : H12AffineEnvironment.transform 34 131333 env1237 = env1238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131333 env1237 == env1238) = true)

def env1239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,184,74228,8328,74134,336222,16385,151552,2081,75134,1,73854,1,131333,512]

theorem envBound1239 : H12AffineFastState.Bounded env1239 := by
  intro p hp
  have h : env1239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1238_1239 : H12AffineEnvironment.transform 22 184 env1238 = env1239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1238 == env1239) = true)

theorem identity1239 : scanCanonicalize (H12AffineFastState.compose env1239 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound1239 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,223323,75134,8693,2097152,74078,184,74228,8328,74134,149765,16385,151552,2081,75134,1,73854,1,131333,512]

theorem envBound1240 : H12AffineFastState.Bounded env1240 := by
  intro p hp
  have h : env1240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1239_1240 : H12AffineEnvironment.transform 17 223323 env1239 = env1240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env1239 == env1240) = true)

def env1241 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,2097152,73890,184,73736,8328,73834,149753,16385,151552,2081,74882,1,73854,1,131321,512]

theorem envBound1241 : H12AffineFastState.Bounded env1241 := by
  intro p hp
  have h : env1241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1240_1241 : H12AffineEnvironment.transform 7 252 env1240 = env1241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1240 == env1241) = true)

theorem identity1241 : scanCanonicalize (H12AffineFastState.compose env1241 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound1241 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1242 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,151553,73890,184,73736,8328,73834,149753,16385,151552,2081,74882,1,73854,1,131321,512]

theorem envBound1242 : H12AffineFastState.Bounded env1242 := by
  intro p hp
  have h : env1242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1241_1242 : H12AffineEnvironment.transform 20 151553 env1241 = env1242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env1241 == env1242) = true)

theorem identity1242 : scanCanonicalize (H12AffineFastState.compose env1242 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90234) := by decide +kernel

theorem selectedBound1242 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1243 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,90234,2081,74882,8201,77947,73890,184,73736,8328,73834,75907,16385,77946,2081,74882,1,73854,1,90243,512]

theorem envBound1243 : H12AffineFastState.Bounded env1243 := by
  intro p hp
  have h : env1243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1242_1243 : H12AffineEnvironment.transform 16 90234 env1242 = env1243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90234 env1242 == env1243) = true)

theorem identity1243 : scanCanonicalize (H12AffineFastState.compose env1243 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1243 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1244 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,8323,16633,2081,1025,8201,4344,33,184,139,8328,233,2048,16385,4345,2081,1025,1,253,1,16384,512]

theorem envBound1244 : H12AffineFastState.Bounded env1244 := by
  intro p hp
  have h : env1244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1243_1244 : H12AffineEnvironment.transform 15 8323 env1243 = env1244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1243 == env1244) = true)

theorem identity1244 : scanCanonicalize (H12AffineFastState.compose env1244 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound1244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1245 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8201,8323,5260,2081,1025,8201,4344,33,184,139,8328,233,2048,5236,4345,2081,1025,1,253,1,5237,512]

theorem envBound1245 : H12AffineFastState.Bounded env1245 := by
  intro p hp
  have h : env1245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1244_1245 : H12AffineEnvironment.transform 13 5237 env1244 = env1245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env1244 == env1245) = true)

theorem identity1245 : scanCanonicalize (H12AffineFastState.compose env1245 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound1245 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1246 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,602,8201,8323,675,2081,1025,8201,1751,33,184,139,8328,233,2048,603,1750,2081,1025,1,253,1,602,512]

theorem envBound1246 : H12AffineFastState.Bounded env1246 := by
  intro p hp
  have h : env1246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1245_1246 : H12AffineEnvironment.transform 11 1583 env1245 = env1246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env1245 == env1246) = true)

theorem identity1246 : scanCanonicalize (H12AffineFastState.compose env1246 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3823) := by decide +kernel

theorem selectedBound1246 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1247 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3823,602,3814,3692,675,2081,1025,3814,1751,33,184,139,3687,233,2048,603,1750,2081,1025,1,253,1,602,512]

theorem envBound1247 : H12AffineFastState.Bounded env1247 := by
  intro p hp
  have h : env1247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1246_1247 : H12AffineEnvironment.transform 12 3823 env1246 = env1247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3823 env1246 == env1247) = true)

theorem identity1247 : scanCanonicalize (H12AffineFastState.compose env1247 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1247 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1248 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,555,2795,602,2786,2664,675,2081,5,2786,723,33,184,139,2659,233,2048,603,722,2081,5,1,253,1,602,512]

theorem envBound1248 : H12AffineFastState.Bounded env1248 := by
  intro p hp
  have h : env1248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1247_1248 : H12AffineEnvironment.transform 9 4 env1247 = env1248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1247 == env1248) = true)

theorem identity1248 : scanCanonicalize (H12AffineFastState.compose env1248 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1248 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1249 : List Nat := [2,4,8,16,32,64,121,5,512,4,2048,555,2578,602,2587,2664,602,2081,5,2587,554,33,65,114,2659,16,2048,603,555,2081,5,1,4,1,602,512]

theorem envBound1249 : H12AffineFastState.Bounded env1249 := by
  intro p hp
  have h : env1249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1248_1249 : H12AffineEnvironment.transform 6 121 env1248 = env1249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1248 == env1249) = true)

theorem identity1249 : scanCanonicalize (H12AffineFastState.compose env1249 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound1249 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1250 : List Nat := [2,4,8,16,32,64,121,5,512,4,608,555,114,602,123,8,602,577,5,123,554,33,65,114,3,16,608,603,555,577,5,1,4,1,602,512]

theorem envBound1250 : H12AffineFastState.Bounded env1250 := by
  intro p hp
  have h : env1250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1249_1250 : H12AffineEnvironment.transform 10 608 env1249 = env1250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env1249 == env1250) = true)

theorem identity1250 : scanCanonicalize (H12AffineFastState.compose env1250 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound1250 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1251 : List Nat := [2,4,8,16,26,64,67,5,512,4,602,529,72,602,65,8,602,577,5,65,528,27,65,72,3,16,602,603,529,577,5,1,4,1,602,512]

theorem envBound1251 : H12AffineFastState.Bounded env1251 := by
  intro p hp
  have h : env1251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1250_1251 : H12AffineEnvironment.transform 4 26 env1250 = env1251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env1250 == env1251) = true)

def env1252 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,2097152,73891,184,73737,8328,73835,149752,16385,151552,2081,74883,1,73854,1,131320,512]

theorem envBound1252 : H12AffineFastState.Bounded env1252 := by
  intro p hp
  have h : env1252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1240_1252 : H12AffineEnvironment.transform 7 253 env1240 = env1252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1240 == env1252) = true)

theorem identity1252 : scanCanonicalize (H12AffineFastState.compose env1252 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78034) := by decide +kernel

theorem selectedBound1252 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1253 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,78034,73891,184,73737,8328,73835,149752,16385,151552,2081,74883,1,73854,1,131320,512]

theorem envBound1253 : H12AffineFastState.Bounded env1253 := by
  intro p hp
  have h : env1253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1252_1253 : H12AffineEnvironment.transform 20 78034 env1252 = env1253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78034 env1252 == env1253) = true)

theorem identity1253 : scanCanonicalize (H12AffineFastState.compose env1253 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound1253 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1254 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7694,8200,65536,131072,210517,74883,8200,78034,73891,184,73737,8328,73835,136950,7695,134670,2081,74883,1,73854,1,131320,512]

theorem envBound1254 : H12AffineFastState.Bounded env1254 := by
  intro p hp
  have h : env1254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1253_1254 : H12AffineEnvironment.transform 13 7694 env1253 = env1254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env1253 == env1254) = true)

def env1255 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,131072,205377,74883,8200,74950,73891,184,73737,8328,73835,131810,2587,134670,2081,74883,1,73854,1,131320,512]

theorem envBound1255 : H12AffineFastState.Bounded env1255 := by
  intro p hp
  have h : env1255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1254_1255 : H12AffineEnvironment.transform 11 1044 env1254 = env1255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1254 == env1255) = true)

def env1256 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76384,2081,74883,8200,74950,73891,184,73737,8328,73835,75906,2587,74862,2081,74883,1,73854,1,76440,512]

theorem envBound1256 : H12AffineFastState.Bounded env1256 := by
  intro p hp
  have h : env1256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1255_1256 : H12AffineEnvironment.transform 16 76384 env1255 = env1256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1255 == env1256) = true)

theorem identity1256 : scanCanonicalize (H12AffineFastState.compose env1256 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound1256 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1257 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,98,10754,2081,9441,8200,9380,8385,184,8299,8328,8201,10464,2587,9228,2081,9441,1,8220,1,11002,512]

theorem envBound1257 : H12AffineFastState.Bounded env1257 := by
  intro p hp
  have h : env1257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1256_1257 : H12AffineEnvironment.transform 15 98 env1256 = env1257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env1256 == env1257) = true)

def env1258 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76385,2080,74883,8200,74950,73891,184,73737,8328,73835,75907,2587,74863,2081,74883,1,73854,1,76441,512]

theorem envBound1258 : H12AffineFastState.Bounded env1258 := by
  intro p hp
  have h : env1258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1255_1258 : H12AffineEnvironment.transform 16 76385 env1255 = env1258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1255 == env1258) = true)

theorem identity1258 : scanCanonicalize (H12AffineFastState.compose env1258 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1258 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1259 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2586,3615,65536,66678,2080,68244,3615,68305,69300,184,69150,3743,69244,67220,2587,68216,2081,68244,1,69225,1,66702,512]

theorem envBound1259 : H12AffineFastState.Bounded env1259 := by
  intro p hp
  have h : env1259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1258_1259 : H12AffineEnvironment.transform 12 3607 env1258 = env1259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1258 == env1259) = true)

theorem identity1259 : scanCanonicalize (H12AffineFastState.compose env1259 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1259 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1260 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2586,3615,3733,2787,2080,1025,3615,1092,33,184,139,3743,233,2049,2587,1261,2081,1025,1,252,1,2587,512]

theorem envBound1260 : H12AffineFastState.Bounded env1260 := by
  intro p hp
  have h : env1260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1259_1260 : H12AffineEnvironment.transform 15 3733 env1259 = env1260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1259 == env1260) = true)

theorem identity1260 : scanCanonicalize (H12AffineFastState.compose env1260 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1260 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1261 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2626,2586,2634,2752,2787,2080,84,2634,17,33,184,139,2762,233,2049,2587,184,2081,84,1,252,1,2587,512]

theorem envBound1261 : H12AffineFastState.Bounded env1261 := by
  intro p hp
  have h : env1261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1260_1261 : H12AffineEnvironment.transform 9 85 env1260 = env1261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1260 == env1261) = true)

theorem identity1261 : scanCanonicalize (H12AffineFastState.compose env1261 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1261 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1262 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,65,2626,2586,2634,2664,2635,2080,84,2634,17,33,16,35,2658,65,2049,2587,16,2081,84,1,84,1,2587,512]

theorem envBound1262 : H12AffineFastState.Bounded env1262 := by
  intro p hp
  have h : env1262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1261_1262 : H12AffineEnvironment.transform 6 40 env1261 = env1262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1261 == env1262) = true)

def env1263 : List Nat := [2,4,8,16,16,64,24,85,512,85,2048,65,2626,2586,2634,2648,2635,2064,84,2634,17,17,16,19,2642,65,2049,2587,16,2065,84,1,84,1,2587,512]

theorem envBound1263 : H12AffineFastState.Bounded env1263 := by
  intro p hp
  have h : env1263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1262_1263 : H12AffineEnvironment.transform 4 16 env1262 = env1263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1262 == env1263) = true)

def env1264 : List Nat := [2,4,8,16,16,64,24,85,512,85,0,65,578,538,586,600,587,16,84,586,17,17,16,19,594,65,1,539,16,17,84,1,84,1,539,512]

theorem envBound1264 : H12AffineFastState.Bounded env1264 := by
  intro p hp
  have h : env1264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1263_1264 : H12AffineEnvironment.transform 10 0 env1263 = env1264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1263 == env1264) = true)

theorem identity1264 : scanCanonicalize (H12AffineFastState.compose env1264 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound1264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1265 : List Nat := [2,4,8,16,16,12,24,25,512,25,0,13,526,538,518,532,519,16,24,518,17,17,16,19,542,13,1,539,16,17,24,1,24,1,539,512]

theorem envBound1265 : H12AffineFastState.Bounded env1265 := by
  intro p hp
  have h : env1265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1264_1265 : H12AffineEnvironment.transform 5 12 env1264 = env1265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env1264 == env1265) = true)

def env1266 : List Nat := [2,4,4,16,16,0,20,21,512,21,0,1,514,534,518,532,519,16,20,518,17,17,16,19,530,1,1,535,16,17,20,1,20,1,535,512]

theorem envBound1266 : H12AffineFastState.Bounded env1266 := by
  intro p hp
  have h : env1266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1265_1266 : H12AffineEnvironment.transform 2 4 env1265 = env1266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1265 == env1266) = true)

theorem identity1266 : scanCanonicalize (H12AffineFastState.compose env1266 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1266 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1267 : List Nat := [2,4,4,16,16,0,20,21,23,21,0,1,21,1,17,3,16,16,20,17,17,17,16,19,5,1,1,0,16,17,20,1,20,1,0,23]

theorem envBound1267 : H12AffineFastState.Bounded env1267 := by
  intro p hp
  have h : env1267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1266_1267 : H12AffineEnvironment.transform 8 23 env1266 = env1267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1266 == env1267) = true)

def leafEnv1267 : List Nat := [2,4,4,16,16,0,20,21,23,21,0,1,21,1,17,3,16,16,20,17,17,17,16,19,20,5,1,1,1,0,16,17,20,1,20,1,4,18,0,23,1,16,0]

def active1267 : List Nat := [0,1,3]

def tree1267 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1267 : H12WitnessSearch.Good tree1267 := H12GlobalWitnessIndex.good

theorem leafIdentity1267 : H12AffineFastState.composeSystem env1267 rootObs = leafEnv1267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1267 rootObs == leafEnv1267) = true)

theorem terminalChecked1267 : H12PackedTerminal.terminalCheckFast leafEnv1267 active1267 tree1267 = true := by decide +kernel

def env1268 : List Nat := [2,4,5,16,16,1,21,20,512,20,0,0,515,535,518,532,519,16,21,518,17,17,16,19,531,0,1,534,16,17,21,1,21,1,534,512]

theorem envBound1268 : H12AffineFastState.Bounded env1268 := by
  intro p hp
  have h : env1268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1265_1268 : H12AffineEnvironment.transform 2 5 env1265 = env1268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1265 == env1268) = true)

def leafEnv1268 : List Nat := [2,4,5,16,16,1,21,20,512,20,0,0,515,535,518,532,519,16,21,518,17,17,16,19,21,531,1,0,1,534,16,17,21,1,21,1,4,517,534,512,1,16,0]

def active1268 : List Nat := [0,1,3,8]

def tree1268 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1268 : H12WitnessSearch.Good tree1268 := H12GlobalWitnessIndex.good

theorem leafIdentity1268 : H12AffineFastState.composeSystem env1268 rootObs = leafEnv1268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1268 rootObs == leafEnv1268) = true)

theorem terminalChecked1268 : H12PackedTerminal.terminalCheckFast leafEnv1268 active1268 tree1268 = true := by decide +kernel

def env1269 : List Nat := [2,4,8,16,16,64,24,85,512,85,1,65,579,539,587,601,586,17,84,587,17,17,16,19,595,65,0,538,16,16,84,1,84,1,538,512]

theorem envBound1269 : H12AffineFastState.Bounded env1269 := by
  intro p hp
  have h : env1269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1263_1269 : H12AffineEnvironment.transform 10 1 env1263 = env1269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1263 == env1269) = true)

theorem identity1269 : scanCanonicalize (H12AffineFastState.compose env1269 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound1269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1270 : List Nat := [2,4,8,16,16,29,24,8,512,8,1,28,542,539,534,516,535,17,9,534,17,17,16,19,526,28,0,538,16,16,9,1,9,1,538,512]

theorem envBound1270 : H12AffineFastState.Bounded env1270 := by
  intro p hp
  have h : env1270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1269_1270 : H12AffineEnvironment.transform 5 29 env1269 = env1270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env1269 == env1270) = true)

def env1271 : List Nat := [2,4,8,12,12,1,4,8,512,8,1,0,514,519,522,516,523,13,9,522,13,13,12,15,526,0,0,518,12,12,9,1,9,1,518,512]

theorem envBound1271 : H12AffineFastState.Bounded env1271 := by
  intro p hp
  have h : env1271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1270_1271 : H12AffineEnvironment.transform 3 12 env1270 = env1271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1270 == env1271) = true)

theorem identity1271 : scanCanonicalize (H12AffineFastState.compose env1271 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1271 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1272 : List Nat := [2,4,8,12,12,1,4,8,6,8,1,0,4,1,12,2,13,13,9,12,13,13,12,15,8,0,0,0,12,12,9,1,9,1,0,6]

theorem envBound1272 : H12AffineFastState.Bounded env1272 := by
  intro p hp
  have h : env1272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1271_1272 : H12AffineEnvironment.transform 8 6 env1271 = env1272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1271 == env1272) = true)

def leafEnv1272 : List Nat := [2,4,8,12,12,1,4,8,6,8,1,0,4,1,12,2,13,13,9,12,13,13,12,15,9,8,1,0,0,0,12,12,9,1,9,1,4,15,0,6,1,12,0]

def active1272 : List Nat := [0,1,2]

def tree1272 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1272 : H12WitnessSearch.Good tree1272 := H12GlobalWitnessIndex.good

theorem leafIdentity1272 : H12AffineFastState.composeSystem env1272 rootObs = leafEnv1272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1272 rootObs == leafEnv1272) = true)

theorem terminalChecked1272 : H12PackedTerminal.terminalCheckFast leafEnv1272 active1272 tree1272 = true := by decide +kernel

def env1273 : List Nat := [2,4,8,13,13,0,5,8,512,8,1,1,515,518,523,516,522,12,9,523,12,12,13,14,526,1,0,519,13,13,9,1,9,1,519,512]

theorem envBound1273 : H12AffineFastState.Bounded env1273 := by
  intro p hp
  have h : env1273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1270_1273 : H12AffineEnvironment.transform 3 13 env1270 = env1273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1270 == env1273) = true)

def leafEnv1273 : List Nat := [2,4,8,13,13,0,5,8,512,8,1,1,515,518,523,516,522,12,9,523,12,12,13,14,9,526,1,1,0,519,13,13,9,1,9,1,4,520,519,512,1,13,0]

def active1273 : List Nat := [0,1,2,8]

def tree1273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1273 : H12WitnessSearch.Good tree1273 := H12GlobalWitnessIndex.good

theorem leafIdentity1273 : H12AffineFastState.composeSystem env1273 rootObs = leafEnv1273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1273 rootObs == leafEnv1273) = true)

theorem terminalChecked1273 : H12PackedTerminal.terminalCheckFast leafEnv1273 active1273 tree1273 = true := by decide +kernel

def env1274 : List Nat := [2,4,8,16,17,64,25,85,512,85,2048,65,2626,2586,2634,2649,2635,2065,84,2634,17,16,16,18,2643,65,2049,2587,16,2064,84,1,84,1,2587,512]

theorem envBound1274 : H12AffineFastState.Bounded env1274 := by
  intro p hp
  have h : env1274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1262_1274 : H12AffineEnvironment.transform 4 17 env1262 = env1274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1262 == env1274) = true)

def env1275 : List Nat := [2,4,8,16,17,64,25,85,512,85,0,65,578,538,586,601,587,17,84,586,17,16,16,18,595,65,1,539,16,16,84,1,84,1,539,512]

theorem envBound1275 : H12AffineFastState.Bounded env1275 := by
  intro p hp
  have h : env1275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1274_1275 : H12AffineEnvironment.transform 10 0 env1274 = env1275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1274 == env1275) = true)

theorem identity1275 : scanCanonicalize (H12AffineFastState.compose env1275 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1276 : List Nat := [2,4,8,16,17,64,25,85,6,85,0,65,68,28,76,95,77,17,84,76,17,16,16,18,85,65,1,29,16,16,84,1,84,1,29,6]

theorem envBound1276 : H12AffineFastState.Bounded env1276 := by
  intro p hp
  have h : env1276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1275_1276 : H12AffineEnvironment.transform 8 6 env1275 = env1276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1275 == env1276) = true)

def env1277 : List Nat := [2,4,8,16,17,0,25,21,6,21,0,1,4,28,12,31,13,17,20,12,17,16,16,18,21,1,1,29,16,16,20,1,20,1,29,6]

theorem envBound1277 : H12AffineFastState.Bounded env1277 := by
  intro p hp
  have h : env1277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1276_1277 : H12AffineEnvironment.transform 5 0 env1276 = env1277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1276 == env1277) = true)

theorem identity1277 : scanCanonicalize (H12AffineFastState.compose env1277 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1277 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1278 : List Nat := [2,4,8,12,13,0,5,9,6,9,0,1,4,0,12,3,13,13,8,12,13,12,12,14,9,1,1,1,12,12,8,1,8,1,1,6]

theorem envBound1278 : H12AffineFastState.Bounded env1278 := by
  intro p hp
  have h : env1278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1277_1278 : H12AffineEnvironment.transform 3 12 env1277 = env1278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1277 == env1278) = true)

def leafEnv1278 : List Nat := [2,4,8,12,13,0,5,9,6,9,0,1,4,0,12,3,13,13,8,12,13,12,12,14,8,9,1,1,1,1,12,12,8,1,8,1,4,15,1,6,1,12,0]

def active1278 : List Nat := [0,1,2]

def tree1278 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1278 : H12WitnessSearch.Good tree1278 := H12GlobalWitnessIndex.good

theorem leafIdentity1278 : H12AffineFastState.composeSystem env1278 rootObs = leafEnv1278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1278 rootObs == leafEnv1278) = true)

theorem terminalChecked1278 : H12PackedTerminal.terminalCheckFast leafEnv1278 active1278 tree1278 = true := by decide +kernel

def env1279 : List Nat := [2,4,8,16,17,1,25,20,6,20,0,0,5,28,13,30,12,17,21,13,17,16,16,18,20,0,1,29,16,16,21,1,21,1,29,6]

theorem envBound1279 : H12AffineFastState.Bounded env1279 := by
  intro p hp
  have h : env1279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1276_1279 : H12AffineEnvironment.transform 5 1 env1276 = env1279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1276 == env1279) = true)

def leafEnv1279 : List Nat := [2,4,8,16,17,1,25,20,6,20,0,0,5,28,13,30,12,17,21,13,17,16,16,18,21,20,1,0,1,29,16,16,21,1,21,1,4,14,29,6,1,16,0]

def active1279 : List Nat := [0,1,2,3]

def tree1279 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1279 : H12WitnessSearch.Good tree1279 := H12GlobalWitnessIndex.good

theorem leafIdentity1279 : H12AffineFastState.composeSystem env1279 rootObs = leafEnv1279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1279 rootObs == leafEnv1279) = true)

theorem terminalChecked1279 : H12PackedTerminal.terminalCheckFast leafEnv1279 active1279 tree1279 = true := by decide +kernel

def env1280 : List Nat := [2,4,8,16,17,64,25,85,512,85,1,65,579,539,587,600,586,16,84,587,17,16,16,18,594,65,0,538,16,17,84,1,84,1,538,512]

theorem envBound1280 : H12AffineFastState.Bounded env1280 := by
  intro p hp
  have h : env1280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1274_1280 : H12AffineEnvironment.transform 10 1 env1274 = env1280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1274 == env1280) = true)

theorem identity1280 : scanCanonicalize (H12AffineFastState.compose env1280 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1280 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1281 : List Nat := [2,4,8,16,17,64,25,85,23,85,1,65,84,12,92,79,93,16,84,92,17,16,16,18,69,65,0,13,16,17,84,1,84,1,13,23]

theorem envBound1281 : H12AffineFastState.Bounded env1281 := by
  intro p hp
  have h : env1281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1280_1281 : H12AffineEnvironment.transform 8 23 env1280 = env1281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1280 == env1281) = true)

def env1282 : List Nat := [2,4,8,16,17,0,25,21,23,21,1,1,20,12,28,15,29,16,20,28,17,16,16,18,5,1,0,13,16,17,20,1,20,1,13,23]

theorem envBound1282 : H12AffineFastState.Bounded env1282 := by
  intro p hp
  have h : env1282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1281_1282 : H12AffineEnvironment.transform 5 0 env1281 = env1282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1281 == env1282) = true)

def leafEnv1282 : List Nat := [2,4,8,16,17,0,25,21,23,21,1,1,20,12,28,15,29,16,20,28,17,16,16,18,20,5,1,1,0,13,16,17,20,1,20,1,4,31,13,23,1,16,0]

def active1282 : List Nat := [0,1,2,3]

def tree1282 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1282 : H12WitnessSearch.Good tree1282 := H12GlobalWitnessIndex.good

theorem leafIdentity1282 : H12AffineFastState.composeSystem env1282 rootObs = leafEnv1282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1282 rootObs == leafEnv1282) = true)

theorem terminalChecked1282 : H12PackedTerminal.terminalCheckFast leafEnv1282 active1282 tree1282 = true := by decide +kernel

def env1283 : List Nat := [2,4,8,16,17,1,25,20,23,20,1,0,21,12,29,14,28,16,21,29,17,16,16,18,4,0,0,13,16,17,21,1,21,1,13,23]

theorem envBound1283 : H12AffineFastState.Bounded env1283 := by
  intro p hp
  have h : env1283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1281_1283 : H12AffineEnvironment.transform 5 1 env1281 = env1283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1281 == env1283) = true)

theorem identity1283 : scanCanonicalize (H12AffineFastState.compose env1283 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1283 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1284 : List Nat := [2,4,4,16,17,1,21,20,23,20,1,0,21,0,17,2,16,16,21,17,17,16,16,18,4,0,0,1,16,17,21,1,21,1,1,23]

theorem envBound1284 : H12AffineFastState.Bounded env1284 := by
  intro p hp
  have h : env1284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1283_1284 : H12AffineEnvironment.transform 2 4 env1283 = env1284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1283 == env1284) = true)

def leafEnv1284 : List Nat := [2,4,4,16,17,1,21,20,23,20,1,0,21,0,17,2,16,16,21,17,17,16,16,18,21,4,1,0,0,1,16,17,21,1,21,1,4,18,1,23,1,16,0]

def active1284 : List Nat := [0,1,3]

def tree1284 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1284 : H12WitnessSearch.Good tree1284 := H12GlobalWitnessIndex.good

theorem leafIdentity1284 : H12AffineFastState.composeSystem env1284 rootObs = leafEnv1284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1284 rootObs == leafEnv1284) = true)

theorem terminalChecked1284 : H12PackedTerminal.terminalCheckFast leafEnv1284 active1284 tree1284 = true := by decide +kernel

def env1285 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,131072,205376,74883,8200,74951,73891,184,73737,8328,73835,131811,2586,134670,2081,74883,1,73854,1,131320,512]

theorem envBound1285 : H12AffineFastState.Bounded env1285 := by
  intro p hp
  have h : env1285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1254_1285 : H12AffineEnvironment.transform 11 1045 env1254 = env1285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1254 == env1285) = true)

def env1286 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76384,2080,74883,8200,74951,73891,184,73737,8328,73835,75907,2586,74862,2081,74883,1,73854,1,76440,512]

theorem envBound1286 : H12AffineFastState.Bounded env1286 := by
  intro p hp
  have h : env1286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1285_1286 : H12AffineEnvironment.transform 16 76384 env1285 = env1286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1285 == env1286) = true)

theorem identity1286 : scanCanonicalize (H12AffineFastState.compose env1286 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1286 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1287 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,3733,9461,2080,10774,8200,10834,11830,184,11932,8328,12030,9750,2586,11003,2081,10774,1,12011,1,9229,512]

theorem envBound1287 : H12AffineFastState.Bounded env1287 := by
  intro p hp
  have h : env1287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1286_1287 : H12AffineEnvironment.transform 15 3733 env1286 = env1287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1286 == env1287) = true)

theorem identity1287 : scanCanonicalize (H12AffineFastState.compose env1287 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1287 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1288 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2587,3615,3733,2786,2080,1025,3615,1093,33,184,139,3743,233,2049,2586,1260,2081,1025,1,252,1,2586,512]

theorem envBound1288 : H12AffineFastState.Bounded env1288 := by
  intro p hp
  have h : env1288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1287_1288 : H12AffineEnvironment.transform 12 3607 env1287 = env1288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1287 == env1288) = true)

theorem identity1288 : scanCanonicalize (H12AffineFastState.compose env1288 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1288 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1289 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2626,2587,2634,2752,2786,2080,84,2634,16,33,184,139,2762,233,2049,2586,185,2081,84,1,252,1,2586,512]

theorem envBound1289 : H12AffineFastState.Bounded env1289 := by
  intro p hp
  have h : env1289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1288_1289 : H12AffineEnvironment.transform 9 85 env1288 = env1289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1288 == env1289) = true)

theorem identity1289 : scanCanonicalize (H12AffineFastState.compose env1289 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1289 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1290 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,64,2626,2587,2634,2664,2634,2080,84,2634,16,33,16,35,2658,65,2049,2586,17,2081,84,1,84,1,2586,512]

theorem envBound1290 : H12AffineFastState.Bounded env1290 := by
  intro p hp
  have h : env1290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1289_1290 : H12AffineEnvironment.transform 6 40 env1289 = env1290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1289 == env1290) = true)

def env1291 : List Nat := [2,4,8,16,16,64,24,85,512,85,2048,64,2626,2587,2634,2648,2634,2064,84,2634,16,17,16,19,2642,65,2049,2586,17,2065,84,1,84,1,2586,512]

theorem envBound1291 : H12AffineFastState.Bounded env1291 := by
  intro p hp
  have h : env1291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1290_1291 : H12AffineEnvironment.transform 4 16 env1290 = env1291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1290 == env1291) = true)

def env1292 : List Nat := [2,4,8,16,16,64,24,85,512,85,0,64,578,539,586,600,586,16,84,586,16,17,16,19,594,65,1,538,17,17,84,1,84,1,538,512]

theorem envBound1292 : H12AffineFastState.Bounded env1292 := by
  intro p hp
  have h : env1292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1291_1292 : H12AffineEnvironment.transform 10 0 env1291 = env1292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1291 == env1292) = true)

theorem identity1292 : scanCanonicalize (H12AffineFastState.compose env1292 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound1292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1293 : List Nat := [2,4,8,16,16,64,24,85,70,85,0,64,4,93,12,30,12,16,84,12,16,17,16,19,20,65,1,92,17,17,84,1,84,1,92,70]

theorem envBound1293 : H12AffineFastState.Bounded env1293 := by
  intro p hp
  have h : env1293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1292_1293 : H12AffineEnvironment.transform 8 70 env1292 = env1293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env1292 == env1293) = true)

def env1294 : List Nat := [2,4,8,16,16,0,24,21,6,21,0,0,4,29,12,30,12,16,20,12,16,17,16,19,20,1,1,28,17,17,20,1,20,1,28,6]

theorem envBound1294 : H12AffineFastState.Bounded env1294 := by
  intro p hp
  have h : env1294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1293_1294 : H12AffineEnvironment.transform 5 0 env1293 = env1294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1293 == env1294) = true)

def leafEnv1294 : List Nat := [2,4,8,16,16,0,24,21,6,21,0,0,4,29,12,30,12,16,20,12,16,17,16,19,20,20,1,1,1,28,17,17,20,1,20,1,4,15,28,6,1,17,0]

def active1294 : List Nat := [0,1,2,3]

def tree1294 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1294 : H12WitnessSearch.Good tree1294 := H12GlobalWitnessIndex.good

theorem leafIdentity1294 : H12AffineFastState.composeSystem env1294 rootObs = leafEnv1294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1294 rootObs == leafEnv1294) = true)

theorem terminalChecked1294 : H12PackedTerminal.terminalCheckFast leafEnv1294 active1294 tree1294 = true := by decide +kernel

def env1295 : List Nat := [2,4,8,16,16,1,24,20,7,20,0,1,4,28,12,30,12,16,21,12,16,17,16,19,20,0,1,29,17,17,21,1,21,1,29,7]

theorem envBound1295 : H12AffineFastState.Bounded env1295 := by
  intro p hp
  have h : env1295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1293_1295 : H12AffineEnvironment.transform 5 1 env1293 = env1295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1293 == env1295) = true)

theorem identity1295 : scanCanonicalize (H12AffineFastState.compose env1295 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1295 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1296 : List Nat := [2,4,8,12,12,1,4,8,7,8,0,1,4,0,12,2,12,12,9,12,12,13,12,15,8,0,1,1,13,13,9,1,9,1,1,7]

theorem envBound1296 : H12AffineFastState.Bounded env1296 := by
  intro p hp
  have h : env1296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1295_1296 : H12AffineEnvironment.transform 3 12 env1295 = env1296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1295 == env1296) = true)

def leafEnv1296 : List Nat := [2,4,8,12,12,1,4,8,7,8,0,1,4,0,12,2,12,12,9,12,12,13,12,15,9,8,1,0,1,1,13,13,9,1,9,1,4,15,1,7,1,13,0]

def active1296 : List Nat := [0,1,2]

def tree1296 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1296 : H12WitnessSearch.Good tree1296 := H12GlobalWitnessIndex.good

theorem leafIdentity1296 : H12AffineFastState.composeSystem env1296 rootObs = leafEnv1296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1296 rootObs == leafEnv1296) = true)

theorem terminalChecked1296 : H12PackedTerminal.terminalCheckFast leafEnv1296 active1296 tree1296 = true := by decide +kernel

def env1297 : List Nat := [2,4,8,16,16,64,24,85,512,85,1,64,579,538,587,601,587,17,84,587,16,17,16,19,595,65,0,539,17,16,84,1,84,1,539,512]

theorem envBound1297 : H12AffineFastState.Bounded env1297 := by
  intro p hp
  have h : env1297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1291_1297 : H12AffineEnvironment.transform 10 1 env1291 = env1297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1291 == env1297) = true)

theorem identity1297 : scanCanonicalize (H12AffineFastState.compose env1297 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound1297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1298 : List Nat := [2,4,8,16,16,64,24,85,86,85,1,64,21,76,29,15,29,17,84,29,16,17,16,19,5,65,0,77,17,16,84,1,84,1,77,86]

theorem envBound1298 : H12AffineFastState.Bounded env1298 := by
  intro p hp
  have h : env1298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1297_1298 : H12AffineEnvironment.transform 8 86 env1297 = env1298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env1297 == env1298) = true)

def env1299 : List Nat := [2,4,8,16,16,0,24,21,22,21,1,0,21,12,29,15,29,17,20,29,16,17,16,19,5,1,0,13,17,16,20,1,20,1,13,22]

theorem envBound1299 : H12AffineFastState.Bounded env1299 := by
  intro p hp
  have h : env1299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1298_1299 : H12AffineEnvironment.transform 5 0 env1298 = env1299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1298 == env1299) = true)

theorem identity1299 : scanCanonicalize (H12AffineFastState.compose env1299 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1299 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1300 : List Nat := [2,4,4,16,16,0,20,21,22,21,1,0,21,0,17,3,17,17,20,17,16,17,16,19,5,1,0,1,17,16,20,1,20,1,1,22]

theorem envBound1300 : H12AffineFastState.Bounded env1300 := by
  intro p hp
  have h : env1300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1299_1300 : H12AffineEnvironment.transform 2 4 env1299 = env1300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1299 == env1300) = true)

def leafEnv1300 : List Nat := [2,4,4,16,16,0,20,21,22,21,1,0,21,0,17,3,17,17,20,17,16,17,16,19,20,5,1,1,0,1,17,16,20,1,20,1,4,18,1,22,1,17,0]

def active1300 : List Nat := [0,1,3]

def tree1300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1300 : H12WitnessSearch.Good tree1300 := H12GlobalWitnessIndex.good

theorem leafIdentity1300 : H12AffineFastState.composeSystem env1300 rootObs = leafEnv1300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1300 rootObs == leafEnv1300) = true)

theorem terminalChecked1300 : H12PackedTerminal.terminalCheckFast leafEnv1300 active1300 tree1300 = true := by decide +kernel

def env1301 : List Nat := [2,4,8,16,16,1,24,20,23,20,1,1,21,13,29,15,29,17,21,29,16,17,16,19,5,0,0,12,17,16,21,1,21,1,12,23]

theorem envBound1301 : H12AffineFastState.Bounded env1301 := by
  intro p hp
  have h : env1301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1298_1301 : H12AffineEnvironment.transform 5 1 env1298 = env1301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1298 == env1301) = true)

def leafEnv1301 : List Nat := [2,4,8,16,16,1,24,20,23,20,1,1,21,13,29,15,29,17,21,29,16,17,16,19,21,5,1,0,0,12,17,16,21,1,21,1,4,30,12,23,1,17,0]

def active1301 : List Nat := [0,1,2,3]

def tree1301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1301 : H12WitnessSearch.Good tree1301 := H12GlobalWitnessIndex.good

theorem leafIdentity1301 : H12AffineFastState.composeSystem env1301 rootObs = leafEnv1301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1301 rootObs == leafEnv1301) = true)

theorem terminalChecked1301 : H12PackedTerminal.terminalCheckFast leafEnv1301 active1301 tree1301 = true := by decide +kernel

def env1302 : List Nat := [2,4,8,16,17,64,25,85,512,85,2048,64,2626,2587,2634,2649,2634,2065,84,2634,16,16,16,18,2643,65,2049,2586,17,2064,84,1,84,1,2586,512]

theorem envBound1302 : H12AffineFastState.Bounded env1302 := by
  intro p hp
  have h : env1302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1290_1302 : H12AffineEnvironment.transform 4 17 env1290 = env1302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1290 == env1302) = true)

def env1303 : List Nat := [2,4,8,16,17,64,25,85,512,85,0,64,578,539,586,601,586,17,84,586,16,16,16,18,595,65,1,538,17,16,84,1,84,1,538,512]

theorem envBound1303 : H12AffineFastState.Bounded env1303 := by
  intro p hp
  have h : env1303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1302_1303 : H12AffineEnvironment.transform 10 0 env1302 = env1303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1302 == env1303) = true)

theorem identity1303 : scanCanonicalize (H12AffineFastState.compose env1303 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1303 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1304 : List Nat := [2,4,4,16,17,64,21,85,512,85,0,64,578,535,582,597,582,17,84,582,16,16,16,18,595,65,1,534,17,16,84,1,84,1,534,512]

theorem envBound1304 : H12AffineFastState.Bounded env1304 := by
  intro p hp
  have h : env1304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1303_1304 : H12AffineEnvironment.transform 2 4 env1303 = env1304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1303 == env1304) = true)

def env1305 : List Nat := [2,4,4,16,17,0,21,21,512,21,0,0,514,535,518,533,518,17,20,518,16,16,16,18,531,1,1,534,17,16,20,1,20,1,534,512]

theorem envBound1305 : H12AffineFastState.Bounded env1305 := by
  intro p hp
  have h : env1305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1304_1305 : H12AffineEnvironment.transform 5 0 env1304 = env1305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1304 == env1305) = true)

def leafEnv1305 : List Nat := [2,4,4,16,17,0,21,21,512,21,0,0,514,535,518,533,518,17,20,518,16,16,16,18,20,531,1,1,1,534,17,16,20,1,20,1,4,517,534,512,1,17,0]

def active1305 : List Nat := [0,1,3,8]

def tree1305 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1305 : H12WitnessSearch.Good tree1305 := H12GlobalWitnessIndex.good

theorem leafIdentity1305 : H12AffineFastState.composeSystem env1305 rootObs = leafEnv1305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1305 rootObs == leafEnv1305) = true)

theorem terminalChecked1305 : H12PackedTerminal.terminalCheckFast leafEnv1305 active1305 tree1305 = true := by decide +kernel

def env1306 : List Nat := [2,4,4,16,17,1,21,20,512,20,0,1,515,535,519,532,519,17,21,519,16,16,16,18,530,0,1,534,17,16,21,1,21,1,534,512]

theorem envBound1306 : H12AffineFastState.Bounded env1306 := by
  intro p hp
  have h : env1306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1304_1306 : H12AffineEnvironment.transform 5 1 env1304 = env1306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1304 == env1306) = true)

theorem identity1306 : scanCanonicalize (H12AffineFastState.compose env1306 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1307 : List Nat := [2,4,4,16,17,1,21,20,22,20,0,1,21,1,17,2,17,17,21,17,16,16,16,18,4,0,1,0,17,16,21,1,21,1,0,22]

theorem envBound1307 : H12AffineFastState.Bounded env1307 := by
  intro p hp
  have h : env1307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1306_1307 : H12AffineEnvironment.transform 8 22 env1306 = env1307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1306 == env1307) = true)

def leafEnv1307 : List Nat := [2,4,4,16,17,1,21,20,22,20,0,1,21,1,17,2,17,17,21,17,16,16,16,18,21,4,1,0,1,0,17,16,21,1,21,1,4,18,0,22,1,17,0]

def active1307 : List Nat := [0,1,3]

def tree1307 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1307 : H12WitnessSearch.Good tree1307 := H12GlobalWitnessIndex.good

theorem leafIdentity1307 : H12AffineFastState.composeSystem env1307 rootObs = leafEnv1307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1307 rootObs == leafEnv1307) = true)

theorem terminalChecked1307 : H12PackedTerminal.terminalCheckFast leafEnv1307 active1307 tree1307 = true := by decide +kernel

def env1308 : List Nat := [2,4,8,16,17,64,25,85,512,85,1,64,579,538,587,600,587,16,84,587,16,16,16,18,594,65,0,539,17,17,84,1,84,1,539,512]

theorem envBound1308 : H12AffineFastState.Bounded env1308 := by
  intro p hp
  have h : env1308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1302_1308 : H12AffineEnvironment.transform 10 1 env1302 = env1308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1302 == env1308) = true)

theorem identity1308 : scanCanonicalize (H12AffineFastState.compose env1308 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1308 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1309 : List Nat := [2,4,8,12,13,64,5,73,512,73,1,64,579,518,587,580,587,12,72,587,12,12,12,14,590,65,0,519,13,13,72,1,72,1,519,512]

theorem envBound1309 : H12AffineFastState.Bounded env1309 := by
  intro p hp
  have h : env1309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1308_1309 : H12AffineEnvironment.transform 3 12 env1308 = env1309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1308 == env1309) = true)

def env1310 : List Nat := [2,4,8,12,13,0,5,9,512,9,1,0,515,518,523,516,523,12,8,523,12,12,12,14,526,1,0,519,13,13,8,1,8,1,519,512]

theorem envBound1310 : H12AffineFastState.Bounded env1310 := by
  intro p hp
  have h : env1310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1309_1310 : H12AffineEnvironment.transform 5 0 env1309 = env1310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1309 == env1310) = true)

theorem identity1310 : scanCanonicalize (H12AffineFastState.compose env1310 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1311 : List Nat := [2,4,8,12,13,0,5,9,7,9,1,0,4,1,12,3,12,12,8,12,12,12,12,14,9,1,0,0,13,13,8,1,8,1,0,7]

theorem envBound1311 : H12AffineFastState.Bounded env1311 := by
  intro p hp
  have h : env1311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1310_1311 : H12AffineEnvironment.transform 8 7 env1310 = env1311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1310 == env1311) = true)

def leafEnv1311 : List Nat := [2,4,8,12,13,0,5,9,7,9,1,0,4,1,12,3,12,12,8,12,12,12,12,14,8,9,1,1,0,0,13,13,8,1,8,1,4,15,0,7,1,13,0]

def active1311 : List Nat := [0,1,2]

def tree1311 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1311 : H12WitnessSearch.Good tree1311 := H12GlobalWitnessIndex.good

theorem leafIdentity1311 : H12AffineFastState.composeSystem env1311 rootObs = leafEnv1311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1311 rootObs == leafEnv1311) = true)

theorem terminalChecked1311 : H12PackedTerminal.terminalCheckFast leafEnv1311 active1311 tree1311 = true := by decide +kernel

def env1312 : List Nat := [2,4,8,12,13,1,5,8,512,8,1,1,514,518,522,517,522,12,9,522,12,12,12,14,527,0,0,519,13,13,9,1,9,1,519,512]

theorem envBound1312 : H12AffineFastState.Bounded env1312 := by
  intro p hp
  have h : env1312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1309_1312 : H12AffineEnvironment.transform 5 1 env1309 = env1312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1309 == env1312) = true)

def leafEnv1312 : List Nat := [2,4,8,12,13,1,5,8,512,8,1,1,514,518,522,517,522,12,9,522,12,12,12,14,9,527,1,0,0,519,13,13,9,1,9,1,4,521,519,512,1,13,0]

def active1312 : List Nat := [0,1,2,8]

def tree1312 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1312 : H12WitnessSearch.Good tree1312 := H12GlobalWitnessIndex.good

theorem leafIdentity1312 : H12AffineFastState.composeSystem env1312 rootObs = leafEnv1312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1312 rootObs == leafEnv1312) = true)

theorem terminalChecked1312 : H12PackedTerminal.terminalCheckFast leafEnv1312 active1312 tree1312 = true := by decide +kernel

def env1313 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76385,2081,74883,8200,74951,73891,184,73737,8328,73835,75906,2586,74863,2081,74883,1,73854,1,76441,512]

theorem envBound1313 : H12AffineFastState.Bounded env1313 := by
  intro p hp
  have h : env1313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1285_1313 : H12AffineEnvironment.transform 16 76385 env1285 = env1313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1285 == env1313) = true)

theorem identity1313 : scanCanonicalize (H12AffineFastState.compose env1313 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 224) := by decide +kernel

theorem selectedBound1313 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1314 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,224,2587,232,65536,68225,2081,66659,232,66599,65603,184,65769,104,65675,67682,2586,66703,2081,66659,1,65694,1,68217,512]

theorem envBound1314 : H12AffineFastState.Bounded env1314 := by
  intro p hp
  have h : env1314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1313_1314 : H12AffineEnvironment.transform 12 224 env1313 = env1314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env1313 == env1314) = true)

def env1315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,185,74229,8328,74135,336223,16385,151552,2081,75135,0,73854,1,131333,512]

theorem envBound1315 : H12AffineFastState.Bounded env1315 := by
  intro p hp
  have h : env1315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1238_1315 : H12AffineEnvironment.transform 22 185 env1238 = env1315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1238 == env1315) = true)

theorem identity1315 : scanCanonicalize (H12AffineFastState.compose env1315 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1315 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1316 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,74883,8200,2097152,73891,185,73736,8328,73834,336034,16385,151552,2081,74882,0,73854,1,131320,512]

theorem envBound1316 : H12AffineFastState.Bounded env1316 := by
  intro p hp
  have h : env1316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1315_1316 : H12AffineEnvironment.transform 7 253 env1315 = env1316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1315 == env1316) = true)

def env1317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,268435456,268570625,268453920,17399808,281601389,525568,268451840,34359738368,25733063]

theorem envBound1317 : H12AffineFastState.Bounded env1317 := by
  intro p hp
  have h : env1317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans781_1317 : H12AffineEnvironment.transform 25 8914001 env781 = env1317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env781 == env1317) = true)

def env1318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2080,17399808,13149549,525568,0,34359738368,25733063]

theorem envBound1318 : H12AffineFastState.Bounded env1318 := by
  intro p hp
  have h : env1318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1317_1318 : H12AffineEnvironment.transform 27 16384 env1317 = env1318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env1317 == env1318) = true)

def env1319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2080,17375732,13108377,525568,0,34359738368,25691699]

theorem envBound1319 : H12AffineFastState.Bounded env1319 := by
  intro p hp
  have h : env1319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1318_1319 : H12AffineEnvironment.transform 14 8692 env1318 = env1319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env1318 == env1319) = true)

theorem identity1319 : scanCanonicalize (H12AffineFastState.compose env1319 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound1319 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913971,8328,8914001,9176216,16384,151553,2080,8463815,13108377,525568,0,34359738368,512]

theorem envBound1320 : H12AffineFastState.Bounded env1320 := by
  intro p hp
  have h : env1320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1319_1320 : H12AffineEnvironment.transform 23 8913971 env1319 = env1320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env1319 == env1320) = true)

theorem identity1320 : scanCanonicalize (H12AffineFastState.compose env1320 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525345) := by decide +kernel

theorem selectedBound1320 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525345,8388608,8913971,8328,8914001,9176216,16384,151553,2080,8463815,8388792,525568,0,34359738368,512]

theorem envBound1321 : H12AffineFastState.Bounded env1321 := by
  intro p hp
  have h : env1321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1320_1321 : H12AffineEnvironment.transform 21 525345 env1320 = env1321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525345 env1320 == env1321) = true)

theorem identity1321 : scanCanonicalize (H12AffineFastState.compose env1321 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75135) := by decide +kernel

theorem selectedBound1321 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,8388608,8462668,8328,8462638,8724967,16384,151553,2080,8463815,8388792,73855,0,34359738368,512]

theorem envBound1322 : H12AffineFastState.Bounded env1322 := by
  intro p hp
  have h : env1322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1321_1322 : H12AffineEnvironment.transform 18 75135 env1321 = env1322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75135 env1321 == env1322) = true)

theorem identity1322 : scanCanonicalize (H12AffineFastState.compose env1322 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound1322 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,8388608,8462668,8328,8462638,8724967,16384,151553,2080,8463815,8388792,73855,0,131332,512]

theorem envBound1323 : H12AffineFastState.Bounded env1323 := by
  intro p hp
  have h : env1323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1322_1323 : H12AffineEnvironment.transform 34 131332 env1322 = env1323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env1322 == env1323) = true)

def env1324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,184,74228,8328,74134,336223,16384,151553,2080,75135,0,73855,0,131332,512]

theorem envBound1324 : H12AffineFastState.Bounded env1324 := by
  intro p hp
  have h : env1324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1323_1324 : H12AffineEnvironment.transform 22 184 env1323 = env1324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1323 == env1324) = true)

theorem identity1324 : scanCanonicalize (H12AffineFastState.compose env1324 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound1324 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223323,75135,8692,2097152,74078,184,74228,8328,74134,149764,16384,151553,2080,75135,0,73855,0,131332,512]

theorem envBound1325 : H12AffineFastState.Bounded env1325 := by
  intro p hp
  have h : env1325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1324_1325 : H12AffineEnvironment.transform 17 223323 env1324 = env1325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env1324 == env1325) = true)

def env1326 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,2097152,73890,184,73736,8328,73834,149752,16384,151553,2080,74883,0,73855,0,131320,512]

theorem envBound1326 : H12AffineFastState.Bounded env1326 := by
  intro p hp
  have h : env1326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1325_1326 : H12AffineEnvironment.transform 7 252 env1325 = env1326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1325 == env1326) = true)

theorem identity1326 : scanCanonicalize (H12AffineFastState.compose env1326 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151552) := by decide +kernel

theorem selectedBound1326 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1327 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74883,8200,151552,73890,184,73736,8328,73834,149752,16384,151553,2080,74883,0,73855,0,131320,512]

theorem envBound1327 : H12AffineFastState.Bounded env1327 := by
  intro p hp
  have h : env1327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1326_1327 : H12AffineEnvironment.transform 20 151552 env1326 = env1327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151552 env1326 == env1327) = true)

theorem identity1327 : scanCanonicalize (H12AffineFastState.compose env1327 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound1327 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1328 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90235,2080,74883,8200,77947,73890,184,73736,8328,73834,75907,16384,77946,2080,74883,0,73855,0,90243,512]

theorem envBound1328 : H12AffineFastState.Bounded env1328 := by
  intro p hp
  have h : env1328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1327_1328 : H12AffineEnvironment.transform 16 90235 env1327 = env1328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env1327 == env1328) = true)

theorem identity1328 : scanCanonicalize (H12AffineFastState.compose env1328 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1328 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1329 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16632,2080,1024,8200,4344,33,184,139,8328,233,2048,16384,4345,2080,1024,0,252,0,16384,512]

theorem envBound1329 : H12AffineFastState.Bounded env1329 := by
  intro p hp
  have h : env1329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1328_1329 : H12AffineEnvironment.transform 15 8323 env1328 = env1329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1328 == env1329) = true)

theorem identity1329 : scanCanonicalize (H12AffineFastState.compose env1329 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound1329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1330 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8200,8323,5260,2080,1024,8200,4344,33,184,139,8328,233,2048,5236,4345,2080,1024,0,252,0,5236,512]

theorem envBound1330 : H12AffineFastState.Bounded env1330 := by
  intro p hp
  have h : env1330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1329_1330 : H12AffineEnvironment.transform 13 5236 env1329 = env1330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env1329 == env1330) = true)

theorem identity1330 : scanCanonicalize (H12AffineFastState.compose env1330 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound1330 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1331 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,8192,602,8200,8323,674,2080,1024,8200,1750,33,184,139,8328,233,2048,602,1751,2080,1024,0,252,0,602,512]

theorem envBound1331 : H12AffineFastState.Bounded env1331 := by
  intro p hp
  have h : env1331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1330_1331 : H12AffineEnvironment.transform 11 1582 env1330 = env1331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env1330 == env1331) = true)

theorem identity1331 : scanCanonicalize (H12AffineFastState.compose env1331 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3823) := by decide +kernel

theorem selectedBound1331 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1332 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,3823,602,3815,3692,674,2080,1024,3815,1750,33,184,139,3687,233,2048,602,1751,2080,1024,0,252,0,602,512]

theorem envBound1332 : H12AffineFastState.Bounded env1332 := by
  intro p hp
  have h : env1332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1331_1332 : H12AffineEnvironment.transform 12 3823 env1331 = env1332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3823 env1331 == env1332) = true)

theorem identity1332 : scanCanonicalize (H12AffineFastState.compose env1332 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound1332 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1333 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,555,2794,602,2786,2665,674,2080,5,2786,723,33,184,139,2658,233,2048,602,722,2080,5,0,252,0,602,512]

theorem envBound1333 : H12AffineFastState.Bounded env1333 := by
  intro p hp
  have h : env1333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1332_1333 : H12AffineEnvironment.transform 9 5 env1332 = env1333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env1332 == env1333) = true)

theorem identity1333 : scanCanonicalize (H12AffineFastState.compose env1333 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1333 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1334 : List Nat := [2,4,8,16,32,64,121,5,512,5,2048,555,2579,602,2587,2665,603,2080,5,2587,554,33,65,114,2658,16,2048,602,555,2080,5,0,5,0,602,512]

theorem envBound1334 : H12AffineFastState.Bounded env1334 := by
  intro p hp
  have h : env1334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1333_1334 : H12AffineEnvironment.transform 6 121 env1333 = env1334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1333 == env1334) = true)

theorem identity1334 : scanCanonicalize (H12AffineFastState.compose env1334 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound1334 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1335 : List Nat := [2,4,8,16,32,64,121,5,512,5,609,555,114,602,122,8,603,577,5,122,554,33,65,114,3,16,609,602,555,577,5,0,5,0,602,512]

theorem envBound1335 : H12AffineFastState.Bounded env1335 := by
  intro p hp
  have h : env1335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1334_1335 : H12AffineEnvironment.transform 10 609 env1334 = env1335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env1334 == env1335) = true)

theorem identity1335 : scanCanonicalize (H12AffineFastState.compose env1335 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound1335 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1336 : List Nat := [2,4,8,16,27,64,66,5,512,5,602,528,73,602,65,8,603,577,5,65,529,26,65,73,3,16,602,602,528,577,5,0,5,0,602,512]

theorem envBound1336 : H12AffineFastState.Bounded env1336 := by
  intro p hp
  have h : env1336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1335_1336 : H12AffineEnvironment.transform 4 27 env1335 = env1336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env1335 == env1336) = true)

def env1337 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,2097152,73891,184,73737,8328,73835,149753,16384,151553,2080,74882,0,73855,0,131321,512]

theorem envBound1337 : H12AffineFastState.Bounded env1337 := by
  intro p hp
  have h : env1337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1325_1337 : H12AffineEnvironment.transform 7 253 env1325 = env1337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1325 == env1337) = true)

theorem identity1337 : scanCanonicalize (H12AffineFastState.compose env1337 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound1337 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1338 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74882,8201,78035,73891,184,73737,8328,73835,149753,16384,151553,2080,74882,0,73855,0,131321,512]

theorem envBound1338 : H12AffineFastState.Bounded env1338 := by
  intro p hp
  have h : env1338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1337_1338 : H12AffineEnvironment.transform 20 78035 env1337 = env1338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env1337 == env1338) = true)

theorem identity1338 : scanCanonicalize (H12AffineFastState.compose env1338 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound1338 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1339 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210516,74882,8201,78035,73891,184,73737,8328,73835,136950,7695,134670,2080,74882,0,73855,0,131321,512]

theorem envBound1339 : H12AffineFastState.Bounded env1339 := by
  intro p hp
  have h : env1339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1338_1339 : H12AffineEnvironment.transform 13 7695 env1338 = env1339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env1338 == env1339) = true)

def env1340 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205376,74882,8201,74951,73891,184,73737,8328,73835,131810,2587,134670,2080,74882,0,73855,0,131321,512]

theorem envBound1340 : H12AffineFastState.Bounded env1340 := by
  intro p hp
  have h : env1340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1339_1340 : H12AffineEnvironment.transform 11 1044 env1339 = env1340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1339 == env1340) = true)

def env1341 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2080,74882,8201,74951,73891,184,73737,8328,73835,75906,2587,74862,2080,74882,0,73855,0,76441,512]

theorem envBound1341 : H12AffineFastState.Bounded env1341 := by
  intro p hp
  have h : env1341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1340_1341 : H12AffineEnvironment.transform 16 76384 env1340 = env1341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1340 == env1341) = true)

theorem identity1341 : scanCanonicalize (H12AffineFastState.compose env1341 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound1341 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1342 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,99,10755,2080,9441,8201,9380,8384,184,8298,8328,8200,10465,2587,9229,2080,9441,0,8220,0,11002,512]

theorem envBound1342 : H12AffineFastState.Bounded env1342 := by
  intro p hp
  have h : env1342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1341_1342 : H12AffineEnvironment.transform 15 99 env1341 = env1342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env1341 == env1342) = true)

def env1343 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2081,74882,8201,74951,73891,184,73737,8328,73835,75907,2587,74863,2080,74882,0,73855,0,76440,512]

theorem envBound1343 : H12AffineFastState.Bounded env1343 := by
  intro p hp
  have h : env1343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1340_1343 : H12AffineEnvironment.transform 16 76385 env1340 = env1343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1340 == env1343) = true)

theorem identity1343 : scanCanonicalize (H12AffineFastState.compose env1343 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1343 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1344 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2587,3614,65536,66678,2081,68245,3614,68304,69300,184,69150,3743,69244,67220,2587,68216,2080,68245,0,69224,0,66703,512]

theorem envBound1344 : H12AffineFastState.Bounded env1344 := by
  intro p hp
  have h : env1344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1343_1344 : H12AffineEnvironment.transform 12 3607 env1343 = env1344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1343 == env1344) = true)

theorem identity1344 : scanCanonicalize (H12AffineFastState.compose env1344 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1344 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1345 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2587,3614,3733,2787,2081,1024,3614,1093,33,184,139,3743,233,2049,2587,1261,2080,1024,0,253,0,2586,512]

theorem envBound1345 : H12AffineFastState.Bounded env1345 := by
  intro p hp
  have h : env1345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1344_1345 : H12AffineEnvironment.transform 15 3733 env1344 = env1345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1344 == env1345) = true)

theorem identity1345 : scanCanonicalize (H12AffineFastState.compose env1345 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1345 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1346 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2626,2587,2635,2752,2787,2081,85,2635,16,33,184,139,2762,233,2049,2587,184,2080,85,0,253,0,2586,512]

theorem envBound1346 : H12AffineFastState.Bounded env1346 := by
  intro p hp
  have h : env1346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1345_1346 : H12AffineEnvironment.transform 9 85 env1345 = env1346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1345 == env1346) = true)

theorem identity1346 : scanCanonicalize (H12AffineFastState.compose env1346 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1346 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1347 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,65,2626,2587,2635,2665,2634,2081,85,2635,16,33,17,34,2659,64,2049,2587,17,2080,85,0,84,0,2586,512]

theorem envBound1347 : H12AffineFastState.Bounded env1347 := by
  intro p hp
  have h : env1347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1346_1347 : H12AffineEnvironment.transform 6 41 env1346 = env1347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1346 == env1347) = true)

def env1348 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,65,2626,2587,2635,2649,2634,2065,85,2635,16,17,17,18,2643,64,2049,2587,17,2064,85,0,84,0,2586,512]

theorem envBound1348 : H12AffineFastState.Bounded env1348 := by
  intro p hp
  have h : env1348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1347_1348 : H12AffineEnvironment.transform 4 16 env1347 = env1348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1347 == env1348) = true)

def env1349 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,65,578,539,587,601,586,17,85,587,16,17,17,18,595,64,1,539,17,16,85,0,84,0,538,512]

theorem envBound1349 : H12AffineFastState.Bounded env1349 := by
  intro p hp
  have h : env1349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1348_1349 : H12AffineEnvironment.transform 10 0 env1348 = env1349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1348 == env1349) = true)

theorem identity1349 : scanCanonicalize (H12AffineFastState.compose env1349 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1350 : List Nat := [2,4,8,12,12,64,5,72,512,73,0,65,578,519,587,581,586,13,73,587,12,13,13,14,591,64,1,519,13,12,73,0,72,0,518,512]

theorem envBound1350 : H12AffineFastState.Bounded env1350 := by
  intro p hp
  have h : env1350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1349_1350 : H12AffineEnvironment.transform 3 12 env1349 = env1350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1349 == env1350) = true)

def env1351 : List Nat := [2,4,8,12,12,0,5,8,512,9,0,1,514,519,523,517,522,13,9,523,12,13,13,14,527,0,1,519,13,12,9,0,8,0,518,512]

theorem envBound1351 : H12AffineFastState.Bounded env1351 := by
  intro p hp
  have h : env1351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1350_1351 : H12AffineEnvironment.transform 5 0 env1350 = env1351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1350 == env1351) = true)

def leafEnv1351 : List Nat := [2,4,8,12,12,0,5,8,512,9,0,1,514,519,523,517,522,13,9,523,12,13,13,14,8,527,1,0,1,519,13,12,9,0,8,0,5,521,518,512,1,13,0]

def active1351 : List Nat := [0,1,2,8]

def tree1351 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1351 : H12WitnessSearch.Good tree1351 := H12GlobalWitnessIndex.good

theorem leafIdentity1351 : H12AffineFastState.composeSystem env1351 rootObs = leafEnv1351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1351 rootObs == leafEnv1351) = true)

theorem terminalChecked1351 : H12PackedTerminal.terminalCheckFast leafEnv1351 active1351 tree1351 = true := by decide +kernel

def env1352 : List Nat := [2,4,8,12,12,1,5,9,512,8,0,0,515,519,522,516,523,13,8,522,12,13,13,14,526,1,1,519,13,12,8,0,9,0,518,512]

theorem envBound1352 : H12AffineFastState.Bounded env1352 := by
  intro p hp
  have h : env1352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1350_1352 : H12AffineEnvironment.transform 5 1 env1350 = env1352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1350 == env1352) = true)

theorem identity1352 : scanCanonicalize (H12AffineFastState.compose env1352 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1353 : List Nat := [2,4,8,12,12,1,5,9,6,8,0,0,5,1,12,2,13,13,8,12,12,13,13,14,8,1,1,1,13,12,8,0,9,0,0,6]

theorem envBound1353 : H12AffineFastState.Bounded env1353 := by
  intro p hp
  have h : env1353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1352_1353 : H12AffineEnvironment.transform 8 6 env1352 = env1353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1352 == env1353) = true)

def leafEnv1353 : List Nat := [2,4,8,12,12,1,5,9,6,8,0,0,5,1,12,2,13,13,8,12,12,13,13,14,9,8,1,1,1,1,13,12,8,0,9,0,5,14,0,6,1,13,0]

def active1353 : List Nat := [0,1,2]

def tree1353 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1353 : H12WitnessSearch.Good tree1353 := H12GlobalWitnessIndex.good

theorem leafIdentity1353 : H12AffineFastState.composeSystem env1353 rootObs = leafEnv1353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1353 rootObs == leafEnv1353) = true)

theorem terminalChecked1353 : H12PackedTerminal.terminalCheckFast leafEnv1353 active1353 tree1353 = true := by decide +kernel

def env1354 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,65,579,538,586,600,587,16,85,586,16,17,17,18,594,64,0,538,17,17,85,0,84,0,539,512]

theorem envBound1354 : H12AffineFastState.Bounded env1354 := by
  intro p hp
  have h : env1354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1348_1354 : H12AffineEnvironment.transform 10 1 env1348 = env1354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1348 == env1354) = true)

theorem identity1354 : scanCanonicalize (H12AffineFastState.compose env1354 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1355 : List Nat := [2,4,4,16,16,64,21,84,512,85,1,65,579,534,582,596,583,16,85,582,16,17,17,18,594,64,0,534,17,17,85,0,84,0,535,512]

theorem envBound1355 : H12AffineFastState.Bounded env1355 := by
  intro p hp
  have h : env1355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1354_1355 : H12AffineEnvironment.transform 2 4 env1354 = env1355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1354 == env1355) = true)

def env1356 : List Nat := [2,4,4,16,16,0,21,20,512,21,1,1,515,534,518,532,519,16,21,518,16,17,17,18,530,0,0,534,17,17,21,0,20,0,535,512]

theorem envBound1356 : H12AffineFastState.Bounded env1356 := by
  intro p hp
  have h : env1356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1355_1356 : H12AffineEnvironment.transform 5 0 env1355 = env1356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1355 == env1356) = true)

theorem identity1356 : scanCanonicalize (H12AffineFastState.compose env1356 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1356 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1357 : List Nat := [2,4,4,16,16,0,21,20,23,21,1,1,20,1,17,3,16,16,21,17,16,17,17,18,5,0,0,1,17,17,21,0,20,0,0,23]

theorem envBound1357 : H12AffineFastState.Bounded env1357 := by
  intro p hp
  have h : env1357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1356_1357 : H12AffineEnvironment.transform 8 23 env1356 = env1357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1356 == env1357) = true)

def leafEnv1357 : List Nat := [2,4,4,16,16,0,21,20,23,21,1,1,20,1,17,3,16,16,21,17,16,17,17,18,20,5,1,0,0,1,17,17,21,0,20,0,5,19,0,23,1,17,0]

def active1357 : List Nat := [0,1,3]

def tree1357 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1357 : H12WitnessSearch.Good tree1357 := H12GlobalWitnessIndex.good

theorem leafIdentity1357 : H12AffineFastState.composeSystem env1357 rootObs = leafEnv1357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1357 rootObs == leafEnv1357) = true)

theorem terminalChecked1357 : H12PackedTerminal.terminalCheckFast leafEnv1357 active1357 tree1357 = true := by decide +kernel

def env1358 : List Nat := [2,4,4,16,16,1,21,21,512,20,1,0,514,534,519,533,518,16,20,519,16,17,17,18,531,1,0,534,17,17,20,0,21,0,535,512]

theorem envBound1358 : H12AffineFastState.Bounded env1358 := by
  intro p hp
  have h : env1358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1355_1358 : H12AffineEnvironment.transform 5 1 env1355 = env1358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1355 == env1358) = true)

def leafEnv1358 : List Nat := [2,4,4,16,16,1,21,21,512,20,1,0,514,534,519,533,518,16,20,519,16,17,17,18,21,531,1,1,0,534,17,17,20,0,21,0,5,517,535,512,1,17,0]

def active1358 : List Nat := [0,1,3,8]

def tree1358 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1358 : H12WitnessSearch.Good tree1358 := H12GlobalWitnessIndex.good

theorem leafIdentity1358 : H12AffineFastState.composeSystem env1358 rootObs = leafEnv1358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1358 rootObs == leafEnv1358) = true)

theorem terminalChecked1358 : H12PackedTerminal.terminalCheckFast leafEnv1358 active1358 tree1358 = true := by decide +kernel

def env1359 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,65,2626,2587,2635,2648,2634,2064,85,2635,16,16,17,19,2642,64,2049,2587,17,2065,85,0,84,0,2586,512]

theorem envBound1359 : H12AffineFastState.Bounded env1359 := by
  intro p hp
  have h : env1359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1347_1359 : H12AffineEnvironment.transform 4 17 env1347 = env1359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1347 == env1359) = true)

def env1360 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,65,578,539,587,600,586,16,85,587,16,16,17,19,594,64,1,539,17,17,85,0,84,0,538,512]

theorem envBound1360 : H12AffineFastState.Bounded env1360 := by
  intro p hp
  have h : env1360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1359_1360 : H12AffineEnvironment.transform 10 0 env1359 = env1360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1359 == env1360) = true)

theorem identity1360 : scanCanonicalize (H12AffineFastState.compose env1360 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound1360 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1361 : List Nat := [2,4,8,16,17,64,24,84,87,85,0,65,21,76,28,15,29,16,85,28,16,16,17,19,5,64,1,76,17,17,85,0,84,0,77,87]

theorem envBound1361 : H12AffineFastState.Bounded env1361 := by
  intro p hp
  have h : env1361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1360_1361 : H12AffineEnvironment.transform 8 87 env1360 = env1361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env1360 == env1361) = true)

def env1362 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,1,21,12,28,15,29,16,21,28,16,16,17,19,5,0,1,12,17,17,21,0,20,0,13,23]

theorem envBound1362 : H12AffineFastState.Bounded env1362 := by
  intro p hp
  have h : env1362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1361_1362 : H12AffineEnvironment.transform 5 0 env1361 = env1362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1361 == env1362) = true)

def leafEnv1362 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,1,21,12,28,15,29,16,21,28,16,16,17,19,20,5,1,0,1,12,17,17,21,0,20,0,5,30,13,23,1,17,0]

def active1362 : List Nat := [0,1,2,3]

def tree1362 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1362 : H12WitnessSearch.Good tree1362 := H12GlobalWitnessIndex.good

theorem leafIdentity1362 : H12AffineFastState.composeSystem env1362 rootObs = leafEnv1362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1362 rootObs == leafEnv1362) = true)

theorem terminalChecked1362 : H12PackedTerminal.terminalCheckFast leafEnv1362 active1362 tree1362 = true := by decide +kernel

def env1363 : List Nat := [2,4,8,16,17,1,24,21,22,20,0,0,21,13,28,15,29,16,20,28,16,16,17,19,5,1,1,13,17,17,20,0,21,0,12,22]

theorem envBound1363 : H12AffineFastState.Bounded env1363 := by
  intro p hp
  have h : env1363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1361_1363 : H12AffineEnvironment.transform 5 1 env1361 = env1363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1361 == env1363) = true)

theorem identity1363 : scanCanonicalize (H12AffineFastState.compose env1363 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1364 : List Nat := [2,4,5,16,17,1,21,21,22,20,0,0,21,0,17,2,16,16,20,17,16,16,17,19,5,1,1,0,17,17,20,0,21,0,1,22]

theorem envBound1364 : H12AffineFastState.Bounded env1364 := by
  intro p hp
  have h : env1364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1363_1364 : H12AffineEnvironment.transform 2 5 env1363 = env1364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1363 == env1364) = true)

def leafEnv1364 : List Nat := [2,4,5,16,17,1,21,21,22,20,0,0,21,0,17,2,16,16,20,17,16,16,17,19,21,5,1,1,1,0,17,17,20,0,21,0,5,19,1,22,1,17,0]

def active1364 : List Nat := [0,1,3]

def tree1364 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1364 : H12WitnessSearch.Good tree1364 := H12GlobalWitnessIndex.good

theorem leafIdentity1364 : H12AffineFastState.composeSystem env1364 rootObs = leafEnv1364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1364 rootObs == leafEnv1364) = true)

theorem terminalChecked1364 : H12PackedTerminal.terminalCheckFast leafEnv1364 active1364 tree1364 = true := by decide +kernel

def env1365 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,65,579,538,586,601,587,17,85,586,16,16,17,19,595,64,0,538,17,16,85,0,84,0,539,512]

theorem envBound1365 : H12AffineFastState.Bounded env1365 := by
  intro p hp
  have h : env1365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1359_1365 : H12AffineEnvironment.transform 10 1 env1359 = env1365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1359 == env1365) = true)

theorem identity1365 : scanCanonicalize (H12AffineFastState.compose env1365 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound1365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1366 : List Nat := [2,4,8,16,17,64,24,84,71,85,1,65,4,93,13,30,12,17,85,13,16,16,17,19,20,64,0,93,17,16,85,0,84,0,92,71]

theorem envBound1366 : H12AffineFastState.Bounded env1366 := by
  intro p hp
  have h : env1366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1365_1366 : H12AffineEnvironment.transform 8 71 env1365 = env1366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env1365 == env1366) = true)

def env1367 : List Nat := [2,4,8,16,17,0,24,20,7,21,1,1,4,29,13,30,12,17,21,13,16,16,17,19,20,0,0,29,17,16,21,0,20,0,28,7]

theorem envBound1367 : H12AffineFastState.Bounded env1367 := by
  intro p hp
  have h : env1367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1366_1367 : H12AffineEnvironment.transform 5 0 env1366 = env1367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1366 == env1367) = true)

theorem identity1367 : scanCanonicalize (H12AffineFastState.compose env1367 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1368 : List Nat := [2,4,8,13,12,0,5,9,7,8,1,1,4,0,13,3,12,12,8,13,13,13,12,14,9,0,0,0,12,13,8,0,9,0,1,7]

theorem envBound1368 : H12AffineFastState.Bounded env1368 := by
  intro p hp
  have h : env1368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1367_1368 : H12AffineEnvironment.transform 3 13 env1367 = env1368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1367 == env1368) = true)

def leafEnv1368 : List Nat := [2,4,8,13,12,0,5,9,7,8,1,1,4,0,13,3,12,12,8,13,13,13,12,14,9,9,1,0,0,0,12,13,8,0,9,0,5,15,1,7,1,12,0]

def active1368 : List Nat := [0,1,2]

def tree1368 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1368 : H12WitnessSearch.Good tree1368 := H12GlobalWitnessIndex.good

theorem leafIdentity1368 : H12AffineFastState.composeSystem env1368 rootObs = leafEnv1368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1368 rootObs == leafEnv1368) = true)

theorem terminalChecked1368 : H12PackedTerminal.terminalCheckFast leafEnv1368 active1368 tree1368 = true := by decide +kernel

def env1369 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,0,4,28,13,30,12,17,20,13,16,16,17,19,20,1,0,28,17,16,20,0,21,0,29,6]

theorem envBound1369 : H12AffineFastState.Bounded env1369 := by
  intro p hp
  have h : env1369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1366_1369 : H12AffineEnvironment.transform 5 1 env1366 = env1369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1366 == env1369) = true)

def leafEnv1369 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,0,4,28,13,30,12,17,20,13,16,16,17,19,21,20,1,1,0,28,17,16,20,0,21,0,5,15,29,6,1,17,0]

def active1369 : List Nat := [0,1,2,3]

def tree1369 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1369 : H12WitnessSearch.Good tree1369 := H12GlobalWitnessIndex.good

theorem leafIdentity1369 : H12AffineFastState.composeSystem env1369 rootObs = leafEnv1369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1369 rootObs == leafEnv1369) = true)

theorem terminalChecked1369 : H12PackedTerminal.terminalCheckFast leafEnv1369 active1369 tree1369 = true := by decide +kernel

def env1370 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205377,74882,8201,74950,73891,184,73737,8328,73835,131811,2586,134670,2080,74882,0,73855,0,131321,512]

theorem envBound1370 : H12AffineFastState.Bounded env1370 := by
  intro p hp
  have h : env1370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1339_1370 : H12AffineEnvironment.transform 11 1045 env1339 = env1370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1339 == env1370) = true)

def env1371 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2081,74882,8201,74950,73891,184,73737,8328,73835,75907,2586,74862,2080,74882,0,73855,0,76441,512]

theorem envBound1371 : H12AffineFastState.Bounded env1371 := by
  intro p hp
  have h : env1371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1370_1371 : H12AffineEnvironment.transform 16 76384 env1370 = env1371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1370 == env1371) = true)

theorem identity1371 : scanCanonicalize (H12AffineFastState.compose env1371 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1371 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1372 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,3733,9461,2081,10775,8201,10835,11830,184,11932,8328,12030,9750,2586,11003,2080,10775,0,12010,0,9228,512]

theorem envBound1372 : H12AffineFastState.Bounded env1372 := by
  intro p hp
  have h : env1372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1371_1372 : H12AffineEnvironment.transform 15 3733 env1371 = env1372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1371 == env1372) = true)

theorem identity1372 : scanCanonicalize (H12AffineFastState.compose env1372 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1372 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1373 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2586,3614,3733,2786,2081,1024,3614,1092,33,184,139,3743,233,2049,2586,1260,2080,1024,0,253,0,2587,512]

theorem envBound1373 : H12AffineFastState.Bounded env1373 := by
  intro p hp
  have h : env1373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1372_1373 : H12AffineEnvironment.transform 12 3607 env1372 = env1373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1372 == env1373) = true)

theorem identity1373 : scanCanonicalize (H12AffineFastState.compose env1373 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1373 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1374 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2626,2586,2635,2752,2786,2081,85,2635,17,33,184,139,2762,233,2049,2586,185,2080,85,0,253,0,2587,512]

theorem envBound1374 : H12AffineFastState.Bounded env1374 := by
  intro p hp
  have h : env1374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1373_1374 : H12AffineEnvironment.transform 9 85 env1373 = env1374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1373 == env1374) = true)

theorem identity1374 : scanCanonicalize (H12AffineFastState.compose env1374 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1374 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1375 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,64,2626,2586,2635,2665,2635,2081,85,2635,17,33,17,34,2659,64,2049,2586,16,2080,85,0,84,0,2587,512]

theorem envBound1375 : H12AffineFastState.Bounded env1375 := by
  intro p hp
  have h : env1375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1374_1375 : H12AffineEnvironment.transform 6 41 env1374 = env1375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1374 == env1375) = true)

def env1376 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,64,2626,2586,2635,2649,2635,2065,85,2635,17,17,17,18,2643,64,2049,2586,16,2064,85,0,84,0,2587,512]

theorem envBound1376 : H12AffineFastState.Bounded env1376 := by
  intro p hp
  have h : env1376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1375_1376 : H12AffineEnvironment.transform 4 16 env1375 = env1376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1375 == env1376) = true)

def env1377 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,64,578,538,587,601,587,17,85,587,17,17,17,18,595,64,1,538,16,16,85,0,84,0,539,512]

theorem envBound1377 : H12AffineFastState.Bounded env1377 := by
  intro p hp
  have h : env1377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1376_1377 : H12AffineEnvironment.transform 10 0 env1376 = env1377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1376 == env1377) = true)

theorem identity1377 : scanCanonicalize (H12AffineFastState.compose env1377 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1378 : List Nat := [2,4,8,16,16,64,25,84,22,85,0,64,84,12,93,79,93,17,85,93,17,17,17,18,69,64,1,12,16,16,85,0,84,0,13,22]

theorem envBound1378 : H12AffineFastState.Bounded env1378 := by
  intro p hp
  have h : env1378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1377_1378 : H12AffineEnvironment.transform 8 22 env1377 = env1378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1377 == env1378) = true)

def env1379 : List Nat := [2,4,8,16,16,0,25,20,22,21,0,0,20,12,29,15,29,17,21,29,17,17,17,18,5,0,1,12,16,16,21,0,20,0,13,22]

theorem envBound1379 : H12AffineFastState.Bounded env1379 := by
  intro p hp
  have h : env1379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1378_1379 : H12AffineEnvironment.transform 5 0 env1378 = env1379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1378 == env1379) = true)

theorem identity1379 : scanCanonicalize (H12AffineFastState.compose env1379 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1379 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1380 : List Nat := [2,4,4,16,16,0,21,20,22,21,0,0,20,0,17,3,17,17,21,17,17,17,17,18,5,0,1,0,16,16,21,0,20,0,1,22]

theorem envBound1380 : H12AffineFastState.Bounded env1380 := by
  intro p hp
  have h : env1380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1379_1380 : H12AffineEnvironment.transform 2 4 env1379 = env1380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1379 == env1380) = true)

def leafEnv1380 : List Nat := [2,4,4,16,16,0,21,20,22,21,0,0,20,0,17,3,17,17,21,17,17,17,17,18,20,5,1,0,1,0,16,16,21,0,20,0,5,19,1,22,1,16,0]

def active1380 : List Nat := [0,1,3]

def tree1380 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1380 : H12WitnessSearch.Good tree1380 := H12GlobalWitnessIndex.good

theorem leafIdentity1380 : H12AffineFastState.composeSystem env1380 rootObs = leafEnv1380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1380 rootObs == leafEnv1380) = true)

theorem terminalChecked1380 : H12PackedTerminal.terminalCheckFast leafEnv1380 active1380 tree1380 = true := by decide +kernel

def env1381 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,1,21,12,28,14,28,17,20,28,17,17,17,18,4,1,1,12,16,16,20,0,21,0,13,22]

theorem envBound1381 : H12AffineFastState.Bounded env1381 := by
  intro p hp
  have h : env1381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1378_1381 : H12AffineEnvironment.transform 5 1 env1378 = env1381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1378 == env1381) = true)

def leafEnv1381 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,1,21,12,28,14,28,17,20,28,17,17,17,18,21,4,1,1,1,12,16,16,20,0,21,0,5,30,13,22,1,16,0]

def active1381 : List Nat := [0,1,2,3]

def tree1381 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1381 : H12WitnessSearch.Good tree1381 := H12GlobalWitnessIndex.good

theorem leafIdentity1381 : H12AffineFastState.composeSystem env1381 rootObs = leafEnv1381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1381 rootObs == leafEnv1381) = true)

theorem terminalChecked1381 : H12PackedTerminal.terminalCheckFast leafEnv1381 active1381 tree1381 = true := by decide +kernel

def env1382 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,64,579,539,586,600,586,16,85,586,17,17,17,18,594,64,0,539,16,17,85,0,84,0,538,512]

theorem envBound1382 : H12AffineFastState.Bounded env1382 := by
  intro p hp
  have h : env1382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1376_1382 : H12AffineEnvironment.transform 10 1 env1376 = env1382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1376 == env1382) = true)

theorem identity1382 : scanCanonicalize (H12AffineFastState.compose env1382 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1383 : List Nat := [2,4,8,16,16,64,25,84,7,85,1,64,68,28,77,95,77,16,85,77,17,17,17,18,85,64,0,28,16,17,85,0,84,0,29,7]

theorem envBound1383 : H12AffineFastState.Bounded env1383 := by
  intro p hp
  have h : env1383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1382_1383 : H12AffineEnvironment.transform 8 7 env1382 = env1383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1382 == env1383) = true)

def env1384 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,0,4,28,13,31,13,16,21,13,17,17,17,18,21,0,0,28,16,17,21,0,20,0,29,7]

theorem envBound1384 : H12AffineFastState.Bounded env1384 := by
  intro p hp
  have h : env1384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1383_1384 : H12AffineEnvironment.transform 5 0 env1383 = env1384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1383 == env1384) = true)

def leafEnv1384 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,0,4,28,13,31,13,16,21,13,17,17,17,18,20,21,1,0,0,28,16,17,21,0,20,0,5,15,29,7,1,16,0]

def active1384 : List Nat := [0,1,2,3]

def tree1384 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1384 : H12WitnessSearch.Good tree1384 := H12GlobalWitnessIndex.good

theorem leafIdentity1384 : H12AffineFastState.composeSystem env1384 rootObs = leafEnv1384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1384 rootObs == leafEnv1384) = true)

theorem terminalChecked1384 : H12PackedTerminal.terminalCheckFast leafEnv1384 active1384 tree1384 = true := by decide +kernel

def env1385 : List Nat := [2,4,8,16,16,1,25,21,7,20,1,1,5,28,12,30,12,16,20,12,17,17,17,18,20,1,0,28,16,17,20,0,21,0,29,7]

theorem envBound1385 : H12AffineFastState.Bounded env1385 := by
  intro p hp
  have h : env1385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1383_1385 : H12AffineEnvironment.transform 5 1 env1383 = env1385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1383 == env1385) = true)

theorem identity1385 : scanCanonicalize (H12AffineFastState.compose env1385 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1386 : List Nat := [2,4,8,12,12,1,5,9,7,8,1,1,5,0,12,2,12,12,8,12,13,13,13,14,8,1,0,0,12,13,8,0,9,0,1,7]

theorem envBound1386 : H12AffineFastState.Bounded env1386 := by
  intro p hp
  have h : env1386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1385_1386 : H12AffineEnvironment.transform 3 12 env1385 = env1386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1385 == env1386) = true)

def leafEnv1386 : List Nat := [2,4,8,12,12,1,5,9,7,8,1,1,5,0,12,2,12,12,8,12,13,13,13,14,9,8,1,1,0,0,12,13,8,0,9,0,5,14,1,7,1,12,0]

def active1386 : List Nat := [0,1,2]

def tree1386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1386 : H12WitnessSearch.Good tree1386 := H12GlobalWitnessIndex.good

theorem leafIdentity1386 : H12AffineFastState.composeSystem env1386 rootObs = leafEnv1386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1386 rootObs == leafEnv1386) = true)

theorem terminalChecked1386 : H12PackedTerminal.terminalCheckFast leafEnv1386 active1386 tree1386 = true := by decide +kernel

def env1387 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,64,2626,2586,2635,2648,2635,2064,85,2635,17,16,17,19,2642,64,2049,2586,16,2065,85,0,84,0,2587,512]

theorem envBound1387 : H12AffineFastState.Bounded env1387 := by
  intro p hp
  have h : env1387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1375_1387 : H12AffineEnvironment.transform 4 17 env1375 = env1387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1375 == env1387) = true)

def env1388 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,64,578,538,587,600,587,16,85,587,17,16,17,19,594,64,1,538,16,17,85,0,84,0,539,512]

theorem envBound1388 : H12AffineFastState.Bounded env1388 := by
  intro p hp
  have h : env1388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1387_1388 : H12AffineEnvironment.transform 10 0 env1387 = env1388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1387 == env1388) = true)

theorem identity1388 : scanCanonicalize (H12AffineFastState.compose env1388 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound1388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1389 : List Nat := [2,4,8,16,17,29,24,9,512,8,0,29,543,538,534,517,534,16,8,534,17,16,17,19,527,29,1,538,16,17,8,0,9,0,539,512]

theorem envBound1389 : H12AffineFastState.Bounded env1389 := by
  intro p hp
  have h : env1389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1388_1389 : H12AffineEnvironment.transform 5 29 env1388 = env1389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env1388 == env1389) = true)

def env1390 : List Nat := [2,4,8,12,13,1,4,9,512,8,0,1,515,518,522,517,522,12,8,522,13,12,13,15,527,1,1,518,12,13,8,0,9,0,519,512]

theorem envBound1390 : H12AffineFastState.Bounded env1390 := by
  intro p hp
  have h : env1390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1389_1390 : H12AffineEnvironment.transform 3 12 env1389 = env1390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1389 == env1390) = true)

def leafEnv1390 : List Nat := [2,4,8,12,13,1,4,9,512,8,0,1,515,518,522,517,522,12,8,522,13,12,13,15,9,527,1,1,1,518,12,13,8,0,9,0,5,520,519,512,1,12,0]

def active1390 : List Nat := [0,1,2,8]

def tree1390 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1390 : H12WitnessSearch.Good tree1390 := H12GlobalWitnessIndex.good

theorem leafIdentity1390 : H12AffineFastState.composeSystem env1390 rootObs = leafEnv1390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1390 rootObs == leafEnv1390) = true)

theorem terminalChecked1390 : H12PackedTerminal.terminalCheckFast leafEnv1390 active1390 tree1390 = true := by decide +kernel

def env1391 : List Nat := [2,4,8,13,12,0,5,9,512,8,0,0,514,519,523,517,523,13,8,523,12,13,12,14,527,0,1,519,13,12,8,0,9,0,518,512]

theorem envBound1391 : H12AffineFastState.Bounded env1391 := by
  intro p hp
  have h : env1391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1389_1391 : H12AffineEnvironment.transform 3 13 env1389 = env1391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1389 == env1391) = true)

theorem identity1391 : scanCanonicalize (H12AffineFastState.compose env1391 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1392 : List Nat := [2,4,8,13,12,0,5,9,6,8,0,0,4,1,13,3,13,13,8,13,12,13,12,14,9,0,1,1,13,12,8,0,9,0,0,6]

theorem envBound1392 : H12AffineFastState.Bounded env1392 := by
  intro p hp
  have h : env1392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1391_1392 : H12AffineEnvironment.transform 8 6 env1391 = env1392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1391 == env1392) = true)

def leafEnv1392 : List Nat := [2,4,8,13,12,0,5,9,6,8,0,0,4,1,13,3,13,13,8,13,12,13,12,14,9,9,1,0,1,1,13,12,8,0,9,0,5,15,0,6,1,13,0]

def active1392 : List Nat := [0,1,2]

def tree1392 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1392 : H12WitnessSearch.Good tree1392 := H12GlobalWitnessIndex.good

theorem leafIdentity1392 : H12AffineFastState.composeSystem env1392 rootObs = leafEnv1392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1392 rootObs == leafEnv1392) = true)

theorem terminalChecked1392 : H12PackedTerminal.terminalCheckFast leafEnv1392 active1392 tree1392 = true := by decide +kernel

def env1393 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,64,579,539,586,601,586,17,85,586,17,16,17,19,595,64,0,539,16,16,85,0,84,0,538,512]

theorem envBound1393 : H12AffineFastState.Bounded env1393 := by
  intro p hp
  have h : env1393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1387_1393 : H12AffineEnvironment.transform 10 1 env1387 = env1393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1387 == env1393) = true)

theorem identity1393 : scanCanonicalize (H12AffineFastState.compose env1393 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound1393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1394 : List Nat := [2,4,8,16,17,12,24,24,512,25,1,12,527,539,518,533,518,17,25,518,17,16,17,19,543,12,0,539,16,16,25,0,24,0,538,512]

theorem envBound1394 : H12AffineFastState.Bounded env1394 := by
  intro p hp
  have h : env1394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1393_1394 : H12AffineEnvironment.transform 5 12 env1393 = env1394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env1393 == env1394) = true)

def env1395 : List Nat := [2,4,4,16,17,0,20,20,512,21,1,0,515,535,518,533,518,17,21,518,17,16,17,19,531,0,0,535,16,16,21,0,20,0,534,512]

theorem envBound1395 : H12AffineFastState.Bounded env1395 := by
  intro p hp
  have h : env1395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1394_1395 : H12AffineEnvironment.transform 2 4 env1394 = env1395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1394 == env1395) = true)

def leafEnv1395 : List Nat := [2,4,4,16,17,0,20,20,512,21,1,0,515,535,518,533,518,17,21,518,17,16,17,19,20,531,1,0,0,535,16,16,21,0,20,0,5,516,534,512,1,16,0]

def active1395 : List Nat := [0,1,3,8]

def tree1395 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1395 : H12WitnessSearch.Good tree1395 := H12GlobalWitnessIndex.good

theorem leafIdentity1395 : H12AffineFastState.composeSystem env1395 rootObs = leafEnv1395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1395 rootObs == leafEnv1395) = true)

theorem terminalChecked1395 : H12PackedTerminal.terminalCheckFast leafEnv1395 active1395 tree1395 = true := by decide +kernel

def env1396 : List Nat := [2,4,5,16,17,1,21,21,512,20,1,1,514,534,518,533,518,17,20,518,17,16,17,19,530,1,0,534,16,16,20,0,21,0,535,512]

theorem envBound1396 : H12AffineFastState.Bounded env1396 := by
  intro p hp
  have h : env1396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1394_1396 : H12AffineEnvironment.transform 2 5 env1394 = env1396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1394 == env1396) = true)

theorem identity1396 : scanCanonicalize (H12AffineFastState.compose env1396 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1397 : List Nat := [2,4,5,16,17,1,21,21,23,20,1,1,21,1,17,2,17,17,20,17,17,16,17,19,5,1,0,1,16,16,20,0,21,0,0,23]

theorem envBound1397 : H12AffineFastState.Bounded env1397 := by
  intro p hp
  have h : env1397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1396_1397 : H12AffineEnvironment.transform 8 23 env1396 = env1397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1396 == env1397) = true)

def leafEnv1397 : List Nat := [2,4,5,16,17,1,21,21,23,20,1,1,21,1,17,2,17,17,20,17,17,16,17,19,21,5,1,1,0,1,16,16,20,0,21,0,5,19,0,23,1,16,0]

def active1397 : List Nat := [0,1,3]

def tree1397 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1397 : H12WitnessSearch.Good tree1397 := H12GlobalWitnessIndex.good

theorem leafIdentity1397 : H12AffineFastState.composeSystem env1397 rootObs = leafEnv1397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1397 rootObs == leafEnv1397) = true)

theorem terminalChecked1397 : H12PackedTerminal.terminalCheckFast leafEnv1397 active1397 tree1397 = true := by decide +kernel

def env1398 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2080,74882,8201,74950,73891,184,73737,8328,73835,75906,2586,74863,2080,74882,0,73855,0,76440,512]

theorem envBound1398 : H12AffineFastState.Bounded env1398 := by
  intro p hp
  have h : env1398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1370_1398 : H12AffineEnvironment.transform 16 76385 env1370 = env1398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1370 == env1398) = true)

theorem identity1398 : scanCanonicalize (H12AffineFastState.compose env1398 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound1398 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1399 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,225,2586,232,65536,68224,2080,66659,232,66599,65602,184,65768,105,65674,67683,2586,66702,2080,66659,0,65694,0,68217,512]

theorem envBound1399 : H12AffineFastState.Bounded env1399 := by
  intro p hp
  have h : env1399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1398_1399 : H12AffineEnvironment.transform 12 225 env1398 = env1399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env1398 == env1399) = true)

def env1400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,185,74229,8328,74135,336222,16384,151553,2080,75134,1,73855,0,131332,512]

theorem envBound1400 : H12AffineFastState.Bounded env1400 := by
  intro p hp
  have h : env1400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1323_1400 : H12AffineEnvironment.transform 22 185 env1323 = env1400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1323 == env1400) = true)

theorem identity1400 : scanCanonicalize (H12AffineFastState.compose env1400 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1400 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1401 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74882,8201,2097152,73891,185,73736,8328,73834,336035,16384,151553,2080,74883,1,73855,0,131321,512]

theorem envBound1401 : H12AffineFastState.Bounded env1401 := by
  intro p hp
  have h : env1401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1400_1401 : H12AffineEnvironment.transform 7 253 env1400 = env1401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1400 == env1401) = true)

def env1402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2080,17375733,13108376,525568,0,34359738368,25691698]

theorem envBound1402 : H12AffineFastState.Bounded env1402 := by
  intro p hp
  have h : env1402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1318_1402 : H12AffineEnvironment.transform 14 8693 env1318 = env1402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1318 == env1402) = true)

def env1403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672785,935128,16384,151553,2080,17375733,4867288,525568,0,34359738368,17450610]

theorem envBound1403 : H12AffineFastState.Bounded env1403 := by
  intro p hp
  have h : env1403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1402_1403 : H12AffineEnvironment.transform 22 147520 env1402 = env1403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env1402 == env1403) = true)

def env1404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,34359738368,16925298]

theorem envBound1404 : H12AffineFastState.Bounded env1404 := by
  intro p hp
  have h : env1404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1403_1404 : H12AffineEnvironment.transform 18 1024 env1403 = env1404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1403 == env1404) = true)

def env1405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,131072,16925298]

theorem envBound1405 : H12AffineFastState.Bounded env1405 := by
  intro p hp
  have h : env1405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1404_1405 : H12AffineEnvironment.transform 34 131072 env1404 = env1405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1404 == env1405) = true)

theorem identity1405 : scanCanonicalize (H12AffineFastState.compose env1405 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound1405 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1406 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,131072,262144,257,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16851188,4341976,256,0,131072,16925298]

theorem envBound1406 : H12AffineFastState.Bounded env1406 := by
  intro p hp
  have h : env1406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1405_1406 : H12AffineEnvironment.transform 9 257 env1405 = env1406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env1405 == env1406) = true)

theorem identity1406 : scanCanonicalize (H12AffineFastState.compose env1406 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 4268501) := by decide +kernel

theorem selectedBound1406 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1407 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,131072,262144,257,8693,2097152,4194304,147520,4268501,8328,147473,409816,16384,151553,2080,4194593,4341976,256,0,131072,4416423]

theorem envBound1407 : H12AffineFastState.Bounded env1407 := by
  intro p hp
  have h : env1407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1406_1407 : H12AffineEnvironment.transform 23 4268501 env1406 = env1407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4268501 env1406 == env1407) = true)

theorem identity1407 : scanCanonicalize (H12AffineFastState.compose env1407 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 221607) := by decide +kernel

theorem selectedBound1407 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1408 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,131072,262144,257,8693,2097152,221607,147520,147570,8328,147473,409816,16384,151553,2080,221318,74111,256,0,131072,512]

theorem envBound1408 : H12AffineFastState.Bounded env1408 := by
  intro p hp
  have h : env1408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1407_1408 : H12AffineEnvironment.transform 21 221607 env1407 = env1408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 221607 env1407 == env1408) = true)

theorem identity1408 : scanCanonicalize (H12AffineFastState.compose env1408 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90502) := by decide +kernel

theorem selectedBound1408 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1409 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,90502,262144,257,8693,2097152,33,74182,74228,8328,74135,336222,16384,78215,2080,256,74111,256,0,90502,512]

theorem envBound1409 : H12AffineFastState.Bounded env1409 := by
  intro p hp
  have h : env1409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1408_1409 : H12AffineEnvironment.transform 16 90502 env1408 = env1409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90502 env1408 == env1409) = true)

theorem identity1409 : scanCanonicalize (H12AffineFastState.compose env1409 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1409 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1410 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,8574,16632,262144,257,8693,2097152,33,184,138,8328,233,262176,16384,4345,2080,256,1,256,0,16632,512]

theorem envBound1410 : H12AffineFastState.Bounded env1410 := by
  intro p hp
  have h : env1410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1409_1410 : H12AffineEnvironment.transform 15 8574 env1409 = env1410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1409 == env1410) = true)

theorem identity1410 : scanCanonicalize (H12AffineFastState.compose env1410 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound1410 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1411 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,8574,16632,2080,257,8693,2097152,33,184,138,8328,233,2048,16384,4345,2080,256,1,256,0,16632,512]

theorem envBound1411 : H12AffineFastState.Bounded env1411 := by
  intro p hp
  have h : env1411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1410_1411 : H12AffineEnvironment.transform 17 2080 env1410 = env1411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env1410 == env1411) = true)

theorem identity1411 : scanCanonicalize (H12AffineFastState.compose env1411 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound1411 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1412 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,16384,8201,8322,16632,2080,253,8201,2097152,33,184,138,8328,233,2048,16384,4345,2080,252,1,252,0,16632,512]

theorem envBound1412 : H12AffineFastState.Bounded env1412 := by
  intro p hp
  have h : env1412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1411_1412 : H12AffineEnvironment.transform 7 252 env1411 = env1412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1411 == env1412) = true)

theorem identity1412 : scanCanonicalize (H12AffineFastState.compose env1412 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26674) := by decide +kernel

theorem selectedBound1412 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env1413 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,16384,8201,8322,16632,2080,253,8201,26674,33,184,138,8328,233,2048,16384,4345,2080,252,1,252,0,16632,512]

theorem envBound1413 : H12AffineFastState.Bounded env1413 := by
  intro p hp
  have h : env1413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1412_1413 : H12AffineEnvironment.transform 20 26674 env1412 = env1413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26674 env1412 == env1413) = true)

theorem identity1413 : scanCanonicalize (H12AffineFastState.compose env1413 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound1413 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1414 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,8192,12496,8201,8322,12328,2080,253,8201,6370,33,184,138,8328,233,2048,12496,4345,2080,252,1,252,0,12328,512]

theorem envBound1414 : H12AffineFastState.Bounded env1414 := by
  intro p hp
  have h : env1414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1413_1414 : H12AffineEnvironment.transform 13 12496 env1413 = env1414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env1413 == env1414) = true)

theorem identity1414 : scanCanonicalize (H12AffineFastState.compose env1414 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound1414 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env1415 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,4096,2282,6202,2275,2152,6338,2080,253,2275,6370,33,184,138,2146,233,2048,6202,4345,2080,252,1,252,0,6338,512]

theorem envBound1415 : H12AffineFastState.Bounded env1415 := by
  intro p hp
  have h : env1415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1414_1415 : H12AffineEnvironment.transform 12 2282 env1414 = env1415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env1414 == env1415) = true)

theorem identity1415 : scanCanonicalize (H12AffineFastState.compose env1415 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2128) := by decide +kernel

theorem selectedBound1415 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env1416 : List Nat := [2,4,8,16,32,64,128,252,512,253,2048,2128,2282,106,2275,2152,146,2080,253,2275,178,33,184,138,2146,233,2048,106,2217,2080,252,1,252,0,146,512]

theorem envBound1416 : H12AffineFastState.Bounded env1416 := by
  intro p hp
  have h : env1416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1415_1416 : H12AffineEnvironment.transform 11 2128 env1415 = env1416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2128 env1415 == env1416) = true)

theorem identity1416 : scanCanonicalize (H12AffineFastState.compose env1416 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound1416 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1417 : List Nat := [2,4,8,16,32,64,128,252,512,253,194,146,40,106,33,170,146,226,253,33,178,33,184,138,160,233,194,106,107,226,252,1,252,0,146,512]

theorem envBound1417 : H12AffineFastState.Bounded env1417 := by
  intro p hp
  have h : env1417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1416_1417 : H12AffineEnvironment.transform 10 194 env1416 = env1417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env1416 == env1417) = true)

theorem identity1417 : scanCanonicalize (H12AffineFastState.compose env1417 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound1417 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env1418 : List Nat := [2,4,8,16,32,64,19,111,512,110,81,1,40,106,33,57,1,113,110,33,33,33,43,25,51,122,81,106,107,113,111,1,111,0,1,512]

theorem envBound1418 : H12AffineFastState.Bounded env1418 := by
  intro p hp
  have h : env1418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1417_1418 : H12AffineEnvironment.transform 6 19 env1417 = env1418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env1417 == env1418) = true)

theorem identity1418 : scanCanonicalize (H12AffineFastState.compose env1418 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound1418 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1419 : List Nat := [2,4,8,16,32,43,19,4,512,5,58,1,40,1,33,57,1,26,5,33,33,33,43,25,51,17,58,1,0,26,4,1,4,0,1,512]

theorem envBound1419 : H12AffineFastState.Bounded env1419 := by
  intro p hp
  have h : env1419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1418_1419 : H12AffineEnvironment.transform 5 43 env1418 = env1419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env1418 == env1419) = true)

theorem identity1419 : scanCanonicalize (H12AffineFastState.compose env1419 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound1419 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1420 : List Nat := [2,4,8,16,1,10,19,4,512,5,27,1,9,1,0,24,1,26,5,0,0,0,10,25,18,17,27,1,0,26,4,1,4,0,1,512]

theorem envBound1420 : H12AffineFastState.Bounded env1420 := by
  intro p hp
  have h : env1420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1419_1420 : H12AffineEnvironment.transform 4 1 env1419 = env1420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env1419 == env1420) = true)

theorem identity1420 : scanCanonicalize (H12AffineFastState.compose env1420 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1421 : List Nat := [2,4,5,16,1,7,19,4,512,5,22,1,4,1,0,21,1,23,5,0,0,0,7,20,18,17,22,1,0,23,4,1,4,0,1,512]

theorem envBound1421 : H12AffineFastState.Bounded env1421 := by
  intro p hp
  have h : env1421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1420_1421 : H12AffineEnvironment.transform 2 5 env1420 = env1421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1420 == env1421) = true)

theorem identity1421 : scanCanonicalize (H12AffineFastState.compose env1421 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound1421 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env1422 : List Nat := [2,4,5,0,1,7,3,4,512,5,6,1,4,1,0,5,1,7,5,0,0,0,7,4,2,1,6,1,0,7,4,1,4,0,1,512]

theorem envBound1422 : H12AffineFastState.Bounded env1422 := by
  intro p hp
  have h : env1422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1421_1422 : H12AffineEnvironment.transform 3 0 env1421 = env1422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env1421 == env1422) = true)

theorem identity1422 : scanCanonicalize (H12AffineFastState.compose env1422 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1422 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1423 : List Nat := [2,3,2,0,1,0,3,3,512,2,1,1,3,1,0,2,1,0,2,0,0,0,0,3,2,1,1,1,0,0,3,1,3,0,1,512]

theorem envBound1423 : H12AffineFastState.Bounded env1423 := by
  intro p hp
  have h : env1423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1422_1423 : H12AffineEnvironment.transform 1 3 env1422 = env1423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1422 == env1423) = true)

def env1424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,131073,16925298]

theorem envBound1424 : H12AffineFastState.Bounded env1424 := by
  intro p hp
  have h : env1424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1404_1424 : H12AffineEnvironment.transform 34 131073 env1404 = env1424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1404 == env1424) = true)

theorem identity1424 : scanCanonicalize (H12AffineFastState.compose env1424 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 5377) := by decide +kernel

theorem selectedBound1424 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,5377,4194304,147520,16777216,8328,147473,409816,16384,151553,2080,16852469,4341976,256,0,131073,16925298]

theorem envBound1425 : H12AffineFastState.Bounded env1425 := by
  intro p hp
  have h : env1425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1424_1425 : H12AffineEnvironment.transform 20 5377 env1424 = env1425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5377 env1424 == env1425) = true)

theorem identity1425 : scanCanonicalize (H12AffineFastState.compose env1425 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 139) := by decide +kernel

theorem selectedBound1425 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,5377,4194304,147520,139,8328,147473,409816,16384,151553,2080,75134,4341976,256,0,131073,148217]

theorem envBound1426 : H12AffineFastState.Bounded env1426 := by
  intro p hp
  have h : env1426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1425_1426 : H12AffineEnvironment.transform 23 139 env1425 = env1426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 139 env1425 == env1426) = true)

def env1427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,5377,32,147520,139,8328,147473,409816,16384,151553,2080,75134,147704,256,0,131073,148217]

theorem envBound1427 : H12AffineFastState.Bounded env1427 := by
  intro p hp
  have h : env1427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1426_1427 : H12AffineEnvironment.transform 21 32 env1426 = env1427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env1426 == env1427) = true)

theorem identity1427 : scanCanonicalize (H12AffineFastState.compose env1427 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90503) := by decide +kernel

theorem selectedBound1427 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,90503,262144,1024,8693,5377,32,74183,139,8328,74134,336223,16384,78214,2080,75134,74111,256,0,90502,74622]

theorem envBound1428 : H12AffineFastState.Bounded env1428 := by
  intro p hp
  have h : env1428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1427_1428 : H12AffineEnvironment.transform 16 90503 env1427 = env1428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90503 env1427 == env1428) = true)

theorem identity1428 : scanCanonicalize (H12AffineFastState.compose env1428 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8663) := by decide +kernel

theorem selectedBound1428 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env1429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8663,16464,262144,1024,8693,5377,32,16,139,8328,65,262280,16384,4177,2080,1193,168,256,0,16465,681]

theorem envBound1429 : H12AffineFastState.Bounded env1429 := by
  intro p hp
  have h : env1429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1428_1429 : H12AffineEnvironment.transform 15 8663 env1428 = env1429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8663 env1428 == env1429) = true)

theorem identity1429 : scanCanonicalize (H12AffineFastState.compose env1429 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12465) := by decide +kernel

theorem selectedBound1429 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env1430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12465,8693,8663,12513,262144,1024,8693,5377,32,16,139,8328,65,262280,12465,4177,2080,1193,168,256,0,12512,681]

theorem envBound1430 : H12AffineFastState.Bounded env1430 := by
  intro p hp
  have h : env1430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1429_1430 : H12AffineEnvironment.transform 13 12465 env1429 = env1430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12465 env1429 == env1430) = true)

theorem identity1430 : scanCanonicalize (H12AffineFastState.compose env1430 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1430 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1431 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,12312,8540,8574,12360,262144,1024,8540,5377,32,16,34,8225,65,262177,12312,4177,2080,1024,1,256,0,12361,512]

theorem envBound1431 : H12AffineFastState.Bounded env1431 := by
  intro p hp
  have h : env1431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1430_1431 : H12AffineEnvironment.transform 6 41 env1430 = env1431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1430 == env1431) = true)

theorem identity1431 : scanCanonicalize (H12AffineFastState.compose env1431 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound1431 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1432 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,12312,8461,8495,12313,262144,1024,8461,5377,32,16,34,8225,16,262177,12312,4096,2080,1024,1,256,0,12312,512]

theorem envBound1432 : H12AffineFastState.Bounded env1432 := by
  intro p hp
  have h : env1432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1431_1432 : H12AffineEnvironment.transform 5 17 env1431 = env1432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env1431 == env1432) = true)

theorem identity1432 : scanCanonicalize (H12AffineFastState.compose env1432 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8982) := by decide +kernel

theorem selectedBound1432 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env1433 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,12312,8461,8495,12313,8982,1024,8461,5377,32,16,34,8225,16,9015,12312,4096,2080,1024,1,256,0,12312,512]

theorem envBound1433 : H12AffineFastState.Bounded env1433 := by
  intro p hp
  have h : env1433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1432_1433 : H12AffineEnvironment.transform 17 8982 env1432 = env1433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8982 env1432 == env1433) = true)

theorem identity1433 : scanCanonicalize (H12AffineFastState.compose env1433 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2871) := by decide +kernel

theorem selectedBound1433 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env1434 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,2871,6959,2618,2584,6958,2081,1024,2618,5377,32,16,34,2838,16,2048,6959,4096,2080,1024,1,256,0,6959,512]

theorem envBound1434 : H12AffineFastState.Bounded env1434 := by
  intro p hp
  have h : env1434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1433_1434 : H12AffineEnvironment.transform 12 2871 env1433 = env1434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2871 env1433 == env1434) = true)

theorem identity1434 : scanCanonicalize (H12AffineFastState.compose env1434 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound1434 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env1435 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1086,4096,1801,5905,1540,1574,5904,1055,1024,1540,5377,32,16,34,1832,16,1086,5905,4096,1054,1024,1,256,0,5905,512]

theorem envBound1435 : H12AffineFastState.Bounded env1435 := by
  intro p hp
  have h : env1435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1434_1435 : H12AffineEnvironment.transform 10 1086 env1434 = env1435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env1434 == env1435) = true)

theorem identity1435 : scanCanonicalize (H12AffineFastState.compose env1435 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1055) := by decide +kernel

theorem selectedBound1435 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env1436 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1086,1055,1801,782,1540,1574,783,1055,1024,1540,286,32,16,34,1832,16,1086,782,1055,1054,1024,1,256,0,782,512]

theorem envBound1436 : H12AffineFastState.Bounded env1436 := by
  intro p hp
  have h : env1436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1435_1436 : H12AffineEnvironment.transform 11 1055 env1435 = env1436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1055 env1435 == env1436) = true)

theorem identity1436 : scanCanonicalize (H12AffineFastState.compose env1436 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound1436 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env1437 : List Nat := [2,4,8,16,32,17,41,256,512,817,783,814,56,782,309,279,783,814,817,309,286,32,16,34,25,16,783,782,814,815,817,1,256,0,782,512]

theorem envBound1437 : H12AffineFastState.Bounded env1437 := by
  intro p hp
  have h : env1437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1436_1437 : H12AffineEnvironment.transform 9 817 env1436 = env1437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env1436 == env1437) = true)

theorem identity1437 : scanCanonicalize (H12AffineFastState.compose env1437 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound1437 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1438 : List Nat := [2,4,8,16,32,17,41,256,271,62,0,33,56,1,309,279,0,33,62,309,286,32,16,34,25,16,0,1,33,32,62,1,256,0,1,271]

theorem envBound1438 : H12AffineFastState.Bounded env1438 := by
  intro p hp
  have h : env1438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1437_1438 : H12AffineEnvironment.transform 8 271 env1437 = env1438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env1437 == env1438) = true)

theorem identity1438 : scanCanonicalize (H12AffineFastState.compose env1438 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1438 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env1439 : List Nat := [2,4,8,16,32,17,41,4,11,62,0,33,56,1,49,19,0,33,62,49,26,32,16,34,25,16,0,1,33,32,62,1,4,0,1,11]

theorem envBound1439 : H12AffineFastState.Bounded env1439 := by
  intro p hp
  have h : env1439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1438_1439 : H12AffineEnvironment.transform 7 4 env1438 = env1439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1438 == env1439) = true)

theorem identity1439 : scanCanonicalize (H12AffineFastState.compose env1439 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound1439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1440 : List Nat := [2,4,8,16,17,17,24,4,11,15,0,16,9,1,0,19,0,16,15,0,26,17,16,19,25,16,0,1,16,17,15,1,4,0,1,11]

theorem envBound1440 : H12AffineFastState.Bounded env1440 := by
  intro p hp
  have h : env1440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1439_1440 : H12AffineEnvironment.transform 4 17 env1439 = env1440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1439 == env1440) = true)

theorem identity1440 : scanCanonicalize (H12AffineFastState.compose env1440 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1441 : List Nat := [2,4,4,16,17,17,20,4,7,3,0,16,5,1,0,19,0,16,3,0,22,17,16,19,21,16,0,1,16,17,3,1,4,0,1,7]

theorem envBound1441 : H12AffineFastState.Bounded env1441 := by
  intro p hp
  have h : env1441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1440_1441 : H12AffineEnvironment.transform 2 4 env1440 = env1441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1440 == env1441) = true)

def env1442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,5377,33,147520,139,8328,147473,409816,16384,151553,2080,75134,147705,256,0,131073,148217]

theorem envBound1442 : H12AffineFastState.Bounded env1442 := by
  intro p hp
  have h : env1442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1426_1442 : H12AffineEnvironment.transform 21 33 env1426 = env1442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env1426 == env1442) = true)

theorem identity1442 : scanCanonicalize (H12AffineFastState.compose env1442 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1442 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,5377,33,147520,139,8328,147473,409816,16384,151553,2080,1024,147705,256,0,131073,148217]

theorem envBound1443 : H12AffineFastState.Bounded env1443 := by
  intro p hp
  have h : env1443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1442_1443 : H12AffineEnvironment.transform 15 8574 env1442 = env1443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1442 == env1443) = true)

theorem identity1443 : scanCanonicalize (H12AffineFastState.compose env1443 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1443 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env1444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1024,8693,5377,33,185,139,8328,232,262177,16384,4344,2080,1024,0,256,0,16632,512]

theorem envBound1444 : H12AffineFastState.Bounded env1444 := by
  intro p hp
  have h : env1444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1443_1444 : H12AffineEnvironment.transform 16 16633 env1443 = env1444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1443 == env1444) = true)

def env1445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16852468,4341977,257,0,34359738368,16925299]

theorem envBound1445 : H12AffineFastState.Bounded env1445 := by
  intro p hp
  have h : env1445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1403_1445 : H12AffineEnvironment.transform 18 1025 env1403 = env1445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1403 == env1445) = true)

def env1446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2080,16852468,4341977,257,0,131072,16925299]

theorem envBound1446 : H12AffineFastState.Bounded env1446 := by
  intro p hp
  have h : env1446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1