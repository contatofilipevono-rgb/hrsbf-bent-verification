import H12CloudChart1Data183

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound46623 : H12AffineFastState.Bounded env46623 := by
  intro p hp
  have h : env46623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46622_46623 : H12AffineEnvironment.transform 20 4160 env46622 = env46623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46622 == env46623) = true)

def env46624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,73755,73736,8192,64,496947,46157,77835,505115,99331,32,256,98679,79194,41821]

theorem envBound46624 : H12AffineFastState.Bounded env46624 := by
  intro p hp
  have h : env46624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46623_46624 : H12AffineEnvironment.transform 6 8 env46623 = env46624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46623 == env46624) = true)

theorem identity46624 : scanCanonicalize (H12AffineFastState.compose env46624 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound46624 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79130,262144,1024,32769,4160,33,73755,73736,8192,64,303145,46157,77835,294913,99331,32,256,98679,79194,41821]

theorem envBound46625 : H12AffineFastState.Bounded env46625 := by
  intro p hp
  have h : env46625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46624_46625 : H12AffineEnvironment.transform 16 79130 env46624 = env46625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env46624 == env46625) = true)

theorem identity46625 : scanCanonicalize (H12AffineFastState.compose env46625 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound46625 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env46626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,46156,262144,1024,32769,4160,33,41293,41310,8192,64,303145,46157,45405,294913,1365,32,256,33,46092,41821]

theorem envBound46626 : H12AffineFastState.Bounded env46626 := by
  intro p hp
  have h : env46626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46625_46626 : H12AffineEnvironment.transform 15 33110 env46625 = env46626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env46625 == env46626) = true)

theorem identity46626 : scanCanonicalize (H12AffineFastState.compose env46626 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46626 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env46627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,46156,10281,1024,32769,4160,33,41293,41310,8192,64,34816,46157,45405,43048,1365,32,256,33,46092,41821]

theorem envBound46627 : H12AffineFastState.Bounded env46627 := by
  intro p hp
  have h : env46627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46626_46627 : H12AffineEnvironment.transform 17 10281 env46626 = env46627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46626 == env46627) = true)

theorem identity46627 : scanCanonicalize (H12AffineFastState.compose env46627 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound46627 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8312,8494,5172,10281,1024,8313,4160,33,309,294,8192,64,10360,5173,4389,2128,1365,32,256,33,5236,805]

theorem envBound46628 : H12AffineFastState.Bounded env46628 := by
  intro p hp
  have h : env46628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46627_46628 : H12AffineEnvironment.transform 14 8312 env46627 = env46628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env46627 == env46628) = true)

theorem identity46628 : scanCanonicalize (H12AffineFastState.compose env46628 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound46628 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5376,113,295,5172,2080,1024,112,4160,33,309,294,9,64,2161,5173,4389,2128,1365,32,256,33,5236,805]

theorem envBound46629 : H12AffineFastState.Bounded env46629 := by
  intro p hp
  have h : env46629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46628_46629 : H12AffineEnvironment.transform 12 9 env46628 = env46629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env46628 == env46629) = true)

theorem identity46629 : scanCanonicalize (H12AffineFastState.compose env46629 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46629 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46630 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,9,5157,113,2,5172,2080,1024,112,4160,33,16,3,9,64,2161,5173,4096,2128,1136,32,37,33,5236,512]

theorem envBound46630 : H12AffineFastState.Bounded env46630 := by
  intro p hp
  have h : env46630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46629_46630 : H12AffineEnvironment.transform 7 37 env46629 = env46630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46629 == env46630) = true)

theorem identity46630 : scanCanonicalize (H12AffineFastState.compose env46630 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46630 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46631 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,9,5157,32,2,5172,2080,1024,33,4113,33,16,3,9,17,2080,5173,4096,2049,1057,32,37,33,5157,512]

theorem envBound46631 : H12AffineFastState.Bounded env46631 := by
  intro p hp
  have h : env46631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46630_46631 : H12AffineEnvironment.transform 5 17 env46630 = env46631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46630 == env46631) = true)

theorem identity46631 : scanCanonicalize (H12AffineFastState.compose env46631 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound46631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46632 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,1061,9,0,32,2,17,2080,1024,33,1076,33,16,3,9,17,2080,16,1061,2049,1057,32,37,33,0,512]

theorem envBound46632 : H12AffineFastState.Bounded env46632 := by
  intro p hp
  have h : env46632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46631_46632 : H12AffineEnvironment.transform 11 1061 env46631 = env46632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env46631 == env46632) = true)

theorem identity46632 : scanCanonicalize (H12AffineFastState.compose env46632 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 575) := by decide +kernel

theorem selectedBound46632 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env46633 : List Nat := [2,4,8,16,32,17,8,37,512,1024,575,1061,9,0,32,2,17,543,1024,33,1076,33,16,3,9,17,543,16,1061,574,1057,32,37,33,0,512]

theorem envBound46633 : H12AffineFastState.Bounded env46633 := by
  intro p hp
  have h : env46633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46632_46633 : H12AffineEnvironment.transform 10 575 env46632 = env46633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 575 env46632 == env46633) = true)

theorem identity46633 : scanCanonicalize (H12AffineFastState.compose env46633 (packedSelected [0,1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46633 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env46634 : List Nat := [2,4,8,16,32,17,8,37,512,20,575,49,9,0,32,2,17,543,20,33,32,33,16,3,9,17,543,16,49,574,53,32,37,33,0,512]

theorem envBound46634 : H12AffineFastState.Bounded env46634 := by
  intro p hp
  have h : env46634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46633_46634 : H12AffineEnvironment.transform 9 20 env46633 = env46634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46633 == env46634) = true)

theorem identity46634 : scanCanonicalize (H12AffineFastState.compose env46634 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound46634 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46635 : List Nat := [2,4,8,5,32,4,8,37,512,1,554,36,9,0,32,2,4,522,1,33,32,33,5,3,9,4,522,5,36,555,32,32,37,33,0,512]

theorem envBound46635 : H12AffineFastState.Bounded env46635 := by
  intro p hp
  have h : env46635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46634_46635 : H12AffineEnvironment.transform 3 5 env46634 = env46635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env46634 == env46635) = true)

theorem identity46635 : scanCanonicalize (H12AffineFastState.compose env46635 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound46635 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env46636 : List Nat := [2,4,8,5,32,4,8,37,8,1,34,36,9,0,32,2,4,2,1,33,32,33,5,3,9,4,2,5,36,35,32,32,37,33,0,8]

theorem envBound46636 : H12AffineFastState.Bounded env46636 := by
  intro p hp
  have h : env46636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46635_46636 : H12AffineEnvironment.transform 8 8 env46635 = env46636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env46635 == env46636) = true)

theorem identity46636 : scanCanonicalize (H12AffineFastState.compose env46636 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46636 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env46637 : List Nat := [1,4,8,5,32,4,8,37,8,1,33,36,9,0,32,1,4,1,1,33,32,33,5,0,9,4,1,5,36,32,32,32,37,33,0,8]

theorem envBound46637 : H12AffineFastState.Bounded env46637 := by
  intro p hp
  have h : env46637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46636_46637 : H12AffineEnvironment.transform 0 1 env46636 = env46637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46636 == env46637) = true)

theorem identity46637 : scanCanonicalize (H12AffineFastState.compose env46637 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46638 : List Nat := [1,4,8,5,0,4,8,5,8,1,1,4,9,0,0,1,4,1,1,1,0,1,5,0,9,4,1,5,4,0,0,0,5,1,0,8]

theorem envBound46638 : H12AffineFastState.Bounded env46638 := by
  intro p hp
  have h : env46638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46637_46638 : H12AffineEnvironment.transform 4 0 env46637 = env46638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46637 == env46638) = true)

def env46639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73754,73736,8193,64,496947,46156,77834,505114,99330,32,256,98679,79195,41821]

theorem envBound46639 : H12AffineFastState.Bounded env46639 := by
  intro p hp
  have h : env46639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46623_46639 : H12AffineEnvironment.transform 6 9 env46623 = env46639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46623 == env46639) = true)

theorem identity46639 : scanCanonicalize (H12AffineFastState.compose env46639 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound46639 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103494,262144,1024,32769,4160,32,73754,73736,8193,64,262517,46156,77834,270684,99330,32,256,98679,79195,41821]

theorem envBound46640 : H12AffineFastState.Bounded env46640 := by
  intro p hp
  have h : env46640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46639_46640 : H12AffineEnvironment.transform 16 103494 env46639 = env46640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env46639 == env46640) = true)

theorem identity46640 : scanCanonicalize (H12AffineFastState.compose env46640 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound46640 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env46641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103494,35189,1024,32769,4160,32,73754,73736,8193,64,34816,46156,77834,43049,99330,32,256,98679,79195,41821]

theorem envBound46641 : H12AffineFastState.Bounded env46641 := by
  intro p hp
  have h : env46641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46640_46641 : H12AffineEnvironment.transform 17 35189 env46640 = env46641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env46640 == env46641) = true)

theorem identity46641 : scanCanonicalize (H12AffineFastState.compose env46641 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound46641 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33030,5440,35189,1024,32769,4160,32,41244,41230,8193,64,34816,46156,45324,43049,1284,32,256,113,46173,41821]

theorem envBound46642 : H12AffineFastState.Bounded env46642 := by
  intro p hp
  have h : env46642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46641_46642 : H12AffineEnvironment.transform 15 33030 env46641 = env46642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env46641 == env46642) = true)

theorem identity46642 : scanCanonicalize (H12AffineFastState.compose env46642 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46642 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env46643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,33030,5440,35189,1024,32769,4160,32,32785,32771,268,64,34816,38209,36865,35108,1284,32,256,113,38224,33360]

theorem envBound46643 : H12AffineFastState.Bounded env46643 := by
  intro p hp
  have h : env46643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46642_46643 : H12AffineEnvironment.transform 12 269 env46642 = env46643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46642 == env46643) = true)

theorem identity46643 : scanCanonicalize (H12AffineFastState.compose env46643 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46643 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env46644 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,33030,5392,35109,1024,32769,4112,32,32785,32771,268,16,34816,38161,36865,35108,1284,32,256,33,38144,33280]

theorem envBound46644 : H12AffineFastState.Bounded env46644 := by
  intro p hp
  have h : env46644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46643_46644 : H12AffineEnvironment.transform 5 16 env46643 = env46644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46643 == env46644) = true)

theorem identity46644 : scanCanonicalize (H12AffineFastState.compose env46644 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 6965) := by decide +kernel

theorem selectedBound46644 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46645 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,6965,6707,5392,4624,1024,6964,4112,32,6948,6966,268,16,4917,3620,2868,4625,1284,32,256,33,3637,6453]

theorem envBound46645 : H12AffineFastState.Bounded env46645 := by
  intro p hp
  have h : env46645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46644_46645 : H12AffineEnvironment.transform 14 6965 env46644 = env46645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6965 env46644 == env46645) = true)

theorem identity46645 : scanCanonicalize (H12AffineFastState.compose env46645 (packedSelected [0,3,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound46645 : packedSelected [0,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env46646 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1557,269,789,3360,3110,773,1029,1024,3361,1541,32,3377,3363,268,16,1312,3620,2868,1028,1284,32,256,33,3637,3872]

theorem envBound46646 : H12AffineFastState.Bounded env46646 := by
  intro p hp
  have h : env46646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46645_46646 : H12AffineEnvironment.transform 11 1557 env46645 = env46646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env46645 == env46646) = true)

theorem identity46646 : scanCanonicalize (H12AffineFastState.compose env46646 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46646 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env46647 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,545,269,789,2324,2066,773,49,52,2325,561,32,2309,2327,268,16,276,2576,2868,48,304,32,256,33,2561,2836]

theorem envBound46647 : H12AffineFastState.Bounded env46647 := by
  intro p hp
  have h : env46647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46646_46647 : H12AffineEnvironment.transform 9 52 env46646 = env46647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46646 == env46647) = true)

theorem identity46647 : scanCanonicalize (H12AffineFastState.compose env46647 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46647 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46648 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,545,41,561,2096,2066,545,49,52,2097,561,32,2081,2099,40,16,48,2576,2576,48,20,32,36,33,2561,2608]

theorem envBound46648 : H12AffineFastState.Bounded env46648 := by
  intro p hp
  have h : env46648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46647_46648 : H12AffineEnvironment.transform 7 36 env46647 = env46648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46647 == env46648) = true)

theorem identity46648 : scanCanonicalize (H12AffineFastState.compose env46648 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46648 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46649 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,512,8,528,2065,2066,512,16,21,2064,528,1,2048,2066,9,16,17,2576,2576,17,20,1,5,0,2561,2577]

theorem envBound46649 : H12AffineFastState.Bounded env46649 := by
  intro p hp
  have h : env46649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46648_46649 : H12AffineEnvironment.transform 4 1 env46648 = env46649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46648 == env46649) = true)

theorem identity46649 : scanCanonicalize (H12AffineFastState.compose env46649 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound46649 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46650 : List Nat := [2,4,8,16,1,16,9,5,16,21,2048,16,8,0,2065,2066,16,16,21,2064,0,1,2048,2066,9,16,17,2048,2048,17,20,1,5,0,2065,2049]

theorem envBound46650 : H12AffineFastState.Bounded env46650 := by
  intro p hp
  have h : env46650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46649_46650 : H12AffineEnvironment.transform 8 16 env46649 = env46650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46649 == env46650) = true)

theorem identity46650 : scanCanonicalize (H12AffineFastState.compose env46650 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound46650 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46651 : List Nat := [2,4,8,16,1,16,9,5,16,21,17,16,8,0,0,3,16,16,21,1,0,1,17,3,9,16,17,17,17,17,20,1,5,0,0,16]

theorem envBound46651 : H12AffineFastState.Bounded env46651 := by
  intro p hp
  have h : env46651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46650_46651 : H12AffineEnvironment.transform 10 17 env46650 = env46651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env46650 == env46651) = true)

theorem identity46651 : scanCanonicalize (H12AffineFastState.compose env46651 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46652 : List Nat := [2,4,8,1,1,1,9,5,1,4,0,1,8,0,0,3,1,1,4,1,0,1,0,3,9,1,0,0,0,0,5,1,5,0,0,1]

theorem envBound46652 : H12AffineFastState.Bounded env46652 := by
  intro p hp
  have h : env46652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46651_46652 : H12AffineEnvironment.transform 3 1 env46651 = env46652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46651 == env46652) = true)

theorem identity46652 : scanCanonicalize (H12AffineFastState.compose env46652 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound46652 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46653 : List Nat := [2,4,6,1,1,1,7,5,1,4,0,1,6,0,0,3,1,1,4,1,0,1,0,3,7,1,0,0,0,0,5,1,5,0,0,1]

theorem envBound46653 : H12AffineFastState.Bounded env46653 := by
  intro p hp
  have h : env46653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46652_46653 : H12AffineEnvironment.transform 2 6 env46652 = env46653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env46652 == env46653) = true)

def env46654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175048,8328,64,2590066,46277,77955,2598355,99466,2101344,256,2199863,2172307,41820]

theorem envBound46654 : H12AffineFastState.Bounded env46654 := by
  intro p hp
  have h : env46654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46621_46654 : H12AffineEnvironment.transform 13 5377 env46621 = env46654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46621 == env46654) = true)

def env46655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101344,2175066,2175048,8192,64,2590066,46157,77835,2598235,99330,2101344,256,2199863,2172187,41820]

theorem envBound46655 : H12AffineFastState.Bounded env46655 := by
  intro p hp
  have h : env46655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46654_46655 : H12AffineEnvironment.transform 6 8 env46654 = env46655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46654 == env46655) = true)

theorem identity46655 : scanCanonicalize (H12AffineFastState.compose env46655 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46655 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,2097152,2101344,2175066,2175048,8192,64,2565167,5392,77835,2556934,75103,2101344,256,2175082,2172187,513]

theorem envBound46656 : H12AffineFastState.Bounded env46656 := by
  intro p hp
  have h : env46656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46655_46656 : H12AffineEnvironment.transform 14 8541 env46655 = env46656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46655 == env46656) = true)

theorem identity46656 : scanCanonicalize (H12AffineFastState.compose env46656 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound46656 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,262144,1024,8540,2097152,2101344,2175066,2175048,8192,64,2363700,5392,77835,2371869,75103,2101344,256,2175082,2172187,513]

theorem envBound46657 : H12AffineFastState.Bounded env46657 := by
  intro p hp
  have h : env46657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46656_46657 : H12AffineEnvironment.transform 16 79131 env46656 = env46657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env46656 == env46657) = true)

theorem identity46657 : scanCanonicalize (H12AffineFastState.compose env46657 (packedSelected [7,14,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46657 : packedSelected [7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env46658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,65536,70679,262144,1024,80,2097152,2101344,2167126,2167108,268,64,2363700,5392,69895,2363409,66643,2101344,256,2167142,2163735,513]

theorem envBound46658 : H12AffineFastState.Bounded env46658 := by
  intro p hp
  have h : env46658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46657_46658 : H12AffineEnvironment.transform 12 268 env46657 = env46658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46657 == env46658) = true)

theorem identity46658 : scanCanonicalize (H12AffineFastState.compose env46658 (packedSelected [0,1,2,5,6,7,8,20,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound46658 : packedSelected [0,1,2,5,6,7,8,20,21,24] rootPS < 2^1333 := by decide +kernel

def env46659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,65536,70679,3172,1024,80,2097152,2101344,2167126,2167108,268,64,2104656,5392,69895,2104437,66643,2101344,256,2167142,2163735,513]

theorem envBound46659 : H12AffineFastState.Bounded env46659 := by
  intro p hp
  have h : env46659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46658_46659 : H12AffineEnvironment.transform 17 3172 env46658 = env46659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env46658 == env46659) = true)

theorem identity46659 : scanCanonicalize (H12AffineFastState.compose env46659 (packedSelected [3,4,5,9,10,14,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound46659 : packedSelected [3,4,5,9,10,14,20,21] rootPS < 2^1333 := by decide +kernel

def env46660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,1046,4097,3172,1024,80,2097152,2101344,2102592,2102610,268,64,2104656,5392,5393,2104437,69,2101344,256,2102640,2097153,513]

theorem envBound46660 : H12AffineFastState.Bounded env46660 := by
  intro p hp
  have h : env46660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46659_46660 : H12AffineEnvironment.transform 15 1046 env46659 = env46660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env46659 == env46660) = true)

theorem identity46660 : scanCanonicalize (H12AffineFastState.compose env46660 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46660 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46661 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,268,4160,81,343,4097,2341,321,80,2097152,2101344,2101249,2101267,268,64,2103313,4177,4176,2103604,69,2101344,256,2101297,2097153,513]

theorem envBound46661 : H12AffineFastState.Bounded env46661 := by
  intro p hp
  have h : env46661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46660_46661 : H12AffineEnvironment.transform 9 321 env46660 = env46661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46660 == env46661) = true)

theorem identity46661 : scanCanonicalize (H12AffineFastState.compose env46661 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 1) := by decide +kernel

theorem selectedBound46661 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env46662 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,268,4160,81,343,4097,2341,321,80,1,4193,4096,4114,268,64,6160,4177,4176,6453,69,4193,256,4144,0,513]

theorem envBound46662 : H12AffineFastState.Bounded env46662 := by
  intro p hp
  have h : env46662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46661_46662 : H12AffineEnvironment.transform 20 1 env46661 = env46662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1 env46661 == env46662) = true)

theorem identity46662 : scanCanonicalize (H12AffineFastState.compose env46662 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound46662 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46663 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2357,268,2421,81,343,2356,2341,321,80,1,2388,2357,2343,268,64,293,2404,2405,0,69,2388,256,2309,0,513]

theorem envBound46663 : H12AffineFastState.Bounded env46663 := by
  intro p hp
  have h : env46663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46662_46663 : H12AffineEnvironment.transform 11 2357 env46662 = env46663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env46662 == env46663) = true)

theorem identity46663 : scanCanonicalize (H12AffineFastState.compose env46663 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound46663 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env46664 : List Nat := [2,4,8,16,32,64,8,256,512,321,80,357,268,293,81,343,356,373,321,80,1,260,357,375,268,64,293,308,309,0,69,260,256,341,0,513]

theorem envBound46664 : H12AffineFastState.Bounded env46664 := by
  intro p hp
  have h : env46664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46663_46664 : H12AffineEnvironment.transform 10 80 env46663 = env46664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env46663 == env46664) = true)

theorem identity46664 : scanCanonicalize (H12AffineFastState.compose env46664 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound46664 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46665 : List Nat := [2,4,8,16,32,64,8,256,64,321,80,357,268,293,81,343,356,373,321,80,1,260,357,375,268,64,293,308,309,0,69,260,256,341,0,65]

theorem envBound46665 : H12AffineFastState.Bounded env46665 := by
  intro p hp
  have h : env46665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46664_46665 : H12AffineEnvironment.transform 8 64 env46664 = env46665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env46664 == env46665) = true)

theorem identity46665 : scanCanonicalize (H12AffineFastState.compose env46665 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46665 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env46666 : List Nat := [2,4,8,16,32,16,8,256,16,273,0,309,268,293,1,263,308,293,273,0,1,260,309,295,268,16,293,308,309,0,21,260,256,261,0,17]

theorem envBound46666 : H12AffineFastState.Bounded env46666 := by
  intro p hp
  have h : env46666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46665_46666 : H12AffineEnvironment.transform 5 16 env46665 = env46666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46665 == env46666) = true)

theorem identity46666 : scanCanonicalize (H12AffineFastState.compose env46666 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46666 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env46667 : List Nat := [2,4,8,16,32,16,8,37,16,52,0,16,41,0,1,34,17,0,52,0,1,33,16,2,41,16,0,17,16,0,21,33,37,32,0,17]

theorem envBound46667 : H12AffineFastState.Bounded env46667 := by
  intro p hp
  have h : env46667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46666_46667 : H12AffineEnvironment.transform 7 37 env46666 = env46667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46666 == env46667) = true)

theorem identity46667 : scanCanonicalize (H12AffineFastState.compose env46667 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46668 : List Nat := [2,4,8,16,10,16,8,15,16,30,0,16,3,0,1,8,17,0,30,0,1,11,16,2,3,16,0,17,16,0,21,11,15,10,0,17]

theorem envBound46668 : H12AffineFastState.Bounded env46668 := by
  intro p hp
  have h : env46668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46667_46668 : H12AffineEnvironment.transform 4 10 env46667 = env46668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46667 == env46668) = true)

theorem identity46668 : scanCanonicalize (H12AffineFastState.compose env46668 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46669 : List Nat := [2,4,8,1,10,1,8,15,1,15,0,1,3,0,1,8,0,0,15,0,1,11,1,2,3,1,0,0,1,0,4,11,15,10,0,0]

theorem envBound46669 : H12AffineFastState.Bounded env46669 := by
  intro p hp
  have h : env46669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46668_46669 : H12AffineEnvironment.transform 3 1 env46668 = env46669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46668 == env46669) = true)

def env46670 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101345,2175067,2175048,8193,64,2590066,46156,77834,2598234,99331,2101344,256,2199863,2172186,41820]

theorem envBound46670 : H12AffineFastState.Bounded env46670 := by
  intro p hp
  have h : env46670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46654_46670 : H12AffineEnvironment.transform 6 9 env46654 = env46670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46654 == env46670) = true)

def env46671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,2097152,2101345,2175067,2175048,8193,64,2338138,46156,77834,2329970,99331,2101344,256,2199863,2172186,41820]

theorem envBound46671 : H12AffineFastState.Bounded env46671 := by
  intro p hp
  have h : env46671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46670_46671 : H12AffineEnvironment.transform 17 10280 env46670 = env46671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46670 == env46671) = true)

theorem identity46671 : scanCanonicalize (H12AffineFastState.compose env46671 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound46671 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,77899,73770,16,3,8193,64,171281,46156,77834,179513,99331,73771,256,41340,5457,41820]

theorem envBound46672 : H12AffineFastState.Bounded env46672 := by
  intro p hp
  have h : env46672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46671_46672 : H12AffineEnvironment.transform 20 77899 env46671 = env46672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env46671 == env46672) = true)

theorem identity46672 : scanCanonicalize (H12AffineFastState.compose env46672 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound46672 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103494,10280,1024,32769,77899,73770,16,3,8193,64,67927,46156,77834,76159,99331,73771,256,41340,5457,41820]

theorem envBound46673 : H12AffineFastState.Bounded env46673 := by
  intro p hp
  have h : env46673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46672_46673 : H12AffineEnvironment.transform 16 103494 env46672 = env46673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env46672 == env46673) = true)

theorem identity46673 : scanCanonicalize (H12AffineFastState.compose env46673 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 33862) := by decide +kernel

theorem selectedBound46673 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env46674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33862,4096,10280,1024,32769,46093,42092,16,3,8193,64,36113,46156,46156,44345,69,42093,256,41340,5457,41820]

theorem envBound46674 : H12AffineFastState.Bounded env46674 := by
  intro p hp
  have h : env46674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46673_46674 : H12AffineEnvironment.transform 15 33862 env46673 = env46674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33862 env46673 == env46674) = true)

theorem identity46674 : scanCanonicalize (H12AffineFastState.compose env46674 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 9529) := by decide +kernel

theorem selectedBound46674 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env46675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9529,8575,4096,10280,1024,9528,4404,341,16,3,8193,64,10280,4469,4469,2048,69,340,256,1093,5457,1637]

theorem envBound46675 : H12AffineFastState.Bounded env46675 := by
  intro p hp
  have h : env46675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46674_46675 : H12AffineEnvironment.transform 14 9529 env46674 = env46675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9529 env46674 == env46675) = true)

theorem identity46675 : scanCanonicalize (H12AffineFastState.compose env46675 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46675 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env46676 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8233,8575,4096,10280,272,8232,4404,341,16,3,8193,64,10280,4469,4469,2048,69,340,256,341,4161,885]

theorem envBound46676 : H12AffineFastState.Bounded env46676 := by
  intro p hp
  have h : env46676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46675_46676 : H12AffineEnvironment.transform 9 272 env46675 = env46676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46675 == env46676) = true)

theorem identity46676 : scanCanonicalize (H12AffineFastState.compose env46676 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound46676 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env46677 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2404,8192,2421,8233,8575,2404,10280,272,8232,2128,341,16,3,8193,64,10280,2065,2065,2048,69,340,256,341,2341,885]

theorem envBound46677 : H12AffineFastState.Bounded env46677 := by
  intro p hp
  have h : env46677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46676_46677 : H12AffineEnvironment.transform 11 2404 env46676 = env46677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env46676 == env46677) = true)

theorem identity46677 : scanCanonicalize (H12AffineFastState.compose env46677 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound46677 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env46678 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2065,8192,2048,8233,8202,2065,10280,101,8232,2128,32,16,3,8193,64,10280,2065,2065,2048,69,33,117,32,2128,512]

theorem envBound46678 : H12AffineFastState.Bounded env46678 := by
  intro p hp
  have h : env46678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46677_46678 : H12AffineEnvironment.transform 7 117 env46677 = env46678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46677 == env46678) = true)

theorem identity46678 : scanCanonicalize (H12AffineFastState.compose env46678 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound46678 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46679 : List Nat := [2,4,8,16,32,49,9,4,512,20,2048,2065,8192,2048,8233,8202,2065,10280,20,8232,2081,32,16,3,8193,49,10280,2065,2065,2048,52,33,4,32,2081,512]

theorem envBound46679 : H12AffineFastState.Bounded env46679 := by
  intro p hp
  have h : env46679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46678_46679 : H12AffineEnvironment.transform 5 49 env46678 = env46679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env46678 == env46679) = true)

theorem identity46679 : scanCanonicalize (H12AffineFastState.compose env46679 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound46679 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env46680 : List Nat := [2,4,8,16,21,4,9,4,512,20,2048,2065,8192,2048,8220,8202,2065,10269,20,8221,2068,21,16,3,8193,4,10269,2065,2065,2048,1,20,4,21,2068,512]

theorem envBound46680 : H12AffineFastState.Bounded env46680 := by
  intro p hp
  have h : env46680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46679_46680 : H12AffineEnvironment.transform 4 21 env46679 = env46680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env46679 == env46680) = true)

theorem identity46680 : scanCanonicalize (H12AffineFastState.compose env46680 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound46680 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46681 : List Nat := [2,4,8,16,21,4,9,4,512,20,2048,2065,8,2048,20,2,2065,2069,20,21,2068,21,16,3,9,4,2069,2065,2065,2048,1,20,4,21,2068,512]

theorem envBound46681 : H12AffineFastState.Bounded env46681 := by
  intro p hp
  have h : env46681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46680_46681 : H12AffineEnvironment.transform 12 8 env46680 = env46681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env46680 == env46681) = true)

theorem identity46681 : scanCanonicalize (H12AffineFastState.compose env46681 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound46681 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46682 : List Nat := [2,4,8,5,0,4,9,4,512,1,2048,2052,8,2048,1,2,2052,2048,1,0,2049,0,5,3,9,4,2048,2052,2052,2048,1,1,4,0,2049,512]

theorem envBound46682 : H12AffineFastState.Bounded env46682 := by
  intro p hp
  have h : env46682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46681_46682 : H12AffineEnvironment.transform 3 5 env46681 = env46682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env46681 == env46682) = true)

theorem identity46682 : scanCanonicalize (H12AffineFastState.compose env46682 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46683 : List Nat := [2,4,8,5,0,4,9,4,0,1,2048,2052,8,2048,1,2,2052,2048,1,0,2049,0,5,3,9,4,2048,2052,2052,2048,1,1,4,0,2049,0]

theorem envBound46683 : H12AffineFastState.Bounded env46683 := by
  intro p hp
  have h : env46683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46682_46683 : H12AffineEnvironment.transform 8 0 env46682 = env46683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46682 == env46683) = true)

def leafEnv46683 : List Nat := [2,4,8,5,0,4,9,4,0,1,2048,2052,8,2048,1,2,2052,2048,1,0,2049,0,5,3,1,9,1,4,2048,2052,2052,2048,1,1,4,0,4,3,2049,0,1,2048,0]

def active46683 : List Nat := [0,1,2,10]

def tree46683 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46683 : H12WitnessSearch.Good tree46683 := H12GlobalWitnessIndex.good

theorem leafIdentity46683 : H12AffineFastState.composeSystem env46683 rootObs = leafEnv46683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46683 rootObs == leafEnv46683) = true)

theorem terminalChecked46683 : H12PackedTerminal.terminalCheckFast leafEnv46683 active46683 tree46683 = true := by decide +kernel

def env46684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,2097152,2101345,2175067,2175048,8193,64,2338139,46156,77834,2329971,99331,2101344,256,2199863,2172186,41820]

theorem envBound46684 : H12AffineFastState.Bounded env46684 := by
  intro p hp
  have h : env46684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46670_46684 : H12AffineEnvironment.transform 17 10281 env46670 = env46684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46670 == env46684) = true)

theorem identity46684 : scanCanonicalize (H12AffineFastState.compose env46684 (packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46684 : packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env46685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,2097152,2101345,2175067,2175048,8193,64,2296838,5393,77834,2305070,75102,2101344,256,2175082,2172186,513]

theorem envBound46685 : H12AffineFastState.Bounded env46685 := by
  intro p hp
  have h : env46685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46684_46685 : H12AffineEnvironment.transform 14 8541 env46684 = env46685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46684 == env46685) = true)

theorem identity46685 : scanCanonicalize (H12AffineFastState.compose env46685 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound46685 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env46686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77851,73850,64,83,8193,64,146461,5393,77834,138293,75102,73851,256,113,5377,513]

theorem envBound46686 : H12AffineFastState.Bounded env46686 := by
  intro p hp
  have h : env46686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46685_46686 : H12AffineEnvironment.transform 20 77851 env46685 = env46686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env46685 == env46686) = true)

theorem identity46686 : scanCanonicalize (H12AffineFastState.compose env46686 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46686 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,10281,1024,8540,4113,112,64,83,8193,64,146461,5393,4096,138293,1364,113,256,113,5377,513]

theorem envBound46687 : H12AffineFastState.Bounded env46687 := by
  intro p hp
  have h : env46687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46686_46687 : H12AffineEnvironment.transform 15 8202 env46686 = env46687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46686 == env46687) = true)

theorem identity46687 : scanCanonicalize (H12AffineFastState.compose env46687 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46687 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env46688 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10281,1024,8461,4113,33,17,2,8193,17,146461,5393,4096,138293,1285,32,256,32,5377,513]

theorem envBound46688 : H12AffineFastState.Bounded env46688 := by
  intro p hp
  have h : env46688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46687_46688 : H12AffineEnvironment.transform 5 17 env46687 = env46688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46687 == env46688) = true)

theorem identity46688 : scanCanonicalize (H12AffineFastState.compose env46688 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46688 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46689 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,13341,10281,1024,8461,4113,33,17,2,8193,17,2048,5393,4096,10280,1285,32,256,32,5377,513]

theorem envBound46689 : H12AffineFastState.Bounded env46689 := by
  intro p hp
  have h : env46689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46688_46689 : H12AffineEnvironment.transform 16 13341 env46688 = env46689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env46688 == env46689) = true)

theorem identity46689 : scanCanonicalize (H12AffineFastState.compose env46689 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound46689 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46690 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,5377,8460,8202,13341,9245,1024,8461,4113,33,17,2,8193,17,1076,5393,4096,9244,1285,32,256,32,5377,513]

theorem envBound46690 : H12AffineFastState.Bounded env46690 := by
  intro p hp
  have h : env46690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46689_46690 : H12AffineEnvironment.transform 10 1076 env46689 = env46690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env46689 == env46690) = true)

theorem identity46690 : scanCanonicalize (H12AffineFastState.compose env46690 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound46690 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46691 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,16,8192,1297,8460,8202,9229,9245,1024,8461,1,33,17,2,8193,17,1076,1281,16,9244,1285,32,256,32,1297,513]

theorem envBound46691 : H12AffineFastState.Bounded env46691 := by
  intro p hp
  have h : env46691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46690_46691 : H12AffineEnvironment.transform 11 16 env46690 = env46691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env46690 == env46691) = true)

theorem identity46691 : scanCanonicalize (H12AffineFastState.compose env46691 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46691 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env46692 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,16,41,1297,293,35,1060,1076,1024,292,1,33,17,2,40,17,1076,1281,16,1077,1285,32,256,32,1297,513]

theorem envBound46692 : H12AffineFastState.Bounded env46692 := by
  intro p hp
  have h : env46692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46691_46692 : H12AffineEnvironment.transform 12 41 env46691 = env46692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46691 == env46692) = true)

theorem identity46692 : scanCanonicalize (H12AffineFastState.compose env46692 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46692 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46693 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,16,41,1076,0,35,1060,1076,1024,1,1,33,17,2,40,17,1076,1060,16,1077,1056,32,37,32,1076,513]

theorem envBound46693 : H12AffineFastState.Bounded env46693 := by
  intro p hp
  have h : env46693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46692_46693 : H12AffineEnvironment.transform 7 37 env46692 = env46693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46692 == env46693) = true)

theorem identity46693 : scanCanonicalize (H12AffineFastState.compose env46693 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46694 : List Nat := [2,4,8,1,32,0,9,37,512,1024,1061,1,41,1061,0,35,1060,1061,1024,1,1,33,0,2,40,0,1061,1060,1,1060,1056,32,37,32,1061,513]

theorem envBound46694 : H12AffineFastState.Bounded env46694 := by
  intro p hp
  have h : env46694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46693_46694 : H12AffineEnvironment.transform 3 1 env46693 = env46694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46693 == env46694) = true)

theorem identity46694 : scanCanonicalize (H12AffineFastState.compose env46694 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound46694 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46695 : List Nat := [2,4,8,1,32,0,9,37,512,548,513,1,41,513,0,35,512,513,548,1,1,33,0,2,40,0,513,512,1,512,516,32,37,32,513,513]

theorem envBound46695 : H12AffineFastState.Bounded env46695 := by
  intro p hp
  have h : env46695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46694_46695 : H12AffineEnvironment.transform 9 548 env46694 = env46695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env46694 == env46695) = true)

def env46696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175049,8328,64,2609266,46276,77955,2598355,119178,2101345,256,2199862,2191507,63068]

theorem envBound46696 : H12AffineFastState.Bounded env46696 := by
  intro p hp
  have h : env46696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46620_46696 : H12AffineEnvironment.transform 23 2175049 env46620 = env46696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env46620 == env46696) = true)

def env46697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175049,8328,64,2590066,46276,77955,2598355,99466,2101345,256,2199862,2172307,41820]

theorem envBound46697 : H12AffineFastState.Bounded env46697 := by
  intro p hp
  have h : env46697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46696_46697 : H12AffineEnvironment.transform 13 5376 env46696 = env46697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46696 == env46697) = true)

theorem identity46697 : scanCanonicalize (H12AffineFastState.compose env46697 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46697 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,2097152,2101481,2175187,2175049,8328,64,2565167,5529,77955,2557070,75223,2101345,256,2175083,2172307,513]

theorem envBound46698 : H12AffineFastState.Bounded env46698 := by
  intro p hp
  have h : env46698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46697_46698 : H12AffineEnvironment.transform 14 8541 env46697 = env46698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46697 == env46698) = true)

def env46699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,2097152,2101481,2175187,2175049,8328,64,2296975,5529,77955,2305070,75223,2101345,256,2175083,2172307,513]

theorem envBound46699 : H12AffineFastState.Bounded env46699 := by
  intro p hp
  have h : env46699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46698_46699 : H12AffineEnvironment.transform 17 10400 env46698 = env46699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46698 == env46699) = true)

def env46700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,2097152,2101345,2175067,2175049,8192,64,2296839,5393,77835,2305070,75103,2101345,256,2175083,2172187,513]

theorem envBound46700 : H12AffineFastState.Bounded env46700 := by
  intro p hp
  have h : env46700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46699_46700 : H12AffineEnvironment.transform 6 8 env46699 = env46700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46699 == env46700) = true)

theorem identity46700 : scanCanonicalize (H12AffineFastState.compose env46700 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound46700 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,79130,10280,1024,8540,2097152,2101345,2175067,2175049,8192,64,2111773,5393,77835,2103604,75103,2101345,256,2175083,2172187,513]

theorem envBound46701 : H12AffineFastState.Bounded env46701 := by
  intro p hp
  have h : env46701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46700_46701 : H12AffineEnvironment.transform 16 79130 env46700 = env46701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env46700 == env46701) = true)

theorem identity46701 : scanCanonicalize (H12AffineFastState.compose env46701 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound46701 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9498,4096,10280,1024,8540,2097152,2101345,2102593,2102611,8192,64,2111773,5393,5393,2103604,69,2101345,256,2102641,2097153,513]

theorem envBound46702 : H12AffineFastState.Bounded env46702 := by
  intro p hp
  have h : env46702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46701_46702 : H12AffineEnvironment.transform 15 9498 env46701 = env46702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env46701 == env46702) = true)

theorem identity46702 : scanCanonicalize (H12AffineFastState.compose env46702 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound46702 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env46703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,3344,8541,9498,2064,10280,1024,8540,2097152,2099313,2100561,2100547,8192,64,2105613,3329,3329,2097444,69,2099313,256,2100577,2097153,513]

theorem envBound46703 : H12AffineFastState.Bounded env46703 := by
  intro p hp
  have h : env46703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46702_46703 : H12AffineEnvironment.transform 11 2064 env46702 = env46703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env46702 == env46703) = true)

def env46704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,2097152,2101344,2175066,2175049,8193,64,2296838,5392,77834,2305070,75102,2101345,256,2175083,2172186,513]

theorem envBound46704 : H12AffineFastState.Bounded env46704 := by
  intro p hp
  have h : env46704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46699_46704 : H12AffineEnvironment.transform 6 9 env46699 = env46704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46699 == env46704) = true)

theorem identity46704 : scanCanonicalize (H12AffineFastState.compose env46704 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 77850) := by decide +kernel

theorem selectedBound46704 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env46705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,77850,73850,64,83,8193,64,146460,5392,77834,138292,75102,73851,256,113,5376,513]

theorem envBound46705 : H12AffineFastState.Bounded env46705 := by
  intro p hp
  have h : env46705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46704_46705 : H12AffineEnvironment.transform 20 77850 env46704 = env46705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77850 env46704 == env46705) = true)

theorem identity46705 : scanCanonicalize (H12AffineFastState.compose env46705 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46705 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10281,1024,8540,4112,112,64,83,8193,64,146460,5392,4096,138292,1364,113,256,113,5376,513]

theorem envBound46706 : H12AffineFastState.Bounded env46706 := by
  intro p hp
  have h : env46706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46705_46706 : H12AffineEnvironment.transform 15 8202 env46705 = env46706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46705 == env46706) = true)

theorem identity46706 : scanCanonicalize (H12AffineFastState.compose env46706 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46706 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env46707 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10281,1024,8461,4112,33,17,2,8193,17,146460,5392,4096,138292,1285,32,256,32,5376,513]

theorem envBound46707 : H12AffineFastState.Bounded env46707 := by
  intro p hp
  have h : env46707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46706_46707 : H12AffineEnvironment.transform 5 17 env46706 = env46707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46706 == env46707) = true)

theorem identity46707 : scanCanonicalize (H12AffineFastState.compose env46707 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound46707 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46708 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10281,1024,8461,4112,33,17,2,8193,17,2048,5392,4096,10280,1285,32,256,32,5376,513]

theorem envBound46708 : H12AffineFastState.Bounded env46708 := by
  intro p hp
  have h : env46708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46707_46708 : H12AffineEnvironment.transform 16 13340 env46707 = env46708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env46707 == env46708) = true)

theorem identity46708 : scanCanonicalize (H12AffineFastState.compose env46708 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound46708 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46709 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3385,5376,3125,3379,6437,1296,1024,3124,4112,33,17,2,3384,17,2048,5392,4096,1297,1285,32,256,32,5376,513]

theorem envBound46709 : H12AffineFastState.Bounded env46709 := by
  intro p hp
  have h : env46709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46708_46709 : H12AffineEnvironment.transform 12 3385 env46708 = env46709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env46708 == env46709) = true)

theorem identity46709 : scanCanonicalize (H12AffineFastState.compose env46709 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound46709 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46710 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,16,3385,1296,3125,3379,2357,1296,1024,3124,0,33,17,2,3384,17,2048,1280,16,1297,1285,32,256,32,1296,513]

theorem envBound46710 : H12AffineFastState.Bounded env46710 := by
  intro p hp
  have h : env46710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46709_46710 : H12AffineEnvironment.transform 11 16 env46709 = env46710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env46709 == env46710) = true)

theorem identity46710 : scanCanonicalize (H12AffineFastState.compose env46710 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46710 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env46711 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,16,3100,1077,3125,3094,2064,1077,1024,3124,0,33,17,2,3101,17,2048,1061,16,1076,1056,32,37,32,1077,513]

theorem envBound46711 : H12AffineFastState.Bounded env46711 := by
  intro p hp
  have h : env46711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46710_46711 : H12AffineEnvironment.transform 7 37 env46710 = env46711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46710 == env46711) = true)

def env46712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,2097152,2101481,2175187,2175049,8328,64,2296974,5529,77955,2305071,75223,2101345,256,2175083,2172307,513]

theorem envBound46712 : H12AffineFastState.Bounded env46712 := by
  intro p hp
  have h : env46712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46698_46712 : H12AffineEnvironment.transform 17 10401 env46698 = env46712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46698 == env46712) = true)

theorem identity46712 : scanCanonicalize (H12AffineFastState.compose env46712 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 78019) := by decide +kernel

theorem selectedBound46712 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,73770,16,138,8328,64,146509,5529,77955,138476,75223,73890,256,168,5456,513]

theorem envBound46713 : H12AffineFastState.Bounded env46713 := by
  intro p hp
  have h : env46713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46712_46713 : H12AffineEnvironment.transform 20 78019 env46712 = env46713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78019 env46712 == env46713) = true)

theorem identity46713 : scanCanonicalize (H12AffineFastState.compose env46713 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound46713 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79130,10401,1024,8540,78019,73770,16,138,8328,64,67927,5529,77955,76278,75223,73890,256,168,5456,513]

theorem envBound46714 : H12AffineFastState.Bounded env46714 := by
  intro p hp
  have h : env46714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46713_46714 : H12AffineEnvironment.transform 16 79130 env46713 = env46714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env46713 == env46714) = true)

theorem identity46714 : scanCanonicalize (H12AffineFastState.compose env46714 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound46714 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,9498,4096,10401,1024,8540,5593,1328,16,138,8328,64,11341,5529,5529,3308,205,1464,256,168,5456,513]

theorem envBound46715 : H12AffineFastState.Bounded env46715 := by
  intro p hp
  have h : env46715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46714_46715 : H12AffineEnvironment.transform 15 9498 env46714 = env46715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env46714 == env46715) = true)

theorem identity46715 : scanCanonicalize (H12AffineFastState.compose env46715 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound46715 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env46716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5376,429,1514,4096,2129,1024,428,5593,1328,16,138,120,64,3261,5529,5529,3308,205,1464,256,168,5456,513]

theorem envBound46716 : H12AffineFastState.Bounded env46716 := by
  intro p hp
  have h : env46716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46715_46716 : H12AffineEnvironment.transform 12 240 env46715 = env46716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env46715 == env46716) = true)

theorem identity46716 : scanCanonicalize (H12AffineFastState.compose env46716 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound46716 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46717 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,240,4588,429,262,4096,2129,236,428,4405,476,16,138,120,64,2129,4469,4469,2048,205,340,256,168,4540,513]

theorem envBound46717 : H12AffineFastState.Bounded env46717 := by
  intro p hp
  have h : env46717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46716_46717 : H12AffineEnvironment.transform 9 236 env46716 = env46717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env46716 == env46717) = true)

theorem identity46717 : scanCanonicalize (H12AffineFastState.compose env46717 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound46717 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env46718 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,2492,240,2128,429,262,2492,2129,236,428,2185,476,16,138,120,64,2129,2249,2249,2048,205,340,256,168,2048,513]

theorem envBound46718 : H12AffineFastState.Bounded env46718 := by
  intro p hp
  have h : env46718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46717_46718 : H12AffineEnvironment.transform 11 2492 env46717 = env46718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env46717 == env46718) = true)

theorem identity46718 : scanCanonicalize (H12AffineFastState.compose env46718 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound46718 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env46719 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,2112,240,2128,81,250,2112,2129,236,80,2185,32,16,138,120,64,2129,2249,2249,2048,205,168,252,168,2048,513]

theorem envBound46719 : H12AffineFastState.Bounded env46719 := by
  intro p hp
  have h : env46719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46718_46719 : H12AffineEnvironment.transform 7 252 env46718 = env46719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46718 == env46719) = true)

theorem identity46719 : scanCanonicalize (H12AffineFastState.compose env46719 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound46719 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46720 : List Nat := [2,4,8,16,32,64,89,37,512,53,2048,2112,41,2128,81,35,2112,2129,53,80,2128,32,16,83,120,64,2129,2064,2064,2048,20,113,37,113,2048,513]

theorem envBound46720 : H12AffineFastState.Bounded env46720 := by
  intro p hp
  have h : env46720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46719_46720 : H12AffineEnvironment.transform 6 89 env46719 = env46720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env46719 == env46720) = true)

theorem identity46720 : scanCanonicalize (H12AffineFastState.compose env46720 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound46720 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46721 : List Nat := [2,4,8,16,32,64,89,37,48,53,2048,2112,41,2128,81,35,2112,2129,53,80,2128,32,16,83,120,64,2129,2064,2064,2048,20,113,37,113,2048,49]

theorem envBound46721 : H12AffineFastState.Bounded env46721 := by
  intro p hp
  have h : env46721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46720_46721 : H12AffineEnvironment.transform 8 48 env46720 = env46721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env46720 == env46721) = true)

theorem identity46721 : scanCanonicalize (H12AffineFastState.compose env46721 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound46721 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46722 : List Nat := [2,4,8,16,32,64,89,37,48,53,80,16,41,0,81,35,16,1,53,80,0,32,16,83,120,64,1,64,64,80,20,113,37,113,80,49]

theorem envBound46722 : H12AffineFastState.Bounded env46722 := by
  intro p hp
  have h : env46722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46721_46722 : H12AffineEnvironment.transform 10 80 env46721 = env46722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env46721 == env46722) = true)

theorem identity46722 : scanCanonicalize (H12AffineFastState.compose env46722 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46722 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46723 : List Nat := [2,4,8,16,32,16,9,37,48,53,0,16,41,0,1,35,16,1,53,0,0,32,16,3,40,16,1,16,16,0,20,33,37,33,0,49]

theorem envBound46723 : H12AffineFastState.Bounded env46723 := by
  intro p hp
  have h : env46723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46722_46723 : H12AffineEnvironment.transform 5 16 env46722 = env46723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46722 == env46723) = true)

theorem identity46723 : scanCanonicalize (H12AffineFastState.compose env46723 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46724 : List Nat := [2,4,8,0,32,0,9,37,32,37,0,0,41,0,1,35,0,1,37,0,0,32,0,3,40,0,1,0,0,0,4,33,37,33,0,33]

theorem envBound46724 : H12AffineFastState.Bounded env46724 := by
  intro p hp
  have h : env46724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46723_46724 : H12AffineEnvironment.transform 3 0 env46723 = env46724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46723 == env46724) = true)

def env46725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175049,8328,64,2590067,46276,77955,2598355,99467,2101345,256,2199862,2172306,41821]

theorem envBound46725 : H12AffineFastState.Bounded env46725 := by
  intro p hp
  have h : env46725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46696_46725 : H12AffineEnvironment.transform 13 5377 env46696 = env46725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46696 == env46725) = true)

theorem identity46725 : scanCanonicalize (H12AffineFastState.compose env46725 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45341) := by decide +kernel

theorem selectedBound46725 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45341,41461,98767,98644,8328,64,472174,46276,77955,464078,99467,41340,256,73771,103567,41821]

theorem envBound46726 : H12AffineFastState.Bounded env46726 := by
  intro p hp
  have h : env46726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46725_46726 : H12AffineEnvironment.transform 20 45341 env46725 = env46726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45341 env46725 == env46726) = true)

def env46727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45341,41341,98631,98644,8192,64,472174,46156,77835,463942,99331,41340,256,73771,103431,41821]

theorem envBound46727 : H12AffineFastState.Bounded env46727 := by
  intro p hp
  have h : env46727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46726_46727 : H12AffineEnvironment.transform 6 8 env46726 = env46727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46726 == env46727) = true)

theorem identity46727 : scanCanonicalize (H12AffineFastState.compose env46727 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound46727 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103495,262144,1024,32769,45341,41341,98631,98644,8192,64,303145,46156,77835,294913,99331,41340,256,73771,103431,41821]

theorem envBound46728 : H12AffineFastState.Bounded env46728 := by
  intro p hp
  have h : env46728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46727_46728 : H12AffineEnvironment.transform 16 103495 env46727 = env46728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env46727 == env46728) = true)

theorem identity46728 : scanCanonicalize (H12AffineFastState.compose env46728 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46728 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,262144,1024,8541,4161,33,73755,73736,8192,64,262517,5392,77835,270685,75103,32,256,73771,79195,513]

theorem envBound46729 : H12AffineFastState.Bounded env46729 := by
  intro p hp
  have h : env46729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46728_46729 : H12AffineEnvironment.transform 14 8540 env46728 = env46729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46728 == env46729) = true)

theorem identity46729 : scanCanonicalize (H12AffineFastState.compose env46729 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46729 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46730 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8313,65536,78910,262144,1024,8312,4161,33,73755,73736,8192,64,262224,5173,77835,270456,74874,32,37,73771,78974,513]

theorem envBound46730 : H12AffineFastState.Bounded env46730 := by
  intro p hp
  have h : env46730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46729_46730 : H12AffineEnvironment.transform 7 37 env46729 = env46730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46729 == env46730) = true)

theorem identity46730 : scanCanonicalize (H12AffineFastState.compose env46730 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound46730 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46731 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8313,9279,4097,262144,1024,8312,4161,33,1060,1079,8192,64,262224,5173,5172,270456,69,32,37,1044,4161,513]

theorem envBound46731 : H12AffineFastState.Bounded env46731 := by
  intro p hp
  have h : env46731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46730_46731 : H12AffineEnvironment.transform 15 9279 env46730 = env46731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env46730 == env46731) = true)

theorem identity46731 : scanCanonicalize (H12AffineFastState.compose env46731 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46731 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46732 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8313,9279,4097,10281,1024,8312,4161,33,1060,1079,8192,64,10361,5173,5172,2129,69,32,37,1044,4161,513]

theorem envBound46732 : H12AffineFastState.Bounded env46732 := by
  intro p hp
  have h : env46732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46731_46732 : H12AffineEnvironment.transform 17 10281 env46731 = env46732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46731 == env46732) = true)

theorem identity46732 : scanCanonicalize (H12AffineFastState.compose env46732 (packedSelected [0,1,3,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3685) := by decide +kernel

theorem selectedBound46732 : packedSelected [0,1,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env46733 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3685,8192,2625,8313,9279,3684,10281,1024,8312,3620,33,1060,1079,8192,64,10361,2640,2641,2129,69,32,37,1044,3620,513]

theorem envBound46733 : H12AffineFastState.Bounded env46733 := by
  intro p hp
  have h : env46733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46732_46733 : H12AffineEnvironment.transform 11 3685 env46732 = env46733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3685 env46732 == env46733) = true)

theorem identity46733 : scanCanonicalize (H12AffineFastState.compose env46733 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound46733 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46734 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1077,592,8192,1652,8313,9279,593,9244,1024,8312,529,33,1060,1079,8192,64,9292,1637,1636,1124,69,32,37,1044,529,513]

theorem envBound46734 : H12AffineFastState.Bounded env46734 := by
  intro p hp
  have h : env46734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46733_46734 : H12AffineEnvironment.transform 10 1077 env46733 = env46734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env46733 == env46734) = true)

theorem identity46734 : scanCanonicalize (H12AffineFastState.compose env46734 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound46734 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env46735 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1077,592,105,1652,16,1110,593,1141,1024,17,529,33,1060,1079,105,64,1061,1637,1636,1124,69,32,37,1044,529,513]

theorem envBound46735 : H12AffineFastState.Bounded env46735 := by
  intro p hp
  have h : env46735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46734_46735 : H12AffineEnvironment.transform 12 105 env46734 = env46735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env46734 == env46735) = true)

theorem identity46735 : scanCanonicalize (H12AffineFastState.compose env46735 (packedSelected [0,1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 628) := by decide +kernel

theorem selectedBound46735 : packedSelected [0,1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env46736 : List Nat := [2,4,8,16,32,64,8,37,512,628,577,592,105,0,16,546,593,513,628,17,529,33,592,579,105,64,593,17,16,528,69,32,37,608,529,513]

theorem envBound46736 : H12AffineFastState.Bounded env46736 := by
  intro p hp
  have h : env46736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46735_46736 : H12AffineEnvironment.transform 9 628 env46735 = env46736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 628 env46735 == env46736) = true)

theorem identity46736 : scanCanonicalize (H12AffineFastState.compose env46736 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound46736 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env46737 : List Nat := [2,4,8,16,32,64,8,37,65,53,0,17,105,0,16,99,16,64,53,17,80,33,17,2,105,64,16,17,16,81,69,32,37,33,80,64]

theorem envBound46737 : H12AffineFastState.Bounded env46737 := by
  intro p hp
  have h : env46737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46736_46737 : H12AffineEnvironment.transform 8 65 env46736 = env46737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env46736 == env46737) = true)

theorem identity46737 : scanCanonicalize (H12AffineFastState.compose env46737 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46738 : List Nat := [2,4,8,16,0,64,8,5,65,21,0,17,73,0,16,67,16,64,21,17,80,1,17,2,73,64,16,17,16,81,69,0,5,1,80,64]

theorem envBound46738 : H12AffineFastState.Bounded env46738 := by
  intro p hp
  have h : env46738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46737_46738 : H12AffineEnvironment.transform 4 0 env46737 = env46738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46737 == env46738) = true)

theorem identity46738 : scanCanonicalize (H12AffineFastState.compose env46738 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound46738 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46739 : List Nat := [2,4,8,16,0,0,8,5,1,21,0,17,9,0,16,3,16,0,21,17,16,1,17,2,9,0,16,17,16,17,5,0,5,1,16,0]

theorem envBound46739 : H12AffineFastState.Bounded env46739 := by
  intro p hp
  have h : env46739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46738_46739 : H12AffineEnvironment.transform 5 0 env46738 = env46739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env46738 == env46739) = true)

theorem identity46739 : scanCanonicalize (H12AffineFastState.compose env46739 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46739 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46740 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,0,9,0,1,3,1,0,4,0,1,1,0,2,9,0,1,0,1,0,5,0,5,1,1,0]

theorem envBound46740 : H12AffineFastState.Bounded env46740 := by
  intro p hp
  have h : env46740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46739_46740 : H12AffineEnvironment.transform 3 1 env46739 = env46740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46739 == env46740) = true)

def env46741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45341,41340,98630,98644,8193,64,472174,46157,77834,463943,99330,41340,256,73771,103430,41821]

theorem envBound46741 : H12AffineFastState.Bounded env46741 := by
  intro p hp
  have h : env46741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46726_46741 : H12AffineEnvironment.transform 6 9 env46726 = env46741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46726 == env46741) = true)

theorem identity46741 : scanCanonicalize (H12AffineFastState.compose env46741 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound46741 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,262144,1024,32769,45341,41340,98630,98644,8193,64,262517,46157,77834,270684,99330,41340,256,73771,103430,41821]

theorem envBound46742 : H12AffineFastState.Bounded env46742 := by
  intro p hp
  have h : env46742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46741_46742 : H12AffineEnvironment.transform 16 79131 env46741 = env46742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env46741 == env46742) = true)

theorem identity46742 : scanCanonicalize (H12AffineFastState.compose env46742 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46742 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env46743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,10281,1024,32769,45341,41340,98630,98644,8193,64,10588,46157,77834,2421,99330,41340,256,73771,103430,41821]

theorem envBound46743 : H12AffineFastState.Bounded env46743 := by
  intro p hp
  have h : env46743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46742_46743 : H12AffineEnvironment.transform 17 10281 env46742 = env46743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46742 == env46743) = true)

theorem identity46743 : scanCanonicalize (H12AffineFastState.compose env46743 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound46743 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,343,13388,10281,1024,32769,45341,41340,32785,32771,8193,64,10588,46157,12637,2421,34133,41340,256,8572,38225,41821]

theorem envBound46744 : H12AffineFastState.Bounded env46744 := by
  intro p hp
  have h : env46744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46743_46744 : H12AffineEnvironment.transform 15 343 env46743 = env46744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env46743 == env46744) = true)

theorem identity46744 : scanCanonicalize (H12AffineFastState.compose env46744 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46744 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env46745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,343,5393,2420,1024,32769,36928,32801,32785,32771,348,64,2049,38160,4096,2421,34133,32801,256,33,38225,33280]

theorem envBound46745 : H12AffineFastState.Bounded env46745 := by
  intro p hp
  have h : env46745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46744_46745 : H12AffineEnvironment.transform 12 349 env46744 = env46745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46744 == env46745) = true)

theorem identity46745 : scanCanonicalize (H12AffineFastState.compose env46745 (packedSelected [2,4,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound46745 : packedSelected [2,4,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46746 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,349,4145,32768,343,4129,2420,304,32769,36928,32801,32785,32771,348,64,2049,36896,4096,2421,32869,32801,256,33,36961,33280]

theorem envBound46746 : H12AffineFastState.Bounded env46746 := by
  intro p hp
  have h : env46746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46745_46746 : H12AffineEnvironment.transform 9 304 env46745 = env46746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env46745 == env46746) = true)

def env46747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound46747 : H12AffineFastState.Bounded env46747 := by
  intro p hp
  have h : env46747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46526_46747 : H12AffineEnvironment.transform 18 1025 env46526 = env46747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env46526 == env46747) = true)

theorem identity46747 : scanCanonicalize (H12AffineFastState.compose env46747 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262354) := by decide +kernel

theorem selectedBound46747 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262354,8328,64,15025490,197086,10507600,8830977,10682690,4448403,257,8602111,8626267,10626709]

theorem envBound46748 : H12AffineFastState.Bounded env46748 := by
  intro p hp
  have h : env46748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46747_46748 : H12AffineEnvironment.transform 23 2262354 env46747 = env46748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262354 env46747 == env46748) = true)

def env46749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025490,115150,10507600,8650769,10600786,4268163,257,8487407,8478795,10544773]

theorem envBound46749 : H12AffineFastState.Bounded env46749 := by
  intro p hp
  have h : env46749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46748_46749 : H12AffineEnvironment.transform 16 49168 env46748 = env46749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env46748 == env46749) = true)

def env46750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543746,115150,17664,2363457,119042,4268163,257,2199999,2191387,63189]

theorem envBound46750 : H12AffineFastState.Bounded env46750 := by
  intro p hp
  have h : env46750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46749_46750 : H12AffineEnvironment.transform 22 2101328 env46749 = env46750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env46749 == env46750) = true)

def env46751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97666,115150,17664,2363457,119042,329731,257,2199999,2191387,63189]

theorem envBound46751 : H12AffineFastState.Bounded env46751 := by
  intro p hp
  have h : env46751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46750_46751 : H12AffineEnvironment.transform 21 272512 env46750 = env46751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46750 == env46751) = true)

def env46752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101328,2114882,8192,64,97546,115014,17664,2363457,119042,329731,257,2199863,2191387,63069]

theorem envBound46752 : H12AffineFastState.Bounded env46752 := by
  intro p hp
  have h : env46752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46751_46752 : H12AffineEnvironment.transform 6 8 env46751 = env46752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46751 == env46752) = true)

def env46753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,16,21762,8192,64,97546,115014,17664,262145,119042,329731,257,98679,90203,63069]

theorem envBound46753 : H12AffineFastState.Bounded env46753 := by
  intro p hp
  have h : env46753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46752_46753 : H12AffineEnvironment.transform 20 4160 env46752 = env46753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46752 == env46753) = true)

theorem identity46753 : scanCanonicalize (H12AffineFastState.compose env46753 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound46753 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env46754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,89459,1025,32769,4160,95611,16,21762,8192,64,97546,115014,17664,89458,119042,21872,257,98679,90203,63069]

theorem envBound46754 : H12AffineFastState.Bounded env46754 := by
  intro p hp
  have h : env46754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46753_46754 : H12AffineEnvironment.transform 17 89459 env46753 = env46754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env46753 == env46754) = true)

theorem identity46754 : scanCanonicalize (H12AffineFastState.compose env46754 (packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound46754 : packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env46755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,13340,89459,1025,29709,4160,95611,16,21762,8192,64,97546,79178,17664,89458,75022,21872,257,95611,90203,593]

theorem envBound46755 : H12AffineFastState.Bounded env46755 := by
  intro p hp
  have h : env46755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46754_46755 : H12AffineEnvironment.transform 14 29708 env46754 = env46755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env46754 == env46755) = true)

theorem identity46755 : scanCanonicalize (H12AffineFastState.compose env46755 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound46755 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env46756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,65536,13340,67619,1025,8541,4160,73771,16,82,8192,64,75866,79178,4176,67618,75022,32,257,73771,79115,593]

theorem envBound46756 : H12AffineFastState.Bounded env46756 := by
  intro p hp
  have h : env46756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46755_46756 : H12AffineEnvironment.transform 13 5456 env46755 = env46756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env46755 == env46756) = true)

theorem identity46756 : scanCanonicalize (H12AffineFastState.compose env46756 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46756 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46757 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,65536,13340,67619,1025,8461,4112,73771,16,2,8192,16,75786,79130,4096,67618,75022,32,257,73771,79115,513]

theorem envBound46757 : H12AffineFastState.Bounded env46757 := by
  intro p hp
  have h : env46757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46756_46757 : H12AffineEnvironment.transform 5 16 env46756 = env46757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46756 == env46757) = true)

theorem identity46757 : scanCanonicalize (H12AffineFastState.compose env46757 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46757 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46758 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10281,1025,8461,4112,33,16,2,8192,16,2048,5392,4096,10280,1284,32,257,33,5377,513]

theorem envBound46758 : H12AffineFastState.Bounded env46758 := by
  intro p hp
  have h : env46758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46757_46758 : H12AffineEnvironment.transform 15 8202 env46757 = env46758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46757 == env46758) = true)

theorem identity46758 : scanCanonicalize (H12AffineFastState.compose env46758 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound46758 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46759 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2097,8192,3377,8460,8202,11309,10281,1025,8461,2081,33,16,2,8192,16,2048,3361,2097,10280,1284,32,257,33,3376,513]

theorem envBound46759 : H12AffineFastState.Bounded env46759 := by
  intro p hp
  have h : env46759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46758_46759 : H12AffineEnvironment.transform 11 2097 env46758 = env46759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env46758 == env46759) = true)

theorem identity46759 : scanCanonicalize (H12AffineFastState.compose env46759 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound46759 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46760 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2097,1305,3377,1045,1299,2356,3376,1025,1044,2081,33,16,2,1305,16,2048,3361,2097,3377,1284,32,257,33,3376,513]

theorem envBound46760 : H12AffineFastState.Bounded env46760 := by
  intro p hp
  have h : env46760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46759_46760 : H12AffineEnvironment.transform 12 1305 env46759 = env46760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env46759 == env46760) = true)

theorem identity46760 : scanCanonicalize (H12AffineFastState.compose env46760 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46760 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env46761 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2097,300,2308,32,294,2356,2309,52,33,2081,33,16,2,300,16,2048,2324,2097,2308,305,32,257,33,2309,513]

theorem envBound46761 : H12AffineFastState.Bounded env46761 := by
  intro p hp
  have h : env46761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46760_46761 : H12AffineEnvironment.transform 9 53 env46760 = env46761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46760 == env46761) = true)

def env46762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21763,8192,64,97546,115014,17664,262144,119042,329731,257,98678,90202,63069]

theorem envBound46762 : H12AffineFastState.Bounded env46762 := by
  intro p hp
  have h : env46762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46752_46762 : H12AffineEnvironment.transform 20 4161 env46752 = env46762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46752 == env46762) = true)

theorem identity46762 : scanCanonicalize (H12AffineFastState.compose env46762 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46762 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,33,17,21763,8192,64,97546,115014,17664,10281,119042,73770,257,98678,90202,63069]

theorem envBound46763 : H12AffineFastState.Bounded env46763 := by
  intro p hp
  have h : env46763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46762_46763 : H12AffineEnvironment.transform 17 10281 env46762 = env46763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46762 == env46763) = true)

theorem identity46763 : scanCanonicalize (H12AffineFastState.compose env46763 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound46763 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env46764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10281,1025,32769,4161,33,17,21763,8192,64,56577,24909,17664,10281,28937,32801,257,8573,49233,63069]

theorem envBound46764 : H12AffineFastState.Bounded env46764 := by
  intro p hp
  have h : env46764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46763_46764 : H12AffineEnvironment.transform 15 40971 env46763 = env46764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env46763 == env46764) = true)

theorem identity46764 : scanCanonicalize (H12AffineFastState.compose env46764 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46764 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16400,10281,1025,1,4161,33,17,21763,8192,64,23809,24909,17664,10281,28937,33,257,8573,16465,30301]

theorem envBound46765 : H12AffineFastState.Bounded env46765 := by
  intro p hp
  have h : env46765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46764_46765 : H12AffineEnvironment.transform 14 0 env46764 = env46765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46764 == env46765) = true)

theorem identity46765 : scanCanonicalize (H12AffineFastState.compose env46765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,16400,2420,1025,1,4161,33,17,21763,349,64,23809,16400,17664,2420,20564,33,257,32,16465,22272]

theorem envBound46766 : H12AffineFastState.Bounded env46766 := by
  intro p hp
  have h : env46766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46765_46766 : H12AffineEnvironment.transform 12 349 env46765 = env46766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46765 == env46766) = true)

theorem identity46766 : scanCanonicalize (H12AffineFastState.compose env46766 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound46766 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,0,342,5441,2420,1025,1,4161,33,17,82,349,64,2128,5441,4177,2420,1285,33,257,32,5376,593]

theorem envBound46767 : H12AffineFastState.Bounded env46767 := by
  intro p hp
  have h : env46767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46766_46767 : H12AffineEnvironment.transform 13 5457 env46766 = env46767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46766 == env46767) = true)

theorem identity46767 : scanCanonicalize (H12AffineFastState.compose env46767 (packedSelected [4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46767 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env46768 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5457,0,342,5441,2388,1025,1,4161,1,17,82,349,64,2128,5441,4177,2388,1285,1,257,0,5376,593]

theorem envBound46768 : H12AffineFastState.Bounded env46768 := by
  intro p hp
  have h : env46768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46767_46768 : H12AffineEnvironment.transform 4 0 env46767 = env46768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46767 == env46768) = true)

theorem identity46768 : scanCanonicalize (H12AffineFastState.compose env46768 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46768 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46769 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5377,0,262,5393,2308,1025,1,4113,1,17,2,269,16,2048,5393,4097,2308,1285,1,257,0,5376,513]

theorem envBound46769 : H12AffineFastState.Bounded env46769 := by
  intro p hp
  have h : env46769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46768_46769 : H12AffineEnvironment.transform 5 16 env46768 = env46769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46768 == env46769) = true)

theorem identity46769 : scanCanonicalize (H12AffineFastState.compose env46769 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46770 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,0,3,5140,2049,1025,1,4113,1,17,2,8,16,2048,5140,4097,2049,1024,1,4,0,5125,513]

theorem envBound46770 : H12AffineFastState.Bounded env46770 := by
  intro p hp
  have h : env46770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46769_46770 : H12AffineEnvironment.transform 7 5 env46769 = env46770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46769 == env46770) = true)

theorem identity46770 : scanCanonicalize (H12AffineFastState.compose env46770 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound46770 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46771 : List Nat := [2,4,8,16,0,16,8,5,512,1024,523,4096,8,5124,0,3,5140,522,1025,1,4113,1,17,2,8,16,523,5140,4097,522,1024,1,4,0,5125,513]

theorem envBound46771 : H12AffineFastState.Bounded env46771 := by
  intro p hp
  have h : env46771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46770_46771 : H12AffineEnvironment.transform 10 523 env46770 = env46771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env46770 == env46771) = true)

def env46772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101328,2114882,8193,64,97547,115015,17664,2363457,119042,329731,257,2199862,2191387,63068]

theorem envBound46772 : H12AffineFastState.Bounded env46772 := by
  intro p hp
  have h : env46772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46751_46772 : H12AffineEnvironment.transform 6 9 env46751 = env46772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46751 == env46772) = true)

def env46773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,16,21762,8193,64,97547,115015,17664,262145,119042,329731,257,98678,90203,63068]

theorem envBound46773 : H12AffineFastState.Bounded env46773 := by
  intro p hp
  have h : env46773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46772_46773 : H12AffineEnvironment.transform 20 4160 env46772 = env46773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46772 == env46773) = true)

theorem identity46773 : scanCanonicalize (H12AffineFastState.compose env46773 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46773 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1025,8541,4160,272393,16,21762,8193,64,97547,90139,17664,262145,94302,329731,257,73770,90203,22272]

theorem envBound46774 : H12AffineFastState.Bounded env46774 := by
  intro p hp
  have h : env46774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46773_46774 : H12AffineEnvironment.transform 14 8540 env46773 = env46774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46773 == env46774) = true)

theorem identity46774 : scanCanonicalize (H12AffineFastState.compose env46774 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound46774 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,97407,1025,8541,4160,87158,16,21762,8193,64,97547,90139,17664,97406,94302,29820,257,73770,90203,22272]

theorem envBound46775 : H12AffineFastState.Bounded env46775 := by
  intro p hp
  have h : env46775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46774_46775 : H12AffineEnvironment.transform 17 97407 env46774 = env46775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env46774 == env46775) = true)

theorem identity46775 : scanCanonicalize (H12AffineFastState.compose env46775 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound46775 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21591,24908,10280,1025,8541,4160,33,16,21762,8193,64,10588,13388,17664,10281,9225,29820,257,29821,13324,22272]

theorem envBound46776 : H12AffineFastState.Bounded env46776 := by
  intro p hp
  have h : env46776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46775_46776 : H12AffineEnvironment.transform 15 21591 env46775 = env46776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env46775 == env46776) = true)

theorem identity46776 : scanCanonicalize (H12AffineFastState.compose env46776 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound46776 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env46777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8540,9499,4096,10280,1025,8541,4160,33,16,9294,8193,64,10588,13388,13388,10281,9225,1328,257,1329,13324,9804]

theorem envBound46777 : H12AffineFastState.Bounded env46777 := by
  intro p hp
  have h : env46777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46776_46777 : H12AffineEnvironment.transform 13 12620 env46776 = env46777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env46776 == env46777) = true)

theorem identity46777 : scanCanonicalize (H12AffineFastState.compose env46777 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound46777 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env46778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,4404,292,1379,4096,2128,1025,293,4160,33,16,1078,121,64,2340,5172,5172,2129,1137,1328,257,1329,5236,1588]

theorem envBound46778 : H12AffineFastState.Bounded env46778 := by
  intro p hp
  have h : env46778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46777_46778 : H12AffineEnvironment.transform 12 120 env46777 = env46778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env46777 == env46778) = true)

theorem identity46778 : scanCanonicalize (H12AffineFastState.compose env46778 (packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46778 : packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env46779 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,120,4404,292,115,4096,2128,273,293,4160,33,16,294,121,64,2340,4388,4388,2129,353,32,257,33,4452,804]

theorem envBound46779 : H12AffineFastState.Bounded env46779 := by
  intro p hp
  have h : env46779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46778_46779 : H12AffineEnvironment.transform 9 272 env46778 = env46779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46778 == env46779) = true)

theorem identity46779 : scanCanonicalize (H12AffineFastState.compose env46779 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46779 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46780 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,1,115,4096,2128,52,0,4160,33,16,3,121,64,2049,4097,4097,2129,68,32,36,33,4161,513]

theorem envBound46780 : H12AffineFastState.Bounded env46780 := by
  intro p hp
  have h : env46780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46779_46780 : H12AffineEnvironment.transform 7 37 env46779 = env46780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46779 == env46780) = true)

def env46781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21763,8193,64,97547,115015,17664,262144,119042,329731,257,98679,90202,63068]

theorem envBound46781 : H12AffineFastState.Bounded env46781 := by
  intro p hp
  have h : env46781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46772_46781 : H12AffineEnvironment.transform 20 4161 env46772 = env46781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46772 == env46781) = true)

theorem identity46781 : scanCanonicalize (H12AffineFastState.compose env46781 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound46781 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,4161,41341,17,21763,8193,64,97547,115015,17664,35188,119042,98679,257,98679,90202,63068]

theorem envBound46782 : H12AffineFastState.Bounded env46782 := by
  intro p hp
  have h : env46782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46781_46782 : H12AffineEnvironment.transform 17 35188 env46781 = env46782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env46781 == env46782) = true)

theorem identity46782 : scanCanonicalize (H12AffineFastState.compose env46782 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound46782 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env46783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,293,65536,16693,2129,1025,292,4161,8280,17,21763,8193,64,97547,82018,17664,2129,86055,65618,257,65618,90202,30585]

theorem envBound46783 : H12AffineFastState.Bounded env46783 := by
  intro p hp
  have h : env46783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46782_46783 : H12AffineEnvironment.transform 14 293 env46782 = env46783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env46782 == env46783) = true)

theorem identity46783 : scanCanonicalize (H12AffineFastState.compose env46783 (packedSelected [0,2,3,5,6,7,8,11,18,20,28] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound46783 : packedSelected [0,2,3,5,6,7,8,11,18,20,28] rootPS < 2^1333 := by decide +kernel

def env46784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,293,8575,16693,2129,1025,292,4161,8280,17,21763,8193,64,23668,24861,17664,2129,29016,8493,257,8493,16677,30585]

theorem envBound46784 : H12AffineFastState.Bounded env46784 := by
  intro p hp
  have h : env46784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46783_46784 : H12AffineEnvironment.transform 15 8575 env46783 = env46784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env46783 == env46784) = true)

theorem identity46784 : scanCanonicalize (H12AffineFastState.compose env46784 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46784 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env46785 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,81,8203,16449,2129,1025,80,4161,8280,17,21623,8193,64,23668,24681,17524,2129,28716,8281,117,8281,16465,30221]

theorem envBound46785 : H12AffineFastState.Bounded env46785 := by
  intro p hp
  have h : env46785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46784_46785 : H12AffineEnvironment.transform 7 116 env46784 = env46785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46784 == env46785) = true)

theorem identity46785 : scanCanonicalize (H12AffineFastState.compose env46785 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound46785 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46786 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13325,81,8203,13388,2129,1025,80,4161,8280,17,8314,8193,64,10361,5220,12409,2129,1057,8281,117,8281,13404,512]

theorem envBound46786 : H12AffineFastState.Bounded env46786 := by
  intro p hp
  have h : env46786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46785_46786 : H12AffineEnvironment.transform 13 13325 env46785 = env46786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env46785 == env46786) = true)

theorem identity46786 : scanCanonicalize (H12AffineFastState.compose env46786 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound46786 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env46787 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2144,8192,11373,81,8203,11308,2129,1025,80,2081,8280,17,8314,8193,64,10361,3076,10265,2129,1057,8281,117,8281,11324,512]

theorem envBound46787 : H12AffineFastState.Bounded env46787 := by
  intro p hp
  have h : env46787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46786_46787 : H12AffineEnvironment.transform 11 2144 env46786 = env46787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env46786 == env46787) = true)

theorem identity46787 : scanCanonicalize (H12AffineFastState.compose env46787 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46787 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46788 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,2113,8192,11340,81,8203,11277,2129,1025,80,2048,8280,17,8283,8193,64,10328,3076,10265,2129,1024,8281,84,8281,11293,512]

theorem envBound46788 : H12AffineFastState.Bounded env46788 := by
  intro p hp
  have h : env46788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46787_46788 : H12AffineEnvironment.transform 4 1 env46787 = env46788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46787 == env46788) = true)

theorem identity46788 : scanCanonicalize (H12AffineFastState.compose env46788 (packedSelected [0,2,3,4,5,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46788 : packedSelected [0,2,3,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env46789 : List Nat := [2,4,8,16,1,64,9,85,512,1024,0,65,8192,9292,81,8203,9229,81,1025,80,0,8280,17,8283,8193,64,8280,1028,8217,81,1024,8281,84,8281,9245,512]

theorem envBound46789 : H12AffineFastState.Bounded env46789 := by
  intro p hp
  have h : env46789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46788_46789 : H12AffineEnvironment.transform 10 0 env46788 = env46789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46788 == env46789) = true)

theorem identity46789 : scanCanonicalize (H12AffineFastState.compose env46789 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound46789 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env46790 : List Nat := [2,4,8,16,1,64,9,85,512,1024,0,65,89,1045,81,82,1108,81,1025,80,0,1,17,2,88,64,1,1028,64,81,1024,0,84,0,1092,512]

theorem envBound46790 : H12AffineFastState.Bounded env46790 := by
  intro p hp
  have h : env46790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46789_46790 : H12AffineEnvironment.transform 12 89 env46789 = env46790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env46789 == env46790) = true)

theorem identity46790 : scanCanonicalize (H12AffineFastState.compose env46790 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46790 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env46791 : List Nat := [2,4,8,16,1,17,9,4,512,1024,0,16,8,1045,0,3,1029,0,1025,1,0,1,17,2,9,17,1,1028,17,0,1024,0,5,0,1045,512]

theorem envBound46791 : H12AffineFastState.Bounded env46791 := by
  intro p hp
  have h : env46791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46790_46791 : H12AffineEnvironment.transform 5 17 env46790 = env46791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46790 == env46791) = true)

theorem identity46791 : scanCanonicalize (H12AffineFastState.compose env46791 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46792 : List Nat := [2,4,8,1,1,0,9,4,512,1024,0,1,8,1028,0,3,1029,0,1025,1,0,1,0,2,9,0,1,1028,0,0,1024,0,5,0,1028,512]

theorem envBound46792 : H12AffineFastState.Bounded env46792 := by
  intro p hp
  have h : env46792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46791_46792 : H12AffineEnvironment.transform 3 1 env46791 = env46792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46791 == env46792) = true)

theorem identity46792 : scanCanonicalize (H12AffineFastState.compose env46792 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46793 : List Nat := [2,4,8,1,1,0,9,4,512,4,0,1,8,0,0,3,1,0,5,1,0,1,0,2,9,0,1,0,0,0,4,0,5,0,0,512]

theorem envBound46793 : H12AffineFastState.Bounded env46793 := by
  intro p hp
  have h : env46793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46792_46793 : H12AffineEnvironment.transform 9 4 env46792 = env46793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46792 == env46793) = true)

theorem identity46793 : scanCanonicalize (H12AffineFastState.compose env46793 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound46793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46794 : List Nat := [2,4,8,1,1,0,9,4,4,4,0,1,8,0,0,3,1,0,5,1,0,1,0,2,9,0,1,0,0,0,4,0,5,0,0,4]

theorem envBound46794 : H12AffineFastState.Bounded env46794 := by
  intro p hp
  have h : env46794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46793_46794 : H12AffineEnvironment.transform 8 4 env46793 = env46794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env46793 == env46794) = true)

theorem identity46794 : scanCanonicalize (H12AffineFastState.compose env46794 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46794 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46795 : List Nat := [2,0,8,1,1,0,9,0,0,0,0,1,8,0,0,3,1,0,1,1,0,1,0,2,9,0,1,0,0,0,0,0,1,0,0,0]

theorem envBound46795 : H12AffineFastState.Bounded env46795 := by
  intro p hp
  have h : env46795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46794_46795 : H12AffineEnvironment.transform 1 0 env46794 = env46795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46794 == env46795) = true)

def env46796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97667,115150,17664,2363457,119042,329730,257,2199999,2191387,63189]

theorem envBound46796 : H12AffineFastState.Bounded env46796 := by
  intro p hp
  have h : env46796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46750_46796 : H12AffineEnvironment.transform 21 272513 env46750 = env46796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46750 == env46796) = true)

theorem identity46796 : scanCanonicalize (H12AffineFastState.compose env46796 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound46796 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272513,17,21763,8328,64,97667,115150,17664,262144,119042,329730,257,98814,90202,63189]

theorem envBound46797 : H12AffineFastState.Bounded env46797 := by
  intro p hp
  have h : env46797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46796_46797 : H12AffineEnvironment.transform 20 4161 env46796 = env46797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46796 == env46797) = true)

def env46798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21763,8192,64,97547,115014,17664,262144,119042,329730,257,98678,90202,63069]

theorem envBound46798 : H12AffineFastState.Bounded env46798 := by
  intro p hp
  have h : env46798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46797_46798 : H12AffineEnvironment.transform 6 8 env46797 = env46798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46797 == env46798) = true)

theorem identity46798 : scanCanonicalize (H12AffineFastState.compose env46798 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46798 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,32,17,21763,8192,64,97547,115014,17664,10281,119042,73771,257,98678,90202,63069]

theorem envBound46799 : H12AffineFastState.Bounded env46799 := by
  intro p hp
  have h : env46799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46798_46799 : H12AffineEnvironment.transform 17 10281 env46798 = env46799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46798 == env46799) = true)

theorem identity46799 : scanCanonicalize (H12AffineFastState.compose env46799 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46799 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env46800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10281,1025,8540,4161,32,17,21763,8192,64,97547,90139,17664,10281,94303,73771,257,73771,90202,22272]

theorem envBound46800 : H12AffineFastState.Bounded env46800 := by
  intro p hp
  have h : env46800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46799_46800 : H12AffineEnvironment.transform 14 8541 env46799 = env46800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46799 == env46800) = true)

theorem identity46800 : scanCanonicalize (H12AffineFastState.compose env46800 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound46800 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env46801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,24909,10281,1025,8540,4161,32,17,21763,8192,64,31837,24909,17664,10281,28937,8573,257,8573,24844,22272]

theorem envBound46801 : H12AffineFastState.Bounded env46801 := by
  intro p hp
  have h : env46801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46800_46801 : H12AffineEnvironment.transform 15 342 env46800 = env46801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env46800 == env46801) = true)

theorem identity46801 : scanCanonicalize (H12AffineFastState.compose env46801 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46801 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,16400,2420,1025,1,4161,32,17,21763,349,64,23808,16400,17664,2420,20564,32,257,32,16465,22272]

theorem envBound46802 : H12AffineFastState.Bounded env46802 := by
  intro p hp
  have h : env46802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46801_46802 : H12AffineEnvironment.transform 12 349 env46801 = env46802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46801 == env46802) = true)

theorem identity46802 : scanCanonicalize (H12AffineFastState.compose env46802 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound46802 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5125,0,342,5141,2420,1025,1,4161,32,17,262,349,64,2309,5141,4357,2420,1105,32,257,32,5204,773]

theorem envBound46803 : H12AffineFastState.Bounded env46803 := by
  intro p hp
  have h : env46803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46802_46803 : H12AffineEnvironment.transform 13 5125 env46802 = env46803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env46802 == env46803) = true)

def env46804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21763,8193,64,97546,115015,17664,262144,119042,329730,257,98679,90202,63068]

theorem envBound46804 : H12AffineFastState.Bounded env46804 := by
  intro p hp
  have h : env46804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46797_46804 : H12AffineEnvironment.transform 6 9 env46797 = env46804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46797 == env46804) = true)

theorem identity46804 : scanCanonicalize (H12AffineFastState.compose env46804 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound46804 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,4161,41340,17,21763,8193,64,97546,115015,17664,35188,119042,98678,257,98679,90202,63068]

theorem envBound46805 : H12AffineFastState.Bounded env46805 := by
  intro p hp
  have h : env46805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46804_46805 : H12AffineEnvironment.transform 17 35188 env46804 = env46805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env46804 == env46805) = true)

theorem identity46805 : scanCanonicalize (H12AffineFastState.compose env46805 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound46805 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env46806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,65536,13625,31837,1025,29992,4161,21589,17,21763,8193,64,97546,78958,17664,31837,74795,95327,257,95326,90202,885]

theorem envBound46806 : H12AffineFastState.Bounded env46806 := by
  intro p hp
  have h : env46806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46805_46806 : H12AffineEnvironment.transform 14 29993 env46805 = env46806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env46805 == env46806) = true)

theorem identity46806 : scanCanonicalize (H12AffineFastState.compose env46806 (packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46806 : packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env46807 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29708,65536,13340,31837,1025,29709,4161,21589,17,21542,8193,64,97327,78958,17445,31837,74795,95327,36,95326,90202,592]

theorem envBound46807 : H12AffineFastState.Bounded env46807 := by
  intro p hp
  have h : env46807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46806_46807 : H12AffineEnvironment.transform 7 37 env46806 = env46807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46806 == env46807) = true)

theorem identity46807 : scanCanonicalize (H12AffineFastState.compose env46807 (packedSelected [0,3,4,5,7,10,12,15,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound46807 : packedSelected [0,3,4,5,7,10,12,15,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46808 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29708,115,13340,31837,1025,29709,4161,21589,17,21542,8193,64,31836,13341,17445,31837,9304,29740,36,29741,24617,592]

theorem envBound46808 : H12AffineFastState.Bounded env46808 := by
  intro p hp
  have h : env46808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46807_46808 : H12AffineEnvironment.transform 15 115 env46807 = env46808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env46807 == env46808) = true)

theorem identity46808 : scanCanonicalize (H12AffineFastState.compose env46808 (packedSelected [0,3,4,5,7,9,10,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound46808 : packedSelected [0,3,4,5,7,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env46809 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,16384,21621,115,5221,23588,1025,21620,4161,21589,17,21542,120,64,23589,5220,17445,23588,1057,21589,36,21588,16464,592]

theorem envBound46809 : H12AffineFastState.Bounded env46809 := by
  intro p hp
  have h : env46809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46808_46809 : H12AffineEnvironment.transform 12 121 env46808 = env46809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env46808 == env46809) = true)

theorem identity46809 : scanCanonicalize (H12AffineFastState.compose env46809 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound46809 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46810 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5156,81,115,5221,2048,1025,80,4161,113,17,2,120,64,2049,5220,4097,2048,1057,113,36,112,5236,592]

theorem envBound46810 : H12AffineFastState.Bounded env46810 := by
  intro p hp
  have h : env46810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46809_46810 : H12AffineEnvironment.transform 13 5156 env46809 = env46810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env46809 == env46810) = true)

theorem identity46810 : scanCanonicalize (H12AffineFastState.compose env46810 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound46810 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env46811 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,17,121,1077,81,115,1140,2048,1025,80,80,113,17,2,120,64,2049,1141,16,2048,1057,113,36,112,1125,592]

theorem envBound46811 : H12AffineFastState.Bounded env46811 := by
  intro p hp
  have h : env46811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46810_46811 : H12AffineEnvironment.transform 11 17 env46810 = env46811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env46810 == env46811) = true)

theorem identity46811 : scanCanonicalize (H12AffineFastState.compose env46811 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46811 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env46812 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1,17,121,1077,81,115,1140,1,1025,80,80,113,17,2,120,64,0,1141,16,1,1057,113,36,112,1125,592]

theorem envBound46812 : H12AffineFastState.Bounded env46812 := by
  intro p hp
  have h : env46812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46811_46812 : H12AffineEnvironment.transform 10 1 env46811 = env46812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46811 == env46812) = true)

theorem identity46812 : scanCanonicalize (H12AffineFastState.compose env46812 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46812 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env46813 : List Nat := [2,4,8,16,32,64,9,37,512,52,1,17,121,1,81,115,64,1,53,80,80,113,17,2,120,64,0,65,16,1,21,113,36,112,81,592]

theorem envBound46813 : H12AffineFastState.Bounded env46813 := by
  intro p hp
  have h : env46813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46812_46813 : H12AffineEnvironment.transform 9 52 env46812 = env46813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46812 == env46813) = true)

def env46814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543747,115150,17665,2363456,119043,4268163,257,2199998,2191386,63188]

theorem envBound46814 : H12AffineFastState.Bounded env46814 := by
  intro p hp
  have h : env46814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46749_46814 : H12AffineEnvironment.transform 22 2101329 env46749 = env46814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env46749 == env46814) = true)

def env46815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97667,115150,17665,2363456,119043,329731,257,2199998,2191386,63188]

theorem envBound46815 : H12AffineFastState.Bounded env46815 := by
  intro p hp
  have h : env46815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46814_46815 : H12AffineEnvironment.transform 21 272512 env46814 = env46815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46814 == env46815) = true)

theorem identity46815 : scanCanonicalize (H12AffineFastState.compose env46815 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound46815 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,262144,1025,29908,2097152,272512,2101329,2114882,8328,64,97667,79131,17665,2363456,75222,329731,257,2188651,2191386,513]

theorem envBound46816 : H12AffineFastState.Bounded env46816 := by
  intro p hp
  have h : env46816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46815_46816 : H12AffineEnvironment.transform 14 29909 env46815 = env46816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env46815 == env46816) = true)

def env46817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,10400,1025,29908,2097152,32,2101329,2114882,8328,64,97667,79131,17665,2111712,75222,73891,257,2188651,2191386,513]

theorem envBound46817 : H12AffineFastState.Bounded env46817 := by
  intro p hp
  have h : env46817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46816_46817 : H12AffineEnvironment.transform 17 10400 env46816 = env46817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46816 == env46817) = true)

theorem identity46817 : scanCanonicalize (H12AffineFastState.compose env46817 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21727) := by decide +kernel

theorem selectedBound46817 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21727,13509,10400,1025,29908,2097152,32,2101329,2114882,8328,64,10588,25028,17665,2111712,28937,29820,257,2109876,2106565,513]

theorem envBound46818 : H12AffineFastState.Bounded env46818 := by
  intro p hp
  have h : env46818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46817_46818 : H12AffineEnvironment.transform 15 21727 env46817 = env46818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21727 env46817 == env46818) = true)

theorem identity46818 : scanCanonicalize (H12AffineFastState.compose env46818 (packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound46818 : packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env46819 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,29909,21727,13509,10400,1025,29908,2097152,32,2101329,2114799,8328,64,10481,24681,17580,2111712,28836,29820,172,2109465,2106565,513]

theorem envBound46819 : H12AffineFastState.Bounded env46819 := by
  intro p hp
  have h : env46819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46818_46819 : H12AffineEnvironment.transform 7 173 env46818 = env46819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46818 == env46819) = true)

theorem identity46819 : scanCanonicalize (H12AffineFastState.compose env46819 (packedSelected [1,4,5,9,10,12,14,15,17,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 12512) := by decide +kernel

theorem selectedBound46819 : packedSelected [1,4,5,9,10,12,14,15,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env46820 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,29909,21727,13509,10400,1025,29908,12512,32,8369,29711,8328,64,10481,24681,17580,2048,28836,29820,172,249,5157,513]

theorem envBound46820 : H12AffineFastState.Bounded env46820 := by
  intro p hp
  have h : env46820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46819_46820 : H12AffineEnvironment.transform 20 12512 env46819 = env46820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12512 env46819 == env46820) = true)

theorem identity46820 : scanCanonicalize (H12AffineFastState.compose env46820 (packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound46820 : packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env46821 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,5236,8353,171,13509,10400,1025,8352,12512,32,8369,8315,8328,64,10481,13341,4312,2048,9424,8200,172,249,5157,513]

theorem envBound46821 : H12AffineFastState.Bounded env46821 := by
  intro p hp
  have h : env46821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46820_46821 : H12AffineEnvironment.transform 13 5236 env46820 = env46821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env46820 == env46821) = true)

theorem identity46821 : scanCanonicalize (H12AffineFastState.compose env46821 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7381) := by decide +kernel

theorem selectedBound46821 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env46822 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,7381,5236,7284,171,2064,5237,1025,7285,3125,32,7268,7342,7261,64,5156,2248,4312,2048,6149,7389,172,249,5157,513]

theorem envBound46822 : H12AffineFastState.Bounded env46822 := by
  intro p hp
  have h : env46822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46821_46822 : H12AffineEnvironment.transform 12 7381 env46821 = env46822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7381 env46821 == env46822) = true)

theorem identity46822 : scanCanonicalize (H12AffineFastState.compose env46822 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound46822 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46823 : List Nat := [2,4,8,16,32,64,128,173,512,1024,136,4096,5213,5236,5372,171,152,5237,1025,5373,1213,32,5356,5158,5333,64,5156,64,4312,136,4237,5205,172,249,5157,513]

theorem envBound46823 : H12AffineFastState.Bounded env46823 := by
  intro p hp
  have h : env46823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46822_46823 : H12AffineEnvironment.transform 10 136 env46822 = env46823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env46822 == env46823) = true)

theorem identity46823 : scanCanonicalize (H12AffineFastState.compose env46823 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound46823 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env46824 : List Nat := [2,4,8,16,32,64,24,53,512,1024,16,4096,5213,5236,5220,51,0,5237,1025,5221,1061,32,5236,5158,5197,64,5156,64,4160,16,4117,5205,52,97,5157,513]

theorem envBound46824 : H12AffineFastState.Bounded env46824 := by
  intro p hp
  have h : env46824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46823_46824 : H12AffineEnvironment.transform 6 24 env46823 = env46824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env46823 == env46824) = true)

theorem identity46824 : scanCanonicalize (H12AffineFastState.compose env46824 (packedSelected [4,5,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound46824 : packedSelected [4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46825 : List Nat := [2,4,8,16,32,64,24,53,512,1024,16,529,1612,1637,1653,51,0,1636,1025,1652,1061,32,1637,1591,1628,64,1589,64,593,16,516,1604,52,97,1588,513]

theorem envBound46825 : H12AffineFastState.Bounded env46825 := by
  intro p hp
  have h : env46825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46824_46825 : H12AffineEnvironment.transform 11 529 env46824 = env46825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env46824 == env46825) = true)

def env46826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,10401,1025,29908,2097152,33,2101329,2114882,8328,64,97667,79131,17665,2111713,75222,73890,257,2188651,2191386,513]

theorem envBound46826 : H12AffineFastState.Bounded env46826 := by
  intro p hp
  have h : env46826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46816_46826 : H12AffineEnvironment.transform 17 10401 env46816 = env46826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46816 == env46826) = true)

def env46827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13509,10401,1025,8660,2097152,33,2101329,2101314,8328,64,75907,79131,4097,2111713,75222,73890,257,2175083,2172186,513]

theorem envBound46827 : H12AffineFastState.Bounded env46827 := by
  intro p hp
  have h : env46827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46826_46827 : H12AffineEnvironment.transform 13 5376 env46826 = env46827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46826 == env46827) = true)

theorem identity46827 : scanCanonicalize (H12AffineFastState.compose env46827 (packedSelected [16,20] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound46827 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13509,10401,1025,8660,4296,33,153,138,8328,64,75907,79131,4097,10281,75222,73890,257,73891,79314,513]

theorem envBound46828 : H12AffineFastState.Bounded env46828 := by
  intro p hp
  have h : env46828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46827_46828 : H12AffineEnvironment.transform 20 4296 env46827 = env46828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env46827 == env46828) = true)

theorem identity46828 : scanCanonicalize (H12AffineFastState.compose env46828 (packedSelected [0,1,7,8,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound46828 : packedSelected [0,1,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env46829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8323,13509,10401,1025,8660,4296,33,153,138,8328,64,2048,5528,4097,10281,1365,33,257,32,5457,513]

theorem envBound46829 : H12AffineFastState.Bounded env46829 := by
  intro p hp
  have h : env46829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46828_46829 : H12AffineEnvironment.transform 15 8323 env46828 = env46829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env46828 == env46829) = true)

theorem identity46829 : scanCanonicalize (H12AffineFastState.compose env46829 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46829 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,216,398,5576,2476,1025,217,4296,33,153,138,389,64,2048,5528,4097,2340,1365,33,257,32,5457,513]

theorem envBound46830 : H12AffineFastState.Bounded env46830 := by
  intro p hp
  have h : env46830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46829_46830 : H12AffineEnvironment.transform 12 269 env46829 = env46830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46829 == env46830) = true)

theorem identity46830 : scanCanonicalize (H12AffineFastState.compose env46830 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46830 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env46831 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,136,398,5528,2476,1025,137,4248,33,153,138,389,16,2048,5528,4097,2340,1285,33,257,32,5377,513]

theorem envBound46831 : H12AffineFastState.Bounded env46831 := by
  intro p hp
  have h : env46831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46830_46831 : H12AffineEnvironment.transform 5 16 env46830 = env46831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46830 == env46831) = true)

theorem identity46831 : scanCanonicalize (H12AffineFastState.compose env46831 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46831 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46832 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5157,136,171,5309,2185,1025,137,4248,33,153,138,160,16,2048,5309,4097,2049,1056,33,36,32,5156,513]

theorem envBound46832 : H12AffineFastState.Bounded env46832 := by
  intro p hp
  have h : env46832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46831_46832 : H12AffineEnvironment.transform 7 37 env46831 = env46832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46831 == env46832) = true)

theorem identity46832 : scanCanonicalize (H12AffineFastState.compose env46832 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound46832 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46833 : List Nat := [2,4,8,16,32,16,128,37,512,1024,522,4096,40,5157,136,171,5309,643,1025,137,4248,33,153,138,160,16,522,5309,4097,523,1056,33,36,32,5156,513]

theorem envBound46833 : H12AffineFastState.Bounded env46833 := by
  intro p hp
  have h : env46833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46832_46833 : H12AffineEnvironment.transform 10 522 env46832 = env46833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env46832 == env46833) = true)

def env46834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13509,10401,1025,8661,2097152,33,2101329,2101315,8328,64,75906,79131,4096,2111713,75222,73890,257,2175082,2172187,513]

theorem envBound46834 : H12AffineFastState.Bounded env46834 := by
  intro p hp
  have h : env46834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46826_46834 : H12AffineEnvironment.transform 13 5377 env46826 = env46834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46826 == env46834) = true)

theorem identity46834 : scanCanonicalize (H12AffineFastState.compose env46834 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46834 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,13389,10281,1025,8541,2097152,33,2101329,2101315,8192,64,75786,79131,4096,2111593,75102,73770,257,2175082,2172187,513]

theorem envBound46835 : H12AffineFastState.Bounded env46835 := by
  intro p hp
  have h : env46835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46834_46835 : H12AffineEnvironment.transform 6 8 env46834 = env46835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46834 == env46835) = true)

theorem identity46835 : scanCanonicalize (H12AffineFastState.compose env46835 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 69910) := by decide +kernel

theorem selectedBound46835 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,13389,10281,1025,8541,69910,33,65863,65877,8192,64,75786,79131,4096,76159,75102,73770,257,8572,13325,513]

theorem envBound46836 : H12AffineFastState.Bounded env46836 := by
  intro p hp
  have h : env46836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46835_46836 : H12AffineEnvironment.transform 20 69910 env46835 = env46836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69910 env46835 == env46836) = true)

theorem identity46836 : scanCanonicalize (H12AffineFastState.compose env46836 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46836 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13389,10281,1025,8541,12573,33,8524,8542,8192,64,2049,5392,4096,2420,1365,33,257,8572,13325,513]

theorem envBound46837 : H12AffineFastState.Bounded env46837 := by
  intro p hp
  have h : env46837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46836_46837 : H12AffineEnvironment.transform 15 8203 env46836 = env46837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46836 == env46837) = true)

theorem identity46837 : scanCanonicalize (H12AffineFastState.compose env46837 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46837 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env46838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2420,1025,0,4160,33,17,3,349,64,2049,5392,4096,2420,1365,33,257,33,5456,513]

theorem envBound46838 : H12AffineFastState.Bounded env46838 := by
  intro p hp
  have h : env46838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46837_46838 : H12AffineEnvironment.transform 12 349 env46837 = env46838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46837 == env46838) = true)

theorem identity46838 : scanCanonicalize (H12AffineFastState.compose env46838 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound46838 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,821,349,1588,1,342,1573,2420,1025,0,885,33,17,3,349,64,2049,1573,821,2420,1365,33,257,33,1637,513]

theorem envBound46839 : H12AffineFastState.Bounded env46839 := by
  intro p hp
  have h : env46839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46838_46839 : H12AffineEnvironment.transform 11 821 env46838 = env46839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env46838 == env46839) = true)

theorem identity46839 : scanCanonicalize (H12AffineFastState.compose env46839 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46839 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46840 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,821,268,1588,1,263,1573,2341,1025,0,804,33,17,3,268,17,2049,1573,821,2341,1284,33,257,33,1588,513]

theorem envBound46840 : H12AffineFastState.Bounded env46840 := by
  intro p hp
  have h : env46840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46839_46840 : H12AffineEnvironment.transform 5 17 env46839 = env46840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46839 == env46840) = true)

theorem identity46840 : scanCanonicalize (H12AffineFastState.compose env46840 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound46840 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46841 : List Nat := [2,4,8,16,32,17,8,256,308,1024,2048,1,268,1280,1,263,1297,2341,1025,0,16,33,17,3,268,17,2049,1297,1,2341,1284,33,257,33,1280,309]

theorem envBound46841 : H12AffineFastState.Bounded env46841 := by
  intro p hp
  have h : env46841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46840_46841 : H12AffineEnvironment.transform 8 308 env46840 = env46841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env46840 == env46841) = true)

theorem identity46841 : scanCanonicalize (H12AffineFastState.compose env46841 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46841 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46842 : List Nat := [2,4,8,16,32,17,8,256,308,273,2048,1,268,17,1,263,0,2341,272,0,16,33,17,3,268,17,2049,0,1,2341,21,33,257,33,17,309]

theorem envBound46842 : H12AffineFastState.Bounded env46842 := by
  intro p hp
  have h : env46842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46841_46842 : H12AffineEnvironment.transform 9 273 env46841 = env46842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46841 == env46842) = true)

theorem identity46842 : scanCanonicalize (H12AffineFastState.compose env46842 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound46842 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46843 : List Nat := [2,4,8,16,32,17,8,52,0,37,2048,1,56,17,1,51,0,2065,36,0,16,33,17,3,56,17,2049,0,1,2065,21,33,53,33,17,1]

theorem envBound46843 : H12AffineFastState.Bounded env46843 := by
  intro p hp
  have h : env46843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46842_46843 : H12AffineEnvironment.transform 7 52 env46842 = env46843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env46842 == env46843) = true)

theorem identity46843 : scanCanonicalize (H12AffineFastState.compose env46843 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound46843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46844 : List Nat := [2,4,8,16,26,17,8,14,0,31,2048,1,2,17,1,9,0,2065,30,0,16,27,17,3,2,17,2049,0,1,2065,21,27,15,27,17,1]

theorem envBound46844 : H12AffineFastState.Bounded env46844 := by
  intro p hp
  have h : env46844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46843_46844 : H12AffineEnvironment.transform 4 26 env46843 = env46844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env46843 == env46844) = true)

theorem identity46844 : scanCanonicalize (H12AffineFastState.compose env46844 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46844 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46845 : List Nat := [2,4,8,16,26,17,8,14,0,31,0,1,2,17,1,9,0,17,30,0,16,27,17,3,2,17,1,0,1,17,21,27,15,27,17,1]

theorem envBound46845 : H12AffineFastState.Bounded env46845 := by
  intro p hp
  have h : env46845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46844_46845 : H12AffineEnvironment.transform 10 0 env46844 = env46845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46844 == env46845) = true)

theorem identity46845 : scanCanonicalize (H12AffineFastState.compose env46845 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46845 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env46846 : List Nat := [2,4,8,0,10,1,8,14,0,15,0,1,2,1,1,9,0,1,14,0,0,11,1,3,2,1,1,0,1,1,5,11,15,11,1,1]

theorem envBound46846 : H12AffineFastState.Bounded env46846 := by
  intro p hp
  have h : env46846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46845_46846 : H12AffineEnvironment.transform 3 0 env46845 = env46846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46845 == env46846) = true)

def env46847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97666,115150,17665,2363456,119043,329730,257,2199998,2191386,63188]

theorem envBound46847 : H12AffineFastState.Bounded env46847 := by
  intro p hp
  have h : env46847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46814_46847 : H12AffineEnvironment.transform 21 272513 env46814 = env46847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46814 == env46847) = true)

theorem identity46847 : scanCanonicalize (H12AffineFastState.compose env46847 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound46847 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58517,272513,62660,41431,8328,64,97666,115150,17665,324821,119043,329730,257,95531,103567,63188]

theorem envBound46848 : H12AffineFastState.Bounded env46848 := by
  intro p hp
  have h : env46848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46847_46848 : H12AffineEnvironment.transform 20 58517 env46847 = env46848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env46847 == env46848) = true)

def env46849 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58517,272513,62612,41351,8328,16,97666,115102,17665,324741,119043,329730,257,95531,103567,63108]

theorem envBound46849 : H12AffineFastState.Bounded env46849 := by
  intro p hp
  have h : env46849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46848_46849 : H12AffineEnvironment.transform 5 16 env46848 = env46849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46848 == env46849) = true)

theorem identity46849 : scanCanonicalize (H12AffineFastState.compose env46849 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound46849 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46850 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,64808,1025,32769,58517,54697,62612,41351,8328,16,97666,115102,17665,2477,119043,128298,257,95531,103567,63108]

theorem envBound46850 : H12AffineFastState.Bounded env46850 := by
  intro p hp
  have h : env46850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46849_46850 : H12AffineEnvironment.transform 17 64808 env46849 = env46850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env46849 == env46850) = true)

theorem identity46850 : scanCanonicalize (H12AffineFastState.compose env46850 (packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound46850 : packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env46851 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,65536,13340,2340,1025,29709,4249,8613,152,21899,8328,16,97666,79250,17665,2477,75023,65830,257,95531,90243,648]

theorem envBound46851 : H12AffineFastState.Bounded env46851 := by
  intro p hp
  have h : env46851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46850_46851 : H12AffineEnvironment.transform 14 29708 env46850 = env46851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env46850 == env46851) = true)

theorem identity46851 : scanCanonicalize (H12AffineFastState.compose env46851 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound46851 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env46852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4405,9529,65536,13340,2340,1025,9528,4249,8613,152,1214,8328,16,76983,79250,5172,2477,75023,65830,257,74782,78262,648]

theorem envBound46852 : H12AffineFastState.Bounded env46852 := by
  intro p hp
  have h : env46852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46851_46852 : H12AffineEnvironment.transform 13 4405 env46851 = env46852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env46851 == env46852) = true)

theorem identity46852 : scanCanonicalize (H12AffineFastState.compose env46852 (packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound46852 : packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS < 2^1333 := by decide +kernel

def env46853 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4405,9529,8323,13340,2340,1025,9528,4249,8613,152,1214,8328,16,3124,5393,5172,2477,1420,8613,257,1181,4405,648]

theorem envBound46853 : H12AffineFastState.Bounded env46853 := by
  intro p hp
  have h : env46853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46852_46853 : H12AffineEnvironment.transform 15 8323 env46852 = env46853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env46852 == env46853) = true)

def env46854 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58517,272513,62613,41350,8328,17,97666,115103,17665,324740,119043,329730,257,95531,103567,63109]

theorem envBound46854 : H12AffineFastState.Bounded env46854 := by
  intro p hp
  have h : env46854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46848_46854 : H12AffineEnvironment.transform 5 17 env46848 = env46854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46848 == env46854) = true)

theorem identity46854 : scanCanonicalize (H12AffineFastState.compose env46854 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound46854 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46855 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,122146,1025,32769,58517,128419,62613,41350,8328,17,97666,115103,17665,76198,119043,54560,257,95531,103567,63109]

theorem envBound46855 : H12AffineFastState.Bounded env46855 := by
  intro p hp
  have h : env46855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46854_46855 : H12AffineEnvironment.transform 17 122146 env46854 = env46855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env46854 == env46855) = true)

theorem identity46855 : scanCanonicalize (H12AffineFastState.compose env46855 (packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound46855 : packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46856 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,263,49168,56357,1025,32769,58517,62628,62613,41350,8328,17,31877,49304,17665,10401,53252,54560,257,29740,38280,63109]

theorem envBound46856 : H12AffineFastState.Bounded env46856 := by
  intro p hp
  have h : env46856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46855_46856 : H12AffineEnvironment.transform 15 263 env46855 = env46856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env46855 == env46856) = true)

theorem identity46856 : scanCanonicalize (H12AffineFastState.compose env46856 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46856 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env46857 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,263,38160,35109,1025,32769,45461,41380,41365,41350,8328,17,10629,38296,4097,10401,34052,32800,257,8492,38280,41861]

theorem envBound46857 : H12AffineFastState.Bounded env46857 := by
  intro p hp
  have h : env46857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46856_46857 : H12AffineEnvironment.transform 13 5376 env46856 = env46857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46856 == env46857) = true)

theorem identity46857 : scanCanonicalize (H12AffineFastState.compose env46857 (packedSelected [0,1,3,4,5,7,8,9,11,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 15777) := by decide +kernel

theorem selectedBound46857 : packedSelected [0,1,3,4,5,7,8,9,11,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env46858 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,15777,263,10417,13444,1025,15776,3124,7173,7220,7207,8328,17,10629,10297,4097,10401,14501,15745,257,8492,10281,7716]

theorem envBound46858 : H12AffineFastState.Bounded env46858 := by
  intro p hp
  have h : env46858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46857_46858 : H12AffineEnvironment.transform 14 15777 env46857 = env46858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15777 env46857 == env46858) = true)

theorem identity46858 : scanCanonicalize (H12AffineFastState.compose env46858 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound46858 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env46859 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3109,8192,2341,8580,263,10417,10401,1025,8581,3124,32,17,2,8328,17,10629,10297,3108,10401,9344,8612,257,8492,10281,513]

theorem envBound46859 : H12AffineFastState.Bounded env46859 := by
  intro p hp
  have h : env46859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46858_46859 : H12AffineEnvironment.transform 11 3109 env46858 = env46859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env46858 == env46859) = true)

theorem identity46859 : scanCanonicalize (H12AffineFastState.compose env46859 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound46859 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env46860 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3109,389,2341,1,263,2356,2340,1025,0,3124,32,17,2,269,17,2048,2492,3108,2340,1285,33,257,169,2476,513]

theorem envBound46860 : H12AffineFastState.Bounded env46860 := by
  intro p hp
  have h : env46860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46859_46860 : H12AffineEnvironment.transform 12 389 env46859 = env46860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env46859 == env46860) = true)

theorem identity46860 : scanCanonicalize (H12AffineFastState.compose env46860 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46860 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46861 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,2341,1,263,2356,2340,1025,0,3124,32,17,2,269,17,2048,2357,3108,2340,1285,33,257,32,2341,513]

theorem envBound46861 : H12AffineFastState.Bounded env46861 := by
  intro p hp
  have h : env46861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46860_46861 : H12AffineEnvironment.transform 6 9 env46860 = env46861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46860 == env46861) = true)

theorem identity46861 : scanCanonicalize (H12AffineFastState.compose env46861 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound46861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46862 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1029,32,268,1312,1,263,1329,1313,1025,0,49,32,17,2,269,17,1029,1328,33,1313,1285,33,257,32,1312,513]

theorem envBound46862 : H12AffineFastState.Bounded env46862 := by
  intro p hp
  have h : env46862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46861_46862 : H12AffineEnvironment.transform 10 1029 env46861 = env46862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env46861 == env46862) = true)

theorem identity46862 : scanCanonicalize (H12AffineFastState.compose env46862 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound46862 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46863 : List Nat := [2,4,8,16,32,17,9,256,512,785,788,32,268,561,1,263,544,560,784,0,49,32,17,2,269,17,788,545,33,560,532,33,257,32,561,513]

theorem envBound46863 : H12AffineFastState.Bounded env46863 := by
  intro p hp
  have h : env46863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46862_46863 : H12AffineEnvironment.transform 9 785 env46862 = env46863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env46862 == env46863) = true)

theorem identity46863 : scanCanonicalize (H12AffineFastState.compose env46863 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46863 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46864 : List Nat := [2,4,8,16,32,17,9,256,0,273,276,32,268,49,1,263,32,48,272,0,49,32,17,2,269,17,276,33,33,48,20,33,257,32,49,1]

theorem envBound46864 : H12AffineFastState.Bounded env46864 := by
  intro p hp
  have h : env46864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46863_46864 : H12AffineEnvironment.transform 8 0 env46863 = env46864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46863 == env46864) = true)

theorem identity46864 : scanCanonicalize (H12AffineFastState.compose env46864 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46864 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46865 : List Nat := [2,4,8,16,32,17,9,4,0,21,16,32,8,49,1,3,32,48,20,0,49,32,17,2,9,17,16,33,33,48,20,33,5,32,49,1]

theorem envBound46865 : H12AffineFastState.Bounded env46865 := by
  intro p hp
  have h : env46865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46864_46865 : H12AffineEnvironment.transform 7 4 env46864 = env46865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46864 == env46865) = true)

theorem identity46865 : scanCanonicalize (H12AffineFastState.compose env46865 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46865 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46866 : List Nat := [2,4,8,1,32,0,9,4,0,4,1,32,8,32,1,3,32,33,5,0,32,32,0,2,9,0,1,33,33,33,5,33,5,32,32,1]

theorem envBound46866 : H12AffineFastState.Bounded env46866 := by
  intro p hp
  have h : env46866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46865_46866 : H12AffineEnvironment.transform 3 1 env46865 = env46866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46865 == env46866) = true)

theorem identity46866 : scanCanonicalize (H12AffineFastState.compose env46866 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46867 : List Nat := [2,4,8,1,1,0,9,4,0,4,1,1,8,1,1,3,1,0,5,0,1,1,0,2,9,0,1,0,0,0,5,0,5,1,1,1]

theorem envBound46867 : H12AffineFastState.Bounded env46867 := by
  intro p hp
  have h : env46867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46866_46867 : H12AffineEnvironment.transform 4 1 env46866 = env46867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46866 == env46867) = true)

def env46868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025490,115151,10507600,8650768,10600787,4268162,257,8487406,8478794,10544772]

theorem envBound46868 : H12AffineFastState.Bounded env46868 := by
  intro p hp
  have h : env46868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46748_46868 : H12AffineEnvironment.transform 16 49169 env46748 = env46868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env46748 == env46868) = true)

def env46869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543746,115151,17664,2363456,119043,4268162,257,2199998,2191386,63188]

theorem envBound46869 : H12AffineFastState.Bounded env46869 := by
  intro p hp
  have h : env46869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46868_46869 : H12AffineEnvironment.transform 22 2101328 env46868 = env46869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env46868 == env46869) = true)

def env46870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97666,115151,17664,2363456,119043,329730,257,2199998,2191386,63188]

theorem envBound46870 : H12AffineFastState.Bounded env46870 := by
  intro p hp
  have h : env46870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46869_46870 : H12AffineEnvironment.transform 21 272512 env46869 = env46870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46869 == env46870) = true)

theorem identity46870 : scanCanonicalize (H12AffineFastState.compose env46870 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound46870 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115870,272512,120014,98781,8328,64,97666,115151,17664,382174,119043,329730,257,21792,46212,63188]

theorem envBound46871 : H12AffineFastState.Bounded env46871 := by
  intro p hp
  have h : env46871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46870_46871 : H12AffineEnvironment.transform 20 115870 env46870 = env46871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env46870 == env46871) = true)

def env46872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115734,272392,119878,98645,8192,64,97546,115015,17664,382038,119043,329730,257,21792,46092,63068]

theorem envBound46872 : H12AffineFastState.Bounded env46872 := by
  intro p hp
  have h : env46872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46871_46872 : H12AffineEnvironment.transform 6 8 env46871 = env46872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46871 == env46872) = true)

theorem identity46872 : scanCanonicalize (H12AffineFastState.compose env46872 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46872 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env46873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,65536,49169,262144,1025,32769,115734,264453,119878,98645,269,64,89095,115015,17664,382038,119043,329730,257,21792,38145,55121]

theorem envBound46873 : H12AffineFastState.Bounded env46873 := by
  intro p hp
  have h : env46873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46872_46873 : H12AffineEnvironment.transform 12 269 env46872 = env46873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46872 == env46873) = true)

theorem identity46873 : scanCanonicalize (H12AffineFastState.compose env46873 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46873 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env46874 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,65536,49169,262144,1025,32769,115734,264453,119831,98564,269,17,89095,114966,17664,381959,119043,329730,257,21792,38145,55040]

theorem envBound46874 : H12AffineFastState.Bounded env46874 := by
  intro p hp
  have h : env46874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46873_46874 : H12AffineEnvironment.transform 5 17 env46873 = env46874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46873 == env46874) = true)

theorem identity46874 : scanCanonicalize (H12AffineFastState.compose env46874 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound46874 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS < 2^1333 := by decide +kernel

def env46875 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,65536,5392,262144,1025,21760,69911,264453,65814,87045,269,17,89095,70679,17664,327942,66562,329730,257,21792,16384,513]

theorem envBound46875 : H12AffineFastState.Bounded env46875 := by
  intro p hp
  have h : env46875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46874_46875 : H12AffineEnvironment.transform 14 21761 env46874 = env46875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env46874 == env46875) = true)

theorem identity46875 : scanCanonicalize (H12AffineFastState.compose env46875 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound46875 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46876 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,262,5392,262144,1025,21760,4113,264453,16,21763,269,17,23809,5393,17664,262144,1284,264452,257,21792,16384,513]

theorem envBound46876 : H12AffineFastState.Bounded env46876 := by
  intro p hp
  have h : env46876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46875_46876 : H12AffineEnvironment.transform 15 262 env46875 = env46876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env46875 == env46876) = true)

theorem identity46876 : scanCanonicalize (H12AffineFastState.compose env46876 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound46876 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46877 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,262,5392,23589,1025,21760,4113,21792,16,21763,269,17,23809,5393,17664,23589,1284,21793,257,21792,16384,513]

theorem envBound46877 : H12AffineFastState.Bounded env46877 := by
  intro p hp
  have h : env46877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46876_46877 : H12AffineEnvironment.transform 17 23589 env46876 = env46877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env46876 == env46877) = true)

theorem identity46877 : scanCanonicalize (H12AffineFastState.compose env46877 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46877 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env46878 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4113,33,16,2,269,17,2048,5393,4097,2340,1284,32,257,33,5377,513]

theorem envBound46878 : H12AffineFastState.Bounded env46878 := by
  intro p hp
  have h : env46878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46877_46878 : H12AffineEnvironment.transform 13 5377 env46877 = env46878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46877 == env46878) = true)

theorem identity46878 : scanCanonicalize (H12AffineFastState.compose env46878 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

end H12CloudChart1